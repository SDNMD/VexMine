package vexbot.api;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.server.level.ServerPlayer;
import vexbot.VexBot;

public final class VexBotEvents {
   private static final List<PlayerDeathListener> DEATH = new CopyOnWriteArrayList();

   private VexBotEvents() {
   }

   public static void registerDeathListener(PlayerDeathListener l) {
      if (l != null) {
         DEATH.add(l);
      }

   }

   public static void fireDeath(ServerPlayer victim, ServerPlayer killer) {
      for(PlayerDeathListener l : DEATH) {
         try {
            l.onDeath(victim, killer);
         } catch (Throwable t) {
            VexBot.LOGGER.error("[VexBot] add-on death listener crashed: {}", t.toString());
         }
      }

   }

   @FunctionalInterface
   public interface PlayerDeathListener {
      void onDeath(ServerPlayer var1, ServerPlayer var2);
   }
}
