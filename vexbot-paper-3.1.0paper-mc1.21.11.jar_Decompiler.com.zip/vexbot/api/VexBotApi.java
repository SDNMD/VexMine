package vexbot.api;

import java.util.List;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import vexbot.bot.BotManager;
import vexbot.bot.loadout.RandomGearGenerator;
import vexbot.kit.KitManager;
import vexbot.kit.KitShareCodec;

public final class VexBotApi {
   private VexBotApi() {
   }

   public static ItemStack[] decodeKitId(MinecraftServer server, String kitId) {
      try {
         return KitShareCodec.decode(server, kitId).stacks();
      } catch (RuntimeException var3) {
         return null;
      }
   }

   public static boolean applyKitId(MinecraftServer server, ServerPlayer target, String kitId) {
      try {
         KitShareCodec.SharedKit shared = KitShareCodec.decode(server, kitId);
         if (shared == null) {
            return false;
         } else {
            KitManager.apply(target, shared.stacks());
            KitManager.applyEnder(target, shared.ender());
            return true;
         }
      } catch (RuntimeException var4) {
         return false;
      }
   }

   public static boolean spawnBot(MinecraftServer server, String name, Vec3 pos, float yaw, String dimensionId) {
      return BotManager.peekSpawnStaticBlockReason(server, name) != null ? false : BotManager.spawn(server, name, pos.x, pos.y, pos.z, yaw, 0.0F, dimensionId);
   }

   public static boolean despawnBot(MinecraftServer server, String name) {
      return BotManager.kill(server, name);
   }

   public static void giveRandomGear(ServerPlayer bot) {
      RandomGearGenerator.apply(bot);
   }

   public static boolean hunt(String botName, String targetName) {
      return BotManager.forceTarget(botName, targetName);
   }

   public static void lookAt(String botName, String targetName) {
      BotManager.setLookAtTarget(botName, targetName);
   }

   public static void clearLookAt(String botName) {
      BotManager.clearLookAtTarget(botName);
   }

   public static List<String> listBots() {
      return List.copyOf(BotManager.getBotNames());
   }

   public static boolean isBot(MinecraftServer server, String name) {
      return BotManager.resolveTrackedBotPlayer(server, name) != null;
   }

   public static boolean isPracticeBot(String name) {
      return BotManager.isPracticeBot(name);
   }

   public static ServerPlayer resolveBot(MinecraftServer server, String name) {
      return BotManager.resolveTrackedBotPlayer(server, name);
   }
}
