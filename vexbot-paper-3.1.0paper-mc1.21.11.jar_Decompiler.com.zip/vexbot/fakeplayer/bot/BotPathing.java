package vexbot.fakeplayer.bot;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import vexbot.fakeplayer.bot.pathing.MovementHelper;
import vexbot.fakeplayer.bot.pathing.PathFinder;
import vexbot.fakeplayer.bot.pathing.PathSettings;
import vexbot.i18n.VexText;
import vexbot.platform.Internals;

public class BotPathing {
   private final BotPlayer bot;
   private final BotPlayerActionPack actionPack;
   private final CommandSourceStack source;
   private final PathSettings settings;
   private List<BlockPos> path;
   private Vec3 target;
   private int currentIndex;
   private int stuckTime;
   private Vec3 lastPos;
   private boolean done;
   private boolean retrying;
   private BlockPos retryTarget;
   private int retryNextIndex;
   private double originalNodeDistance;
   private boolean pendingRecalc;
   private final Entity targetEntity;
   private int recalcCd;
   private Vec3 lastRecalcTarget;
   private Set<BlockPos> debugger;

   public BotPathing(BotPlayer bot, List<BlockPos> path, Vec3 target, CommandSourceStack source, PathSettings settings) {
      this.bot = bot;
      this.actionPack = Internals.get().actionPack(bot);
      this.path = path;
      this.target = target;
      this.source = source;
      this.settings = settings;
      this.targetEntity = null;
      this.currentIndex = 0;
      this.stuckTime = 0;
      this.lastPos = bot.position();
      this.lastRecalcTarget = target;
      this.initDebugNodes(path);
   }

   public BotPathing(BotPlayer bot, Entity targetEntity, CommandSourceStack source, PathSettings settings) {
      this.bot = bot;
      this.actionPack = Internals.get().actionPack(bot);
      this.targetEntity = targetEntity;
      this.target = computeEntityTarget(targetEntity, settings, bot);
      this.source = source;
      this.settings = settings;
      this.currentIndex = 0;
      this.stuckTime = 0;
      this.lastPos = bot.position();
      this.lastRecalcTarget = this.target;
      this.path = PathFinder.findPath(bot.level(), bot.blockPosition(), this.target, settings, bot);
      if (this.path == null) {
         this.path = List.of();
      }

      this.initDebugNodes(this.path);
   }

   public void recalcPath() {
      if (!this.done) {
         Vec3 currentTarget = this.targetEntity != null ? this.targetEntity.position() : this.target;
         List<BlockPos> newPath = PathFinder.findPath(this.bot.level(), this.bot.blockPosition(), currentTarget, this.settings, this.bot);
         if (newPath != null && !newPath.isEmpty()) {
            this.path = newPath;
            this.currentIndex = 0;
            this.stuckTime = 0;
            this.initDebugNodes(newPath);
         }

      }
   }

   public void requestRecalc() {
      if (!this.done) {
         this.pendingRecalc = true;
      }

   }

   public void tick() {
      if (!this.done) {
         if (this.pendingRecalc && this.bot.onGround()) {
            this.pendingRecalc = false;
            this.recalcPath();
         }

         Vec3 botPos = this.bot.position();
         if (this.updateTarget(botPos)) {
            this.advanceWaypoints(botPos);
            this.moveTowardGoal(botPos);
            this.tickDebugParticles();
            this.tickStuck(botPos);
         }
      }
   }

   private boolean updateTarget(Vec3 botPos) {
      if (this.targetEntity != null) {
         if (this.targetEntity.isRemoved()) {
            this.stop();
            this.source.sendFailure(VexText.literal(this.bot.getGameProfile().name() + " lost target entity"));
            return false;
         }

         this.target = computeEntityTarget(this.targetEntity, this.settings, this.bot);
      }

      if (this.isWithinTarget(botPos)) {
         if (this.targetEntity != null && !this.settings.isStopFollowing()) {
            this.actionPack.setForward(0.0F);
            this.actionPack.setStrafing(0.0F);
            this.actionPack.setSprinting(false);
            Vec3 eyePos = this.targetEntity.getEyePosition();
            this.actionPack.lookAt(eyePos);
            this.setVerticalLook(eyePos);
            return false;
         } else {
            this.stop();
            String var10000 = this.bot.getGameProfile().name();
            String msg = var10000 + " reached target" + (this.targetEntity != null ? " entity" : " position");
            this.source.sendSuccess(() -> VexText.literal(msg), false);
            return false;
         }
      } else {
         if (this.targetEntity != null) {
            this.tickEntityRecalc();
         } else if (this.currentIndex >= this.path.size()) {
            this.tryRecalcPath();
         }

         return true;
      }
   }

   private void tickEntityRecalc() {
      --this.recalcCd;
      if (this.recalcCd <= 0 || this.currentIndex >= this.path.size()) {
         this.tryRecalcPath();
         this.recalcCd = 20;
      }

   }

   private void tryRecalcPath() {
      if (this.lastRecalcTarget == null || !(this.lastRecalcTarget.distanceTo(this.target) <= (double)2.0F)) {
         List<BlockPos> newPath = PathFinder.findPath(this.bot.level(), this.bot.blockPosition(), this.target, this.settings, this.bot);
         if (newPath != null && !newPath.isEmpty()) {
            this.path = newPath;
            this.currentIndex = 0;
            this.lastRecalcTarget = this.target;
            this.initDebugNodes(newPath);
         }

      }
   }

   private void advanceWaypoints(Vec3 botPos) {
      while(true) {
         if (this.currentIndex < this.path.size()) {
            BlockPos wp = (BlockPos)this.path.get(this.currentIndex);
            double hDist = PathFinder.closestHDistToBlock(wp, botPos);
            double vDist = Math.abs(botPos.y - (double)wp.getY());
            if (this.settings.isWithinNode(hDist, vDist)) {
               this.spawnDebugReached(wp);
               ++this.currentIndex;
               continue;
            }
         }

         if (this.currentIndex < this.path.size()) {
            for(int i = Math.min(this.path.size() - 1, this.currentIndex + 3); i > this.currentIndex; --i) {
               BlockPos futureWp = (BlockPos)this.path.get(i);
               double hDist = PathFinder.closestHDistToBlock(futureWp, botPos);
               double vDist = Math.abs(botPos.y - (double)futureWp.getY());
               if (this.settings.isWithinNode(hDist, vDist)) {
                  for(int j = this.currentIndex; j <= i; ++j) {
                     this.spawnDebugReached((BlockPos)this.path.get(j));
                  }

                  this.currentIndex = i + 1;
                  break;
               }
            }
         }

         if (this.currentIndex < this.path.size()) {
            for(int i = this.currentIndex + 1; i < this.path.size() && i - this.currentIndex <= 2; ++i) {
               BlockPos candidate = (BlockPos)this.path.get(i);
               if ((double)candidate.getY() < botPos.y - (double)0.5F) {
                  double hDist = PathFinder.closestHDistToBlock(candidate, botPos);
                  if (hDist < (double)1.5F) {
                     for(int j = this.currentIndex; j < i; ++j) {
                        this.spawnDebugReached((BlockPos)this.path.get(j));
                     }

                     this.currentIndex = i;
                  }
                  break;
               }
            }
         }

         return;
      }
   }

   private void moveTowardGoal(Vec3 botPos) {
      if (this.currentIndex >= this.path.size()) {
         this.finalApproach(botPos);
      } else {
         BlockPos waypoint = (BlockPos)this.path.get(this.currentIndex);
         if (isFullySubmerged(this.bot)) {
            this.swimToWaypoint(botPos, waypoint);
         } else if (isWading(this.bot)) {
            this.wadeToWaypoint(waypoint);
         } else {
            this.walkToWaypoint(botPos, waypoint);
         }

      }
   }

   private void swimToWaypoint(Vec3 botPos, BlockPos waypoint) {
      Vec3 waypointMid = Vec3.atCenterOf(waypoint);
      this.actionPack.lookAt(waypointMid);
      this.setVerticalLook(waypointMid);
      this.actionPack.setForward(1.0F);
      this.actionPack.setStrafing(0.0F);
      this.actionPack.setSprinting(true);
      double dy = waypointMid.y - botPos.y;
      double hDist = Math.sqrt(horizontalDistanceSq(botPos, waypointMid));
      boolean moreVertical = Math.abs(dy) > hDist;
      if (dy > (double)0.5F) {
         this.bot.setJumping(true);
         if (moreVertical) {
            this.actionPack.setSneaking(false);
         }
      } else if (dy < (double)-0.5F) {
         this.bot.setJumping(false);
         if (moreVertical) {
            this.actionPack.setSneaking(true);
         }
      } else {
         this.bot.setJumping(false);
         this.actionPack.setSneaking(false);
      }

   }

   private void wadeToWaypoint(BlockPos waypoint) {
      Vec3 waypointCenter = Vec3.atBottomCenterOf(waypoint);
      this.actionPack.setSneaking(false);
      this.bot.setJumping(false);
      this.actionPack.setForward(1.0F);
      this.actionPack.setStrafing(0.0F);
      this.actionPack.setSprinting(false);
      this.actionPack.lookAt(waypointCenter);
      this.setVerticalLook(waypointCenter);
   }

   private void walkToWaypoint(Vec3 botPos, BlockPos waypoint) {
      Vec3 waypointCenter = Vec3.atBottomCenterOf(waypoint);
      this.actionPack.setSneaking(false);
      this.bot.setJumping(false);
      Vec3 lookHorizontal;
      if (this.currentIndex + 1 < this.path.size()) {
         lookHorizontal = Vec3.atBottomCenterOf((Vec3i)this.path.get(this.currentIndex + 1));
      } else {
         lookHorizontal = this.targetEntity != null ? this.targetEntity.position() : this.target;
      }

      Vec3 verticalTarget = this.targetEntity != null ? this.targetEntity.getEyePosition() : waypointCenter;
      this.actionPack.lookAt(new Vec3(lookHorizontal.x, verticalTarget.y, lookHorizontal.z));
      this.setVerticalLook(verticalTarget);
      this.applyMoveType(false, botPos, waypoint);
      double dx = waypointCenter.x - botPos.x;
      double dz = waypointCenter.z - botPos.z;
      double toWaypointAngle = Math.atan2(-dx, dz);
      double facingAngle = Math.toRadians((double)this.bot.getYRot());
      double relativeAngle = toWaypointAngle - facingAngle;
      relativeAngle = Math.atan2(Math.sin(relativeAngle), Math.cos(relativeAngle));
      float forward = (float)Math.cos(relativeAngle);
      float strafe = (float)(-Math.sin(relativeAngle));
      this.actionPack.setForward(forward > 0.0F ? forward : 0.0F);
      this.actionPack.setStrafing(strafe);
      if (this.bot.onGround()) {
         if ((double)waypoint.getY() > botPos.y + (double)0.5F) {
            this.bot.jumpFromGround();
         } else if (this.isParkourJump(botPos, waypoint)) {
            this.actionPack.setSprinting(true);
            this.bot.jumpFromGround();
         } else if ((double)waypoint.getY() < botPos.y - (double)0.5F && this.settings.getMoveType() == PathSettings.MoveType.SPRINT_JUMP) {
            this.bot.jumpFromGround();
         }
      }

   }

   private void finalApproach(Vec3 botPos) {
      Vec3 finalLook = this.targetEntity != null ? this.targetEntity.getEyePosition() : this.target;
      this.actionPack.lookAt(new Vec3(this.target.x, finalLook.y, this.target.z));
      this.setVerticalLook(finalLook);
      this.applyMoveType(true, botPos, (BlockPos)null);
      this.actionPack.setStrafing(0.0F);
   }

   private void tickStuck(Vec3 botPos) {
      if (this.retrying && this.currentIndex > this.retryNextIndex) {
         this.retrying = false;
         this.retryTarget = null;
         this.stuckTime = 0;
         this.settings.setNodeHorizontalDistance(this.originalNodeDistance);
      }

      if (horizontalDistanceSq(botPos, this.lastPos) < 0.001) {
         ++this.stuckTime;
         if (this.stuckTime == 50) {
            this.actionPack.start(BotPlayerActionPack.ActionType.JUMP, BotPlayerActionPack.Action.once());
         }

         if (this.stuckTime > 100) {
            if (this.retrying) {
               this.retryTarget = null;
               this.settings.setNodeHorizontalDistance(this.originalNodeDistance);
               this.stop();
               this.source.sendFailure(VexText.literal(this.bot.getGameProfile().name() + " got stuck while pathing"));
               return;
            }

            int prevIndex = Math.max(0, this.currentIndex - 1);
            this.retryTarget = (BlockPos)this.path.get(prevIndex);
            this.retryNextIndex = this.currentIndex;
            this.currentIndex = prevIndex;
            this.retrying = true;
            this.stuckTime = 0;
            this.originalNodeDistance = this.settings.getNodeHorizontalDistance();
            this.settings.setNodeHorizontalDistance(this.originalNodeDistance / (double)2.0F);
         }
      } else {
         this.stuckTime = 0;
      }

      this.lastPos = botPos;
   }

   private boolean isParkourJump(Vec3 botPos, BlockPos waypoint) {
      int bx = (int)Math.floor(botPos.x);
      int bz = (int)Math.floor(botPos.z);
      int by = (int)Math.floor(botPos.y);
      int wx = waypoint.getX();
      int wz = waypoint.getZ();
      int wy = waypoint.getY();
      if (wy < by) {
         return false;
      } else {
         int dx = wx - bx;
         int dz = wz - bz;
         int dist = Math.abs(dx) + Math.abs(dz);
         if (dist >= 2 && dist <= 4) {
            if (dx != 0 && dz != 0) {
               return false;
            } else {
               int stepDx = Integer.compare(dx, 0);
               int stepDz = Integer.compare(dz, 0);
               return !MovementHelper.canWalkOn(this.bot.level(), bx + stepDx, by - 1, bz + stepDz, this.settings);
            }
         } else {
            return false;
         }
      }
   }

   private static boolean isFullySubmerged(BotPlayer bot) {
      int feetX = (int)Math.floor(bot.getX());
      int feetY = (int)Math.floor(bot.getY());
      int feetZ = (int)Math.floor(bot.getZ());
      int headY = (int)Math.floor(bot.getY() + (double)bot.getEyeHeight());
      return isSwimmableBlock(bot, feetX, feetY, feetZ) && isSwimmableBlock(bot, feetX, headY, feetZ);
   }

   private static boolean isWading(BotPlayer bot) {
      int feetX = (int)Math.floor(bot.getX());
      int feetY = (int)Math.floor(bot.getY());
      int feetZ = (int)Math.floor(bot.getZ());
      return isSwimmableBlock(bot, feetX, feetY, feetZ);
   }

   private static boolean isSwimmableBlock(BotPlayer bot, int x, int y, int z) {
      BlockPos pos = new BlockPos(x, y, z);
      BlockState state = bot.level().getBlockState(pos);
      if (MovementHelper.isWater(bot.level(), x, y, z)) {
         return true;
      } else if (!state.is(Blocks.KELP) && !state.is(Blocks.KELP_PLANT) && !state.is(Blocks.SEAGRASS) && !state.is(Blocks.TALL_SEAGRASS)) {
         return !state.getFluidState().isEmpty() && state.getCollisionShape(bot.level(), pos).isEmpty();
      } else {
         return true;
      }
   }

   private void setVerticalLook(Vec3 lookTarget) {
      Vec3 botEye = this.bot.getEyePosition();
      double dx = lookTarget.x - botEye.x;
      double dy = lookTarget.y - botEye.y;
      double dz = lookTarget.z - botEye.z;
      double hDist = Math.sqrt(dx * dx + dz * dz);
      float pitch = (float)Math.toDegrees(-Math.atan2(dy, hDist));
      this.bot.setXRot(pitch);
   }

   private boolean shouldAllowJump(double hDistSqToTarget, BlockPos currentWaypoint) {
      if (hDistSqToTarget <= (double)100.0F) {
         return false;
      } else if (currentWaypoint != null && this.currentIndex + 1 < this.path.size()) {
         BlockPos nextWaypoint = (BlockPos)this.path.get(this.currentIndex + 1);
         return nextWaypoint.getY() == currentWaypoint.getY();
      } else {
         return true;
      }
   }

   private void applyMoveType(boolean finalApproach, Vec3 botPos, BlockPos currentWaypoint) {
      if (finalApproach) {
         this.actionPack.setForward(1.0F);
         this.actionPack.setSprinting(false);
      } else {
         double hDistSq = horizontalDistanceSq(botPos, this.target);
         boolean nearTarget = hDistSq <= (double)25.0F;
         boolean closeRange = hDistSq <= (double)100.0F;
         switch (this.settings.getMoveType()) {
            case WALK:
               this.actionPack.setForward(1.0F);
               this.actionPack.setSprinting(false);
               this.actionPack.autoJump = false;
               break;
            case SPRINT:
               this.actionPack.setForward(1.0F);
               this.actionPack.setSprinting(!nearTarget);
               this.actionPack.autoJump = false;
               break;
            case SPRINT_JUMP:
               this.actionPack.setForward(1.0F);
               this.actionPack.setSprinting(!nearTarget);
               if (closeRange) {
                  this.actionPack.autoJump = true;
               } else {
                  this.actionPack.autoJump = false;
                  if (this.bot.onGround() && this.shouldAllowJump(hDistSq, currentWaypoint)) {
                     this.bot.jumpFromGround();
                  }
               }
         }

      }
   }

   private boolean isWithinTarget(Vec3 botPos) {
      double hDist = Math.sqrt(horizontalDistanceSq(botPos, this.target));
      double vDist = Math.abs(botPos.y - this.target.y);
      return this.settings.isWithinTarget(hDist, vDist);
   }

   private static Vec3 computeEntityTarget(Entity entity, PathSettings settings, BotPlayer bot) {
      if (settings.getMaxVerticalDistance() < (double)0.0F) {
         BlockPos start = entity.blockPosition();
         ServerLevel level = bot.level();

         for(int dy = 0; dy <= 64; ++dy) {
            BlockPos check = start.below(dy);
            BlockState state = level.getBlockState(check);
            if (!state.getCollisionShape(level, check).isEmpty()) {
               return Vec3.atBottomCenterOf(check.above());
            }
         }
      }

      return entity.position();
   }

   private void initDebugNodes(List<BlockPos> pathNodes) {
      if (!this.settings.isDebug()) {
         this.debugger = null;
      } else {
         if (this.debugger == null) {
            this.debugger = new LinkedHashSet();
         } else {
            this.debugger.clear();
         }

         if (pathNodes != null) {
            this.debugger.addAll(pathNodes);
         }

      }
   }

   private void tickDebugParticles() {
      if (this.debugger != null && !this.debugger.isEmpty()) {
         ServerLevel serverLevel = this.bot.level();

         for(BlockPos pos : this.debugger) {
            serverLevel.sendParticles(ParticleTypes.WAX_OFF, (double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.25F, (double)pos.getZ() + (double)0.5F, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
         }

         if (this.retryTarget != null) {
            serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, (double)this.retryTarget.getX() + (double)0.5F, (double)this.retryTarget.getY() + (double)0.25F, (double)this.retryTarget.getZ() + (double)0.5F, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
         }

      }
   }

   private void spawnDebugReached(BlockPos pos) {
      if (this.debugger != null && this.debugger.remove(pos)) {
         ServerLevel serverLevel = this.bot.level();
         serverLevel.sendParticles(ParticleTypes.WAX_ON, (double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.5F, (double)pos.getZ() + (double)0.5F, 5, 0.2, (double)0.5F, 0.2, (double)0.0F);
      }
   }

   public void stop() {
      if (!this.done) {
         this.done = true;
         if (this.debugger != null) {
            this.debugger.clear();
         }

         this.actionPack.setForward(0.0F);
         this.actionPack.setStrafing(0.0F);
         this.actionPack.setSprinting(false);
         this.actionPack.setSneaking(false);
         this.actionPack.autoJump = false;
         this.bot.setJumping(false);
      }
   }

   public boolean isDone() {
      return this.done;
   }

   public Entity getTargetEntity() {
      return this.targetEntity;
   }

   public Vec3 getTarget() {
      return this.target;
   }

   public boolean isEntityMode() {
      return this.targetEntity != null;
   }

   private static double horizontalDistanceSq(Vec3 botPos, Vec3 target) {
      double dx = botPos.x - target.x;
      double dz = botPos.z - target.z;
      return dx * dx + dz * dz;
   }
}
