package vexbot.fakeplayer.bot;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.StreamSupport;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.protocol.game.ClientboundSetHeldSlotPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResult.SwingSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.PlayerRideableJumping;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import vexbot.compat.McCompat;
import vexbot.fakeplayer.util.RayTrace;
import vexbot.platform.Internals;

public class BotPlayerActionPack {
   public final ServerPlayer player;
   private final Map<ActionType, Action> actions = new EnumMap(ActionType.class);
   private static final ActionType[] ACTION_TYPES = BotPlayerActionPack.ActionType.values();
   private BlockPos currentBlock;
   private int blockHitDelay;
   private boolean isHittingBlock;
   private float curBlockDamageMP;
   public boolean autoJump = false;
   private int autoJumpTime;
   private boolean sneaking;
   private boolean sprinting;
   private float forward;
   private float strafing;
   private float appliedForward;
   private float appliedStrafing;
   private static final float MOVE_ACCEL = 0.22F;
   private static final float MOVE_DECEL = 0.8F;
   private long lastJumpOnceTick = -100L;
   private boolean jumping;
   private int vehicleJumpOverrideTicks = 0;
   private boolean clearJumpNextTick = false;
   private int jumpChargeAmount = 0;
   private int itemUseCooldown;
   private final List<DelayedAction> pendingActions = new ArrayList();
   private LookInterpolation lookInterpolation;
   private float speedScale = 1.0F;

   public BotPlayerActionPack(ServerPlayer playerIn) {
      this.player = playerIn;
      this.stopAll();
   }

   public void copyFrom(BotPlayerActionPack other) {
      this.actions.putAll(other.actions);
      this.currentBlock = other.currentBlock;
      this.blockHitDelay = other.blockHitDelay;
      this.isHittingBlock = other.isHittingBlock;
      this.curBlockDamageMP = other.curBlockDamageMP;
      this.sneaking = other.sneaking;
      this.sprinting = other.sprinting;
      this.forward = other.forward;
      this.strafing = other.strafing;
      this.appliedForward = other.appliedForward;
      this.appliedStrafing = other.appliedStrafing;
      this.itemUseCooldown = other.itemUseCooldown;
   }

   public BotPlayerActionPack start(ActionType type, Action action) {
      if (action.isContinuous) {
         Action curent = (Action)this.actions.get(type);
         if (curent != null) {
            return this;
         }
      }

      Action previous = (Action)this.actions.remove(type);
      if (previous != null) {
         type.stop(this.player, previous);
      }

      this.actions.put(type, action);
      return this;
   }

   public BotPlayerActionPack stop(ActionType type) {
      Action action = (Action)this.actions.remove(type);
      if (action != null) {
         action.ticksRemaining = -1;
         type.stop(this.player, action);
      }

      if (type == BotPlayerActionPack.ActionType.USE) {
         this.itemUseCooldown = 0;
         this.player.releaseUsingItem();
      }

      return this;
   }

   public BotPlayerActionPack setSneaking(boolean doSneak) {
      this.sneaking = doSneak;
      this.player.setShiftKeyDown(doSneak);
      return this;
   }

   public BotPlayerActionPack setSprinting(boolean doSprint) {
      this.sprinting = doSprint;
      this.player.setSprinting(doSprint);
      return this;
   }

   public BotPlayerActionPack setForward(float value) {
      this.forward = value;
      return this;
   }

   public BotPlayerActionPack setSpeedScale(float value) {
      this.speedScale = Math.max(0.1F, Math.min(1.0F, value));
      return this;
   }

   public BotPlayerActionPack setStrafing(float value) {
      this.strafing = value;
      return this;
   }

   public float getForward() {
      return this.forward;
   }

   public float getStrafing() {
      return this.strafing;
   }

   public BotPlayerActionPack look(Direction direction) {
      BotPlayerActionPack var10000;
      switch (direction) {
         case NORTH -> var10000 = this.look(180.0F, 0.0F);
         case SOUTH -> var10000 = this.look(0.0F, 0.0F);
         case EAST -> var10000 = this.look(-90.0F, 0.0F);
         case WEST -> var10000 = this.look(90.0F, 0.0F);
         case UP -> var10000 = this.look(this.player.getYRot(), -90.0F);
         case DOWN -> var10000 = this.look(this.player.getYRot(), 90.0F);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public BotPlayerActionPack look(Vec2 rotation) {
      return this.look(rotation.y, rotation.x);
   }

   public BotPlayerActionPack look(float yaw, float pitch) {
      this.player.setYRot(yaw % 360.0F);
      this.player.setXRot(Mth.clamp(pitch, -90.0F, 90.0F));
      return this;
   }

   public BotPlayerActionPack lookAt(Vec3 position) {
      this.player.lookAt(Anchor.EYES, position);
      return this;
   }

   public BotPlayerActionPack turn(float yaw, float pitch) {
      return this.look(this.player.getYRot() + yaw, this.player.getXRot() + pitch);
   }

   public BotPlayerActionPack lookInterpolated(float targetYaw, float targetPitch, int ticks) {
      if (ticks <= 0) {
         return this.look(targetYaw, targetPitch);
      } else {
         float clampedPitch = Mth.clamp(targetPitch, -90.0F, 90.0F);
         this.lookInterpolation = new LookInterpolation(targetYaw, clampedPitch, Mth.wrapDegrees(targetYaw - this.player.getYRot()) / (float)ticks, (clampedPitch - this.player.getXRot()) / (float)ticks, ticks);
         return this;
      }
   }

   public BotPlayerActionPack look(Direction direction, int ticks) {
      float targetYaw;
      float targetPitch;
      switch (direction) {
         case NORTH:
            targetYaw = 180.0F;
            targetPitch = 0.0F;
            break;
         case SOUTH:
            targetYaw = 0.0F;
            targetPitch = 0.0F;
            break;
         case EAST:
            targetYaw = -90.0F;
            targetPitch = 0.0F;
            break;
         case WEST:
            targetYaw = 90.0F;
            targetPitch = 0.0F;
            break;
         case UP:
            targetYaw = this.player.getYRot();
            targetPitch = -90.0F;
            break;
         case DOWN:
            targetYaw = this.player.getYRot();
            targetPitch = 90.0F;
            break;
         default:
            return this;
      }

      return this.lookInterpolated(targetYaw, targetPitch, ticks);
   }

   public BotPlayerActionPack look(Vec2 rotation, int ticks) {
      return this.lookInterpolated(rotation.y, rotation.x, ticks);
   }

   public BotPlayerActionPack turn(float yaw, float pitch, int ticks) {
      return this.lookInterpolated(this.player.getYRot() + yaw, this.player.getXRot() + pitch, ticks);
   }

   public BotPlayerActionPack lookAt(Vec3 position, int ticks) {
      if (ticks <= 0) {
         return this.lookAt(position);
      } else {
         Vec3 eye = this.player.getEyePosition();
         double dx = position.x - eye.x;
         double dy = position.y - eye.y;
         double dz = position.z - eye.z;
         double dist = Math.sqrt(dx * dx + dz * dz);
         float yaw = Mth.wrapDegrees((float)(Mth.atan2(dz, dx) * (180D / Math.PI)) - 90.0F);
         float pitch = Mth.wrapDegrees((float)(-(Mth.atan2(dy, dist) * (180D / Math.PI))));
         return this.lookInterpolated(yaw, pitch, ticks);
      }
   }

   public void stopInterpolation() {
      this.lookInterpolation = null;
   }

   public BotPlayerActionPack stopMovement() {
      this.setSneaking(false);
      this.setSprinting(false);
      this.forward = 0.0F;
      this.strafing = 0.0F;
      return this;
   }

   public BotPlayerActionPack startOrExtender(ActionType type, int ticks) {
      Action current = (Action)this.actions.get(type);
      if (current != null && current.isContinuous) {
         current.ticksRemaining = ticks;
         return this;
      } else {
         Action previous = (Action)this.actions.remove(type);
         if (previous != null) {
            type.stop(this.player, previous);
         }

         this.actions.put(type, BotPlayerActionPack.Action.continuous(ticks));
         return this;
      }
   }

   public BotPlayerActionPack stopAll() {
      for(ActionType type : this.actions.keySet()) {
         type.stop(this.player, (Action)this.actions.get(type));
      }

      this.actions.clear();
      this.stopInterpolation();
      ServerPlayer var4 = this.player;
      if (var4 instanceof BotPlayer bot) {
         bot.clearPathFollower();
      }

      this.appliedForward = 0.0F;
      this.appliedStrafing = 0.0F;
      return this.stopMovement();
   }

   public void onUpdate() {
      if (this.autoJumpTime > 0) {
         --this.autoJumpTime;
         this.start(BotPlayerActionPack.ActionType.JUMP, BotPlayerActionPack.Action.once());
      }

      if (this.lookInterpolation != null) {
         --this.lookInterpolation.ticksRemaining;
         if (this.lookInterpolation.ticksRemaining == 0) {
            this.look(this.lookInterpolation.targetYaw, this.lookInterpolation.targetPitch);
            this.lookInterpolation = null;
         } else {
            this.player.setYRot(Mth.wrapDegrees(this.player.getYRot() + this.lookInterpolation.deltaYaw));
            this.player.setXRot(Mth.clamp(this.player.getXRot() + this.lookInterpolation.deltaPitch, -90.0F, 90.0F));
         }
      }

      if (!this.pendingActions.isEmpty()) {
         long currentTick = (long)this.player.level().getServer().getTickCount();
         Iterator<DelayedAction> it = this.pendingActions.iterator();

         while(it.hasNext()) {
            DelayedAction da = (DelayedAction)it.next();
            if (currentTick >= da.tick()) {
               da.action().run();
               it.remove();
            }
         }
      }

      for(ActionType type : ACTION_TYPES) {
         Action a = (Action)this.actions.get(type);
         if (a != null && a.done) {
            this.actions.remove(type);
         }
      }

      Boolean useAttempt = null;
      Boolean attackAttempt = null;

      for(ActionType type : ACTION_TYPES) {
         Action action = (Action)this.actions.get(type);
         if (action != null) {
            if (!Boolean.TRUE.equals(useAttempt) || type != BotPlayerActionPack.ActionType.ATTACK) {
               Boolean actionStatus = action.tick(this, type);
               if (actionStatus != null) {
                  if (type == BotPlayerActionPack.ActionType.USE) {
                     useAttempt = actionStatus;
                  } else if (type == BotPlayerActionPack.ActionType.ATTACK) {
                     attackAttempt = actionStatus;
                  }
               }
            }

            if (type == BotPlayerActionPack.ActionType.ATTACK && Boolean.TRUE.equals(attackAttempt) && Boolean.FALSE.equals(useAttempt)) {
               Action using = (Action)this.actions.get(BotPlayerActionPack.ActionType.USE);
               if (using != null) {
                  using.retry(this, BotPlayerActionPack.ActionType.USE);
               }
            }
         }
      }

      if (this.vehicleJumpOverrideTicks > 0) {
         this.player.setJumping(true);
         --this.vehicleJumpOverrideTicks;
         if (this.vehicleJumpOverrideTicks == 0) {
            this.clearJumpNextTick = true;
         }
      } else if (this.clearJumpNextTick) {
         this.player.setJumping(false);
         this.clearJumpNextTick = false;
      }

      boolean slowUse = this.player.isUsingItem() && !this.player.getUseItem().has(DataComponents.KINETIC_WEAPON);
      if (slowUse) {
         this.sprinting = false;
         this.player.setSprinting(false);
      } else if ((this.forward != 0.0F || this.strafing != 0.0F) && !this.player.getFoodData().hasEnoughFood() && !this.player.getAbilities().mayfly && !this.player.isPassenger()) {
         this.player.setSprinting(false);
      } else if (this.sprinting) {
         this.player.setSprinting(true);
      }

      float vel = this.sneaking ? 0.3F : 1.0F;
      vel *= slowUse ? 0.2F : 1.0F;
      vel *= this.speedScale;
      this.appliedForward = approachInput(this.appliedForward, this.forward);
      this.appliedStrafing = approachInput(this.appliedStrafing, this.strafing);
      if (this.appliedForward != 0.0F || this.player instanceof BotPlayer) {
         this.player.zza = this.appliedForward * vel;
      }

      if (this.appliedStrafing != 0.0F || this.player instanceof BotPlayer) {
         this.player.xxa = this.appliedStrafing * vel;
      }

      if (this.player.getAbilities().flying && this.player instanceof BotPlayer) {
         double verticalSpeed = 0.15000000000000002;
         Vec3 dm = this.player.getDeltaMovement();
         if (this.jumping && !this.sneaking) {
            this.player.setDeltaMovement(dm.add((double)0.0F, verticalSpeed, (double)0.0F));
         } else if (this.sneaking && !this.jumping) {
            this.player.setDeltaMovement(dm.add((double)0.0F, -verticalSpeed, (double)0.0F));
         }

         if (this.jumping && this.actions.get(BotPlayerActionPack.ActionType.JUMP) == null) {
            this.jumping = false;
         }
      }

   }

   private static float approachInput(float cur, float target) {
      if (cur == target) {
         return target;
      } else {
         float rate = Math.abs(target) > Math.abs(cur) ? 0.22F : 0.8F;
         return cur < target ? Math.min(cur + rate, target) : Math.max(cur - rate, target);
      }
   }

   public void updateAutoJump(float f, float g) {
      if (this.canAutoJump()) {
         Vec3 startPos = this.player.position();
         Vec3 endPos = startPos.add((double)f, (double)0.0F, (double)g);
         Vec3 movement = new Vec3((double)f, (double)0.0F, (double)g);
         float speed = this.player.getSpeed();
         float movementLenSqr = (float)movement.lengthSqr();
         if (movementLenSqr <= 0.001F) {
            Vec2 moveVector = new Vec2(this.strafing, this.forward);
            float xInput = speed * moveVector.x;
            float zInput = speed * moveVector.y;
            float sin = Mth.sin((double)(this.player.getYRot() * ((float)Math.PI / 180F)));
            float cos = Mth.cos((double)(this.player.getYRot() * ((float)Math.PI / 180F)));
            movement = new Vec3((double)(xInput * cos - zInput * sin), movement.y, (double)(zInput * cos + xInput * sin));
            movementLenSqr = (float)movement.lengthSqr();
            if (movementLenSqr <= 0.001F) {
               return;
            }
         }

         float invLen = Mth.invSqrt(movementLenSqr);
         Vec3 movementDir = movement.scale((double)invLen);
         Vec3 playerForward = this.player.getForward();
         float forwardDot = (float)(playerForward.x * movementDir.x + playerForward.z * movementDir.z);
         if (!(forwardDot < -0.15F)) {
            CollisionContext collisionContext = CollisionContext.of(this.player);
            BlockPos blockPos = BlockPos.containing(this.player.getX(), this.player.getBoundingBox().maxY, this.player.getZ());
            if (this.player.level().getBlockState(blockPos).getCollisionShape(this.player.level(), blockPos, collisionContext).isEmpty()) {
               blockPos = blockPos.above();
               if (this.player.level().getBlockState(blockPos).getCollisionShape(this.player.level(), blockPos, collisionContext).isEmpty()) {
                  float maxStepHeight = 1.2F;
                  if (this.player.hasEffect(MobEffects.JUMP_BOOST)) {
                     maxStepHeight += (float)(((MobEffectInstance)Objects.requireNonNull(this.player.getEffect(MobEffects.JUMP_BOOST))).getAmplifier() + 1) * 0.75F;
                  }

                  float probeDistance = Math.max(speed * 7.0F, 1.0F / invLen);
                  Vec3 probeEnd = endPos.add(movementDir.scale((double)probeDistance));
                  float bbWidth = this.player.getBbWidth();
                  float bbHeight = this.player.getBbHeight();
                  AABB searchBox = (new AABB(startPos, probeEnd.add((double)0.0F, (double)bbHeight, (double)0.0F))).inflate((double)bbWidth, (double)0.0F, (double)bbWidth);
                  Vec3 raisedStart = startPos.add((double)0.0F, 0.51, (double)0.0F);
                  Vec3 raisedEnd = probeEnd.add((double)0.0F, 0.51, (double)0.0F);
                  Vec3 side = movementDir.cross(new Vec3((double)0.0F, (double)1.0F, (double)0.0F));
                  Vec3 halfWidth = side.scale((double)(bbWidth * 0.5F));
                  Vec3 leftStart = raisedStart.subtract(halfWidth);
                  Vec3 leftEnd = raisedEnd.subtract(halfWidth);
                  Vec3 rightStart = raisedStart.add(halfWidth);
                  Vec3 rightEnd = raisedEnd.add(halfWidth);
                  Iterable<VoxelShape> collisions = this.player.level().getCollisions(this.player, searchBox);
                  Iterator<AABB> iterator = StreamSupport.stream(collisions.spliterator(), false).flatMap((shape) -> shape.toAabbs().stream()).iterator();
                  float obstacleTopY = Float.MIN_VALUE;

                  while(iterator.hasNext()) {
                     AABB hitBox = (AABB)iterator.next();
                     if (hitBox.intersects(leftStart, leftEnd) || hitBox.intersects(rightStart, rightEnd)) {
                        obstacleTopY = (float)hitBox.maxY;
                        Vec3 center = hitBox.getCenter();
                        BlockPos obstaclePos = BlockPos.containing(center);

                        for(int u = 1; (float)u < maxStepHeight; ++u) {
                           BlockPos abovePos = obstaclePos.above(u);
                           VoxelShape aboveShape = this.player.level().getBlockState(abovePos).getCollisionShape(this.player.level(), abovePos, collisionContext);
                           if (!aboveShape.isEmpty()) {
                              obstacleTopY = (float)aboveShape.max(Axis.Y) + (float)abovePos.getY();
                              if ((double)obstacleTopY - this.player.getY() > (double)maxStepHeight) {
                                 return;
                              }
                           }

                           if (u > 1) {
                              blockPos = blockPos.above();
                              if (!this.player.level().getBlockState(blockPos).getCollisionShape(this.player.level(), blockPos, collisionContext).isEmpty()) {
                                 return;
                              }
                           }
                        }
                        break;
                     }
                  }

                  if (obstacleTopY != Float.MIN_VALUE) {
                     float stepHeight = (float)((double)obstacleTopY - this.player.getY());
                     if (stepHeight > 0.5F && stepHeight <= maxStepHeight) {
                        this.autoJumpTime = 1;
                     }
                  }

               }
            }
         }
      }
   }

   public void attemptAutoJump() {
      boolean wasAutoJump = this.autoJump;
      this.autoJump = true;
      this.updateAutoJump(0.0F, 0.0F);
      this.autoJump = wasAutoJump;
   }

   private boolean canAutoJump() {
      return this.autoJump && this.autoJumpTime <= 0 && this.player.onGround() && !this.player.isPassenger() && (this.forward != 0.0F || this.strafing != 0.0F);
   }

   static HitResult getTarget(ServerPlayer player) {
      double blockReach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
      double entityReach = player.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE);
      HitResult hit = RayTrace.rayTrace(player, 1.0F, blockReach, false);
      return hit.getType() == Type.BLOCK ? hit : RayTrace.rayTrace(player, 1.0F, entityReach, false);
   }

   public void setSlot(int slot) {
      this.player.getInventory().setSelectedSlot(slot - 1);
      this.player.connection.send(new ClientboundSetHeldSlotPacket(slot - 1));
   }

   private static void handleSpearStab(ServerPlayer player) {
      if (!(player.getAttackStrengthScale(0.5F) < 1.0F)) {
         player.connection.handlePlayerAction(new ServerboundPlayerActionPacket(net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STAB, player.blockPosition(), player.getDirection()));
         player.resetLastActionTime();
      }
   }

   private static record DelayedAction(long tick, Runnable action) {
   }

   private static class LookInterpolation {
      float targetYaw;
      float targetPitch;
      float deltaYaw;
      float deltaPitch;
      int ticksRemaining;

      LookInterpolation(float targetYaw, float targetPitch, float deltaYaw, float deltaPitch, int ticks) {
         this.targetYaw = targetYaw;
         this.targetPitch = targetPitch;
         this.deltaYaw = deltaYaw;
         this.deltaPitch = deltaPitch;
         this.ticksRemaining = ticks;
      }
   }

   public static enum ActionType permits null, null, null, null, null, null, null {
      USE(true) {
         boolean execute(ServerPlayer player, BotPlayerActionPack.Action action) {
            BotPlayerActionPack ap = Internals.get().actionPack(player);
            if (ap.itemUseCooldown > 0) {
               --ap.itemUseCooldown;
               return true;
            } else if (player.isUsingItem()) {
               return true;
            } else {
               HitResult hit = BotPlayerActionPack.getTarget(player);
               if (player instanceof BotPlayer) {
                  BotPlayer var5 = (BotPlayer)player;
               }

               return BotPlayerActionPack.ActionType.executeUse(player, hit);
            }
         }

         void inactiveTick(ServerPlayer player, BotPlayerActionPack.Action action) {
            BotPlayerActionPack ap = Internals.get().actionPack(player);
            ap.itemUseCooldown = 0;
            player.releaseUsingItem();
         }

         // $FF: synthetic method
         private static void lambda$execute$0(ServerPlayer player, HitResult hit) {
            BotPlayerActionPack.ActionType.executeUse(player, hit);
         }
      },
      ATTACK(true) {
         boolean execute(ServerPlayer player, BotPlayerActionPack.Action action) {
            ItemStack stack = player.getMainHandItem();
            boolean isSpear = stack.has(DataComponents.KINETIC_WEAPON);
            if (isSpear) {
               if (player.getAttackStrengthScale(0.5F) < 1.0F) {
                  return false;
               } else {
                  if (player instanceof BotPlayer) {
                     BotPlayer var13 = (BotPlayer)player;
                  }

                  BotPlayerActionPack.handleSpearStab(player);
                  return true;
               }
            } else {
               HitResult hit = BotPlayerActionPack.getTarget(player);
               switch (hit.getType()) {
                  case ENTITY:
                     Entity target = ((EntityHitResult)hit).getEntity();
                     boolean continuous = action.isContinuous;
                     if (player instanceof BotPlayer) {
                        BotPlayer var16 = (BotPlayer)player;
                     }

                     if (!continuous) {
                        player.attack(target);
                        McCompat.swing(player, InteractionHand.MAIN_HAND);
                     }

                     player.resetAttackStrengthTicker();
                     player.resetLastActionTime();
                     return true;
                  case BLOCK:
                     BotPlayerActionPack ap = Internals.get().actionPack(player);
                     if (ap.blockHitDelay > 0) {
                        --ap.blockHitDelay;
                        return false;
                     } else {
                        BlockHitResult blockHit = (BlockHitResult)hit;
                        BlockPos pos = blockHit.getBlockPos();
                        Direction side = blockHit.getDirection();
                        if (player.blockActionRestricted(player.level(), pos, player.gameMode.getGameModeForPlayer())) {
                           return false;
                        } else {
                           if (ap.currentBlock != null && player.level().getBlockState(ap.currentBlock).isAir()) {
                              ap.currentBlock = null;
                              return false;
                           }

                           BlockState state = player.level().getBlockState(pos);
                           boolean blockBroken = false;
                           if (player.gameMode.getGameModeForPlayer().isCreative()) {
                              player.gameMode.handleBlockBreakAction(pos, net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
                              ap.blockHitDelay = 5;
                              blockBroken = true;
                           } else if (ap.currentBlock != null && ap.currentBlock.equals(pos)) {
                              ap.curBlockDamageMP += state.getDestroyProgress(player, player.level(), pos);
                              if (ap.curBlockDamageMP >= 1.0F) {
                                 player.gameMode.handleBlockBreakAction(pos, net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
                                 ap.currentBlock = null;
                                 ap.blockHitDelay = 5;
                                 blockBroken = true;
                              }

                              player.level().destroyBlockProgress(-1, pos, (int)(ap.curBlockDamageMP * 10.0F));
                           } else {
                              if (ap.currentBlock != null) {
                                 player.gameMode.handleBlockBreakAction(ap.currentBlock, net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
                              }

                              player.gameMode.handleBlockBreakAction(pos, net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.START_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
                              boolean notAir = !state.isAir();
                              if (notAir && ap.curBlockDamageMP == 0.0F) {
                                 state.attack(player.level(), pos, player);
                              }

                              if (notAir && state.getDestroyProgress(player, player.level(), pos) >= 1.0F) {
                                 ap.currentBlock = null;
                                 blockBroken = true;
                              } else {
                                 ap.currentBlock = pos;
                                 ap.curBlockDamageMP = 0.0F;
                              }
                           }

                           player.resetLastActionTime();
                           McCompat.swing(player, InteractionHand.MAIN_HAND);
                           if (action.resetMineCheck() && ap.currentBlock != null) {
                              player.gameMode.handleBlockBreakAction(ap.currentBlock, net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, side, player.level().getMaxY(), -1);
                              player.level().destroyBlockProgress(-1, ap.currentBlock, -1);
                              ap.currentBlock = null;
                              ap.curBlockDamageMP = 0.0F;
                           }

                           return blockBroken;
                        }
                     }
                  default:
                     if (!action.isContinuous) {
                        McCompat.swing(player, InteractionHand.MAIN_HAND);
                     }

                     player.resetAttackStrengthTicker();
                     player.resetLastActionTime();
                     return false;
               }
            }
         }

         void stop(ServerPlayer player, BotPlayerActionPack.Action action) {
            super.stop(player, action);
            BotPlayerActionPack ap = Internals.get().actionPack(player);
            if (ap != null && ap.currentBlock != null) {
               player.gameMode.handleBlockBreakAction(ap.currentBlock, net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.ABORT_DESTROY_BLOCK, Direction.DOWN, player.level().getMaxY(), -1);
               player.level().destroyBlockProgress(-1, ap.currentBlock, -1);
               ap.currentBlock = null;
               ap.curBlockDamageMP = 0.0F;
            }
         }

         // $FF: synthetic method
         private static void lambda$execute$1(ServerPlayer player, boolean wasSprinting, double savedFallDistance, boolean wasOnGround, boolean continuous, Entity target) {
            boolean currentSprinting = player.isSprinting();
            double currentFallDistance = player.fallDistance;
            boolean currentOnGround = player.onGround();
            player.setSprinting(wasSprinting);
            player.fallDistance = savedFallDistance;
            player.setOnGround(wasOnGround);
            if (!continuous) {
               player.attack(target);
               McCompat.swing(player, InteractionHand.MAIN_HAND);
            }

            player.resetAttackStrengthTicker();
            player.resetLastActionTime();
            player.setSprinting(currentSprinting);
            player.fallDistance = currentFallDistance;
            player.setOnGround(currentOnGround);
         }

         // $FF: synthetic method
         private static void lambda$execute$0(ServerPlayer player) {
            BotPlayerActionPack.handleSpearStab(player);
         }
      },
      JUMP(true) {
         boolean execute(ServerPlayer player, BotPlayerActionPack.Action action) {
            BotPlayerActionPack ap = Internals.get().actionPack(player);
            long currentTick = (long)player.level().getServer().getTickCount();
            if (action.limit == 1) {
               if (player.isPassenger()) {
                  Entity var7 = player.getVehicle();
                  if (var7 instanceof PlayerRideableJumping) {
                     PlayerRideableJumping jumpVehicle = (PlayerRideableJumping)var7;
                     jumpVehicle.handleStartJump(1);
                     jumpVehicle.handleStopJump();
                     ap.jumpChargeAmount = 0;
                  } else {
                     ap.vehicleJumpOverrideTicks = 2;
                     player.setJumping(true);
                  }
               } else {
                  if (player.getAbilities().mayfly && currentTick - ap.lastJumpOnceTick <= 7L) {
                     player.getAbilities().flying = !player.getAbilities().flying;
                     player.onUpdateAbilities();
                     ap.lastJumpOnceTick = -100L;
                     return false;
                  }

                  ap.lastJumpOnceTick = currentTick;
                  if (player.getAbilities().flying) {
                     if (!ap.sneaking && player instanceof BotPlayer) {
                        player.setDeltaMovement(player.getDeltaMovement().add((double)0.0F, 0.15000000000000002, (double)0.0F));
                     }
                  } else if (player.onGround()) {
                     player.jumpFromGround();
                  } else if (!player.onClimbable() && !player.getAbilities().flying) {
                     player.tryToStartFallFlying();
                  }
               }
            } else if (player.isPassenger()) {
               Entity var9 = player.getVehicle();
               if (var9 instanceof PlayerRideableJumping) {
                  PlayerRideableJumping jumpVehicle = (PlayerRideableJumping)var9;
                  ap.jumpChargeAmount = Math.min(ap.jumpChargeAmount + 1, 100);
                  jumpVehicle.handleStartJump(ap.jumpChargeAmount);
               } else if (player.getAbilities().flying) {
                  ap.jumping = true;
               } else {
                  player.setJumping(true);
               }
            } else if (player.getAbilities().flying) {
               ap.jumping = true;
            } else {
               player.setJumping(true);
            }

            return false;
         }

         void inactiveTick(ServerPlayer player, BotPlayerActionPack.Action action) {
            BotPlayerActionPack ap = Internals.get().actionPack(player);
            if (ap.vehicleJumpOverrideTicks <= 0) {
               player.setJumping(false);
            }

            ap.jumping = false;
            Entity var5 = player.getVehicle();
            if (var5 instanceof PlayerRideableJumping jumpVehicle) {
               jumpVehicle.handleStopJump();
               ap.jumpChargeAmount = 0;
            }

         }
      },
      DROP_ITEM(true) {
         boolean execute(ServerPlayer player, BotPlayerActionPack.Action action) {
            player.resetLastActionTime();
            player.drop(false);
            return false;
         }
      },
      DROP_STACK(true) {
         boolean execute(ServerPlayer player, BotPlayerActionPack.Action action) {
            player.resetLastActionTime();
            player.drop(true);
            return false;
         }
      },
      SWAP_HANDS(true) {
         boolean execute(ServerPlayer player, BotPlayerActionPack.Action action) {
            player.resetLastActionTime();
            ItemStack itemStack_1 = player.getItemInHand(InteractionHand.OFF_HAND);
            player.setItemInHand(InteractionHand.OFF_HAND, player.getItemInHand(InteractionHand.MAIN_HAND));
            player.setItemInHand(InteractionHand.MAIN_HAND, itemStack_1);
            return false;
         }
      },
      SWING(false) {
         boolean execute(ServerPlayer player, BotPlayerActionPack.Action action) {
            InteractionHand hand = action.hand == null ? InteractionHand.MAIN_HAND : action.hand;
            McCompat.swing(player, hand);
            player.resetLastActionTime();
            return false;
         }
      };

      public final boolean preventSpectator;

      private static boolean executeUse(ServerPlayer player, HitResult hit) {
         BotPlayerActionPack ap = Internals.get().actionPack(player);

         for(InteractionHand hand : InteractionHand.values()) {
            switch (hit.getType()) {
               case ENTITY:
                  player.resetLastActionTime();
                  EntityHitResult entityHit = (EntityHitResult)hit;
                  Entity entity = entityHit.getEntity();
                  boolean handWasEmpty = player.getItemInHand(hand).isEmpty();
                  boolean itemFrameEmpty = entity instanceof ItemFrame && ((ItemFrame)entity).getItem().isEmpty();
                  Vec3 relativeHitPos = entityHit.getLocation().subtract(entity.getX(), entity.getY(), entity.getZ());
                  if (McCompat.interactAt(entity, player, relativeHitPos, hand).consumesAction()) {
                     ap.itemUseCooldown = 3;
                     return true;
                  }

                  if (McCompat.interactOn(player, entity, hand, relativeHitPos).consumesAction() && (!handWasEmpty || !itemFrameEmpty)) {
                     ap.itemUseCooldown = 3;
                     return true;
                  }
                  break;
               case BLOCK:
                  player.resetLastActionTime();
                  ServerLevel world = player.level();
                  BlockHitResult blockHit = (BlockHitResult)hit;
                  BlockPos pos = blockHit.getBlockPos();
                  Direction side = blockHit.getDirection();
                  if (pos.getY() < player.level().getMaxY() - (side == Direction.UP ? 1 : 0) && world.mayInteract(player, pos)) {
                     InteractionResult result = player.gameMode.useItemOn(player, world, player.getItemInHand(hand), hand, blockHit);
                     if (result instanceof InteractionResult.Success) {
                        InteractionResult.Success success = (InteractionResult.Success)result;
                        if (success.swingSource() != SwingSource.NONE) {
                           McCompat.swing(player, hand);
                        }

                        ap.itemUseCooldown = 3;
                        return true;
                     }
                  }
            }

            ItemStack handItem = player.getItemInHand(hand);
            if (player.gameMode.useItem(player, player.level(), handItem, hand).consumesAction()) {
               ap.itemUseCooldown = 3;
               return true;
            }
         }

         return false;
      }

      private ActionType(boolean preventSpectator) {
         this.preventSpectator = preventSpectator;
      }

      abstract boolean execute(ServerPlayer var1, Action var2);

      void inactiveTick(ServerPlayer player, Action action) {
      }

      void stop(ServerPlayer player, Action action) {
         this.inactiveTick(player, action);
      }

      // $FF: synthetic method
      private static ActionType[] $values() {
         return new ActionType[]{USE, ATTACK, JUMP, DROP_ITEM, DROP_STACK, SWAP_HANDS, SWING};
      }
   }

   public static class Action {
      public boolean done = false;
      public final int limit;
      public final int interval;
      public final int offset;
      public final InteractionHand hand;
      private int count;
      private int next;
      private final boolean isContinuous;
      private int ticksRemaining;

      private Action(int limit, int interval, int offset, boolean continuous, InteractionHand hand, int ticksRemaining) {
         this.limit = limit;
         this.interval = interval;
         this.offset = offset;
         this.hand = hand;
         this.next = interval + offset;
         this.isContinuous = continuous;
         this.ticksRemaining = ticksRemaining;
      }

      public static Action once() {
         return new Action(1, 1, 0, false, (InteractionHand)null, -1);
      }

      public static Action continuous() {
         return new Action(-1, 1, 0, true, (InteractionHand)null, -1);
      }

      public static Action continuous(int ticks) {
         return new Action(-1, 1, 0, true, (InteractionHand)null, ticks);
      }

      public static Action interval(int interval) {
         return new Action(-1, interval, 0, false, (InteractionHand)null, -1);
      }

      public static Action interval(int interval, int ticks) {
         return new Action(-1, interval, 0, false, (InteractionHand)null, ticks);
      }

      public boolean resetMineCheck() {
         return !this.isContinuous || this.ticksRemaining > 0;
      }

      Boolean tick(BotPlayerActionPack actionPack, ActionType type) {
         if (this.ticksRemaining > 0) {
            --this.ticksRemaining;
            if (this.ticksRemaining <= 0) {
               type.stop(actionPack.player, this);
               this.done = true;
               return null;
            }
         }

         --this.next;
         Boolean cancel = null;
         if (this.next <= 0) {
            if (this.interval == 1 && !this.isContinuous && (!type.preventSpectator || !actionPack.player.isSpectator())) {
               type.inactiveTick(actionPack.player, this);
            }

            if (!type.preventSpectator || !actionPack.player.isSpectator()) {
               cancel = type.execute(actionPack.player, this);
            }

            ++this.count;
            if (this.count == this.limit) {
               type.stop(actionPack.player, (Action)null);
               this.done = true;
               return cancel;
            }

            this.next = this.interval;
         } else if (!type.preventSpectator || !actionPack.player.isSpectator()) {
            type.inactiveTick(actionPack.player, this);
         }

         return cancel;
      }

      void retry(BotPlayerActionPack actionPack, ActionType type) {
         if (!type.preventSpectator || !actionPack.player.isSpectator()) {
            type.execute(actionPack.player, this);
         }

         ++this.count;
         if (this.count == this.limit) {
            type.stop(actionPack.player, (Action)null);
            this.done = true;
         }

      }
   }
}
