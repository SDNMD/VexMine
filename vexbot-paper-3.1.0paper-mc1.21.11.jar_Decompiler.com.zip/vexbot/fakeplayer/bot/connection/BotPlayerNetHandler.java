package vexbot.fakeplayer.bot.connection;

import io.papermc.paper.adventure.PaperAdventure;
import java.util.Set;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.PositionMoveRotation;
import net.minecraft.world.entity.Relative;
import org.bukkit.event.player.PlayerKickEvent;
import org.jspecify.annotations.NonNull;
import vexbot.VexBot;
import vexbot.fakeplayer.bot.BotPlayer;

public class BotPlayerNetHandler extends ServerGamePacketListenerImpl {
   public BotPlayerNetHandler(MinecraftServer server, Connection connection, ServerPlayer player, CommonListenerCookie cookie) {
      super(server, connection, player, cookie);
   }

   private void botDisconnect(Component message) {
      ServerPlayer var3 = this.player;
      if (var3 instanceof BotPlayer bot) {
         if (bot.botJoining) {
            VexBot.LOGGER.info("[VexBot] Ignored a join-time disconnect for bot '{}' (reason: {}) — a plugin tried to kick it; keeping the bot.", bot.getGameProfile().name(), message.getString());
         } else {
            bot.botPlayerDisconnect(message);
         }
      }
   }

   public void disconnect(net.kyori.adventure.text.@NonNull Component message) {
      this.botDisconnect(PaperAdventure.asVanilla(message));
   }

   public void disconnect(net.kyori.adventure.text.@NonNull Component message, PlayerKickEvent.@NonNull Cause cause) {
      this.botDisconnect(PaperAdventure.asVanilla(message));
   }

   public void disconnect(@NonNull Component message, PlayerKickEvent.@NonNull Cause cause) {
      this.botDisconnect(message);
   }

   public boolean hasClientLoaded() {
      return this.player instanceof BotPlayer || super.hasClientLoaded();
   }

   public void markClientUnloadedAfterDeath() {
      if (!(this.player instanceof BotPlayer)) {
         super.markClientUnloadedAfterDeath();
      }

   }

   public void teleport(@NonNull PositionMoveRotation pos, @NonNull Set<Relative> relatives) {
      super.teleport(pos, relatives);
      if (this.player.level().getPlayerByUUID(this.player.getUUID()) != null) {
         this.resetPosition();
         this.player.level().getChunkSource().move(this.player);
      }

      BotPlayer botPlayer = (BotPlayer)this.player;
      if (botPlayer.getPathFollower() != null) {
         botPlayer.getPathFollower().requestRecalc();
      }

   }
}
