package vexbot.fakeplayer.bot.connection;

import vexbot.fakeplayer.bot.BotPlayerActionPack;

public interface ServerPlayerInterface {
   BotPlayerActionPack getActionPack();
}
