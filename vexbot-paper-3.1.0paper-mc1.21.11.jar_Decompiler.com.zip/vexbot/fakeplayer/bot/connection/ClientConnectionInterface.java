package vexbot.fakeplayer.bot.connection;

import io.netty.channel.Channel;

public interface ClientConnectionInterface {
   void setChannel(Channel var1);
}
