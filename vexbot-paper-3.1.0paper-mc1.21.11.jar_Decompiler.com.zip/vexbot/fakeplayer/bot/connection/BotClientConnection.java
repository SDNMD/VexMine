package vexbot.fakeplayer.bot.connection;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import io.netty.channel.embedded.EmbeddedChannel;
import io.netty.util.ReferenceCountUtil;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import vexbot.platform.Internals;

public class BotClientConnection extends Connection {
   private static final String[] VANILLA_HANDLERS = new String[]{"timeout", "splitter", "decoder", "prepender", "encoder", "unbundler", "bundler", "packet_handler"};

   public BotClientConnection(PacketFlow p) {
      super(p);
      Internals.get().setConnectionChannel(this, botChannel());
   }

   private static EmbeddedChannel botChannel() {
      EmbeddedChannel ch = new EmbeddedChannel();
      ch.pipeline().addLast("vexbot_sink", new ChannelOutboundHandlerAdapter() {
         public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) {
            ReferenceCountUtil.release(msg);
            promise.trySuccess();
         }
      });

      for(String name : VANILLA_HANDLERS) {
         ch.pipeline().addLast(name, new ChannelDuplexHandler());
      }

      return ch;
   }

   public void setReadOnly() {
   }

   public void send(@NonNull Packet<?> packet, @Nullable ChannelFutureListener channelFutureListener, boolean bl) {
   }

   public void handleDisconnection() {
   }

   public void setListenerForServerboundHandshake(@NonNull PacketListener packetListener) {
   }

   public <T extends PacketListener> void setupInboundProtocol(@NonNull ProtocolInfo<T> protocolInfo, @NonNull T packetListener) {
   }
}
