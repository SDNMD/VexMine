package vexbot.fakeplayer.bot.pathing;

import java.util.Arrays;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import vexbot.platform.Internals;

public final class BlockProbe implements AutoCloseable {
   private static final int SHARED_BITS = 15;
   private static final int NESTED_BITS = 10;
   private static final int MAX_PROBE = 8;
   private static final int COL_BITS = 8;
   private static final int MAX_COL_PROBE = 16;
   private static final int WATER = 1;
   private static final int SHAPE_EMPTY = 2;
   private static final int BUBBLE = 4;
   private static final int NOT_AVOIDED = 8;
   private static final int IN_BOUNDS = 16;
   private static final int DYNAMIC = 32;
   private static final int DRAG_DOWN = 64;
   private static final int STAMP_SHIFT = 8;
   private static final int STAMP_MAX = 16777215;
   private static final long NO_COLUMN = Long.MIN_VALUE;
   private static final int STATE_BITS = 7;
   private static final int MAX_STATE_PROBE = 8;
   private static Owned shared;
   private final int bits;
   private final int mask;
   private final int scratch;
   private final long[] keys;
   private final int[] meta;
   private final BlockState[] states;
   private final int colBits;
   private final int colMask;
   private final long[] colKeys;
   private final int[] colStamps;
   private final LevelChunk[] colChunks;
   private final BlockState[] stateKeys = new BlockState[128];
   private final int[] stateVals = new int[128];
   private final int[] stateStamps = new int[128];
   private final BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
   private int stamp;
   private int stateStamp;
   private BlockState lastState;
   private int lastStateFlags;
   private boolean open;
   private Level level;
   private ServerLevel serverLevel;
   private PathSettings settings;
   private Internals internals;
   private long lastCol;
   private LevelChunk lastChunk;
   private int minY;
   private int maxY;

   private BlockProbe(int bits, int colBits) {
      this.bits = bits;
      this.mask = (1 << bits) - 1;
      this.scratch = 1 << bits;
      this.keys = new long[(1 << bits) + 1];
      this.meta = new int[(1 << bits) + 1];
      this.states = new BlockState[(1 << bits) + 1];
      this.colBits = colBits;
      this.colMask = (1 << colBits) - 1;
      this.colKeys = new long[1 << colBits];
      this.colStamps = new int[1 << colBits];
      this.colChunks = new LevelChunk[1 << colBits];
   }

   public static BlockProbe open(Level level, PathSettings settings) {
      ServerLevel var10000;
      label41: {
         if (level instanceof ServerLevel sl) {
            if (sl.getServer().isSameThread()) {
               var10000 = sl;
               break label41;
            }
         }

         var10000 = null;
      }

      ServerLevel server = var10000;
      BlockProbe probe;
      if (server == null) {
         probe = new BlockProbe(1, 1);
      } else {
         Thread thread = Thread.currentThread();
         Owned owned = shared;
         if (owned != null && owned.owner() == thread) {
            probe = owned.probe();
         } else {
            probe = new BlockProbe(15, 8);
            shared = new Owned(thread, probe);
         }

         if (probe.open) {
            probe = new BlockProbe(10, 8);
         }
      }

      probe.open = true;
      probe.level = level;
      probe.serverLevel = server;
      probe.settings = settings;
      probe.internals = server != null ? Internals.get() : null;
      probe.lastCol = Long.MIN_VALUE;
      probe.lastChunk = null;
      if (server != null) {
         probe.minY = level.getMinY();
         probe.maxY = level.getMaxY();
      }

      probe.lastState = null;
      if (++probe.stateStamp == 0) {
         Arrays.fill(probe.stateStamps, 0);
         probe.stateStamp = 1;
      }

      probe.newEpoch();
      return probe;
   }

   public void close() {
      this.open = false;
      this.level = null;
      this.serverLevel = null;
      this.settings = null;
      this.internals = null;
      this.lastChunk = null;
      this.lastState = null;
      Arrays.fill(this.colChunks, (Object)null);
   }

   public PathSettings settings() {
      return this.settings;
   }

   public BlockState state(int x, int y, int z) {
      return this.serverLevel == null ? this.level.getBlockState(new BlockPos(x, y, z)) : this.states[this.slot(x, y, z)];
   }

   public boolean isPassable(int x, int y, int z) {
      if (this.serverLevel == null) {
         return MovementHelper.isPassable(this.level, x, y, z, this.settings);
      } else {
         int i = this.slot(x, y, z);
         int m = this.meta[i];
         if ((m & 32) == 0) {
            return (m & 10) == 10;
         } else {
            return this.dynamicShapeEmpty(this.states[i], x, y, z) && (m & 8) != 0;
         }
      }
   }

   public boolean canWalkOn(int x, int y, int z) {
      if (this.serverLevel == null) {
         return MovementHelper.canWalkOn(this.level, x, y, z, this.settings);
      } else {
         int i = this.slot(x, y, z);
         int m = this.meta[i];
         if ((m & 32) == 0) {
            return (m & 10) == 8;
         } else {
            return !this.dynamicShapeEmpty(this.states[i], x, y, z) && (m & 8) != 0;
         }
      }
   }

   public boolean isWalkable(int x, int y, int z) {
      if (!this.isPassable(x, y, z)) {
         return false;
      } else {
         return !this.isPassable(x, y + 1, z) ? false : this.canWalkOn(x, y - 1, z);
      }
   }

   public boolean isSolid(int x, int y, int z) {
      if (this.serverLevel == null) {
         BlockPos pos = new BlockPos(x, y, z);
         return !this.level.getBlockState(pos).getCollisionShape(this.level, pos).isEmpty();
      } else {
         int i = this.slot(x, y, z);
         if ((this.meta[i] & 32) != 0) {
            return !this.dynamicShapeEmpty(this.states[i], x, y, z);
         } else {
            return (this.meta[i] & 2) == 0;
         }
      }
   }

   public boolean isWater(int x, int y, int z) {
      if (this.serverLevel == null) {
         return MovementHelper.isWater(this.level, x, y, z);
      } else {
         return (this.meta[this.slot(x, y, z)] & 1) != 0;
      }
   }

   public boolean isBubbleColumn(int x, int y, int z) {
      if (this.serverLevel == null) {
         return MovementHelper.isBubbleColumn(this.level, x, y, z);
      } else {
         return (this.meta[this.slot(x, y, z)] & 4) != 0;
      }
   }

   public boolean isBubbleColumnUp(int x, int y, int z) {
      if (this.serverLevel == null) {
         return MovementHelper.isBubbleColumnUp(this.level, x, y, z);
      } else {
         return (this.meta[this.slot(x, y, z)] & 68) == 4;
      }
   }

   public boolean isBubbleColumnDown(int x, int y, int z) {
      if (this.serverLevel == null) {
         return MovementHelper.isBubbleColumnDown(this.level, x, y, z);
      } else {
         return (this.meta[this.slot(x, y, z)] & 68) == 68;
      }
   }

   public boolean canSwimThrough(int x, int y, int z) {
      if (this.serverLevel == null) {
         return MovementHelper.canSwimThrough(this.level, x, y, z);
      } else {
         int i = this.slot(x, y, z);
         boolean empty = (this.meta[i] & 32) != 0 ? this.dynamicShapeEmpty(this.states[i], x, y, z) : (this.meta[i] & 2) != 0;
         return empty && this.isWater(x, y, z);
      }
   }

   public int getBubbleColumnHeight(int x, int y, int z, boolean goingUp) {
      int count = 0;
      int dy = goingUp ? 1 : -1;

      for(int cy = y; this.isBubbleColumn(x, cy, z); cy += dy) {
         ++count;
      }

      return count;
   }

   private int slot(int x, int y, int z) {
      if (!packable(x, y, z)) {
         return this.uncached(x, y, z);
      } else {
         long key = key(x, y, z);
         int i = this.find(key);
         boolean inBounds = i >= 0 ? (this.meta[i] & 16) != 0 : this.inBounds(x, y, z);
         if (inBounds) {
            long col = column(x >> 4, z >> 4);
            if (col != this.lastCol) {
               int epoch = this.stamp;
               BlockState read = this.enter(col, x, y, z);
               if (read != null) {
                  return this.insert(key, read, 16 | this.stateFlags(read, x, y, z));
               }

               if (this.stamp != epoch) {
                  i = -1;
               }
            }
         }

         if (i >= 0) {
            return i;
         } else {
            BlockState s;
            if (!inBounds) {
               s = this.level.getBlockState(new BlockPos(x, y, z));
            } else if (this.lastChunk != null) {
               s = this.lastChunk.getBlockState(this.cursor.set(x, y, z));
            } else {
               s = this.level.getBlockState(new BlockPos(x, y, z));
            }

            return this.insert(key, s, (inBounds ? 16 : 0) | this.stateFlags(s, x, y, z));
         }
      }
   }

   private boolean inBounds(int x, int y, int z) {
      return y >= this.minY && y <= this.maxY && ChunkPos.isValid(x >> 4, z >> 4);
   }

   private BlockState enter(long col, int x, int y, int z) {
      int cx = x >> 4;
      int cz = z >> 4;
      LevelChunk full = this.knownColumn(col);
      if (full == null) {
         full = this.internals.fullChunkNow(this.serverLevel, cx, cz);
         if (full == null) {
            BlockState s = this.level.getBlockState(new BlockPos(x, y, z));
            this.newEpoch();
            this.lastCol = col;
            this.lastChunk = null;
            return s;
         }

         this.rememberColumn(col, full);
      }

      LevelChunk got = this.level.getChunk(cx, cz);
      this.lastCol = col;
      if (got == full) {
         this.lastChunk = got;
      } else {
         this.newEpoch();
         this.lastChunk = null;
      }

      return null;
   }

   private int uncached(int x, int y, int z) {
      BlockPos pos = new BlockPos(x, y, z);
      BlockState s = this.level.getBlockState(pos);
      if (this.level.isInValidBounds(pos)) {
         this.newEpoch();
         this.lastCol = Long.MIN_VALUE;
         this.lastChunk = null;
      }

      this.keys[this.scratch] = 0L;
      this.states[this.scratch] = s;
      this.meta[this.scratch] = this.stamp << 8 | this.stateFlags(s, x, y, z);
      return this.scratch;
   }

   private boolean dynamicShapeEmpty(BlockState s, int x, int y, int z) {
      boolean empty = s.getCollisionShape(this.level, new BlockPos(x, y, z)).isEmpty();
      this.newEpoch();
      this.lastCol = Long.MIN_VALUE;
      this.lastChunk = null;
      return empty;
   }

   private int stateFlags(BlockState s, int x, int y, int z) {
      if (s == this.lastState) {
         return this.lastStateFlags;
      } else {
         int h = System.identityHashCode(s);
         int mask = 127;
         int i = (h ^ h >>> 16) & mask;
         int n = 0;

         int f;
         while(true) {
            if (this.stateStamps[i] != this.stateStamp) {
               f = this.computeStateFlags(s, x, y, z);
               this.stateKeys[i] = s;
               this.stateVals[i] = f;
               this.stateStamps[i] = this.stateStamp;
               break;
            }

            if (this.stateKeys[i] == s) {
               f = this.stateVals[i];
               break;
            }

            if (n == 7) {
               f = this.computeStateFlags(s, x, y, z);
               break;
            }

            i = i + 1 & mask;
            ++n;
         }

         this.lastState = s;
         this.lastStateFlags = f;
         return f;
      }
   }

   private int computeStateFlags(BlockState s, int x, int y, int z) {
      Block block = s.getBlock();
      int f = 0;
      if (block.hasDynamicShape()) {
         f |= 32;
      } else if (s.getCollisionShape(this.level, this.cursor.set(x, y, z)).isEmpty()) {
         f |= 2;
      }

      if (this.settings.isNotAvoided(block)) {
         f |= 8;
      }

      if (MovementHelper.isWater(s)) {
         f |= 1;
      }

      if (MovementHelper.isBubbleColumn(s)) {
         f |= 4;
         if (MovementHelper.isBubbleColumnDown(s)) {
            f |= 64;
         }
      }

      return f;
   }

   private void newEpoch() {
      if (++this.stamp > 16777215) {
         Arrays.fill(this.meta, 0);
         Arrays.fill(this.colStamps, 0);
         this.stamp = 1;
      }

   }

   private static boolean packable(int x, int y, int z) {
      return x + 33554432 >>> 26 == 0 && z + 33554432 >>> 26 == 0 && y + 2048 >>> 12 == 0;
   }

   private static long key(int x, int y, int z) {
      return (long)(x & 67108863) << 38 | (long)(z & 67108863) << 12 | (long)(y & 4095);
   }

   private static long column(int cx, int cz) {
      return (long)cx & 4294967295L | ((long)cz & 4294967295L) << 32;
   }

   private int home(long key) {
      return (int)(key * -7046029254386353131L >>> 64 - this.bits);
   }

   private int find(long key) {
      int i = this.home(key);

      for(int n = 0; n < 8; ++n) {
         int m = this.meta[i];
         if (m >>> 8 != this.stamp) {
            return -1;
         }

         if (this.keys[i] == key) {
            return i;
         }

         i = i + 1 & this.mask;
      }

      return -1;
   }

   private int insert(long key, BlockState s, int flags) {
      int home = this.home(key);
      int i = home;

      for(int n = 0; this.meta[i] >>> 8 == this.stamp; ++n) {
         if (n == 7) {
            i = home;
            break;
         }

         i = i + 1 & this.mask;
      }

      this.keys[i] = key;
      this.states[i] = s;
      this.meta[i] = this.stamp << 8 | flags;
      return i;
   }

   private int colHome(long col) {
      return (int)(col * -7046029254386353131L >>> 64 - this.colBits);
   }

   private LevelChunk knownColumn(long col) {
      int i = this.colHome(col);

      for(int n = 0; n < 16; ++n) {
         if (this.colStamps[i] != this.stamp) {
            return null;
         }

         if (this.colKeys[i] == col) {
            return this.colChunks[i];
         }

         i = i + 1 & this.colMask;
      }

      return null;
   }

   private void rememberColumn(long col, LevelChunk chunk) {
      int i = this.colHome(col);

      for(int n = 0; n < 16; ++n) {
         if (this.colStamps[i] != this.stamp) {
            this.colKeys[i] = col;
            this.colChunks[i] = chunk;
            this.colStamps[i] = this.stamp;
            return;
         }

         i = i + 1 & this.colMask;
      }

   }

   private static record Owned(Thread owner, BlockProbe probe) {
   }
}
