package vexbot.fakeplayer.bot.pathing;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public class PathSettings {
   private final Set<Block> avoidedBlocks = new LinkedHashSet();
   private MoveType moveType;
   private double maxHorizontalDistance;
   private double maxVerticalDistance;
   private double nodeHorizontalDistance;
   private double nodeVerticalDistance;
   private boolean stopFollowing;
   private double horizontalMoveCost;
   private double verticalMoveCost;
   private double swimCostMultiplier;
   private boolean debug;

   public PathSettings() {
      this.moveType = PathSettings.MoveType.SPRINT;
      this.maxHorizontalDistance = (double)1.0F;
      this.maxVerticalDistance = (double)2.0F;
      this.nodeHorizontalDistance = (double)0.25F;
      this.nodeVerticalDistance = (double)0.5F;
      this.stopFollowing = true;
      this.horizontalMoveCost = (double)1.0F;
      this.verticalMoveCost = (double)1.5F;
      this.swimCostMultiplier = (double)3.0F;
      this.debug = false;
      this.avoidedBlocks.add(Blocks.LAVA);
      this.avoidedBlocks.add(Blocks.MAGMA_BLOCK);
      this.avoidedBlocks.add(Blocks.FIRE);
      this.avoidedBlocks.add(Blocks.SOUL_FIRE);
      this.avoidedBlocks.add(Blocks.CACTUS);
      this.avoidedBlocks.add(Blocks.SWEET_BERRY_BUSH);
      this.avoidedBlocks.add(Blocks.WITHER_ROSE);
      this.avoidedBlocks.add(Blocks.COBWEB);
      this.avoidedBlocks.add(Blocks.SCULK_SHRIEKER);
      this.avoidedBlocks.add(Blocks.RAIL);
      this.avoidedBlocks.add(Blocks.POWERED_RAIL);
      this.avoidedBlocks.add(Blocks.DETECTOR_RAIL);
      this.avoidedBlocks.add(Blocks.ACTIVATOR_RAIL);
   }

   public void copyFrom(PathSettings other) {
      this.avoidedBlocks.clear();
      this.avoidedBlocks.addAll(other.avoidedBlocks);
      this.moveType = other.moveType;
      this.maxHorizontalDistance = other.maxHorizontalDistance;
      this.maxVerticalDistance = other.maxVerticalDistance;
      this.nodeHorizontalDistance = other.nodeHorizontalDistance;
      this.nodeVerticalDistance = other.nodeVerticalDistance;
      this.stopFollowing = other.stopFollowing;
      this.horizontalMoveCost = other.horizontalMoveCost;
      this.verticalMoveCost = other.verticalMoveCost;
      this.swimCostMultiplier = other.swimCostMultiplier;
      this.debug = other.debug;
   }

   public boolean isNotAvoided(Block block) {
      return !this.avoidedBlocks.contains(block);
   }

   public Set<Block> getAvoidedBlocks() {
      return Collections.unmodifiableSet(this.avoidedBlocks);
   }

   public void addAvoidedBlock(Block block) {
      this.avoidedBlocks.add(block);
   }

   public boolean removeAvoidedBlock(Block block) {
      return this.avoidedBlocks.remove(block);
   }

   public void clearAvoidedBlocks() {
      this.avoidedBlocks.clear();
   }

   public MoveType getMoveType() {
      return this.moveType;
   }

   public void setMoveType(MoveType moveType) {
      this.moveType = moveType;
   }

   public double getMaxHorizontalDistance() {
      return this.maxHorizontalDistance;
   }

   public void setMaxHorizontalDistance(double value) {
      if (!(value <= (double)0.0F)) {
         this.maxHorizontalDistance = value;
      }
   }

   public double getMaxVerticalDistance() {
      return this.maxVerticalDistance;
   }

   public void setMaxVerticalDistance(double value) {
      this.maxVerticalDistance = value;
   }

   public double getNodeHorizontalDistance() {
      return this.nodeHorizontalDistance;
   }

   public void setNodeHorizontalDistance(double value) {
      if (!(value <= (double)0.0F)) {
         this.nodeHorizontalDistance = value;
      }
   }

   public double getNodeVerticalDistance() {
      return this.nodeVerticalDistance;
   }

   public void setNodeVerticalDistance(double value) {
      this.nodeVerticalDistance = value;
   }

   public boolean isStopFollowing() {
      return this.stopFollowing;
   }

   public void setStopFollowing(boolean value) {
      this.stopFollowing = value;
   }

   public double getHorizontalMoveCost() {
      return this.horizontalMoveCost;
   }

   public void setHorizontalMoveCost(double value) {
      if (!(value <= (double)0.0F)) {
         this.horizontalMoveCost = value;
      }
   }

   public double getVerticalMoveCost() {
      return this.verticalMoveCost;
   }

   public void setVerticalMoveCost(double value) {
      if (!(value <= (double)0.0F)) {
         this.verticalMoveCost = value;
      }
   }

   public double getSwimCostMultiplier() {
      return this.swimCostMultiplier;
   }

   public void setSwimCostMultiplier(double value) {
      if (!(value <= (double)0.0F)) {
         this.swimCostMultiplier = value;
      }
   }

   public void calculateSwimCost(double waterMovementEfficiency, boolean hasDolphinsGrace) {
      double base = (double)3.0F;
      base *= (double)1.0F - waterMovementEfficiency * 0.9;
      if (hasDolphinsGrace) {
         base *= 0.3;
      }

      this.swimCostMultiplier = Math.max(0.1, base);
   }

   public boolean isDebug() {
      return this.debug;
   }

   public void setDebug(boolean value) {
      this.debug = value;
   }

   public boolean isWithinTarget(double hDist, double vDist) {
      boolean hOk = hDist <= this.maxHorizontalDistance;
      boolean vOk = this.maxVerticalDistance < (double)0.0F || vDist <= this.maxVerticalDistance;
      return hOk && vOk;
   }

   public boolean isWithinNode(double hDist, double vDist) {
      boolean hOk = hDist <= this.nodeHorizontalDistance;
      boolean vOk = this.nodeVerticalDistance < (double)0.0F || vDist <= this.nodeVerticalDistance;
      return hOk && vOk;
   }

   public static enum MoveType {
      WALK,
      SPRINT,
      SPRINT_JUMP;

      public String displayName() {
         String var10000;
         switch (this.ordinal()) {
            case 0 -> var10000 = "walk";
            case 1 -> var10000 = "sprint";
            case 2 -> var10000 = "sprint-jump";
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }

      // $FF: synthetic method
      private static MoveType[] $values() {
         return new MoveType[]{WALK, SPRINT, SPRINT_JUMP};
      }
   }
}
