package vexbot.fakeplayer.bot.pathing;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BubbleColumnBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;

public final class MovementHelper {
   private MovementHelper() {
   }

   public static boolean isPassable(Level level, int x, int y, int z, PathSettings settings) {
      BlockPos pos = new BlockPos(x, y, z);
      BlockState state = level.getBlockState(pos);
      return !state.getCollisionShape(level, pos).isEmpty() ? false : settings.isNotAvoided(state.getBlock());
   }

   public static boolean canWalkOn(Level level, int x, int y, int z, PathSettings settings) {
      BlockPos pos = new BlockPos(x, y, z);
      BlockState state = level.getBlockState(pos);
      return state.getCollisionShape(level, pos).isEmpty() ? false : settings.isNotAvoided(state.getBlock());
   }

   public static boolean isWalkable(Level level, int x, int y, int z, PathSettings settings) {
      if (!isPassable(level, x, y, z, settings)) {
         return false;
      } else {
         return !isPassable(level, x, y + 1, z, settings) ? false : canWalkOn(level, x, y - 1, z, settings);
      }
   }

   public static boolean isWater(Level level, int x, int y, int z) {
      return isWater(level.getBlockState(new BlockPos(x, y, z)));
   }

   public static boolean isWater(BlockState state) {
      FluidState fluid = state.getFluidState();
      return fluid.is(Fluids.WATER) || fluid.is(Fluids.FLOWING_WATER) || state.is(Blocks.BUBBLE_COLUMN);
   }

   public static boolean isBubbleColumn(Level level, int x, int y, int z) {
      return isBubbleColumn(level.getBlockState(new BlockPos(x, y, z)));
   }

   public static boolean isBubbleColumn(BlockState state) {
      return state.is(Blocks.BUBBLE_COLUMN);
   }

   public static boolean isBubbleColumnUp(Level level, int x, int y, int z) {
      return isBubbleColumnUp(level.getBlockState(new BlockPos(x, y, z)));
   }

   public static boolean isBubbleColumnUp(BlockState state) {
      return state.is(Blocks.BUBBLE_COLUMN) && !(Boolean)state.getValue(BubbleColumnBlock.DRAG_DOWN);
   }

   public static boolean isBubbleColumnDown(Level level, int x, int y, int z) {
      return isBubbleColumnDown(level.getBlockState(new BlockPos(x, y, z)));
   }

   public static boolean isBubbleColumnDown(BlockState state) {
      return state.is(Blocks.BUBBLE_COLUMN) && (Boolean)state.getValue(BubbleColumnBlock.DRAG_DOWN);
   }

   public static boolean canSwimThrough(Level level, int x, int y, int z) {
      BlockPos pos = new BlockPos(x, y, z);
      BlockState state = level.getBlockState(pos);
      return state.getCollisionShape(level, pos).isEmpty() && isWater(level, x, y, z);
   }

   public static int getBubbleColumnHeight(Level level, int x, int y, int z, boolean goingUp) {
      int count = 0;
      int dy = goingUp ? 1 : -1;

      for(int cy = y; isBubbleColumn(level, x, cy, z); cy += dy) {
         ++count;
      }

      return count;
   }
}
