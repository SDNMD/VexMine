package vexbot.fakeplayer.bot;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.UUIDUtil;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentContents;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.game.ClientboundEntityPositionSyncPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundRotateHeadPacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket.Action;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.players.NameAndId;
import net.minecraft.server.players.OldUsersConverter;
import net.minecraft.server.players.PlayerList;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.ProblemReporter;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.throwableitemprojectile.AbstractThrownPotion;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.BlocksAttacks;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.level.storage.LevelData.RespawnData;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import org.jspecify.annotations.NonNull;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.compat.CompatServerPlayer;
import vexbot.compat.LuckPermsCompat;
import vexbot.fakeplayer.bot.connection.BotClientConnection;
import vexbot.fakeplayer.bot.pathing.PathSettings;
import vexbot.i18n.VexText;
import vexbot.nick.NickManager;
import vexbot.platform.Internals;
import vexbot.platform.Platform;
import vexbot.stats.Stats;
import vexbot.util.MeleeWeaponGuard;

public class BotPlayer extends CompatServerPlayer {
   private static final Set<String> spawning = ConcurrentHashMap.newKeySet();
   public int ping = 0;
   private final List<DelayedKnockback> pendingKnockbacks = new ArrayList();
   private final List<DelayedExplosionKB> pendingExplosionKB = new ArrayList();
   private long shieldDisabledTick = -1L;
   public Runnable fixStartingPosition = () -> {
   };
   public boolean isAShadow;
   public Vec3 spawnPos;
   private ResourceKey<Level> spawnDimension;
   public double spawnYaw;
   public boolean botJoining = false;
   private boolean inventoryScreenOpen;
   private BotPathing pathFollower;
   private final PathSettings pathSettings = new PathSettings();
   private static final Map<String, String[]> pendingSkins = new ConcurrentHashMap();
   private static final ExecutorService UUID_LOOKUP = Executors.newFixedThreadPool(12, (r) -> {
      Thread t = new Thread(r, "VexBot UUID lookup");
      t.setDaemon(true);
      return t;
   });
   private static final Map<String, Long> NO_ACCOUNT = new ConcurrentHashMap();
   private static final long NO_ACCOUNT_DAYS = 30L;
   private static volatile boolean noAccountLoaded;
   private static volatile long noAccountSavedAt;
   private static final Map<UUID, GameProfile> SKINS = new ConcurrentHashMap();
   public static final byte SKIN_CAPE = 1;
   public static final byte SKIN_JACKET = 2;
   public static final byte SKIN_LEFT_SLEEVE = 4;
   public static final byte SKIN_RIGHT_SLEEVE = 8;
   public static final byte SKIN_LEFT_PANT = 16;
   public static final byte SKIN_RIGHT_PANT = 32;
   public static final byte SKIN_HAT = 64;
   private static final boolean DEBUG_HURT = Boolean.getBoolean("vexbot.debugHurt");

   public PathSettings getPathSettings() {
      return this.pathSettings;
   }

   public void setPathFollower(BotPathing follower) {
      if (this.pathFollower != null) {
         this.pathFollower.stop();
      }

      this.pathFollower = follower;
   }

   public BotPathing getPathFollower() {
      return this.pathFollower;
   }

   public void clearPathFollower() {
      if (this.pathFollower != null) {
         this.pathFollower.stop();
         this.pathFollower = null;
      }

   }

   public boolean isScreenOpen() {
      return this.inventoryScreenOpen || this.containerMenu != this.inventoryMenu;
   }

   public boolean isContainerOpen() {
      return this.containerMenu != this.inventoryMenu;
   }

   public void openInventoryScreen() {
      this.inventoryScreenOpen = true;
   }

   public void closeScreen() {
      if (this.containerMenu != this.inventoryMenu) {
         this.closeContainer();
      }

      this.inventoryScreenOpen = false;
   }

   public AbstractContainerMenu getActiveMenu() {
      if (this.containerMenu != this.inventoryMenu) {
         return this.containerMenu;
      } else {
         return this.inventoryScreenOpen ? this.inventoryMenu : null;
      }
   }

   public static void setPendingSkin(String name, String value, String signature) {
      if (name != null && value != null && !value.isEmpty()) {
         pendingSkins.put(name.toLowerCase(Locale.ROOT), new String[]{value, signature});
      }
   }

   private static GameProfile applyPendingSkin(GameProfile profile) {
      if (profile != null && profile.name() != null) {
         String[] skin = (String[])pendingSkins.remove(profile.name().toLowerCase(Locale.ROOT));
         if (skin == null) {
            return profile;
         } else {
            try {
               Multimap<String, Property> backing = LinkedHashMultimap.create();
               profile.properties().forEach((k, v) -> {
                  if (!"textures".equals(k)) {
                     backing.put(k, v);
                  }

               });
               Property p = skin[1] != null && !skin[1].isEmpty() ? new Property("textures", skin[0], skin[1]) : new Property("textures", skin[0]);
               backing.put("textures", p);
               return new GameProfile(profile.id(), profile.name(), new PropertyMap(backing));
            } catch (Throwable t) {
               VexBot.LOGGER.warn("[VexBot] Couldn't apply custom skin to '{}' — spawning without it: {}", profile.name(), t.toString());
               return profile;
            }
         }
      } else {
         return profile;
      }
   }

   public static int createFake(String username, MinecraftServer server, Vec3 pos, double yaw, double pitch, ResourceKey<Level> dimensionId, GameType gamemode, boolean flying) {
      return createFake(username, server, pos, yaw, pitch, dimensionId, gamemode, flying, (Runnable)null);
   }

   public static int createFake(String username, MinecraftServer server, Vec3 pos, double yaw, double pitch, ResourceKey<Level> dimensionId, GameType gamemode, boolean flying, Runnable onNoUuid) {
      ServerLevel worldIn = server.getLevel(dimensionId);
      spawning.add(username);
      CompletableFuture.supplyAsync(() -> lookupUuid(server, username), UUID_LOOKUP).whenCompleteAsync((found, err) -> {
         UUID uuid = err == null ? found : null;
         if (uuid == null) {
            server.services().nameToIdCache().resolveOfflineUsers(server.isDedicatedServer() && server.usesAuthentication());
            uuid = UUIDUtil.createOfflinePlayerUUID(username);
         }

         if (uuid == null) {
            spawning.remove(username);
            if (onNoUuid != null) {
               onNoUuid.run();
            }

         } else {
            continueSpawn(username, server, worldIn, uuid, pos, yaw, pitch, dimensionId, gamemode, flying);
         }
      }, server);
      return 1;
   }

   private static UUID lookupUuid(MinecraftServer server, String username) {
      loadNoAccount();
      String key = username.toLowerCase(Locale.ROOT);
      if (NO_ACCOUNT.containsKey(key)) {
         return null;
      } else {
         server.services().nameToIdCache().resolveOfflineUsers(false);
         UUID uuid = OldUsersConverter.convertMobOwnerIfNecessary(server, username);
         if (uuid == null && NO_ACCOUNT.size() < 200000) {
            NO_ACCOUNT.put(key, LocalDate.now().toEpochDay());
            saveNoAccount(false);
         }

         return uuid;
      }
   }

   private static Path noAccountFile() {
      return Platform.get().configDir().resolve("vexbot_noaccount.json");
   }

   private static synchronized void loadNoAccount() {
      if (!noAccountLoaded) {
         noAccountLoaded = true;

         try {
            Path f = noAccountFile();
            if (!Files.isRegularFile(f, new LinkOption[0])) {
               return;
            }

            long today = LocalDate.now().toEpochDay();
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();

            for(Map.Entry<String, JsonElement> e : o.entrySet()) {
               long day = ((JsonElement)e.getValue()).getAsLong();
               if (today - day < 30L) {
                  NO_ACCOUNT.put((String)e.getKey(), day);
               }
            }
         } catch (Exception e) {
            VexBot.LOGGER.warn("[VexBot] Could not read vexbot_noaccount.json: {}", e.toString());
         }

      }
   }

   public static synchronized void saveNoAccount(boolean force) {
      long now = System.currentTimeMillis();
      if (noAccountLoaded && (force || now - noAccountSavedAt >= 5000L)) {
         noAccountSavedAt = now;

         try {
            JsonObject o = new JsonObject();
            Map var10000 = NO_ACCOUNT;
            Objects.requireNonNull(o);
            var10000.forEach(o::addProperty);
            Files.writeString(noAccountFile(), o.toString());
         } catch (Exception e) {
            VexBot.LOGGER.warn("[VexBot] Could not write vexbot_noaccount.json: {}", e.toString());
         }

      }
   }

   private static void continueSpawn(String username, MinecraftServer server, ServerLevel worldIn, UUID uuid, Vec3 pos, double yaw, double pitch, ResourceKey<Level> dimensionId, GameType gamemode, boolean flying) {
      UUID skinId = uuid;
      if (hasNonBotPlayerData(server, uuid, username)) {
         uuid = botOnlyUuid(username);
         VexBot.LOGGER.info("[VexBot] '{}' is a real player's name here — spawning the bot as {} to keep their save untouched.", username, uuid);
      }

      GameProfile gameprofile = new GameProfile(uuid, username);
      String name = gameprofile.name();
      fetchGameProfile(server, skinId).whenCompleteAsync((p, t) -> {
         spawning.remove(name);
         GameProfile current;
         if (t == null && p != null && !p.name().isEmpty()) {
            current = new GameProfile(uuid, gameprofile.name(), p.properties());
         } else {
            current = gameprofile;
         }

         try {
            placeBot(server, worldIn, current, pos, yaw, pitch, dimensionId, gamemode, flying);
         } catch (Throwable placeError) {
            VexBot.LOGGER.error("[VexBot] Failed to place bot '{}': {}", new Object[]{name, placeError.toString(), placeError});
         }

      }, server);
   }

   private static void placeBot(MinecraftServer server, ServerLevel worldIn, GameProfile current, Vec3 pos, double yaw, double pitch, ResourceKey<Level> dimensionId, GameType gamemode, boolean flying) {
      current = applyPendingSkin(current);
      BotPlayer instance = new BotPlayer(server, worldIn, current, ClientInformation.createDefault(), false);
      instance.fixStartingPosition = () -> instance.snapTo(pos.x, pos.y, pos.z, (float)yaw, (float)pitch);
      LuckPermsCompat.preloadUser(current.id(), current.name());
      instance.botJoining = true;

      try {
         server.getPlayerList().placeNewPlayer(new BotClientConnection(PacketFlow.SERVERBOUND), instance, CommonListenerCookie.createInitial(current, false));
      } catch (Throwable joinError) {
         VexBot.LOGGER.warn("[VexBot] A mod's player-join handler errored while spawning bot '{}' — keeping the bot alive.", current.name(), joinError);
      } finally {
         instance.botJoining = false;
      }

      loadPlayerData(instance);
      instance.stopRiding();

      assert worldIn != null;

      instance.teleportTo(worldIn, pos.x, pos.y, pos.z, Set.of(), (float)yaw, (float)pitch, true);
      instance.setHealth(20.0F);
      instance.unsetRemoved();
      ((AttributeInstance)Objects.requireNonNull(instance.getAttribute(Attributes.STEP_HEIGHT))).setBaseValue((double)0.6F);
      instance.gameMode.changeGameModeForPlayer(gamemode);
      instance.spawnPos = pos;
      instance.spawnDimension = dimensionId;
      instance.setRespawnPosition(new ServerPlayer.RespawnConfig(RespawnData.of(dimensionId, BlockPos.containing(pos), (float)yaw, (float)pitch), true), false);
      instance.ping = 0;
      instance.spawnYaw = yaw;
      server.getPlayerList().broadcastAll(new ClientboundRotateHeadPacket(instance, (byte)((int)(instance.yHeadRot * 256.0F / 360.0F))), dimensionId);
      server.getPlayerList().broadcastAll(ClientboundEntityPositionSyncPacket.of(instance), dimensionId);
      instance.entityData.set(DATA_PLAYER_MODE_CUSTOMISATION, (byte)127);
      instance.getAbilities().flying = flying;
   }

   private static CompletableFuture<GameProfile> fetchGameProfile(MinecraftServer server, UUID name) {
      if (name.version() == 3) {
         return CompletableFuture.completedFuture((Object)null);
      } else {
         GameProfile known = (GameProfile)SKINS.get(name);
         if (known != null) {
            return CompletableFuture.completedFuture(known);
         } else {
            ResolvableProfile resolvableProfile = ResolvableProfile.createUnresolved(name);
            return resolvableProfile.resolveProfile(server.services().profileResolver()).thenApply((p) -> {
               if (p != null && !p.name().isEmpty() && !p.properties().isEmpty() && SKINS.size() < 5000) {
                  SKINS.put(name, p);
               }

               return p;
            });
         }
      }
   }

   private static UUID botOnlyUuid(String username) {
      return UUID.nameUUIDFromBytes(("VexBotBot:" + username.toLowerCase(Locale.ROOT)).getBytes(StandardCharsets.UTF_8));
   }

   private static boolean hasNonBotPlayerData(MinecraftServer server, UUID uuid, String username) {
      try {
         return (Boolean)server.getPlayerList().loadPlayerData(new NameAndId(uuid, username)).map((tag) -> !tag.contains("botPlayerPing")).orElse(false);
      } catch (Throwable var4) {
         return false;
      }
   }

   private static void loadPlayerData(BotPlayer player) {
      player.level().getServer().getPlayerList().loadPlayerData(player.nameAndId()).map((tag) -> TagValueInput.create(ProblemReporter.DISCARDING, player.registryAccess(), tag)).ifPresent((valueInput) -> {
         player.load(valueInput);
         player.loadAndSpawnEnderPearls(valueInput);
         player.loadAndSpawnParentVehicle(valueInput);
      });
   }

   public void copycat(ServerPlayer otherPlayer) {
      BotPlayerActionPack srcPack = Internals.get().actionPack(otherPlayer);
      if (srcPack != null) {
         BotPlayerActionPack dstPack = Internals.get().actionPack(this);
         if (dstPack != null) {
            dstPack.copyFrom(srcPack);
            this.getInventory().clearContent();

            for(int i = 0; i < otherPlayer.getInventory().getContainerSize(); ++i) {
               this.getInventory().setItem(i, otherPlayer.getInventory().getItem(i).copy());
            }

            this.inventoryMenu.sendAllDataToRemote();
         }
      }
   }

   public static BotPlayer respawnFake(MinecraftServer server, ServerLevel level, GameProfile profile, ClientInformation cli) {
      return new BotPlayer(server, level, profile, cli, false);
   }

   public static boolean isSpawningPlayer(String username) {
      return spawning.contains(username);
   }

   private BotPlayer(MinecraftServer server, ServerLevel worldIn, GameProfile profile, ClientInformation cli, boolean shadow) {
      super(server, worldIn, profile, cli);
      this.isAShadow = shadow;
   }

   public void toggleSkinPart(byte mask) {
      byte current = (Byte)this.entityData.get(DATA_PLAYER_MODE_CUSTOMISATION);
      this.entityData.set(DATA_PLAYER_MODE_CUSTOMISATION, (byte)(current ^ mask));
   }

   public boolean isSkinPartEnabled(byte mask) {
      return ((Byte)this.entityData.get(DATA_PLAYER_MODE_CUSTOMISATION) & mask) != 0;
   }

   public CompletableFuture<Boolean> forceLoadSkin() {
      return this.forceLoadSkin(this.getUUID());
   }

   public CompletableFuture<Boolean> forceLoadSkin(String name) {
      MinecraftServer server = this.level().getServer();
      return CompletableFuture.supplyAsync(() -> {
         server.services().nameToIdCache().resolveOfflineUsers(false);
         UUID uuid = OldUsersConverter.convertMobOwnerIfNecessary(server, name);
         if (uuid == null) {
            server.services().nameToIdCache().resolveOfflineUsers(server.isDedicatedServer() && server.usesAuthentication());
            uuid = UUIDUtil.createOfflinePlayerUUID(name);
         }

         return uuid;
      }).thenCompose((uuid) -> uuid == null ? CompletableFuture.completedFuture(false) : this.forceLoadSkin(uuid));
   }

   public CompletableFuture<Boolean> forceLoadSkin(UUID skinUUID) {
      MinecraftServer server = this.level().getServer();
      String uuidStr = skinUUID.toString().replace("-", "");
      return CompletableFuture.supplyAsync(() -> {
         try {
            HttpURLConnection connection = (HttpURLConnection)URI.create("https://sessionserver.mojang.com/session/minecraft/profile/" + uuidStr + "?unsigned=false").toURL().openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            if (connection.getResponseCode() != 200) {
               return null;
            } else {
               InputStreamReader reader = new InputStreamReader(connection.getInputStream());

               JsonObject var3;
               try {
                  var3 = JsonParser.parseReader(reader).getAsJsonObject();
               } catch (Throwable var6) {
                  try {
                     reader.close();
                  } catch (Throwable var5) {
                     var6.addSuppressed(var5);
                  }

                  throw var6;
               }

               reader.close();
               return var3;
            }
         } catch (Exception var7) {
            return null;
         }
      }).thenApplyAsync((json) -> {
         if (json == null) {
            return false;
         } else {
            ImmutableMultimap.Builder<String, Property> builder = ImmutableMultimap.builder();
            JsonArray properties = json.getAsJsonArray("properties");
            if (properties != null) {
               for(JsonElement element : properties) {
                  JsonObject prop = element.getAsJsonObject();
                  String propName = prop.get("name").getAsString();
                  String value = prop.get("value").getAsString();
                  String signature = prop.has("signature") ? prop.get("signature").getAsString() : null;
                  builder.put(propName, new Property(propName, value, signature));
               }
            }

            String botName = this.getGameProfile().name();
            GameProfile newProfile = new GameProfile(this.getUUID(), botName, new PropertyMap(builder.build()));
            Internals.get().setGameProfile(this, newProfile);
            PlayerList playerList = server.getPlayerList();
            playerList.broadcastAll(new ClientboundPlayerInfoRemovePacket(List.of(this.getUUID())));
            playerList.broadcastAll(ClientboundPlayerInfoUpdatePacket.createPlayerInitializing(List.of(this)));
            ServerLevel level = this.level();
            level.getChunkSource().removeEntity(this);
            level.getChunkSource().addEntity(this);
            return true;
         }
      }, server);
   }

   public void setMainHand(HumanoidArm arm) {
      this.entityData.set(DATA_PLAYER_MAIN_HAND, arm);
   }

   public @NonNull Vec3 getLastClientMoveIntent() {
      BotPlayerActionPack ap = Internals.get().actionPack(this);
      float forward = ap.getForward();
      float strafing = ap.getStrafing();
      if (forward == 0.0F && strafing == 0.0F) {
         return Vec3.ZERO;
      } else {
         float yawRad = this.getYRot() * ((float)Math.PI / 180F);
         double sin = Math.sin((double)yawRad);
         double cos = Math.cos((double)yawRad);
         return new Vec3((double)strafing * cos - (double)forward * sin, (double)0.0F, (double)forward * cos + (double)strafing * sin);
      }
   }

   public void move(@NonNull MoverType moverType, @NonNull Vec3 vec3) {
      double oldX = this.getX();
      double oldZ = this.getZ();
      super.move(moverType, vec3);
      float movedX = (float)(this.getX() - oldX);
      float movedZ = (float)(this.getZ() - oldZ);
      Internals.get().actionPack(this).updateAutoJump(movedX, movedZ);
   }

   public void updatePlayerPose() {
      if (!this.isSleeping() && !this.isSpectator() && !this.isPassenger()) {
         Pose wanted = this.isSwimming() ? Pose.SWIMMING : (this.isFallFlying() ? Pose.FALL_FLYING : (this.isAutoSpinAttack() ? Pose.SPIN_ATTACK : (this.isShiftKeyDown() && !this.getAbilities().flying ? Pose.CROUCHING : Pose.STANDING)));
         if (this.canPlayerFitWithinBlocksAndEntitiesWhen(wanted)) {
            this.setPose(wanted);
         } else if (this.canPlayerFitWithinBlocksAndEntitiesWhen(Pose.SWIMMING)) {
            this.setPose(this.canPlayerFitWithinBlocksAndEntitiesWhen(Pose.CROUCHING) ? Pose.CROUCHING : Pose.SWIMMING);
         }

      } else {
         super.updatePlayerPose();
      }
   }

   protected boolean canPlayerFitWithinBlocksAndEntitiesWhen(@NonNull Pose pose) {
      if (BotCollisionSweep.ENABLED) {
         AABB box = this.getDimensions(pose).makeBoundingBox(this.position()).deflate(1.0E-7);
         ServerLevel level = this.level();
         int sweep = BotCollisionSweep.sweep(level, this, box, false);
         if (sweep != 2) {
            return sweep == 0 && level.noEntityCollision(this, box) && level.noBorderCollision(this, box);
         }
      }

      return super.canPlayerFitWithinBlocksAndEntitiesWhen(pose);
   }

   protected void checkSupportingBlock(boolean onGround, Vec3 movement) {
      if (onGround && BotCollisionSweep.ENABLED) {
         AABB box = this.getBoundingBox();
         AABB feet = new AABB(box.minX, box.minY - 1.0E-6, box.minZ, box.maxX, box.minY, box.maxZ);
         Optional<BlockPos> support = BotCollisionSweep.supportingBlock(this.level(), this, feet);
         if (support == null) {
            super.checkSupportingBlock(true, movement);
         } else {
            Internals internals = Internals.get();
            if (!support.isPresent() && !internals.onGroundNoBlocks(this)) {
               if (movement != null) {
                  AABB moved = feet.move(-movement.x, (double)0.0F, -movement.z);
                  support = BotCollisionSweep.supportingBlock(this.level(), this, moved);
                  if (support == null) {
                     support = this.level().findSupportingBlock(this, moved);
                  }

                  this.mainSupportingBlockPos = support;
               }
            } else {
               this.mainSupportingBlockPos = support;
            }

            internals.setOnGroundNoBlocks(this, support.isEmpty());
         }
      } else {
         super.checkSupportingBlock(onGround, movement);
      }
   }

   public boolean isInWall() {
      if (!BotCollisionSweep.ENABLED) {
         return super.isInWall();
      } else if (!this.isSleeping() && !this.noPhysics) {
         float width = this.getBbWidth() * 0.8F;
         AABB eyes = AABB.ofSize(this.getEyePosition(), (double)width, 1.0E-6, (double)width);
         int minX = Mth.floor(eyes.minX);
         int minY = Mth.floor(eyes.minY);
         int minZ = Mth.floor(eyes.minZ);
         int maxX = Mth.floor(eyes.maxX);
         int maxY = Mth.floor(eyes.maxY);
         int maxZ = Mth.floor(eyes.maxZ);
         BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

         for(int z = minZ; z <= maxZ; ++z) {
            for(int y = minY; y <= maxY; ++y) {
               for(int x = minX; x <= maxX; ++x) {
                  pos.set(x, y, z);
                  BlockState state = this.level().getBlockState(pos);
                  if (!state.isAir() && state.isSuffocating(this.level(), pos) && Shapes.joinIsNotEmpty(state.getCollisionShape(this.level(), pos).move(pos), Shapes.create(eyes), BooleanOp.AND)) {
                     return true;
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public @NonNull Iterable<Entity> getIndirectPassengers() {
      return (Iterable<Entity>)(this.getPassengers().isEmpty() ? Collections.emptyList() : super.getIndirectPassengers());
   }

   public void onEquipItem(@NonNull EquipmentSlot slot, @NonNull ItemStack previous, @NonNull ItemStack stack) {
      if (!this.isUsingItem()) {
         super.onEquipItem(slot, previous, stack);
      }

   }

   public void kill(@NonNull ServerLevel level) {
      this.kill((Component)VexText.literal("Killed"));
   }

   public void attack(@NonNull Entity target) {
      if (target instanceof LivingEntity) {
         MeleeWeaponGuard.ensureWeapon(this);
      }

      if (!(target instanceof LivingEntity) || !this.getMainHandItem().has(DataComponents.FOOD) && !this.getMainHandItem().is(Items.POTION)) {
         super.attack(target);
      }
   }

   public void botPlayerDisconnect(Component reason) {
      this.level().getServer().schedule(new TickTask(this.level().getServer().getTickCount(), () -> this.connection.onDisconnect(new DisconnectionDetails(reason))));
   }

   public void kill(Component reason) {
      this.shakeOff();
      ComponentContents var3 = reason.getContents();
      if (var3 instanceof TranslatableContents text) {
         if (text.getKey().equals("multiplayer.disconnect.duplicate_login")) {
            this.connection.onDisconnect(new DisconnectionDetails(reason));
            return;
         }
      }

      this.hurtServer(this.level(), this.level().damageSources().fellOutOfWorld(), Float.MAX_VALUE);
   }

   public void startUsingItem(@NonNull InteractionHand hand) {
      ItemStack stack = this.getItemInHand(hand);
      if (!stack.has(DataComponents.BLOCKS_ATTACKS) || !this.getCooldowns().isOnCooldown(stack)) {
         super.startUsingItem(hand);
      }
   }

   public void tick() {
      if (this.level().getServer().getTickCount() % 10 == Math.floorMod(this.getId(), 10)) {
         this.connection.resetPosition();
         this.level().getChunkSource().move(this);
      }

      this.containerMenu.suppressRemoteUpdates();
      if (this.isUsingItem()) {
         ItemStack use = this.getUseItem();
         if (use.has(DataComponents.BLOCKS_ATTACKS) && this.getCooldowns().isOnCooldown(use)) {
            this.stopUsingItem();
         }
      }

      try {
         double startX = this.getX();
         double startY = this.getY();
         double startZ = this.getZ();
         super.tick();
         if (!this.noPhysics && this.cornerColumnsSuffocate()) {
            this.moveTowardsClosestSpace(this.getX() - (double)this.getBbWidth() * 0.35, this.getZ() + (double)this.getBbWidth() * 0.35);
            this.moveTowardsClosestSpace(this.getX() - (double)this.getBbWidth() * 0.35, this.getZ() - (double)this.getBbWidth() * 0.35);
            this.moveTowardsClosestSpace(this.getX() + (double)this.getBbWidth() * 0.35, this.getZ() - (double)this.getBbWidth() * 0.35);
            this.moveTowardsClosestSpace(this.getX() + (double)this.getBbWidth() * 0.35, this.getZ() + (double)this.getBbWidth() * 0.35);
         }

         this.doTick();
         this.processPendingKBs();
         if (this.pathFollower != null) {
            this.pathFollower.tick();
            if (this.pathFollower.isDone()) {
               this.pathFollower = null;
            }
         }

         Vec3 movement = new Vec3(this.getX() - startX, this.getY() - startY, this.getZ() - startZ);
         this.setKnownMovement(movement);
         if (movement.lengthSqr() > (double)1.0E-5F) {
            this.resetLastActionTime();
         }
      } catch (NullPointerException var8) {
      }

   }

   private void moveTowardsClosestSpace(double x, double z) {
      BlockPos pos = BlockPos.containing(x, this.getY(), z);
      if (this.suffocatesAt(pos)) {
         double xd = x - (double)pos.getX();
         double zd = z - (double)pos.getZ();
         Direction dir = null;
         double closest = Double.MAX_VALUE;

         for(Direction direction : new Direction[]{Direction.WEST, Direction.EAST, Direction.NORTH, Direction.SOUTH}) {
            double axisDistance = direction.getAxis().choose(xd, (double)0.0F, zd);
            double distanceToEdge = direction.getAxisDirection() == AxisDirection.POSITIVE ? (double)1.0F - axisDistance : axisDistance;
            if (distanceToEdge < closest && !this.suffocatesAt(pos.relative(direction))) {
               closest = distanceToEdge;
               dir = direction;
            }
         }

         if (dir != null) {
            Vec3 oldMovement = this.getDeltaMovement();
            if (dir.getAxis() == Axis.X) {
               this.setDeltaMovement(0.1 * (double)dir.getStepX(), oldMovement.y, oldMovement.z);
            } else {
               this.setDeltaMovement(oldMovement.x, oldMovement.y, 0.1 * (double)dir.getStepZ());
            }
         }
      }

   }

   private boolean cornerColumnsSuffocate() {
      double r = (double)this.getBbWidth() * 0.35;
      AABB boundingBox = this.getBoundingBox();
      AABB area = (new AABB((double)Mth.floor(this.getX() - r), boundingBox.minY, (double)Mth.floor(this.getZ() - r), (double)Mth.floor(this.getX() + r) + (double)1.0F, boundingBox.maxY, (double)Mth.floor(this.getZ() + r) + (double)1.0F)).deflate(1.0E-7);
      if (BotCollisionSweep.ENABLED) {
         int sweep = BotCollisionSweep.sweep(this.level(), this, area, true);
         if (sweep != 2) {
            return sweep == 1;
         }
      }

      return this.level().collidesWithSuffocatingBlock(this, area);
   }

   protected void onAttributeUpdated(Holder<Attribute> attribute) {
      super.onAttributeUpdated(attribute);
      if (attribute.is(Attributes.WAYPOINT_RECEIVE_RANGE) && this.isTransmittingWaypoint() && this.getAttributes().getValue(Attributes.WAYPOINT_RECEIVE_RANGE) <= (double)0.0F) {
         this.level().getWaypointManager().trackWaypoint(this);
      }

   }

   private boolean suffocatesAt(BlockPos pos) {
      AABB boundingBox = this.getBoundingBox();
      AABB testArea = (new AABB((double)pos.getX(), boundingBox.minY, (double)pos.getZ(), (double)pos.getX() + (double)1.0F, boundingBox.maxY, (double)pos.getZ() + (double)1.0F)).deflate(1.0E-7);
      return this.level().collidesWithSuffocatingBlock(this, testArea);
   }

   private void processPendingKBs() {
      long currentTick = (long)this.level().getServer().getTickCount();
      if (!this.pendingKnockbacks.isEmpty()) {
         this.pendingKnockbacks.removeIf((kb) -> {
            if (currentTick >= kb.tick()) {
               this.applyKnockbackWithScale(kb.strength(), kb.x(), kb.z(), kb.horizontalScale());
               return true;
            } else {
               return false;
            }
         });
      }

      if (!this.pendingExplosionKB.isEmpty()) {
         this.pendingExplosionKB.removeIf((dp) -> {
            if (currentTick >= dp.tick()) {
               super.push(dp.explosionKB());
               return true;
            } else {
               return false;
            }
         });
      }

   }

   public void delayedExplosionKB(Vec3 vec3) {
      int delayTicks = this.delayTicks(2);
      if (delayTicks <= 0) {
         super.push(vec3);
      } else {
         long executeAt = (long)(this.level().getServer().getTickCount() + delayTicks);
         this.pendingExplosionKB.add(new DelayedExplosionKB(executeAt, vec3));
      }

   }

   protected void markHurt() {
   }

   protected void vexKnockback(double strength, double x, double z) {
      if (!this.getAbilities().invulnerable) {
         this.superKnockback(strength, x, z);
         if (this.pathFollower != null && !this.pathFollower.isDone()) {
            this.pathFollower.recalcPath();
         }

      }
   }

   private void scaledKnockback(double strength, double x, double z, double horizontalScale) {
      int delayTicks = this.delayTicks(2);
      if (delayTicks <= 0) {
         this.applyKnockbackWithScale(strength, x, z, horizontalScale);
      } else {
         long executeAt = (long)(this.level().getServer().getTickCount() + delayTicks);
         this.pendingKnockbacks.add(new DelayedKnockback(executeAt, strength, x, z, horizontalScale));
      }

      if (this.pathFollower != null && !this.pathFollower.isDone()) {
         this.pathFollower.recalcPath();
      }

   }

   private void applyKnockbackWithScale(double strength, double x, double z, double horizontalScale) {
      if (horizontalScale >= (double)1.0F) {
         this.superKnockback(strength, x, z);
      } else {
         double d = strength * ((double)1.0F - this.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
         if (!(d <= (double)0.0F)) {
            for(this.needsSync = true; x * x + z * z < (double)1.0E-5F; z = (this.random.nextDouble() - this.random.nextDouble()) * 0.01) {
               x = (this.random.nextDouble() - this.random.nextDouble()) * 0.01;
            }

            Vec3 dir = (new Vec3(x, (double)0.0F, z)).normalize().scale(d * horizontalScale);
            Vec3 vel = this.getDeltaMovement();
            this.setDeltaMovement(vel.x / (double)2.0F - dir.x, this.onGround() ? Math.min(0.4, vel.y / (double)2.0F + d) : vel.y, vel.z / (double)2.0F - dir.z);
         }
      }
   }

   public int delayTicks(int p2tMultiplier) {
      int pingToTicks = 25;
      int remainder = this.ping % (pingToTicks * p2tMultiplier);
      if (remainder == 0) {
         return this.ping / pingToTicks;
      } else {
         int random = ThreadLocalRandom.current().nextInt(pingToTicks);
         return random < remainder ? this.ping / pingToTicks + 1 : this.ping / pingToTicks;
      }
   }

   public boolean hurtServer(@NonNull ServerLevel serverLevel, @NonNull DamageSource damageSource, float finalDamage) {
      if ((this.gameMode.getGameModeForPlayer() == GameType.CREATIVE || this.gameMode.getGameModeForPlayer() == GameType.SPECTATOR) && damageSource != this.level().damageSources().fellOutOfWorld()) {
         return false;
      } else if (damageSource.getDirectEntity() instanceof ThrowableItemProjectile && !(damageSource.getDirectEntity() instanceof AbstractThrownPotion)) {
         return false;
      } else if (!this.isInvulnerableTo(serverLevel, damageSource)) {
         if (this.isDeadOrDying()) {
            return false;
         } else if (damageSource.is(DamageTypeTags.IS_FIRE) && this.hasEffect(MobEffects.FIRE_RESISTANCE)) {
            return false;
         } else if (damageSource.is(DamageTypeTags.IS_EXPLOSION)) {
            float hpBefore = this.statsHpBefore(damageSource);
            boolean hurt = super.hurtServer(serverLevel, damageSource, finalDamage);
            if (!"Fabric".equals(Platform.get().loaderName())) {
               this.statsDamageDealt(hpBefore);
            }

            return hurt;
         } else {
            if (this.isSleeping()) {
               this.stopSleeping();
            }

            float hpBefore = this.statsHpBefore(damageSource);
            boolean hurt = this.vexHurtServer(serverLevel, damageSource, finalDamage);
            this.statsDamageDealt(hpBefore);
            if (this.pathFollower != null) {
               this.pathFollower.requestRecalc();
            }

            return hurt;
         }
      } else {
         if (DEBUG_HURT) {
            VexBot.LOGGER.info("[VexBot-hurt] {} refused {}: changingDimension={} clientLoaded={} creativeOrSpectator={} invulnerableFlag={}", new Object[]{this.getScoreboardName(), damageSource.getMsgId(), this.isChangingDimension(), this.connection.hasClientLoaded(), this.isCreative() || this.isSpectator(), this.isInvulnerable()});
         }

         return false;
      }
   }

   private float statsHpBefore(DamageSource damageSource) {
      if (!Stats.enabled()) {
         return -1.0F;
      } else {
         return damageSource.getEntity() instanceof BotPlayer && damageSource.getEntity() != this ? this.getHealth() + this.getAbsorptionAmount() : -1.0F;
      }
   }

   private void statsDamageDealt(float hpBefore) {
      if (!(hpBefore < 0.0F)) {
         float lost = hpBefore - this.getHealth() - this.getAbsorptionAmount();
         if (lost > 0.0F) {
            Stats.add("damage_dealt", (long)Math.round(lost));
         }

      }
   }

   private void shakeOff() {
      if (this.getVehicle() instanceof Player) {
         this.stopRiding();
      }

      for(Entity passenger : this.getIndirectPassengers()) {
         if (passenger instanceof Player) {
            passenger.stopRiding();
         }
      }

   }

   public void die(@NonNull DamageSource cause) {
      if (!cause.is(DamageTypes.FELL_OUT_OF_WORLD)) {
      }

      this.shakeOff();
      super.die(cause);
      MinecraftServer server = (MinecraftServer)Objects.requireNonNull(this.level().getServer());
      String name = NickManager.realName(this);
      if ((new EffectiveSettings(name)).botLeaveOnDeath()) {
         BotManager.releaseTrackedBot(server, name);
         server.schedule(new TickTask(server.getTickCount() + 1, () -> {
            try {
               server.getPlayerList().broadcastSystemMessage(Component.translatable("multiplayer.player.left", new Object[]{this.getDisplayName()}).withStyle(ChatFormatting.YELLOW), false);
               server.getPlayerList().remove(this);
            } catch (Throwable t) {
               VexBot.LOGGER.warn("[VexBot] Error removing dead bot '{}': {}", name, t.getMessage());
            }

         }));
      } else {
         server.schedule(new TickTask(server.getTickCount() + 1, () -> {
            try {
               this.reviveInPlace();
            } catch (Throwable t) {
               VexBot.LOGGER.warn("[VexBot] Could not revive bot '{}': {}", this.getGameProfile().name(), t.getMessage());
            }

         }));
      }
   }

   private void reviveInPlace() {
      this.setHealth(this.getMaxHealth());
      this.foodData = new FoodData();
      this.setExperienceLevels(0);
      this.setExperiencePoints(0);
      this.removeAllEffects();
      this.setRemainingFireTicks(0);
      this.setAirSupply(this.getMaxAirSupply());
      this.setAbsorptionAmount(0.0F);
      this.deathTime = 0;
      this.hurtTime = 0;
      this.hurtDuration = 0;
      if (this.isRemoved()) {
         this.unsetRemoved();
      }

      this.stopRiding();
      ServerLevel spawnLevel = this.level();
      ServerLevel level = spawnLevel instanceof ServerLevel ? spawnLevel : null;
      if (level != null) {
         MinecraftServer server = level.getServer();
         if (this.spawnPos != null && this.spawnDimension != null) {
            spawnLevel = server.getLevel(this.spawnDimension);
            if (spawnLevel != null) {
               level = spawnLevel;
            }
         }

         Vec3 where = this.respawnOrWorldSpawn(level);
         this.teleportTo(level, where.x, where.y, where.z, Set.of(), this.getYRot(), this.getXRot(), true);
         server.getPlayerList().broadcastAll(ClientboundEntityPositionSyncPacket.of(this), level.dimension());
         if (this.pathFollower != null) {
            this.pathFollower.requestRecalc();
         }

         VexBot.LOGGER.info("[VexBot] '{}' respawned in place (botleaveondeath off).", this.getGameProfile().name());
      }
   }

   private Vec3 respawnOrWorldSpawn(ServerLevel level) {
      return this.spawnPos != null ? this.spawnPos : this.position();
   }

   public @NonNull String getIpAddress() {
      return "127.0.0.1";
   }

   public boolean allowsListing() {
      return true;
   }

   public boolean isInvulnerableTo(@NonNull ServerLevel serverLevel, @NonNull DamageSource damageSource) {
      return super.isInvulnerableTo(serverLevel, damageSource) || this.isChangingDimension() && !damageSource.is(DamageTypes.ENDER_PEARL);
   }

   public void showEndCredits() {
      this.seenCredits = true;
   }

   public ServerPlayer teleport(@NonNull TeleportTransition serverLevel) {
      super.teleport(serverLevel);
      if (this.wonGame) {
         ServerboundClientCommandPacket p = new ServerboundClientCommandPacket(Action.PERFORM_RESPAWN);
         this.connection.handleClientCommand(p);
      }

      if (this.connection.player.isChangingDimension()) {
         this.connection.player.hasChangedDimension();
      }

      return this.connection.player;
   }

   public void addAdditionalSaveData(@NonNull ValueOutput output) {
      super.addAdditionalSaveData(output);
      output.putInt("botPlayerPing", this.ping);
   }

   public void readAdditionalSaveData(@NonNull ValueInput input) {
      super.readAdditionalSaveData(input);
      this.ping = input.getIntOr("botPlayerPing", 0);
   }

   protected void vexBlockUsingItem(ServerLevel serverLevel, LivingEntity livingEntity) {
      ItemStack itemStack = this.getItemBlockingWith();
      BlocksAttacks blocksAttacks = itemStack != null ? (BlocksAttacks)itemStack.get(DataComponents.BLOCKS_ATTACKS) : null;
      float f = livingEntity.getSecondsToDisableBlocking();
      if (f > 0.0F && blocksAttacks != null) {
         Internals.get().disableBlocking(blocksAttacks, serverLevel, this, f, itemStack, livingEntity);
         this.shieldDisabledTick = (long)serverLevel.getServer().getTickCount();
      }

   }

   private static record DelayedKnockback(long tick, double strength, double x, double z, double horizontalScale) {
   }

   private static record DelayedExplosionKB(long tick, Vec3 explosionKB) {
   }
}
