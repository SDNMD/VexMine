package vexbot.fakeplayer.bot;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import vexbot.platform.Internals;
import vexbot.platform.Platform;

final class BotCollisionSweep {
   static final int CLEAR = 0;
   static final int HIT = 1;
   static final int UNKNOWN = 2;
   static final boolean ENABLED = Platform.isInstalled() && "Fabric".equals(Platform.get().loaderName()) && !Platform.get().isModLoaded("moonrise");
   private static final Predicate<BlockState> RING_STATE = (state) -> state.hasLargeCollisionShape() || state.is(Blocks.MOVING_PISTON);
   private final ServerLevel level;
   private final Entity entity;
   private final AABB box;
   private final boolean suffocatingOnly;
   private final boolean support;
   private BlockPos supportPos;
   private double supportDistance = Double.MAX_VALUE;
   private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
   private int minX;
   private int maxX;
   private int minY;
   private int maxY;
   private int minZ;
   private int maxZ;
   private int cx0;
   private int cz0;
   private int sy0;
   private LevelChunk c0;
   private LevelChunk c1;
   private LevelChunk c2;
   private LevelChunk c3;
   private int ring;
   private CollisionContext context;
   private VoxelShape boxShape;

   private BotCollisionSweep(ServerLevel level, Entity entity, AABB box, boolean suffocatingOnly, boolean support) {
      this.level = level;
      this.entity = entity;
      this.box = box;
      this.suffocatingOnly = suffocatingOnly;
      this.support = support;
   }

   static int sweep(ServerLevel level, Entity entity, AABB box, boolean suffocatingOnly) {
      BotCollisionSweep sweep = new BotCollisionSweep(level, entity, box, suffocatingOnly, false);
      if (!sweep.open()) {
         return 2;
      } else {
         return sweep.walk() ? 1 : 0;
      }
   }

   static Optional<BlockPos> supportingBlock(ServerLevel level, Entity entity, AABB box) {
      BotCollisionSweep sweep = new BotCollisionSweep(level, entity, box, false, true);
      if (!sweep.open()) {
         return null;
      } else {
         sweep.walk();
         return Optional.ofNullable(sweep.supportPos);
      }
   }

   private boolean open() {
      if (this.level.isDebug()) {
         return false;
      } else {
         this.minX = Mth.floor(this.box.minX - 1.0E-7) - 1;
         this.maxX = Mth.floor(this.box.maxX + 1.0E-7) + 1;
         this.minY = Mth.floor(this.box.minY - 1.0E-7) - 1;
         this.maxY = Mth.floor(this.box.maxY + 1.0E-7) + 1;
         this.minZ = Mth.floor(this.box.minZ - 1.0E-7) - 1;
         this.maxZ = Mth.floor(this.box.maxZ + 1.0E-7) + 1;
         this.cx0 = this.minX >> 4;
         this.cz0 = this.minZ >> 4;
         this.sy0 = this.minY >> 4;
         int cx1 = this.maxX >> 4;
         int cz1 = this.maxZ >> 4;
         int sy1 = this.maxY >> 4;
         if (cx1 - this.cx0 <= 1 && cz1 - this.cz0 <= 1 && sy1 - this.sy0 <= 7) {
            Internals internals = Internals.get();
            if ((this.c0 = internals.fullChunkNow(this.level, this.cx0, this.cz0)) == null) {
               return false;
            } else {
               this.c1 = this.c2 = this.c3 = this.c0;
               if (cx1 != this.cx0 && (this.c1 = internals.fullChunkNow(this.level, cx1, this.cz0)) == null) {
                  return false;
               } else if (cz1 != this.cz0 && (this.c2 = internals.fullChunkNow(this.level, this.cx0, cz1)) == null) {
                  return false;
               } else if (cx1 != this.cx0 && cz1 != this.cz0 && (this.c3 = internals.fullChunkNow(this.level, cx1, cz1)) == null) {
                  return false;
               } else {
                  this.ring = this.ringSections(this.c0, sy1);
                  if (cx1 != this.cx0) {
                     this.ring |= this.ringSections(this.c1, sy1) << 8;
                  }

                  if (cz1 != this.cz0) {
                     this.ring |= this.ringSections(this.c2, sy1) << 16;
                  }

                  if (cx1 != this.cx0 && cz1 != this.cz0) {
                     this.ring |= this.ringSections(this.c3, sy1) << 24;
                  }

                  return true;
               }
            }
         } else {
            return false;
         }
      }
   }

   private int ringSections(LevelChunk chunk, int sy1) {
      LevelChunkSection[] sections = chunk.getSections();
      int bits = 0;

      for(int sy = this.sy0; sy <= sy1; ++sy) {
         int index = chunk.getSectionIndex(sy << 4);
         if (index >= 0 && index < sections.length) {
            LevelChunkSection section = sections[index];
            if (!section.hasOnlyAir() && section.maybeHas(RING_STATE)) {
               bits |= 1 << sy - this.sy0;
            }
         }
      }

      return bits;
   }

   private boolean walk() {
      BlockGetter getter = null;
      int getterColumn = -1;

      for(int z = this.minZ; z <= this.maxZ; ++z) {
         int zEdge = z != this.minZ && z != this.maxZ ? 0 : 1;
         int zColumn = z >> 4 != this.cz0 ? 2 : 0;

         for(int y = this.minY; y <= this.maxY; ++y) {
            int yzEdge = zEdge + (y != this.minY && y != this.maxY ? 0 : 1);
            int section = (y >> 4) - this.sy0;

            for(int x = this.minX; x <= this.maxX; ++x) {
               int type = yzEdge + (x != this.minX && x != this.maxX ? 0 : 1);
               if (type != 3) {
                  int column = zColumn + (x >> 4 != this.cx0 ? 1 : 0);
                  if (getter == null || column != getterColumn) {
                     getter = this.level.getChunkForCollisions(x >> 4, z >> 4);
                     getterColumn = column;
                     if (getter == null) {
                        continue;
                     }
                  }

                  LevelChunk chunk = column == 0 ? this.c0 : (column == 1 ? this.c1 : (column == 2 ? this.c2 : this.c3));
                  if (type == 0 || getter != chunk || (this.ring & 1 << column * 8 + section) != 0) {
                     this.pos.set(x, y, z);
                     BlockState state = getter.getBlockState(this.pos);
                     if ((!this.suffocatingOnly || state.isSuffocating(getter, this.pos)) && (type != 1 || state.hasLargeCollisionShape()) && (type != 2 || state.is(Blocks.MOVING_PISTON)) && this.yields(state, x, y, z)) {
                        if (!this.support) {
                           return true;
                        }

                        double distance = this.pos.distToCenterSqr(this.entity.position());
                        if (distance < this.supportDistance || distance == this.supportDistance && (this.supportPos == null || this.supportPos.compareTo(this.pos) < 0)) {
                           this.supportPos = this.pos.immutable();
                           this.supportDistance = distance;
                        }
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   private boolean yields(BlockState state, int x, int y, int z) {
      if (this.context == null) {
         this.context = CollisionContext.of(this.entity);
      }

      VoxelShape shape = this.context.getCollisionShape(state, this.level, this.pos);
      if (shape == Shapes.block()) {
         return this.box.intersects((double)x, (double)y, (double)z, (double)x + (double)1.0F, (double)y + (double)1.0F, (double)z + (double)1.0F);
      } else {
         VoxelShape moved = shape.move(this.pos);
         if (moved.isEmpty()) {
            return false;
         } else {
            if (this.boxShape == null) {
               this.boxShape = Shapes.create(this.box);
            }

            return Shapes.joinIsNotEmpty(moved, this.boxShape, BooleanOp.AND);
         }
      }
   }
}
