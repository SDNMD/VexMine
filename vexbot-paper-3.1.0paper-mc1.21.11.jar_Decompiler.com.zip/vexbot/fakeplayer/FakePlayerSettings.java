package vexbot.fakeplayer;

import net.minecraft.world.entity.Entity;

public final class FakePlayerSettings {
   public static final boolean creativeNoClip = false;
   public static final double creativeFlySpeed = (double)1.0F;
   public static final double creativeFlyDrag = 0.09;
   public static final boolean allowSpawningOfflinePlayers = true;
   public static final boolean allowListingBotPlayers = true;
   public static final int botPingToTicks = 25;
   public static final boolean botLagAttacks = false;
   public static final boolean botLagUses = false;
   public static final boolean shieldStunning = false;
   public static final int shieldStunningWindow = 3;
   public static final int shieldDelayTicks = 5;
   public static final ExplosionNoDmgMode explosionNoBlockDamage;
   public static final boolean explosionNoFire = false;
   public static final boolean windChargeNoTrigger = false;
   public static final boolean editablePlayerNbt = false;
   public static final boolean clientsIgnoreSlowTickRate = false;
   public static final boolean xpNoCooldown = false;
   public static final boolean noProjectileRandom = false;
   public static final boolean deleteChunkEntities = false;
   public static final boolean rainThroughMovingPiston = false;
   public static final boolean shulkerBoxAlwaysDrops = false;
   public static final boolean disableExperimentalScreen = false;

   private FakePlayerSettings() {
   }

   public static boolean isCreativeNoClipFlying(Entity entity) {
      return false;
   }

   static {
      explosionNoBlockDamage = FakePlayerSettings.ExplosionNoDmgMode.FALSE;
   }

   public static enum ExplosionNoDmgMode {
      TRUE,
      FALSE,
      MOST;

      public boolean enabled() {
         return this != FALSE;
      }

      // $FF: synthetic method
      private static ExplosionNoDmgMode[] $values() {
         return new ExplosionNoDmgMode[]{TRUE, FALSE, MOST};
      }
   }
}
