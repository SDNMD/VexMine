package vexbot.fakeplayer.util;

import com.google.common.base.Supplier;
import net.minecraft.world.item.ItemStack;

public final class SlotCopyMemo implements Supplier<ItemStack> {
   private ItemStack source;
   private ItemStack copy;
   private boolean copied;

   public SlotCopyMemo reset(ItemStack source) {
      this.source = source;
      this.copy = null;
      this.copied = false;
      return this;
   }

   public ItemStack get() {
      if (!this.copied) {
         this.copy = this.source.copy();
         this.copied = true;
      }

      return this.copy;
   }
}
