package vexbot.i18n;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import java.io.Reader;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import vexbot.VexBot;

public final class VexLang {
   public static final String ENGLISH = "en";
   public static final Map<String, String> LANGUAGES;
   private static final ThreadLocal<String> CURRENT;
   private static final Map<UUID, String> PICKS;
   private static final String FILE = "vexbot_languages.json";

   private VexLang() {
   }

   public static String current() {
      String l = (String)CURRENT.get();
      return l == null ? "en" : l;
   }

   public static String of(ServerPlayer p) {
      if (p == null) {
         return "en";
      } else {
         String pick = (String)PICKS.get(p.getUUID());
         return pick != null ? pick : fromClient(clientLanguage(p));
      }
   }

   public static String of(Object to) {
      if (to instanceof ServerPlayer sp) {
         return of(sp);
      } else {
         if (to instanceof CommandSourceStack src) {
            Entity var3 = src.getEntity();
            if (var3 instanceof ServerPlayer sp) {
               return of(sp);
            }
         }

         return "en";
      }
   }

   public static String fromClient(String mc) {
      if (mc != null && !mc.isEmpty()) {
         String s = mc.toLowerCase(Locale.ROOT);
         String base = s.contains("_") ? s.substring(0, s.indexOf(95)) : s;
         return LANGUAGES.containsKey(base) ? base : "en";
      } else {
         return "en";
      }
   }

   private static String clientLanguage(ServerPlayer p) {
      try {
         return p.clientInformation().language();
      } catch (Throwable var2) {
         return null;
      }
   }

   public static <T> T call(Object to, Supplier<T> body) {
      String prev = (String)CURRENT.get();
      CURRENT.set(of(to));

      Object var3;
      try {
         var3 = body.get();
      } finally {
         if (prev == null) {
            CURRENT.remove();
         } else {
            CURRENT.set(prev);
         }

      }

      return (T)var3;
   }

   public static void run(Object to, Runnable body) {
      call(to, () -> {
         body.run();
         return null;
      });
   }

   public static void wrapCommands(CommandNode<CommandSourceStack> root) {
      try {
         Field f = CommandNode.class.getDeclaredField("command");
         f.setAccessible(true);
         wrap(root, f, Collections.newSetFromMap(new IdentityHashMap()));
      } catch (Throwable t) {
         VexBot.LOGGER.warn("[VexBot] Couldn't hook commands for translations, they stay in English: {}", t.toString());
      }

   }

   private static void wrap(CommandNode<CommandSourceStack> node, Field f, Set<Object> seen) throws IllegalAccessException {
      if (seen.add(node)) {
         Command<CommandSourceStack> cmd = node.getCommand();
         if (cmd != null && !(cmd instanceof Localized)) {
            f.set(node, new Localized(cmd));
         }

         for(CommandNode<CommandSourceStack> child : node.getChildren()) {
            wrap(child, f, seen);
         }

      }
   }

   public static void setPick(MinecraftServer server, ServerPlayer p, String code) {
      if (code != null && !code.equalsIgnoreCase("auto")) {
         PICKS.put(p.getUUID(), code.toLowerCase(Locale.ROOT));
      } else {
         PICKS.remove(p.getUUID());
      }

      save(server);
   }

   public static String pick(ServerPlayer p) {
      return p == null ? null : (String)PICKS.get(p.getUUID());
   }

   public static List<String> codes() {
      return List.copyOf(LANGUAGES.keySet());
   }

   private static Path file(MinecraftServer server) {
      return server.getServerDirectory().resolve("vexbot_languages.json");
   }

   public static void load(MinecraftServer server) {
      PICKS.clear();

      try {
         Path f = file(server);
         if (Files.exists(f, new LinkOption[0])) {
            Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8);

            label80: {
               try {
                  JsonObject o = (JsonObject)(new Gson()).fromJson(r, JsonObject.class);
                  if (o == null) {
                     break label80;
                  }

                  for(Map.Entry<String, JsonElement> e : o.entrySet()) {
                     try {
                        String code = ((JsonElement)e.getValue()).getAsString();
                        if (LANGUAGES.containsKey(code)) {
                           PICKS.put(UUID.fromString((String)e.getKey()), code);
                        }
                     } catch (Exception var8) {
                     }
                  }
               } catch (Throwable var9) {
                  if (r != null) {
                     try {
                        r.close();
                     } catch (Throwable var7) {
                        var9.addSuppressed(var7);
                     }
                  }

                  throw var9;
               }

               if (r != null) {
                  r.close();
               }

               return;
            }

            if (r != null) {
               r.close();
            }

         }
      } catch (Exception e) {
         VexBot.LOGGER.warn("[VexBot] Couldn't read {}: {}", "vexbot_languages.json", e.toString());
      }
   }

   private static void save(MinecraftServer server) {
      try {
         JsonObject o = new JsonObject();
         PICKS.forEach((k, v) -> o.addProperty(k.toString(), v));
         Files.writeString(file(server), (new Gson()).toJson(o), StandardCharsets.UTF_8);
      } catch (Exception e) {
         VexBot.LOGGER.warn("[VexBot] Couldn't save {}: {}", "vexbot_languages.json", e.toString());
      }

   }

   static {
      Map<String, String> m = new LinkedHashMap();
      m.put("en", "English");
      m.put("es", "Español");
      m.put("pt", "Português (Brasil)");
      m.put("fr", "Français");
      m.put("de", "Deutsch");
      m.put("ru", "Русский");
      m.put("zh", "简体中文");
      m.put("hi", "हिन्दी");
      LANGUAGES = Collections.unmodifiableMap(m);
      CURRENT = new ThreadLocal();
      PICKS = new ConcurrentHashMap();
   }

   private static record Localized(Command<CommandSourceStack> inner) implements Command<CommandSourceStack> {
      public int run(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
         String prev = (String)VexLang.CURRENT.get();
         VexLang.CURRENT.set(VexLang.of(ctx.getSource()));

         int var3;
         try {
            var3 = this.inner.run(ctx);
         } finally {
            if (prev == null) {
               VexLang.CURRENT.remove();
            } else {
               VexLang.CURRENT.set(prev);
            }

         }

         return var3;
      }
   }
}
