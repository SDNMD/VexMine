package vexbot.i18n;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import vexbot.VexBot;

public final class VexText {
   private static final Map<String, Catalog> CATALOGS = new ConcurrentHashMap();
   private static final Catalog NONE = new Catalog();

   private VexText() {
   }

   public static MutableComponent literal(String s) {
      return Component.literal(tr(s, VexLang.current()));
   }

   public static MutableComponent literal(Object to, String s) {
      return Component.literal(tr(s, VexLang.of(to)));
   }

   public static String tr(String s) {
      return tr(s, VexLang.current());
   }

   public static String tr(String s, String lang) {
      if (s != null && !s.isEmpty() && lang != null && !"en".equals(lang)) {
         Catalog c = (Catalog)CATALOGS.computeIfAbsent(lang, VexText::load);
         return c == NONE ? s : c.translate(s);
      } else {
         return s;
      }
   }

   private static Catalog load(String lang) {
      try {
         InputStream in = VexText.class.getResourceAsStream("/vexbot/lang/" + lang + ".json");

         Catalog var7;
         label48: {
            Catalog var3;
            try {
               if (in == null) {
                  var7 = NONE;
                  break label48;
               }

               JsonObject o = (JsonObject)(new Gson()).fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), JsonObject.class);
               var3 = new Catalog(o);
            } catch (Throwable var5) {
               if (in != null) {
                  try {
                     in.close();
                  } catch (Throwable var4) {
                     var5.addSuppressed(var4);
                  }
               }

               throw var5;
            }

            if (in != null) {
               in.close();
            }

            return var3;
         }

         if (in != null) {
            in.close();
         }

         return var7;
      } catch (Exception e) {
         VexBot.LOGGER.warn("[VexBot] Couldn't load the {} translations: {}", lang, e.toString());
         return NONE;
      }
   }

   private static final class Catalog {
      private static final int CACHE_MAX = 4096;
      private final Map<String, String> exact = new HashMap();
      private final Map<String, List<Tpl>> byHead = new HashMap();
      private final List<Tpl> headless = new ArrayList();
      private final List<String[]> fragments = new ArrayList();
      private final Map<String, String> cache = new ConcurrentHashMap();

      Catalog() {
      }

      Catalog(JsonObject o) {
         if (o.has("exact")) {
            for(Map.Entry<String, JsonElement> e : o.getAsJsonObject("exact").entrySet()) {
               String en = (String)e.getKey();
               String tr = ((JsonElement)e.getValue()).getAsString();
               if (!tr.isEmpty() && !tr.equals(en)) {
                  this.exact.put(en, tr);
                  String bare = en.replaceAll("§.", "").trim();
                  if (bare.indexOf(32) >= 0 && bare.length() >= 8) {
                     this.fragments.add(new String[]{en, tr});
                  }
               }
            }
         }

         this.fragments.sort(Comparator.comparingInt((f) -> f[0].length()).reversed());
         List<Tpl> all = new ArrayList();
         if (o.has("template")) {
            for(Map.Entry<String, JsonElement> e : o.getAsJsonObject("template").entrySet()) {
               String tr = ((JsonElement)e.getValue()).getAsString();
               if (!tr.isEmpty()) {
                  Tpl t = VexText.Tpl.of((String)e.getKey(), tr);
                  if (t != null) {
                     all.add(t);
                  }
               }
            }
         }

         all.sort(Comparator.comparingInt((tx) -> tx.literalLength).reversed());

         for(Tpl t : all) {
            if (t.head == null) {
               this.headless.add(t);
            } else {
               ((List)this.byHead.computeIfAbsent(t.head, (k) -> new ArrayList())).add(t);
            }
         }

      }

      String translate(String s) {
         String hit = (String)this.exact.get(s);
         if (hit != null) {
            return hit;
         } else {
            String cached = (String)this.cache.get(s);
            if (cached != null) {
               return cached;
            } else {
               String out = this.viaTemplate(s);
               if (out == null) {
                  out = this.viaFragments(s);
               }

               if (this.cache.size() > 4096) {
                  this.cache.clear();
               }

               this.cache.put(s, out);
               return out;
            }
         }
      }

      private String viaTemplate(String s) {
         if (s.length() >= 3) {
            List<Tpl> c = (List)this.byHead.get(s.substring(0, 3));
            if (c != null) {
               for(Tpl t : c) {
                  String r = t.apply(s, this.exact);
                  if (r != null) {
                     return r;
                  }
               }
            }
         }

         for(Tpl t : this.headless) {
            String r = t.apply(s, this.exact);
            if (r != null) {
               return r;
            }
         }

         return null;
      }

      private String viaFragments(String s) {
         if (s.length() < 8) {
            return s;
         } else {
            String out = s;

            for(String[] f : this.fragments) {
               if (out.contains(f[0])) {
                  out = out.replace(f[0], f[1]);
               }
            }

            return out;
         }
      }
   }

   private static final class Tpl {
      private static final Pattern TOKEN = Pattern.compile("\\{\\{|\\}\\}|\\{(\\d+)\\}");
      final Pattern match;
      final String translated;
      final String head;
      final int literalLength;
      final int slots;

      private Tpl(Pattern match, String translated, String head, int literalLength, int slots) {
         this.match = match;
         this.translated = translated;
         this.head = head;
         this.literalLength = literalLength;
         this.slots = slots;
      }

      static Tpl of(String en, String tr) {
         StringBuilder re = new StringBuilder();
         StringBuilder lead = new StringBuilder();
         boolean leading = true;
         int literal = 0;
         int slots = 0;
         int last = 0;

         for(Matcher m = TOKEN.matcher(en); m.find(); last = m.end()) {
            String text = en.substring(last, m.start());
            if (!text.isEmpty()) {
               re.append(Pattern.quote(text));
               literal += text.length();
               if (leading) {
                  lead.append(text);
               }
            }

            if (m.group(1) != null) {
               re.append("(.*?)");
               ++slots;
               leading = false;
            } else {
               String brace = m.group().substring(0, 1);
               re.append(Pattern.quote(brace));
               ++literal;
               if (leading) {
                  lead.append(brace);
               }
            }
         }

         String tail = en.substring(last);
         if (!tail.isEmpty()) {
            re.append(Pattern.quote(tail));
            literal += tail.length();
            if (leading) {
               lead.append(tail);
            }
         }

         if (slots != 0 && literal != 0) {
            String head = lead.length() >= 3 ? lead.substring(0, 3) : null;
            return new Tpl(Pattern.compile(re.toString(), 32), tr, head, literal, slots);
         } else {
            return null;
         }
      }

      String apply(String s, Map<String, String> exact) {
         Matcher m = this.match.matcher(s);
         if (!m.matches()) {
            return null;
         } else {
            StringBuilder out = new StringBuilder();
            Matcher t = TOKEN.matcher(this.translated);

            int last;
            for(last = 0; t.find(); last = t.end()) {
               out.append(this.translated, last, t.start());
               if (t.group(1) != null) {
                  int i = Integer.parseInt(t.group(1));
                  String v = i < m.groupCount() + 1 && i < this.slots ? m.group(i + 1) : "";
                  out.append((String)exact.getOrDefault(v, v));
               } else {
                  out.append(t.group().charAt(0));
               }
            }

            out.append(this.translated, last, this.translated.length());
            return out.toString();
         }
      }
   }
}
