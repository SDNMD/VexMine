package vexbot.platform;

import com.mojang.brigadier.CommandDispatcher;
import java.nio.file.Path;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

public interface Platform {
   static Platform get() {
      Platform p = Platform.Holder.INSTANCE;
      if (p == null) {
         throw new IllegalStateException("[VexBot] Platform not installed — the loader entrypoint must call Platform.install(...) first");
      } else {
         return p;
      }
   }

   static boolean isInstalled() {
      return Platform.Holder.INSTANCE != null;
   }

   static void install(Platform platform) {
      if (platform == null) {
         throw new IllegalArgumentException("platform");
      } else if (Platform.Holder.INSTANCE != null && Platform.Holder.INSTANCE != platform) {
         throw new IllegalStateException("[VexBot] Platform already installed: " + Platform.Holder.INSTANCE.loaderName());
      } else {
         Platform.Holder.INSTANCE = platform;
      }
   }

   String loaderName();

   String modVersion();

   boolean isClient();

   boolean isModLoaded(String var1);

   Path configDir();

   Path extensionsDir();

   void onEndServerTick(Consumer<MinecraftServer> var1);

   void onServerStarting(Consumer<MinecraftServer> var1);

   void onServerStarted(Consumer<MinecraftServer> var1);

   void onServerStopping(Consumer<MinecraftServer> var1);

   void registerCommands(Consumer<CommandDispatcher<CommandSourceStack>> var1);

   void onPlayerAttackEntity(AttackEntityHandler var1);

   void onPlayerUseItem(UseItemHandler var1);

   void onPlayerUseBlock(UseBlockHandler var1);

   void addInputInterceptor(InputInterceptor var1);

   default Optional<PovRecorder> povRecorder() {
      return Optional.empty();
   }

   public static final class Holder {
      static volatile Platform INSTANCE;

      private Holder() {
      }
   }

   public interface InputInterceptor {
      default boolean onEntityClick(ServerPlayer player, Entity target, boolean attack) {
         return false;
      }

      default boolean onBlockClick(ServerPlayer player, BlockPos pos, boolean attack) {
         return false;
      }

      default void onSwing(ServerPlayer player) {
      }

      default boolean onHotbarChange(ServerPlayer player, int from, int to) {
         return false;
      }
   }

   @FunctionalInterface
   public interface AttackEntityHandler {
      void onAttack(ServerPlayer var1, Entity var2);
   }

   public interface PovRecorder {
      void start(String var1);

      void stopAll();
   }

   @FunctionalInterface
   public interface UseBlockHandler {
      void onUseBlock(ServerPlayer var1, BlockPos var2);
   }

   @FunctionalInterface
   public interface UseItemHandler {
      boolean onUseItem(ServerPlayer var1, InteractionHand var2, ItemStack var3);
   }
}
