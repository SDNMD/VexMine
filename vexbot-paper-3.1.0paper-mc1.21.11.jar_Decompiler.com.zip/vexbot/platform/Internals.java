package vexbot.platform;

import com.mojang.authlib.GameProfile;
import io.netty.channel.Channel;
import net.minecraft.network.Connection;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BlocksAttacks;
import net.minecraft.world.level.chunk.LevelChunk;
import vexbot.fakeplayer.bot.BotPlayerActionPack;

public interface Internals {
   static Internals get() {
      Internals i = Internals.Holder.INSTANCE;
      if (i == null) {
         throw new IllegalStateException("[VexBot] Internals not installed");
      } else {
         return i;
      }
   }

   static void install(Internals internals) {
      if (internals == null) {
         throw new IllegalArgumentException("internals");
      } else {
         Internals.Holder.INSTANCE = internals;
      }
   }

   void setConnectionChannel(Connection var1, Channel var2);

   void setGameProfile(Player var1, GameProfile var2);

   ChunkMap.TrackedEntity trackedEntity(ChunkMap var1, int var2);

   void detectEquipmentUpdates(LivingEntity var1);

   boolean checkTotemDeathProtection(LivingEntity var1, DamageSource var2);

   void playSecondaryHurtSound(LivingEntity var1, DamageSource var2);

   void setLastDamage(LivingEntity var1, DamageSource var2, long var3);

   void disableBlocking(BlocksAttacks var1, ServerLevel var2, LivingEntity var3, float var4, ItemStack var5, LivingEntity var6);

   BotPlayerActionPack actionPack(ServerPlayer var1);

   void setLatency(ServerPlayer var1, int var2);

   default void setAffectsSpawning(ServerPlayer player, boolean affects) {
   }

   default LevelChunk fullChunkNow(ServerLevel level, int cx, int cz) {
      return level.getChunkSource().getChunkNow(cx, cz);
   }

   default boolean onGroundNoBlocks(Entity entity) {
      throw new UnsupportedOperationException("onGroundNoBlocks is Fabric-only");
   }

   default void setOnGroundNoBlocks(Entity entity, boolean value) {
      throw new UnsupportedOperationException("onGroundNoBlocks is Fabric-only");
   }

   public static final class Holder {
      static volatile Internals INSTANCE;

      private Holder() {
      }
   }
}
