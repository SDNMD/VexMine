package vexbot;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import vexbot.bot.BotManager;
import vexbot.bot.BotPersistence;
import vexbot.combat.CombatRecorder;
import vexbot.command.VexBotCommand;
import vexbot.compat.McCompat;
import vexbot.extensions.ExtensionPuller;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.i18n.VexLang;
import vexbot.i18n.VexText;
import vexbot.kit.KitManager;
import vexbot.kit.KitPotion;
import vexbot.name.NamePoolStorage;
import vexbot.nick.SkinStorage;
import vexbot.nick.TeamSkinManager;
import vexbot.panel.ControlPanel;
import vexbot.path.PathManager;
import vexbot.platform.Platform;
import vexbot.stats.Stats;
import vexbot.team.TeamHornSummon;
import vexbot.util.ExplosionRules;
import vexbot.util.NameTagPainter;

public final class VexBotCore {
   private VexBotCore() {
   }

   public static void init() {
      Platform p = Platform.get();
      ExtensionPuller.ensureConfig();
      VexBotCommand.register();
      p.onPlayerUseBlock((sp, pos) -> ExplosionRules.note(sp, Vec3.atCenterOf(pos)));
      p.onPlayerAttackEntity((attacker, target) -> ExplosionRules.note(attacker, target.position()));
      p.onPlayerAttackEntity((attacker, target) -> {
         if (target instanceof ServerPlayer botPlayer) {
            if (McCompat.tags(botPlayer).contains("vexbot")) {
               BotManager.notifyBotHurtBy(botPlayer.getName().getString(), attacker.getName().getString());
            }
         }

      });
      p.onPlayerUseItem((sp, hand, stack) -> {
         TeamHornSummon.onUseItem(sp, stack);
         String kitName = KitPotion.getKitName(stack);
         if (kitName == null) {
            return false;
         } else if (BotSettings.kitPotionDoSplash) {
            return false;
         } else {
            boolean applied = KitManager.give(VexBot.SERVER, sp, kitName);
            if (!applied) {
               sp.sendSystemMessage(VexText.literal(sp, "§cKit '§e" + kitName + "§c' no longer exists."));
               return true;
            } else {
               if (!BotSettings.silentCommands) {
                  sp.sendSystemMessage(VexText.literal(sp, "§aKit §e" + kitName + " §arestored!"));
               }

               return true;
            }
         }
      });
      ControlPanel.init(p);
      p.onEndServerTick(BotManager::onServerTick);
      p.onEndServerTick(BotPersistence::onServerTick);
      p.onEndServerTick(Stats::tick);
      p.onEndServerTick(NameTagPainter::onServerTick);
      p.onEndServerTick(CombatRecorder::onServerTick);
      p.onEndServerTick(TeamSkinManager::onServerTick);
      p.onServerStarting((server) -> VexBot.SERVER = server);
      p.onServerStarted((server) -> {
         SkinStorage.ensureFolders(server);
         NamePoolStorage.ensureFolder(server);
         SettingsPersistence.load(server);
         VexLang.load(server);
         PathManager.load(server);
         BotPersistence.restore(server);
      });
      p.onServerStopping((server) -> {
         BotPlayer.saveNoAccount(true);
         SettingsPersistence.save(server);
         PathManager.save(server);
         BotPersistence.save(server);
         BotManager.killAll(server);
         Stats.stopping(server);
         VexBot.SERVER = null;
      });
      VexBot.LOGGER.info("VexBot initialized ({}).", p.loaderName());
   }
}
