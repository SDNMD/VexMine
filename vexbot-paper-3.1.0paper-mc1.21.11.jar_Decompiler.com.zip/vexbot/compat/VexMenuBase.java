package vexbot.compat;

import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import org.bukkit.craftbukkit.inventory.CraftInventory;
import org.bukkit.craftbukkit.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public abstract class VexMenuBase extends AbstractContainerMenu {
   protected final Inventory viewer;
   private InventoryView bukkitView;

   protected VexMenuBase(MenuType<?> type, int containerId, Inventory viewer) {
      super(type, containerId);
      this.viewer = viewer;
   }

   public InventoryView getBukkitView() {
      if (this.bukkitView == null) {
         Container top = this.topContainer();
         this.bukkitView = new CraftInventoryView(this.viewer.player.getBukkitEntity(), new CraftInventory(top), this);
      }

      return this.bukkitView;
   }

   private Container topContainer() {
      if (this.slots.isEmpty()) {
         return new SimpleContainer(0);
      } else {
         int viewerSlots = 0;

         for(int i = this.slots.size() - 1; i >= 0 && viewerSlots < 36 && ((Slot)this.slots.get(i)).container == this.viewer; --i) {
            ++viewerSlots;
         }

         int topCount = this.slots.size() - viewerSlots;
         Container first = ((Slot)this.slots.get(0)).container;
         if (first.getContainerSize() == topCount) {
            return first;
         } else {
            for(int i = 1; i < topCount; ++i) {
               Container c = ((Slot)this.slots.get(i)).container;
               if (c.getContainerSize() == topCount) {
                  return c;
               }
            }

            return new SimpleContainer(topCount);
         }
      }
   }
}
