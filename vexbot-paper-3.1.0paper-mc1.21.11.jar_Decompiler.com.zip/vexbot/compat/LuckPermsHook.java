package vexbot.compat;

import java.util.UUID;
import java.util.concurrent.TimeUnit;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import vexbot.VexBot;

final class LuckPermsHook {
   private static final long LOAD_TIMEOUT_SECONDS = 5L;

   private LuckPermsHook() {
   }

   static void preloadUser(UUID uuid, String name) throws Exception {
      LuckPerms lp = LuckPermsProvider.get();
      lp.getUserManager().loadUser(uuid, name).get(5L, TimeUnit.SECONDS);
      VexBot.LOGGER.info("[VexBot] Pre-loaded LuckPerms data for bot '{}' so it won't be kicked on join.", name);
   }
}
