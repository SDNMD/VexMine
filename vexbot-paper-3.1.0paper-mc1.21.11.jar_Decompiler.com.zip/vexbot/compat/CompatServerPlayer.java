package vexbot.compat;

import com.mojang.authlib.GameProfile;
import io.papermc.paper.event.entity.EntityKnockbackEvent;
import io.papermc.paper.event.entity.EntityKnockbackEvent.Cause;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.EffectiveSettings;
import vexbot.fakeplayer.bot.BotPlayerActionPack;

public abstract class CompatServerPlayer extends ServerPlayer {
   private final BotPlayerActionPack actionPack = new BotPlayerActionPack(this);
   private Entity knockbackAttacker;
   private EntityKnockbackEvent.Cause knockbackCause;

   protected CompatServerPlayer(MinecraftServer server, ServerLevel level, GameProfile profile, ClientInformation clientInfo) {
      super(server, level, profile, clientInfo);
   }

   public BotPlayerActionPack botActionPack() {
      return this.actionPack;
   }

   public void tick() {
      this.actionPack.onUpdate();
      super.tick();
   }

   public boolean isClientAuthoritative() {
      return false;
   }

   public boolean isReceivingWaypoints() {
      return false;
   }

   public final void knockback(double strength, double x, double z, Entity attacker, EntityKnockbackEvent.Cause cause) {
      this.knockbackAttacker = attacker;
      this.knockbackCause = cause;

      try {
         this.vexKnockback(strength, x, z);
      } finally {
         this.knockbackAttacker = null;
         this.knockbackCause = null;
      }

   }

   protected final void superKnockback(double strength, double x, double z) {
      super.knockback(strength, x, z, this.knockbackAttacker, this.knockbackCause == null ? Cause.UNKNOWN : this.knockbackCause);
   }

   protected abstract void vexKnockback(double var1, double var3, double var5);

   protected final void blockUsingItem(ServerLevel level, LivingEntity attacker) {
      this.vexBlockUsingItem(level, attacker);
   }

   protected abstract void vexBlockUsingItem(ServerLevel var1, LivingEntity var2);

   protected boolean vexHurtServer(ServerLevel serverLevel, DamageSource damageSource, float finalDamage) {
      return super.hurtServer(serverLevel, damageSource, finalDamage);
   }

   public ItemStack getItemBlockingWith() {
      if (this.isUsingItem()) {
         ItemStack use = this.getUseItem();
         if (use.has(DataComponents.BLOCKS_ATTACKS)) {
            return this.getCooldowns().isOnCooldown(use) ? null : use;
         }
      }

      return super.getItemBlockingWith();
   }

   public boolean isInWaterOrRain() {
      if (super.isInWaterOrRain()) {
         return true;
      } else {
         ItemStack trident = this.isUsingItem() ? this.getUseItem() : (this.getMainHandItem().is(Items.TRIDENT) ? this.getMainHandItem() : this.getOffhandItem());
         return trident.is(Items.TRIDENT) && EffectiveSettings.of(this.getGameProfile().name()).riptideAnywhere();
      }
   }
}
