package vexbot.compat;

import java.util.UUID;
import vexbot.VexBot;
import vexbot.platform.Platform;

public final class LuckPermsCompat {
   private static final boolean PRESENT = Platform.get().isModLoaded("luckperms");

   private LuckPermsCompat() {
   }

   public static boolean isPresent() {
      return PRESENT;
   }

   public static void preloadUser(UUID uuid, String name) {
      if (PRESENT) {
         try {
            LuckPermsHook.preloadUser(uuid, name);
         } catch (Throwable t) {
            VexBot.LOGGER.warn("[VexBot] LuckPerms pre-load for '{}' failed (spawning anyway): {}", name, t.toString());
         }

      }
   }
}
