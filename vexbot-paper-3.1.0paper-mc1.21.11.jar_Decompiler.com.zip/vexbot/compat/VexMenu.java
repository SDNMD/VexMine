package vexbot.compat;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import vexbot.i18n.VexLang;

public abstract class VexMenu extends VexMenuBase {
   private ClickType current;

   protected VexMenu(MenuType<?> type, int containerId, Inventory viewer) {
      super(type, containerId, viewer);
   }

   public final void clicked(int slotId, int button, ClickType type, Player player) {
      this.current = type;

      try {
         boolean quick = type == ClickType.QUICK_MOVE;
         VexLang.run(player, () -> this.vexClicked(slotId, button, quick, player));
      } finally {
         this.current = null;
      }

   }

   protected abstract void vexClicked(int var1, int var2, boolean var3, Player var4);

   protected final boolean isPlainClick() {
      return this.current == ClickType.PICKUP || this.current == ClickType.QUICK_MOVE;
   }

   protected final void vanillaClick(int slotId, int button, Player player) {
      super.clicked(slotId, button, this.current, player);
   }
}
