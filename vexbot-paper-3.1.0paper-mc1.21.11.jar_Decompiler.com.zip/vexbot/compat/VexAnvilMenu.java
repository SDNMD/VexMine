package vexbot.compat;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.ContainerLevelAccess;

public abstract class VexAnvilMenu extends AnvilMenu {
   protected VexAnvilMenu(int containerId, Inventory inv, ContainerLevelAccess access) {
      super(containerId, inv, access);
   }

   public final void clicked(int slotId, int button, ClickType type, Player player) {
      boolean plain = type == ClickType.PICKUP || type == ClickType.QUICK_MOVE;
      if (!this.interceptClick(slotId, plain, player)) {
         super.clicked(slotId, button, type, player);
      }
   }

   protected abstract boolean interceptClick(int var1, boolean var2, Player var3);
}
