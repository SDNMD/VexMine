package vexbot.compat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.InstrumentComponent;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.PlayerTeam;

public final class McCompat {
   public static final String MC_VERSION = "1.21.11";

   private McCompat() {
   }

   public static Set<String> tags(Entity entity) {
      return entity.getTags();
   }

   public static Item pane(DyeColor colour) {
      Item var10000;
      switch (colour) {
         case WHITE -> var10000 = Items.WHITE_STAINED_GLASS_PANE;
         case ORANGE -> var10000 = Items.ORANGE_STAINED_GLASS_PANE;
         case MAGENTA -> var10000 = Items.MAGENTA_STAINED_GLASS_PANE;
         case LIGHT_BLUE -> var10000 = Items.LIGHT_BLUE_STAINED_GLASS_PANE;
         case YELLOW -> var10000 = Items.YELLOW_STAINED_GLASS_PANE;
         case LIME -> var10000 = Items.LIME_STAINED_GLASS_PANE;
         case PINK -> var10000 = Items.PINK_STAINED_GLASS_PANE;
         case GRAY -> var10000 = Items.GRAY_STAINED_GLASS_PANE;
         case LIGHT_GRAY -> var10000 = Items.LIGHT_GRAY_STAINED_GLASS_PANE;
         case CYAN -> var10000 = Items.CYAN_STAINED_GLASS_PANE;
         case PURPLE -> var10000 = Items.PURPLE_STAINED_GLASS_PANE;
         case BLUE -> var10000 = Items.BLUE_STAINED_GLASS_PANE;
         case BROWN -> var10000 = Items.BROWN_STAINED_GLASS_PANE;
         case GREEN -> var10000 = Items.GREEN_STAINED_GLASS_PANE;
         case RED -> var10000 = Items.RED_STAINED_GLASS_PANE;
         case BLACK -> var10000 = Items.BLACK_STAINED_GLASS_PANE;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public static InteractionResult interactAt(Entity target, Player who, Vec3 hit, InteractionHand hand) {
      return target.interactAt(who, hit, hand);
   }

   public static InteractionResult interactOn(Player who, Entity target, InteractionHand hand, Vec3 hit) {
      return who.interactOn(target, hand);
   }

   public static List<ItemStack> nonEmptyItems(ItemContainerContents box) {
      List<ItemStack> out = new ArrayList();

      for(ItemStack stack : box.nonEmptyItemsCopy()) {
         out.add(stack);
      }

      return out;
   }

   public static void setTeamColour(PlayerTeam team, ChatFormatting colour) {
      team.setColor(colour);
   }

   public static boolean teamColourIs(PlayerTeam team, ChatFormatting colour) {
      return team.getColor() == colour;
   }

   public static void setTeamPrefix(PlayerTeam team, Component prefix) {
      team.setPlayerPrefix(prefix);
   }

   public static ItemParticleOption itemParticle(ItemStack stack) {
      return new ItemParticleOption(ParticleTypes.ITEM, stack);
   }

   public static boolean isPlayerType(EntityType<?> type) {
      return type == EntityType.PLAYER;
   }

   public static boolean entityTypeIs(EntityType<?> type, TagKey<EntityType<?>> tag) {
      return type.is(tag);
   }

   public static EntityType<LightningBolt> lightningBolt() {
      return EntityType.LIGHTNING_BOLT;
   }

   public static Item dye(DyeColor colour) {
      Item var10000;
      switch (colour) {
         case WHITE -> var10000 = Items.WHITE_DYE;
         case ORANGE -> var10000 = Items.ORANGE_DYE;
         case MAGENTA -> var10000 = Items.MAGENTA_DYE;
         case LIGHT_BLUE -> var10000 = Items.LIGHT_BLUE_DYE;
         case YELLOW -> var10000 = Items.YELLOW_DYE;
         case LIME -> var10000 = Items.LIME_DYE;
         case PINK -> var10000 = Items.PINK_DYE;
         case GRAY -> var10000 = Items.GRAY_DYE;
         case LIGHT_GRAY -> var10000 = Items.LIGHT_GRAY_DYE;
         case CYAN -> var10000 = Items.CYAN_DYE;
         case PURPLE -> var10000 = Items.PURPLE_DYE;
         case BLUE -> var10000 = Items.BLUE_DYE;
         case BROWN -> var10000 = Items.BROWN_DYE;
         case GREEN -> var10000 = Items.GREEN_DYE;
         case RED -> var10000 = Items.RED_DYE;
         case BLACK -> var10000 = Items.BLACK_DYE;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public static Item shulkerBox(DyeColor colour) {
      if (colour == null) {
         return Items.SHULKER_BOX;
      } else {
         Item var10000;
         switch (colour) {
            case WHITE -> var10000 = Items.WHITE_SHULKER_BOX;
            case ORANGE -> var10000 = Items.ORANGE_SHULKER_BOX;
            case MAGENTA -> var10000 = Items.MAGENTA_SHULKER_BOX;
            case LIGHT_BLUE -> var10000 = Items.LIGHT_BLUE_SHULKER_BOX;
            case YELLOW -> var10000 = Items.YELLOW_SHULKER_BOX;
            case LIME -> var10000 = Items.LIME_SHULKER_BOX;
            case PINK -> var10000 = Items.PINK_SHULKER_BOX;
            case GRAY -> var10000 = Items.GRAY_SHULKER_BOX;
            case LIGHT_GRAY -> var10000 = Items.LIGHT_GRAY_SHULKER_BOX;
            case CYAN -> var10000 = Items.CYAN_SHULKER_BOX;
            case PURPLE -> var10000 = Items.PURPLE_SHULKER_BOX;
            case BLUE -> var10000 = Items.BLUE_SHULKER_BOX;
            case BROWN -> var10000 = Items.BROWN_SHULKER_BOX;
            case GREEN -> var10000 = Items.GREEN_SHULKER_BOX;
            case RED -> var10000 = Items.RED_SHULKER_BOX;
            case BLACK -> var10000 = Items.BLACK_SHULKER_BOX;
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   public static void sendMessage(ServerPlayer to, Component text, boolean actionBar) {
      to.displayClientMessage(text, actionBar);
   }

   public static void triggerEntityHurtPlayer(ServerPlayer victim, DamageSource source, float original, float dealt, boolean blocked) {
      CriteriaTriggers.ENTITY_HURT_PLAYER.trigger(victim, source, original, dealt, blocked);
   }

   public static void triggerPlayerHurtEntity(ServerPlayer attacker, Entity victim, DamageSource source, float original, float dealt, boolean blocked) {
      CriteriaTriggers.PLAYER_HURT_ENTITY.trigger(attacker, victim, source, original, dealt, blocked);
   }

   public static String instrumentId(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         InstrumentComponent c = (InstrumentComponent)stack.get(DataComponents.INSTRUMENT);
         return c == null ? null : (String)c.instrument().key().map((k) -> k.identifier().getPath()).orElse((Object)null);
      } else {
         return null;
      }
   }

   public static void stopAdvancementTriggers(ServerPlayer p) {
      p.getAdvancements().stopListening();
   }

   public static void resumeAdvancementTriggers(ServerPlayer p, MinecraftServer server) {
      p.getAdvancements().reload(server.getAdvancements());
   }

   public static void swing(LivingEntity e, InteractionHand hand) {
      e.swing(hand);
   }

   public static int invulnerableTime(Entity e) {
      return e.invulnerableTime;
   }

   public static void setInvulnerableTime(Entity e, int ticks) {
      e.invulnerableTime = ticks;
   }

   public static ItemEntity drop(Player p, ItemStack s, boolean around) {
      return p.drop(s, around);
   }

   public static ItemEntity drop(Player p, ItemStack s, boolean around, boolean withThrower) {
      return p.drop(s, around, withThrower);
   }

   public static void placeBack(Inventory inv, ItemStack s) {
      inv.placeItemBackInInventory(s);
   }

   public static boolean blocksMotion(BlockState s) {
      return s.blocksMotion();
   }

   public static void markVelocityDirty(Entity e) {
      e.hurtMarked = true;
   }

   public static void setInvulnerable(Entity e, boolean on) {
      e.setInvulnerable(on);
   }
}
