package vexbot.path;

import java.util.List;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import vexbot.i18n.VexText;

public final class PathCli {
   private static final double LINE_STEP = 0.4;

   private PathCli() {
   }

   private static void ok(CommandSourceStack src, String msg) {
      src.sendSuccess(() -> VexText.literal("[VexBot] " + msg), false);
   }

   private static int fail(CommandSourceStack src, String msg) {
      src.sendFailure(VexText.literal("[VexBot] " + msg));
      return 0;
   }

   private static void persist(CommandSourceStack src) {
      if (src.getServer() != null) {
         PathManager.save(src.getServer());
      }

   }

   public static int create(CommandSourceStack src, String name) {
      if (PathManager.exists(name)) {
         return fail(src, "A path called §e" + name + "§r already exists.");
      } else {
         String dim = src.getLevel().dimension().identifier().toString();
         BotPath p = PathManager.create(name, dim);
         p.points.add(src.getPosition());
         persist(src);
         ok(src, "Created path §e" + name + "§r with its first point where you are standing. §7Walk somewhere and run §f/vexbot path add " + name + "§7 to add the next one.");
         return 1;
      }
   }

   public static int add(CommandSourceStack src, String name) {
      BotPath p = PathManager.get(name);
      if (p == null) {
         return fail(src, "No path called §e" + name + "§r.");
      } else {
         String dim = src.getLevel().dimension().identifier().toString();
         if (!dim.equals(p.dimension)) {
            return fail(src, "That path is in §e" + p.dimension + "§r — a path cannot cross dimensions.");
         } else {
            p.points.add(src.getPosition());
            persist(src);
            int var10001 = p.size();
            ok(src, "Point §f" + var10001 + "§r added to §e" + name + "§r.");
            return 1;
         }
      }
   }

   public static int removePoint(CommandSourceStack src, String name, int index) {
      BotPath p = PathManager.get(name);
      if (p == null) {
         return fail(src, "No path called §e" + name + "§r.");
      } else if (index >= 1 && index <= p.size()) {
         p.points.remove(index - 1);
         persist(src);
         ok(src, "Removed point §f" + index + "§r; §e" + name + "§r now has §f" + p.size() + "§r.");
         return 1;
      } else {
         return fail(src, "§e" + name + "§r has points 1–" + p.size() + ".");
      }
   }

   public static int delete(CommandSourceStack src, String name) {
      if (!PathManager.delete(name)) {
         return fail(src, "No path called §e" + name + "§r.");
      } else {
         persist(src);
         ok(src, "Deleted path §e" + name + "§r.");
         return 1;
      }
   }

   public static int list(CommandSourceStack src) {
      List<BotPath> all = PathManager.all();
      if (all.isEmpty()) {
         ok(src, "No paths yet. §7Make one with §f/vexbot path create <name>§7.");
         return 1;
      } else {
         ok(src, "Paths:");

         for(BotPath p : all) {
            src.sendSuccess(() -> {
               String var10000 = p.name;
               return VexText.literal("  §e" + var10000 + "§r §7— " + p.size() + " points, " + String.format("%.0f", p.length()) + " blocks, " + p.mode.name().toLowerCase() + ", " + p.walk.name().toLowerCase());
            }, false);
         }

         return 1;
      }
   }

   public static int info(CommandSourceStack src, String name) {
      BotPath p = PathManager.get(name);
      if (p == null) {
         return fail(src, "No path called §e" + name + "§r.");
      } else {
         String var10001 = p.name;
         ok(src, "§e" + var10001 + "§r — §f" + p.size() + "§r points, §f" + String.format("%.0f", p.length()) + "§r blocks, mode §f" + p.mode.name().toLowerCase() + "§r, walk §f" + p.walk.name().toLowerCase() + "§r, in §f" + p.dimension);
         int i = 1;

         for(Vec3 v : p.points) {
            int n = i++;
            src.sendSuccess(() -> VexText.literal(String.format("  §7%d.§r %.1f %.1f %.1f", n, v.x, v.y, v.z)), false);
         }

         return 1;
      }
   }

   public static int mode(CommandSourceStack src, String name, String modeRaw) {
      BotPath p = PathManager.get(name);
      if (p == null) {
         return fail(src, "No path called §e" + name + "§r.");
      } else {
         try {
            p.mode = BotPath.Mode.valueOf(modeRaw.toUpperCase(Locale.ROOT));
         } catch (IllegalArgumentException var5) {
            return fail(src, "Mode is §eonce§r, §eloop§r or §epingpong§r.");
         }

         persist(src);
         ok(src, "§e" + name + "§r is now §f" + p.mode.name().toLowerCase() + "§r.");
         return 1;
      }
   }

   public static int walk(CommandSourceStack src, String name, String walkRaw) {
      BotPath p = PathManager.get(name);
      if (p == null) {
         return fail(src, "No path called §e" + name + "§r.");
      } else {
         try {
            p.walk = BotPath.Walk.valueOf(walkRaw.toUpperCase(Locale.ROOT));
         } catch (IllegalArgumentException var5) {
            return fail(src, "Walk type is §ewalk§r, §esprint§r or §ebunnyhop§r.");
         }

         persist(src);
         ok(src, "Bots on §e" + name + "§r now §f" + p.walk.name().toLowerCase() + "§r.");
         return 1;
      }
   }

   public static int show(CommandSourceStack src, String name) {
      BotPath p = PathManager.get(name);
      if (p == null) {
         return fail(src, "No path called §e" + name + "§r.");
      } else {
         ServerLevel var4 = src.getLevel();
         if (!(var4 instanceof ServerLevel)) {
            return fail(src, "Not in a world.");
         } else {
            ServerLevel lvl = var4;
            if (p.size() == 0) {
               return fail(src, "§e" + name + "§r has no points yet.");
            } else {
               for(Vec3 v : p.points) {
                  lvl.sendParticles(ParticleTypes.HAPPY_VILLAGER, v.x, v.y + 0.4, v.z, 6, 0.15, (double)0.25F, 0.15, (double)0.0F);
               }

               int segments = p.mode == BotPath.Mode.LOOP && p.size() > 2 ? p.size() : p.size() - 1;

               for(int i = 0; i < segments; ++i) {
                  Vec3 a = (Vec3)p.points.get(i);
                  Vec3 b = (Vec3)p.points.get((i + 1) % p.size());
                  double len = a.distanceTo(b);

                  for(double d = (double)0.0F; d < len; d += 0.4) {
                     Vec3 at = a.add(b.subtract(a).normalize().scale(d));
                     lvl.sendParticles(ParticleTypes.WAX_OFF, at.x, at.y + 0.3, at.z, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
                  }
               }

               ok(src, "Showing §e" + name + "§r — §f" + p.size() + "§r points" + (p.mode == BotPath.Mode.LOOP ? " §7(closed loop)" : ""));
               return 1;
            }
         }
      }
   }

   public static void assign(CommandSourceStack src, String pathName, String botName) {
      if (!PathManager.exists(pathName)) {
         fail(src, "No path called §e" + pathName + "§r.");
      } else {
         PathWalker.assign(botName, pathName, 0);
         ok(src, "§f" + botName + "§r is now walking §e" + pathName + "§r.");
      }
   }

   public static void stop(CommandSourceStack src, String botName) {
      if (!PathWalker.isWalking(botName)) {
         ok(src, "§f" + botName + "§r was not on a path.");
      } else {
         PathWalker.clear(botName);
         ok(src, "§f" + botName + "§r stopped walking its path.");
      }
   }

   public static void spread(CommandSourceStack src, String pathName, String botName, int ordinal, int total) {
      BotPath p = PathManager.get(pathName);
      if (p == null) {
         fail(src, "No path called §e" + pathName + "§r.");
      } else if (p.size() == 0) {
         fail(src, "§e" + pathName + "§r has no points.");
      } else {
         int start = total <= 1 ? 0 : (int)Math.round((double)ordinal * (double)p.size() / (double)total) % p.size();
         PathWalker.assign(botName, pathName, start);
         ok(src, "§f" + botName + "§r joined §e" + pathName + "§r at point §f" + (start + 1) + "§r.");
      }
   }
}
