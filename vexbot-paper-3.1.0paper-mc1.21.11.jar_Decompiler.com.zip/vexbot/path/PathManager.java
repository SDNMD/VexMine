package vexbot.path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.phys.Vec3;
import vexbot.VexBot;

public final class PathManager {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final Map<String, BotPath> PATHS = new LinkedHashMap();

   private PathManager() {
   }

   private static Path file(MinecraftServer server) {
      return server.getServerDirectory().resolve("vexbot_paths.json");
   }

   private static String key(String name) {
      return name.toLowerCase(Locale.ROOT);
   }

   public static BotPath get(String name) {
      return name == null ? null : (BotPath)PATHS.get(key(name));
   }

   public static boolean exists(String name) {
      return get(name) != null;
   }

   public static List<BotPath> all() {
      return new ArrayList(PATHS.values());
   }

   public static BotPath create(String name, String dimension) {
      if (exists(name)) {
         return null;
      } else {
         BotPath p = new BotPath(name, dimension);
         PATHS.put(key(name), p);
         return p;
      }
   }

   public static boolean delete(String name) {
      return PATHS.remove(key(name)) != null;
   }

   public static void save(MinecraftServer server) {
      JsonObject root = new JsonObject();

      for(BotPath p : PATHS.values()) {
         JsonObject o = new JsonObject();
         o.addProperty("dimension", p.dimension);
         o.addProperty("mode", p.mode.name());
         o.addProperty("walk", p.walk.name());
         JsonArray pts = new JsonArray();

         for(Vec3 v : p.points) {
            JsonArray a = new JsonArray();
            a.add(v.x);
            a.add(v.y);
            a.add(v.z);
            pts.add(a);
         }

         o.add("points", pts);
         root.add(p.name, o);
      }

      Path f = file(server);
      Path tmp = f.resolveSibling(String.valueOf(f.getFileName()) + ".tmp");

      try {
         Files.writeString(tmp, GSON.toJson(root));

         try {
            Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (AtomicMoveNotSupportedException var9) {
            Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING);
         }
      } catch (IOException e) {
         VexBot.LOGGER.error("[VexBot] could not save paths", e);
      }

   }

   public static void load(MinecraftServer server) {
      Path f = file(server);
      if (Files.exists(f, new LinkOption[0])) {
         try {
            JsonObject root = (JsonObject)GSON.fromJson(Files.readString(f), JsonObject.class);
            if (root == null) {
               return;
            }

            Map<String, BotPath> loaded = new LinkedHashMap();
            boolean skipped = false;

            for(String name : root.keySet()) {
               try {
                  JsonObject o = root.getAsJsonObject(name);
                  BotPath p = new BotPath(name, o.get("dimension").getAsString());

                  try {
                     p.mode = BotPath.Mode.valueOf(o.get("mode").getAsString());
                  } catch (Exception var13) {
                  }

                  try {
                     p.walk = BotPath.Walk.valueOf(o.get("walk").getAsString());
                  } catch (Exception var12) {
                  }

                  for(JsonElement el : o.getAsJsonArray("points")) {
                     JsonArray a = el.getAsJsonArray();
                     p.points.add(new Vec3(a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble()));
                  }

                  loaded.put(key(name), p);
               } catch (Exception e) {
                  skipped = true;
                  VexBot.LOGGER.error("[VexBot] skipping unreadable path '{}'", name, e);
               }
            }

            if (skipped) {
               backup(f);
            }

            PATHS.clear();
            PATHS.putAll(loaded);
            VexBot.LOGGER.info("[VexBot] loaded {} path(s)", PATHS.size());
         } catch (Exception e) {
            VexBot.LOGGER.error("[VexBot] could not read paths", e);
            backup(f);
         }

      }
   }

   private static void backup(Path f) {
      try {
         Files.copy(f, f.resolveSibling(String.valueOf(f.getFileName()) + ".bak"), StandardCopyOption.REPLACE_EXISTING);
      } catch (IOException e) {
         VexBot.LOGGER.error("[VexBot] could not back up paths file", e);
      }

   }
}
