package vexbot.path;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.phys.Vec3;

public final class BotPath {
   public final String name;
   public String dimension;
   public final List<Vec3> points = new ArrayList();
   public Mode mode;
   public Walk walk;

   public BotPath(String name, String dimension) {
      this.mode = BotPath.Mode.LOOP;
      this.walk = BotPath.Walk.WALK;
      this.name = name;
      this.dimension = dimension;
   }

   public int size() {
      return this.points.size();
   }

   public double length() {
      double d = (double)0.0F;

      for(int i = 1; i < this.points.size(); ++i) {
         d += ((Vec3)this.points.get(i - 1)).distanceTo((Vec3)this.points.get(i));
      }

      if (this.mode == BotPath.Mode.LOOP && this.points.size() > 2) {
         d += ((Vec3)this.points.get(this.points.size() - 1)).distanceTo((Vec3)this.points.get(0));
      }

      return d;
   }

   public Vec3 pointAt(int index) {
      return index >= 0 && index < this.points.size() ? (Vec3)this.points.get(index) : null;
   }

   public static enum Mode {
      ONCE,
      LOOP,
      PINGPONG;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{ONCE, LOOP, PINGPONG};
      }
   }

   public static enum Walk {
      WALK,
      SPRINT,
      BUNNYHOP;

      // $FF: synthetic method
      private static Walk[] $values() {
         return new Walk[]{WALK, SPRINT, BUNNYHOP};
      }
   }
}
