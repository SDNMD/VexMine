package vexbot.path;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import vexbot.util.BotCommands;

public final class PathWalker {
   private static final double ARRIVE = 1.6;
   private static final double VERTICAL_ARRIVE = (double)2.0F;
   private static final int STUCK_TICKS = 200;
   private static final Map<String, Assignment> ASSIGNED = new HashMap();

   private PathWalker() {
   }

   private static String key(String botName) {
      return botName.toLowerCase(Locale.ROOT);
   }

   public static void assign(String botName, String pathName, int startIndex) {
      ASSIGNED.put(key(botName), new Assignment(pathName, startIndex, 1, 0, false));
   }

   public static void clear(String botName) {
      ASSIGNED.remove(key(botName));
   }

   public static boolean isWalking(String botName) {
      return ASSIGNED.containsKey(key(botName));
   }

   public static String pathOf(String botName) {
      Assignment a = (Assignment)ASSIGNED.get(key(botName));
      return a == null ? null : a.pathName;
   }

   public static boolean tick(ServerPlayer bot, MinecraftServer server, Consumer<Vec3> chase) {
      String botName = bot.getScoreboardName();
      Assignment a = (Assignment)ASSIGNED.get(key(botName));
      if (a != null && !a.done) {
         BotPath path = PathManager.get(a.pathName);
         if (path != null && path.size() != 0) {
            if (!bot.level().dimension().identifier().toString().equals(path.dimension)) {
               return false;
            } else {
               int clamped = Math.max(0, Math.min(a.index, path.size() - 1));
               if (clamped != a.index) {
                  a = new Assignment(a.pathName, clamped, a.dir, 0, false);
                  ASSIGNED.put(key(botName), a);
               }

               Vec3 goal = path.pointAt(a.index);
               if (goal == null) {
                  ASSIGNED.remove(key(botName));
                  return false;
               } else {
                  if (arrived(bot.position(), goal)) {
                     Assignment next = advance(path, a);
                     ASSIGNED.put(key(botName), next);
                     if (next.done) {
                        BotCommands.stopMoving(server, botName);
                        return true;
                     }

                     goal = path.pointAt(next.index);
                     if (goal == null) {
                        return true;
                     }
                  } else {
                     if (a.ticksOnPoint > 200) {
                        Assignment next = advance(path, a);
                        ASSIGNED.put(key(botName), next);
                        return true;
                     }

                     ASSIGNED.put(key(botName), new Assignment(a.pathName, a.index, a.dir, a.ticksOnPoint + 1, false));
                  }

                  chase.accept(goal);
                  applyWalkStyle(bot, server, botName, path.walk);
                  return true;
               }
            }
         } else {
            ASSIGNED.remove(key(botName));
            return false;
         }
      } else {
         return false;
      }
   }

   private static boolean arrived(Vec3 at, Vec3 goal) {
      double dx = goal.x - at.x;
      double dz = goal.z - at.z;
      return dx * dx + dz * dz <= 2.5600000000000005 && Math.abs(goal.y - at.y) <= (double)2.0F;
   }

   private static Assignment advance(BotPath path, Assignment a) {
      int last = path.size() - 1;
      int dir = path.mode == BotPath.Mode.PINGPONG ? a.dir : 1;
      int i = a.index + dir;
      switch (path.mode) {
         case LOOP:
            if (i > last) {
               i = 0;
            }

            if (i < 0) {
               i = last;
            }
            break;
         case PINGPONG:
            if (i > last) {
               dir = -1;
               i = Math.max(0, last - 1);
            } else if (i < 0) {
               dir = 1;
               i = Math.min(last, 1);
            }
            break;
         case ONCE:
            if (i > last || i < 0) {
               return new Assignment(a.pathName, a.index, dir, 0, true);
            }
      }

      return new Assignment(a.pathName, i, dir, 0, false);
   }

   private static void applyWalkStyle(ServerPlayer bot, MinecraftServer server, String botName, BotPath.Walk walk) {
      switch (walk) {
         case WALK:
            bot.setSprinting(false);
            break;
         case SPRINT:
            bot.setSprinting(true);
            break;
         case BUNNYHOP:
            bot.setSprinting(true);
            if (bot.onGround()) {
               BotCommands.jumpOnce(server, botName);
            }
      }

   }

   private static record Assignment(String pathName, int index, int dir, int ticksOnPoint, boolean done) {
   }
}
