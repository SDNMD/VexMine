package vexbot.command;

import com.mojang.brigadier.LiteralMessage;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.selector.EntitySelector;
import net.minecraft.commands.arguments.selector.EntitySelectorParser;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.bot.BotManager;
import vexbot.compat.McCompat;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.i18n.VexText;
import vexbot.nick.NickManager;

public final class BotTargetArgument implements ArgumentType<Target> {
   public static Supplier<ArgumentType<Target>> FACTORY = BotTargetArgument::new;
   public static final SuggestionProvider<CommandSourceStack> SUGGEST = (ctx, builder) -> target().listSuggestions(ctx, builder);
   private static final SimpleCommandExceptionType AT_B_NO_OPTIONS = new SimpleCommandExceptionType(new LiteralMessage("@b takes no options; use @e[tag=vexbot,...] to filter bots"));

   public static ArgumentType<Target> target() {
      return (ArgumentType)FACTORY.get();
   }

   public static BotTargetArgument raw() {
      return new BotTargetArgument();
   }

   public Target parse(StringReader reader) throws CommandSyntaxException {
      if (reader.canRead() && reader.peek() == '@') {
         int after = reader.getCursor() + 1;
         char sel = after < reader.getString().length() ? reader.getString().charAt(after) : 0;
         if (sel != 'b' && sel != 'B') {
            EntitySelector parsed = (new EntitySelectorParser(reader, true)).parse();
            return new Selector(parsed, Character.toLowerCase(sel));
         } else {
            reader.skip();
            reader.skip();
            if (reader.canRead() && reader.peek() == '[') {
               throw AT_B_NO_OPTIONS.createWithContext(reader);
            } else {
               return new AllBots();
            }
         }
      } else {
         return new Named(reader.readString());
      }
   }

   private static boolean selectorsAllowed(CommandSourceStack source) {
      return true;
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
      Object var4 = context.getSource();
      if (var4 instanceof SharedSuggestionProvider ssp) {
         StringReader reader = new StringReader(builder.getInput());
         reader.setCursor(builder.getStart());
         EntitySelectorParser parser = new EntitySelectorParser(reader, true);

         try {
            parser.parse();
         } catch (CommandSyntaxException var7) {
         }

         return parser.fillSuggestions(builder, (b) -> {
            b.suggest("@b");
            List<String> names = new ArrayList(BotManager.getBotNames());
            names.addAll(ssp.getOnlinePlayerNames());
            SharedSuggestionProvider.suggest(names, b);
         });
      } else {
         return Suggestions.empty();
      }
   }

   public static List<ServerPlayer> resolve(CommandSourceStack source, Target t) {
      MinecraftServer server = source.getServer();
      List<ServerPlayer> out = new ArrayList();
      if ((t instanceof AllBots || t instanceof Selector) && !selectorsAllowed(source)) {
         return out;
      } else {
         if (t instanceof AllBots) {
            for(ServerPlayer p : server.getPlayerList().getPlayers()) {
               if (p instanceof BotPlayer && McCompat.tags(p).contains("vexbot") && !BotManager.isPracticeBot(NickManager.realName(p))) {
                  out.add(p);
               }
            }
         } else if (t instanceof Selector) {
            Selector s = (Selector)t;

            try {
               for(ServerPlayer p : s.selector().findPlayers(source)) {
                  if (s.type() != 'a' || !(p instanceof BotPlayer)) {
                     out.add(p);
                  }
               }
            } catch (CommandSyntaxException var8) {
            }
         } else if (t instanceof Named) {
            Named n = (Named)t;
            ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, n.name());
            if (bot != null) {
               out.add(bot);
            } else {
               ServerPlayer pl = server.getPlayerList().getPlayerByName(n.name());
               if (pl != null) {
                  out.add(pl);
               }
            }
         }

         return out;
      }
   }

   public static Target get(CommandContext<CommandSourceStack> ctx, String name) {
      return (Target)ctx.getArgument(name, Target.class);
   }

   public static int runForEach(CommandContext<CommandSourceStack> ctx, String argName, Consumer<String> action) {
      CommandSourceStack src = (CommandSourceStack)ctx.getSource();
      Target t = get(ctx, argName);
      if ((t instanceof AllBots || t instanceof Selector) && !selectorsAllowed(src)) {
         src.sendFailure(VexText.literal("[VexBot] §c@-selectors (@b, @a, …) only work from a command block§r — type a bot name in chat."));
         return 0;
      } else {
         List<ServerPlayer> targets = resolve(src, t);
         if (targets.isEmpty()) {
            src.sendFailure(VexText.literal("[VexBot] No targets matched."));
            return 0;
         } else {
            for(ServerPlayer p : targets) {
               action.accept(identityName(p));
            }

            return targets.size();
         }
      }
   }

   public static String firstName(CommandSourceStack source, Target t) {
      List<ServerPlayer> r = resolve(source, t);
      return r.isEmpty() ? null : identityName((ServerPlayer)r.get(0));
   }

   public static List<String> resolveNamesGated(CommandContext<CommandSourceStack> ctx, String argName) {
      CommandSourceStack src = (CommandSourceStack)ctx.getSource();
      Target t = get(ctx, argName);
      if ((t instanceof AllBots || t instanceof Selector) && !selectorsAllowed(src)) {
         src.sendFailure(VexText.literal("[VexBot] §c@-selectors (@b, @a, …) only work from a command block§r — use a bot name in chat."));
         return null;
      } else {
         List<String> names = new ArrayList();

         for(ServerPlayer p : resolve(src, t)) {
            names.add(identityName(p));
         }

         return names;
      }
   }

   private static String identityName(ServerPlayer p) {
      return !(p instanceof BotPlayer) && !McCompat.tags(p).contains("vexbot") ? p.getName().getString() : NickManager.realName(p);
   }

   public static record AllBots() implements Target {
   }

   public static record Selector(EntitySelector selector, char type) implements Target {
   }

   public static record Named(String name) implements Target {
   }

   public sealed interface Target permits BotTargetArgument.AllBots, BotTargetArgument.Selector, BotTargetArgument.Named {
   }
}
