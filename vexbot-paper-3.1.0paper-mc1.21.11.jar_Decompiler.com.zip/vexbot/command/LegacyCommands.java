package vexbot.command;

import java.util.Map;

public final class LegacyCommands {
   private static final Map<String, String> TEAM_NAMED = Map.ofEntries(Map.entry("teamsettings", "settings"), Map.entry("teamtargets", "targets"), Map.entry("teammembers", "members"), Map.entry("teamdifficulty", "difficulty"), Map.entry("teamalliance", "allies"), Map.entry("teamfollow", "follow"), Map.entry("teamgoto", "goto"), Map.entry("teamlook", "look"), Map.entry("teamlookat", "look"), Map.entry("teamtp", "tp"), Map.entry("teamnamepool", "names"), Map.entry("teamplaystyle", "playstyle"), Map.entry("teamgivekit", "kit"), Map.entry("teamgivekitid", "kitid"), Map.entry("teamrandomgear", "gear"), Map.entry("teamrandomgearconfig", "gearconfig"), Map.entry("teammass_spawn", "massspawn"), Map.entry("teamskin", "skin"), Map.entry("teamtechniques", "settings"));
   private static final Map<String, String> TEAM_ROOT = Map.of("teamcreate", "create", "teamdelete", "delete", "teamjoin", "join", "teamleave", "leave");

   private LegacyCommands() {
   }

   public static String rewrite(String command) {
      if (command != null && command.length() >= 8) {
         String slash = command.startsWith("/") ? "/" : "";
         String body = command.substring(slash.length());
         int a = body.indexOf(32);
         if (a < 0) {
            return null;
         } else {
            String root = body.substring(0, a);
            if (!root.equals("vexbot") && !root.equals("vexbot:vexbot")) {
               return null;
            } else {
               String afterRoot = body.substring(a + 1).stripLeading();
               int b = afterRoot.indexOf(32);
               String sub = b < 0 ? afterRoot : afterRoot.substring(0, b);
               String rest = b < 0 ? "" : afterRoot.substring(b + 1).stripLeading();
               String head = slash + root + " ";
               String rootSub = (String)TEAM_ROOT.get(sub);
               if (rootSub != null) {
                  return head + "team " + rootSub + tail(rest);
               } else if (!sub.equals("teamskin") || !rest.equals("list") && !rest.startsWith("list ")) {
                  String named = (String)TEAM_NAMED.get(sub);
                  if (named != null) {
                     if (rest.isEmpty()) {
                        return null;
                     } else {
                        int c = rest.indexOf(32);
                        String team = c < 0 ? rest : rest.substring(0, c);
                        String args = c < 0 ? "" : rest.substring(c + 1).stripLeading();
                        if (sub.equals("teamtechniques")) {
                           args = args.isEmpty() ? "list" : techniqueArgs(args);
                        }

                        return head + "team " + team + " " + named + tail(args);
                     }
                  } else {
                     String var10000;
                     switch (sub) {
                        case "techniques" -> var10000 = head + "settings " + (rest.isEmpty() ? "list" : techniqueArgs(rest));
                        case "viewinv" -> var10000 = rest.isEmpty() ? null : head + "view inventory " + rest;
                        default -> var10000 = null;
                     }

                     return var10000;
                  }
               } else {
                  return head + "team skin " + rest;
               }
            }
         }
      } else {
         return null;
      }
   }

   static String techniqueArgs(String rest) {
      String[] w = rest.trim().split("\\s+");
      if (w.length == 2 && w[0].equalsIgnoreCase("info")) {
         return w[1];
      } else {
         return w.length == 3 && w[1].equalsIgnoreCase("variant") ? w[0] + "-style " + w[2] : rest.trim();
      }
   }

   private static String tail(String rest) {
      return rest.isEmpty() ? "" : " " + rest;
   }
}
