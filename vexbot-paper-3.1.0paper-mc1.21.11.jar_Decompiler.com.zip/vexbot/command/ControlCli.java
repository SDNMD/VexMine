package vexbot.command;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import vexbot.bot.BotManager;
import vexbot.fakeplayer.bot.BotPlayerActionPack;
import vexbot.i18n.VexText;
import vexbot.platform.Internals;

public final class ControlCli {
   private static final Set<String> MANUAL = ConcurrentHashMap.newKeySet();

   private ControlCli() {
   }

   public static boolean isManual(String botName) {
      return !MANUAL.isEmpty() && MANUAL.contains(botName.toLowerCase(Locale.ROOT));
   }

   public static void forget(String botName) {
      MANUAL.remove(botName.toLowerCase(Locale.ROOT));
   }

   public static LiteralArgumentBuilder<CommandSourceStack> control() {
      RequiredArgumentBuilder<CommandSourceStack, BotTargetArgument.Target> bot = Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST);
      bot.then(moveDirs(Commands.literal("move")));
      LiteralArgumentBuilder<CommandSourceStack> look = (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("look").then(Commands.literal("at").then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> {
         Vec3 p = Vec3Argument.getVec3(ctx, "pos");
         return each(ctx, "looks at a point", (ap) -> ap.lookAt(p));
      })))).then(Commands.argument("yaw", FloatArgumentType.floatArg(-180.0F, 360.0F)).then(Commands.argument("pitch", FloatArgumentType.floatArg(-90.0F, 90.0F)).executes((ctx) -> {
         float y = FloatArgumentType.getFloat(ctx, "yaw");
         float p = FloatArgumentType.getFloat(ctx, "pitch");
         return each(ctx, "looks " + y + " " + p, (ap) -> ap.look(y, p));
      })));

      for(Direction d : Direction.values()) {
         String n = d.getSerializedName();
         look.then(Commands.literal(n).executes((ctx) -> each(ctx, "looks " + n, (ap) -> ap.look(d))));
      }

      bot.then(look);
      bot.then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("turn").then(Commands.literal("left").executes((ctx) -> each(ctx, "turns left", (ap) -> ap.turn(-90.0F, 0.0F))))).then(Commands.literal("right").executes((ctx) -> each(ctx, "turns right", (ap) -> ap.turn(90.0F, 0.0F))))).then(Commands.literal("back").executes((ctx) -> each(ctx, "turns around", (ap) -> ap.turn(180.0F, 0.0F)))));
      action(bot, "jump", BotPlayerActionPack.ActionType.JUMP);
      action(bot, "use", BotPlayerActionPack.ActionType.USE);
      action(bot, "attack", BotPlayerActionPack.ActionType.ATTACK);
      action(bot, "drop", BotPlayerActionPack.ActionType.DROP_ITEM);
      action(bot, "dropstack", BotPlayerActionPack.ActionType.DROP_STACK);
      action(bot, "swaphands", BotPlayerActionPack.ActionType.SWAP_HANDS);
      action(bot, "swing", BotPlayerActionPack.ActionType.SWING);
      bot.then(Commands.literal("hotbar").then(Commands.argument("slot", IntegerArgumentType.integer(1, 9)).executes((ctx) -> {
         int s = IntegerArgumentType.getInteger(ctx, "slot");
         return each(ctx, "holds hotbar slot " + s, (ap) -> ap.setSlot(s));
      })));
      bot.then(Commands.literal("sneak").executes((ctx) -> each(ctx, "sneaks", (ap) -> ap.setSneaking(true))));
      bot.then(Commands.literal("unsneak").executes((ctx) -> each(ctx, "stops sneaking", (ap) -> ap.setSneaking(false))));
      bot.then(Commands.literal("sprint").executes((ctx) -> each(ctx, "sprints", (ap) -> ap.setSprinting(true))));
      bot.then(Commands.literal("unsprint").executes((ctx) -> each(ctx, "stops sprinting", (ap) -> ap.setSprinting(false))));
      bot.then(Commands.literal("stop").executes((ctx) -> each(ctx, "stops everything", BotPlayerActionPack::stopAll)));
      bot.then(Commands.literal("release").executes(ControlCli::release));
      return (LiteralArgumentBuilder)Commands.literal("control").then(bot);
   }

   public static LiteralArgumentBuilder<CommandSourceStack> move() {
      return (LiteralArgumentBuilder)Commands.literal("move").then(moveDirs(Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST)));
   }

   private static <T extends ArgumentBuilder<CommandSourceStack, T>> T moveDirs(T node) {
      return (T)node.then(Commands.literal("forward").executes((ctx) -> each(ctx, "moves forward", (ap) -> ap.setForward(1.0F)))).then(Commands.literal("backward").executes((ctx) -> each(ctx, "moves backward", (ap) -> ap.setForward(-1.0F)))).then(Commands.literal("left").executes((ctx) -> each(ctx, "moves left", (ap) -> ap.setStrafing(1.0F)))).then(Commands.literal("right").executes((ctx) -> each(ctx, "moves right", (ap) -> ap.setStrafing(-1.0F)))).then(Commands.literal("stop").executes((ctx) -> each(ctx, "stops moving", BotPlayerActionPack::stopMovement)));
   }

   private static void action(ArgumentBuilder<CommandSourceStack, ?> bot, String name, BotPlayerActionPack.ActionType type) {
      bot.then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(name).executes((ctx) -> each(ctx, name + " (once)", (ap) -> ap.start(type, BotPlayerActionPack.Action.once())))).then(Commands.literal("once").executes((ctx) -> each(ctx, name + " (once)", (ap) -> ap.start(type, BotPlayerActionPack.Action.once()))))).then(Commands.literal("continuous").executes((ctx) -> each(ctx, name + " (held)", (ap) -> ap.start(type, BotPlayerActionPack.Action.continuous()))))).then(Commands.literal("interval").then(Commands.argument("ticks", IntegerArgumentType.integer(1, 72000)).executes((ctx) -> {
         int t = IntegerArgumentType.getInteger(ctx, "ticks");
         return each(ctx, name + " every " + t + " ticks", (ap) -> ap.start(type, BotPlayerActionPack.Action.interval(t)));
      })))).then(Commands.literal("stop").executes((ctx) -> each(ctx, "stops " + name, (ap) -> ap.stop(type)))));
   }

   private static int each(CommandContext<CommandSourceStack> ctx, String what, Consumer<BotPlayerActionPack> act) {
      CommandSourceStack src = (CommandSourceStack)ctx.getSource();
      MinecraftServer server = src.getServer();
      return BotTargetArgument.runForEach(ctx, "bot", (name) -> {
         ServerPlayer p = BotManager.resolveTrackedBotPlayer(server, name);
         if (p == null) {
            src.sendFailure(VexText.literal("[VexBot] No bot named '§e" + name + "§r'."));
         } else {
            BotPlayerActionPack ap = Internals.get().actionPack(p);
            if (ap != null) {
               if (MANUAL.add(p.getScoreboardName().toLowerCase(Locale.ROOT))) {
                  ap.stopAll();
                  src.sendSuccess(() -> {
                     String var10000 = p.getScoreboardName();
                     return VexText.literal("[VexBot] " + var10000 + " is under manual control (§e/vexbot control " + p.getScoreboardName() + " release§r gives it back to its AI).");
                  }, false);
               }

               act.accept(ap);
               p.setYHeadRot(p.getYRot());
               src.sendSuccess(() -> {
                  String var10000 = p.getScoreboardName();
                  return VexText.literal("[VexBot] " + var10000 + " " + what + ".");
               }, false);
            }
         }
      });
   }

   private static int release(CommandContext<CommandSourceStack> ctx) {
      CommandSourceStack src = (CommandSourceStack)ctx.getSource();
      MinecraftServer server = src.getServer();
      return BotTargetArgument.runForEach(ctx, "bot", (name) -> {
         ServerPlayer p = BotManager.resolveTrackedBotPlayer(server, name);
         String n = p != null ? p.getScoreboardName() : name;
         boolean was = MANUAL.remove(n.toLowerCase(Locale.ROOT));
         if (p != null) {
            BotPlayerActionPack ap = Internals.get().actionPack(p);
            if (ap != null) {
               ap.stopAll();
            }
         }

         src.sendSuccess(() -> VexText.literal(was ? "[VexBot] " + n + " is back on its AI." : "[VexBot] " + n + " was not under manual control."), false);
      });
   }
}
