package vexbot.command;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.tree.ArgumentCommandNode;
import com.mojang.brigadier.tree.CommandNode;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.IdentifierArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction.Axis;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.minecart.MinecartCommandBlock;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BaseCommandBlock;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.DifficultyKnobs;
import vexbot.DifficultyParams;
import vexbot.EffectiveSettings;
import vexbot.SettingsPersistence;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.bot.ai.FollowFormation;
import vexbot.bot.ai.RestockController;
import vexbot.bot.ai.RestockPlan;
import vexbot.bot.loadout.LootChestOps;
import vexbot.bot.loadout.RandomGearConfig;
import vexbot.bot.loadout.RandomGearGenerator;
import vexbot.combat.CombatRecorder;
import vexbot.compat.McCompat;
import vexbot.extensions.ExtensionPuller;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.gui.EnderChestViewMenu;
import vexbot.gui.InventoryViewMenu;
import vexbot.gui.KitListMenu;
import vexbot.gui.PlayerMenuHelper;
import vexbot.gui.TeamBuilderMenu;
import vexbot.gui.TeamDeleteAllMenu;
import vexbot.gui.TeamDeleteConfirmMenu;
import vexbot.gui.TeamSettingsMenu;
import vexbot.gui.TeamTargetsMenu;
import vexbot.gui.VexBotSettingsMenu;
import vexbot.i18n.VexLang;
import vexbot.i18n.VexText;
import vexbot.kit.KitCli;
import vexbot.kit.KitManager;
import vexbot.kit.KitShareCodec;
import vexbot.march.TeamMarch;
import vexbot.march.TeamSurround;
import vexbot.name.NamePoolShare;
import vexbot.name.NamePoolStorage;
import vexbot.nick.NickCli;
import vexbot.nick.SkinStorage;
import vexbot.nick.TeamSkinCli;
import vexbot.panel.ControlPanel;
import vexbot.path.PathCli;
import vexbot.path.PathManager;
import vexbot.platform.Platform;
import vexbot.settings.GameplaySettingsScope;
import vexbot.settings.SettingsCli;
import vexbot.spawn.SpawnArea;
import vexbot.team.TeamCommand;
import vexbot.team.TeamCreateCli;
import vexbot.team.TeamHornSummon;
import vexbot.team.TeamManager;
import vexbot.team.TeamTargetsCli;
import vexbot.util.BotCommands;
import vexbot.util.NameTagPainter;

public class VexBotCommand {
   private static final Random RNG = new Random();
   private static final Map<String, PovSession> povSessions = new ConcurrentHashMap();
   private static final Predicate<CommandSourceStack> REQUIRES_GAMEMASTER;
   private static final Predicate<CommandSourceStack> REQUIRES_GAMEMASTER_NOT_COMMAND_BLOCK;
   private static final String[] ADJECTIVES;
   private static final String[] NOUNS;
   private static final List<TeamSub> TEAM_SUBS;
   private static final Set<String> TEAM_ROOT_SUBS;
   private static final Map<String, String> TEAM_SUB_ALIASES;
   private static final String NULL_SOLDIER_KIT = "VBK3:eNrVV9tu2zAMVZukdf2wtVvX24Zi9-0b9rQ_EWSZtoXIkiDJyPL3k5KgptLECzagcwM4SEwd-hySksmckDMyA1WCJfGTkaliLYTvTspgER5alwfDdU6m8U9GjkVJbluhgFtW-R8KfAM2mKhbaFtOyIzrTvkAOcpJznVrtALl3YS86UEWDBOWcu02C696GyjeMOXbNeh1b3ANs0aBcwEym5DL3tKpwgKbC1UH02R1TZ3UfiUpIX69izj7BSOgnZigqgQXwecyohJFR6mit7sUGcHnQ6oGmB_Gzwk5p153vIm-D6V-nFK_3KZuGZ8jzj8RdJJCEf1ayxIUZcZILPg9Ak9TMMoo13oOJS0AKoS9QtjZ3gJyRjLXUKO90Gog1GizrNeGAlI-2jJysr6D3Uqtauq8BVX7JgnfyZNQudmmshCV39Rvz-X0Sbjcb3GphAVqwQnnmeKQMMrGk6iXI0rU-egSdTGeRN2MKFG3o0vU3XgS9WFEifo4ukR9In_uzgqt4-t9L6cXPchbETxlLfMByiRuZh78ZeTUMB8WKIyspF6QgeYCMauARVe0YlKuO4zpoc2HsdoDX0UpvttxJD6nkXi3KxIS6jq4_e_B-GexX1Kx97vE8gacD2Xp4dnL_ZrKvdsltwHZgn_2Ur-lUs_xNCFA7p-yzvAWK5hSYYdtBKzGuCyLSKktmRUydNtIHz7H2rAp40EsDDjyAMmlqBtPa8uWCIfIFTbMHQjw6BkoZ2vvtNQLZaPbARTq18OzyzBbeNqZAcCrx4CB1RdowGt0W3RYwaJJqwCp5cJyCQOOUX3wzsplOINtHLT_pnKS8vgefp9U2obSXZXObw1L1Ok";
   private static final String NULL_SKIN_VALUE = "ewogICJ0aW1lc3RhbXAiIDogMTYyMTYzNTM3MzI0NywKICAicHJvZmlsZUlkIiA6ICIyMWUzNjdkNzI1Y2Y0ZTNiYjI2OTJjNGEzMDBhNGRlYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJHZXlzZXJNQyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNDkxZDBiZjhiZWMwNDEzNzc0YjVmOTQyZmYxMjkyY2M5YWRiZjY2ZmRhZmFmZGY0OGI0N2IyZmVmNDMzNGE4IgogICAgfQogIH0KfQ==";
   private static final String NULL_SKIN_SIGNATURE = "iVVrEdeTONKlXcAoywO3+6ayRpRH5DP2Bvl5aso6AvfHZyseHcrxskHwmiYRWn+WaN9eRww27eJ3b9d4kVBtjMTKIWucNwd/Jsp3kWxZJ8lgWDB7sHg46e4aKMaoj1dRDKEZ5GwcpcDmM35MrhYpKF4sK33AAncY13Dfz5eCxzd3UssnRiVQQ4f61kW3a85P+fBrl4j3PbCkfbEOH+n1irO7onvJyAgQfl0B4a/3+7SoeaSWNtgR15RW8rOAguYY4RN26gt8a1kGbgS9jai/64hIrz/vqYb756T/fRNEaKMuLur/Wxejc/Arrm8ai9Tr7ODW42fWfpqeUevRet2Mdc0Mb4XRYDA3A4+xh65BTGnb1UVDmiDCG5+CH9uZUS29Yedn12+zQOqGflg76czPF4UVx3DBO2qURe4dQzXqz9PspO5HXHAs6UlRtBoMxD16veLcXcrYeTKxBGAeQraBizlw60ZQTwTC/sMo3DTeJqL52Ovx19mGwTmm4mfyaoj2Xr3785ra2ZqWGFX4SacimGkNEUz34kapoLvUnHCULqQGiLb4d98o8suaMH6TV7vRZxB9YgLspSHQTiHu3RW7uH2lO3/61KoaxbMbd+9K11S7ds7AmQIwcRmgfCU/PD5MzkI4wiMa33SdHtkJOaZgnbVZImNN7Kw47JJ00F09JeI=";
   private static final String JAMATOP_NAME = "jamatoP";
   private static final String SPOKE_NAME = "SpokeIsHere";
   private static final String NULL_SPECIAL_KIT = "VBK3:eNrNWF1P2zAUNbSFUE0MugEDJsa-9xv2NGnv-wuW49w0Vhzbsx11_fezU0RsSgJqEYSn0utzc-7Judd2pwgdoAmIDDTyfwkaC1IBevWn5hz_JsoSJtwKZqEyU7fgeorG_p8E7bIMnVdMANUktz8F2AK0C2GzkDoboQmVtbAOsjNFUyorJQUIa0bopAVpUIRpTKW5WXjaxkDQgghbrYFypgETo4B60O4IvWljpiBaCTDGRSYj9LaN1CLVQEom5i40ikClkLRMCS09Bx9FY8OlbQSJyj27r1zyD5662I0KCkKQ54wyl3PpUVFFO3FFl_dVpBgt-6rqYf44fobxEltZ08Lnfiz13Zj6rAXJ1LCMEREw_hUARzEwID-XPAOBiVIcOsDjTvCCWNA4rWkJNtQqAE86_WMUJ6bASlomRY_SQYet1jr_COtjCdpbfYMugrRWSzF3Lchye-Oals3es7C5atdwz6VpVw2GGUsEhYjR_rMwOl_Xx2oQc1tEZJJN_XUQA0_C5nCDFSsgmgfYowB7OCiHvB6cQ46G5JDjmEygqpXuWyxzXIts6UZexzyYxQmO2gRUpgtIOwx2uoXBzgZlsHeDM9j5kAx2sa3BLlHX-SznTFhMROaeDMCfdHOParjqNCuVsoQMpwB5h9E_bLPZXg_K6R8H5_RPQ3L6Z_TwRSKV0tuuk85h0B6auUxJ5V3CCA9P0Lf5ErSviHULRIjMuVygHtOHLQTEp8I54Xzl_HHUFEq7JqWNCk0oUDgDZQuvBFvdtO6ch2XNsbvQQLYW6mm0L7GE7--TkMN87rAvrmIwBZp2wUa4qh6otkfcSIivsRBX9wlBCzDW2dzCZlLMwntcZqyDbKbE1tV-69wj2moL4FU8J1_4pbuRpJgmNwWNot4gf2uCibv3CWaXaxfCu031uN743nnQMgUD3v3zxEHY8CkRwh-vVqU3v38kiUdyqdEk5YSWgTLhQK3ciGjaXYFBt5ApZ_PC4rkmywAXkEu1u3oHgLVnxLuPy44zuRDap-1BBS_CPTtz12uLa9UDmK0DelYfB--5kFVahxUsitg_4ZmXacqhJ3HgLFprvnQ7gvbzc-szyg_3eS-X2pm-6a__HMC-Jw";
   private static final String NULL_COMMANDER_KIT = "VBK3:eNrtW9lyozgUVbwkjrM5-9aTnn35hXmaqnmfX6AECKOykBhJlOP--pHsVHMVB8pB6URV4zzFFudw7kV3Aa7HCO2jIeEpkcj-jdCA44Kg438qxqK_RVFgu2aOoZoUamwO-WOMBvbDCPVoim4Lykkicab_5ETnRJqlSM2FTPtomIiKawPZGaNxIopScMK16qPLGiRJiamMEqGeDryq1whPcsx1sQbKqCQRViVJLKjXR-f1msqxLDlRyqwM--iiXql4LAmeUT41S30HNOMimcU4mVkNdhUNFBN66RLH3OuXzMWP5K2N7WQQWCJZRhNqOBcW5Vi041p0_5JFJU1mbVa1KN9Mn6JsFmlRJbnl3lR6z5V-XIMKnHRSewooTBSspO60bzaASQlXVC_Wrsyc8jSKK7m8zv0Wpzjm9V3zgOipYOZUES5LBs38C4AHaIO4LAmW7-Wmk3qNVXxK1oLOO1J7jveGrgPOaoyIFU0p5g2e2230nLXJpLJZJM1JiW7A77n4CXAiW2iJ39Lhm22kkavorgZpYb6NRBZVPF0YKNQGCPZ9Cca-BAcuwSV0lClIkd3JDGAnAHvYmLNVybDKo1JoKnjLdQF7YHWsydlc27UR2l19A21SWgo-NWWPZvppQ9dqjoJSc_wuam7X1WhJ-FTnjpiTkMRM3kXMA8iKVsoybUqiqNKYJ8RRdNpYqWNmMmCk8orNTCzE4rFR1T5MnlYONp-k7ePuQZMThuWwSQlOUS84Rf3XZkjYLXhghx7Y3aZSmYh4TmKnwsIS2w02enU_BWvgh-cmWE9DEnMQkpjDkMQchSTm2CNOT7q0xLCYeuJPmyofeSzNvYxplokpe1o3h-_Zx3ddQM15UGouglJzGZSaq6DUXHvE8I1nDN564u86xrATxdsWeNsCb1vgbQu8bYG3LfC2Bd62wNsWeNsC_79a4HPUjQTsdZcBvEOKJSFfTHsl0gboZVAvL66CUnMd0tuLm5DE3Ab3KuXOVfSphi4IY2L-rW4kN33x2Xjf14Gg50vQ9yUY-BIMfQl2fQn2fAlGvgT7vgRjX4IDX4JDX4IjX4JjX4ITX4KJL8GpL8GZL8G5L8GFL8GlL8GVL8G1L8GNL8GtL8FdNwJIcY9e8RSqhn1qHGybY22LbvWsiYaTQN95jmc9BNU0fg5KzfchdY0_hCTmx-Ba2J82GPCMhbDTg42awMSsltQwjQobgBQz2Np-5RuhvRJrcwCHyMz0y6jD7CKMXILtKaIMM7ZaHzizjaU0KSlZumi5dA1Hbkud22tGVzPrz-aKRcXsmCtJXzN4-3Pj3UHtWkamU4P9cO-CByDLmI4UN1atWfvcgy3TtS9fL8dBv7gOenjJQUlOlDaxoUk3F4Fi8m-Fpf7ytrtvs7l0122OD35tvLOrfZATVriFLKQAdH6JoEoq8ZOhfSfCsHF_hLOM8tVo-063jeU477fGxkHllLC05Z4bpI0Yc24f-a1csvw1ymhkkUxINFy-EQYegzm7MIlmmTRKotBXyJjRaa6jqcQLgJvA52M0mQHA2jncQmvYo1TMubS0LShwIcy5U2oMjaqyBXC2Dmg5Glx_mYsirqAF89zdV7CHozJhpIUY7Likkmxh6o20WfibDbL_bv7fzYQ0QbKMx_8AgGqGsg";
   private static final String SPOKE_KIT = "VBK3:eNrtW8ty2zYUhSRLlpT4FceWH6mrvttFp_uuskxmOu0i2WNAEhQxggAGACMrX99L0hMBksHEZBpxpvbKEnDAg4t7DshLaIzQCPWpiKhC-d8Q7QmyoGjyJpVz-lq_oorivzPOf_-LEugEnZmhCz2Gvr-N0V7-YYi6LEKXCyZoqEhs_hTUJFRBE9ZLqaIe6ocyEwYgnTEah3KRSkGFgUHO1qAw00YucH71nNGtUWSYI9Dhm3yQqYynBSdgaKAVmsbofA2nIkyIMIt83J49bsxgBkSnNMwx3R46XbfphKhUUK2hpd9Dz9ctmQgUJXMmZtDUc0BzIcN5QMJ5wQ5a0Z7m0hThcyJyfV9EUhbOyS2tiIl3UifrBvgmKrl1HNo0jlnIALbampFmfI6NzMJkC-VO1plSx53Smc0N0gGnlChuTebYwnZd7LEdd0a5Py-GNrmAaIpDyaVC_YBD2Ed2qgVEiJwGMYYqUaTlYJiPm_cfczZLDJ4pshqi_bs-No9AwWpo9BFQXsDqO7E4LwjnWBvFUloFsUIEF45gMQzO0grAs21ARW9r7iUXHMml4DS2QcsEwn7_lEOmQk6rtPN5idHzLi7lK9Duf5TgFYz2vKm6ZCLCcCE1s3X30sL2Xex0iyGN8EzyiApM0pT7hhm4w0zuM4Ca4q_lWl5ncAK372WtCV9IgYMsnFNTIdezTcgfmn2gaLCgEcsWY_TCklwxFgYcMyscEUM66Olr8T7joGMScNrpoMErSrhJ3OUdes21kAjWScbnYAWBvPUyHdlhDKUwBD6p3DSuLRd_qOPZdtkA222A7TlY2z0VpR8oVjJyUtaWjQO18i9MpMo0jlXGjA_cd8CWk4VKah3IZZ1UtxreZWDQd9Ld2ogXGTdMJ2Xgq13C1qjvriW_UYA7jTkEayPdX24wP90GQWqN6W3KpWay3Ib2wY5BqSl4Lc_p4wD2jxEaFBate8XeenN9jf4_3TroKC535ChTxECgOu7S7PsUDpEF84QsgbGlMRv-a5uEL5m95m2BRw0EOG6AfdIA-7S-8A-aCP_wUUVtVdHR49K0dWmOGxvcie9W7c7gQqKU9Kr2WQOnOW2Afd4Ae1bf4c6bONzkUUZtldHF49K0dWkuGzvcVc2i0WNZ6AuUhaorbzWLRk6CjPzFhpQTneBU5mlV8dxoTbXsi_Mn-bIQMSi_QTfrPlyKGS6KwIpqpg2BFHQYjVvH6AmqpyLrsaDxCAeNRzhsPMIR8ho9Z6AfIiJQHqW8TpXh84qKx8hX4ZCBZhEjwsP9ZDflqqs1wEj4FssYZyJawdzsy_hrVjUG6LZDP95yWBsY7bWOUf9rMLrYYKSXLDZ3pWtvTW63XPa_BpfJJhejqJiZxKUybA-VUVOTGDcd4EnrFPS0dYwOWsfosEXKPmoRl-P2SPukPVSeNTWJ06YDPG-dgs5ax-i8dYwmLVL2RYu4XLZH2le7puL4TOse-U_Rg2vVlmmhHQfXcqsG58XOG2AnLvbAetyudwjhyIpIJopDc92e_fzPRMwEM6vy8IHdXS6Lw5R959uY58cqH3Cc6aLBcaZLbzSM8CXRlYuxqOevlJYe1HXrlPQCPfCF0Rr6Ddq1d6-53LSIy7cNhDlFD39juUZ_10AE33-CdZhQbV-3a2F_QJ8-2xxImRuFN_6HluoUg5GGC2IASrhd1vs4nlWXt_SqWIBqnJi0S6WU5FfAMeG8bN9zLCiF6NOwyIaiyVqhiKYmKd5tlMfD3ROFWmYc65TSaKupwtZ-dCP74r7IcjqbAXbXwbVPNea6wFrApLYmuxnAivOY9y-XE5-f3Pjc3BefInPBBQytFyFrF4NNySQrbawAHdqbllyiL3lgtyJwThR-9la111FIKF9UnErdrQCt3IF9KmXly9IyBJbCyLuMYBLbdxJ1MsuJ3S-13gjU-GHGyduETt_mY07_iaf5j0Ts32ZYIc7JPBjvDbn11tLAvbHI96qxY3nviWA6gQniMFOabmnsV_h_EEsF6VBk3r_Agrm-";
   private static final String NULL_COMMANDER_NAME = "_________";
   private static final String[] NULL_COMMANDER_NAMES;
   private static final int NULL_MAX_COMMANDERS = 1;
   private static final int NULL_MAX_SPECIALS = 7;
   private static final String JAMATOP_KIT = "VBK3:eNrNWktz2zYQhk1LoRXH9Vt-1XHbpI-DZpyM6zY5dXrsoeOZZnrlQORSxAgCGACs5PzA_qieuqTdIRCbSi22Ng4eW1zu8tuP-y25WvcICcmKoBMgO7_QCTVycDn4teB8cCmVoXyVdJiBie4RQr7rkZXyQ0iWWUIOJkxArGhq3gowGSg0RXoqVRKQTiwLYdBlqUd6sZzkUoAwGGSvdgIRZ1SYSWkIyGZtwCMJE6PSOyC79fGUKYioziEuIy8HZLu26YyqXIDWaOkEZKe2FGKogI6vAwYB6VtOU4AcDREkIyit1c-K5rK8ACFOuv270qUzWCTZhYBbJkhTFjOMeVV6IeaN2pbgTayyObSTWXKTObormZzF4wUTarp7_2E6fTudZTedXRtXAirKgSpuJbJh-QaNVMAsRyYQB0RDaQy3qfjJirDiRtiqI8ihZgmjosGxQ5oUlHImTERFEmkDwB_kHjjV3nWhHdZORuLRSKZRIZIrdJ2DzboPcaGNnERlY8EWAjOjaFjV4dq7Mt7pb4ZqprH1GLRVWrvtnFBDe2TrshhyFv9cjMfM_E55Aeh2HKNswBimb_DpKl6E7YcnpFP9Wib7DWd9WNoIGo0z8qd-G5Lt2lzSEhUF0vLi_CwBeP3D-SCFJBmcp9-fDX58cx4PLl6fXVwME_rm1avz5utekb-Iw_oTl_XTW_cWkmgkeQIionnuFGTXChM2tiqdc6qzKJeGSTHnzlmleH1uFEu8OtpC0r0-Qk7qc7jErln1YwWYmKGoGSex1QdBtP8RIj1lqblppjWW3oNgsc7RRlVojAIxMpkD5mnr7rPWOsIznwhZ9wnMZz6B2VioJVsBNr1rC1setYVtF4v1mMSHJHzAHGTSIKCd1hLcbR1hz6dS7fsEZt8nMAdtRXzonYiPPBLxceMgMGX4Mo3vUGrUpKDPW2vwpDHCkNN4HOms4GMcR4Zy1shG2PDWjEM5TuGr9qxYkkTxkyqH8SNrUl2oxOzp8NEFY892PoEJ_BCfPXw-tvjsedYjLN37fiNgj2ELT2GBHSacDyHOQBvLt-MMTG013PNJNk99ArPmnYafeaSb9Xu-BdvT0mLPT3vEaR1hs3WErbbK2_ap2Hd8ArPrnfL2HETWd6kN_d2plP7iUtlvXaYHrSMcLhjBjvGc3PcZV_ueknuTXzt_4dNQ96VPYL4in17LDaUsVwSNcNatrqcYRgon1KAr5fZaASagKE9C8iSnBs3C9ku5nJJ264lcYceNq9zxPddZ1SWQm6zMn2GV3VogzdlrvHDZOb6LHQ6jEfo-MkG79mISH9WRFpjTrVw_JmnOiu1uyh16Xrr0nNxFT6VprGsD3lfQnCWjy5tDwteNA3RNQgZ8AsZPAqzKwedezhS9SdNdd9P3BY1omjLBzNUnxffv5PXN_7c2DEsHLhVZKYH_syncfJfB6fUKUaan5T8qzGPMaoZ_UMF0Vm7740JpuKWEb_HvbioV3rWqQP4GVOPp6Q";
   private static final SuggestionProvider<CommandSourceStack> SUGGEST_PATHS;
   private static final String[] DIFFICULTY_KNOBS;
   private static final String[] LEVEL_NAMES;
   private static final String[] DIFFICULTY_PRESETS;
   private static final String[] TEAM_ORDER_TOGGLES;
   public static final String DISCORD_INVITE = "https://discord.gg/ZYZMC2rRt6";
   private static final Item[] RESTOCK_SHOWCASE;
   private static final Map<String, FfaDeal> FFA_DEALS;

   private static boolean isCommandBlockSource(CommandSourceStack stack) {
      CommandSource output = stack.source;
      return output instanceof BaseCommandBlock.CloseableCommandBlockSource ? true : stack.getEntity() instanceof MinecartCommandBlock;
   }

   private static List<String> poolNames(String teamName) {
      MinecraftServer server = VexBot.SERVER;
      if (server != null) {
         String pool = "";
         if (teamName != null) {
            TeamManager.BotTeam team = resolveTeamByName(teamName);
            if (team != null && team.namePool != null) {
               pool = team.namePool;
            }
         }

         if (pool.isBlank()) {
            pool = BotSettings.namePool;
         }

         if (pool != null && !pool.isBlank()) {
            NamePoolStorage.LoadResult res = NamePoolStorage.load(server, pool);
            if (res.ok() && !res.names().isEmpty()) {
               return res.names();
            }
         }
      }

      return null;
   }

   private static List<String> freePoolNames(MinecraftServer server, String teamName) {
      List<String> names = poolNames(teamName);
      if (names == null) {
         return null;
      } else {
         List<String> free = new ArrayList();

         for(String n : names) {
            if (BotManager.peekSpawnStaticBlockReason(server, n) == null) {
               free.add(n);
            }
         }

         return free;
      }
   }

   private static String freeBotName(MinecraftServer server, String teamName) {
      List<String> free = freePoolNames(server, teamName);
      if (free != null && !free.isEmpty()) {
         return (String)free.get(RNG.nextInt(free.size()));
      } else {
         for(int attempt = 0; attempt < 200; ++attempt) {
            String candidate = randomBotName();
            if (BotManager.peekSpawnStaticBlockReason(server, candidate) == null) {
               return candidate;
            }
         }

         return randomBotName();
      }
   }

   private static String randomBotName() {
      int roll = RNG.nextInt(100);
      if (roll < 2) {
         String var4 = ADJECTIVES[RNG.nextInt(ADJECTIVES.length)];
         String base = var4 + NOUNS[RNG.nextInt(NOUNS.length)];
         switch (RNG.nextInt(3)) {
            case 0 -> var4 = "_" + base + "_";
            case 1 -> var4 = "x" + base + "x";
            default -> var4 = "x_" + base + "_x";
         }

         String decorated = var4;
         return decorated.length() <= 16 ? decorated : base;
      } else if (roll < 85 && BotNamePool.NAMES.length > 0) {
         return BotNamePool.NAMES[RNG.nextInt(BotNamePool.NAMES.length)];
      } else {
         String var10000 = ADJECTIVES[RNG.nextInt(ADJECTIVES.length)];
         String base = var10000 + NOUNS[RNG.nextInt(NOUNS.length)];
         return base;
      }
   }

   public static void register() {
      Platform.get().registerCommands((dispatcher) -> VexLang.wrapCommands(dispatcher.register(tree())));
   }

   public static LiteralArgumentBuilder<CommandSourceStack> tree() {
      TEAM_SUBS.clear();
      LiteralArgumentBuilder<CommandSourceStack> root = (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("vexbot").then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("spawn").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> spawnBot((CommandSourceStack)ctx.getSource(), freeBotName(((CommandSourceStack)ctx.getSource()).getServer(), (String)null)))).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> spawnBotAt((CommandSourceStack)ctx.getSource(), freeBotName(((CommandSourceStack)ctx.getSource()).getServer(), (String)null), Vec3Argument.getVec3(ctx, "pos"))))).then(((RequiredArgumentBuilder)Commands.argument("name", StringArgumentType.word()).executes((ctx) -> spawnBot((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))).then(((RequiredArgumentBuilder)Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> spawnBotAt((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name"), Vec3Argument.getVec3(ctx, "pos")))).then(((RequiredArgumentBuilder)Commands.argument("kit", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)c.getSource()).getServer()), b)).executes((ctx) -> spawnBotAtWithKit((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name"), Vec3Argument.getVec3(ctx, "pos"), StringArgumentType.getString(ctx, "kit"), (String)null))).then(Commands.argument("team", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> spawnBotAtWithKit((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name"), Vec3Argument.getVec3(ctx, "pos"), StringArgumentType.getString(ctx, "kit"), StringArgumentType.getString(ctx, "team"))))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("spawnarea").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> spawnAreaShow((CommandSourceStack)ctx.getSource()))).then(Commands.literal("show").executes((ctx) -> spawnAreaShow((CommandSourceStack)ctx.getSource())))).then(Commands.literal("clear").executes((ctx) -> spawnAreaClear((CommandSourceStack)ctx.getSource())))).then(Commands.literal("off").executes((ctx) -> spawnAreaClear((CommandSourceStack)ctx.getSource())))).then(Commands.literal("here").then(Commands.argument("radius", IntegerArgumentType.integer(1, 512)).executes((ctx) -> spawnAreaHere((CommandSourceStack)ctx.getSource(), IntegerArgumentType.getInteger(ctx, "radius")))))).then(Commands.literal("set").then(Commands.argument("from", Vec3Argument.vec3()).then(Commands.argument("to", Vec3Argument.vec3()).executes((ctx) -> spawnAreaSet((CommandSourceStack)ctx.getSource(), Vec3Argument.getVec3(ctx, "from"), Vec3Argument.getVec3(ctx, "to")))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("kill").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> killAll((CommandSourceStack)ctx.getSource()))).then(Commands.argument("name", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         BotTargetArgument.Target patt0$temp = BotTargetArgument.get(ctx, "name");
         if (patt0$temp instanceof BotTargetArgument.Named n) {
            if (BotManager.resolveTrackedBotPlayer(((CommandSourceStack)ctx.getSource()).getServer(), n.name()) == null && BotManager.getBotNames().stream().anyMatch((b) -> b.equalsIgnoreCase(n.name()))) {
               return killOne((CommandSourceStack)ctx.getSource(), n.name());
            }
         }

         return BotTargetArgument.runForEach(ctx, "name", (nx) -> killOne((CommandSourceStack)ctx.getSource(), nx));
      })))).then(((LiteralArgumentBuilder)Commands.literal("version").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> showVersion((CommandSourceStack)ctx.getSource())))).then(Commands.literal("discord").executes((ctx) -> discordLink((CommandSourceStack)ctx.getSource())))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("extensions").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> ExtensionPuller.list((CommandSourceStack)ctx.getSource()))).then(Commands.literal("list").executes((ctx) -> ExtensionPuller.list((CommandSourceStack)ctx.getSource())))).then(Commands.literal("pull").then(Commands.argument("extension", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"bounty-sim"}, b)).executes((ctx) -> ExtensionPuller.pull((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "extension")))))).then(Commands.literal("unload").then(Commands.argument("extension", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"bounty-sim"}, b)).executes((ctx) -> ExtensionPuller.unload((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "extension")))))).then(Commands.literal("update").executes((ctx) -> ExtensionPuller.update((CommandSourceStack)ctx.getSource()))))).then(((LiteralArgumentBuilder)Commands.literal("list").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> listBots((CommandSourceStack)ctx.getSource())))).then(viewTree("view"))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("tag").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> tagStatus((CommandSourceStack)ctx.getSource()))).then(Commands.literal("on").executes((ctx) -> setTags((CommandSourceStack)ctx.getSource(), true)))).then(Commands.literal("off").executes((ctx) -> setTags((CommandSourceStack)ctx.getSource(), false))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("prefer").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> SettingsCli.showOne((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.global(), "offhand"))).then(Commands.argument("mode", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"totem", "shield", "auto"}, b)).executes((ctx) -> SettingsCli.apply((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.global(), "offhand", StringArgumentType.getString(ctx, "mode")))))).then(languageNode())).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("settings").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> settingsRoot((CommandSourceStack)ctx.getSource()))).then(languageNode())).then(Commands.literal("list").executes((ctx) -> SettingsCli.listAll((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.global())))).then(Commands.literal("bot").then(((LiteralArgumentBuilder)Commands.literal("ping").executes((ctx) -> settingsShow((CommandSourceStack)ctx.getSource(), "botping"))).then(Commands.argument("ms", IntegerArgumentType.integer(0, 5000)).executes((ctx) -> settingsApply((CommandSourceStack)ctx.getSource(), "botping", String.valueOf(IntegerArgumentType.getInteger(ctx, "ms")))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("stun").executes((ctx) -> settingsShow((CommandSourceStack)ctx.getSource(), "stunslam"))).then(Commands.argument("value", StringArgumentType.word()).suggests((ctx, builder) -> SettingsCli.suggestValues((CommandSourceStack)ctx.getSource(), builder, "stunslam")).executes((ctx) -> settingsApply((CommandSourceStack)ctx.getSource(), "stunslam", StringArgumentType.getString(ctx, "value"))))).then(Commands.literal("slam").then(((LiteralArgumentBuilder)Commands.literal("chance").executes((ctx) -> SettingsCli.showOne((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.global(), "stunslamchance"))).then(Commands.argument("percent", IntegerArgumentType.integer(0, 100)).executes((ctx) -> SettingsCli.apply((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.global(), "stunslamchance", String.valueOf(IntegerArgumentType.getInteger(ctx, "percent"))))))))).then(((RequiredArgumentBuilder)Commands.argument("setting", StringArgumentType.word()).suggests((ctx, builder) -> SettingsCli.suggestSettings((CommandSourceStack)ctx.getSource(), builder)).executes((ctx) -> settingsShow((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "setting")))).then(Commands.argument("value", StringArgumentType.word()).suggests((ctx, builder) -> SettingsCli.suggestValues((CommandSourceStack)ctx.getSource(), builder, StringArgumentType.getString(ctx, "setting"))).executes((ctx) -> settingsApply((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "setting"), StringArgumentType.getString(ctx, "value"))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("restock").requires(REQUIRES_GAMEMASTER)).then(((LiteralArgumentBuilder)Commands.literal("list").executes((ctx) -> restockList((CommandSourceStack)ctx.getSource(), (String)null))).then(Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> restockList((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))))).then(Commands.literal("defaults").executes((ctx) -> restockDefaults((CommandSourceStack)ctx.getSource())))).then(((LiteralArgumentBuilder)Commands.literal("clear").executes((ctx) -> restockClear((CommandSourceStack)ctx.getSource(), (String)null))).then(Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> restockClear((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))))).then(Commands.literal("set").then(Commands.argument("item", IdentifierArgument.id()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"ender_pearl", "golden_apple", "enchanted_golden_apple", "experience_bottle", "firework_rocket", "totem_of_undying", "tnt_minecart", "rail", "cobweb", "end_crystal", "obsidian", "splash_potion", "wind_charge", "arrow"}, b)).then(((RequiredArgumentBuilder)Commands.argument("count", IntegerArgumentType.integer(0, 640)).executes((ctx) -> restockSet((CommandSourceStack)ctx.getSource(), (String)null, IdentifierArgument.getId(ctx, "item").toString(), IntegerArgumentType.getInteger(ctx, "count")))).then(Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> restockSet((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), IdentifierArgument.getId(ctx, "item").toString(), IntegerArgumentType.getInteger(ctx, "count"))))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("pickuploot").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> settingsShow((CommandSourceStack)ctx.getSource(), "pickuploot"))).then(Commands.argument("value", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(new String[]{"on", "off"}, builder)).executes((ctx) -> settingsApply((CommandSourceStack)ctx.getSource(), "pickuploot", StringArgumentType.getString(ctx, "value")))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("difficulty").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("preset").then(Commands.argument("level", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(DIFFICULTY_PRESETS, b)).executes((ctx) -> setGlobalDifficultyPreset((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "level")))))).then(Commands.literal("list").executes((ctx) -> difficultyList((CommandSourceStack)ctx.getSource(), BotSettings.difficultyParams, "global")))).then(Commands.literal("player").then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("bot", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(BotManager.getBotNames(), b)).then(Commands.literal("list").executes((ctx) -> botDifficultyList((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "bot"))))).then(Commands.literal("clear").executes((ctx) -> botDifficultyClear((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "bot"))))).then(Commands.literal("preset").then(Commands.argument("level", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(DIFFICULTY_PRESETS, b)).executes((ctx) -> botDifficultyPreset((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "bot"), StringArgumentType.getString(ctx, "level")))))).then(((RequiredArgumentBuilder)Commands.argument("knob", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(DIFFICULTY_KNOBS, b)).then(Commands.argument("value", DoubleArgumentType.doubleArg()).executes((ctx) -> botDifficultyKnob((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "bot"), StringArgumentType.getString(ctx, "knob"), DoubleArgumentType.getDouble(ctx, "value"))))).then(Commands.argument("level", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(LEVEL_NAMES, b)).executes((ctx) -> botDifficultyKnobNamed((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "bot"), StringArgumentType.getString(ctx, "knob"), StringArgumentType.getString(ctx, "level")))))))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("knob", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(DIFFICULTY_KNOBS, b)).executes((ctx) -> difficultyKnobPresets((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "knob")))).then(Commands.argument("value", DoubleArgumentType.doubleArg()).executes((ctx) -> setDifficultyKnob((CommandSourceStack)ctx.getSource(), BotSettings.difficultyParams, "global", StringArgumentType.getString(ctx, "knob"), DoubleArgumentType.getDouble(ctx, "value"))))).then(Commands.argument("level", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(LEVEL_NAMES, b)).executes((ctx) -> setDifficultyKnobNamed((CommandSourceStack)ctx.getSource(), BotSettings.difficultyParams, "global", StringArgumentType.getString(ctx, "knob"), StringArgumentType.getString(ctx, "level"))))))).then(teamSub("difficulty", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamdifficulty").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).then(Commands.literal("list").executes((ctx) -> difficultyListTeam((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("preset").then(Commands.argument("level", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(DIFFICULTY_PRESETS, b)).executes((ctx) -> setTeamDifficultyPreset((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "level")))))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("knob", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(DIFFICULTY_KNOBS, b)).executes((ctx) -> difficultyKnobPresets((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "knob")))).then(Commands.argument("value", DoubleArgumentType.doubleArg()).executes((ctx) -> setDifficultyKnobTeam((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "knob"), DoubleArgumentType.getDouble(ctx, "value"))))).then(Commands.argument("level", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(LEVEL_NAMES, b)).executes((ctx) -> setDifficultyKnobTeamNamed((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "knob"), StringArgumentType.getString(ctx, "level"))))))))).then(((LiteralArgumentBuilder)Commands.literal("mass_spawn").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("count", IntegerArgumentType.integer(1, 1000)).executes((ctx) -> massSpawn((CommandSourceStack)ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count")))).then(((LiteralArgumentBuilder)Commands.literal("randomgear").executes((ctx) -> massSpawnWithPivot((CommandSourceStack)ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count"), computeMassSpawnPivot((CommandSourceStack)ctx.getSource()), true))).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> massSpawnWithPivot((CommandSourceStack)ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count"), pivotAt((CommandSourceStack)ctx.getSource(), Vec3Argument.getVec3(ctx, "pos")), true))))).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> massSpawnAt((CommandSourceStack)ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count"), Vec3Argument.getVec3(ctx, "pos"))))))).then(teamSub("massspawn", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teammass_spawn").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).then(((RequiredArgumentBuilder)Commands.argument("amount", IntegerArgumentType.integer(1, 1000)).then(((LiteralArgumentBuilder)Commands.literal("randomgear").executes((ctx) -> teamMassSpawn((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), IntegerArgumentType.getInteger(ctx, "amount"), (String)null, computeMassSpawnPivot((CommandSourceStack)ctx.getSource())))).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> teamMassSpawn((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), IntegerArgumentType.getInteger(ctx, "amount"), (String)null, pivotAt((CommandSourceStack)ctx.getSource(), Vec3Argument.getVec3(ctx, "pos"))))))).then(((RequiredArgumentBuilder)Commands.argument("kit", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)c.getSource()).getServer()), b)).executes((ctx) -> teamMassSpawn((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), IntegerArgumentType.getInteger(ctx, "amount"), StringArgumentType.getString(ctx, "kit")))).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> teamMassSpawnAt((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), IntegerArgumentType.getInteger(ctx, "amount"), StringArgumentType.getString(ctx, "kit"), Vec3Argument.getVec3(ctx, "pos")))))))))).then(((LiteralArgumentBuilder)Commands.literal("createkit").requires(REQUIRES_GAMEMASTER_NOT_COMMAND_BLOCK)).then(Commands.argument("name", StringArgumentType.word()).executes((ctx) -> createKit((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))))).then(((LiteralArgumentBuilder)Commands.literal("updatekit").requires(REQUIRES_GAMEMASTER_NOT_COMMAND_BLOCK)).then(Commands.argument("name", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes((ctx) -> KitCli.updateKit((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "name")))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("deletekit").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> deletekitRoot((CommandSourceStack)ctx.getSource()))).then(Commands.literal("list").executes((ctx) -> KitCli.listKits((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer())))).then(Commands.argument("kit", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes((ctx) -> KitCli.deleteKit((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "kit")))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("givekit").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> givekitRoot((CommandSourceStack)ctx.getSource()))).then(Commands.literal("list").executes((ctx) -> KitCli.listKits((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer())))).then(((RequiredArgumentBuilder)Commands.argument("kit", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes((ctx) -> givekitNeedPlayer((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "kit")))).then(Commands.argument("player", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String kit = StringArgumentType.getString(ctx, "kit");
         return BotTargetArgument.runForEach(ctx, "player", (name) -> KitCli.giveToPlayer((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), kit, name));
      }))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("givekitall").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> givekitallRoot((CommandSourceStack)ctx.getSource()))).then(Commands.argument("kit", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes((ctx) -> KitCli.giveToAll((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "kit")))))).then(((LiteralArgumentBuilder)Commands.literal("kiticon").requires(REQUIRES_GAMEMASTER_NOT_COMMAND_BLOCK)).executes((ctx) -> openKitIconMenu((CommandSourceStack)ctx.getSource())))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("getkitid").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> getkitidRoot((CommandSourceStack)ctx.getSource()))).then(Commands.argument("kit", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes((ctx) -> KitCli.getKitId((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "kit")))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("givekitid").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("target", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).then(Commands.argument("kitId", StringArgumentType.greedyString()).executes((ctx) -> {
         CommandSourceStack src = (CommandSourceStack)ctx.getSource();
         String saved = KitCli.importKitId(src, src.getServer(), StringArgumentType.getString(ctx, "kitId"));
         return saved == null ? 0 : BotTargetArgument.runForEach(ctx, "target", (name) -> KitCli.giveToPlayer(src, src.getServer(), saved, name));
      })))).then(Commands.argument("kitId", StringArgumentType.greedyString()).executes((ctx) -> KitCli.giveKitId((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "kitId")))))).then(teamSub("kitid", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamgivekitid").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).then(Commands.argument("kitId", StringArgumentType.greedyString()).executes((ctx) -> KitCli.giveTeamKitId((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "kitId")))))))).then(((LiteralArgumentBuilder)Commands.literal("givekitallid").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("kitId", StringArgumentType.greedyString()).executes((ctx) -> KitCli.giveAllKitId((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "kitId")))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("path").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("list").executes((ctx) -> PathCli.list((CommandSourceStack)ctx.getSource())))).then(Commands.literal("create").then(Commands.argument("name", StringArgumentType.word()).executes((ctx) -> PathCli.create((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))))).then(Commands.literal("add").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).executes((ctx) -> PathCli.add((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))))).then(Commands.literal("info").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).executes((ctx) -> PathCli.info((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))))).then(Commands.literal("show").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).executes((ctx) -> PathCli.show((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))))).then(Commands.literal("delete").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).executes((ctx) -> PathCli.delete((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))))).then(Commands.literal("removepoint").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).then(Commands.argument("index", IntegerArgumentType.integer(1)).executes((ctx) -> PathCli.removePoint((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name"), IntegerArgumentType.getInteger(ctx, "index"))))))).then(Commands.literal("mode").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).then(Commands.argument("mode", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"once", "loop", "pingpong"}, b)).executes((ctx) -> PathCli.mode((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name"), StringArgumentType.getString(ctx, "mode"))))))).then(Commands.literal("walk").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).then(Commands.argument("walk", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"walk", "sprint", "bunnyhop"}, b)).executes((ctx) -> PathCli.walk((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name"), StringArgumentType.getString(ctx, "walk"))))))).then(Commands.literal("assign").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).then(Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String path = StringArgumentType.getString(ctx, "name");
         return BotTargetArgument.runForEach(ctx, "bot", (n) -> PathCli.assign((CommandSourceStack)ctx.getSource(), path, n));
      }))))).then(Commands.literal("spread").then(Commands.argument("name", StringArgumentType.word()).suggests(SUGGEST_PATHS).then(Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String path = StringArgumentType.getString(ctx, "name");
         List<String> names = new ArrayList();
         Objects.requireNonNull(names);
         BotTargetArgument.runForEach(ctx, "bot", names::add);

         for(int i = 0; i < names.size(); ++i) {
            PathCli.spread((CommandSourceStack)ctx.getSource(), path, (String)names.get(i), i, names.size());
         }

         return names.size();
      }))))).then(Commands.literal("stop").then(Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> BotTargetArgument.runForEach(ctx, "bot", (n) -> PathCli.stop((CommandSourceStack)ctx.getSource(), n))))))).then(teamSub("create", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamcreate").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).executes((ctx) -> teamcreateRoot((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))).then(Commands.literal("list").executes((ctx) -> TeamCreateCli.show((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("addbot").then(Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String team = StringArgumentType.getString(ctx, "teamName");
         return BotTargetArgument.runForEach(ctx, "bot", (name) -> TeamCreateCli.addBot((CommandSourceStack)ctx.getSource(), team, name));
      })))).then(Commands.literal("removebot").then(Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String team = StringArgumentType.getString(ctx, "teamName");
         return BotTargetArgument.runForEach(ctx, "bot", (name) -> TeamCreateCli.removeBot((CommandSourceStack)ctx.getSource(), team, name));
      })))).then(Commands.literal("addplayer").then(Commands.argument("player", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String team = StringArgumentType.getString(ctx, "teamName");
         return BotTargetArgument.runForEach(ctx, "player", (name) -> TeamCreateCli.addPlayer((CommandSourceStack)ctx.getSource(), team, name));
      })))).then(Commands.literal("removeplayer").then(Commands.argument("player", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String team = StringArgumentType.getString(ctx, "teamName");
         return BotTargetArgument.runForEach(ctx, "player", (name) -> TeamCreateCli.removePlayer((CommandSourceStack)ctx.getSource(), team, name));
      })))).then(Commands.literal("clearbots").executes((ctx) -> TeamCreateCli.clearBots((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("clearplayers").executes((ctx) -> TeamCreateCli.clearPlayers((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("clear").executes((ctx) -> TeamCreateCli.clearRoster((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))))))).then(teamSub("members", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teammembers").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).executes((ctx) -> openTeamBuilderGui((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), true))).then(Commands.literal("add").then(Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> teamMembersAdd(ctx, StringArgumentType.getString(ctx, "teamName")))))).then(Commands.literal("addall").executes((ctx) -> teamMembersAddAll((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("addnear").then(Commands.argument("radius", DoubleArgumentType.doubleArg((double)0.0F)).executes((ctx) -> teamMembersAddNear((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), DoubleArgumentType.getDouble(ctx, "radius")))))).then(Commands.literal("remove").then(Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> teamMembersRemove(ctx, StringArgumentType.getString(ctx, "teamName")))))).then(Commands.literal("clear").executes((ctx) -> TeamCreateCli.clearBots((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("list").executes((ctx) -> TeamCreateCli.show((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))))))).then(teamSub("settings", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamsettings").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).executes((ctx) -> teamSettingsRoot((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))).then(Commands.literal("search").then(Commands.argument("query", StringArgumentType.greedyString()).executes((ctx) -> teamSettingsSearch((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "query")))))).then(teamOrdersShow())).then(teamOrdersFormation())).then(teamOrdersBoss())).then(teamOrdersHorn())).then(teamOrderToggle(TEAM_ORDER_TOGGLES[0]))).then(teamOrderToggle(TEAM_ORDER_TOGGLES[1]))).then(teamOrderToggle(TEAM_ORDER_TOGGLES[2]))).then(teamOrderToggle(TEAM_ORDER_TOGGLES[3]))).then(teamOrderToggle(TEAM_ORDER_TOGGLES[4]))).then(Commands.literal("list").executes((ctx) -> SettingsCli.listAll((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.forTeam(StringArgumentType.getString(ctx, "teamName")))))).then(Commands.literal("bot").then(((LiteralArgumentBuilder)Commands.literal("ping").executes((ctx) -> SettingsCli.showOne((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.forTeam(StringArgumentType.getString(ctx, "teamName")), "botping"))).then(Commands.argument("ms", IntegerArgumentType.integer(0, 5000)).executes((ctx) -> teamSettingsApply((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), "botping", String.valueOf(IntegerArgumentType.getInteger(ctx, "ms")))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("stun").executes((ctx) -> teamSettingsShow((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), "stunslam"))).then(Commands.argument("value", StringArgumentType.word()).suggests((ctx, builder) -> SettingsCli.suggestValues((CommandSourceStack)ctx.getSource(), builder, "stunslam")).executes((ctx) -> teamSettingsApply((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), "stunslam", StringArgumentType.getString(ctx, "value"))))).then(Commands.literal("slam").then(((LiteralArgumentBuilder)Commands.literal("chance").executes((ctx) -> SettingsCli.showOne((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.forTeam(StringArgumentType.getString(ctx, "teamName")), "stunslamchance"))).then(Commands.argument("percent", IntegerArgumentType.integer(0, 100)).executes((ctx) -> SettingsCli.apply((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.forTeam(StringArgumentType.getString(ctx, "teamName")), "stunslamchance", String.valueOf(IntegerArgumentType.getInteger(ctx, "percent"))))))))).then(((RequiredArgumentBuilder)Commands.argument("setting", StringArgumentType.word()).suggests((ctx, builder) -> SettingsCli.suggestSettings((CommandSourceStack)ctx.getSource(), builder)).executes((ctx) -> teamSettingsShow((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "setting")))).then(Commands.argument("value", StringArgumentType.word()).suggests((ctx, builder) -> SettingsCli.suggestValues((CommandSourceStack)ctx.getSource(), builder, StringArgumentType.getString(ctx, "setting"))).executes((ctx) -> teamSettingsApply((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "setting"), StringArgumentType.getString(ctx, "value"))))))))).then(teamSub("targets", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamtargets").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).executes((ctx) -> teamtargetsRoot((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))).then(Commands.literal("list").executes((ctx) -> TeamTargetsCli.show((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("mode").then(Commands.argument("mode", StringArgumentType.word()).suggests((ctx, builder) -> TeamTargetsCli.suggestModes((CommandSourceStack)ctx.getSource(), builder)).executes((ctx) -> TeamTargetsCli.setMode((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "mode")))))).then(Commands.literal("add").then(Commands.argument("player", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String team = StringArgumentType.getString(ctx, "teamName");
         return BotTargetArgument.runForEach(ctx, "player", (name) -> TeamTargetsCli.addTarget((CommandSourceStack)ctx.getSource(), team, name));
      })))).then(Commands.literal("remove").then(Commands.argument("player", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String team = StringArgumentType.getString(ctx, "teamName");
         return BotTargetArgument.runForEach(ctx, "player", (name) -> TeamTargetsCli.removeTarget((CommandSourceStack)ctx.getSource(), team, name));
      })))).then(Commands.literal("clear").executes((ctx) -> TeamTargetsCli.clearTargets((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("addteam").then(Commands.argument("otherTeam", StringArgumentType.word()).suggests((ctx, builder) -> TeamTargetsCli.suggestOtherTeams((CommandSourceStack)ctx.getSource(), builder, StringArgumentType.getString(ctx, "teamName"))).executes((ctx) -> TeamTargetsCli.addTargetTeam((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "otherTeam")))))).then(Commands.literal("removeteam").then(Commands.argument("otherTeam", StringArgumentType.word()).suggests((ctx, builder) -> TeamTargetsCli.suggestOtherTeams((CommandSourceStack)ctx.getSource(), builder, StringArgumentType.getString(ctx, "teamName"))).executes((ctx) -> TeamTargetsCli.removeTargetTeam((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "otherTeam")))))).then(Commands.literal("clearteams").executes((ctx) -> TeamTargetsCli.clearTargetTeams((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("revenge").then(Commands.argument("value", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(new String[]{"on", "off", "toggle"}, builder)).executes((ctx) -> {
         try {
            return TeamTargetsCli.setRevenge((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "value"));
         } catch (IllegalArgumentException e) {
            ((CommandSourceStack)ctx.getSource()).sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
            return 0;
         }
      }))))))).then(teamSub("delete", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamdelete").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).executes((ctx) -> openTeamDeleteConfirm((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))).then(Commands.literal("confirm").executes((ctx) -> teamDeleteNow((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))))))).then(teamSub("allies", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamalliance").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).then(Commands.literal("list").executes((ctx) -> teamAllianceList((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("clear").executes((ctx) -> teamAllianceClear((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("add").then(Commands.argument("teamName2", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> teamAlliance((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "teamName2"), true))))).then(Commands.literal("remove").then(Commands.argument("teamName2", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> teamAlliance((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "teamName2"), false)))))))).then(teamSub("kit", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamgivekit").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).executes((ctx) -> teamgivekitRoot((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))).then(Commands.argument("kit", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes((ctx) -> KitCli.giveToTeam((CommandSourceStack)ctx.getSource(), ((CommandSourceStack)ctx.getSource()).getServer(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "kit")))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("attack").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("stop").then(Commands.argument("botName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> BotTargetArgument.runForEach(ctx, "botName", (name) -> stopAttack((CommandSourceStack)ctx.getSource(), name)))))).then(Commands.argument("playerName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).then(Commands.argument("botName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String player = BotTargetArgument.firstName((CommandSourceStack)ctx.getSource(), BotTargetArgument.get(ctx, "playerName"));
         if (player == null) {
            ((CommandSourceStack)ctx.getSource()).sendFailure(VexText.literal("[VexBot] No target matched."));
            return 0;
         } else {
            return BotTargetArgument.runForEach(ctx, "botName", (name) -> startAttack((CommandSourceStack)ctx.getSource(), player, name));
         }
      }))))).then(((LiteralArgumentBuilder)Commands.literal("follow").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)Commands.argument("botName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).then(Commands.literal("stop").executes((ctx) -> BotTargetArgument.runForEach(ctx, "botName", (name) -> stopFollow((CommandSourceStack)ctx.getSource(), name))))).then(Commands.argument("playerName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         String player = BotTargetArgument.firstName((CommandSourceStack)ctx.getSource(), BotTargetArgument.get(ctx, "playerName"));
         if (player == null) {
            ((CommandSourceStack)ctx.getSource()).sendFailure(VexText.literal("[VexBot] No player matched."));
            return 0;
         } else {
            return BotTargetArgument.runForEach(ctx, "botName", (name) -> startFollow((CommandSourceStack)ctx.getSource(), name, player));
         }
      }))))).then(teamSub("follow", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamfollow").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).then(Commands.literal("stop").executes((ctx) -> teamFollowStop((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(((RequiredArgumentBuilder)Commands.argument("targetName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(teamFollowTargetNames(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes((ctx) -> teamFollowStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "targetName"), (String)null, 0, false, 0))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("formation", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(FollowFormation.names(), builder)).executes((ctx) -> teamFollowStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "targetName"), StringArgumentType.getString(ctx, "formation"), 0, false, 0))).then(((LiteralArgumentBuilder)Commands.literal("elytra").executes((ctx) -> teamFollowStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "targetName"), StringArgumentType.getString(ctx, "formation"), 0, true, 0))).then(Commands.argument("flyCount", IntegerArgumentType.integer(1, 200)).executes((ctx) -> teamFollowStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "targetName"), StringArgumentType.getString(ctx, "formation"), 0, true, IntegerArgumentType.getInteger(ctx, "flyCount")))))).then(((RequiredArgumentBuilder)Commands.argument("perRow", IntegerArgumentType.integer(1, 50)).executes((ctx) -> teamFollowStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "targetName"), StringArgumentType.getString(ctx, "formation"), IntegerArgumentType.getInteger(ctx, "perRow"), false, 0))).then(((LiteralArgumentBuilder)Commands.literal("elytra").executes((ctx) -> teamFollowStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "targetName"), StringArgumentType.getString(ctx, "formation"), IntegerArgumentType.getInteger(ctx, "perRow"), true, 0))).then(Commands.argument("flyCount", IntegerArgumentType.integer(1, 200)).executes((ctx) -> teamFollowStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "targetName"), StringArgumentType.getString(ctx, "formation"), IntegerArgumentType.getInteger(ctx, "perRow"), true, IntegerArgumentType.getInteger(ctx, "flyCount")))))))))))).then(teamSub("goto", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamgoto").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).then(Commands.literal("stop").executes((ctx) -> teamGotoStop((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("status").executes((ctx) -> teamGotoStatus((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("pos", Vec3Argument.vec3()).executes(VexBotCommand::teamGotoRun)).then(teamGotoThen())).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("formation", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(FollowFormation.names(), builder)).executes(VexBotCommand::teamGotoRun)).then(teamGotoThen())).then(((RequiredArgumentBuilder)Commands.argument("perRow", IntegerArgumentType.integer(1, 50)).executes(VexBotCommand::teamGotoRun)).then(teamGotoThen()))))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("targetName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(teamFollowTargetNames(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes(VexBotCommand::teamGotoRun)).then(teamGotoThen())).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("formation", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(FollowFormation.names(), builder)).executes(VexBotCommand::teamGotoRun)).then(teamGotoThen())).then(((RequiredArgumentBuilder)Commands.argument("perRow", IntegerArgumentType.integer(1, 50)).executes(VexBotCommand::teamGotoRun)).then(teamGotoThen())))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("namepool").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("list").executes((ctx) -> namePoolList((CommandSourceStack)ctx.getSource())))).then(Commands.literal("getid").then(Commands.argument("pool", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(NamePoolStorage.list(((CommandSourceStack)c.getSource()).getServer()), b)).executes((ctx) -> namePoolGetId((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "pool")))))).then(Commands.literal("import").then(Commands.argument("id", StringArgumentType.greedyString()).executes((ctx) -> namePoolImport((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "id")))))).then(Commands.literal("none").executes((ctx) -> namePoolSet((CommandSourceStack)ctx.getSource(), (String)null, "")))).then(Commands.argument("pool", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(NamePoolStorage.list(((CommandSourceStack)c.getSource()).getServer()), b)).executes((ctx) -> namePoolSet((CommandSourceStack)ctx.getSource(), (String)null, StringArgumentType.getString(ctx, "pool")))))).then(teamSub("names", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamnamepool").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).then(Commands.literal("none").executes((ctx) -> namePoolSet((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), "")))).then(Commands.argument("pool", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(NamePoolStorage.list(((CommandSourceStack)c.getSource()).getServer()), b)).executes((ctx) -> namePoolSet((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "pool")))))))).then(ControlCli.control().requires(REQUIRES_GAMEMASTER))).then(ControlCli.move().requires(REQUIRES_GAMEMASTER))).then(((LiteralArgumentBuilder)Commands.literal("goto").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).then(Commands.literal("stop").executes((ctx) -> BotTargetArgument.runForEach(ctx, "bot", (name) -> gotoStop((CommandSourceStack)ctx.getSource(), name))))).then(((RequiredArgumentBuilder)Commands.argument("pos", Vec3Argument.vec3()).executes(VexBotCommand::gotoRun)).then(gotoThen()))).then(((RequiredArgumentBuilder)Commands.argument("targetName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(teamFollowTargetNames(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes(VexBotCommand::gotoRun)).then(gotoThen()))))).then(teamSub("skin", (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamskin").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("list").executes((ctx) -> TeamSkinCli.list((CommandSourceStack)ctx.getSource())))).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).then(Commands.literal("stop").executes((ctx) -> TeamSkinCli.clear((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("clear").executes((ctx) -> TeamSkinCli.clear((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.argument("skin", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(SkinStorage.list(((CommandSourceStack)c.getSource()).getServer(), "vexbot_teamskins"), b)).executes((ctx) -> TeamSkinCli.set((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "skin")))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("controlpanel").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> giveControlPanel((CommandSourceStack)ctx.getSource(), 1))).then(Commands.argument("count", IntegerArgumentType.integer(1, 64)).executes((ctx) -> giveControlPanel((CommandSourceStack)ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count")))))).then(((LiteralArgumentBuilder)Commands.literal("recordpov").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("bot", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> BotTargetArgument.runForEach(ctx, "bot", (name) -> recordPovStart((CommandSourceStack)ctx.getSource(), name)))))).then(((LiteralArgumentBuilder)Commands.literal("recordpovstop").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> recordPovStop((CommandSourceStack)ctx.getSource())))).then(((LiteralArgumentBuilder)Commands.literal("recordpovlist").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> recordPovList((CommandSourceStack)ctx.getSource())))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("record").requires(REQUIRES_GAMEMASTER)).then(((LiteralArgumentBuilder)Commands.literal("start").executes((ctx) -> combatRecordStart((CommandSourceStack)ctx.getSource(), (String)null))).then(Commands.argument("focus", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(((CommandSourceStack)c.getSource()).getOnlinePlayerNames(), b)).executes((ctx) -> combatRecordStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "focus")))))).then(Commands.literal("stop").executes((ctx) -> combatRecordStop((CommandSourceStack)ctx.getSource()))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("ffa").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("start").executes((ctx) -> ffaSet((CommandSourceStack)ctx.getSource(), true)))).then(Commands.literal("stop").executes((ctx) -> ffaSet((CommandSourceStack)ctx.getSource(), false)))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("config").executes((ctx) -> ffaConfigList((CommandSourceStack)ctx.getSource()))).then(((LiteralArgumentBuilder)Commands.literal("randomdifficulties").executes((ctx) -> ffaRandomDiffSet((CommandSourceStack)ctx.getSource(), !BotSettings.ffaRandomDifficulties))).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> ffaRandomDiffSet((CommandSourceStack)ctx.getSource(), BoolArgumentType.getBool(ctx, "value")))))).then(((LiteralArgumentBuilder)Commands.literal("randompresets").executes((ctx) -> ffaRandomDiffSet((CommandSourceStack)ctx.getSource(), !BotSettings.ffaRandomDifficulties))).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> ffaRandomDiffSet((CommandSourceStack)ctx.getSource(), BoolArgumentType.getBool(ctx, "value")))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("stunslampractice").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> spawnStunDummy((CommandSourceStack)ctx.getSource(), (String)null))).then(Commands.argument("name", StringArgumentType.word()).executes((ctx) -> spawnStunDummy((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "name")))))).then(((LiteralArgumentBuilder)Commands.literal("nick").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)Commands.argument("player", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).then(Commands.literal("stop").executes((ctx) -> BotTargetArgument.runForEach(ctx, "player", (name) -> NickCli.stop((CommandSourceStack)ctx.getSource(), name))))).then(((RequiredArgumentBuilder)Commands.argument("nickname", StringArgumentType.word()).executes((ctx) -> BotTargetArgument.runForEach(ctx, "player", (name) -> NickCli.nick((CommandSourceStack)ctx.getSource(), name, StringArgumentType.getString(ctx, "nickname"), (String)null)))).then(Commands.argument("skin", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(SkinStorage.list(((CommandSourceStack)c.getSource()).getServer()), b)).executes((ctx) -> BotTargetArgument.runForEach(ctx, "player", (name) -> NickCli.nick((CommandSourceStack)ctx.getSource(), name, StringArgumentType.getString(ctx, "nickname"), StringArgumentType.getString(ctx, "skin"))))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("nullportalconfig").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> nullPortalConfigList((CommandSourceStack)ctx.getSource()))).then(Commands.literal("list").executes((ctx) -> nullPortalConfigList((CommandSourceStack)ctx.getSource())))).then(Commands.literal("jointeam").then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> {
         BotSettings.nullPortalJoinTeam = BoolArgumentType.getBool(ctx, "value");
         return nullPortalConfigSaved((CommandSourceStack)ctx.getSource(), "jointeam", onOffStr(BotSettings.nullPortalJoinTeam));
      })))).then(Commands.literal("team").then(Commands.argument("name", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> {
         BotSettings.nullPortalTeam = StringArgumentType.getString(ctx, "name").strip();
         return nullPortalConfigSaved((CommandSourceStack)ctx.getSource(), "team", BotSettings.nullPortalTeam);
      })))).then(Commands.literal("breakportal").then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> {
         BotSettings.nullPortalBreakAfterSpawn = BoolArgumentType.getBool(ctx, "value");
         return nullPortalConfigSaved((CommandSourceStack)ctx.getSource(), "breakportal", onOffStr(BotSettings.nullPortalBreakAfterSpawn));
      })))).then(Commands.literal("jamatopchance").then(Commands.argument("percent", DoubleArgumentType.doubleArg((double)0.0F, (double)100.0F)).executes((ctx) -> nullPortalChance((CommandSourceStack)ctx.getSource(), "jamatop", DoubleArgumentType.getDouble(ctx, "percent")))))).then(Commands.literal("commanderchance").then(Commands.argument("percent", DoubleArgumentType.doubleArg((double)0.0F, (double)100.0F)).executes((ctx) -> nullPortalChance((CommandSourceStack)ctx.getSource(), "commander", DoubleArgumentType.getDouble(ctx, "percent")))))).then(Commands.literal("specialchance").then(Commands.argument("percent", DoubleArgumentType.doubleArg((double)0.0F, (double)100.0F)).executes((ctx) -> nullPortalChance((CommandSourceStack)ctx.getSource(), "special", DoubleArgumentType.getDouble(ctx, "percent")))))).then(((LiteralArgumentBuilder)Commands.literal("commanderkit").then(Commands.literal("clear").executes((ctx) -> nullPortalKit((CommandSourceStack)ctx.getSource(), "commander", "")))).then(Commands.argument("code", StringArgumentType.greedyString()).executes((ctx) -> nullPortalKit((CommandSourceStack)ctx.getSource(), "commander", StringArgumentType.getString(ctx, "code")))))).then(((LiteralArgumentBuilder)Commands.literal("leader").then(Commands.literal("jamatop").executes((ctx) -> {
         BotSettings.nullPortalLeader = "jamatop";
         return nullPortalConfigSaved((CommandSourceStack)ctx.getSource(), "leader", "jamatop");
      }))).then(Commands.literal("spoke").executes((ctx) -> {
         BotSettings.nullPortalLeader = "spoke";
         return nullPortalConfigSaved((CommandSourceStack)ctx.getSource(), "leader", "spoke");
      })))).then(Commands.literal("leaderchance").then(Commands.argument("percent", DoubleArgumentType.doubleArg((double)0.0F, (double)100.0F)).executes((ctx) -> nullPortalChance((CommandSourceStack)ctx.getSource(), "jamatop", DoubleArgumentType.getDouble(ctx, "percent")))))).then(((LiteralArgumentBuilder)Commands.literal("spokekit").then(Commands.literal("clear").executes((ctx) -> nullPortalKit((CommandSourceStack)ctx.getSource(), "spoke", "")))).then(Commands.argument("code", StringArgumentType.greedyString()).executes((ctx) -> nullPortalKit((CommandSourceStack)ctx.getSource(), "spoke", StringArgumentType.getString(ctx, "code")))))).then(((LiteralArgumentBuilder)Commands.literal("specialkit").then(Commands.literal("clear").executes((ctx) -> nullPortalKit((CommandSourceStack)ctx.getSource(), "special", "")))).then(Commands.argument("code", StringArgumentType.greedyString()).executes((ctx) -> nullPortalKit((CommandSourceStack)ctx.getSource(), "special", StringArgumentType.getString(ctx, "code")))))).then(Commands.literal("skin").then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> {
         BotSettings.nullPortalSkin = BoolArgumentType.getBool(ctx, "value");
         return nullPortalConfigSaved((CommandSourceStack)ctx.getSource(), "skin", onOffStr(BotSettings.nullPortalSkin));
      }))))).then(((LiteralArgumentBuilder)Commands.literal("nullportalspawn").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("pos", Vec3Argument.vec3()).then(((RequiredArgumentBuilder)Commands.argument("count", IntegerArgumentType.integer(1, 50)).executes((ctx) -> nullPortalSpawn((CommandSourceStack)ctx.getSource(), Vec3Argument.getVec3(ctx, "pos"), IntegerArgumentType.getInteger(ctx, "count"), (String)null))).then(Commands.argument("kitId", StringArgumentType.greedyString()).executes((ctx) -> nullPortalSpawn((CommandSourceStack)ctx.getSource(), Vec3Argument.getVec3(ctx, "pos"), IntegerArgumentType.getInteger(ctx, "count"), StringArgumentType.getString(ctx, "kitId")))))))).then(((LiteralArgumentBuilder)Commands.literal("randomgear").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> randomGearTargets(ctx))))).then(teamSub("gear", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamrandomgear").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).executes((ctx) -> teamRandomGear((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("randomchestloot").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> randomChestLootSelf((CommandSourceStack)ctx.getSource()))).then(((LiteralArgumentBuilder)Commands.literal("replace").executes((ctx) -> lootChestReplace((CommandSourceStack)ctx.getSource(), 16))).then(Commands.argument("radius", IntegerArgumentType.integer(1, 128)).executes((ctx) -> lootChestReplace((CommandSourceStack)ctx.getSource(), IntegerArgumentType.getInteger(ctx, "radius")))))).then(Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> randomChestLootTargets(ctx))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("randomchestlootconfig").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("list").executes((ctx) -> rgcList((CommandSourceStack)ctx.getSource(), BotSettings.randomChestLootConfig, "chestloot")))).then(Commands.literal("allowfood").then(Commands.argument("food", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(RandomGearGenerator.foodNames(), b)).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> rgcSetFood((CommandSourceStack)ctx.getSource(), BotSettings.randomChestLootConfig, "chestloot", StringArgumentType.getString(ctx, "food"), BoolArgumentType.getBool(ctx, "value"))))))).then(Commands.argument("key", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(RandomGearConfig.KEYS, b)).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> rgcSet((CommandSourceStack)ctx.getSource(), BotSettings.randomChestLootConfig, "chestloot", StringArgumentType.getString(ctx, "key"), BoolArgumentType.getBool(ctx, "value"))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("randomgearconfig").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("list").executes((ctx) -> rgcList((CommandSourceStack)ctx.getSource(), BotSettings.randomGearConfig, "global")))).then(Commands.literal("allowfood").then(Commands.argument("food", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(RandomGearGenerator.foodNames(), b)).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> rgcSetFood((CommandSourceStack)ctx.getSource(), BotSettings.randomGearConfig, "global", StringArgumentType.getString(ctx, "food"), BoolArgumentType.getBool(ctx, "value"))))))).then(Commands.argument("key", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(RandomGearConfig.KEYS, b)).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> rgcSet((CommandSourceStack)ctx.getSource(), BotSettings.randomGearConfig, "global", StringArgumentType.getString(ctx, "key"), BoolArgumentType.getBool(ctx, "value"))))))).then(teamSub("gearconfig", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamrandomgearconfig").requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).then(Commands.literal("list").executes((ctx) -> rgcListTeam((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(Commands.literal("allowfood").then(Commands.argument("food", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(RandomGearGenerator.foodNames(), b)).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> rgcSetFoodTeam((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "food"), BoolArgumentType.getBool(ctx, "value"))))))).then(Commands.argument("key", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(RandomGearConfig.KEYS, b)).then(Commands.argument("value", BoolArgumentType.bool()).executes((ctx) -> rgcSetTeam((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "key"), BoolArgumentType.getBool(ctx, "value"))))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("playstyle").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("list").executes((ctx) -> playStyleList((CommandSourceStack)ctx.getSource())))).then(((RequiredArgumentBuilder)Commands.argument("style", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"default", "safe", "defensive", "balanced", "aggressive", "adaptive"}, b)).then(Commands.literal("all").executes((ctx) -> playStyleAll((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "style"))))).then(Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> playStyleSet(ctx)))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("randomplaystyle").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("all").executes((ctx) -> randomPlayStyleAll((CommandSourceStack)ctx.getSource())))).then(Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> randomPlayStyleSet(ctx))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("randomplaystylechances").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> randomPlayStyleChancesList((CommandSourceStack)ctx.getSource()))).then(Commands.literal("list").executes((ctx) -> randomPlayStyleChancesList((CommandSourceStack)ctx.getSource())))).then(Commands.literal("reset").executes((ctx) -> randomPlayStyleChancesReset((CommandSourceStack)ctx.getSource())))).then(Commands.argument("style", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"default", "safe", "defensive", "balanced", "aggressive", "adaptive"}, b)).then(Commands.argument("weight", IntegerArgumentType.integer(0, 1000)).executes((ctx) -> randomPlayStyleChanceSet((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "style"), IntegerArgumentType.getInteger(ctx, "weight"))))))).then(((LiteralArgumentBuilder)Commands.literal("renamekit").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("kit", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(KitManager.list(((CommandSourceStack)ctx.getSource()).getServer()), builder)).then(Commands.argument("newName", StringArgumentType.word()).executes((ctx) -> renameKit((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "kit"), StringArgumentType.getString(ctx, "newName"))))))).then(teamSub("playstyle", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamplaystyle").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("teamName", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).then(Commands.argument("style", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"default", "safe", "defensive", "balanced", "aggressive", "adaptive"}, b)).executes((ctx) -> teamPlayStyle((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "style")))))))).then(lookCommand("look"))).then(lookCommand("lookat"))).then(teamSub("look", teamLookCommand("teamlook")))).then(teamSub("surround", teamSurroundCommand("teamsurround")))).then(teamSub((String)null, teamLookCommand("teamlookat")))).then(teamSub("tp", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamtp").requires(REQUIRES_GAMEMASTER)).then(Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> teamTp((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), Vec3Argument.getVec3(ctx, "pos")))))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("movement").requires(REQUIRES_GAMEMASTER)).then(Commands.literal("freeze").executes((ctx) -> movementFreeze((CommandSourceStack)ctx.getSource())))).then(Commands.literal("unfreeze").executes((ctx) -> movementUnfreeze((CommandSourceStack)ctx.getSource()))))).then(teamSub("join", (LiteralArgumentBuilder)Commands.literal("teamjoin").then(((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).executes((ctx) -> teamJoin((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")))).then(((RequiredArgumentBuilder)Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).requires(REQUIRES_GAMEMASTER)).executes((ctx) -> teamJoinTargets(ctx, StringArgumentType.getString(ctx, "teamName")))))))).then(teamSub("leave", (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("teamleave").executes((ctx) -> teamLeave((CommandSourceStack)ctx.getSource()))).then(((RequiredArgumentBuilder)Commands.argument("targets", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).requires(REQUIRES_GAMEMASTER)).executes((ctx) -> teamLeaveTargets(ctx)))));

      try {
         return withTeamTree(root);
      } catch (RuntimeException e) {
         VexBot.LOGGER.error("[VexBot] building /vexbot team failed", e);
         return root;
      }
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamSub(String name, LiteralArgumentBuilder<CommandSourceStack> builder) {
      if (name != null) {
         TEAM_SUBS.add(new TeamSub(name, builder));
      }

      return (LiteralArgumentBuilder)Commands.literal(builder.getLiteral()).requires((src) -> false);
   }

   private static LiteralArgumentBuilder<CommandSourceStack> withTeamTree(LiteralArgumentBuilder<CommandSourceStack> root) {
      LiteralArgumentBuilder<CommandSourceStack> team = (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("team").then(((LiteralArgumentBuilder)Commands.literal("list").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> teamList((CommandSourceStack)ctx.getSource())))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("deleteall").requires(REQUIRES_GAMEMASTER)).executes((ctx) -> teamDeleteAllStart((CommandSourceStack)ctx.getSource()))).then(Commands.literal("confirm").executes((ctx) -> teamDeleteAllNoGui((CommandSourceStack)ctx.getSource()))));
      RequiredArgumentBuilder<CommandSourceStack, String> named = (RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).requires(REQUIRES_GAMEMASTER)).suggests((ctx, b) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), b)).executes((ctx) -> teamSettingsRoot((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName")));
      Map<String, LiteralArgumentBuilder<CommandSourceStack>> rootLevel = new LinkedHashMap();

      for(TeamSub sub : TEAM_SUBS) {
         CommandNode<CommandSourceStack> old = sub.builder().build();
         Predicate<CommandSourceStack> req = sub.builder().getRequirement();
         boolean beforeName = TEAM_ROOT_SUBS.contains(sub.name());
         LiteralArgumentBuilder<CommandSourceStack> top = (LiteralArgumentBuilder)rootLevel.computeIfAbsent(sub.name(), (nx) -> (LiteralArgumentBuilder)Commands.literal(nx).requires(req));
         if (old.getCommand() != null) {
            top.executes(old.getCommand());
         }

         for(CommandNode<CommandSourceStack> child : old.getChildren()) {
            boolean teamArg = child instanceof ArgumentCommandNode && child.getName().equals("teamName");
            if (teamArg && !beforeName) {
               List<String> names = new ArrayList(List.of(sub.name()));
               if (TEAM_SUB_ALIASES.containsKey(sub.name())) {
                  names.add((String)TEAM_SUB_ALIASES.get(sub.name()));
               }

               for(String n : names) {
                  LiteralArgumentBuilder<CommandSourceStack> what = (LiteralArgumentBuilder)Commands.literal(n).requires(req);
                  if (child.getCommand() != null) {
                     what.executes(child.getCommand());
                  }

                  for(CommandNode<CommandSourceStack> gc : child.getChildren()) {
                     what.then(gc);
                  }

                  named.then(what);
               }
            } else {
               top.then(child);
            }
         }
      }

      named.then(teamOrdersHorn());
      named.then(teamSpreadOut());

      for(LiteralArgumentBuilder<CommandSourceStack> top : rootLevel.values()) {
         if (!top.getArguments().isEmpty() || top.getCommand() != null) {
            team.then(top);
         }
      }

      team.then(named);
      return (LiteralArgumentBuilder)root.then(team);
   }

   private static int teamDeleteAllStart(CommandSourceStack source) {
      if (TeamManager.teamNames().isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] There are no teams to delete."));
         return 0;
      } else {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] From the console or a command block use §e/vexbot team deleteall confirm§r."));
            return 0;
         } else {
            TeamDeleteAllMenu.open(player, source.getServer(), false);
            return 1;
         }
      }
   }

   private static int teamDeleteAllNoGui(CommandSourceStack source) {
      if (source.getPlayer() != null) {
         return teamDeleteAllStart(source);
      } else {
         int n = deleteAllTeams(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §aDeleted all §e" + n + "§a team(s). (Bots themselves are not removed.)"), true);
         return n;
      }
   }

   public static int deleteAllTeams(MinecraftServer server) {
      List<String> names = new ArrayList(TeamManager.teamNames());

      for(String n : names) {
         TeamManager.delete(n);
         RestockPlan.clear(n);
      }

      if (!names.isEmpty()) {
         SettingsPersistence.save(server);
      }

      return names.size();
   }

   private static int teamList(CommandSourceStack source) {
      List<String> names = new ArrayList(TeamManager.teamNames());
      if (names.isEmpty()) {
         source.sendSuccess(() -> VexText.literal("[VexBot] No teams yet. Create one with §e/vexbot team create <name>§r."), false);
         return 0;
      } else {
         names.sort(String.CASE_INSENSITIVE_ORDER);
         StringBuilder sb = new StringBuilder("[VexBot] Teams (§f" + names.size() + "§r):");

         for(String n : names) {
            TeamManager.BotTeam t = TeamManager.get(n);
            if (t != null) {
               sb.append("\n §e").append(t.getName()).append("§7 — ").append(t.getBotNames().size()).append(" bot(s), ").append(t.getPlayerNames().size()).append(" player(s)");
            }
         }

         String msg = sb.toString();
         source.sendSuccess(() -> VexText.literal(msg), false);
         return names.size();
      }
   }

   private static int spawnStunDummy(CommandSourceStack source, String name) {
      MinecraftServer server = source.getServer();
      String botName = name == null ? "stunslamprac" : name.strip();

      for(int i = 2; name == null && BotManager.peekSpawnStaticBlockReason(server, botName) != null && i < 100; ++i) {
         botName = "stunslamprac" + i;
      }

      String block = BotManager.peekSpawnStaticBlockReason(server, botName);
      if (block != null) {
         source.sendFailure(VexText.literal("[VexBot] " + block));
         return 0;
      } else {
         SpawnPlacement place = computeSpawnPlacement(source);
         BotManager.markPracticeBot(botName);
         boolean ok = BotManager.spawn(server, botName, place.x, place.y, place.z, place.botYaw, place.pitch, place.dimensionId);
         if (!ok) {
            BotManager.unmarkPracticeBot(botName);
            source.sendFailure(VexText.literal("[VexBot] Could not spawn the practice dummy."));
            return 0;
         } else {
            source.sendSuccess(() -> VexText.literal("[VexBot] §aStun-slam practice dummy §f" + botName + "§a spawned — dive at it with a mace or spear and it shields. Remove with §f/vexbot kill " + botName), true);
            return 1;
         }
      }
   }

   private static int spawnBot(CommandSourceStack source, String name) {
      try {
         String botName = name.strip();
         if (botName.isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] Invalid bot name."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            String block = BotManager.peekSpawnStaticBlockReason(server, botName);
            if (block != null) {
               source.sendFailure(VexText.literal("[VexBot] " + block));
               return 0;
            } else {
               SpawnPlacement place = computeSpawnPlacement(source);
               boolean ok = BotManager.spawn(server, botName, place.x, place.y, place.z, place.botYaw, place.pitch, place.dimensionId);
               if (ok) {
                  source.sendSuccess(() -> VexText.literal("[VexBot] Spawning " + botName + "…"), false);
                  return 1;
               } else {
                  if (BotManager.getBotNames().stream().noneMatch((n) -> n.equalsIgnoreCase(botName))) {
                     source.sendFailure(VexText.literal("[VexBot] Could not spawn '" + botName + "'. Online mode or profile lookup may be required."));
                  } else {
                     source.sendFailure(VexText.literal("[VexBot] A bot named '" + botName + "' already exists."));
                  }

                  return 0;
               }
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] spawnBot crashed", t);
         String var10001 = t.getClass().getSimpleName();
         source.sendFailure(VexText.literal("[VexBot] Internal error: " + var10001 + ": " + t.getMessage()));
         return 0;
      }
   }

   private static int spawnBotAt(CommandSourceStack source, String name, Vec3 pos) {
      try {
         String botName = name.strip();
         if (botName.isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] Invalid bot name."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            String blockReason = BotManager.peekSpawnStaticBlockReason(server, botName);
            if (blockReason != null) {
               source.sendFailure(VexText.literal("[VexBot] " + blockReason));
               return 0;
            } else {
               String dim = source.getLevel().dimension().identifier().toString();
               boolean ok = BotManager.spawn(server, botName, pos.x, pos.y, pos.z, 0.0F, 0.0F, dim);
               if (ok) {
                  source.sendSuccess(() -> VexText.literal(String.format(Locale.ROOT, "[VexBot] Spawning %s at %.1f %.1f %.1f…", botName, pos.x, pos.y, pos.z)), false);
                  return 1;
               } else {
                  if (BotManager.getBotNames().stream().noneMatch((n) -> n.equalsIgnoreCase(botName))) {
                     source.sendFailure(VexText.literal("[VexBot] Could not spawn '" + botName + "'. Online mode or profile lookup may be required."));
                  } else {
                     source.sendFailure(VexText.literal("[VexBot] A bot named '" + botName + "' already exists."));
                  }

                  return 0;
               }
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] spawnBotAt crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Internal error: " + t.getMessage()));
         return 0;
      }
   }

   private static String[] buildCommanderNames() {
      String[] names = new String[27];

      for(char c = 'a'; c <= 'z'; ++c) {
         names[c - 97] = "____" + c + "____";
      }

      names[26] = "_________";
      return names;
   }

   private static boolean rollPercent(Random rng, double percent) {
      if (percent <= (double)0.0F) {
         return false;
      } else if (percent >= (double)100.0F) {
         return true;
      } else {
         return rng.nextInt(10000) < (int)Math.round(percent * (double)100.0F);
      }
   }

   private static String specialNullName(Random rng) {
      return NullCaptainNames.NAMES[rng.nextInt(NullCaptainNames.NAMES.length)];
   }

   private static String freeCommanderName(MinecraftServer server, Random rng) {
      List<String> names = new ArrayList(List.of(NULL_COMMANDER_NAMES));
      Collections.shuffle(names, rng);

      for(String n : names) {
         if (BotManager.peekSpawnStaticBlockReason(server, n) == null) {
            return n;
         }
      }

      return null;
   }

   private static KitShareCodec.SharedKit decodeKit(MinecraftServer server, String code) {
      if (code != null && !code.isBlank()) {
         try {
            return KitShareCodec.decode(server, code.strip());
         } catch (Throwable var3) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static int nullPortalSpawn(CommandSourceStack source, Vec3 pos, int count, String kitOverride) {
      try {
         MinecraftServer server = source.getServer();
         ServerLevel level = source.getLevel();
         BlockPos base = BlockPos.containing(pos);
         buildNetherPortal(level, base);
         String kitId = kitOverride != null && !kitOverride.isBlank() ? kitOverride.strip() : "VBK3:eNrVV9tu2zAMVZukdf2wtVvX24Zi9-0b9rQ_EWSZtoXIkiDJyPL3k5KgptLECzagcwM4SEwd-hySksmckDMyA1WCJfGTkaliLYTvTspgER5alwfDdU6m8U9GjkVJbluhgFtW-R8KfAM2mKhbaFtOyIzrTvkAOcpJznVrtALl3YS86UEWDBOWcu02C696GyjeMOXbNeh1b3ANs0aBcwEym5DL3tKpwgKbC1UH02R1TZ3UfiUpIX69izj7BSOgnZigqgQXwecyohJFR6mit7sUGcHnQ6oGmB_Gzwk5p153vIm-D6V-nFK_3KZuGZ8jzj8RdJJCEf1ayxIUZcZILPg9Ak9TMMoo13oOJS0AKoS9QtjZ3gJyRjLXUKO90Gog1GizrNeGAlI-2jJysr6D3Uqtauq8BVX7JgnfyZNQudmmshCV39Rvz-X0Sbjcb3GphAVqwQnnmeKQMMrGk6iXI0rU-egSdTGeRN2MKFG3o0vU3XgS9WFEifo4ukR9In_uzgqt4-t9L6cXPchbETxlLfMByiRuZh78ZeTUMB8WKIyspF6QgeYCMauARVe0YlKuO4zpoc2HsdoDX0UpvttxJD6nkXi3KxIS6jq4_e_B-GexX1Kx97vE8gacD2Xp4dnL_ZrKvdsltwHZgn_2Ur-lUs_xNCFA7p-yzvAWK5hSYYdtBKzGuCyLSKktmRUydNtIHz7H2rAp40EsDDjyAMmlqBtPa8uWCIfIFTbMHQjw6BkoZ2vvtNQLZaPbARTq18OzyzBbeNqZAcCrx4CB1RdowGt0W3RYwaJJqwCp5cJyCQOOUX3wzsplOINtHLT_pnKS8vgefp9U2obSXZXObw1L1Ok";
         ItemStack[] kitStacks = null;
         ItemStack[] kitEnder = null;

         try {
            KitShareCodec.SharedKit sk = KitShareCodec.decode(server, kitId);
            if (sk != null) {
               kitStacks = sk.stacks();
               kitEnder = sk.ender();
            }
         } catch (Throwable t) {
            VexBot.LOGGER.warn("[VexBot] nullportalspawn: kit decode failed: {}", t.getMessage());
         }

         String dim = level.dimension().identifier().toString();
         double sx = (double)base.getX() + (double)1.5F;
         double sy = (double)(base.getY() + 1);
         double sz = (double)base.getZ() + (double)1.5F;
         Random rng = new Random();
         boolean spokeLeads = "spoke".equalsIgnoreCase(BotSettings.nullPortalLeader);
         String leaderName = spokeLeads ? "SpokeIsHere" : "jamatoP";
         KitShareCodec.SharedKit leaderSk = spokeLeads ? decodeKit(server, BotSettings.nullPortalSpokeKit.isBlank() ? "VBK3:eNrtW8ty2zYUhSRLlpT4FceWH6mrvttFp_uuskxmOu0i2WNAEhQxggAGACMrX99L0hMBksHEZBpxpvbKEnDAg4t7DshLaIzQCPWpiKhC-d8Q7QmyoGjyJpVz-lq_oorivzPOf_-LEugEnZmhCz2Gvr-N0V7-YYi6LEKXCyZoqEhs_hTUJFRBE9ZLqaIe6ocyEwYgnTEah3KRSkGFgUHO1qAw00YucH71nNGtUWSYI9Dhm3yQqYynBSdgaKAVmsbofA2nIkyIMIt83J49bsxgBkSnNMwx3R46XbfphKhUUK2hpd9Dz9ctmQgUJXMmZtDUc0BzIcN5QMJ5wQ5a0Z7m0hThcyJyfV9EUhbOyS2tiIl3UifrBvgmKrl1HNo0jlnIALbampFmfI6NzMJkC-VO1plSx53Smc0N0gGnlChuTebYwnZd7LEdd0a5Py-GNrmAaIpDyaVC_YBD2Ed2qgVEiJwGMYYqUaTlYJiPm_cfczZLDJ4pshqi_bs-No9AwWpo9BFQXsDqO7E4LwjnWBvFUloFsUIEF45gMQzO0grAs21ARW9r7iUXHMml4DS2QcsEwn7_lEOmQk6rtPN5idHzLi7lK9Duf5TgFYz2vKm6ZCLCcCE1s3X30sL2Xex0iyGN8EzyiApM0pT7hhm4w0zuM4Ca4q_lWl5ncAK372WtCV9IgYMsnFNTIdezTcgfmn2gaLCgEcsWY_TCklwxFgYcMyscEUM66Olr8T7joGMScNrpoMErSrhJ3OUdes21kAjWScbnYAWBvPUyHdlhDKUwBD6p3DSuLRd_qOPZdtkA222A7TlY2z0VpR8oVjJyUtaWjQO18i9MpMo0jlXGjA_cd8CWk4VKah3IZZ1UtxreZWDQd9Ld2ogXGTdMJ2Xgq13C1qjvriW_UYA7jTkEayPdX24wP90GQWqN6W3KpWay3Ib2wY5BqSl4Lc_p4wD2jxEaFBate8XeenN9jf4_3TroKC535ChTxECgOu7S7PsUDpEF84QsgbGlMRv-a5uEL5m95m2BRw0EOG6AfdIA-7S-8A-aCP_wUUVtVdHR49K0dWmOGxvcie9W7c7gQqKU9Kr2WQOnOW2Afd4Ae1bf4c6bONzkUUZtldHF49K0dWkuGzvcVc2i0WNZ6AuUhaorbzWLRk6CjPzFhpQTneBU5mlV8dxoTbXsi_Mn-bIQMSi_QTfrPlyKGS6KwIpqpg2BFHQYjVvH6AmqpyLrsaDxCAeNRzhsPMIR8ho9Z6AfIiJQHqW8TpXh84qKx8hX4ZCBZhEjwsP9ZDflqqs1wEj4FssYZyJawdzsy_hrVjUG6LZDP95yWBsY7bWOUf9rMLrYYKSXLDZ3pWtvTW63XPa_BpfJJhejqJiZxKUybA-VUVOTGDcd4EnrFPS0dYwOWsfosEXKPmoRl-P2SPukPVSeNTWJ06YDPG-dgs5ax-i8dYwmLVL2RYu4XLZH2le7puL4TOse-U_Rg2vVlmmhHQfXcqsG58XOG2AnLvbAetyudwjhyIpIJopDc92e_fzPRMwEM6vy8IHdXS6Lw5R959uY58cqH3Cc6aLBcaZLbzSM8CXRlYuxqOevlJYe1HXrlPQCPfCF0Rr6Ddq1d6-53LSIy7cNhDlFD39juUZ_10AE33-CdZhQbV-3a2F_QJ8-2xxImRuFN_6HluoUg5GGC2IASrhd1vs4nlWXt_SqWIBqnJi0S6WU5FfAMeG8bN9zLCiF6NOwyIaiyVqhiKYmKd5tlMfD3ROFWmYc65TSaKupwtZ-dCP74r7IcjqbAXbXwbVPNea6wFrApLYmuxnAivOY9y-XE5-f3Pjc3BefInPBBQytFyFrF4NNySQrbawAHdqbllyiL3lgtyJwThR-9la111FIKF9UnErdrQCt3IF9KmXly9IyBJbCyLuMYBLbdxJ1MsuJ3S-13gjU-GHGyduETt_mY07_iaf5j0Ts32ZYIc7JPBjvDbn11tLAvbHI96qxY3nviWA6gQniMFOabmnsV_h_EEsF6VBk3r_Agrm-" : BotSettings.nullPortalSpokeKit) : null;
         if (leaderSk == null) {
            leaderSk = decodeKit(server, "VBK3:eNrNWktz2zYQhk1LoRXH9Vt-1XHbpI-DZpyM6zY5dXrsoeOZZnrlQORSxAgCGACs5PzA_qieuqTdIRCbSi22Ng4eW1zu8tuP-y25WvcICcmKoBMgO7_QCTVycDn4teB8cCmVoXyVdJiBie4RQr7rkZXyQ0iWWUIOJkxArGhq3gowGSg0RXoqVRKQTiwLYdBlqUd6sZzkUoAwGGSvdgIRZ1SYSWkIyGZtwCMJE6PSOyC79fGUKYioziEuIy8HZLu26YyqXIDWaOkEZKe2FGKogI6vAwYB6VtOU4AcDREkIyit1c-K5rK8ACFOuv270qUzWCTZhYBbJkhTFjOMeVV6IeaN2pbgTayyObSTWXKTObormZzF4wUTarp7_2E6fTudZTedXRtXAirKgSpuJbJh-QaNVMAsRyYQB0RDaQy3qfjJirDiRtiqI8ihZgmjosGxQ5oUlHImTERFEmkDwB_kHjjV3nWhHdZORuLRSKZRIZIrdJ2DzboPcaGNnERlY8EWAjOjaFjV4dq7Mt7pb4ZqprH1GLRVWrvtnFBDe2TrshhyFv9cjMfM_E55Aeh2HKNswBimb_DpKl6E7YcnpFP9Wib7DWd9WNoIGo0z8qd-G5Lt2lzSEhUF0vLi_CwBeP3D-SCFJBmcp9-fDX58cx4PLl6fXVwME_rm1avz5utekb-Iw_oTl_XTW_cWkmgkeQIionnuFGTXChM2tiqdc6qzKJeGSTHnzlmleH1uFEu8OtpC0r0-Qk7qc7jErln1YwWYmKGoGSex1QdBtP8RIj1lqblppjWW3oNgsc7RRlVojAIxMpkD5mnr7rPWOsIznwhZ9wnMZz6B2VioJVsBNr1rC1setYVtF4v1mMSHJHzAHGTSIKCd1hLcbR1hz6dS7fsEZt8nMAdtRXzonYiPPBLxceMgMGX4Mo3vUGrUpKDPW2vwpDHCkNN4HOms4GMcR4Zy1shG2PDWjEM5TuGr9qxYkkTxkyqH8SNrUl2oxOzp8NEFY892PoEJ_BCfPXw-tvjsedYjLN37fiNgj2ELT2GBHSacDyHOQBvLt-MMTG013PNJNk99ArPmnYafeaSb9Xu-BdvT0mLPT3vEaR1hs3WErbbK2_ap2Hd8ArPrnfL2HETWd6kN_d2plP7iUtlvXaYHrSMcLhjBjvGc3PcZV_ueknuTXzt_4dNQ96VPYL4in17LDaUsVwSNcNatrqcYRgon1KAr5fZaASagKE9C8iSnBs3C9ku5nJJ264lcYceNq9zxPddZ1SWQm6zMn2GV3VogzdlrvHDZOb6LHQ6jEfo-MkG79mISH9WRFpjTrVw_JmnOiu1uyh16Xrr0nNxFT6VprGsD3lfQnCWjy5tDwteNA3RNQgZ8AsZPAqzKwedezhS9SdNdd9P3BY1omjLBzNUnxffv5PXN_7c2DEsHLhVZKYH_syncfJfB6fUKUaan5T8qzGPMaoZ_UMF0Vm7740JpuKWEb_HvbioV3rWqQP4GVOPp6Q");
         }

         ItemStack[] jamatoPKit = leaderSk != null ? leaderSk.stacks() : null;
         ItemStack[] jamatoPEnder = leaderSk != null ? leaderSk.ender() : null;
         ItemStack[] cmdKit = kitStacks;
         ItemStack[] cmdEnder = kitEnder;
         ItemStack[] specKit = kitStacks;
         ItemStack[] specEnder = kitEnder;
         KitShareCodec.SharedKit cmdSk = decodeKit(server, BotSettings.nullPortalCommanderKit.isBlank() ? "VBK3:eNrtW9lyozgUVbwkjrM5-9aTnn35hXmaqnmfX6AECKOykBhJlOP--pHsVHMVB8pB6URV4zzFFudw7kV3Aa7HCO2jIeEpkcj-jdCA44Kg438qxqK_RVFgu2aOoZoUamwO-WOMBvbDCPVoim4Lykkicab_5ETnRJqlSM2FTPtomIiKawPZGaNxIopScMK16qPLGiRJiamMEqGeDryq1whPcsx1sQbKqCQRViVJLKjXR-f1msqxLDlRyqwM--iiXql4LAmeUT41S30HNOMimcU4mVkNdhUNFBN66RLH3OuXzMWP5K2N7WQQWCJZRhNqOBcW5Vi041p0_5JFJU1mbVa1KN9Mn6JsFmlRJbnl3lR6z5V-XIMKnHRSewooTBSspO60bzaASQlXVC_Wrsyc8jSKK7m8zv0Wpzjm9V3zgOipYOZUES5LBs38C4AHaIO4LAmW7-Wmk3qNVXxK1oLOO1J7jveGrgPOaoyIFU0p5g2e2230nLXJpLJZJM1JiW7A77n4CXAiW2iJ39Lhm22kkavorgZpYb6NRBZVPF0YKNQGCPZ9Cca-BAcuwSV0lClIkd3JDGAnAHvYmLNVybDKo1JoKnjLdQF7YHWsydlc27UR2l19A21SWgo-NWWPZvppQ9dqjoJSc_wuam7X1WhJ-FTnjpiTkMRM3kXMA8iKVsoybUqiqNKYJ8RRdNpYqWNmMmCk8orNTCzE4rFR1T5MnlYONp-k7ePuQZMThuWwSQlOUS84Rf3XZkjYLXhghx7Y3aZSmYh4TmKnwsIS2w02enU_BWvgh-cmWE9DEnMQkpjDkMQchSTm2CNOT7q0xLCYeuJPmyofeSzNvYxplokpe1o3h-_Zx3ddQM15UGouglJzGZSaq6DUXHvE8I1nDN564u86xrATxdsWeNsCb1vgbQu8bYG3LfC2Bd62wNsWeNsC_79a4HPUjQTsdZcBvEOKJSFfTHsl0gboZVAvL66CUnMd0tuLm5DE3Ab3KuXOVfSphi4IY2L-rW4kN33x2Xjf14Gg50vQ9yUY-BIMfQl2fQn2fAlGvgT7vgRjX4IDX4JDX4IjX4JjX4ITX4KJL8GpL8GZL8G5L8GFL8GlL8GVL8G1L8GNL8GtL8FdNwJIcY9e8RSqhn1qHGybY22LbvWsiYaTQN95jmc9BNU0fg5KzfchdY0_hCTmx-Ba2J82GPCMhbDTg42awMSsltQwjQobgBQz2Np-5RuhvRJrcwCHyMz0y6jD7CKMXILtKaIMM7ZaHzizjaU0KSlZumi5dA1Hbkud22tGVzPrz-aKRcXsmCtJXzN4-3Pj3UHtWkamU4P9cO-CByDLmI4UN1atWfvcgy3TtS9fL8dBv7gOenjJQUlOlDaxoUk3F4Fi8m-Fpf7ytrtvs7l0122OD35tvLOrfZATVriFLKQAdH6JoEoq8ZOhfSfCsHF_hLOM8tVo-063jeU477fGxkHllLC05Z4bpI0Yc24f-a1csvw1ymhkkUxINFy-EQYegzm7MIlmmTRKotBXyJjRaa6jqcQLgJvA52M0mQHA2jncQmvYo1TMubS0LShwIcy5U2oMjaqyBXC2Dmg5Glx_mYsirqAF89zdV7CHozJhpIUY7Likkmxh6o20WfibDbL_bv7fzYQ0QbKMx_8AgGqGsg" : BotSettings.nullPortalCommanderKit);
         if (cmdSk != null) {
            cmdKit = cmdSk.stacks();
            cmdEnder = cmdSk.ender();
         }

         KitShareCodec.SharedKit specSk = decodeKit(server, BotSettings.nullPortalSpecialKit.isBlank() ? "VBK3:eNrNWF1P2zAUNbSFUE0MugEDJsa-9xv2NGnv-wuW49w0Vhzbsx11_fezU0RsSgJqEYSn0utzc-7Judd2pwgdoAmIDDTyfwkaC1IBevWn5hz_JsoSJtwKZqEyU7fgeorG_p8E7bIMnVdMANUktz8F2AK0C2GzkDoboQmVtbAOsjNFUyorJQUIa0bopAVpUIRpTKW5WXjaxkDQgghbrYFypgETo4B60O4IvWljpiBaCTDGRSYj9LaN1CLVQEom5i40ikClkLRMCS09Bx9FY8OlbQSJyj27r1zyD5662I0KCkKQ54wyl3PpUVFFO3FFl_dVpBgt-6rqYf44fobxEltZ08Lnfiz13Zj6rAXJ1LCMEREw_hUARzEwID-XPAOBiVIcOsDjTvCCWNA4rWkJNtQqAE86_WMUJ6bASlomRY_SQYet1jr_COtjCdpbfYMugrRWSzF3Lchye-Oals3es7C5atdwz6VpVw2GGUsEhYjR_rMwOl_Xx2oQc1tEZJJN_XUQA0_C5nCDFSsgmgfYowB7OCiHvB6cQ46G5JDjmEygqpXuWyxzXIts6UZexzyYxQmO2gRUpgtIOwx2uoXBzgZlsHeDM9j5kAx2sa3BLlHX-SznTFhMROaeDMCfdHOParjqNCuVsoQMpwB5h9E_bLPZXg_K6R8H5_RPQ3L6Z_TwRSKV0tuuk85h0B6auUxJ5V3CCA9P0Lf5ErSviHULRIjMuVygHtOHLQTEp8I54Xzl_HHUFEq7JqWNCk0oUDgDZQuvBFvdtO6ch2XNsbvQQLYW6mm0L7GE7--TkMN87rAvrmIwBZp2wUa4qh6otkfcSIivsRBX9wlBCzDW2dzCZlLMwntcZqyDbKbE1tV-69wj2moL4FU8J1_4pbuRpJgmNwWNot4gf2uCibv3CWaXaxfCu031uN743nnQMgUD3v3zxEHY8CkRwh-vVqU3v38kiUdyqdEk5YSWgTLhQK3ciGjaXYFBt5ApZ_PC4rkmywAXkEu1u3oHgLVnxLuPy44zuRDap-1BBS_CPTtz12uLa9UDmK0DelYfB--5kFVahxUsitg_4ZmXacqhJ3HgLFprvnQ7gvbzc-szyg_3eS-X2pm-6a__HMC-Jw" : BotSettings.nullPortalSpecialKit);
         if (specSk != null) {
            specKit = specSk.stacks();
            specEnder = specSk.ender();
         }

         List<String> spawnedNames = new ArrayList();
         boolean jamatoPDone = false;
         int commanders = 0;
         int specials = 0;

         for(int i = 0; i < count; ++i) {
            if (!jamatoPDone && rollPercent(rng, BotSettings.nullPortalJamatopChance) && BotManager.peekSpawnStaticBlockReason(server, leaderName) == null && BotManager.spawn(server, leaderName, sx, sy, sz, 0.0F, 0.0F, dim)) {
               spawnedNames.add(leaderName);
               if (jamatoPKit != null) {
                  BotManager.setPendingKit(leaderName, jamatoPKit, jamatoPEnder);
               }

               jamatoPDone = true;
            } else {
               String commanderName;
               if (commanders < 1 && rollPercent(rng, BotSettings.nullPortalCommanderChance) && (commanderName = freeCommanderName(server, rng)) != null) {
                  if (BotSettings.nullPortalSkin) {
                     BotPlayer.setPendingSkin(commanderName, "ewogICJ0aW1lc3RhbXAiIDogMTYyMTYzNTM3MzI0NywKICAicHJvZmlsZUlkIiA6ICIyMWUzNjdkNzI1Y2Y0ZTNiYjI2OTJjNGEzMDBhNGRlYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJHZXlzZXJNQyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNDkxZDBiZjhiZWMwNDEzNzc0YjVmOTQyZmYxMjkyY2M5YWRiZjY2ZmRhZmFmZGY0OGI0N2IyZmVmNDMzNGE4IgogICAgfQogIH0KfQ==", "iVVrEdeTONKlXcAoywO3+6ayRpRH5DP2Bvl5aso6AvfHZyseHcrxskHwmiYRWn+WaN9eRww27eJ3b9d4kVBtjMTKIWucNwd/Jsp3kWxZJ8lgWDB7sHg46e4aKMaoj1dRDKEZ5GwcpcDmM35MrhYpKF4sK33AAncY13Dfz5eCxzd3UssnRiVQQ4f61kW3a85P+fBrl4j3PbCkfbEOH+n1irO7onvJyAgQfl0B4a/3+7SoeaSWNtgR15RW8rOAguYY4RN26gt8a1kGbgS9jai/64hIrz/vqYb756T/fRNEaKMuLur/Wxejc/Arrm8ai9Tr7ODW42fWfpqeUevRet2Mdc0Mb4XRYDA3A4+xh65BTGnb1UVDmiDCG5+CH9uZUS29Yedn12+zQOqGflg76czPF4UVx3DBO2qURe4dQzXqz9PspO5HXHAs6UlRtBoMxD16veLcXcrYeTKxBGAeQraBizlw60ZQTwTC/sMo3DTeJqL52Ovx19mGwTmm4mfyaoj2Xr3785ra2ZqWGFX4SacimGkNEUz34kapoLvUnHCULqQGiLb4d98o8suaMH6TV7vRZxB9YgLspSHQTiHu3RW7uH2lO3/61KoaxbMbd+9K11S7ds7AmQIwcRmgfCU/PD5MzkI4wiMa33SdHtkJOaZgnbVZImNN7Kw47JJ00F09JeI=");
                  }

                  if (BotManager.spawn(server, commanderName, sx, sy, sz, 0.0F, 0.0F, dim)) {
                     spawnedNames.add(commanderName);
                     boolean white = commanderName.equals("_________");
                     ItemStack[] k = white ? cmdKit : specKit;
                     if (k != null) {
                        BotManager.setPendingKit(commanderName, k, white ? cmdEnder : specEnder);
                     }

                     ++commanders;
                     continue;
                  }
               }

               if (specials < 7 && rollPercent(rng, BotSettings.nullPortalSpecialChance)) {
                  boolean placed = false;

                  for(int t = 0; t < 8 && !placed; ++t) {
                     String name = specialNullName(rng);
                     if (BotManager.peekSpawnStaticBlockReason(server, name) == null) {
                        if (BotSettings.nullPortalSkin) {
                           BotPlayer.setPendingSkin(name, "ewogICJ0aW1lc3RhbXAiIDogMTYyMTYzNTM3MzI0NywKICAicHJvZmlsZUlkIiA6ICIyMWUzNjdkNzI1Y2Y0ZTNiYjI2OTJjNGEzMDBhNGRlYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJHZXlzZXJNQyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNDkxZDBiZjhiZWMwNDEzNzc0YjVmOTQyZmYxMjkyY2M5YWRiZjY2ZmRhZmFmZGY0OGI0N2IyZmVmNDMzNGE4IgogICAgfQogIH0KfQ==", "iVVrEdeTONKlXcAoywO3+6ayRpRH5DP2Bvl5aso6AvfHZyseHcrxskHwmiYRWn+WaN9eRww27eJ3b9d4kVBtjMTKIWucNwd/Jsp3kWxZJ8lgWDB7sHg46e4aKMaoj1dRDKEZ5GwcpcDmM35MrhYpKF4sK33AAncY13Dfz5eCxzd3UssnRiVQQ4f61kW3a85P+fBrl4j3PbCkfbEOH+n1irO7onvJyAgQfl0B4a/3+7SoeaSWNtgR15RW8rOAguYY4RN26gt8a1kGbgS9jai/64hIrz/vqYb756T/fRNEaKMuLur/Wxejc/Arrm8ai9Tr7ODW42fWfpqeUevRet2Mdc0Mb4XRYDA3A4+xh65BTGnb1UVDmiDCG5+CH9uZUS29Yedn12+zQOqGflg76czPF4UVx3DBO2qURe4dQzXqz9PspO5HXHAs6UlRtBoMxD16veLcXcrYeTKxBGAeQraBizlw60ZQTwTC/sMo3DTeJqL52Ovx19mGwTmm4mfyaoj2Xr3785ra2ZqWGFX4SacimGkNEUz34kapoLvUnHCULqQGiLb4d98o8suaMH6TV7vRZxB9YgLspSHQTiHu3RW7uH2lO3/61KoaxbMbd+9K11S7ds7AmQIwcRmgfCU/PD5MzkI4wiMa33SdHtkJOaZgnbVZImNN7Kw47JJ00F09JeI=");
                        }

                        if (BotManager.spawn(server, name, sx, sy, sz, 0.0F, 0.0F, dim)) {
                           spawnedNames.add(name);
                           if (specKit != null) {
                              BotManager.setPendingKit(name, specKit, specEnder);
                           }

                           ++specials;
                           placed = true;
                        }
                     }
                  }

                  if (placed) {
                     continue;
                  }
               }

               for(int t = 0; t < 8; ++t) {
                  String name = randomNullName(rng);
                  if (BotManager.peekSpawnStaticBlockReason(server, name) == null) {
                     if (BotSettings.nullPortalSkin) {
                        BotPlayer.setPendingSkin(name, "ewogICJ0aW1lc3RhbXAiIDogMTYyMTYzNTM3MzI0NywKICAicHJvZmlsZUlkIiA6ICIyMWUzNjdkNzI1Y2Y0ZTNiYjI2OTJjNGEzMDBhNGRlYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJHZXlzZXJNQyIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNDkxZDBiZjhiZWMwNDEzNzc0YjVmOTQyZmYxMjkyY2M5YWRiZjY2ZmRhZmFmZGY0OGI0N2IyZmVmNDMzNGE4IgogICAgfQogIH0KfQ==", "iVVrEdeTONKlXcAoywO3+6ayRpRH5DP2Bvl5aso6AvfHZyseHcrxskHwmiYRWn+WaN9eRww27eJ3b9d4kVBtjMTKIWucNwd/Jsp3kWxZJ8lgWDB7sHg46e4aKMaoj1dRDKEZ5GwcpcDmM35MrhYpKF4sK33AAncY13Dfz5eCxzd3UssnRiVQQ4f61kW3a85P+fBrl4j3PbCkfbEOH+n1irO7onvJyAgQfl0B4a/3+7SoeaSWNtgR15RW8rOAguYY4RN26gt8a1kGbgS9jai/64hIrz/vqYb756T/fRNEaKMuLur/Wxejc/Arrm8ai9Tr7ODW42fWfpqeUevRet2Mdc0Mb4XRYDA3A4+xh65BTGnb1UVDmiDCG5+CH9uZUS29Yedn12+zQOqGflg76czPF4UVx3DBO2qURe4dQzXqz9PspO5HXHAs6UlRtBoMxD16veLcXcrYeTKxBGAeQraBizlw60ZQTwTC/sMo3DTeJqL52Ovx19mGwTmm4mfyaoj2Xr3785ra2ZqWGFX4SacimGkNEUz34kapoLvUnHCULqQGiLb4d98o8suaMH6TV7vRZxB9YgLspSHQTiHu3RW7uH2lO3/61KoaxbMbd+9K11S7ds7AmQIwcRmgfCU/PD5MzkI4wiMa33SdHtkJOaZgnbVZImNN7Kw47JJ00F09JeI=");
                     }

                     if (BotManager.spawn(server, name, sx, sy, sz, 0.0F, 0.0F, dim)) {
                        spawnedNames.add(name);
                        if (kitStacks != null) {
                           BotManager.setPendingKit(name, kitStacks, kitEnder);
                        }
                        break;
                     }
                  }
               }
            }
         }

         String teamName = BotSettings.nullPortalTeam;
         if (BotSettings.nullPortalJoinTeam && teamName != null && !teamName.isBlank() && !spawnedNames.isEmpty()) {
            teamName = teamName.strip();
            TeamManager.getOrCreate(teamName);
            TeamManager.addBotsToTeam(teamName, spawnedNames);
            SettingsPersistence.save(server);
         }

         if (BotSettings.nullPortalBreakAfterSpawn && !spawnedNames.isEmpty()) {
            scheduleNullPortalBreak(server, level, base, new ArrayList(spawnedNames), 0);
         }

         return spawnedNames.size();
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] nullPortalSpawn crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Internal error: " + t.getMessage()));
         return 0;
      }
   }

   private static String onOffStr(boolean v) {
      return v ? "on" : "off";
   }

   private static int nullPortalConfigList(CommandSourceStack source) {
      source.sendSuccess(() -> {
         String var10000 = onOffStr(BotSettings.nullPortalJoinTeam);
         return VexText.literal("[VexBot] §bNull-portal config §7(/vexbot nullportalconfig)§r:\n  §ejointeam§r = §f" + var10000 + " §8— put soldiers on a team\n  §eteam§r = §f" + BotSettings.nullPortalTeam + " §8— which team (auto-created)\n  §ebreakportal§r = §f" + onOffStr(BotSettings.nullPortalBreakAfterSpawn) + " §8— destroy the portal after they emerge\n  §eskin§r = §f" + onOffStr(BotSettings.nullPortalSkin) + " §8— soldiers wear the null skin (the leader excluded)\n  §eleader§r = §f" + BotSettings.nullPortalLeader + " §8— the rare leader: jamatop or spoke (chance: §ejamatopchance§8)\n§8Set: §e/vexbot nullportalconfig <jointeam|team|breakportal|skin|leader> <value>§8.");
      }, false);
      return 1;
   }

   private static int nullPortalConfigSaved(CommandSourceStack source, String key, String val) {
      SettingsPersistence.save(source.getServer());
      source.sendSuccess(() -> VexText.literal("[VexBot] §anullportalconfig §e" + key + "§a set to §e" + val + "§a."), false);
      return 1;
   }

   private static void scheduleNullPortalBreak(MinecraftServer server, ServerLevel level, BlockPos base, List<String> names, int waited) {
      int POLL = 5;
      int MAX_WAIT = 200;
      int HOLD = 60;
      server.schedule(new TickTask(server.getTickCount() + 5, () -> {
         boolean allOut = names.stream().allMatch((n) -> BotManager.resolveTrackedBotPlayer(server, n) != null);
         int now = waited + 5;
         if (!allOut && now < 200) {
            scheduleNullPortalBreak(server, level, base, names, now);
         } else {
            server.schedule(new TickTask(server.getTickCount() + 60, () -> destroyNetherPortal(level, base)));
         }

      }));
   }

   private static void destroyNetherPortal(ServerLevel level, BlockPos base) {
      BlockState air = Blocks.AIR.defaultBlockState();

      for(int dy = 0; dy < 5; ++dy) {
         for(int dx = 0; dx < 4; ++dx) {
            level.setBlockAndUpdate(base.offset(dx, dy, 0), air);
         }
      }

   }

   private static void buildNetherPortal(ServerLevel level, BlockPos base) {
      BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
      BlockState portal = (BlockState)Blocks.NETHER_PORTAL.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_AXIS, Axis.X);

      for(int dy = 0; dy < 5; ++dy) {
         for(int dx = 0; dx < 4; ++dx) {
            if (dx == 0 || dx == 3 || dy == 0 || dy == 4) {
               level.setBlockAndUpdate(base.offset(dx, dy, 0), obsidian);
            }
         }
      }

      for(int dy = 1; dy <= 3; ++dy) {
         for(int dx = 1; dx <= 2; ++dx) {
            level.setBlock(base.offset(dx, dy, 0), portal, 2);
         }
      }

   }

   private static int nullPortalChance(CommandSourceStack source, String which, double pct) {
      switch (which) {
         case "jamatop" -> BotSettings.nullPortalJamatopChance = pct;
         case "commander" -> BotSettings.nullPortalCommanderChance = pct;
         default -> BotSettings.nullPortalSpecialChance = pct;
      }

      SettingsPersistence.save(source.getServer());
      source.sendSuccess(() -> VexText.literal(String.format("[VexBot] Null portal §e%s§r chance set to §e%.2f%%§r.", which, pct)), true);
      return 1;
   }

   private static int nullPortalKit(CommandSourceStack source, String which, String code) {
      MinecraftServer server = source.getServer();
      String trimmed = code == null ? "" : code.strip();
      if (trimmed.isEmpty()) {
         if (which.equals("commander")) {
            BotSettings.nullPortalCommanderKit = "";
         } else if (which.equals("spoke")) {
            BotSettings.nullPortalSpokeKit = "";
         } else {
            BotSettings.nullPortalSpecialKit = "";
         }

         SettingsPersistence.save(server);
         source.sendSuccess(() -> VexText.literal("[VexBot] Null §e" + which + "§r kit cleared — back to its built-in kit."), true);
         return 1;
      } else {
         int items;
         try {
            KitShareCodec.SharedKit sk = KitShareCodec.decode(server, trimmed);
            if (sk == null || sk.stacks() == null) {
               source.sendFailure(VexText.literal("[VexBot] §cThat kit code could not be read. It was NOT saved."));
               return 0;
            }

            int n = 0;

            for(ItemStack st : sk.stacks()) {
               if (st != null && !st.isEmpty()) {
                  ++n;
               }
            }

            items = n;
         } catch (Throwable t) {
            source.sendFailure(VexText.literal("[VexBot] §cThat kit code could not be read: " + t.getMessage() + " It was NOT saved."));
            return 0;
         }

         if (which.equals("commander")) {
            BotSettings.nullPortalCommanderKit = trimmed;
         } else if (which.equals("spoke")) {
            BotSettings.nullPortalSpokeKit = trimmed;
         } else {
            BotSettings.nullPortalSpecialKit = trimmed;
         }

         SettingsPersistence.save(server);
         source.sendSuccess(() -> VexText.literal("[VexBot] Null §e" + which + "§r kit set — §e" + items + "§r items."), true);
         return 1;
      }
   }

   private static String randomNullName(Random rng) {
      String pool = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
      int len = 7 + rng.nextInt(3);
      StringBuilder sb = new StringBuilder(len);

      for(int i = 0; i < len; ++i) {
         sb.append("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(rng.nextInt("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".length())));
      }

      return sb.toString();
   }

   private static int settingsRoot(CommandSourceStack source) {
      return source.getPlayer() != null ? openSettingsGui(source, (String)null) : SettingsCli.listAll(source, GameplaySettingsScope.global());
   }

   private static int settingsShow(CommandSourceStack source, String setting) {
      return "list".equalsIgnoreCase(setting) ? SettingsCli.listAll(source, GameplaySettingsScope.global()) : SettingsCli.showOne(source, GameplaySettingsScope.global(), setting);
   }

   private static int settingsApply(CommandSourceStack source, String setting, String value) {
      return SettingsCli.apply(source, GameplaySettingsScope.global(), setting, value);
   }

   private static int teamSettingsRoot(CommandSourceStack source, String teamName) {
      if (!requireTeam(source, teamName)) {
         return 0;
      } else {
         ServerPlayer player = source.getPlayer();
         if (player != null) {
            TeamSettingsMenu.open(player, teamName);
            return 1;
         } else {
            return SettingsCli.listAll(source, GameplaySettingsScope.forTeam(teamName));
         }
      }
   }

   private static int teamSettingsSearch(CommandSourceStack source, String teamName, String query) {
      if (!requireTeam(source, teamName)) {
         return 0;
      } else {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Searching opens a GUI, so it needs a player."));
            return 0;
         } else {
            TeamSettingsMenu.openSearch(player, teamName, query);
            return 1;
         }
      }
   }

   private static boolean requireTeam(CommandSourceStack source, String teamName) {
      if (TeamManager.exists(teamName)) {
         return true;
      } else {
         List<String> names = new ArrayList(TeamManager.teamNames());
         names.sort(String.CASE_INSENSITIVE_ORDER);
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'. " + (names.isEmpty() ? "There are no teams yet" : "Teams: §e" + String.join("§r, §e", names) + "§r") + ". Create one with §e/vexbot team create <name>§r."));
         return false;
      }
   }

   private static int teamSettingsShow(CommandSourceStack source, String teamName, String setting) {
      if (!requireTeam(source, teamName)) {
         return 0;
      } else {
         return "list".equalsIgnoreCase(setting) ? SettingsCli.listAll(source, GameplaySettingsScope.forTeam(teamName)) : SettingsCli.showOne(source, GameplaySettingsScope.forTeam(teamName), setting);
      }
   }

   private static int teamSettingsApply(CommandSourceStack source, String teamName, String setting, String value) {
      return !requireTeam(source, teamName) ? 0 : SettingsCli.apply(source, GameplaySettingsScope.forTeam(teamName), setting, value);
   }

   private static int openSettingsGui(CommandSourceStack source, String teamName) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Settings GUI requires a player. Use §e/vexbot settings list§r or §e/vexbot settings <setting> <value>§r."));
            return 0;
         } else {
            if (teamName != null) {
               TeamManager.getOrCreate(teamName);
            }

            String title = teamName != null ? "Team settings: " + teamName : "VexBot Settings";
            player.openMenu(new SimpleMenuProvider((containerId, inventory, p) -> teamName != null ? new VexBotSettingsMenu(containerId, inventory, teamName) : new VexBotSettingsMenu(containerId, inventory), VexText.literal(title)));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openSettingsGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int levelFromName(String raw) {
      byte var10000;
      switch (raw.toLowerCase(Locale.ROOT)) {
         case "easy":
            var10000 = 1;
            break;
         case "medium":
         case "normal":
            var10000 = 2;
            break;
         case "hard":
            var10000 = 3;
            break;
         case "expert":
            var10000 = 4;
            break;
         case "professional":
         case "pro":
         case "perfect":
            var10000 = 5;
            break;
         default:
            var10000 = -1;
      }

      return var10000;
   }

   private static String levelName(int lvl) {
      String var10000;
      switch (Math.max(1, Math.min(5, lvl))) {
         case 1 -> var10000 = "easy";
         case 2 -> var10000 = "medium";
         case 3 -> var10000 = "hard";
         case 4 -> var10000 = "expert";
         default -> var10000 = "professional";
      }

      return var10000;
   }

   private static boolean isLevelKnob(String knob) {
      String k = knob.toLowerCase(Locale.ROOT);
      return k.equals("elytramace") || k.equals("elytramacelevel") || k.equals("crystalpvp") || k.equals("crystallevel") || k.equals("cpvp");
   }

   private static int setDifficultyKnobNamed(CommandSourceStack source, DifficultyParams p, String scope, String knob, String levelWord) {
      if (!isLevelKnob(knob)) {
         source.sendFailure(VexText.literal("[VexBot] '§e" + knob + "§r' takes a number, not a level name. Only §eelytramace§r and §ecrystalpvp§r use easy/medium/hard/expert/professional."));
         return 0;
      } else {
         int lvl = levelFromName(levelWord);
         if (lvl < 0) {
            source.sendFailure(VexText.literal("[VexBot] Unknown level '§e" + levelWord + "§r'. Use: §e" + String.join(", ", LEVEL_NAMES) + "§r (or 1-5)."));
            return 0;
         } else {
            return setDifficultyKnob(source, p, scope, knob, (double)lvl);
         }
      }
   }

   private static int setDifficultyKnobTeamNamed(CommandSourceStack source, String teamName, String knob, String levelWord) {
      if (!isLevelKnob(knob)) {
         source.sendFailure(VexText.literal("[VexBot] '§e" + knob + "§r' takes a number, not a level name. Only §eelytramace§r and §ecrystalpvp§r use easy/medium/hard/expert/professional."));
         return 0;
      } else {
         int lvl = levelFromName(levelWord);
         if (lvl < 0) {
            source.sendFailure(VexText.literal("[VexBot] Unknown level '§e" + levelWord + "§r'. Use: §e" + String.join(", ", LEVEL_NAMES) + "§r (or 1-5)."));
            return 0;
         } else {
            return setDifficultyKnobTeam(source, teamName, knob, (double)lvl);
         }
      }
   }

   private static int giveControlPanel(CommandSourceStack source, int count) {
      ServerPlayer player = source.getPlayer();
      if (player == null) {
         source.sendFailure(VexText.literal("[VexBot] Only a player can hold a control panel."));
         return 0;
      } else {
         ItemStack stack = ControlPanel.create(player.level(), count);
         if (!player.getInventory().add(stack)) {
            McCompat.drop(player, stack, false);
         }

         source.sendSuccess(() -> {
            String var10001 = count == 1 ? "is a control panel§r. Put it in an item frame" : "are " + count + " control panels§r. Put them in item frames";
            return VexText.literal(player, "[VexBot] §aHere " + var10001 + "; frames side by side on one wall make one bigger screen. Aim to point, left-click to click, mouse wheel to scroll, sneak-punch to take one down.");
         }, false);
         return 1;
      }
   }

   private static BotSettings.Difficulty parseDifficulty(String raw) {
      try {
         return BotSettings.Difficulty.valueOf(raw.toUpperCase(Locale.ROOT));
      } catch (IllegalArgumentException var2) {
         return null;
      }
   }

   private static int setGlobalDifficultyPreset(CommandSourceStack source, String raw) {
      BotSettings.Difficulty d = parseDifficulty(raw);
      if (d == null) {
         source.sendFailure(VexText.literal("[VexBot] Unknown preset '§e" + raw + "§r'. Use: §e" + String.join(", ", DIFFICULTY_PRESETS)));
         return 0;
      } else {
         BotSettings.difficulty = d;
         BotSettings.difficultyParams = DifficultyParams.forPreset(d);
         SettingsPersistence.save(source.getServer());
         String name = d.name().toLowerCase(Locale.ROOT);
         source.sendSuccess(() -> VexText.literal("[VexBot] §aGlobal difficulty preset set to §e" + name + "§a — all knobs bundled. §7/vexbot difficulty list§r to see them."), false);
         return 1;
      }
   }

   private static int setTeamDifficultyPreset(CommandSourceStack source, String team, String raw) {
      if (!TeamManager.exists(team)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + team + "' does not exist."));
         return 0;
      } else {
         BotSettings.Difficulty d = parseDifficulty(raw);
         if (d == null) {
            source.sendFailure(VexText.literal("[VexBot] Unknown preset '§e" + raw + "§r'. Use: §e" + String.join(", ", DIFFICULTY_PRESETS)));
            return 0;
         } else {
            TeamManager.BotTeam t = TeamManager.get(team);
            t.difficulty = d;
            t.difficultyParams = DifficultyParams.forPreset(d);
            SettingsPersistence.save(source.getServer());
            String name = d.name().toLowerCase(Locale.ROOT);
            source.sendSuccess(() -> VexText.literal("[VexBot] §aTeam §e" + team + "§a difficulty preset set to §e" + name + "§a — all knobs bundled."), false);
            return 1;
         }
      }
   }

   private static int difficultyList(CommandSourceStack source, DifficultyParams p, String scope) {
      StringBuilder sb = new StringBuilder("[VexBot] §bDifficulty knobs §7(" + scope + ")§r:");
      sb.append("\n  §emisschance§r ").append(Math.round(p.missChance * (double)100.0F)).append("§7%  (aim off-head)");
      sb.append("\n  §eaccuracy§r ").append(Math.round(p.accuracy * (double)100.0F)).append("§7%  (advanced tech)");
      sb.append("\n  §eclutch§r ").append(Math.round(p.clutchAccuracy * (double)100.0F)).append("§7%  (water-bucket)");
      sb.append("\n  §ereaction§r ").append(p.reactionMinTicks * 50).append("§7-§e").append(p.reactionMaxTicks * 50).append("§7 ms  (general)");
      sb.append("\n  §eshielddisablespeed§r ").append(p.shieldReactionMs).append("§7±").append(p.shieldReactionJitterMs).append(" ms  (react + disable your shield)");
      sb.append("\n  §eshieldcharge§r ").append(Math.round(p.shieldDisableCharge * (double)100.0F)).append("§7%  (axe charge to pop shield)");
      sb.append("\n  §estrafe§r ").append(Math.round(p.strafeAngle)).append("§7°  (strafe width)");
      sb.append("\n  §ecrittiming§r ").append(critTimingPct(p.critThreshold)).append("§7%  (100 = optimal)");
      sb.append("\n  §eanchorspeed§r ").append(p.anchorIntervalTicks).append("§7 ticks  (anchor place interval)");
      sb.append("\n  §estunslam§r ").append(p.stunSlamChance).append("§7%  (axe-disable → mace smash)");
      sb.append("\n  §epotspeed§r ").append(p.potIntervalSeconds).append("§7 s  (between potion throws)");
      sb.append("\n  §ewebdrainspeed§r ").append(p.webDrainDelaySeconds).append("§7 s  (react to escape water)");
      sb.append("\n  §ewebescapespeed§r ").append(p.webEscapeDelaySeconds).append("§7 s  (delay before escaping a web)");
      sb.append("\n  §eelytramace§r ").append(levelName(p.elytraMaceLevel)).append("§7 (").append(p.elytraMaceLevel).append("/5, professional = full strength)");
      sb.append("\n  §ecrystalpvp§r ").append(levelName(p.crystalPvpLevel)).append("§7 (").append(p.crystalPvpLevel).append("/5, crystal + anchor skill)");
      sb.append("\n  §ereachflips§r ").append(p.reachFlips).append("§7  (0 = always full reach)");
      sb.append("\n  §ecartskip§r ").append(p.cartSkipChance).append("§7%  (carts let pass)");
      sb.append("\n  §ecartspeed§r ").append(p.cartCooldownTicks).append("§7 ticks  (between TNT carts)");
      sb.append("\n  §ecrystalspeed§r ").append(p.crystalCooldownTicks).append("§7 ticks  (between end crystals)");
      sb.append("\n  §eanchorgap§r ").append(p.anchorCooldownTicks).append("§7 ticks  (between respawn anchors)");
      String out = sb.toString();
      source.sendSuccess(() -> VexText.literal(out), false);
      return 1;
   }

   private static long critTimingPct(double threshold) {
      return Math.max(0L, Math.min(100L, Math.round(((double)1.0F + threshold / 0.15) * (double)100.0F)));
   }

   private static int difficultyKnobPresets(CommandSourceStack source, String knobRaw) {
      String knob = knobRaw.toLowerCase(Locale.ROOT);
      StringBuilder sb = new StringBuilder("[VexBot] §b" + knob + "§r by preset:");

      for(BotSettings.Difficulty d : BotSettings.Difficulty.values()) {
         String v = knobPresetValue(DifficultyParams.forPreset(d), knob);
         if (v == null) {
            source.sendFailure(VexText.literal("[VexBot] Unknown knob '§e" + knobRaw + "§r'. Try: §e" + String.join(", ", DIFFICULTY_KNOBS)));
            return 0;
         }

         sb.append("\n  §e").append(d.name().toLowerCase(Locale.ROOT)).append("§r ").append(v);
      }

      String out = sb.toString();
      source.sendSuccess(() -> VexText.literal(out), false);
      return 1;
   }

   private static DifficultyParams ownParams(String canonical) {
      return (DifficultyParams)BotSettings.botDifficulties.computeIfAbsent(canonical, (n) -> {
         TeamManager.BotTeam team = TeamManager.getTeamForBot(n);
         return (team != null ? team.difficultyParams : BotSettings.difficultyParams).copy();
      });
   }

   private static String resolveBotOrFail(CommandSourceStack source, String raw) {
      String canonical = BotManager.resolveCanonicalBotName(raw);
      if (canonical == null) {
         source.sendFailure(VexText.literal("[VexBot] §cNo bot called '§e" + raw + "§c'."));
         return null;
      } else {
         return canonical;
      }
   }

   private static int botDifficultyList(CommandSourceStack source, String botRaw) {
      String bot = resolveBotOrFail(source, botRaw);
      if (bot == null) {
         return 0;
      } else {
         DifficultyParams own = (DifficultyParams)BotSettings.botDifficulties.get(bot);
         if (own == null) {
            source.sendSuccess(() -> VexText.literal("[VexBot] §e" + bot + "§r has no difficulty of its own — it uses " + (TeamManager.getTeamForBot(bot) != null ? "its team's" : "the global") + " knobs."), false);
            return difficultyList(source, (new EffectiveSettings(bot)).difficultyParams(), "bot " + bot);
         } else {
            return difficultyList(source, own, "bot " + bot);
         }
      }
   }

   private static int botDifficultyClear(CommandSourceStack source, String botRaw) {
      String bot = resolveBotOrFail(source, botRaw);
      if (bot == null) {
         return 0;
      } else {
         boolean had = BotSettings.botDifficulties.remove(bot) != null;
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal(had ? "[VexBot] §aCleared §e" + bot + "§a's own difficulty — back to its team/global knobs." : "[VexBot] §e" + bot + "§r had no difficulty of its own."), false);
         return 1;
      }
   }

   private static int botDifficultyPreset(CommandSourceStack source, String botRaw, String level) {
      String bot = resolveBotOrFail(source, botRaw);
      if (bot == null) {
         return 0;
      } else {
         BotSettings.Difficulty d;
         try {
            d = BotSettings.Difficulty.valueOf(level.toUpperCase(Locale.ROOT));
         } catch (IllegalArgumentException var6) {
            source.sendFailure(VexText.literal("[VexBot] §cUnknown preset '§e" + level + "§c'. Try: §e" + String.join(", ", DIFFICULTY_PRESETS)));
            return 0;
         }

         BotSettings.botDifficulties.put(bot, DifficultyParams.forPreset(d));
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + bot + "§a is now on the §e" + d.name().toLowerCase(Locale.ROOT) + "§a preset (its own, not its team's)."), false);
         return 1;
      }
   }

   private static int botDifficultyKnob(CommandSourceStack source, String botRaw, String knob, double value) {
      String bot = resolveBotOrFail(source, botRaw);
      return bot == null ? 0 : setDifficultyKnob(source, ownParams(bot), "bot " + bot, knob, value);
   }

   private static int botDifficultyKnobNamed(CommandSourceStack source, String botRaw, String knob, String level) {
      String bot = resolveBotOrFail(source, botRaw);
      return bot == null ? 0 : setDifficultyKnobNamed(source, ownParams(bot), "bot " + bot, knob, level);
   }

   private static String knobPresetValue(DifficultyParams p, String knob) {
      String var10000;
      switch (knob) {
         case "misschance":
            var10000 = String.valueOf(Math.round(p.missChance * (double)100.0F));
            break;
         case "accuracy":
            var10000 = String.valueOf(Math.round(p.accuracy * (double)100.0F));
            break;
         case "clutch":
            var10000 = String.valueOf(Math.round(p.clutchAccuracy * (double)100.0F));
            break;
         case "reaction":
            var10000 = p.reactionMinTicks == p.reactionMaxTicks ? p.reactionMinTicks * 50 + " ms" : p.reactionMinTicks * 50 + "-" + p.reactionMaxTicks * 50 + " ms";
            break;
         case "shielddisablespeed":
         case "shieldreaction":
            var10000 = p.shieldReactionMs + (p.shieldReactionJitterMs > 0 ? " ±" + p.shieldReactionJitterMs : "") + " ms";
            break;
         case "shieldcharge":
            var10000 = String.valueOf(Math.round(p.shieldDisableCharge * (double)100.0F));
            break;
         case "strafe":
            var10000 = String.valueOf(Math.round(p.strafeAngle));
            break;
         case "crittiming":
            var10000 = String.valueOf(critTimingPct(p.critThreshold));
            break;
         case "anchorspeed":
            var10000 = p.anchorIntervalTicks + " ticks";
            break;
         case "stunslam":
            var10000 = String.valueOf(p.stunSlamChance);
            break;
         case "potspeed":
            var10000 = secs(p.potIntervalSeconds) + " s";
            break;
         case "webdrainspeed":
         case "webdrain":
            var10000 = secs(p.webDrainDelaySeconds) + " s";
            break;
         case "webescapespeed":
         case "webescape":
            var10000 = secs(p.webEscapeDelaySeconds) + " s";
            break;
         case "elytramace":
         case "elytramacelevel":
            var10000 = levelName(p.elytraMaceLevel) + " (" + p.elytraMaceLevel + "/5)";
            break;
         case "crystalpvp":
         case "crystallevel":
         case "cpvp":
            var10000 = levelName(p.crystalPvpLevel) + " (" + p.crystalPvpLevel + "/5)";
            break;
         case "reachflips":
            var10000 = String.valueOf(p.reachFlips);
            break;
         case "cartskip":
            var10000 = p.cartSkipChance + "%";
            break;
         case "cartspeed":
            var10000 = p.cartCooldownTicks + " ticks";
            break;
         case "crystalspeed":
            var10000 = p.crystalCooldownTicks + " ticks";
            break;
         case "anchorgap":
            var10000 = p.anchorCooldownTicks + " ticks";
            break;
         default:
            var10000 = null;
      }

      return var10000;
   }

   private static String secs(double s) {
      return s == Math.floor(s) ? String.valueOf((long)s) : String.valueOf((double)Math.round(s * (double)100.0F) / (double)100.0F);
   }

   private static int setDifficultyKnob(CommandSourceStack source, DifficultyParams p, String scope, String knob, double v) {
      String shown = DifficultyKnobs.apply(p, knob, v);
      if (shown == null) {
         source.sendFailure(VexText.literal("[VexBot] Unknown knob '§e" + knob + "§r'. Try: §e" + String.join(", ", DIFFICULTY_KNOBS)));
         return 0;
      } else {
         SettingsPersistence.save(source.getServer());
         String msg = "[VexBot] §aDifficulty §e" + knob.toLowerCase(Locale.ROOT) + "§a (" + scope + ") set to §e" + shown + "§r.";
         source.sendSuccess(() -> VexText.literal(msg), false);
         return 1;
      }
   }

   private static int difficultyListTeam(CommandSourceStack source, String team) {
      if (!TeamManager.exists(team)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + team + "' does not exist."));
         return 0;
      } else {
         return difficultyList(source, TeamManager.get(team).difficultyParams, "team " + team);
      }
   }

   private static int setDifficultyKnobTeam(CommandSourceStack source, String team, String knob, double v) {
      if (!TeamManager.exists(team)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + team + "' does not exist."));
         return 0;
      } else {
         return setDifficultyKnob(source, TeamManager.get(team).difficultyParams, "team " + team, knob, v);
      }
   }

   private static double clamp01(double v) {
      return v < (double)0.0F ? (double)0.0F : (v > (double)1.0F ? (double)1.0F : v);
   }

   private static LiteralArgumentBuilder<CommandSourceStack> languageNode() {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("language").executes((ctx) -> languageShow((CommandSourceStack)ctx.getSource()))).then(Commands.argument("lang", StringArgumentType.word()).suggests((c, b) -> {
         List<String> opts = new ArrayList(VexLang.codes());
         opts.add("auto");
         return SharedSuggestionProvider.suggest(opts, b);
      }).executes((ctx) -> languageSet((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "lang"))));
   }

   private static int languageShow(CommandSourceStack source) {
      Entity var2 = source.getEntity();
      if (var2 instanceof ServerPlayer p) {
         String var5 = VexLang.of(p);
         String name = (String)VexLang.LANGUAGES.get(var5);
         boolean picked = VexLang.pick(p) != null;
         source.sendSuccess(() -> VexText.literal("[VexBot] VexBot talks to you in §e" + name + "§r" + (picked ? " (your pick)." : " (from your Minecraft language).") + " Change it with §e/vexbot language <en|es|pt|fr|de|ru|zh|hi|auto>§r."), false);
         return 1;
      } else {
         source.sendFailure(VexText.literal("[VexBot] Only players have a VexBot language."));
         return 0;
      }
   }

   private static int languageSet(CommandSourceStack source, String lang) {
      Entity var3 = source.getEntity();
      if (var3 instanceof ServerPlayer p) {
         String code = lang.toLowerCase(Locale.ROOT);
         if (!code.equals("auto") && !VexLang.LANGUAGES.containsKey(code)) {
            source.sendFailure(VexText.literal("[VexBot] Unknown language '§e" + lang + "§r'. Choose one of: §e" + String.join(", ", VexLang.codes()) + ", auto§r."));
            return 0;
         } else {
            VexLang.setPick(source.getServer(), p, code);
            String name = (String)VexLang.LANGUAGES.get(VexLang.of(p));
            p.sendSystemMessage(VexText.literal(p, code.equals("auto") ? "[VexBot] §aVexBot follows your Minecraft language again: §e" + name + "§a." : "[VexBot] §aVexBot will talk to you in §e" + name + "§a."));
            return 1;
         }
      } else {
         source.sendFailure(VexText.literal("[VexBot] Only players have a VexBot language."));
         return 0;
      }
   }

   private static int massSpawn(CommandSourceStack source, int count) {
      return massSpawnWithPivot(source, count, computeMassSpawnPivot(source), false);
   }

   private static int massSpawnAt(CommandSourceStack source, int count, Vec3 pos) {
      return massSpawnWithPivot(source, count, pivotAt(source, pos), false);
   }

   private static MassSpawnPivot pivotAt(CommandSourceStack source, Vec3 pos) {
      double yawRad = Math.toRadians((double)source.getRotation().y);
      String dim = source.getLevel().dimension().identifier().toString();
      return new MassSpawnPivot(pos.x, pos.y, pos.z, yawRad, dim);
   }

   private static int massSpawnWithPivot(CommandSourceStack source, int count, MassSpawnPivot pivot, boolean randomGear) {
      List<String> spawned = spawnGrid(source, count, pivot);
      if (spawned.isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] Could not spawn any bots."));
         return 0;
      } else {
         if (randomGear) {
            for(String n : spawned) {
               BotManager.setPendingRandomGear(n);
            }
         }

         int n = spawned.size();
         source.sendSuccess(() -> VexText.literal("[VexBot] Queuing " + n + " bot(s)" + (randomGear ? " with §drandom gear§r" : "") + " — staggered, one per server tick."), false);
         return n;
      }
   }

   private static List<String> spawnGrid(CommandSourceStack source, int count, MassSpawnPivot pivot) {
      return spawnGrid(source, count, pivot, (String)null);
   }

   private static List<String> spawnGrid(CommandSourceStack source, int count, MassSpawnPivot pivot, String teamName) {
      List<String> spawned = new ArrayList();

      try {
         double cx = pivot.cx;
         double cy = pivot.cy;
         double cz = pivot.cz;
         double yawRad = pivot.yawRad;
         String dim = pivot.dimensionId;
         MinecraftServer server = source.getServer();
         int gridCols = (int)Math.ceil(Math.sqrt((double)count));
         double spacing = (double)1.5F;
         float faceYaw = (float)Math.toDegrees(yawRad);
         List<String> freePool = freePoolNames(server, teamName);

         for(int idx = 0; idx < count; ++idx) {
            int col = idx % gridCols;
            int row = idx / gridCols;
            double bx = cx + ((double)col - (double)(gridCols - 1) / (double)2.0F) * spacing;
            double bz = cz + ((double)row - (double)(gridCols - 1) / (double)2.0F) * spacing;
            double by = cy;
            float yaw = faceYaw;
            if (pivot.fromArea()) {
               Vec3 spot = SpawnArea.randomSpot(server);
               if (spot != null) {
                  bx = spot.x;
                  by = spot.y;
                  bz = spot.z;
                  yaw = RNG.nextFloat() * 360.0F - 180.0F;
               }
            }

            String name = null;
            if (freePool != null && !freePool.isEmpty()) {
               String picked = (String)freePool.get(RNG.nextInt(freePool.size()));
               freePool.removeIf((s) -> s.equalsIgnoreCase(picked));
               name = picked;
            } else {
               for(int attempt = 0; attempt < 200; ++attempt) {
                  String candidate = randomBotName();
                  if (BotManager.peekSpawnStaticBlockReason(server, candidate) == null && !spawned.stream().anyMatch((s) -> s.equalsIgnoreCase(candidate))) {
                     name = candidate;
                     break;
                  }
               }
            }

            if (name != null && BotManager.queueSpawn(server, name, bx, by, bz, yaw, 0.0F, dim)) {
               spawned.add(name);
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] massSpawn crashed", t);
      }

      return spawned;
   }

   private static int spawnBotAtWithKit(CommandSourceStack source, String name, Vec3 pos, String kitName, String team) {
      try {
         if (!BotSettings.advancedSpawn) {
            source.sendFailure(VexText.literal("[VexBot] Kit spawn is off. Enable it with §e/vexbot settings advancedspawn true§r."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            if (!KitManager.exists(server, kitName)) {
               source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot givekit list§r."));
               return 0;
            } else if (team != null && !TeamManager.exists(team)) {
               source.sendFailure(VexText.literal("[VexBot] §cTeam '" + team + "' does not exist.§r Create it first with §e/vexbot team create " + team + "§r."));
               return 0;
            } else {
               String botName = name.strip();
               if (botName.isEmpty()) {
                  source.sendFailure(VexText.literal("[VexBot] Invalid bot name."));
                  return 0;
               } else {
                  String blockReason = BotManager.peekSpawnStaticBlockReason(server, botName);
                  if (blockReason != null) {
                     source.sendFailure(VexText.literal("[VexBot] " + blockReason));
                     return 0;
                  } else {
                     ItemStack[] stacks = KitManager.load(server, kitName);
                     ItemStack[] kitEnderChest = KitManager.loadEnder(server, kitName);
                     String dim = source.getLevel().dimension().identifier().toString();
                     boolean ok = BotManager.spawn(server, botName, pos.x, pos.y, pos.z, 0.0F, 0.0F, dim);
                     if (!ok) {
                        source.sendFailure(VexText.literal("[VexBot] Could not spawn '" + botName + "' (name taken or profile lookup failed)."));
                        return 0;
                     } else {
                        if (stacks != null) {
                           BotManager.setPendingKit(botName, stacks, kitEnderChest);
                        }

                        if (team != null) {
                           TeamManager.addBotsToTeam(team, List.of(botName));
                           SettingsPersistence.save(server);
                        }

                        String onTeam = team == null ? "" : " on team §e" + team + "§r";
                        source.sendSuccess(() -> VexText.literal(String.format(Locale.ROOT, "[VexBot] Spawning %s at %.1f %.1f %.1f with kit §e%s§r%s…", botName, pos.x, pos.y, pos.z, kitName, onTeam)), false);
                        return 1;
                     }
                  }
               }
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] spawnBotAtWithKit crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Internal error: " + t.getMessage()));
         return 0;
      }
   }

   private static int teamMassSpawn(CommandSourceStack source, String teamName, int amount, String kitName) {
      return teamMassSpawn(source, teamName, amount, kitName, computeMassSpawnPivot(source));
   }

   private static int teamMassSpawnAt(CommandSourceStack source, String teamName, int amount, String kitName, Vec3 pos) {
      return teamMassSpawn(source, teamName, amount, kitName, pivotAt(source, pos));
   }

   private static int teamMassSpawn(CommandSourceStack source, String teamName, int amount, String kitName, MassSpawnPivot pivot) {
      try {
         if (!BotSettings.advancedSpawn) {
            source.sendFailure(VexText.literal("[VexBot] Team mass-spawn is off. Enable it with §e/vexbot settings advancedspawn true§r."));
            return 0;
         } else if (!TeamManager.exists(teamName)) {
            source.sendFailure(VexText.literal("[VexBot] §cTeam '" + teamName + "' does not exist.§r Create it first with §e/vexbot team create " + teamName + "§r."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            boolean randomGear = kitName == null;
            if (!randomGear && !KitManager.exists(server, kitName)) {
               source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot givekit list§r."));
               return 0;
            } else {
               ItemStack[] stacks = randomGear ? null : KitManager.load(server, kitName);
               ItemStack[] kitEnderChest = randomGear ? null : KitManager.loadEnder(server, kitName);
               List<String> spawned = spawnGrid(source, amount, pivot, teamName);
               if (spawned.isEmpty()) {
                  source.sendFailure(VexText.literal("[VexBot] Could not spawn any bots."));
                  return 0;
               } else {
                  TeamManager.addBotsToTeam(teamName, spawned);

                  for(String n : spawned) {
                     if (randomGear) {
                        BotManager.setPendingRandomGear(n);
                     } else if (stacks != null) {
                        BotManager.setPendingKit(n, stacks, kitEnderChest);
                     }
                  }

                  SettingsPersistence.save(server);
                  int n = spawned.size();
                  String gear = randomGear ? "§drandom gear§r" : "kit §e" + kitName + "§r";
                  source.sendSuccess(() -> VexText.literal("[VexBot] Queuing §e" + n + "§r bot(s) onto team §e" + teamName + "§r with " + gear + " — staggered, one per server tick."), false);
                  return n;
               }
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] teamMassSpawn crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Internal error: " + t.getMessage()));
         return 0;
      }
   }

   private static int teamAlliance(CommandSourceStack source, String teamA, String teamB, boolean add) {
      if (!TeamManager.exists(teamA)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + teamA + "' does not exist."));
         return 0;
      } else if (!TeamManager.exists(teamB)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + teamB + "' does not exist."));
         return 0;
      } else if (teamA.equalsIgnoreCase(teamB)) {
         source.sendFailure(VexText.literal("[VexBot] A team can't ally itself."));
         return 0;
      } else {
         boolean changed = add ? TeamManager.addAlliance(teamA, teamB) : TeamManager.removeAlliance(teamA, teamB);
         if (!changed) {
            source.sendFailure(VexText.literal("[VexBot] §7No change — §e" + teamA + "§7 and §e" + teamB + "§7 are already " + (add ? "allied" : "not allied") + "."));
            return 0;
         } else {
            SettingsPersistence.save(source.getServer());
            source.sendSuccess(() -> VexText.literal(add ? "[VexBot] §aAllied §e" + teamA + "§a and §e" + teamB + "§a — their bots won't attack each other." : "[VexBot] §aBroke the alliance between §e" + teamA + "§a and §e" + teamB + "§a."), false);
            return 1;
         }
      }
   }

   private static int teamAllianceList(CommandSourceStack source, String teamName) {
      if (!TeamManager.exists(teamName)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + teamName + "' does not exist."));
         return 0;
      } else {
         Set<String> allies = TeamManager.get(teamName).getAllies();
         String out = allies.isEmpty() ? "[VexBot] Team §e" + teamName + "§r has no alliances." : "[VexBot] Team §e" + teamName + "§r is allied with: §a" + String.join("§r, §a", allies);
         source.sendSuccess(() -> VexText.literal(out), false);
         return 1;
      }
   }

   private static int teamAllianceClear(CommandSourceStack source, String teamName) {
      if (!TeamManager.exists(teamName)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + teamName + "' does not exist."));
         return 0;
      } else {
         int n = TeamManager.clearAlliances(teamName);
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §aCleared §e" + n + "§a alliance(s) for team §e" + teamName + "§a."), false);
         return n > 0 ? 1 : 0;
      }
   }

   private static int killOne(CommandSourceStack source, String name) {
      boolean ok = BotManager.kill(source.getServer(), name);
      if (ok) {
         source.sendSuccess(() -> VexText.literal("[VexBot] Killed " + name + "."), false);
      } else {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + name + "' found."));
      }

      return ok ? 1 : 0;
   }

   private static int killAll(CommandSourceStack source) {
      int n = BotManager.killAll(source.getServer());
      source.sendSuccess(() -> VexText.literal("[VexBot] Killed " + n + " bot(s)."), false);
      return n;
   }

   private static int movementFreeze(CommandSourceStack source) {
      BotSettings.movementFrozen = true;
      MinecraftServer server = source.getServer();

      for(String name : BotManager.getBotNames()) {
         BotCommands.stopMoving(server, name);
      }

      source.sendSuccess(() -> VexText.literal("[VexBot] Bot movement frozen (they still fight). Use /vexbot movement unfreeze to resume."), false);
      return 1;
   }

   private static int movementUnfreeze(CommandSourceStack source) {
      BotSettings.movementFrozen = false;
      source.sendSuccess(() -> VexText.literal("[VexBot] Bot movement unfrozen."), false);
      return 1;
   }

   private static int deletekitRoot(CommandSourceStack source) {
      return source.getPlayer() != null ? openDeleteKitGui(source) : KitCli.listKits(source, source.getServer());
   }

   private static int teamcreateRoot(CommandSourceStack source, String teamName) {
      return source.getPlayer() != null ? openTeamBuilderGui(source, teamName, false) : TeamCreateCli.show(source, teamName);
   }

   private static int teamMembersAdd(CommandContext<CommandSourceStack> ctx, String teamName) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();
      List<String> names = BotTargetArgument.resolveNamesGated(ctx, "targets");
      if (names == null) {
         return 0;
      } else {
         MinecraftServer server = source.getServer();
         List<String> bots = new ArrayList();

         for(String n : names) {
            if (BotManager.resolveTrackedBotPlayer(server, n) != null) {
               bots.add(n);
            }
         }

         if (bots.isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No spawned bots matched."));
            return 0;
         } else {
            int added = TeamManager.addBotsToTeam(teamName, bots);
            SettingsPersistence.save(server);
            int m = bots.size();
            source.sendSuccess(() -> VexText.literal("[VexBot] §aAdded §e" + added + "§a bot(s)§r to team §e" + teamName + "§r" + (m > added ? " §7(" + (m - added) + " already in)" : "") + "."), false);
            return 1;
         }
      }
   }

   private static int teamMembersAddAll(CommandSourceStack source, String teamName) {
      List<String> all = new ArrayList(BotManager.getBotNames());
      if (all.isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] No bots are spawned to add."));
         return 0;
      } else {
         int added = TeamManager.addBotsToTeam(teamName, all);
         SettingsPersistence.save(source.getServer());
         int total = all.size();
         source.sendSuccess(() -> VexText.literal("[VexBot] §aAdded all §e" + added + "§a/" + total + " bot(s)§r to team §e" + teamName + "§r."), false);
         return 1;
      }
   }

   private static int teamMembersAddNear(CommandSourceStack source, String teamName, double radius) {
      MinecraftServer server = source.getServer();
      Vec3 origin = source.getPosition();
      Level level = source.getLevel();
      double r2 = radius * radius;
      List<String> near = new ArrayList();

      for(String name : BotManager.getBotNames()) {
         ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, name);
         if (bot != null && bot.level() == level && bot.position().distanceToSqr(origin) <= r2) {
            near.add(name);
         }
      }

      if (near.isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] No spawned bots within §e" + radius + "§r blocks."));
         return 0;
      } else {
         int added = TeamManager.addBotsToTeam(teamName, near);
         SettingsPersistence.save(server);
         int m = near.size();
         source.sendSuccess(() -> VexText.literal("[VexBot] §aAdded §e" + added + "§a bot(s)§r within §e" + radius + "§r blocks to team §e" + teamName + "§r" + (m > added ? " §7(" + (m - added) + " already in)" : "") + "."), false);
         return 1;
      }
   }

   private static int randomGearTargets(CommandContext<CommandSourceStack> ctx) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();
      List<String> names = BotTargetArgument.resolveNamesGated(ctx, "targets");
      if (names == null) {
         return 0;
      } else {
         MinecraftServer server = source.getServer();
         int n = 0;

         for(String name : names) {
            ServerPlayer who = BotManager.resolveTrackedBotPlayer(server, name);
            if (who == null) {
               who = server.getPlayerList().getPlayerByName(name);
            }

            if (who != null) {
               RandomGearGenerator.apply(who);
               ++n;
            }
         }

         if (n == 0) {
            source.sendFailure(VexText.literal("[VexBot] No bots or players matched."));
            return 0;
         } else {
            source.sendSuccess(() -> VexText.literal("[VexBot] §aRolled random gear for §e" + n + "§a target(s)§r."), false);
            return n;
         }
      }
   }

   private static int randomChestLootSelf(CommandSourceStack source) {
      Entity var2 = source.getEntity();
      if (var2 instanceof ServerPlayer player) {
         giveLootChest(player);
         source.sendSuccess(() -> VexText.literal("[VexBot] §aGave you a §dRandom Loot Chest§a — place it and it fills with random loot (a different table each time)."), false);
         return 1;
      } else {
         source.sendFailure(VexText.literal("[VexBot] From a command block, name a target: §e/vexbot randomchestloot <player/@a>§r."));
         return 0;
      }
   }

   private static int randomChestLootTargets(CommandContext<CommandSourceStack> ctx) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();
      List<String> names = BotTargetArgument.resolveNamesGated(ctx, "targets");
      if (names == null) {
         return 0;
      } else {
         MinecraftServer server = source.getServer();
         int n = 0;

         for(String name : names) {
            ServerPlayer who = BotManager.resolveTrackedBotPlayer(server, name);
            if (who == null) {
               who = server.getPlayerList().getPlayerByName(name);
            }

            if (who != null) {
               giveLootChest(who);
               ++n;
            }
         }

         if (n == 0) {
            source.sendFailure(VexText.literal("[VexBot] No bots or players matched."));
            return 0;
         } else {
            source.sendSuccess(() -> VexText.literal("[VexBot] §aGave §e" + n + "§a target(s) a §dRandom Loot Chest§a."), false);
            return n;
         }
      }
   }

   private static int lootChestReplace(CommandSourceStack source, int radius) {
      ServerLevel level = source.getLevel();
      BlockPos centre = BlockPos.containing(source.getPosition());
      int n = LootChestOps.replaceNearby(level, centre, radius);
      if (n == 0) {
         source.sendFailure(VexText.literal("[VexBot] No chests found within §e" + radius + "§r blocks."));
         return 0;
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] §aTurned §e" + n + "§a chest(s) within §e" + radius + "§a blocks into §dRandom Loot Chests§a — each rolled separately."), true);
         return n;
      }
   }

   private static void giveLootChest(ServerPlayer who) {
      ItemStack chest = RandomGearGenerator.makeLootChestItem();
      if (!who.getInventory().add(chest) && !chest.isEmpty()) {
         McCompat.drop(who, chest, false);
      }

      who.containerMenu.broadcastChanges();
   }

   private static int teamRandomGear(CommandSourceStack source, String teamName) {
      if (!TeamManager.exists(teamName)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + teamName + "' does not exist."));
         return 0;
      } else {
         MinecraftServer server = source.getServer();
         int n = 0;

         for(String name : TeamManager.get(teamName).getBotNames()) {
            ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, name);
            if (bot != null) {
               RandomGearGenerator.apply(bot);
               ++n;
            }
         }

         if (n == 0) {
            source.sendFailure(VexText.literal("[VexBot] No spawned bots on team §e" + teamName + "§r."));
            return 0;
         } else {
            source.sendSuccess(() -> VexText.literal("[VexBot] §aRolled random gear for §e" + n + "§a bot(s)§r on team §e" + teamName + "§r."), false);
            return n;
         }
      }
   }

   private static int rgcSet(CommandSourceStack source, RandomGearConfig cfg, String scope, String key, boolean v) {
      String k = key.toLowerCase(Locale.ROOT);
      if (!RandomGearConfig.isValidKey(k)) {
         source.sendFailure(VexText.literal("[VexBot] Unknown key '§e" + key + "§r'. Try: §e" + String.join(", ", RandomGearConfig.KEYS) + "§r, or §eallowfood <food>§r."));
         return 0;
      } else {
         cfg.setAllow(k, v);
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §a" + k + "§r (" + scope + ") = " + (v ? "§atrue" : "§cfalse")), false);
         return 1;
      }
   }

   private static int rgcSetFood(CommandSourceStack source, RandomGearConfig cfg, String scope, String food, boolean v) {
      String f = food.toLowerCase(Locale.ROOT);
      String[] foods = RandomGearGenerator.foodNames();
      if (!Arrays.asList(foods).contains(f)) {
         source.sendFailure(VexText.literal("[VexBot] Unknown food '§e" + food + "§r'. Try: §e" + String.join(", ", foods) + "§r."));
         return 0;
      } else {
         cfg.setFood(f, v);
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §afood " + f + "§r (" + scope + ") = " + (v ? "§atrue" : "§cfalse")), false);
         return 1;
      }
   }

   private static int rgcList(CommandSourceStack source, RandomGearConfig cfg, String scope) {
      StringBuilder sb = new StringBuilder("[VexBot] §bRandom-gear config §7(" + scope + ")§r — anything not listed is allowed:");
      boolean any = false;

      for(Map.Entry<String, Boolean> e : cfg.categories().entrySet()) {
         if (!(Boolean)e.getValue()) {
            sb.append("\n  §c").append((String)e.getKey()).append(" §7= off");
            any = true;
         }
      }

      for(Map.Entry<String, Boolean> e : cfg.foods().entrySet()) {
         if (!(Boolean)e.getValue()) {
            sb.append("\n  §cfood ").append((String)e.getKey()).append(" §7= off");
            any = true;
         }
      }

      if (!any) {
         sb.append("\n  §a(everything allowed)");
      }

      String out = sb.toString();
      source.sendSuccess(() -> VexText.literal(out), false);
      return 1;
   }

   private static RandomGearConfig teamRgc(CommandSourceStack source, String team) {
      if (!TeamManager.exists(team)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + team + "' does not exist."));
         return null;
      } else {
         return TeamManager.get(team).randomGearConfig;
      }
   }

   private static int rgcSetTeam(CommandSourceStack source, String team, String key, boolean v) {
      RandomGearConfig cfg = teamRgc(source, team);
      return cfg == null ? 0 : rgcSet(source, cfg, "team " + team, key, v);
   }

   private static int rgcSetFoodTeam(CommandSourceStack source, String team, String food, boolean v) {
      RandomGearConfig cfg = teamRgc(source, team);
      return cfg == null ? 0 : rgcSetFood(source, cfg, "team " + team, food, v);
   }

   private static int rgcListTeam(CommandSourceStack source, String team) {
      RandomGearConfig cfg = teamRgc(source, team);
      return cfg == null ? 0 : rgcList(source, cfg, "team " + team);
   }

   private static int teamMembersRemove(CommandContext<CommandSourceStack> ctx, String teamName) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();
      List<String> names = BotTargetArgument.resolveNamesGated(ctx, "targets");
      if (names == null) {
         return 0;
      } else {
         int removed = TeamManager.removeBotsFromTeam(teamName, names);
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §eRemoved §6" + removed + "§e bot(s)§r from team §e" + teamName + "§r."), false);
         return 1;
      }
   }

   private static int openTeamBuilderGui(CommandSourceStack source, String teamName, boolean membersOnly) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Team-builder GUI requires a player. Use §e/vexbot team create " + teamName + " list§r or subcommands like §eaddbot§r."));
            return 0;
         } else {
            TeamManager.getOrCreate(teamName);
            MinecraftServer server = source.getServer();
            String title = membersOnly ? "Team members: " + teamName : "Build Team: " + teamName;
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamBuilderMenu(id, inv, server, teamName, membersOnly), VexText.literal(title)));
            source.sendSuccess(() -> {
               String var10000 = PlayerMenuHelper.formatOnlineHumanSummary(server, teamName);
               return VexText.literal("[VexBot] Bottom row = online real players (friends / LAN). " + var10000);
            }, false);
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openTeamBuilderGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int teamtargetsRoot(CommandSourceStack source, String teamName) {
      return source.getPlayer() != null ? openTeamTargetsGui(source, teamName) : TeamTargetsCli.show(source, teamName);
   }

   private static int openTeamTargetsGui(CommandSourceStack source, String teamName) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Team-targets GUI requires a player. Use §e/vexbot team " + teamName + " targets list§r or subcommands like §emode§r, §eadd§r."));
            return 0;
         } else if (!TeamManager.exists(teamName)) {
            source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r' exists."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamTargetsMenu(id, inv, server, teamName), VexText.literal("Team targets: " + teamName)));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openTeamTargetsGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int teamDeleteNow(CommandSourceStack source, String teamName) {
      if (!TeamManager.exists(teamName)) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r' exists."));
         return 0;
      } else {
         TeamManager.delete(teamName);
         RestockPlan.clear(teamName);
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §aDeleted team §e" + teamName + "§a. (Bots themselves are not removed.)"), false);
         return 1;
      }
   }

   private static int openTeamDeleteConfirm(CommandSourceStack source, String teamName) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] From a command block/console use §e/vexbot team delete " + teamName + " confirm§r."));
            return 0;
         } else if (!TeamManager.exists(teamName)) {
            source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r' exists."));
            return 0;
         } else {
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamDeleteConfirmMenu(id, inv, teamName), VexText.literal("Delete Team: " + teamName)));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openTeamDeleteConfirm crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int teamJoin(CommandSourceStack source, String teamName) {
      try {
         ServerPlayer player = source.getPlayerOrException();
         if (player.isSpectator()) {
            source.sendFailure(VexText.literal("[VexBot] Spectators cannot join a team."));
            return 0;
         } else if (!TeamManager.exists(teamName)) {
            source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'. Ask an admin to run §e/vexbot team create " + teamName + "§r first."));
            return 0;
         } else {
            String name = player.getName().getString();
            TeamManager.addPlayerToTeam(teamName, name);
            SettingsPersistence.save(source.getServer());
            source.sendSuccess(() -> VexText.literal("[VexBot] You joined team §e" + teamName + "§r."), false);
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] teamJoin crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int teamJoinTargets(CommandContext<CommandSourceStack> ctx, String teamName) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();
      if (!TeamManager.exists(teamName)) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'. Create it with §e/vexbot team create " + teamName + "§r first."));
         return 0;
      } else {
         List<ServerPlayer> matched = BotTargetArgument.resolve(source, BotTargetArgument.get(ctx, "targets"));
         if (matched.isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No players or bots matched."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            List<String> botNames = new ArrayList();
            int players = 0;

            for(ServerPlayer p : matched) {
               String n = p.getName().getString();
               if (BotManager.resolveTrackedBotPlayer(server, n) != null) {
                  botNames.add(n);
               } else if (!p.isSpectator()) {
                  TeamManager.addPlayerToTeam(teamName, n);
                  ++players;
               }
            }

            int bots = botNames.isEmpty() ? 0 : TeamManager.addBotsToTeam(teamName, botNames);
            SettingsPersistence.save(server);
            if (players + bots == 0) {
               source.sendFailure(VexText.literal("[VexBot] Nothing added (spectators skipped)."));
               return 0;
            } else {
               source.sendSuccess(() -> VexText.literal("[VexBot] §aAdded §e" + (players + bots) + "§r to team §e" + teamName + "§r §7(" + players + " player(s), " + bots + " bot(s))."), false);
               return players + bots;
            }
         }
      }
   }

   private static int teamLeaveTargets(CommandContext<CommandSourceStack> ctx) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();
      List<ServerPlayer> matched = BotTargetArgument.resolve(source, BotTargetArgument.get(ctx, "targets"));
      if (matched.isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] No players or bots matched."));
         return 0;
      } else {
         MinecraftServer server = source.getServer();
         int removed = 0;

         for(ServerPlayer p : matched) {
            String n = p.getName().getString();
            TeamManager.BotTeam team = TeamManager.getTeamForMember(n);
            if (team != null) {
               if (BotManager.resolveTrackedBotPlayer(server, n) != null) {
                  TeamManager.removeBotsFromTeam(team.getName(), List.of(n));
               } else {
                  TeamManager.removePlayerFromTeam(team.getName(), n);
               }

               ++removed;
            }
         }

         if (removed == 0) {
            source.sendFailure(VexText.literal("[VexBot] None of the matched targets were on a team."));
            return 0;
         } else {
            SettingsPersistence.save(server);
            source.sendSuccess(() -> VexText.literal("[VexBot] §aRemoved §e" + removed + "§a from their team(s)."), false);
            return removed;
         }
      }
   }

   private static int teamLeave(CommandSourceStack source) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] From a command block, use §e/vexbot team leave <player/@a/@b>§r to remove specific members."));
            return 0;
         } else {
            String name = player.getName().getString();
            TeamManager.BotTeam team = TeamManager.getTeamForMember(name);
            if (team == null) {
               source.sendFailure(VexText.literal("[VexBot] You are not on any team roster."));
               return 0;
            } else {
               TeamManager.removePlayerFromTeam(team.getName(), name);
               SettingsPersistence.save(source.getServer());
               source.sendSuccess(() -> VexText.literal("[VexBot] Removed you from team §e" + team.getName() + "§r."), false);
               return 1;
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] teamLeave crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int tagStatus(CommandSourceStack source) {
      boolean on = BotSettings.showTags;
      source.sendSuccess(() -> VexText.literal("[VexBot] Nametag tags are " + (on ? "§aon" : "§coff") + "§r. Use §e/vexbot tag on§r or §e/vexbot tag off§r."), false);
      return on ? 1 : 0;
   }

   private static int setTags(CommandSourceStack source, boolean on) {
      BotSettings.showTags = on;
      NameTagPainter.repaint();
      SettingsPersistence.save(source.getServer());
      source.sendSuccess(() -> VexText.literal("[VexBot] Nametag tags " + (on ? "§aon§r — §bBOT§r on bots, §eDEV§r on developers." : "§coff§r.")), true);
      return 1;
   }

   private static int listBots(CommandSourceStack source) {
      Set<String> names = BotManager.getBotNames();
      if (names.isEmpty()) {
         source.sendSuccess(() -> VexText.literal("[VexBot] No bots active."), false);
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] Active: " + String.join(", ", names)), false);
      }

      return names.size();
   }

   private static int showVersion(CommandSourceStack source) {
      String version = Platform.get().modVersion();
      source.sendSuccess(() -> VexText.literal("[VexBot] Version: " + version), false);
      return 1;
   }

   private static int createKit(CommandSourceStack source, String name) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("Must be run as a player."));
            return 0;
         } else if (KitManager.exists(source.getServer(), name)) {
            source.sendFailure(VexText.literal("[VexBot] A kit named '§e" + name + "§c' already exists. Delete it first or choose a different name."));
            return 0;
         } else {
            KitManager.save(source.getServer(), player, name);
            source.sendSuccess(() -> VexText.literal("[VexBot] Saved kit '§e" + name + "§r' from your inventory."), false);
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] createKit crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int openDeleteKitGui(CommandSourceStack source) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Delete-kit GUI requires a player. Use §e/vexbot deletekit <kit>§r."));
            return 0;
         } else if (KitManager.list(source.getServer()).isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No kits saved yet."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, server, KitListMenu.Mode.DELETE), VexText.literal("Delete a Kit")));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openDeleteKitGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int startAttack(CommandSourceStack source, String playerName, String botName) {
      if (!BotManager.getBotNames().contains(botName)) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else {
         MinecraftServer server = source.getServer();
         ServerPlayer target = BotManager.resolvePlayerOrBotByName(server, playerName);
         if (target == null) {
            source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + playerName + "§r'."));
            return 0;
         } else if (target.getName().getString().equalsIgnoreCase(botName)) {
            source.sendFailure(VexText.literal("[VexBot] A bot cannot attack itself."));
            return 0;
         } else {
            String resolved = target.getName().getString();
            if (TeamManager.isAlliedWithBot(botName, resolved)) {
               source.sendFailure(VexText.literal("[VexBot] §e" + resolved + "§r is on the same team as §e" + botName + "§r."));
               return 0;
            } else {
               BotManager.setAttackTarget(botName, resolved, true);
               source.sendSuccess(() -> VexText.literal("[VexBot] §e" + botName + "§r is now attacking §e" + resolved + "§r."), false);
               return 1;
            }
         }
      }
   }

   private static int stopAttack(CommandSourceStack source, String botName) {
      if (!BotManager.getBotNames().contains(botName)) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else {
         BotManager.clearAttackTarget(botName);
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + botName + "§r stopped attacking."), false);
         return 1;
      }
   }

   private static List<String> onlineHumanNames(MinecraftServer server) {
      return (List)server.getPlayerList().getPlayers().stream().filter((p) -> !McCompat.tags(p).contains("vexbot")).map((p) -> p.getName().getString()).distinct().sorted().collect(Collectors.toList());
   }

   private static List<String> lookAtTargetNames(MinecraftServer server) {
      LinkedHashSet<String> names = new LinkedHashSet();
      names.addAll(BotManager.getBotNames());
      names.addAll(onlineHumanNames(server));
      return (List)names.stream().sorted().collect(Collectors.toList());
   }

   private static BotSettings.PlayStyle parsePlayStyle(String raw) {
      BotSettings.PlayStyle var10000;
      switch (raw == null ? "" : raw.strip().toLowerCase(Locale.ROOT)) {
         case "default":
         case "normal":
         case "standard":
         case "reset":
         case "none":
            var10000 = BotSettings.PlayStyle.DEFAULT;
            break;
         case "safe":
         case "safety":
         case "careful":
         case "passive":
            var10000 = BotSettings.PlayStyle.SAFE;
            break;
         case "defensive":
         case "defense":
         case "defence":
         case "guard":
            var10000 = BotSettings.PlayStyle.DEFENSIVE;
            break;
         case "balanced":
         case "balance":
         case "neutral":
            var10000 = BotSettings.PlayStyle.BALANCED;
            break;
         case "aggressive":
         case "aggro":
         case "offensive":
            var10000 = BotSettings.PlayStyle.AGGRESSIVE;
            break;
         case "adaptive":
         case "adapt":
         case "auto":
         case "match":
            var10000 = BotSettings.PlayStyle.ADAPTIVE;
            break;
         default:
            throw new IllegalArgumentException("Unknown playstyle '§e" + raw + "§r'. Use: §edefault§r, §esafe§r, §edefensive§r, §ebalanced§r, §eaggressive§r, or §eadaptive§r.");
      }

      return var10000;
   }

   private static int playStyleSet(CommandContext<CommandSourceStack> ctx) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();

      BotSettings.PlayStyle style;
      try {
         style = parsePlayStyle(StringArgumentType.getString(ctx, "style"));
      } catch (IllegalArgumentException e) {
         source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
         return 0;
      }

      List<String> names = BotTargetArgument.resolveNamesGated(ctx, "targets");
      if (names == null) {
         return 0;
      } else {
         int n = 0;

         for(String name : names) {
            String canonical = BotManager.resolveCanonicalBotName(name);
            if (canonical != null) {
               BotSettings.setPlayStyle(canonical, style);
               ++n;
            }
         }

         if (n == 0) {
            source.sendFailure(VexText.literal("[VexBot] No bots matched."));
            return 0;
         } else {
            SettingsPersistence.save(source.getServer());
            source.sendSuccess(() -> VexText.literal("[VexBot] §aSet §e" + n + "§a bot(s) to playstyle §e" + style.name().toLowerCase(Locale.ROOT) + "§a."), false);
            return n;
         }
      }
   }

   private static int randomPlayStyleSet(CommandContext<CommandSourceStack> ctx) {
      CommandSourceStack source = (CommandSourceStack)ctx.getSource();
      List<String> names = BotTargetArgument.resolveNamesGated(ctx, "targets");
      if (names == null) {
         return 0;
      } else {
         Random rng = new Random();
         int n = 0;
         StringBuilder detail = new StringBuilder();

         for(String name : names) {
            String canonical = BotManager.resolveCanonicalBotName(name);
            if (canonical != null) {
               BotSettings.PlayStyle style = BotSettings.rollPlayStyle(rng);
               if (style == null) {
                  source.sendFailure(VexText.literal("[VexBot] Every playstyle weight is 0 — nothing can be rolled. Set one with §e/vexbot randomplaystylechances <style> <weight>§r."));
                  return 0;
               }

               BotSettings.setPlayStyle(canonical, style);
               if (n < 8) {
                  detail.append(n == 0 ? "" : ", ").append("§f").append(canonical).append("§7=").append(style.name().toLowerCase(Locale.ROOT));
               }

               ++n;
            }
         }

         if (n == 0) {
            source.sendFailure(VexText.literal("[VexBot] No bots matched."));
            return 0;
         } else {
            SettingsPersistence.save(source.getServer());
            String var10000 = String.valueOf(detail);
            String shown = var10000 + (n > 8 ? ", …" : "");
            source.sendSuccess(() -> VexText.literal("[VexBot] §aRolled a playstyle for §e" + n + "§a bot(s): §7" + shown), false);
            return n;
         }
      }
   }

   private static int randomPlayStyleAll(CommandSourceStack source) {
      Random rng = new Random();
      int n = 0;

      for(String name : BotManager.getBotNames()) {
         BotSettings.PlayStyle style = BotSettings.rollPlayStyle(rng);
         if (style == null) {
            source.sendFailure(VexText.literal("[VexBot] Every playstyle weight is 0 — nothing can be rolled."));
            return 0;
         }

         BotSettings.setPlayStyle(name, style);
         ++n;
      }

      if (n == 0) {
         source.sendFailure(VexText.literal("[VexBot] No bots are online."));
         return 0;
      } else {
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §aRolled an independent playstyle for all §e" + n + "§a bot(s)."), false);
         return n;
      }
   }

   private static int randomPlayStyleChancesList(CommandSourceStack source) {
      int total = 0;

      for(int w : BotSettings.playStyleChances.values()) {
         total += Math.max(0, w);
      }

      StringBuilder sb = new StringBuilder("[VexBot] §6Random playstyle weights§r");

      for(BotSettings.PlayStyle st : BotSettings.PlayStyle.values()) {
         int w = Math.max(0, (Integer)BotSettings.playStyleChances.getOrDefault(st, 0));
         String pct = total > 0 ? String.format(Locale.ROOT, " §8(%.0f%%)", (double)100.0F * (double)w / (double)total) : "";
         sb.append("\n  §e").append(st.name().toLowerCase(Locale.ROOT)).append("§r ").append(w).append(pct);
      }

      if (total == 0) {
         sb.append("\n  §cEverything is 0 — /vexbot randomplaystyle can't roll.");
      }

      String out = sb.toString();
      source.sendSuccess(() -> VexText.literal(out), false);
      return 1;
   }

   private static int randomPlayStyleChanceSet(CommandSourceStack source, String styleRaw, int weight) {
      BotSettings.PlayStyle style;
      try {
         style = parsePlayStyle(styleRaw);
      } catch (IllegalArgumentException e) {
         source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
         return 0;
      }

      BotSettings.playStyleChances.put(style, Math.max(0, weight));
      SettingsPersistence.save(source.getServer());
      source.sendSuccess(() -> {
         String var10000 = style.name().toLowerCase(Locale.ROOT);
         return VexText.literal("[VexBot] §aWeight for §e" + var10000 + "§a is now §e" + weight + "§a. §7(weights are relative, they don't need to total 100)");
      }, false);
      return 1;
   }

   private static int randomPlayStyleChancesReset(CommandSourceStack source) {
      BotSettings.playStyleChances.put(BotSettings.PlayStyle.DEFAULT, 25);
      BotSettings.playStyleChances.put(BotSettings.PlayStyle.SAFE, 15);
      BotSettings.playStyleChances.put(BotSettings.PlayStyle.DEFENSIVE, 15);
      BotSettings.playStyleChances.put(BotSettings.PlayStyle.BALANCED, 20);
      BotSettings.playStyleChances.put(BotSettings.PlayStyle.AGGRESSIVE, 25);
      BotSettings.playStyleChances.put(BotSettings.PlayStyle.ADAPTIVE, 0);
      SettingsPersistence.save(source.getServer());
      source.sendSuccess(() -> VexText.literal("[VexBot] §aPlaystyle weights back to defaults."), false);
      return 1;
   }

   private static int renameKit(CommandSourceStack source, String from, String to) {
      String err = KitManager.rename(source.getServer(), from, to);
      if (err != null) {
         source.sendFailure(VexText.literal("[VexBot] §c" + err));
         return 0;
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] §aKit §e" + from + "§a renamed to §e" + to + "§a."), true);
         return 1;
      }
   }

   private static int playStyleAll(CommandSourceStack source, String styleRaw) {
      BotSettings.PlayStyle style;
      try {
         style = parsePlayStyle(styleRaw);
      } catch (IllegalArgumentException e) {
         source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
         return 0;
      }

      int n = 0;

      for(String name : BotManager.getBotNames()) {
         BotSettings.setPlayStyle(name, style);
         ++n;
      }

      if (n == 0) {
         source.sendFailure(VexText.literal("[VexBot] No bots are online."));
         return 0;
      } else {
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] §aSet ALL §e" + n + "§a bot(s) to playstyle §e" + style.name().toLowerCase(Locale.ROOT) + "§a."), false);
         return n;
      }
   }

   private static int teamPlayStyle(CommandSourceStack source, String teamName, String styleRaw) {
      if (!TeamManager.exists(teamName)) {
         source.sendFailure(VexText.literal("[VexBot] §cTeam '" + teamName + "' does not exist."));
         return 0;
      } else {
         BotSettings.PlayStyle style;
         try {
            style = parsePlayStyle(styleRaw);
         } catch (IllegalArgumentException e) {
            source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
            return 0;
         }

         int n = 0;

         for(String name : TeamManager.get(teamName).getBotNames()) {
            BotSettings.setPlayStyle(name, style);
            ++n;
         }

         if (n == 0) {
            source.sendFailure(VexText.literal("[VexBot] Team §e" + teamName + "§r has no bots."));
            return 0;
         } else {
            SettingsPersistence.save(source.getServer());
            source.sendSuccess(() -> VexText.literal("[VexBot] §aTeam §e" + teamName + "§a (§e" + n + "§a bot(s)) set to playstyle §e" + style.name().toLowerCase(Locale.ROOT) + "§a."), false);
            return n;
         }
      }
   }

   private static int playStyleList(CommandSourceStack source) {
      if (BotSettings.playStyles.isEmpty()) {
         source.sendSuccess(() -> VexText.literal("[VexBot] No playstyles set — every bot plays §edefault§r."), false);
         return 1;
      } else {
         StringBuilder sb = new StringBuilder("[VexBot] §bPlaystyles§r (unlisted bots = default):");
         BotSettings.playStyles.entrySet().stream().sorted(Entry.comparingByKey(String.CASE_INSENSITIVE_ORDER)).forEach((e) -> sb.append("\n  §e").append((String)e.getKey()).append("§r = §f").append(((BotSettings.PlayStyle)e.getValue()).name().toLowerCase(Locale.ROOT)));
         String out = sb.toString();
         source.sendSuccess(() -> VexText.literal(out), false);
         return BotSettings.playStyles.size();
      }
   }

   private static String teamArg(CommandContext<CommandSourceStack> ctx) {
      return StringArgumentType.getString(ctx, "teamName");
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamOrdersShow() {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("orders").executes((ctx) -> openAdvancedTeamSettings((CommandSourceStack)ctx.getSource(), teamArg(ctx)))).then(Commands.literal("show").executes((ctx) -> TeamCommand.show((CommandSourceStack)ctx.getSource(), teamArg(ctx))));
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamOrdersFormation() {
      return (LiteralArgumentBuilder)Commands.literal("formation").then(((RequiredArgumentBuilder)Commands.argument("shape", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(FollowFormation.names(), b)).executes((ctx) -> TeamCommand.setFormation((CommandSourceStack)ctx.getSource(), teamArg(ctx), StringArgumentType.getString(ctx, "shape"), 0))).then(Commands.argument("size", IntegerArgumentType.integer(1, 50)).executes((ctx) -> TeamCommand.setFormation((CommandSourceStack)ctx.getSource(), teamArg(ctx), StringArgumentType.getString(ctx, "shape"), IntegerArgumentType.getInteger(ctx, "size")))));
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamOrdersBoss() {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("boss").then(Commands.literal("clear").executes((ctx) -> TeamCommand.setBoss((CommandSourceStack)ctx.getSource(), teamArg(ctx), (String)null)))).then(Commands.argument("bot", StringArgumentType.word()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> TeamCommand.setBoss((CommandSourceStack)ctx.getSource(), teamArg(ctx), StringArgumentType.getString(ctx, "bot"))));
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamOrdersHorn() {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("horn").then(Commands.literal("clear").executes((ctx) -> TeamCommand.clearHorn((CommandSourceStack)ctx.getSource(), teamArg(ctx))))).then(Commands.literal("call").executes((ctx) -> TeamCommand.blowHornNow((CommandSourceStack)ctx.getSource(), teamArg(ctx))))).then(Commands.argument("player", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(((CommandSourceStack)c.getSource()).getOnlinePlayerNames(), b)).then(((RequiredArgumentBuilder)Commands.argument("variant", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(TeamHornSummon.hornSuggestions(), b)).executes((ctx) -> TeamCommand.setHorn((CommandSourceStack)ctx.getSource(), teamArg(ctx), StringArgumentType.getString(ctx, "player"), StringArgumentType.getString(ctx, "variant"), (String)null))).then(Commands.argument("shape", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(FollowFormation.names(), b)).executes((ctx) -> TeamCommand.setHorn((CommandSourceStack)ctx.getSource(), teamArg(ctx), StringArgumentType.getString(ctx, "player"), StringArgumentType.getString(ctx, "variant"), StringArgumentType.getString(ctx, "shape"))))));
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamOrderToggle(String key) {
      return (LiteralArgumentBuilder)Commands.literal(key).then(Commands.argument("value", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"on", "off"}, b)).executes((ctx) -> {
         String raw = StringArgumentType.getString(ctx, "value");
         Boolean on = parseOnOff(raw);
         if (on == null) {
            ((CommandSourceStack)ctx.getSource()).sendFailure(VexText.literal("[VexBot] '§e" + raw + "§r' is not on/off. Use §eon§r or §eoff§r."));
            return 0;
         } else {
            return TeamCommand.setToggle((CommandSourceStack)ctx.getSource(), teamArg(ctx), key, on);
         }
      }));
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamSpreadOut() {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("spread-out").executes((ctx) -> SettingsCli.showOne((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.forTeam(teamArg(ctx)), "spread-out"))).then(Commands.argument("value", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(new String[]{"true", "false"}, b)).executes((ctx) -> SettingsCli.apply((CommandSourceStack)ctx.getSource(), GameplaySettingsScope.forTeam(teamArg(ctx)), "spread-out", StringArgumentType.getString(ctx, "value"))));
   }

   private static Boolean parseOnOff(String v) {
      Boolean var10000;
      switch (v.toLowerCase(Locale.ROOT)) {
         case "on":
         case "true":
         case "yes":
         case "1":
         case "enable":
         case "enabled":
            var10000 = Boolean.TRUE;
            break;
         case "off":
         case "false":
         case "no":
         case "0":
         case "disable":
         case "disabled":
            var10000 = Boolean.FALSE;
            break;
         default:
            var10000 = null;
      }

      return var10000;
   }

   private static int openAdvancedTeamSettings(CommandSourceStack source, String teamName) {
      if (TeamManager.get(teamName) == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + teamName + "'."));
         return 0;
      } else {
         ServerPlayer viewer = source.getPlayer();
         if (viewer == null) {
            return TeamCommand.show(source, teamName);
         } else {
            TeamSettingsMenu.openBattleOrders(viewer, teamName);
            return 1;
         }
      }
   }

   private static LiteralArgumentBuilder<CommandSourceStack> lookCommand(String name) {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(name).requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("botName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).then(Commands.literal("stop").executes((ctx) -> BotTargetArgument.runForEach(ctx, "botName", (bot) -> stopLook((CommandSourceStack)ctx.getSource(), bot))))).then(Commands.literal("pitch").then(Commands.argument("deg", FloatArgumentType.floatArg(-90.0F, 90.0F)).executes((ctx) -> BotTargetArgument.runForEach(ctx, "botName", (bot) -> lookAngle((CommandSourceStack)ctx.getSource(), bot, (Float)null, FloatArgumentType.getFloat(ctx, "deg"))))))).then(Commands.literal("yaw").then(Commands.argument("deg", FloatArgumentType.floatArg(-360.0F, 360.0F)).executes((ctx) -> BotTargetArgument.runForEach(ctx, "botName", (bot) -> lookAngle((CommandSourceStack)ctx.getSource(), bot, FloatArgumentType.getFloat(ctx, "deg"), (Float)null)))))).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> {
         Vec3 pos = Vec3Argument.getVec3(ctx, "pos");
         return BotTargetArgument.runForEach(ctx, "botName", (bot) -> lookPoint((CommandSourceStack)ctx.getSource(), bot, pos));
      }))).then(Commands.argument("targetName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         BotTargetArgument.Target t = BotTargetArgument.get(ctx, "targetName");
         String release = lookReleaseWord(t);
         String tgt = release != null ? release : BotTargetArgument.firstName((CommandSourceStack)ctx.getSource(), t);
         if (tgt == null) {
            ((CommandSourceStack)ctx.getSource()).sendFailure(VexText.literal("[VexBot] No look target matched."));
            return 0;
         } else {
            return BotTargetArgument.runForEach(ctx, "botName", (bot) -> startLookAt((CommandSourceStack)ctx.getSource(), bot, tgt));
         }
      })));
   }

   private static String lookReleaseWord(BotTargetArgument.Target t) {
      if (!(t instanceof BotTargetArgument.Named n)) {
         return null;
      } else {
         String w = n.name().toLowerCase(Locale.ROOT);
         return !w.equals("clear") && !w.equals("none") && !w.equals("off") ? null : w;
      }
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamSurroundCommand(String name) {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(name).requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).then(Commands.literal("stop").executes((ctx) -> teamSurroundStop((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"))))).then(((RequiredArgumentBuilder)Commands.argument("target", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(((CommandSourceStack)ctx.getSource()).getServer().getPlayerList().getPlayers().stream().map((p) -> p.getName().getString()).toList(), builder)).executes((ctx) -> teamSurroundStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "target"), (double)8.0F))).then(Commands.argument("radius", DoubleArgumentType.doubleArg((double)4.0F, (double)32.0F)).executes((ctx) -> teamSurroundStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), StringArgumentType.getString(ctx, "target"), DoubleArgumentType.getDouble(ctx, "radius"))))));
   }

   private static int teamSurroundStart(CommandSourceStack source, String teamName, String targetName, double radius) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else {
         ServerPlayer target = source.getServer().getPlayerList().getPlayerByName(targetName);
         if (target == null) {
            source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + targetName + "§r'."));
            return 0;
         } else {
            String t = target.getName().getString();
            if (!team.getBotNames().stream().anyMatch((b) -> b.equalsIgnoreCase(t)) && !team.getPlayerNames().stream().anyMatch((b) -> b.equalsIgnoreCase(t))) {
               long bots = team.getBotNames().stream().filter((b) -> source.getServer().getPlayerList().getPlayerByName(b) != null).count();
               if (bots == 0L) {
                  source.sendFailure(VexText.literal("[VexBot] Team §e" + team.getName() + "§r has no bots."));
                  return 0;
               } else {
                  TeamMarch.stop(team.getName());
                  TeamSurround.start(team.getName(), t, radius, (double)4.0F);
                  String msg = "[VexBot] Team §e" + team.getName() + "§r is surrounding §e" + t + "§r: §e" + bots + "§r bot(s) in a ring §e" + (int)Math.round(radius) + "§r blocks out. They close in when §e" + t + "§r comes within §e4§r blocks of one or hits one. Stop with §e/vexbot team " + team.getName() + " surround stop§r.";
                  source.sendSuccess(() -> VexText.literal(msg), true);
                  return 1;
               }
            } else {
               source.sendFailure(VexText.literal("[VexBot] §e" + t + "§r is on team §e" + team.getName() + "§r."));
               return 0;
            }
         }
      }
   }

   private static int teamSurroundStop(CommandSourceStack source, String teamName) {
      if (TeamSurround.stop(teamName) == null) {
         source.sendFailure(VexText.literal("[VexBot] Team §e" + teamName + "§r isn't surrounding anyone."));
         return 0;
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r stopped surrounding."), true);
         return 1;
      }
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamLookCommand(String name) {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(name).requires(REQUIRES_GAMEMASTER)).then(((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)((RequiredArgumentBuilder)Commands.argument("teamName", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder)).then(Commands.literal("stop").executes((ctx) -> teamLookApply((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), (BotManager.LookOrder)null, "stopped staring")))).then(Commands.literal("pitch").then(Commands.argument("deg", FloatArgumentType.floatArg(-90.0F, 90.0F)).executes((ctx) -> teamLookAngle((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), (Float)null, FloatArgumentType.getFloat(ctx, "deg")))))).then(Commands.literal("yaw").then(Commands.argument("deg", FloatArgumentType.floatArg(-360.0F, 360.0F)).executes((ctx) -> teamLookAngle((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), FloatArgumentType.getFloat(ctx, "deg"), (Float)null))))).then(Commands.argument("pos", Vec3Argument.vec3()).executes((ctx) -> teamLookApply((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), BotManager.LookOrder.point(Vec3Argument.getVec3(ctx, "pos")), (String)null)))).then(Commands.argument("targetName", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> {
         BotTargetArgument.Target t = BotTargetArgument.get(ctx, "targetName");
         String release = lookReleaseWord(t);
         String tgt = release != null ? release : BotTargetArgument.firstName((CommandSourceStack)ctx.getSource(), t);
         if (tgt == null) {
            ((CommandSourceStack)ctx.getSource()).sendFailure(VexText.literal("[VexBot] No look target matched."));
            return 0;
         } else {
            return teamLookAt((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), tgt);
         }
      })));
   }

   private static int restockSet(CommandSourceStack source, String teamName, String itemId, int count) {
      if (teamName != null && TeamManager.get(teamName) == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + teamName + "'."));
         return 0;
      } else {
         Item item = RestockPlan.resolve(itemId);
         if (item == null) {
            source.sendFailure(VexText.literal("[VexBot] No item called '§e" + itemId + "§r'."));
            return 0;
         } else {
            RestockPlan.set(teamName, item, count);
            SettingsPersistence.save(source.getServer());
            String scope = teamName == null ? "global" : "team §e" + teamName + "§r";
            String name = (new ItemStack(item)).getHoverName().getString();
            source.sendSuccess(() -> VexText.literal(count <= 0 ? "[VexBot] " + scope + ": §e" + name + "§r back to its built-in amount." : "[VexBot] " + scope + ": bots now carry §e" + count + "§r x §e" + name + "§r."), false);
            return 1;
         }
      }
   }

   private static int discordLink(CommandSourceStack source) {
      Component link = VexText.literal("§9§nhttps://discord.gg/ZYZMC2rRt6").withStyle(Style.EMPTY.withClickEvent(new ClickEvent.OpenUrl(URI.create("https://discord.gg/ZYZMC2rRt6"))).withHoverEvent(new HoverEvent.ShowText(VexText.literal("§7Click to open the VexBot Discord"))));
      source.sendSuccess(() -> VexText.literal("[VexBot] Join the Discord for help, updates and bug reports:"), false);
      source.sendSuccess(() -> link, false);
      return 1;
   }

   private static int restockDefaults(CommandSourceStack source) {
      StringBuilder sb = new StringBuilder("[VexBot] Built-in restock amounts §8(override any with /vexbot restock set)§r:");

      for(Item item : RESTOCK_SHOWCASE) {
         ItemStack st = new ItemStack(item);
         sb.append("\n  §e").append(st.getHoverName().getString()).append("§r x§e").append(RestockController.builtInTarget(st));
      }

      sb.append("\n  §8Armour and elytra are taken LAST unless the worn piece is past repair.");
      sb.append("\n  §8Healing is taken FIRST. Anything not listed defaults to 8.");
      String out = sb.toString();
      source.sendSuccess(() -> VexText.literal(out), false);
      return RESTOCK_SHOWCASE.length;
   }

   private static int restockList(CommandSourceStack source, String teamName) {
      if (teamName != null && TeamManager.get(teamName) == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + teamName + "'."));
         return 0;
      } else {
         Map<String, Integer> view = RestockPlan.view(teamName);
         String scope = teamName == null ? "global" : "team " + teamName;
         if (view.isEmpty()) {
            source.sendSuccess(() -> VexText.literal("[VexBot] No restock overrides for " + scope + " — every item uses its built-in amount. See them with §e/vexbot restock defaults§r, change one with §e/vexbot restock set <item> <count>§r."), false);
            return 0;
         } else {
            StringBuilder sb = new StringBuilder("[VexBot] Restock overrides (" + scope + "):");
            view.forEach((id, n) -> {
               sb.append("\n  §e").append(id).append("§r x§e").append(n);
               Item item = RestockPlan.resolve(id);
               if (item != null) {
                  int def = RestockController.builtInTarget(new ItemStack(item));
                  if (def != n) {
                     sb.append("§r §8(default ").append(def).append(")");
                  }
               }

            });
            String out = sb.toString();
            source.sendSuccess(() -> VexText.literal(out), false);
            return view.size();
         }
      }
   }

   private static int restockClear(CommandSourceStack source, String teamName) {
      if (teamName != null && TeamManager.get(teamName) == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + teamName + "'."));
         return 0;
      } else {
         RestockPlan.clear(teamName);
         SettingsPersistence.save(source.getServer());
         String scope = teamName == null ? "global" : "team §e" + teamName + "§r";
         source.sendSuccess(() -> VexText.literal("[VexBot] Cleared restock overrides for " + scope + "."), false);
         return 1;
      }
   }

   private static int stopLook(CommandSourceStack source, String botName) {
      String resolved = BotManager.resolveCanonicalBotName(botName);
      if (resolved == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else {
         BotManager.clearLookAtTarget(resolved);
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolved + "§r stopped staring — back to normal AI."), false);
         return 1;
      }
   }

   private static int lookPoint(CommandSourceStack source, String botName, Vec3 pos) {
      String resolved = BotManager.resolveCanonicalBotName(botName);
      if (resolved == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else {
         BotManager.setLookPoint(resolved, pos);
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolved + "§r is now looking at §e" + fmtPos(pos) + "§r."), false);
         return 1;
      }
   }

   private static int lookAngle(CommandSourceStack source, String botName, Float yaw, Float pitch) {
      String resolved = BotManager.resolveCanonicalBotName(botName);
      if (resolved == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else {
         BotManager.setLookAngle(resolved, yaw, pitch);
         BotManager.LookOrder order = BotManager.getLookOrder(resolved);
         String held = order == null ? "" : order.describe();
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolved + "§r is now holding §e" + held + "§r."), false);
         return 1;
      }
   }

   private static String fmtPos(Vec3 pos) {
      return String.format(Locale.ROOT, "%.1f %.1f %.1f", pos.x, pos.y, pos.z);
   }

   private static int teamLookApply(CommandSourceStack source, String teamName, BotManager.LookOrder order, String verbPastNull) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + teamName + "'."));
         return 0;
      } else if (team.getBotNames().isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] Team '§e" + teamName + "§r' has no bots."));
         return 0;
      } else {
         int assigned = 0;

         for(String botName : team.getBotNames()) {
            String resolved = BotManager.resolveCanonicalBotName(botName);
            if (resolved != null) {
               if (order == null) {
                  BotManager.clearLookAtTarget(resolved);
               } else if (order.point() != null) {
                  BotManager.setLookPoint(resolved, order.point());
               } else {
                  BotManager.setLookAngle(resolved, order.yaw(), order.pitch());
               }

               ++assigned;
            }
         }

         if (assigned == 0) {
            source.sendFailure(VexText.literal("[VexBot] No online bots on team '§e" + teamName + "§r'."));
            return 0;
         } else {
            if (order == null) {
               source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r " + verbPastNull + " — back to normal AI."), false);
            } else {
               String what = order.describe();
               boolean angle = order.isAngle();
               source.sendSuccess(() -> VexText.literal(angle ? "[VexBot] §e" + assigned + "§r bot(s) on team §e" + teamName + "§r are now holding §e" + what + "§r." : "[VexBot] §e" + assigned + "§r bot(s) on team §e" + teamName + "§r are now looking at §e" + what + "§r."), false);
            }

            return 1;
         }
      }
   }

   private static int teamLookAngle(CommandSourceStack source, String teamName, Float yaw, Float pitch) {
      return teamLookApply(source, teamName, BotManager.LookOrder.angle(yaw, pitch), (String)null);
   }

   private static int startLookAt(CommandSourceStack source, String botName, String targetName) {
      String resolvedBot = BotManager.resolveCanonicalBotName(botName);
      if (resolvedBot == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else {
         String tn = targetName == null ? "" : targetName.strip().toLowerCase(Locale.ROOT);
         if (!tn.equals("stop") && !tn.equals("clear") && !tn.equals("none") && !tn.equals("off")) {
            MinecraftServer server = source.getServer();
            ServerPlayer target = BotManager.resolvePlayerOrBotByName(server, targetName);
            if (target != null && target.isAlive()) {
               String resolvedTarget = target.getName().getString();
               if (resolvedBot.equalsIgnoreCase(resolvedTarget)) {
                  source.sendFailure(VexText.literal("[VexBot] A bot cannot look at itself."));
                  return 0;
               } else {
                  BotManager.setLookAtTarget(resolvedBot, resolvedTarget);
                  source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolvedBot + "§r is now looking at §e" + resolvedTarget + "§r."), false);
                  return 1;
               }
            } else {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + targetName + "§r'."));
               return 0;
            }
         } else {
            BotManager.clearLookAtTarget(resolvedBot);
            source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolvedBot + "§r stopped staring — back to normal AI."), false);
            return 1;
         }
      }
   }

   private static int teamTp(CommandSourceStack source, String teamName, Vec3 pos) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + teamName + "'."));
         return 0;
      } else {
         List<String> names = new ArrayList(team.getBotNames());
         if (names.isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] Team '§e" + teamName + "§r' has no bots."));
            return 0;
         } else {
            double GOLDEN_ANGLE = 2.399963229728653;
            double SPACING = 0.9;
            MinecraftServer server = source.getServer();
            int placed = 0;

            for(int i = 0; i < names.size(); ++i) {
               ServerPlayer bot = server.getPlayerList().getPlayerByName((String)names.get(i));
               if (bot != null) {
                  double radius = 0.9 * Math.sqrt((double)placed);
                  double angle = (double)placed * 2.399963229728653;
                  double bx = pos.x + radius * Math.cos(angle);
                  double bz = pos.z + radius * Math.sin(angle);
                  bot.teleportTo(bx, pos.y, bz);
                  ++placed;
               }
            }

            if (placed == 0) {
               source.sendFailure(VexText.literal("[VexBot] Team '§e" + teamName + "§r' has no bots currently in the world."));
               return 0;
            } else {
               source.sendSuccess(() -> VexText.literal("[VexBot] §aTeleported §e" + placed + "§a bot(s) of team §e" + teamName + "§a to §e" + (int)pos.x + " " + (int)pos.y + " " + (int)pos.z + "§a."), true);
               return 1;
            }
         }
      }
   }

   private static int teamLookAt(CommandSourceStack source, String teamName, String targetName) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + teamName + "'."));
         return 0;
      } else if (team.getBotNames().isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] Team '§e" + teamName + "§r' has no bots."));
         return 0;
      } else {
         String tn = targetName == null ? "" : targetName.strip().toLowerCase(Locale.ROOT);
         if (!tn.equals("stop") && !tn.equals("clear") && !tn.equals("none") && !tn.equals("off")) {
            MinecraftServer server = source.getServer();
            ServerPlayer target = BotManager.resolvePlayerOrBotByName(server, targetName);
            if (target != null && target.isAlive()) {
               String resolvedTarget = target.getName().getString();
               int assigned = 0;

               for(String botName : team.getBotNames()) {
                  if (!botName.equalsIgnoreCase(resolvedTarget) && BotManager.resolveCanonicalBotName(botName) != null) {
                     BotManager.setLookAtTarget(botName, resolvedTarget);
                     ++assigned;
                  }
               }

               if (assigned == 0) {
                  source.sendFailure(VexText.literal("[VexBot] No online bots on team '§e" + teamName + "§r' could look at that target."));
                  return 0;
               } else {
                  source.sendSuccess(() -> VexText.literal("[VexBot] §e" + assigned + "§r bot(s) on team §e" + teamName + "§r are now looking at §e" + resolvedTarget + "§r."), false);
                  return 1;
               }
            } else {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + targetName + "§r'."));
               return 0;
            }
         } else {
            for(String botName : team.getBotNames()) {
               BotManager.clearLookAtTarget(botName);
            }

            source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r stopped staring — back to normal AI."), false);
            return 1;
         }
      }
   }

   private static int startFollow(CommandSourceStack source, String botName, String playerName) {
      String resolvedBot = BotManager.resolveCanonicalBotName(botName);
      if (resolvedBot == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else if (TeamManager.getTeamForBot(resolvedBot) != null) {
         source.sendFailure(VexText.literal("[VexBot] §e" + resolvedBot + "§r is on a team. Remove it from the team first, or use a bot with no team."));
         return 0;
      } else {
         MinecraftServer server = source.getServer();
         ServerPlayer target = BotManager.resolveNonBotPlayerByName(server, playerName);
         if (target == null) {
            source.sendFailure(VexText.literal("[VexBot] No online player named '§e" + playerName + "§r'."));
            return 0;
         } else {
            String resolvedPlayer = target.getName().getString();
            BotManager.setFollowTarget(resolvedBot, resolvedPlayer);
            source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolvedBot + "§r is now following §e" + resolvedPlayer + "§r."), false);
            return 1;
         }
      }
   }

   private static int stopFollow(CommandSourceStack source, String botName) {
      String resolvedBot = BotManager.resolveCanonicalBotName(botName);
      if (resolvedBot == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '" + botName + "'."));
         return 0;
      } else {
         BotManager.clearFollowTarget(resolvedBot);
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolvedBot + "§r stopped following."), false);
         return 1;
      }
   }

   private static int namePoolSet(CommandSourceStack source, String teamName, String pool) {
      MinecraftServer server = source.getServer();
      TeamManager.BotTeam team = null;
      if (teamName != null) {
         team = resolveTeamByName(teamName);
         if (team == null) {
            source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
            return 0;
         }
      }

      if (pool != null && !pool.isBlank()) {
         NamePoolStorage.LoadResult res = NamePoolStorage.load(server, pool);
         if (!res.ok()) {
            source.sendFailure(VexText.literal("[VexBot] §c" + res.error()));
            return 0;
         } else {
            if (team != null) {
               team.namePool = pool;
            } else {
               BotSettings.namePool = pool;
            }

            SettingsPersistence.save(server);
            String who = team != null ? "Team §e" + team.getName() + "§r" : "New bots";
            int n = res.names().size();
            source.sendSuccess(() -> VexText.literal("[VexBot] " + who + " will spawn from §e" + pool + "§r (§e" + n + "§r name" + (n == 1 ? "" : "s") + ")."), true);
            return 1;
         }
      } else {
         if (team != null) {
            team.namePool = "";
         } else {
            BotSettings.namePool = "";
         }

         SettingsPersistence.save(server);
         String who = team != null ? "Team §e" + team.getName() + "§r" : "Bots";
         source.sendSuccess(() -> VexText.literal("[VexBot] " + who + " back to the built-in names."), true);
         return 1;
      }
   }

   private static int namePoolGetId(CommandSourceStack source, String pool) {
      NamePoolStorage.LoadResult res = NamePoolStorage.load(source.getServer(), pool);
      if (!res.ok()) {
         source.sendFailure(VexText.literal("[VexBot] §c" + res.error()));
         return 0;
      } else {
         String id = NamePoolShare.encode(pool, res.names());
         if (id == null) {
            source.sendFailure(VexText.literal("[VexBot] Could not make an ID for that pool."));
            return 0;
         } else {
            source.sendSuccess(() -> VexText.literal("[VexBot] Name pool ID for §e" + pool + "§r (§f" + res.names().size() + "§r names):"), false);
            source.sendSuccess(() -> VexText.literal("§a§n[Click to copy name pool ID]").withStyle(Style.EMPTY.withClickEvent(new ClickEvent.CopyToClipboard(id)).withHoverEvent(new HoverEvent.ShowText(VexText.literal("§7Copy the full ID\n§8Works on any server with VexBot")))), false);
            source.sendSuccess(() -> VexText.literal("§8Then run §e/vexbot namepool import §8and paste it (Ctrl+V)."), false);
            return 1;
         }
      }
   }

   private static int namePoolImport(CommandSourceStack source, String id) {
      NamePoolShare.Shared shared;
      try {
         shared = NamePoolShare.decode(id);
      } catch (IllegalArgumentException e) {
         source.sendFailure(VexText.literal("[VexBot] §c" + e.getMessage()));
         return 0;
      }

      String saved;
      try {
         saved = NamePoolShare.save(source.getServer(), shared);
      } catch (Exception e) {
         source.sendFailure(VexText.literal("[VexBot] §cCould not save the name pool: " + e.getMessage()));
         return 0;
      }

      source.sendSuccess(() -> VexText.literal("[VexBot] §aImported name pool §e" + saved + "§a (" + shared.names().size() + " names) into §evexbot_namepools/§a."), true);
      source.sendSuccess(() -> VexText.literal("§a§n[Use it for all bots]").withStyle(Style.EMPTY.withClickEvent(new ClickEvent.RunCommand("/vexbot namepool " + saved)).withHoverEvent(new HoverEvent.ShowText(VexText.literal("§7/vexbot namepool " + saved + "\n§8For one team: /vexbot team <team> names " + saved)))), false);
      return 1;
   }

   private static int namePoolList(CommandSourceStack source) {
      MinecraftServer server = source.getServer();
      List<String> pools = NamePoolStorage.list(server);
      if (pools.isEmpty()) {
         source.sendSuccess(() -> VexText.literal("[VexBot] No name pools yet. Drop a §e.json§r into §evexbot_namepools/§r — a list of names separated by commas is enough. §evexbot-standard-names.json§r is there as a worked example."), false);
         return 0;
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] Name pools:"), false);

         for(String pool : pools) {
            NamePoolStorage.LoadResult res = NamePoolStorage.load(server, pool);
            String line = res.ok() ? "  §f" + pool + "§7 — " + res.names().size() + " names" : "  §c" + pool + "§7 — §cwill not load§7: " + res.error();
            source.sendSuccess(() -> VexText.literal(line), false);
         }

         String global = BotSettings.namePool;
         source.sendSuccess(() -> {
            String var10000 = global != null && !global.isBlank() ? global : "built-in";
            return VexText.literal("[VexBot] Global: §e" + var10000 + "§r");
         }, false);

         for(TeamManager.BotTeam t : TeamManager.allTeams()) {
            if (t.namePool != null && !t.namePool.isBlank()) {
               source.sendSuccess(() -> {
                  String var10000 = t.getName();
                  return VexText.literal("  team §e" + var10000 + "§7 = §f" + t.namePool);
               }, false);
            }
         }

         return 1;
      }
   }

   private static LiteralArgumentBuilder<CommandSourceStack> gotoThen() {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("then").then(Commands.literal("hold").executes(VexBotCommand::gotoRun))).then(Commands.literal("attack").then(Commands.argument("thenTarget", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(teamFollowTargetNames(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes(VexBotCommand::gotoRun)));
   }

   private static int gotoRun(CommandContext<CommandSourceStack> ctx) {
      String thenTarget = optWord(ctx, "thenTarget");
      TeamMarch.Arrival arrival = thenTarget == null ? TeamMarch.Arrival.hold() : TeamMarch.Arrival.attack(thenTarget);
      Vec3 pos = optVec3(ctx, "pos");
      String targetName = optWord(ctx, "targetName");
      return BotTargetArgument.runForEach(ctx, "bot", (name) -> gotoStart((CommandSourceStack)ctx.getSource(), name, pos, targetName, arrival));
   }

   private static int gotoStart(CommandSourceStack source, String botName, Vec3 pos, String targetName, TeamMarch.Arrival arrival) {
      MinecraftServer server = source.getServer();
      String canonical = BotManager.resolveCanonicalBotName(botName);
      if (canonical == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '§e" + botName + "§r'."));
         return 0;
      } else {
         TeamMarch.Destination dest;
         String dimension;
         String where;
         if (pos != null) {
            dest = TeamMarch.Destination.at(pos);
            dimension = source.getLevel().dimension().identifier().toString();
            where = String.format("§b%.0f %.0f %.0f§r", pos.x, pos.y, pos.z);
         } else {
            ServerPlayer human = BotManager.resolveNonBotPlayerByName(server, targetName);
            String botMatch = BotManager.resolveCanonicalBotName(targetName);
            ServerPlayer who = human != null ? human : (botMatch != null ? server.getPlayerList().getPlayerByName(botMatch) : null);
            if (who == null) {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + targetName + "§r'."));
               return 0;
            }

            dest = TeamMarch.Destination.following(who.getName().getString());
            dimension = who.level().dimension().identifier().toString();
            where = "§b" + who.getName().getString() + "§r";
         }

         if (arrival != null && arrival.kind() == TeamMarch.Arrival.Kind.ATTACK) {
            String want = arrival.target();
            ServerPlayer human = BotManager.resolveNonBotPlayerByName(server, want);
            String botMatch = BotManager.resolveCanonicalBotName(want);
            String resolved = human != null ? human.getName().getString() : botMatch;
            if (resolved == null) {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + want + "§r' to attack."));
               return 0;
            }

            if (TeamManager.isAlliedWithBot(canonical, resolved)) {
               source.sendFailure(VexText.literal("[VexBot] §e" + resolved + "§r is allied with §e" + canonical + "§r."));
               return 0;
            }

            arrival = TeamMarch.Arrival.attack(resolved);
         }

         TeamMarch.March march = TeamMarch.startSolo(canonical, dest, dimension, arrival);
         String then = march.arrival.kind() == TeamMarch.Arrival.Kind.ATTACK ? " — will attack §e" + march.arrival.target() + "§r on arrival" : "";
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + canonical + "§r heading to " + where + then + "."), true);
         return 1;
      }
   }

   private static int gotoStop(CommandSourceStack source, String botName) {
      String canonical = BotManager.resolveCanonicalBotName(botName);
      if (canonical != null) {
         botName = canonical;
      }

      TeamMarch.March march = TeamMarch.stopSolo(botName);
      if (march == null) {
         source.sendFailure(VexText.literal("[VexBot] §e" + botName + "§r is not on its way anywhere."));
         return 0;
      } else {
         BotCommands.stopMoving(source.getServer(), botName);
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + botName + "§r stopped."), true);
         return 1;
      }
   }

   private static LiteralArgumentBuilder<CommandSourceStack> teamGotoThen() {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("then").then(Commands.literal("hold").executes(VexBotCommand::teamGotoRun))).then(Commands.literal("attack").then(Commands.argument("thenTarget", StringArgumentType.word()).suggests((ctx, builder) -> SharedSuggestionProvider.suggest(teamFollowTargetNames(((CommandSourceStack)ctx.getSource()).getServer()), builder)).executes(VexBotCommand::teamGotoRun)));
   }

   private static String optWord(CommandContext<CommandSourceStack> ctx, String name) {
      try {
         return StringArgumentType.getString(ctx, name);
      } catch (IllegalArgumentException var3) {
         return null;
      }
   }

   private static int optInt(CommandContext<CommandSourceStack> ctx, String name, int fallback) {
      try {
         return IntegerArgumentType.getInteger(ctx, name);
      } catch (IllegalArgumentException var4) {
         return fallback;
      }
   }

   private static Vec3 optVec3(CommandContext<CommandSourceStack> ctx, String name) {
      try {
         return Vec3Argument.getVec3(ctx, name);
      } catch (IllegalArgumentException var3) {
         return null;
      }
   }

   private static int teamGotoRun(CommandContext<CommandSourceStack> ctx) {
      String thenTarget = optWord(ctx, "thenTarget");
      TeamMarch.Arrival arrival = thenTarget == null ? TeamMarch.Arrival.hold() : TeamMarch.Arrival.attack(thenTarget);
      return teamGotoStart((CommandSourceStack)ctx.getSource(), StringArgumentType.getString(ctx, "teamName"), optVec3(ctx, "pos"), optWord(ctx, "targetName"), optWord(ctx, "formation"), optInt(ctx, "perRow", 0), arrival);
   }

   private static int teamGotoStart(CommandSourceStack source, String teamName, Vec3 pos, String targetName, String formationName, int rowWidth, TeamMarch.Arrival arrival) {
      MinecraftServer server = source.getServer();
      TeamManager.BotTeam team = resolveTeamByName(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else if (team.getBotNames().isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] Team §e" + team.getName() + "§r has no bots to march."));
         return 0;
      } else {
         TeamMarch.Destination dest;
         String dimension;
         String where;
         if (pos != null) {
            dest = TeamMarch.Destination.at(pos);
            dimension = source.getLevel().dimension().identifier().toString();
            where = String.format("§b%.0f %.0f %.0f§r", pos.x, pos.y, pos.z);
         } else {
            ServerPlayer human = BotManager.resolveNonBotPlayerByName(server, targetName);
            String botMatch = BotManager.resolveCanonicalBotName(targetName);
            ServerPlayer who = human != null ? human : (botMatch != null ? server.getPlayerList().getPlayerByName(botMatch) : null);
            if (who == null) {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + targetName + "§r'."));
               return 0;
            }

            String name = who.getName().getString();
            dest = TeamMarch.Destination.following(name);
            dimension = who.level().dimension().identifier().toString();
            where = "§b" + name + "§r";
         }

         if (arrival != null && arrival.kind() == TeamMarch.Arrival.Kind.ATTACK) {
            String want = arrival.target();
            ServerPlayer human = BotManager.resolveNonBotPlayerByName(server, want);
            String botMatch = BotManager.resolveCanonicalBotName(want);
            String resolved = human != null ? human.getName().getString() : botMatch;
            if (resolved == null) {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + want + "§r' to attack."));
               return 0;
            }

            if (TeamManager.isAlliedWithBot((String)team.getBotNames().iterator().next(), resolved)) {
               source.sendFailure(VexText.literal("[VexBot] §e" + resolved + "§r is allied with team §e" + team.getName() + "§r."));
               return 0;
            }

            arrival = TeamMarch.Arrival.attack(resolved);
         }

         FollowFormation.Type formation = FollowFormation.fromString(formationName);
         TeamMarch.March march = TeamMarch.start(team, dest, dimension, formation, rowWidth, arrival);
         String shape = formation == FollowFormation.Type.NONE ? "" : " in §e" + formation.name().toLowerCase(Locale.ROOT) + "§r";
         String then = march.arrival.kind() == TeamMarch.Arrival.Kind.ATTACK ? " — will attack §e" + march.arrival.target() + "§r on arrival" : "";
         source.sendSuccess(() -> {
            String var10000 = team.getName();
            return VexText.literal("[VexBot] Team §e" + var10000 + "§r (§e" + march.order.size() + "§r bot" + (march.order.size() == 1 ? "" : "s") + ") marching to " + where + shape + then + ".");
         }, true);
         return march.order.size();
      }
   }

   private static int teamGotoStop(CommandSourceStack source, String teamName) {
      TeamManager.BotTeam team = resolveTeamByName(teamName);
      String name = team != null ? team.getName() : teamName;
      TeamMarch.March march = TeamMarch.stop(name);
      if (march == null) {
         source.sendFailure(VexText.literal("[VexBot] Team §e" + name + "§r is not marching."));
         return 0;
      } else {
         for(String bot : march.order) {
            BotCommands.stopMoving(source.getServer(), bot);
         }

         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r stood down."), true);
         return 1;
      }
   }

   private static int teamGotoStatus(CommandSourceStack source, String teamName) {
      TeamManager.BotTeam team = resolveTeamByName(teamName);
      String name = team != null ? team.getName() : teamName;
      TeamMarch.March march = TeamMarch.get(name);
      if (march == null) {
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r is not marching."), false);
         return 0;
      } else {
         Vec3 dest = TeamMarch.destinationPos(source.getServer(), march);
         String where = dest == null ? "§7(target offline)§r" : String.format("§b%.0f %.0f %.0f§r", dest.x, dest.y, dest.z);
         String state = march.arrived ? "§aarrived§r" : "§eon the march§r";
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r — " + state + " to " + where + " (§e" + march.order.size() + "§r bots)."), false);
         return 1;
      }
   }

   private static TeamManager.BotTeam resolveTeamByName(String name) {
      if (name == null) {
         return null;
      } else {
         TeamManager.BotTeam t = TeamManager.get(name);
         if (t != null) {
            return t;
         } else {
            for(String tn : TeamManager.teamNames()) {
               if (tn.equalsIgnoreCase(name)) {
                  return TeamManager.get(tn);
               }
            }

            return null;
         }
      }
   }

   private static List<String> teamFollowTargetNames(MinecraftServer server) {
      LinkedHashSet<String> names = new LinkedHashSet();
      names.addAll(onlineHumanNames(server));
      names.addAll(BotManager.getBotNames());
      names.addAll(TeamManager.teamNames());
      return (List)names.stream().sorted().collect(Collectors.toList());
   }

   private static int teamFollowStart(CommandSourceStack source, String teamName, String targetName, String formationName, int rowWidth, boolean elytra, int flyCount) {
      MinecraftServer server = source.getServer();
      FollowFormation.Type formation = FollowFormation.fromString(formationName);
      TeamManager.BotTeam team = resolveTeamByName(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else {
         ServerPlayer human = BotManager.resolveNonBotPlayerByName(server, targetName);
         String botMatch = BotManager.resolveCanonicalBotName(targetName);
         TeamManager.BotTeam targetTeam = resolveTeamByName(targetName);
         String resolvedTarget;
         if (human != null) {
            resolvedTarget = human.getName().getString();
         } else if (botMatch != null) {
            resolvedTarget = botMatch;
         } else {
            if (targetTeam == null) {
               source.sendFailure(VexText.literal("[VexBot] No online player, bot, or team named '§e" + targetName + "§r'."));
               return 0;
            }

            resolvedTarget = targetTeam.getName();
         }

         if (team.getBotNames().isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] Team §e" + team.getName() + "§r has no bots to follow with."));
            return 0;
         } else if (targetTeam != null && human == null && botMatch == null && targetTeam.getName().equalsIgnoreCase(team.getName())) {
            source.sendFailure(VexText.literal("[VexBot] A team can't follow itself. Name a player, a bot, or another team."));
            return 0;
         } else {
            if (formationName == null && team.tactics.formation != FollowFormation.Type.NONE) {
               formation = team.tactics.formation;
               if (rowWidth <= 0) {
                  rowWidth = team.tactics.formationSize;
               }
            }

            List<String> botList = new ArrayList(team.getBotNames());
            botList.sort(String.CASE_INSENSITIVE_ORDER);
            int n = 0;
            int flown = 0;
            botList.removeIf((b) -> b.equalsIgnoreCase(resolvedTarget));

            for(int i = 0; i < botList.size(); ++i) {
               boolean fly = elytra && (flyCount <= 0 || i < flyCount);
               BotManager.setFollowTarget((String)botList.get(i), resolvedTarget, formation, rowWidth, fly);
               if (fly) {
                  ++flown;
               }

               ++n;
            }

            if (n > 0) {
               TeamHornSummon.markFormedUp(team.getName());
            }

            int ground = n - flown;
            boolean gridLike = formation == FollowFormation.Type.GRID || formation == FollowFormation.Type.ROWS;
            String var10000 = formation == FollowFormation.Type.NONE ? "" : " in §e" + formation.name().toLowerCase() + "§r formation" + (gridLike && rowWidth > 0 ? " (§e" + rowWidth + "§r per row)" : "");
            String formLabel = var10000 + (elytra ? " §b(" + flown + " flying / " + ground + " on ground)§r" : "");
            source.sendSuccess(() -> VexText.literal("[VexBot] §e" + n + "§r bot(s) on team §e" + team.getName() + "§r are now escorting §e" + resolvedTarget + "§r" + formLabel + "."), false);
            return 1;
         }
      }
   }

   private static int teamFollowStop(CommandSourceStack source, String teamName) {
      TeamManager.BotTeam team = resolveTeamByName(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else {
         int n = 0;

         for(String botName : team.getBotNames()) {
            BotManager.clearFollowTarget(botName);
            ++n;
         }

         TeamHornSummon.markStoodDown(team.getName());
         source.sendSuccess(() -> VexText.literal("[VexBot] §e" + n + "§r bot(s) on team §e" + team.getName() + "§r stopped following."), false);
         return 1;
      }
   }

   private static int recordPovStart(CommandSourceStack source, String botName) {
      MinecraftServer server = source.getServer();
      ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, botName);
      if (bot == null) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '§e" + botName + "§r'."));
         return 0;
      } else {
         String resolved = bot.getName().getString();
         Optional<Platform.PovRecorder> recorder = Platform.get().povRecorder();
         if (recorder.isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] POV recording only works on the integrated/host client (no renderer on a dedicated server)."));
            return 0;
         } else {
            ((Platform.PovRecorder)recorder.get()).start(resolved);
            povSessions.put(resolved, new PovSession(resolved, System.currentTimeMillis()));
            TeamManager.BotTeam team = TeamManager.getTeamForBot(resolved);
            String label = resolved + (team != null ? " §7(team " + team.getName() + ")" : "");
            source.sendSuccess(() -> VexText.literal("[VexBot] §c● REC §aPOV of §e" + label + "§r in the background → silent .mp4 in §evexbot-pov/§r. §e/vexbot recordpovstop§r to finish. §7(bot must be in your render distance)"), false);
            return 1;
         }
      }
   }

   private static int recordPovStop(CommandSourceStack source) {
      Platform.get().povRecorder().ifPresent(Platform.PovRecorder::stopAll);
      int n = povSessions.size();
      povSessions.clear();
      String msg = n == 0 ? "[VexBot] No POV recordings were active." : "[VexBot] §a⏹ Stopped §e" + n + "§r POV recording(s) — saved to §evexbot-pov/§r.";
      source.sendSuccess(() -> VexText.literal(msg), false);
      return 1;
   }

   private static int combatRecordStart(CommandSourceStack source, String focus) {
      boolean restarted = CombatRecorder.isRecording();
      CombatRecorder.start(focus, System.currentTimeMillis());
      source.sendSuccess(() -> VexText.literal("[VexBot] Combat recording " + (restarted ? "restarted (previous rows discarded)" : "started") + (focus != null ? " — focus §e" + focus + "§r." : " — all players.") + " §7/vexbot record stop§r to save."), true);
      return 1;
   }

   private static int combatRecordStop(CommandSourceStack source) {
      if (!CombatRecorder.isRecording()) {
         source.sendFailure(VexText.literal("[VexBot] No combat recording is running."));
         return 0;
      } else {
         String path = CombatRecorder.stop(source.getServer());
         if (path == null) {
            source.sendSuccess(() -> VexText.literal("[VexBot] Recording stopped — nothing was recorded."), true);
            return 1;
         } else if (path.startsWith("ERROR: ")) {
            source.sendFailure(VexText.literal("[VexBot] Recording stopped, but the CSV could not be written: " + path.substring(7)));
            return 0;
         } else {
            source.sendSuccess(() -> VexText.literal("[VexBot] Combat recording saved to §e" + path), true);
            return 1;
         }
      }
   }

   private static int recordPovList(CommandSourceStack source) {
      if (povSessions.isEmpty()) {
         source.sendSuccess(() -> VexText.literal("[VexBot] No POV recordings active."), false);
         return 1;
      } else {
         long now = System.currentTimeMillis();
         StringBuilder sb = new StringBuilder("[VexBot] §c● §rRecording POV (" + povSessions.size() + "):");

         for(PovSession s : povSessions.values()) {
            sb.append("\n  §e").append(s.bot()).append(" §7(").append(formatDuration(now - s.startMillis())).append(")");
         }

         String out = sb.toString();
         source.sendSuccess(() -> VexText.literal(out), false);
         return 1;
      }
   }

   private static int ffaSet(CommandSourceStack source, boolean on) {
      MinecraftServer server = source.getServer();
      ThreadLocalRandom rng = ThreadLocalRandom.current();
      BotSettings.Difficulty[] presets = BotSettings.Difficulty.values();
      int n = 0;

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (p instanceof BotPlayer) {
            String name = p.getName().getString();
            BotManager.setFfaLootMode(name, on);
            if (on && BotSettings.ffaRandomDifficulties) {
               BotSettings.Difficulty deal = presets[rng.nextInt(presets.length)];
               DifficultyParams dealtParams = DifficultyParams.forPreset(deal);
               DifficultyParams prev = (DifficultyParams)BotSettings.botDifficulties.put(name, dealtParams);
               FfaDeal earlier = (FfaDeal)FFA_DEALS.get(name);
               FFA_DEALS.put(name, new FfaDeal(earlier != null ? earlier.previous() : prev, dealtParams));
            }

            if (!on) {
               BotManager.clearAttackTarget(name);
            }

            ++n;
         }
      }

      if (!on && !FFA_DEALS.isEmpty()) {
         for(Map.Entry<String, FfaDeal> e : FFA_DEALS.entrySet()) {
            FfaDeal d = (FfaDeal)e.getValue();
            if (BotSettings.botDifficulties.get(e.getKey()) == d.dealt()) {
               if (d.previous() == null) {
                  BotSettings.botDifficulties.remove(e.getKey());
               } else {
                  BotSettings.botDifficulties.put((String)e.getKey(), d.previous());
               }
            }
         }

         FFA_DEALS.clear();
         SettingsPersistence.save(server);
      }

      boolean dealt = on && BotSettings.ffaRandomDifficulties;
      boolean stillHunting = !on && BotSettings.targetBots;
      source.sendSuccess(() -> VexText.literal(on ? "[VexBot] §aFFA loot mode ON§r for §e" + n + "§r bot(s) — they'll gear up from chests, then fight." + (dealt ? " §7Random difficulty presets dealt.§r" : "") : "[VexBot] §eFFA loot mode OFF§r — §e" + n + "§r bot(s) back to normal combat." + (stillHunting ? "\n §7Note: §etargetbots§7 is still §aon§7, so they will re-engage each other as normal targets. §e/vexbot settings targetbots off§7 to stop them fighting altogether.§r" : "")), false);
      return 1;
   }

   private static int ffaConfigList(CommandSourceStack source) {
      source.sendSuccess(() -> VexText.literal("[VexBot] FFA config:\n §erandomdifficulties§r (alias §erandompresets§r): " + onOffStr(BotSettings.ffaRandomDifficulties) + " §7— each bot gets a random difficulty preset (EASY..PERFECT) at ffa start§r"), false);
      return 1;
   }

   private static int ffaRandomDiffSet(CommandSourceStack source, boolean on) {
      BotSettings.ffaRandomDifficulties = on;
      SettingsPersistence.save(source.getServer());
      source.sendSuccess(() -> {
         String var10000 = onOffStr(on);
         return VexText.literal("[VexBot] FFA §erandomdifficulties§r = " + var10000 + (on ? " §7— presets are dealt at the next /vexbot ffa start§r" : ""));
      }, false);
      return 1;
   }

   private static String formatDuration(long millis) {
      long s = Math.max(0L, millis / 1000L);
      long h = s / 3600L;
      long m = s % 3600L / 60L;
      long sec = s % 60L;
      return h > 0L ? String.format("%d:%02d:%02d", h, m, sec) : String.format("%d:%02d", m, sec);
   }

   private static int givekitRoot(CommandSourceStack source) {
      return source.getPlayer() != null ? openGiveKitGui(source) : KitCli.listKits(source, source.getServer());
   }

   private static int getkitidRoot(CommandSourceStack source) {
      if (source.getPlayer() != null) {
         return openGetKitIdGui(source);
      } else {
         source.sendFailure(VexText.literal("[VexBot] Usage: §e/vexbot getkitid <kit>§r — run §e/vexbot givekit list§r for kit names."));
         return 0;
      }
   }

   private static int givekitNeedPlayer(CommandSourceStack source, String kit) {
      if (!KitManager.exists(source.getServer(), kit)) {
         source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kit + "§r' not found. Run §e/vexbot givekit list§r."));
         return 0;
      } else {
         source.sendFailure(VexText.literal("[VexBot] Usage: §e/vexbot givekit " + kit + " <player>§r"));
         return 0;
      }
   }

   private static int givekitallRoot(CommandSourceStack source) {
      if (source.getPlayer() != null) {
         return openGiveKitAllGui(source);
      } else {
         source.sendFailure(VexText.literal("[VexBot] Usage: §e/vexbot givekitall <kit>§r — run §e/vexbot givekit list§r for kit names."));
         return 0;
      }
   }

   private static int teamgivekitRoot(CommandSourceStack source, String teamName) {
      if (source.getPlayer() != null) {
         return openGiveKitToTeamGui(source, teamName);
      } else {
         source.sendFailure(VexText.literal("[VexBot] Usage: §e/vexbot team " + teamName + " kit <kit>§r"));
         return 0;
      }
   }

   private static List<String> onlineRecipientNames(MinecraftServer server) {
      return (List)server.getPlayerList().getPlayers().stream().map((p) -> p.getName().getString()).distinct().sorted().collect(Collectors.toList());
   }

   private static LiteralArgumentBuilder<CommandSourceStack> viewTree(String name) {
      return (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(name).requires(REQUIRES_GAMEMASTER_NOT_COMMAND_BLOCK)).then(Commands.literal("inventory").then(Commands.argument("name", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> viewContainer(ctx, false))))).then(Commands.literal("enderchest").then(Commands.argument("name", BotTargetArgument.target()).suggests(BotTargetArgument.SUGGEST).executes((ctx) -> viewContainer(ctx, true))));
   }

   private static int viewContainer(CommandContext<CommandSourceStack> ctx, boolean enderChest) {
      String who = BotTargetArgument.firstName((CommandSourceStack)ctx.getSource(), BotTargetArgument.get(ctx, "name"));
      if (who == null) {
         ((CommandSourceStack)ctx.getSource()).sendFailure(VexText.literal("[VexBot] No target matched."));
         return 0;
      } else {
         return enderChest ? viewEnderChest((CommandSourceStack)ctx.getSource(), who) : viewInventory((CommandSourceStack)ctx.getSource(), who);
      }
   }

   private static int viewEnderChest(CommandSourceStack source, String name) {
      try {
         ServerPlayer viewer = source.getPlayer();
         if (viewer == null) {
            source.sendFailure(VexText.literal("[VexBot] This needs a player — run it in-game."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            ServerPlayer target = findOnlinePlayer(server, name);
            if (target == null) {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + name + "§r'."));
               return 0;
            } else if (target.equals(viewer)) {
               source.sendFailure(VexText.literal("[VexBot] That's your own ender chest — open it normally."));
               return 0;
            } else {
               viewer.openMenu(new SimpleMenuProvider((id, inv, p) -> new EnderChestViewMenu(id, inv, target), EnderChestViewMenu.title(target.getName().getString())));
               return 1;
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] viewEnderChest crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int viewInventory(CommandSourceStack source, String name) {
      try {
         ServerPlayer viewer = source.getPlayer();
         if (viewer == null) {
            source.sendFailure(VexText.literal("[VexBot] This needs a player. Use §e/vexbot view inventory <name>§r in-game."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            ServerPlayer target = findOnlinePlayer(server, name);
            if (target == null) {
               source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + name + "§r'."));
               return 0;
            } else if (target.equals(viewer)) {
               source.sendFailure(VexText.literal("[VexBot] Use your normal inventory screen to view your own items."));
               return 0;
            } else {
               String title = "Inventory: " + target.getName().getString();
               viewer.openMenu(new SimpleMenuProvider((id, inv, p) -> new InventoryViewMenu(id, inv, server, target), VexText.literal(title)));
               return 1;
            }
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] viewInventory crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static ServerPlayer findOnlinePlayer(MinecraftServer server, String name) {
      ServerPlayer exact = server.getPlayerList().getPlayerByName(name);
      if (exact != null) {
         return exact;
      } else {
         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.getName().getString().equalsIgnoreCase(name)) {
               return p;
            }
         }

         return null;
      }
   }

   private static int openGiveKitGui(CommandSourceStack source) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Give-kit GUI requires a player. Use §e/vexbot givekit <kit> <player>§r."));
            return 0;
         } else if (KitManager.list(source.getServer()).isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No kits saved yet."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, server, KitListMenu.Mode.GIVE), VexText.literal("Give a Kit")));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openGiveKitGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int openGiveKitAllGui(CommandSourceStack source) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Give-kit GUI requires a player. Use §e/vexbot givekitall <kit>§r."));
            return 0;
         } else if (KitManager.list(source.getServer()).isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No kits saved yet."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, server, KitListMenu.Mode.GIVE_ALL), VexText.literal("§aGive Kit to Everyone")));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openGiveKitAllGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int openKitIconMenu(CommandSourceStack source) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("Must be run as a player."));
            return 0;
         } else if (KitManager.list(source.getServer()).isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No kits saved yet."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, server, KitListMenu.Mode.ICON), VexText.literal("§6Kit Icons")));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openKitIconMenu crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int openGetKitIdGui(CommandSourceStack source) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("Must be run as a player."));
            return 0;
         } else if (KitManager.list(source.getServer()).isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No kits saved yet."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, server, KitListMenu.Mode.GET_ID), VexText.literal("§bGet Kit ID")));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openGetKitIdGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int openGiveKitToTeamGui(CommandSourceStack source, String teamName) {
      try {
         ServerPlayer player = source.getPlayer();
         if (player == null) {
            source.sendFailure(VexText.literal("[VexBot] Give-kit GUI requires a player. Use §e/vexbot team " + teamName + " kit <kit>§r."));
            return 0;
         } else if (!TeamManager.exists(teamName)) {
            source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r' exists."));
            return 0;
         } else if (KitManager.list(source.getServer()).isEmpty()) {
            source.sendFailure(VexText.literal("[VexBot] No kits saved yet."));
            return 0;
         } else {
            MinecraftServer server = source.getServer();
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, server, teamName), VexText.literal("§aGive Kit to Team: §e" + teamName)));
            return 1;
         }
      } catch (Throwable t) {
         VexBot.LOGGER.error("[VexBot] openGiveKitToTeamGui crashed", t);
         source.sendFailure(VexText.literal("[VexBot] Error: " + t.getMessage()));
         return 0;
      }
   }

   private static int spawnAreaShow(CommandSourceStack source) {
      if (!SpawnArea.isSet()) {
         source.sendSuccess(() -> VexText.literal("[VexBot] No spawn area. Bots appear where the command is run from. Set one with §e/vexbot spawnarea here 20§r or §e/vexbot spawnarea set <x y z> <x y z>§r."), false);
         return 0;
      } else {
         String where = SpawnArea.describe();
         source.sendSuccess(() -> VexText.literal("[VexBot] Spawn area: §e" + where + "§r."), false);
         return 1;
      }
   }

   private static int spawnAreaClear(CommandSourceStack source) {
      if (!SpawnArea.isSet()) {
         source.sendFailure(VexText.literal("[VexBot] There is no spawn area to clear."));
         return 0;
      } else {
         SpawnArea.clear();
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] Spawn area cleared — bots appear where the command is run from again."), false);
         return 1;
      }
   }

   private static int spawnAreaHere(CommandSourceStack source, int radius) {
      Vec3 at = source.getPosition();
      Vec3 a = new Vec3(at.x - (double)radius, at.y - (double)8.0F, at.z - (double)radius);
      Vec3 b = new Vec3(at.x + (double)radius, at.y + (double)8.0F, at.z + (double)radius);
      return applySpawnArea(source, a, b);
   }

   private static int spawnAreaSet(CommandSourceStack source, Vec3 from, Vec3 to) {
      return applySpawnArea(source, from, to);
   }

   private static int applySpawnArea(CommandSourceStack source, Vec3 a, Vec3 b) {
      String dim = source.getLevel().dimension().identifier().toString();
      SpawnArea.set(dim, a, b);
      SettingsPersistence.save(source.getServer());
      String where = SpawnArea.describe();
      source.sendSuccess(() -> VexText.literal("[VexBot] Spawn area set: §e" + where + "§r. New bots appear inside it unless the command names a spot."), false);
      return 1;
   }

   private static SpawnPlacement computeSpawnPlacement(CommandSourceStack source) {
      if (SpawnArea.isSet()) {
         Vec3 spot = SpawnArea.randomSpot(source.getServer());
         if (spot != null) {
            return new SpawnPlacement(spot.x, spot.y, spot.z, RNG.nextFloat() * 360.0F - 180.0F, 0.0F, SpawnArea.dimensionId());
         }
      }

      return computeSpawnPlacementFromSource(source);
   }

   private static SpawnPlacement computeSpawnPlacementFromSource(CommandSourceStack source) {
      ServerPlayer player = source.getPlayer();
      if (player != null) {
         double yawRad = Math.toRadians((double)player.getYRot());
         double bx = player.getX() - Math.sin(yawRad);
         double bz = player.getZ() + Math.cos(yawRad);
         float botYaw = (float)Math.toDegrees(Math.atan2(-(player.getX() - bx), player.getZ() - bz));
         return new SpawnPlacement(bx, player.getY(), bz, botYaw, 0.0F, player.level().dimension().identifier().toString());
      } else {
         ServerLevel level = source.getLevel();
         Vec3 pos = source.getPosition();
         Vec2 rot = source.getRotation();
         double yawRad = Math.toRadians((double)rot.y);
         double bx = pos.x - Math.sin(yawRad);
         double bz = pos.z + Math.cos(yawRad);
         float botYaw = (float)Math.toDegrees(Math.atan2(-(pos.x - bx), pos.z - bz));
         return new SpawnPlacement(bx, pos.y, bz, botYaw, rot.x, level.dimension().identifier().toString());
      }
   }

   private static MassSpawnPivot computeMassSpawnPivot(CommandSourceStack source) {
      if (SpawnArea.isSet()) {
         Vec3 spot = SpawnArea.randomSpot(source.getServer());
         if (spot != null) {
            return new MassSpawnPivot(spot.x, spot.y, spot.z, (double)0.0F, SpawnArea.dimensionId(), true);
         }
      }

      return computeMassSpawnPivotFromSource(source);
   }

   private static MassSpawnPivot computeMassSpawnPivotFromSource(CommandSourceStack source) {
      ServerPlayer player = source.getPlayer();
      if (player != null) {
         return new MassSpawnPivot(player.getX(), player.getY(), player.getZ(), Math.toRadians((double)player.getYRot()), player.level().dimension().identifier().toString());
      } else {
         ServerLevel level = source.getLevel();
         Vec3 pos = source.getPosition();
         Vec2 rot = source.getRotation();
         return new MassSpawnPivot(pos.x, pos.y, pos.z, Math.toRadians((double)rot.y), level.dimension().identifier().toString());
      }
   }

   static {
      REQUIRES_GAMEMASTER = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);
      REQUIRES_GAMEMASTER_NOT_COMMAND_BLOCK = REQUIRES_GAMEMASTER.and((src) -> !isCommandBlockSource(src));
      ADJECTIVES = new String[]{"Angry", "Arctic", "Atomic", "Blazing", "Blind", "Bold", "Brave", "Bright", "Bronze", "Calm", "Clever", "Cold", "Cosmic", "Crazy", "Crimson", "Crystal", "Dark", "Dead", "Deep", "Dire", "Divine", "Dusk", "Electric", "Epic", "Fast", "Feral", "Fierce", "Fiery", "Frozen", "Grim", "Hidden", "High", "Hollow", "Holy", "Hyper", "Ice", "Idle", "Iron", "Jade", "Keen", "Last", "Lazy", "Light", "Lone", "Lost", "Mad", "Massive", "Mean", "Mighty", "Mystic", "Night", "Noble", "Odd", "Old", "Pale", "Prime", "Quick", "Rapid", "Raw", "Red", "Rogue", "Royal", "Rusty", "Sacred", "Sharp", "Silent", "Silver", "Sly", "Solid", "Sonic", "Steel", "Stone", "Storm", "Swift", "Tidal", "Toxic", "True", "Twin", "Ultra", "Untamed", "Venom", "Void", "Wild", "Wise", "Wrath", "Zero"};
      NOUNS = new String[]{"Ace", "Arrow", "Axe", "Badger", "Bear", "Blade", "Bolt", "Bone", "Bow", "Bull", "Cat", "Claw", "Cobra", "Comet", "Crow", "Dagger", "Dawn", "Deer", "Dragon", "Dusk", "Eagle", "Eye", "Fang", "Falcon", "Fire", "Fish", "Fox", "Frost", "Hawk", "Horn", "Hunter", "Hydra", "Inferno", "Iron", "Jackal", "Jaguar", "Lance", "Leo", "Lion", "Lynx", "Mark", "Moon", "Ninja", "Oak", "Panda", "Panther", "Phantom", "Pike", "Puma", "Raven", "Reaper", "Rex", "Ridge", "Rock", "Rook", "Sage", "Scout", "Shade", "Shadow", "Shark", "Shield", "Shroud", "Skull", "Slash", "Snake", "Sniper", "Specter", "Spider", "Spirit", "Star", "Storm", "Strike", "Sun", "Sword", "Talon", "Tiger", "Titan", "Viper", "Void", "Walker", "Wolf", "Wraith", "Zeus"};
      TEAM_SUBS = new ArrayList();
      TEAM_ROOT_SUBS = Set.of("create", "delete", "join", "leave");
      TEAM_SUB_ALIASES = Map.of("kit", "givekit", "kitid", "givekitid");
      NULL_COMMANDER_NAMES = buildCommanderNames();
      SUGGEST_PATHS = (c, b) -> SharedSuggestionProvider.suggest(PathManager.all().stream().map((p) -> p.name).toList(), b);
      DIFFICULTY_KNOBS = new String[]{"misschance", "accuracy", "clutch", "reaction", "shielddisablespeed", "shieldcharge", "strafe", "crittiming", "anchorspeed", "stunslam", "potspeed", "webdrainspeed", "webescapespeed", "elytramace", "reachflips", "cartskip", "cartspeed", "crystalspeed", "anchorgap", "crystalpvp"};
      LEVEL_NAMES = new String[]{"easy", "medium", "hard", "expert", "professional"};
      DIFFICULTY_PRESETS = new String[]{"easy", "medium", "hard", "expert", "perfect"};
      TEAM_ORDER_TOGGLES = new String[]{"protectboss", "focusbosstarget", "followboss", "maintainformation", "retreatwhenlow"};
      RESTOCK_SHOWCASE = new Item[]{Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE, Items.GOLDEN_CARROT, Items.TOTEM_OF_UNDYING, Items.ENDER_PEARL, Items.FIREWORK_ROCKET, Items.EXPERIENCE_BOTTLE, Items.COBWEB, Items.WIND_CHARGE, Items.ARROW, Items.END_CRYSTAL, Items.OBSIDIAN, Items.RESPAWN_ANCHOR, Items.GLOWSTONE, Items.TNT_MINECART, Items.RAIL, Items.CHORUS_FRUIT, Items.SPLASH_POTION, Items.WATER_BUCKET, Items.SHIELD, Items.ELYTRA, Items.COBBLESTONE};
      FFA_DEALS = new ConcurrentHashMap();
   }

   private static record PovSession(String bot, long startMillis) {
   }

   private static record TeamSub(String name, LiteralArgumentBuilder<CommandSourceStack> builder) {
   }

   private static record FfaDeal(DifficultyParams previous, DifficultyParams dealt) {
   }

   private static record SpawnPlacement(double x, double y, double z, float botYaw, float pitch, String dimensionId) {
   }

   private static record MassSpawnPivot(double cx, double cy, double cz, double yawRad, String dimensionId, boolean fromArea) {
      MassSpawnPivot(double cx, double cy, double cz, double yawRad, String dimensionId) {
         this(cx, cy, cz, yawRad, dimensionId, false);
      }
   }
}
