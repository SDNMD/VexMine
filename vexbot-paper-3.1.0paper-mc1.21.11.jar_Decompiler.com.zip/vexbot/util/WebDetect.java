package vexbot.util;

import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;

public final class WebDetect {
   private static final Predicate<BlockState> IS_WEB = (s) -> s.is(Blocks.COBWEB);

   private WebDetect() {
   }

   public static boolean touchingWeb(Entity entity) {
      return firstWeb(entity) != null;
   }

   public static BlockPos firstWeb(Entity entity) {
      Level level = entity.level();
      AABB box = entity.getBoundingBox();
      int minX = Mth.floor(box.minX);
      int maxX = Mth.floor(box.maxX);
      int minY = Mth.floor(box.minY);
      int maxY = Mth.floor(box.maxY);
      int minZ = Mth.floor(box.minZ);
      int maxZ = Mth.floor(box.maxZ);
      if (!sectionsMayHoldWeb(level, minX, minY, minZ, maxX, maxY, maxZ)) {
         return null;
      } else {
         BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

         for(int y = minY; y <= maxY; ++y) {
            for(int x = minX; x <= maxX; ++x) {
               for(int z = minZ; z <= maxZ; ++z) {
                  pos.set(x, y, z);
                  if (level.getBlockState(pos).is(Blocks.COBWEB)) {
                     return pos.immutable();
                  }
               }
            }
         }

         return null;
      }
   }

   private static boolean sectionsMayHoldWeb(Level level, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
      if (level.isDebug()) {
         return true;
      } else {
         int lo = Math.max(minY, level.getMinY());
         int hi = Math.min(maxY, level.getMaxY());
         if (lo > hi) {
            return false;
         } else {
            int loSection = level.getSectionIndex(lo);
            int hiSection = level.getSectionIndex(hi);

            for(int cx = minX >> 4; cx <= maxX >> 4; ++cx) {
               for(int cz = minZ >> 4; cz <= maxZ >> 4; ++cz) {
                  if (ChunkPos.isValid(cx, cz)) {
                     LevelChunkSection[] sections = level.getChunk(cx, cz).getSections();

                     for(int i = Math.max(0, loSection); i <= Math.min(hiSection, sections.length - 1); ++i) {
                        if (sections[i].maybeHas(IS_WEB)) {
                           return true;
                        }
                     }
                  }
               }
            }

            return false;
         }
      }
   }
}
