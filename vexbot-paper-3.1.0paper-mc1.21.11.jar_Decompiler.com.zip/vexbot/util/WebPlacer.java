package vexbot.util;

import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import vexbot.compat.McCompat;
import vexbot.stats.Stats;

public final class WebPlacer {
   private WebPlacer() {
   }

   public static int equipWeb(ServerPlayer bot) {
      Inventory inv = bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.COBWEB)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(Items.COBWEB)) {
            return InventoryUtils.moveToHotbarSafe(inv, i);
         }
      }

      return -1;
   }

   public static boolean hasWeb(ServerPlayer bot) {
      Inventory inv = bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.COBWEB)) {
            return true;
         }
      }

      return false;
   }

   public static boolean placeAt(ServerPlayer bot, BlockPos pos) {
      Level level = bot.level();
      ItemStack web = bot.getMainHandItem();
      if (web.is(Items.COBWEB) && level.getBlockState(pos).isAir()) {
         lookAt(bot, pos);
         Vec3 hitVec = Vec3.atCenterOf(pos);
         BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, pos, false);
         bot.gameMode.useItemOn(bot, level, web, InteractionHand.MAIN_HAND, hit);
         McCompat.swing(bot, InteractionHand.MAIN_HAND);
         boolean placed = level.getBlockState(pos).is(Blocks.COBWEB);
         if (placed) {
            Stats.inc("webs_placed");
         }

         return placed;
      } else {
         return false;
      }
   }

   public static void lookAt(ServerPlayer bot, BlockPos pos) {
      double dx = (double)pos.getX() + (double)0.5F - bot.getX();
      double dy = (double)pos.getY() + (double)0.5F - bot.getEyeY();
      double dz = (double)pos.getZ() + (double)0.5F - bot.getZ();
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      bot.setYRot(yaw);
      bot.setXRot(pitch);
      bot.yHeadRot = yaw;
   }

   public static int equipWebCutter(ServerPlayer bot) {
      Inventory inv = bot.getInventory();
      int slot = findIn(bot, (s) -> s.is(Items.SHEARS));
      if (slot < 0) {
         slot = findIn(bot, (s) -> s.is(ItemTags.SWORDS));
      }

      if (slot < 0) {
         return -1;
      } else {
         slot = slot >= 9 ? InventoryUtils.moveToHotbarSafe(inv, slot) : slot;
         InventoryUtils.select(inv, slot);
         return slot;
      }
   }

   public static boolean hasShears(ServerPlayer bot) {
      return findIn(bot, (s) -> s.is(Items.SHEARS)) >= 0;
   }

   private static int findIn(ServerPlayer bot, Predicate<ItemStack> match) {
      Inventory inv = bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (match.test(inv.getItem(i))) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (match.test(inv.getItem(i))) {
            return i;
         }
      }

      return -1;
   }
}
