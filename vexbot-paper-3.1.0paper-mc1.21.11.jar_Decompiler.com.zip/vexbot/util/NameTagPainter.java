package vexbot.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.BotSettings;
import vexbot.compat.McCompat;
import vexbot.team.TeamManager;

public final class NameTagPainter {
   private static final int SWEEP_INTERVAL = 20;
   private static int counter = 0;
   private static volatile boolean dirty = false;
   private static final Set<String> DEVS = Set.of("epic_atk", "vortexal2", "gooob21");

   private NameTagPainter() {
   }

   public static void repaint() {
      dirty = true;
   }

   public static void onServerTick(MinecraftServer server) {
      if (server != null) {
         if (dirty || ++counter >= 20) {
            counter = 0;
            dirty = false;
            List<TeamManager.BotTeam> teams = new ArrayList();
            List<Set<String>> members = new ArrayList();

            for(String teamName : TeamManager.teamNames()) {
               TeamManager.BotTeam t = TeamManager.get(teamName);
               if (t != null) {
                  teams.add(t);
                  members.add(lowerMembers(t));
               }
            }

            for(ServerPlayer p : server.getPlayerList().getPlayers()) {
               NameTagColour.apply(server, p, colourFor(p, teams, members), tagFor(p));
            }

         }
      }
   }

   private static NameTagColour.Tag tagFor(ServerPlayer p) {
      if (!BotSettings.showTags) {
         return null;
      } else if (McCompat.tags(p).contains("vexbot")) {
         return NameTagColour.Tag.BOT;
      } else {
         return DEVS.contains(p.getName().getString().toLowerCase(Locale.ROOT)) ? NameTagColour.Tag.DEV : null;
      }
   }

   private static String colourFor(ServerPlayer p, List<TeamManager.BotTeam> teams, List<Set<String>> members) {
      String lower = p.getName().getString().toLowerCase(Locale.ROOT);

      for(int i = 0; i < teams.size(); ++i) {
         if (((Set)members.get(i)).contains(lower)) {
            String c = ((TeamManager.BotTeam)teams.get(i)).nameTagColour;
            if (c != null && !"none".equals(c)) {
               return c;
            }
            break;
         }
      }

      return BotSettings.nameTagColour;
   }

   private static Set<String> lowerMembers(TeamManager.BotTeam t) {
      Set<String> out = new HashSet();

      for(String b : t.getBotNames()) {
         out.add(b.toLowerCase(Locale.ROOT));
      }

      for(String pl : t.getPlayerNames()) {
         out.add(pl.toLowerCase(Locale.ROOT));
      }

      return out;
   }
}
