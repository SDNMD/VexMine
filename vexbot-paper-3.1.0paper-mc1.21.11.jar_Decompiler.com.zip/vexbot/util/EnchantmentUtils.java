package vexbot.util;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

public final class EnchantmentUtils {
   private EnchantmentUtils() {
   }

   public static int getEnchantLevel(ItemStack stack, String enchantPath) {
      if (!stack.isEmpty() && enchantPath != null && !enchantPath.isBlank()) {
         ItemEnchantments enc = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
         if (enc != null && !enc.isEmpty()) {
            for(Holder<Enchantment> h : enc.keySet()) {
               String path = (String)h.unwrapKey().map(ResourceKey::identifier).map((loc) -> loc.getPath()).orElse("");
               if (path.equals(enchantPath)) {
                  return enc.getLevel(h);
               }
            }

            return 0;
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }

   public static boolean hasEnchantAtLeast(ItemStack stack, String enchantPath, int minLevel) {
      return getEnchantLevel(stack, enchantPath) >= minLevel;
   }
}
