package vexbot.util;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class LedgeGuard {
   private LedgeGuard() {
   }

   public static boolean wouldFallDangerously(ServerPlayer bot, double dirX, double dirZ, int maxSafeDrop) {
      if (!bot.onGround()) {
         return false;
      } else {
         double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
         if (len < 1.0E-4) {
            return false;
         } else {
            double nx = dirX / len;
            double nz = dirZ / len;
            Level level = bot.level();
            Vec3 p = bot.position();
            int bx = (int)Math.floor(p.x + nx);
            int bz = (int)Math.floor(p.z + nz);
            int feetY = (int)Math.floor(p.y);

            for(int depth = 0; depth <= maxSafeDrop + 1; ++depth) {
               BlockPos cand = new BlockPos(bx, feetY - depth, bz);
               if (isSolid(level, cand) || isWater(level, cand)) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   private static boolean isSolid(Level level, BlockPos p) {
      return !level.getBlockState(p).getCollisionShape(level, p).isEmpty();
   }

   private static boolean isWater(Level level, BlockPos p) {
      return level.getBlockState(p).getFluidState().is(FluidTags.WATER);
   }
}
