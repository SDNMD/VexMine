package vexbot.util;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class MeleeWallGuard {
   private static final double PROBE = 0.55;

   private MeleeWallGuard() {
   }

   public static float[] deflect(ServerPlayer bot, float forward, float strafe) {
      float[] unchanged = new float[]{forward, strafe};
      if (!bot.onGround()) {
         return unchanged;
      } else if (forward == 0.0F && strafe == 0.0F) {
         return unchanged;
      } else {
         double yaw = Math.toRadians((double)bot.getYRot());
         double fx = -Math.sin(yaw);
         double fz = Math.cos(yaw);
         double sx = Math.cos(yaw);
         double sz = Math.sin(yaw);
         boolean forwardBlocked = forward != 0.0F && blocked(bot, fx * (double)Math.signum(forward), fz * (double)Math.signum(forward));
         boolean strafeBlocked = strafe != 0.0F && blocked(bot, sx * (double)Math.signum(strafe), sz * (double)Math.signum(strafe));
         return !forwardBlocked && !strafeBlocked ? unchanged : new float[]{forwardBlocked ? 0.0F : forward, strafeBlocked ? 0.0F : strafe};
      }
   }

   private static boolean blocked(ServerPlayer bot, double dirX, double dirZ) {
      double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
      if (len < 1.0E-4) {
         return false;
      } else {
         double nx = dirX / len * 0.55;
         double nz = dirZ / len * 0.55;
         Level level = bot.level();
         Vec3 p = bot.position();
         return solid(level, p.x + nx, p.y, p.z + nz) || solid(level, p.x + nx, p.y + (double)1.0F, p.z + nz);
      }
   }

   private static boolean solid(Level level, double x, double y, double z) {
      BlockPos pos = BlockPos.containing(x, y, z);
      return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
   }
}
