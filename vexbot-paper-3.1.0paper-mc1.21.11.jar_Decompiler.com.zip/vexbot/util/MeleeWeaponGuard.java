package vexbot.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import vexbot.bot.ai.ItemEvaluator;

public final class MeleeWeaponGuard {
   private static final Map<UUID, Long> staleWindows = new ConcurrentHashMap();

   private MeleeWeaponGuard() {
   }

   public static void allowStaleWindow(ServerPlayer bot, int ticks) {
      staleWindows.put(bot.getUUID(), bot.level().getGameTime() + (long)ticks);
   }

   public static void clearStaleWindow(ServerPlayer bot) {
      staleWindows.remove(bot.getUUID());
   }

   private static boolean isMeleeWeapon(ItemStack s) {
      if (s.isEmpty()) {
         return false;
      } else if (ItemEvaluator.isMace(s)) {
         return true;
      } else {
         return !s.is(ItemTags.PICKAXES) && !s.is(ItemTags.SHOVELS) && !s.is(ItemTags.HOES) ? ItemEvaluator.isWeapon(s) : false;
      }
   }

   public static void ensureWeapon(ServerPlayer bot) {
      Long until = (Long)staleWindows.get(bot.getUUID());
      if (until != null) {
         if (bot.level().getGameTime() <= until) {
            return;
         }

         staleWindows.remove(bot.getUUID());
      }

      if (!bot.isUsingItem()) {
         if (!isMeleeWeapon(bot.getMainHandItem())) {
            Inventory inv = bot.getInventory();
            int best = -1;
            double bestScore = (double)0.0F;

            for(int i = 0; i < 36; ++i) {
               double score = ItemEvaluator.scoreWeapon(inv.getItem(i));
               if (score > bestScore) {
                  bestScore = score;
                  best = i;
               }
            }

            if (best < 0) {
               for(int i = 0; i < 36; ++i) {
                  double score = ItemEvaluator.scoreMace(inv.getItem(i));
                  if (score > bestScore) {
                     bestScore = score;
                     best = i;
                  }
               }
            }

            if (best < 0) {
               for(int i = 0; i < 9; ++i) {
                  if (inv.getItem(i).isEmpty()) {
                     InventoryUtils.select(inv, i);
                     return;
                  }
               }

            } else {
               InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, best));
               EquipmentSync.syncNow(bot);
            }
         }
      }
   }
}
