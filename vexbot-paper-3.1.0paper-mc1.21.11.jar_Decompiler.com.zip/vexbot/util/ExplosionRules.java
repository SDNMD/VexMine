package vexbot.util;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.VexBot;
import vexbot.team.TeamManager;

public final class ExplosionRules {
   private static final double NOTE_RADIUS = (double)12.0F;
   private static final int MAX_NOTES = 256;
   private static final ArrayDeque<Note> NOTES = new ArrayDeque();

   private ExplosionRules() {
   }

   public static synchronized void note(ServerPlayer player, Vec3 pos) {
      MinecraftServer server = VexBot.SERVER;
      if (server != null) {
         ServerLevel var4 = player.level();
         if (var4 instanceof ServerLevel) {
            ServerLevel level = var4;
            int var5 = server.getTickCount();

            while(!NOTES.isEmpty() && ((Note)NOTES.peekFirst()).tick() < var5 - 1) {
               NOTES.removeFirst();
            }

            if (NOTES.size() >= 256) {
               NOTES.removeFirst();
            }

            NOTES.addLast(new Note(player.getUUID(), level, pos, var5));
            return;
         }
      }

   }

   public static boolean blocksAllowed(ServerLevel level, Vec3 center, Entity direct, Entity indirect, DamageSource source) {
      if (allEnabled()) {
         return true;
      } else {
         ServerPlayer actor = actor(level, center, direct, indirect, source);
         return actor == null || allowedFor(actor);
      }
   }

   public static boolean allowedFor(ServerPlayer player) {
      TeamManager.BotTeam team = TeamManager.getTeamForMember(player.getScoreboardName());
      return team != null ? team.doBlockExplosion : BotSettings.doBlockExplosion;
   }

   private static boolean allEnabled() {
      if (!BotSettings.doBlockExplosion) {
         return false;
      } else {
         for(TeamManager.BotTeam t : TeamManager.allTeams()) {
            if (!t.doBlockExplosion) {
               return false;
            }
         }

         return true;
      }
   }

   private static ServerPlayer actor(ServerLevel level, Vec3 center, Entity direct, Entity indirect, DamageSource source) {
      if (indirect instanceof ServerPlayer p) {
         return p;
      } else {
         if (source != null) {
            Entity var6 = source.getEntity();
            if (var6 instanceof ServerPlayer) {
               ServerPlayer p = (ServerPlayer)var6;
               return p;
            }
         }

         return direct != null && !(direct instanceof EndCrystal) ? null : noted(level, center);
      }
   }

   private static synchronized ServerPlayer noted(ServerLevel level, Vec3 center) {
      MinecraftServer server = VexBot.SERVER;
      if (server == null) {
         return null;
      } else {
         int tick = server.getTickCount();
         Note best = null;
         double bestD = (double)144.0F;
         Iterator<Note> it = NOTES.descendingIterator();

         while(it.hasNext()) {
            Note n = (Note)it.next();
            if (n.tick() >= tick - 1 && n.level() == level) {
               double d = n.pos().distanceToSqr(center);
               if (d <= bestD) {
                  bestD = d;
                  best = n;
               }
            }
         }

         return best == null ? null : server.getPlayerList().getPlayer(best.player());
      }
   }

   private static record Note(UUID player, ServerLevel level, Vec3 pos, int tick) {
   }
}
