package vexbot.util;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class InventoryUtils {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot/InventoryUtils");

   private InventoryUtils() {
   }

   public static int selected(Inventory inv) {
      return inv.getSelectedSlot();
   }

   public static void select(Inventory inv, int slot) {
      if (slot >= 0 && slot <= 8) {
         inv.setSelectedSlot(slot);
      } else {
         StackTraceElement[] st = Thread.currentThread().getStackTrace();
         String caller = st.length > 2 ? st[2].toString() : "?";
         VexLog.detail(LOGGER, "ignored out-of-range hotbar select {} from {}", slot, caller);
      }
   }

   public static int moveToHotbarSafe(Inventory inv, int sourceSlot) {
      if (sourceSlot < 9) {
         return sourceSlot;
      } else {
         int dest = -1;

         for(int i = 0; i < 9; ++i) {
            if (inv.getItem(i).isEmpty()) {
               dest = i;
               break;
            }
         }

         if (dest < 0) {
            for(int i = 8; i >= 0; --i) {
               if (!isProtected(inv.getItem(i))) {
                  dest = i;
                  break;
               }
            }
         }

         if (dest < 0) {
            dest = 8;
         }

         ItemStack moving = inv.getItem(sourceSlot).copy();
         ItemStack displaced = inv.getItem(dest).copy();
         inv.setItem(dest, moving);
         inv.setItem(sourceSlot, displaced);
         return dest;
      }
   }

   public static boolean isProtected(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else if (stack.is(Items.MACE)) {
         return true;
      } else if (stack.is(ItemTags.SWORDS)) {
         return true;
      } else if (stack.is(ItemTags.AXES)) {
         return true;
      } else if (stack.is(Items.BOW)) {
         return true;
      } else if (stack.is(Items.CROSSBOW)) {
         return true;
      } else if (stack.is(ItemTags.SPEARS)) {
         return true;
      } else if (stack.is(Items.TRIDENT) && EnchantmentUtils.hasEnchantAtLeast(stack, "riptide", 3)) {
         return true;
      } else {
         return stack.is(Items.ELYTRA) ? true : EnchantmentUtils.hasEnchantAtLeast(stack, "lunge", 3);
      }
   }
}
