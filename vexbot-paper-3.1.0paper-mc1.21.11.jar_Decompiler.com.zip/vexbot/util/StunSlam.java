package vexbot.util;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;

public final class StunSlam {
   private int step = 0;
   private long pendingTick = -1L;
   private int targetId = -1;
   private static final int STALE_TICKS = 2;

   public Result tick(ServerPlayer bot, LivingEntity target, int axeSlot, int maceSlot, TechniqueConfig.StunSlamVariant variant, boolean enabled, EffectiveSettings effs) {
      if (target != null && target.isAlive() && maceSlot >= 0) {
         long now = bot.level().getGameTime();
         if (this.step > 0 && (target.getId() != this.targetId || now > this.pendingTick + 2L)) {
            this.reset();
         }

         if (this.step > 0) {
            return now < this.pendingTick ? StunSlam.Result.HOLD : this.advance(bot, target, axeSlot, maceSlot, variant);
         } else if (enabled && axeSlot >= 0) {
            if (!target.isBlocking()) {
               return StunSlam.Result.PLAIN;
            } else if (McCompat.invulnerableTime(target) > 10) {
               return StunSlam.Result.HOLD;
            } else if (!effs.rollStunSlamChanceOnly()) {
               return StunSlam.Result.PLAIN;
            } else if (variant == TechniqueConfig.StunSlamVariant.LEGACY_1TICK) {
               SwapEngine.syncedAttack(bot, axeSlot, target);
               SwapEngine.syncedAttack(bot, maceSlot, target);
               this.reset();
               return StunSlam.Result.SMASHED;
            } else {
               SwapEngine.syncedAttack(bot, axeSlot, target);
               this.targetId = target.getId();
               if (variant == TechniqueConfig.StunSlamVariant.OPTIMAL) {
                  InventoryUtils.select(bot.getInventory(), maceSlot);
                  this.step = 1;
                  this.pendingTick = now + 1L;
               } else {
                  this.step = 1;
                  this.pendingTick = now + 2L;
               }

               return StunSlam.Result.HOLD;
            }
         } else {
            return StunSlam.Result.PLAIN;
         }
      } else {
         this.reset();
         return StunSlam.Result.PLAIN;
      }
   }

   private Result advance(ServerPlayer bot, LivingEntity target, int axeSlot, int maceSlot, TechniqueConfig.StunSlamVariant variant) {
      long now = bot.level().getGameTime();
      if (variant == TechniqueConfig.StunSlamVariant.OPTIMAL) {
         this.reset();
         if (!bot.onGround() && !(bot.fallDistance <= (double)1.5F)) {
            SwapEngine.syncedAttack(bot, maceSlot, target);
            return StunSlam.Result.SMASHED;
         } else {
            return StunSlam.Result.PLAIN;
         }
      } else {
         switch (this.step) {
            case 1:
               InventoryUtils.select(bot.getInventory(), maceSlot);
               EquipmentSync.syncNow(bot);
               this.step = 2;
               this.pendingTick = now + 1L;
               return StunSlam.Result.HOLD;
            default:
               this.reset();
               if (!bot.onGround() && !(bot.fallDistance <= (double)1.5F)) {
                  SwapEngine.syncedAttack(bot, maceSlot, target);
                  return StunSlam.Result.SMASHED;
               } else {
                  return StunSlam.Result.PLAIN;
               }
         }
      }
   }

   public boolean isRunning() {
      return this.step > 0;
   }

   public void reset() {
      this.step = 0;
      this.pendingTick = -1L;
      this.targetId = -1;
   }

   public static enum Result {
      HOLD,
      SMASHED,
      PLAIN;

      // $FF: synthetic method
      private static Result[] $values() {
         return new Result[]{HOLD, SMASHED, PLAIN};
      }
   }
}
