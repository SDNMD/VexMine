package vexbot.util;

import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;

public final class UseSlowdown {
   private static final Identifier SPEED_ID = Identifier.withDefaultNamespace("vexbot_use_slow");

   private UseSlowdown() {
   }

   public static void tick(ServerPlayer bot) {
      if (bot != null) {
         AttributeInstance attr = bot.getAttribute(Attributes.MOVEMENT_SPEED);
         if (attr != null) {
            attr.removeModifier(SPEED_ID);
            boolean using = bot.isUsingItem() && bot.getUsedItemHand() == InteractionHand.MAIN_HAND && !bot.getUseItem().has(DataComponents.KINETIC_WEAPON);
            if (using) {
               bot.setSprinting(false);
            }
         }
      }
   }

   public static void clear(ServerPlayer bot) {
      if (bot != null) {
         AttributeInstance attr = bot.getAttribute(Attributes.MOVEMENT_SPEED);
         if (attr != null) {
            attr.removeModifier(SPEED_ID);
         }

      }
   }
}
