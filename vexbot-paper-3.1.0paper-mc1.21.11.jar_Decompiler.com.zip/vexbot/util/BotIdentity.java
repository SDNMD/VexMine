package vexbot.util;

import net.minecraft.server.level.ServerPlayer;
import vexbot.compat.McCompat;
import vexbot.fakeplayer.bot.BotPlayer;

public final class BotIdentity {
   private BotIdentity() {
   }

   public static boolean isBot(ServerPlayer p) {
      return p instanceof BotPlayer || McCompat.tags(p).contains("vexbot");
   }
}
