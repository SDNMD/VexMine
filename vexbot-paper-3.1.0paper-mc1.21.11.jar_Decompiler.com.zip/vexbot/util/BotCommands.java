package vexbot.util;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.BotSettings;
import vexbot.bot.BotManager;
import vexbot.fakeplayer.bot.BotPlayerActionPack;
import vexbot.platform.Internals;

public final class BotCommands {
   private BotCommands() {
   }

   private static BotPlayerActionPack getActionPack(MinecraftServer server, String name) {
      ServerPlayer player = BotManager.resolveTrackedBotPlayer(server, name);
      return player != null ? Internals.get().actionPack(player) : null;
   }

   public static void moveForward(MinecraftServer server, String name) {
      if (!BotSettings.movementFrozen) {
         BotPlayerActionPack ap = getActionPack(server, name);
         if (ap != null) {
            ap.setForward(1.0F);
         }

      }
   }

   public static void moveBackward(MinecraftServer server, String name) {
      if (!BotSettings.movementFrozen) {
         BotPlayerActionPack ap = getActionPack(server, name);
         if (ap != null) {
            ap.setForward(-1.0F);
         }

      }
   }

   public static void moveLeft(MinecraftServer server, String name) {
      if (!BotSettings.movementFrozen) {
         BotPlayerActionPack ap = getActionPack(server, name);
         if (ap != null) {
            ap.setStrafing(1.0F);
         }

      }
   }

   public static void moveRight(MinecraftServer server, String name) {
      if (!BotSettings.movementFrozen) {
         BotPlayerActionPack ap = getActionPack(server, name);
         if (ap != null) {
            ap.setStrafing(-1.0F);
         }

      }
   }

   public static void setSpeedScale(MinecraftServer server, String name, float scale) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.setSpeedScale(scale);
      }

   }

   public static void setMovement(MinecraftServer server, String name, float forward, float strafe) {
      if (!BotSettings.movementFrozen) {
         BotPlayerActionPack ap = getActionPack(server, name);
         if (ap != null) {
            ap.setForward(forward);
            ap.setStrafing(strafe);
         }

      }
   }

   public static void stopMoving(MinecraftServer server, String name) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.stopMovement();
      }

   }

   public static void stopLookInterpolation(MinecraftServer server, String name) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.stopInterpolation();
      }

   }

   public static void setSprinting(MinecraftServer server, String name, boolean sprint) {
      if (!BotSettings.movementFrozen || !sprint) {
         BotPlayerActionPack ap = getActionPack(server, name);
         if (ap != null) {
            ap.setSprinting(sprint);
         }

      }
   }

   public static void jumpOnce(MinecraftServer server, String name) {
      if (!BotSettings.movementFrozen) {
         BotPlayerActionPack ap = getActionPack(server, name);
         if (ap != null) {
            ap.start(BotPlayerActionPack.ActionType.JUMP, BotPlayerActionPack.Action.once());
         }

      }
   }

   public static void attackOnce(MinecraftServer server, String name) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.start(BotPlayerActionPack.ActionType.ATTACK, BotPlayerActionPack.Action.once());
      }

   }

   public static void mineContinuous(MinecraftServer server, String name) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.start(BotPlayerActionPack.ActionType.ATTACK, BotPlayerActionPack.Action.continuous());
      }

   }

   public static void stopMining(MinecraftServer server, String name) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.stop(BotPlayerActionPack.ActionType.ATTACK);
      }

   }

   public static void startUsingItem(MinecraftServer server, String name) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.start(BotPlayerActionPack.ActionType.USE, BotPlayerActionPack.Action.continuous());
      }

   }

   public static void stopUsingItem(MinecraftServer server, String name) {
      BotPlayerActionPack ap = getActionPack(server, name);
      if (ap != null) {
         ap.stop(BotPlayerActionPack.ActionType.USE);
      }

   }
}
