package vexbot.util;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import vexbot.compat.McCompat;
import vexbot.i18n.VexText;

public final class NameTagColour {
   private static final String TEAM_PREFIX = "vexbot_c_";
   private static final String TAG_TEAM_PREFIX = "vexbot_t_";
   private static final Map<String, ChatFormatting> NAMES = new LinkedHashMap();
   public static final String NONE = "none";

   private NameTagColour() {
   }

   private static boolean ours(PlayerTeam t) {
      return t.getName().startsWith("vexbot_c_") || t.getName().startsWith("vexbot_t_");
   }

   public static String[] suggestions() {
      String[] out = new String[NAMES.size() + 1];
      out[0] = "none";
      int i = 1;

      for(String k : NAMES.keySet()) {
         out[i++] = k;
      }

      return out;
   }

   public static String parse(String raw) {
      String v = raw.toLowerCase(Locale.ROOT).trim().replace(' ', '_').replace("-", "_");
      if (!v.equals("none") && !v.equals("off") && !v.equals("clear") && !v.equals("default")) {
         if (!NAMES.containsKey(v)) {
            throw new IllegalArgumentException("Unknown colour '§e" + raw + "§r'. Run §e/vexbot settings nametagcolour§r for the list.");
         } else {
            return v;
         }
      } else {
         return "none";
      }
   }

   public static ChatFormatting formatting(String colourName) {
      return (ChatFormatting)NAMES.get(colourName);
   }

   public static void apply(MinecraftServer server, ServerPlayer player, String colourName) {
      apply(server, player, colourName, (Tag)null);
   }

   public static void apply(MinecraftServer server, ServerPlayer player, String colourName, Tag tag) {
      if (server != null && player != null) {
         Scoreboard board = server.getScoreboard();
         String entry = player.getScoreboardName();
         boolean noColour = colourName == null || "none".equals(colourName);
         ChatFormatting fmt = noColour ? null : (ChatFormatting)NAMES.get(colourName);
         if (fmt == null) {
            noColour = true;
         }

         if (tag == null && noColour) {
            PlayerTeam current = board.getPlayersTeam(entry);
            if (current != null && ours(current)) {
               board.removePlayerFromTeam(entry, current);
            }

         } else {
            String teamName = tag == null ? "vexbot_c_" + colourName : "vexbot_t_" + tag.name().toLowerCase(Locale.ROOT) + "_" + (noColour ? "none" : colourName);
            PlayerTeam team = board.getPlayerTeam(teamName);
            if (team == null) {
               team = board.addPlayerTeam(teamName);
               team.setSeeFriendlyInvisibles(false);
            }

            if (fmt != null && !McCompat.teamColourIs(team, fmt)) {
               McCompat.setTeamColour(team, fmt);
            }

            McCompat.setTeamPrefix(team, tag == null ? Component.empty() : VexText.literal(tag.label + " ").withStyle(new ChatFormatting[]{ChatFormatting.BOLD, tag.colour}));
            PlayerTeam current = board.getPlayersTeam(entry);
            if (current == null || current == team || ours(current)) {
               if (current != team) {
                  board.addPlayerToTeam(entry, team);
               }

            }
         }
      }
   }

   static {
      NAMES.put("black", ChatFormatting.BLACK);
      NAMES.put("dark_blue", ChatFormatting.DARK_BLUE);
      NAMES.put("dark_green", ChatFormatting.DARK_GREEN);
      NAMES.put("dark_aqua", ChatFormatting.DARK_AQUA);
      NAMES.put("dark_red", ChatFormatting.DARK_RED);
      NAMES.put("dark_purple", ChatFormatting.DARK_PURPLE);
      NAMES.put("gold", ChatFormatting.GOLD);
      NAMES.put("gray", ChatFormatting.GRAY);
      NAMES.put("dark_gray", ChatFormatting.DARK_GRAY);
      NAMES.put("blue", ChatFormatting.BLUE);
      NAMES.put("green", ChatFormatting.GREEN);
      NAMES.put("aqua", ChatFormatting.AQUA);
      NAMES.put("red", ChatFormatting.RED);
      NAMES.put("light_purple", ChatFormatting.LIGHT_PURPLE);
      NAMES.put("yellow", ChatFormatting.YELLOW);
      NAMES.put("white", ChatFormatting.WHITE);
      NAMES.put("grey", ChatFormatting.GRAY);
      NAMES.put("dark_grey", ChatFormatting.DARK_GRAY);
      NAMES.put("silver", ChatFormatting.GRAY);
      NAMES.put("charcoal", ChatFormatting.DARK_GRAY);
      NAMES.put("crimson", ChatFormatting.DARK_RED);
      NAMES.put("maroon", ChatFormatting.DARK_RED);
      NAMES.put("blood", ChatFormatting.DARK_RED);
      NAMES.put("scarlet", ChatFormatting.RED);
      NAMES.put("salmon", ChatFormatting.RED);
      NAMES.put("coral", ChatFormatting.RED);
      NAMES.put("pink", ChatFormatting.LIGHT_PURPLE);
      NAMES.put("magenta", ChatFormatting.LIGHT_PURPLE);
      NAMES.put("rose", ChatFormatting.LIGHT_PURPLE);
      NAMES.put("violet", ChatFormatting.DARK_PURPLE);
      NAMES.put("purple", ChatFormatting.DARK_PURPLE);
      NAMES.put("indigo", ChatFormatting.DARK_PURPLE);
      NAMES.put("plum", ChatFormatting.DARK_PURPLE);
      NAMES.put("lavender", ChatFormatting.LIGHT_PURPLE);
      NAMES.put("navy", ChatFormatting.DARK_BLUE);
      NAMES.put("midnight", ChatFormatting.DARK_BLUE);
      NAMES.put("royal", ChatFormatting.BLUE);
      NAMES.put("sky", ChatFormatting.AQUA);
      NAMES.put("cyan", ChatFormatting.AQUA);
      NAMES.put("turquoise", ChatFormatting.AQUA);
      NAMES.put("teal", ChatFormatting.DARK_AQUA);
      NAMES.put("ocean", ChatFormatting.DARK_AQUA);
      NAMES.put("lime", ChatFormatting.GREEN);
      NAMES.put("mint", ChatFormatting.GREEN);
      NAMES.put("emerald", ChatFormatting.DARK_GREEN);
      NAMES.put("forest", ChatFormatting.DARK_GREEN);
      NAMES.put("olive", ChatFormatting.DARK_GREEN);
      NAMES.put("amber", ChatFormatting.GOLD);
      NAMES.put("orange", ChatFormatting.GOLD);
      NAMES.put("bronze", ChatFormatting.GOLD);
      NAMES.put("brown", ChatFormatting.GOLD);
      NAMES.put("sand", ChatFormatting.YELLOW);
      NAMES.put("cream", ChatFormatting.YELLOW);
      NAMES.put("lemon", ChatFormatting.YELLOW);
      NAMES.put("snow", ChatFormatting.WHITE);
      NAMES.put("ivory", ChatFormatting.WHITE);
      NAMES.put("ghost", ChatFormatting.WHITE);
      NAMES.put("void", ChatFormatting.BLACK);
      NAMES.put("obsidian", ChatFormatting.BLACK);
   }

   public static enum Tag {
      BOT("BOT", ChatFormatting.AQUA),
      DEV("DEV", ChatFormatting.YELLOW);

      public final String label;
      public final ChatFormatting colour;

      private Tag(String label, ChatFormatting colour) {
         this.label = label;
         this.colour = colour;
      }

      // $FF: synthetic method
      private static Tag[] $values() {
         return new Tag[]{BOT, DEV};
      }
   }
}
