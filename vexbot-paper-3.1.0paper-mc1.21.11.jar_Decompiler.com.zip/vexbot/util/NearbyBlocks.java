package vexbot.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;

public final class NearbyBlocks {
   private final Level level;
   private LevelChunk chunkA;
   private LevelChunk chunkB;
   private int ax;
   private int az;
   private int bx;
   private int bz;

   public NearbyBlocks(Level level) {
      this.level = level;
   }

   public Level level() {
      return this.level;
   }

   public BlockState state(BlockPos pos) {
      return !this.level.isInValidBounds(pos) ? Blocks.VOID_AIR.defaultBlockState() : this.chunk(pos).getBlockState(pos);
   }

   public FluidState fluid(BlockPos pos) {
      return !this.level.isInValidBounds(pos) ? Fluids.EMPTY.defaultFluidState() : this.chunk(pos).getFluidState(pos);
   }

   public boolean solid(BlockPos pos) {
      return !this.state(pos).getCollisionShape(this.level, pos).isEmpty();
   }

   private LevelChunk chunk(BlockPos pos) {
      int cx = SectionPos.blockToSectionCoord(pos.getX());
      int cz = SectionPos.blockToSectionCoord(pos.getZ());
      if (this.chunkA != null && cx == this.ax && cz == this.az) {
         return this.chunkA;
      } else if (this.chunkB != null && cx == this.bx && cz == this.bz) {
         LevelChunk c = this.chunkB;
         this.chunkB = this.chunkA;
         this.bx = this.ax;
         this.bz = this.az;
         this.chunkA = c;
         this.ax = cx;
         this.az = cz;
         return c;
      } else {
         LevelChunk c = this.level.getChunk(cx, cz);
         this.chunkB = this.chunkA;
         this.bx = this.ax;
         this.bz = this.az;
         this.chunkA = c;
         this.ax = cx;
         this.az = cz;
         return c;
      }
   }
}
