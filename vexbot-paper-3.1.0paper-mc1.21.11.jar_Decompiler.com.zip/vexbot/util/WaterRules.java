package vexbot.util;

import net.minecraft.core.BlockPos;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.level.Level;

public final class WaterRules {
   private WaterRules() {
   }

   public static boolean evaporates(Level level, BlockPos pos) {
      return Boolean.TRUE.equals(level.environmentAttributes().getValue(EnvironmentAttributes.WATER_EVAPORATES, pos));
   }
}
