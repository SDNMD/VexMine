package vexbot.util;

import org.slf4j.Logger;
import vexbot.BotSettings;

public final class VexLog {
   private VexLog() {
   }

   public static void detail(Logger log, String fmt, Object... args) {
      if (BotSettings.gameLogs == BotSettings.GameLogs.DETAILED) {
         log.info(fmt, args);
      }

   }

   public static void brief(Logger log, String fmt, Object... args) {
      if (BotSettings.gameLogs != BotSettings.GameLogs.SIMPLE) {
         log.info(fmt, args);
      }

   }

   public static void always(Logger log, String fmt, Object... args) {
      log.info(fmt, args);
   }
}
