package vexbot.util;

import net.minecraft.server.level.ServerPlayer;
import vexbot.platform.Internals;

public final class EquipmentSync {
   private EquipmentSync() {
   }

   public static void syncNow(ServerPlayer bot) {
      Internals.get().detectEquipmentUpdates(bot);
   }
}
