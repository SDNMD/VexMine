package vexbot.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class ElytraFlight {
   private static final int GROUND_GRACE_TICKS = 2;
   private static final Map<UUID, Integer> GROUNDED = new ConcurrentHashMap();

   private ElytraFlight() {
   }

   public static boolean isUsable(ItemStack stack) {
      return stack.is(Items.ELYTRA) && stack.getDamageValue() < stack.getMaxDamage() - 1;
   }

   public static boolean worn(ServerPlayer bot) {
      return isUsable(bot.getItemBySlot(EquipmentSlot.CHEST));
   }

   public static boolean hasElytra(ServerPlayer bot) {
      if (worn(bot)) {
         return true;
      } else {
         Inventory inv = bot.getInventory();

         for(int i = 0; i < 36; ++i) {
            if (isUsable(inv.getItem(i))) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean equip(ServerPlayer bot) {
      if (worn(bot)) {
         return true;
      } else {
         Inventory inv = bot.getInventory();
         ItemStack chest = bot.getItemBySlot(EquipmentSlot.CHEST);

         for(int i = 0; i < 36; ++i) {
            if (isUsable(inv.getItem(i))) {
               ItemStack elytra = inv.getItem(i).copy();
               inv.setItem(i, chest.copy());
               bot.setItemSlot(EquipmentSlot.CHEST, elytra);
               EquipmentSync.syncNow(bot);
               return true;
            }
         }

         return false;
      }
   }

   public static boolean beginGlide(ServerPlayer bot) {
      if (bot.isFallFlying()) {
         return true;
      } else if (!equip(bot)) {
         return false;
      } else if (!bot.isInWater() && !bot.isInLava()) {
         bot.tryToStartFallFlying();
         if (!bot.isFallFlying() && !bot.onGround()) {
            bot.startFallFlying();
         }

         return bot.isFallFlying();
      } else {
         return false;
      }
   }

   public static void stopGlide(ServerPlayer bot) {
      if (bot.isFallFlying()) {
         bot.stopFallFlying();
      }

   }

   public static boolean guard(ServerPlayer bot) {
      if (!bot.isFallFlying()) {
         GROUNDED.remove(bot.getUUID());
         return false;
      } else if (!worn(bot)) {
         bot.stopFallFlying();
         GROUNDED.remove(bot.getUUID());
         return true;
      } else if (!bot.onGround()) {
         GROUNDED.remove(bot.getUUID());
         return false;
      } else {
         int down = (Integer)GROUNDED.merge(bot.getUUID(), 1, Integer::sum);
         if (down < 2) {
            return false;
         } else {
            bot.stopFallFlying();
            GROUNDED.remove(bot.getUUID());
            return true;
         }
      }
   }

   public static void forget(ServerPlayer bot) {
      GROUNDED.remove(bot.getUUID());
   }
}
