package vexbot.util;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.compat.McCompat;

public final class SwapEngine {
   private static final double WC_SAFE_RADIUS = (double)8.0F;
   private static final double WC_SAFE_COS = 0.866;

   private SwapEngine() {
   }

   public static void staleSwapAttack(ServerPlayer bot, int postSlot, LivingEntity target) {
      InventoryUtils.select(bot.getInventory(), postSlot);
      bot.attack(target);
      McCompat.swing(bot, InteractionHand.MAIN_HAND);
   }

   public static void staleSwapAttackWindowed(ServerPlayer bot, int postSlot, LivingEntity target) {
      MeleeWeaponGuard.allowStaleWindow(bot, 1);
      staleSwapAttack(bot, postSlot, target);
      MeleeWeaponGuard.clearStaleWindow(bot);
   }

   public static void syncedAttack(ServerPlayer bot, int slot, LivingEntity target) {
      InventoryUtils.select(bot.getInventory(), slot);
      EquipmentSync.syncNow(bot);
      bot.attack(target);
      McCompat.swing(bot, InteractionHand.MAIN_HAND);
   }

   public static boolean fireWindCharge(ServerPlayer bot, int wcSlot, float pitch) {
      if (wcSlot >= 0 && wcSlot <= 8) {
         if (bot.getCooldowns().isOnCooldown(new ItemStack(Items.WIND_CHARGE))) {
            return false;
         } else {
            InventoryUtils.select(bot.getInventory(), wcSlot);
            bot.setXRot(pitch);
            ItemStack wc = bot.getMainHandItem();
            if (wc.is(Items.WIND_CHARGE)) {
               ServerLevel var5 = bot.level();
               if (var5 instanceof ServerLevel) {
                  ServerLevel level = var5;
                  if (aimedAtSomeone(bot)) {
                     return false;
                  }

                  try {
                     bot.gameMode.useItem(bot, level, wc, InteractionHand.MAIN_HAND);
                     return true;
                  } catch (Exception var6) {
                     return false;
                  }
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private static boolean aimedAtSomeone(ServerPlayer bot) {
      Vec3 eye = bot.getEyePosition();
      Vec3 look = bot.getViewVector(1.0F).normalize();

      for(LivingEntity e : bot.level().getEntitiesOfClass(LivingEntity.class, bot.getBoundingBox().inflate((double)8.0F))) {
         if (e != bot) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            double d = to.length();
            if (!(d < 0.1) && !(d > (double)8.0F) && look.dot(to.normalize()) >= 0.866) {
               return true;
            }
         }
      }

      return false;
   }

   public static boolean fireWindChargeSelf(ServerPlayer bot, int wcSlot, float pitch) {
      if (wcSlot >= 0 && wcSlot <= 8) {
         if (bot.getCooldowns().isOnCooldown(new ItemStack(Items.WIND_CHARGE))) {
            return false;
         } else {
            InventoryUtils.select(bot.getInventory(), wcSlot);
            bot.setXRot(pitch);
            ItemStack wc = bot.getMainHandItem();
            if (wc.is(Items.WIND_CHARGE)) {
               ServerLevel var5 = bot.level();
               if (var5 instanceof ServerLevel) {
                  ServerLevel level = var5;

                  try {
                     bot.gameMode.useItem(bot, level, wc, InteractionHand.MAIN_HAND);
                     return true;
                  } catch (Exception var6) {
                     return false;
                  }
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean fireWindChargeDown(ServerPlayer bot, int wcSlot) {
      return fireWindCharge(bot, wcSlot, 80.0F);
   }

   public static boolean fireWindChargeUp(ServerPlayer bot, int wcSlot) {
      return fireWindCharge(bot, wcSlot, -90.0F);
   }

   public static boolean throwPearl(ServerPlayer bot, int pearlSlot) {
      if (pearlSlot >= 0 && pearlSlot <= 8) {
         InventoryUtils.select(bot.getInventory(), pearlSlot);
         ItemStack p = bot.getMainHandItem();
         if (p.is(Items.ENDER_PEARL)) {
            ServerLevel var4 = bot.level();
            if (var4 instanceof ServerLevel) {
               ServerLevel level = var4;

               try {
                  bot.gameMode.useItem(bot, level, p, InteractionHand.MAIN_HAND);
                  return true;
               } catch (Exception var5) {
                  return false;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean sameTickJumpAndWc(MinecraftServer server, ServerPlayer bot, int wcSlot) {
      BotCommands.jumpOnce(server, bot.getScoreboardName());
      return fireWindChargeDown(bot, wcSlot);
   }

   public static boolean crouchBoostFire(ServerPlayer bot, int wcSlot) {
      bot.setShiftKeyDown(true);
      return fireWindChargeDown(bot, wcSlot);
   }

   public static void useDown(ServerPlayer bot, InteractionHand hand) {
      bot.startUsingItem(hand);
   }

   public static void useUp(ServerPlayer bot) {
      bot.stopUsingItem();
   }
}
