package vexbot;

import com.google.gson.JsonObject;
import java.util.Random;

public final class DifficultyParams {
   public double missChance;
   public double accuracy;
   public double clutchAccuracy;
   public int reactionMinTicks;
   public int reactionMaxTicks;
   public int shieldReactionMs;
   public int shieldReactionJitterMs;
   public double shieldDisableCharge;
   public double strafeAngle;
   public double critThreshold;
   public int anchorIntervalTicks;
   public int stunSlamChance;
   public double potIntervalSeconds;
   public double webDrainDelaySeconds;
   public double webEscapeDelaySeconds;
   public int reachFlips = 0;
   public int cartSkipChance = 0;
   public int cartCooldownTicks = 3;
   public int crystalCooldownTicks = 0;
   public int anchorCooldownTicks = 5;
   public int elytraMaceLevel = 5;
   public int crystalPvpLevel = 5;

   public int potIntervalTicks() {
      return Math.max(1, (int)Math.round(this.potIntervalSeconds * (double)20.0F));
   }

   public int webDrainDelayTicks() {
      return Math.max(0, (int)Math.round(this.webDrainDelaySeconds * (double)20.0F));
   }

   public int webEscapeDelayTicks() {
      return Math.max(0, (int)Math.round(this.webEscapeDelaySeconds * (double)20.0F));
   }

   public static DifficultyParams forPreset(BotSettings.Difficulty d) {
      DifficultyParams p = new DifficultyParams();
      switch (d) {
         case EASY:
            p.missChance = 0.35;
            p.accuracy = 0.15;
            p.clutchAccuracy = 0.1;
            p.reactionMinTicks = 6;
            p.reactionMaxTicks = 14;
            p.shieldReactionMs = 700;
            p.shieldReactionJitterMs = 150;
            p.shieldDisableCharge = 0.7;
            p.strafeAngle = (double)50.0F;
            p.critThreshold = -0.15;
            p.anchorIntervalTicks = 30;
            p.stunSlamChance = 20;
            p.potIntervalSeconds = (double)1.0F;
            p.webDrainDelaySeconds = (double)1.5F;
            p.webEscapeDelaySeconds = (double)1.5F;
            p.elytraMaceLevel = 1;
            p.reachFlips = 10;
            p.cartSkipChance = 80;
            p.cartCooldownTicks = 15;
            p.crystalCooldownTicks = 12;
            p.anchorCooldownTicks = 20;
            p.crystalPvpLevel = 1;
            break;
         case MEDIUM:
            p.missChance = (double)0.25F;
            p.accuracy = 0.45;
            p.clutchAccuracy = 0.35;
            p.reactionMinTicks = 3;
            p.reactionMaxTicks = 7;
            p.shieldReactionMs = 400;
            p.shieldReactionJitterMs = 100;
            p.shieldDisableCharge = 0.6;
            p.strafeAngle = (double)38.0F;
            p.critThreshold = -0.08;
            p.anchorIntervalTicks = 18;
            p.stunSlamChance = 45;
            p.potIntervalSeconds = 0.7;
            p.webDrainDelaySeconds = (double)1.0F;
            p.webEscapeDelaySeconds = (double)1.0F;
            p.elytraMaceLevel = 2;
            p.reachFlips = 10;
            p.cartSkipChance = 60;
            p.cartCooldownTicks = 12;
            p.crystalCooldownTicks = 7;
            p.anchorCooldownTicks = 13;
            p.crystalPvpLevel = 2;
            break;
         case HARD:
            p.missChance = 0.1;
            p.accuracy = 0.7;
            p.clutchAccuracy = 0.6;
            p.reactionMinTicks = 1;
            p.reactionMaxTicks = 3;
            p.shieldReactionMs = 200;
            p.shieldReactionJitterMs = 50;
            p.shieldDisableCharge = 0.55;
            p.strafeAngle = (double)28.0F;
            p.critThreshold = -0.03;
            p.anchorIntervalTicks = 4;
            p.stunSlamChance = 70;
            p.potIntervalSeconds = 0.4;
            p.webDrainDelaySeconds = 0.6;
            p.webEscapeDelaySeconds = 0.6;
            p.elytraMaceLevel = 3;
            p.reachFlips = 8;
            p.cartSkipChance = 40;
            p.cartCooldownTicks = 9;
            p.crystalCooldownTicks = 2;
            p.anchorCooldownTicks = 6;
            p.crystalPvpLevel = 3;
            break;
         case EXPERT:
            p.missChance = 0.05;
            p.accuracy = 0.9;
            p.clutchAccuracy = 0.85;
            p.reactionMinTicks = 1;
            p.reactionMaxTicks = 1;
            p.shieldReactionMs = 100;
            p.shieldReactionJitterMs = 50;
            p.shieldDisableCharge = 0.4;
            p.strafeAngle = (double)22.0F;
            p.critThreshold = -0.01;
            p.anchorIntervalTicks = 3;
            p.stunSlamChance = 90;
            p.potIntervalSeconds = 0.2;
            p.webDrainDelaySeconds = 0.3;
            p.webEscapeDelaySeconds = 0.3;
            p.elytraMaceLevel = 4;
            p.reachFlips = 6;
            p.cartSkipChance = 20;
            p.cartCooldownTicks = 6;
            p.crystalCooldownTicks = 1;
            p.anchorCooldownTicks = 5;
            p.crystalPvpLevel = 4;
            break;
         case PERFECT:
            p.missChance = (double)0.0F;
            p.accuracy = (double)1.0F;
            p.clutchAccuracy = (double)1.0F;
            p.reactionMinTicks = 0;
            p.reactionMaxTicks = 0;
            p.shieldReactionMs = 50;
            p.shieldReactionJitterMs = 0;
            p.shieldDisableCharge = 0.1;
            p.strafeAngle = (double)18.0F;
            p.critThreshold = (double)0.0F;
            p.anchorIntervalTicks = 2;
            p.stunSlamChance = 100;
            p.potIntervalSeconds = 0.05;
            p.webDrainDelaySeconds = 0.1;
            p.webEscapeDelaySeconds = 0.1;
            p.elytraMaceLevel = 5;
            p.reachFlips = 0;
            p.cartSkipChance = 0;
            p.cartCooldownTicks = 3;
            p.crystalCooldownTicks = 0;
            p.anchorCooldownTicks = 5;
            p.crystalPvpLevel = 5;
      }

      return p;
   }

   public DifficultyParams copy() {
      DifficultyParams p = new DifficultyParams();
      p.missChance = this.missChance;
      p.accuracy = this.accuracy;
      p.clutchAccuracy = this.clutchAccuracy;
      p.reactionMinTicks = this.reactionMinTicks;
      p.reactionMaxTicks = this.reactionMaxTicks;
      p.shieldReactionMs = this.shieldReactionMs;
      p.shieldReactionJitterMs = this.shieldReactionJitterMs;
      p.shieldDisableCharge = this.shieldDisableCharge;
      p.strafeAngle = this.strafeAngle;
      p.critThreshold = this.critThreshold;
      p.anchorIntervalTicks = this.anchorIntervalTicks;
      p.stunSlamChance = this.stunSlamChance;
      p.potIntervalSeconds = this.potIntervalSeconds;
      p.webDrainDelaySeconds = this.webDrainDelaySeconds;
      p.webEscapeDelaySeconds = this.webEscapeDelaySeconds;
      p.elytraMaceLevel = this.elytraMaceLevel;
      p.crystalPvpLevel = this.crystalPvpLevel;
      p.reachFlips = this.reachFlips;
      p.cartSkipChance = this.cartSkipChance;
      p.cartCooldownTicks = this.cartCooldownTicks;
      p.crystalCooldownTicks = this.crystalCooldownTicks;
      p.anchorCooldownTicks = this.anchorCooldownTicks;
      return p;
   }

   public int rollReactionTicks(Random rng) {
      int span = Math.max(0, this.reactionMaxTicks - this.reactionMinTicks);
      return this.reactionMinTicks + (span == 0 ? 0 : rng.nextInt(span + 1));
   }

   public int rollShieldReactionTicks(Random rng) {
      int jitter = this.shieldReactionJitterMs <= 0 ? 0 : rng.nextInt(this.shieldReactionJitterMs * 2 + 1) - this.shieldReactionJitterMs;
      return Math.max(1, Math.round((float)(this.shieldReactionMs + jitter) / 50.0F));
   }

   public void writeTo(JsonObject o) {
      o.addProperty("missChance", this.missChance);
      o.addProperty("accuracy", this.accuracy);
      o.addProperty("clutchAccuracy", this.clutchAccuracy);
      o.addProperty("reactionMinTicks", this.reactionMinTicks);
      o.addProperty("reactionMaxTicks", this.reactionMaxTicks);
      o.addProperty("shieldReactionMs", this.shieldReactionMs);
      o.addProperty("shieldReactionJitterMs", this.shieldReactionJitterMs);
      o.addProperty("shieldDisableCharge", this.shieldDisableCharge);
      o.addProperty("strafeAngle", this.strafeAngle);
      o.addProperty("critThreshold", this.critThreshold);
      o.addProperty("anchorIntervalTicks", this.anchorIntervalTicks);
      o.addProperty("stunSlamChance", this.stunSlamChance);
      o.addProperty("potIntervalSeconds", this.potIntervalSeconds);
      o.addProperty("webDrainDelaySeconds", this.webDrainDelaySeconds);
      o.addProperty("webEscapeDelaySeconds", this.webEscapeDelaySeconds);
      o.addProperty("elytraMaceLevel", this.elytraMaceLevel);
      o.addProperty("crystalPvpLevel", this.crystalPvpLevel);
      o.addProperty("reachFlips", this.reachFlips);
      o.addProperty("cartSkipChance", this.cartSkipChance);
      o.addProperty("cartCooldownTicks", this.cartCooldownTicks);
      o.addProperty("crystalCooldownTicks", this.crystalCooldownTicks);
      o.addProperty("anchorCooldownTicks", this.anchorCooldownTicks);
   }

   public void readFrom(JsonObject o) {
      if (o != null) {
         if (o.has("missChance")) {
            this.missChance = o.get("missChance").getAsDouble();
         }

         if (o.has("accuracy")) {
            this.accuracy = o.get("accuracy").getAsDouble();
         }

         if (o.has("clutchAccuracy")) {
            this.clutchAccuracy = o.get("clutchAccuracy").getAsDouble();
         }

         if (o.has("reactionMinTicks")) {
            this.reactionMinTicks = o.get("reactionMinTicks").getAsInt();
         }

         if (o.has("reactionMaxTicks")) {
            this.reactionMaxTicks = o.get("reactionMaxTicks").getAsInt();
         }

         if (o.has("shieldReactionMs")) {
            this.shieldReactionMs = o.get("shieldReactionMs").getAsInt();
         }

         if (o.has("shieldReactionJitterMs")) {
            this.shieldReactionJitterMs = o.get("shieldReactionJitterMs").getAsInt();
         }

         if (o.has("shieldDisableCharge")) {
            this.shieldDisableCharge = o.get("shieldDisableCharge").getAsDouble();
         }

         if (o.has("strafeAngle")) {
            this.strafeAngle = o.get("strafeAngle").getAsDouble();
         }

         if (o.has("critThreshold")) {
            this.critThreshold = o.get("critThreshold").getAsDouble();
         }

         if (o.has("anchorIntervalTicks")) {
            this.anchorIntervalTicks = o.get("anchorIntervalTicks").getAsInt();
         }

         if (o.has("stunSlamChance")) {
            this.stunSlamChance = o.get("stunSlamChance").getAsInt();
         }

         if (o.has("potIntervalSeconds")) {
            this.potIntervalSeconds = o.get("potIntervalSeconds").getAsDouble();
         }

         if (o.has("webDrainDelaySeconds")) {
            this.webDrainDelaySeconds = o.get("webDrainDelaySeconds").getAsDouble();
         }

         if (o.has("webEscapeDelaySeconds")) {
            this.webEscapeDelaySeconds = o.get("webEscapeDelaySeconds").getAsDouble();
         }

         if (o.has("elytraMaceLevel")) {
            this.elytraMaceLevel = o.get("elytraMaceLevel").getAsInt();
         }

         if (o.has("reachFlips")) {
            this.reachFlips = o.get("reachFlips").getAsInt();
         }

         if (o.has("cartSkipChance")) {
            this.cartSkipChance = o.get("cartSkipChance").getAsInt();
         }

         if (o.has("cartCooldownTicks")) {
            this.cartCooldownTicks = o.get("cartCooldownTicks").getAsInt();
         }

         if (o.has("crystalCooldownTicks")) {
            this.crystalCooldownTicks = o.get("crystalCooldownTicks").getAsInt();
         }

         if (o.has("anchorCooldownTicks")) {
            this.anchorCooldownTicks = o.get("anchorCooldownTicks").getAsInt();
         }

         if (o.has("crystalPvpLevel")) {
            this.crystalPvpLevel = o.get("crystalPvpLevel").getAsInt();
         } else {
            this.crystalPvpLevel = this.crystalCooldownTicks >= 8 ? 1 : (this.crystalCooldownTicks >= 5 ? 2 : (this.crystalCooldownTicks >= 3 ? 3 : (this.crystalCooldownTicks >= 1 ? 4 : 5)));
         }

      }
   }
}
