package vexbot.panel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundMapItemDataPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import vexbot.VexBot;
import vexbot.compat.McCompat;
import vexbot.i18n.VexText;
import vexbot.platform.Platform;

public final class ControlPanel {
   public static final String TAG = "VexBotPanel";
   private static final double SCAN_RANGE = (double)48.0F;
   private static final double VIEW_RANGE = (double)40.0F;
   private static final double POINT_RANGE = (double)24.0F;
   private static final int CLICK_GAP = 5;
   private static final int FULL_RESEND = 600;
   private static volatile List<PanelScreen> screens = List.of();
   private static final Map<UUID, Hover> HOVER = new HashMap();
   private static final Map<UUID, Viewer> VIEWERS = new HashMap();

   private ControlPanel() {
   }

   public static void init(Platform p) {
      p.addInputInterceptor(new Platform.InputInterceptor() {
         public boolean onEntityClick(ServerPlayer player, Entity target, boolean attack) {
            if (target instanceof ItemFrame f) {
               if (ControlPanel.holdsPanel(f)) {
                  return !attack || !player.isShiftKeyDown();
               }
            }

            return false;
         }

         public boolean onBlockClick(ServerPlayer player, BlockPos pos, boolean attack) {
            return ControlPanel.HOVER.containsKey(player.getUUID());
         }

         public void onSwing(ServerPlayer player) {
            if (ControlPanel.HOVER.containsKey(player.getUUID()) && !player.isShiftKeyDown()) {
               Viewer v = (Viewer)ControlPanel.VIEWERS.get(player.getUUID());
               if (v != null) {
                  int now = player.level().getServer().getTickCount();
                  if (now - v.lastClick >= 5) {
                     v.lastClick = now;
                     ++v.pendingClicks;
                  }
               }
            }
         }

         public boolean onHotbarChange(ServerPlayer player, int from, int to) {
            if (!ControlPanel.HOVER.containsKey(player.getUUID())) {
               return false;
            } else {
               Viewer v = (Viewer)ControlPanel.VIEWERS.get(player.getUUID());
               if (v != null) {
                  v.pendingScroll += (to - from + 9) % 9 <= 4 ? 1 : -1;
               }

               return true;
            }
         }
      });
      p.onEndServerTick(ControlPanel::tick);
   }

   public static ItemStack create(ServerLevel level, int count) {
      ItemStack stack = new ItemStack(Items.FILLED_MAP, Math.max(1, Math.min(64, count)));
      stack.set(DataComponents.MAP_ID, level.getFreeMapId());
      CompoundTag tag = new CompoundTag();
      tag.putBoolean("VexBotPanel", true);
      stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
      stack.set(DataComponents.CUSTOM_NAME, VexText.literal("§6VexBot Control Panel").setStyle(Style.EMPTY.withItalic(false)));
      stack.set(DataComponents.LORE, new ItemLore(List.of(VexText.literal("§7Put it in an item frame. Frames side by side").setStyle(Style.EMPTY.withItalic(false)), VexText.literal("§7on one wall join into a bigger screen.").setStyle(Style.EMPTY.withItalic(false)), VexText.literal("§7Aim to point, left-click to click,").setStyle(Style.EMPTY.withItalic(false)), VexText.literal("§7mouse wheel to scroll. Sneak-punch to take down.").setStyle(Style.EMPTY.withItalic(false)))));
      return stack;
   }

   public static boolean isPanel(ItemStack stack) {
      if (!stack.isEmpty() && stack.is(Items.FILLED_MAP)) {
         CustomData data = (CustomData)stack.get(DataComponents.CUSTOM_DATA);
         return data != null && data.copyTag().getBooleanOr("VexBotPanel", false);
      } else {
         return false;
      }
   }

   static boolean holdsPanel(ItemFrame f) {
      return isPanel(f.getItem());
   }

   static boolean isBot(ServerPlayer p) {
      return McCompat.tags(p).contains("vexbot");
   }

   private static void tick(MinecraftServer server) {
      int now = server.getTickCount();
      if (now % 20 == 0) {
         scan(server);
      }

      List<PanelScreen> all = screens;
      if (all.isEmpty()) {
         HOVER.clear();
         if (!VIEWERS.isEmpty()) {
            VIEWERS.clear();
         }

      } else {
         HOVER.clear();
         Set<UUID> online = new HashSet();

         for(ServerPlayer p : List.copyOf(server.getPlayerList().getPlayers())) {
            if (!isBot(p)) {
               List<PanelScreen> near = new ArrayList();

               for(PanelScreen s : all) {
                  if (s.level == p.level()) {
                     Vec3 eye = p.getEyePosition();
                     if (!(eye.distanceTo(s.center()) > (double)40.0F) && !(eye.subtract(s.origin).dot(s.normal) <= (double)0.0F)) {
                        near.add(s);
                     }
                  }
               }

               if (!near.isEmpty()) {
                  online.add(p.getUUID());
                  Viewer v = (Viewer)VIEWERS.computeIfAbsent(p.getUUID(), (k) -> new Viewer());
                  if (v.player != p || v.level != p.level() || now - v.fullAt >= 600) {
                     v.player = p;
                     v.level = p.level();
                     v.fullAt = now;
                     v.sent.clear();
                  }

                  Hover hover = null;
                  if (!p.isSpectator()) {
                     Vec3 eye = p.getEyePosition();
                     Vec3 look = p.getLookAngle();
                     double best = Double.MAX_VALUE;

                     for(PanelScreen s : near) {
                        double[] h = s.hit(eye, look, (double)24.0F);
                        if (h != null && !(h[2] >= best)) {
                           Vec3 at = eye.add(look.scale(h[2] - 0.05));
                           if (p.level().clip(new ClipContext(eye, at, Block.COLLIDER, Fluid.NONE, p)).getType() == Type.MISS) {
                              best = h[2];
                              hover = new Hover(s, h[0], h[1]);
                           }
                        }
                     }
                  }

                  if (hover != null) {
                     HOVER.put(p.getUUID(), hover);
                  }

                  int clicks = v.pendingClicks;
                  int scroll = v.pendingScroll;
                  v.pendingClicks = 0;
                  v.pendingScroll = 0;

                  for(PanelScreen s : near) {
                     PanelUi.Session ses = (PanelUi.Session)v.sessions.computeIfAbsent(s.key, (k) -> new PanelUi.Session());
                     boolean on = hover != null && hover.screen() == s;
                     PanelCanvas canvas = ses.canvas(s.cols, s.rows);
                     int cx = on ? (int)(hover.sx() * (double)128.0F / (double)canvas.scale) : -1;
                     int cy = on ? (int)(hover.sy() * (double)128.0F / (double)canvas.scale) : -1;
                     boolean dirty = cx != ses.cx || cy != ses.cy;
                     ses.cx = cx;
                     ses.cy = cy;
                     if (on && scroll != 0) {
                        ses.scroll(scroll);
                        dirty = true;
                     }

                     if (on && clicks > 0) {
                        ses.click(server, p);
                        dirty = true;
                     }

                     if (dirty || ses.due(now) || v.sent.isEmpty()) {
                        try {
                           PanelUi.render(ses, canvas, server, p, now);
                        } catch (RuntimeException ex) {
                           VexBot.LOGGER.warn("[VexBot] Control panel draw failed", ex);
                           ses.reset();
                           continue;
                        }

                        push(v, s, canvas);
                     }
                  }

                  v.sessions.keySet().removeIf((k) -> near.stream().noneMatch((s) -> s.key.equals(k)));
               }
            }
         }

         VIEWERS.keySet().retainAll(online);
      }
   }

   private static void scan(MinecraftServer server) {
      List<PanelScreen> out = new ArrayList();

      for(ServerLevel level : server.getAllLevels()) {
         Map<Integer, ItemFrame> frames = new HashMap();

         for(ServerPlayer p : level.players()) {
            if (!isBot(p)) {
               for(ItemFrame f : level.getEntitiesOfClass(ItemFrame.class, p.getBoundingBox().inflate((double)48.0F), ControlPanel::holdsPanel)) {
                  frames.put(f.getId(), f);
               }
            }
         }

         if (!frames.isEmpty()) {
            Map<Integer, ItemFrame> byMap = new HashMap();

            for(ItemFrame f : frames.values()) {
               ItemStack st = f.getItem();
               MapId id = (MapId)st.get(DataComponents.MAP_ID);
               if (id == null || byMap.containsKey(id.id())) {
                  id = level.getFreeMapId();
                  ItemStack copy = st.copy();
                  copy.set(DataComponents.MAP_ID, id);
                  f.setItem(copy, false);
               }

               byMap.put(id.id(), f);
               if (f.getRotation() != 0) {
                  f.setRotation(0);
               }
            }

            out.addAll(PanelScreen.group(level, frames.values()));
         }
      }

      screens = List.copyOf(out);
   }

   private static void push(Viewer v, PanelScreen s, PanelCanvas canvas) {
      for(int r = 0; r < s.rows; ++r) {
         for(int c = 0; c < s.cols; ++c) {
            MapId id = s.tiles[r * s.cols + c];
            if (id != null) {
               byte[] now = canvas.tile(c, r);
               byte[] was = (byte[])v.sent.get(id.id());
               int x0 = 0;
               int y0 = 0;
               int x1 = 127;
               int y1 = 127;
               if (was != null) {
                  x0 = Integer.MAX_VALUE;
                  y0 = Integer.MAX_VALUE;
                  x1 = -1;
                  y1 = -1;

                  for(int y = 0; y < 128; ++y) {
                     for(int x = 0; x < 128; ++x) {
                        int i = y * 128 + x;
                        if (now[i] != was[i]) {
                           if (x < x0) {
                              x0 = x;
                           }

                           if (x > x1) {
                              x1 = x;
                           }

                           if (y < y0) {
                              y0 = y;
                           }

                           if (y > y1) {
                              y1 = y;
                           }
                        }
                     }
                  }

                  if (x1 < 0) {
                     continue;
                  }
               }

               int w = x1 - x0 + 1;
               int h = y1 - y0 + 1;
               byte[] patch = new byte[w * h];

               for(int y = 0; y < h; ++y) {
                  System.arraycopy(now, (y0 + y) * 128 + x0, patch, y * w, w);
               }

               v.player.connection.send(new ClientboundMapItemDataPacket(id, (byte)0, true, Optional.empty(), Optional.of(new MapItemSavedData.MapPatch(x0, y0, w, h, patch))));
               v.sent.put(id.id(), now);
            }
         }
      }

   }

   static record Hover(PanelScreen screen, double sx, double sy) {
   }

   static final class Viewer {
      ServerPlayer player;
      ServerLevel level;
      int fullAt;
      final Map<Integer, byte[]> sent = new HashMap();
      final Map<String, PanelUi.Session> sessions = new HashMap();
      int lastClick = -100;
      int pendingClicks;
      int pendingScroll;
   }
}
