package vexbot.panel;

import java.util.Arrays;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.MapColor.Brightness;

final class PanelCanvas {
   static final int TILE = 128;
   static final byte BG;
   static final byte BG2;
   static final byte BTN;
   static final byte BTN_HOT;
   static final byte HEADER;
   static final byte TEXT;
   static final byte DIM;
   static final byte GOLD;
   static final byte GOLD_DK;
   static final byte GREEN;
   static final byte RED;
   static final byte RED_DK;
   static final byte CYAN;
   static final byte WHITE;
   static final byte DARK;
   final int cols;
   final int rows;
   final int scale;
   final int pw;
   final int ph;
   final int w;
   final int h;
   final byte[] px;
   private static final String[] POINTER;

   PanelCanvas(int cols, int rows) {
      this.cols = cols;
      this.rows = rows;
      this.pw = cols * 128;
      this.ph = rows * 128;
      this.scale = Math.max(1, (int)Math.round((double)Math.min(this.pw, this.ph) / (double)192.0F));
      this.w = this.pw / this.scale;
      this.h = this.ph / this.scale;
      this.px = new byte[this.pw * this.ph];
   }

   void clear(byte c) {
      Arrays.fill(this.px, c);
   }

   void fill(int x, int y, int fw, int fh, byte c) {
      int x0 = Math.max(0, x * this.scale);
      int y0 = Math.max(0, y * this.scale);
      int x1 = Math.min(this.pw, (x + fw) * this.scale);
      int y1 = Math.min(this.ph, (y + fh) * this.scale);

      for(int yy = y0; yy < y1; ++yy) {
         int row = yy * this.pw;

         for(int xx = x0; xx < x1; ++xx) {
            this.px[row + xx] = c;
         }
      }

   }

   void outline(int x, int y, int fw, int fh, byte c) {
      this.fill(x, y, fw, 1, c);
      this.fill(x, y + fh - 1, fw, 1, c);
      this.fill(x, y, 1, fh, c);
      this.fill(x + fw - 1, y, 1, fh, c);
   }

   int text(int x, int y, String s, byte c) {
      for(int i = 0; i < s.length(); ++i) {
         boolean[] g = PanelFont.glyph(s.charAt(i));

         for(int gy = 0; gy < 7; ++gy) {
            for(int gx = 0; gx < 5; ++gx) {
               if (g[gy * 5 + gx]) {
                  this.fill(x + gx, y + gy, 1, 1, c);
               }
            }
         }

         x += 6;
      }

      return x;
   }

   void textRight(int right, int y, String s, byte c) {
      this.text(right - PanelFont.width(s), y, s, c);
   }

   void textCenter(int x, int y, int fw, String s, byte c) {
      s = fit(s, fw - 2);
      this.text(x + (fw - PanelFont.width(s)) / 2, y, s, c);
   }

   static String fit(String s, int maxW) {
      int n = Math.max(0, (maxW + 1) / 6);
      if (s.length() <= n) {
         return s;
      } else {
         return n <= 1 ? s.substring(0, Math.max(0, n)) : s.substring(0, n - 1) + ".";
      }
   }

   void bar(int x, int y, int bw, int bh, double frac) {
      frac = Math.max((double)0.0F, Math.min((double)1.0F, frac));
      this.fill(x, y, bw, bh, DARK);
      byte c = frac > (double)0.5F ? GREEN : (frac > (double)0.25F ? GOLD : RED);
      this.fill(x, y, (int)Math.round((double)bw * frac), bh, c);
   }

   void pointer(int x, int y) {
      for(int py = 0; py < POINTER.length; ++py) {
         for(int pxx = 0; pxx < POINTER[py].length(); ++pxx) {
            char ch = POINTER[py].charAt(pxx);
            if (ch == '#') {
               this.fill(x + pxx, y + py, 1, 1, DARK);
            } else if (ch == 'o') {
               this.fill(x + pxx, y + py, 1, 1, WHITE);
            }
         }
      }

   }

   byte[] tile(int col, int row) {
      byte[] out = new byte[16384];

      for(int y = 0; y < 128; ++y) {
         System.arraycopy(this.px, (row * 128 + y) * this.pw + col * 128, out, y * 128, 128);
      }

      return out;
   }

   static {
      BG = MapColor.COLOR_BLUE.getPackedId(Brightness.LOWEST);
      BG2 = MapColor.COLOR_BLUE.getPackedId(Brightness.LOW);
      BTN = MapColor.COLOR_BLUE.getPackedId(Brightness.NORMAL);
      BTN_HOT = MapColor.LAPIS.getPackedId(Brightness.HIGH);
      HEADER = MapColor.COLOR_BLACK.getPackedId(Brightness.HIGH);
      TEXT = MapColor.QUARTZ.getPackedId(Brightness.HIGH);
      DIM = MapColor.COLOR_LIGHT_GRAY.getPackedId(Brightness.HIGH);
      GOLD = MapColor.GOLD.getPackedId(Brightness.HIGH);
      GOLD_DK = MapColor.GOLD.getPackedId(Brightness.LOW);
      GREEN = MapColor.EMERALD.getPackedId(Brightness.HIGH);
      RED = MapColor.FIRE.getPackedId(Brightness.NORMAL);
      RED_DK = MapColor.COLOR_RED.getPackedId(Brightness.NORMAL);
      CYAN = MapColor.DIAMOND.getPackedId(Brightness.HIGH);
      WHITE = MapColor.SNOW.getPackedId(Brightness.HIGH);
      DARK = MapColor.COLOR_BLACK.getPackedId(Brightness.LOWEST);
      POINTER = new String[]{"#.......", "##......", "#o#.....", "#oo#....", "#ooo#...", "#oooo#..", "#ooooo#.", "#oooooo#", "#ooo####", "#o#o#...", "##.#o#..", "....##.."};
   }
}
