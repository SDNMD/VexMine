package vexbot.panel;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.phys.Vec3;

final class PanelScreen {
   static final int MAX_SIDE = 8;
   private static final double SURFACE = (double)0.0625F;
   final ServerLevel level;
   final Direction facing;
   final Vec3 normal;
   final Vec3 right;
   final Vec3 down;
   final Vec3 origin;
   final int cols;
   final int rows;
   final MapId[] tiles;
   final Set<Integer> frameIds = new HashSet();
   final String key;

   private PanelScreen(ServerLevel level, Direction facing, Vec3 origin, int cols, int rows, MapId[] tiles, String key) {
      this.level = level;
      this.facing = facing;
      this.normal = vec(facing);
      this.right = rightOf(facing);
      this.down = downOf(facing);
      this.origin = origin;
      this.cols = cols;
      this.rows = rows;
      this.tiles = tiles;
      this.key = key;
   }

   Vec3 center() {
      return this.origin.add(this.right.scale((double)this.cols / (double)2.0F)).add(this.down.scale((double)this.rows / (double)2.0F));
   }

   private static Vec3 vec(Direction d) {
      return new Vec3((double)d.getStepX(), (double)d.getStepY(), (double)d.getStepZ());
   }

   static Vec3 rightOf(Direction d) {
      return d.getAxis().isHorizontal() ? vec(d.getCounterClockWise()) : new Vec3((double)1.0F, (double)0.0F, (double)0.0F);
   }

   static Vec3 downOf(Direction d) {
      Vec3 var10000;
      switch (d) {
         case UP -> var10000 = new Vec3((double)0.0F, (double)0.0F, (double)1.0F);
         case DOWN -> var10000 = new Vec3((double)0.0F, (double)0.0F, (double)-1.0F);
         default -> var10000 = new Vec3((double)0.0F, (double)-1.0F, (double)0.0F);
      }

      return var10000;
   }

   private static int dot(BlockPos p, Vec3 v) {
      return (int)Math.round((double)p.getX() * v.x + (double)p.getY() * v.y + (double)p.getZ() * v.z);
   }

   static List<PanelScreen> group(ServerLevel level, Iterable<ItemFrame> frames) {
      Map<String, Map<Long, ItemFrame>> planes = new HashMap();

      for(ItemFrame f : frames) {
         Direction d = f.getDirection();
         BlockPos bp = BlockPos.containing(f.position());
         String var10000 = d.getName();
         String plane = var10000 + "@" + dot(bp, vec(d));
         int col = dot(bp, rightOf(d));
         int row = dot(bp, downOf(d));
         ((Map)planes.computeIfAbsent(plane, (k) -> new HashMap())).put(cell(col, row), f);
      }

      List<PanelScreen> out = new ArrayList();

      for(Map.Entry<String, Map<Long, ItemFrame>> e : planes.entrySet()) {
         Map<Long, ItemFrame> cells = (Map)e.getValue();
         Set<Long> seen = new HashSet();

         for(Long start : cells.keySet()) {
            if (seen.add(start)) {
               List<Long> comp = new ArrayList();
               ArrayDeque<Long> q = new ArrayDeque();
               q.add(start);

               while(!q.isEmpty()) {
                  long c = (Long)q.poll();
                  comp.add(c);
                  int cc = col(c);
                  int rr = row(c);

                  for(long n : new long[]{cell(cc + 1, rr), cell(cc - 1, rr), cell(cc, rr + 1), cell(cc, rr - 1)}) {
                     if (cells.containsKey(n) && seen.add(n)) {
                        q.add(n);
                     }
                  }
               }

               out.add(build(level, (String)e.getKey(), cells, comp));
            }
         }
      }

      return out;
   }

   private static PanelScreen build(ServerLevel level, String plane, Map<Long, ItemFrame> cells, List<Long> comp) {
      int minC = Integer.MAX_VALUE;
      int minR = Integer.MAX_VALUE;
      int maxC = Integer.MIN_VALUE;
      int maxR = Integer.MIN_VALUE;

      for(long c : comp) {
         minC = Math.min(minC, col(c));
         maxC = Math.max(maxC, col(c));
         minR = Math.min(minR, row(c));
         maxR = Math.max(maxR, row(c));
      }

      int cols = Math.min(8, maxC - minC + 1);
      int rows = Math.min(8, maxR - minR + 1);
      ItemFrame any = (ItemFrame)cells.get(comp.get(0));
      Direction d = any.getDirection();
      Vec3 n = vec(d);
      Vec3 r = rightOf(d);
      Vec3 dn = downOf(d);
      BlockPos bp0 = BlockPos.containing(any.position());
      int c0 = dot(bp0, r);
      int r0 = dot(bp0, dn);
      Vec3 centre0 = Vec3.atCenterOf(bp0).subtract(n.scale((double)0.4375F));
      Vec3 origin = centre0.add(r.scale((double)(minC - c0) - (double)0.5F)).add(dn.scale((double)(minR - r0) - (double)0.5F));
      MapId[] tiles = new MapId[cols * rows];
      PanelScreen s = new PanelScreen(level, d, origin, cols, rows, tiles, String.valueOf(level.dimension()) + "|" + plane + "|" + minC + "," + minR + "|" + cols + "x" + rows);

      for(long c : comp) {
         int tc = col(c) - minC;
         int tr = row(c) - minR;
         if (tc < cols && tr < rows) {
            ItemFrame f = (ItemFrame)cells.get(c);
            tiles[tr * cols + tc] = (MapId)f.getItem().get(DataComponents.MAP_ID);
            s.frameIds.add(f.getId());
         }
      }

      return s;
   }

   double[] hit(Vec3 eye, Vec3 look, double maxDist) {
      double denom = look.dot(this.normal);
      if (denom > -1.0E-4) {
         return null;
      } else {
         double t = this.origin.subtract(eye).dot(this.normal) / denom;
         if (!(t <= (double)0.0F) && !(t > maxDist)) {
            Vec3 h = eye.add(look.scale(t)).subtract(this.origin);
            double sx = h.dot(this.right);
            double sy = h.dot(this.down);
            if (!(sx < (double)0.0F) && !(sy < (double)0.0F) && !(sx >= (double)this.cols) && !(sy >= (double)this.rows)) {
               return this.tiles[(int)sy * this.cols + (int)sx] == null ? null : new double[]{sx, sy, t};
            } else {
               return null;
            }
         } else {
            return null;
         }
      }
   }

   private static long cell(int col, int row) {
      return (long)col << 32 | (long)row & 4294967295L;
   }

   private static int col(long c) {
      return (int)(c >> 32);
   }

   private static int row(long c) {
      return (int)c;
   }
}
