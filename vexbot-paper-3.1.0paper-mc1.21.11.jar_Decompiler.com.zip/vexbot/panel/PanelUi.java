package vexbot.panel;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.BotSettings;
import vexbot.DifficultyKnobs;
import vexbot.SettingsPersistence;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.settings.GameplaySettingsScope;
import vexbot.settings.SettingsCli;
import vexbot.team.TeamManager;

final class PanelUi {
   private static final Page[] NAV;
   private static final String[] NAV_LABEL;
   private static final String[] PRESETS;
   private static final String[] PRESET_SHORT;
   private static final String[] PRESET_MID;

   private PanelUi() {
   }

   static void render(Session s, PanelCanvas c, MinecraftServer server, ServerPlayer viewer, int now) {
      s.drawnAt = now;
      s.btns.clear();
      c.clear(PanelCanvas.BG);
      int w = c.w;
      int h = c.h;
      boolean side = w >= 230;
      c.fill(0, 0, w, 11, PanelCanvas.HEADER);
      int tx = 3;
      if (s.page != PanelUi.Page.HOME) {
         byte var10007 = PanelCanvas.BTN;
         byte var10008 = PanelCanvas.TEXT;
         Objects.requireNonNull(s);
         button(s, c, 1, 1, 11, 9, "<", var10007, var10008, s::back);
         tx = 15;
      }

      tx = c.text(tx, 2, "VEXBOT", PanelCanvas.GOLD);
      String count = BotManager.getBotNames().size() + " BOTS";
      int countW = w >= 150 ? PanelFont.width(count) + 6 : 0;
      if (countW > 0) {
         c.textRight(w - 3, 2, count, PanelCanvas.DIM);
      }

      c.text(tx + 6, 2, PanelCanvas.fit(title(s), w - tx - 9 - countW), PanelCanvas.TEXT);
      boolean status = s.status != null && now < s.statusUntil;
      if (!status) {
         s.status = null;
      }

      int x0 = 3;
      int y0 = 14;
      int x1 = w - 3;
      int y1 = h - (status ? 13 : 3);
      if (side) {
         sidebar(s, c, 11, h - (status ? 11 : 0));
         x0 = 68;
      }

      switch (s.page.ordinal()) {
         case 0 -> home(s, c, server, x0, y0, x1, y1, side);
         case 1 -> bots(s, c, server, viewer, x0, y0, x1, y1);
         case 2 -> bot(s, c, server, viewer, x0, y0, x1, y1);
         case 3 -> teams(s, c, x0, y0, x1, y1);
         case 4 -> team(s, c, server, viewer, x0, y0, x1, y1);
         case 5 -> difficulty(s, c, server, viewer, x0, y0, x1, y1);
         case 6 -> settings(s, c, server, x0, y0, x1, y1);
         case 7 -> fights(s, c, server, viewer, x0, y0, x1, y1);
      }

      if (status) {
         c.fill(0, h - 11, w, 11, PanelCanvas.HEADER);
         c.text(3, h - 9, PanelCanvas.fit(s.status, w - 6), s.statusColor);
      }

      if (s.cx >= 0) {
         c.pointer(s.cx, s.cy);
      }

   }

   private static String title(Session s) {
      String var10000;
      switch (s.page.ordinal()) {
         case 0 -> var10000 = "CONTROL PANEL";
         case 1 -> var10000 = "BOTS";
         case 2 -> var10000 = s.bot == null ? "BOT" : s.bot;
         case 3 -> var10000 = "TEAMS";
         case 4 -> var10000 = s.team == null ? "TEAM" : s.team;
         case 5 -> var10000 = "DIFFICULTY";
         case 6 -> var10000 = "SETTINGS";
         case 7 -> var10000 = "LIVE FIGHTS";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private static void sidebar(Session s, PanelCanvas c, int top, int bottom) {
      c.fill(0, top, 64, bottom - top, PanelCanvas.BG2);
      int y = top + 3;

      for(int i = 0; i < NAV.length; ++i) {
         Page p = NAV[i];
         boolean on = s.page == p || p == PanelUi.Page.BOTS && s.page == PanelUi.Page.BOT || p == PanelUi.Page.TEAMS && s.page == PanelUi.Page.TEAM;
         button(s, c, 2, y, 60, 12, NAV_LABEL[i], on ? PanelCanvas.GOLD : PanelCanvas.BTN, on ? PanelCanvas.HEADER : PanelCanvas.TEXT, () -> s.go(p));
         y += 14;
      }

   }

   private static void home(Session s, PanelCanvas c, MinecraftServer server, int x0, int y0, int x1, int y1, boolean side) {
      int fighting = 0;

      for(String b : BotManager.getBotNames()) {
         if (BotManager.getAttackTarget(b) != null) {
            ++fighting;
         }
      }

      int var16 = stat(c, x0, x1, y0, "BOTS ONLINE", String.valueOf(BotManager.getBotNames().size()), PanelCanvas.TEXT);
      var16 = stat(c, x0, x1, var16, "TEAMS", String.valueOf(TeamManager.teamNames().size()), PanelCanvas.TEXT);
      var16 = stat(c, x0, x1, var16, "FIGHTING", String.valueOf(fighting), fighting > 0 ? PanelCanvas.RED : PanelCanvas.TEXT);
      var16 = stat(c, x0, x1, var16, "DIFFICULTY", BotSettings.difficulty.name(), PanelCanvas.GOLD);
      var16 += 4;
      if (!side) {
         int bw = (x1 - x0 - 2) / 2;
         int bh = 13;
         Page[] grid = new Page[]{PanelUi.Page.BOTS, PanelUi.Page.TEAMS, PanelUi.Page.DIFFICULTY, PanelUi.Page.SETTINGS};
         String[] label = new String[]{"BOTS", "TEAMS", "DIFFICULTY", "SETTINGS"};

         for(int i = 0; i < grid.length; ++i) {
            Page p = grid[i];
            button(s, c, x0 + i % 2 * (bw + 2), var16 + i / 2 * (bh + 2), bw, bh, label[i], PanelCanvas.BTN, PanelCanvas.TEXT, () -> s.go(p));
         }

         var16 += 2 * (bh + 2);
         if (var16 + bh <= y1) {
            button(s, c, x0, var16, x1 - x0, bh, "LIVE FIGHTS", PanelCanvas.BTN, PanelCanvas.TEXT, () -> s.go(PanelUi.Page.FIGHT));
         }
      } else {
         String[] tips = new String[]{"AIM AT THE SCREEN TO POINT", "LEFT-CLICK TO CLICK", "MOUSE WHEEL TO SCROLL", "SNEAK-PUNCH TO TAKE IT DOWN", "MORE FRAMES = BIGGER SCREEN"};
         var16 += 4;

         for(String t : tips) {
            if (var16 + 7 > y1) {
               break;
            }

            c.text(x0, var16, PanelCanvas.fit(t, x1 - x0), PanelCanvas.DIM);
            var16 += 9;
         }
      }

   }

   private static int stat(PanelCanvas c, int x0, int x1, int y, String label, String value, byte color) {
      c.text(x0, y, PanelCanvas.fit(label, x1 - x0 - PanelFont.width(value) - 6), PanelCanvas.DIM);
      c.textRight(x1, y, value, color);
      return y + 9;
   }

   private static List<String> botNames() {
      List<String> names = new ArrayList(BotManager.getBotNames());
      names.sort(String.CASE_INSENSITIVE_ORDER);
      return names;
   }

   private static void bots(Session s, PanelCanvas c, MinecraftServer server, ServerPlayer viewer, int x0, int y0, int x1, int y1) {
      button(s, c, x0, y0, 52, 11, "+ SPAWN", PanelCanvas.BTN, PanelCanvas.GREEN, () -> cmd(s, server, viewer, String.format(Locale.ROOT, "vexbot spawn %.2f %.2f %.2f", viewer.getX(), viewer.getY(), viewer.getZ()), "Spawned a bot next to you"));
      List<String> names = botNames();
      c.textRight(x1, y0 + 2, names.size() + " ONLINE", PanelCanvas.DIM);
      if (names.isEmpty()) {
         c.text(x0, y0 + 18, PanelCanvas.fit("NO BOTS YET.", x1 - x0), PanelCanvas.DIM);
         c.text(x0, y0 + 27, PanelCanvas.fit("CLICK + SPAWN.", x1 - x0), PanelCanvas.DIM);
         s.scrollMax = 0;
      } else {
         list(s, c, x0, y0 + 14, x1, y1, names.size(), 10, (i, x, y, rw, hot) -> {
            String name = (String)names.get(i);
            boolean fighting = BotManager.getAttackTarget(name) != null;
            c.text(x, y, PanelCanvas.fit(name, rw - 34), hot ? PanelCanvas.WHITE : PanelCanvas.TEXT);
            if (fighting) {
               c.text(x + rw - 32, y, "!", PanelCanvas.RED);
            }

            ServerPlayer b = server.getPlayerList().getPlayerByName(name);
            if (b != null) {
               c.bar(x + rw - 24, y + 2, 24, 3, (double)(b.getHealth() / b.getMaxHealth()));
            }

         }, (i) -> {
            s.bot = (String)names.get(i);
            s.go(PanelUi.Page.BOT);
         });
      }
   }

   private static void bot(Session s, PanelCanvas c, MinecraftServer server, ServerPlayer viewer, int x0, int y0, int x1, int y1) {
      ServerPlayer b = s.bot == null ? null : server.getPlayerList().getPlayerByName(s.bot);
      if (b != null && BotManager.getBotNames().contains(s.bot)) {
         String name = s.bot;
         c.text(x0, y0, PanelCanvas.fit(name, x1 - x0), PanelCanvas.GOLD);
         int y = y0 + 10;
         c.bar(x0, y, x1 - x0, 4, (double)(b.getHealth() / b.getMaxHealth()));
         y += 6;
         int var10005 = Math.round(b.getHealth());
         y = stat(c, x0, x1, y, "HEALTH", var10005 + "/" + Math.round(b.getMaxHealth()), PanelCanvas.TEXT);
         TeamManager.BotTeam t = TeamManager.getTeamForBot(name);
         y = stat(c, x0, x1, y, "TEAM", t == null ? "NONE" : t.getName(), PanelCanvas.TEXT);
         String target = BotManager.getAttackTarget(name);
         y = stat(c, x0, x1, y, "TARGET", target == null ? "NONE" : target, target == null ? PanelCanvas.TEXT : PanelCanvas.RED);
         String follow = BotManager.getFollowTarget(name);
         y = stat(c, x0, x1, y, "FOLLOWING", follow == null ? "NOBODY" : follow, PanelCanvas.TEXT);
         y += 3;
         String me = viewer.getName().getString();
         int bw = (x1 - x0 - 2) / 2;
         int bh = 12;
         button(s, c, x0, y, bw, bh, "ATTACK ME", PanelCanvas.BTN, PanelCanvas.TEXT, () -> cmd(s, server, viewer, "vexbot attack " + me + " " + name, name + " is coming for you"));
         button(s, c, x0 + bw + 2, y, bw, bh, "STOP", PanelCanvas.BTN, PanelCanvas.TEXT, () -> cmd(s, server, viewer, "vexbot attack stop " + name, name + " stopped attacking"));
         y += bh + 2;
         button(s, c, x0, y, bw, bh, "FOLLOW ME", PanelCanvas.BTN, PanelCanvas.TEXT, () -> cmd(s, server, viewer, "vexbot follow " + name + " " + me, name + " follows you"));
         button(s, c, x0 + bw + 2, y, bw, bh, "UNFOLLOW", PanelCanvas.BTN, PanelCanvas.TEXT, () -> cmd(s, server, viewer, "vexbot follow " + name + " stop", name + " stopped following"));
         y += bh + 2;
         if (y + bh <= y1 + 2) {
            button(s, c, x0, y, x1 - x0, bh, "KILL", PanelCanvas.RED_DK, PanelCanvas.TEXT, () -> {
               cmd(s, server, viewer, "vexbot kill " + name, "Killed " + name);
               s.go(PanelUi.Page.BOTS);
            });
         }

      } else {
         c.text(x0, y0, PanelCanvas.fit("NOT ONLINE ANY MORE.", x1 - x0), PanelCanvas.DIM);
         int var10003 = y0 + 12;
         int var10004 = Math.min(60, x1 - x0);
         byte var10007 = PanelCanvas.BTN;
         byte var10008 = PanelCanvas.TEXT;
         Objects.requireNonNull(s);
         button(s, c, x0, var10003, var10004, 12, "BACK", var10007, var10008, s::back);
      }
   }

   private static void teams(Session s, PanelCanvas c, int x0, int y0, int x1, int y1) {
      List<String> names = new ArrayList(TeamManager.teamNames());
      names.sort(String.CASE_INSENSITIVE_ORDER);
      if (names.isEmpty()) {
         c.text(x0, y0, PanelCanvas.fit("NO TEAMS YET.", x1 - x0), PanelCanvas.DIM);
         c.text(x0, y0 + 9, PanelCanvas.fit("/VEXBOT TEAM CREATE", x1 - x0), PanelCanvas.DIM);
         s.scrollMax = 0;
      } else {
         list(s, c, x0, y0, x1, y1, names.size(), 10, (i, x, y, rw, hot) -> {
            TeamManager.BotTeam t = TeamManager.get((String)names.get(i));
            String info = t == null ? "" : t.getBotNames().size() + "B " + t.getPlayerNames().size() + "P";
            c.text(x, y, PanelCanvas.fit((String)names.get(i), rw - PanelFont.width(info) - 4), hot ? PanelCanvas.WHITE : PanelCanvas.TEXT);
            c.textRight(x + rw, y, info, PanelCanvas.DIM);
         }, (i) -> {
            s.team = (String)names.get(i);
            s.go(PanelUi.Page.TEAM);
         });
      }
   }

   private static int presetRow(Session s, PanelCanvas c, int x0, int y, int x1, BotSettings.Difficulty current, Consumer<String> pick) {
      int bw = (x1 - x0 - 8) / 5;
      String[] labels = bw >= 30 ? PRESET_MID : PRESET_SHORT;

      for(int i = 0; i < 5; ++i) {
         String p = PRESETS[i];
         boolean on = current != null && current.name().equalsIgnoreCase(p);
         button(s, c, x0 + i * (bw + 2), y, bw, 11, labels[i], on ? PanelCanvas.GOLD : PanelCanvas.BTN, on ? PanelCanvas.HEADER : PanelCanvas.TEXT, () -> pick.accept(p));
      }

      return y + 13;
   }

   private static void team(Session s, PanelCanvas c, MinecraftServer server, ServerPlayer viewer, int x0, int y0, int x1, int y1) {
      TeamManager.BotTeam t = s.team == null ? null : TeamManager.get(s.team);
      if (t == null) {
         c.text(x0, y0, PanelCanvas.fit("THIS TEAM IS GONE.", x1 - x0), PanelCanvas.DIM);
         int var10003 = y0 + 12;
         int var10004 = Math.min(60, x1 - x0);
         byte var10007 = PanelCanvas.BTN;
         byte var10008 = PanelCanvas.TEXT;
         Objects.requireNonNull(s);
         button(s, c, x0, var10003, var10004, 12, "BACK", var10007, var10008, s::back);
      } else {
         String name = t.getName();
         String info = t.getBotNames().size() + " BOTS";
         c.text(x0, y0, PanelCanvas.fit(name, x1 - x0 - PanelFont.width(info) - 4), PanelCanvas.GOLD);
         c.textRight(x1, y0, info, PanelCanvas.DIM);
         int y = y0 + 10;
         c.text(x0, y, "DIFFICULTY", PanelCanvas.DIM);
         y += 8;
         y = presetRow(s, c, x0, y, x1, t.difficulty, (p) -> cmd(s, server, viewer, "vexbot teamdifficulty " + name + " preset " + p, name + " difficulty: " + p));
         c.text(x0, y, "PLAYSTYLE", PanelCanvas.DIM);
         y += 8;
         String[] styles = new String[]{"default", "safe", "aggressive"};
         String[] labels = new String[]{"DEFAULT", "SAFE", "AGGRO"};
         int bw = (x1 - x0 - 4) / 3;

         for(int i = 0; i < 3; ++i) {
            String st = styles[i];
            button(s, c, x0 + i * (bw + 2), y, bw, 11, labels[i], PanelCanvas.BTN, PanelCanvas.TEXT, () -> cmd(s, server, viewer, "vexbot teamplaystyle " + name + " " + st, name + " playstyle: " + st));
         }

         y += 14;
         List<String> members = new ArrayList(t.getBotNames());
         members.sort(String.CASE_INSENSITIVE_ORDER);
         if (members.isEmpty()) {
            c.text(x0, y, PanelCanvas.fit("NO BOTS ON THIS TEAM.", x1 - x0), PanelCanvas.DIM);
            s.scrollMax = 0;
         } else {
            list(s, c, x0, y, x1, y1, members.size(), 10, (ix, x, yy, rw, hot) -> {
               String m = (String)members.get(ix);
               c.text(x, yy, PanelCanvas.fit(m, rw - 28), PanelCanvas.TEXT);
               ServerPlayer b = server.getPlayerList().getPlayerByName(m);
               if (b != null) {
                  c.bar(x + rw - 24, yy + 2, 24, 3, (double)(b.getHealth() / b.getMaxHealth()));
               } else {
                  c.textRight(x + rw, yy, "OFF", PanelCanvas.DIM);
               }

            }, (IntConsumer)null);
         }
      }
   }

   private static void difficulty(Session s, PanelCanvas c, MinecraftServer server, ServerPlayer viewer, int x0, int y0, int x1, int y1) {
      int y = presetRow(s, c, x0, y0, x1, BotSettings.difficulty, (p) -> cmd(s, server, viewer, "vexbot difficulty preset " + p, "Global difficulty: " + p));
      List<DifficultyKnobs.Knob> knobs = DifficultyKnobs.ALL;
      list(s, c, x0, y, x1, y1, knobs.size(), 11, (i, x, yy, rw, hot) -> {
         DifficultyKnobs.Knob k = (DifficultyKnobs.Knob)knobs.get(i);
         int valW = rw >= 150 ? 66 : 36;
         String val = PanelCanvas.fit(k.shown(BotSettings.difficultyParams).toUpperCase(Locale.ROOT), valW);
         c.text(x, yy + 1, PanelCanvas.fit(k.label().toUpperCase(Locale.ROOT), rw - 24 - valW), PanelCanvas.TEXT);
         c.textRight(x + rw - 22, yy + 1, val, PanelCanvas.GOLD);
         button(s, c, x + rw - 20, yy, 9, 9, "-", PanelCanvas.BTN, PanelCanvas.TEXT, () -> knob(s, server, k, false));
         button(s, c, x + rw - 10, yy, 9, 9, "+", PanelCanvas.BTN, PanelCanvas.TEXT, () -> knob(s, server, k, true));
      }, (IntConsumer)null);
   }

   private static void knob(Session s, MinecraftServer server, DifficultyKnobs.Knob k, boolean up) {
      String r = DifficultyKnobs.step(BotSettings.difficultyParams, k, up, false);
      SettingsPersistence.save(server);
      s.say(k.label() + ": " + (r == null ? "?" : r), PanelCanvas.GREEN);
   }

   private static void settings(Session s, PanelCanvas c, MinecraftServer server, int x0, int y0, int x1, int y1) {
      GameplaySettingsScope scope = GameplaySettingsScope.global();
      List<SettingsCli.Entry> entries = SettingsCli.entries(scope);
      list(s, c, x0, y0, x1, y1, entries.size(), 10, (i, x, y, rw, hot) -> {
         SettingsCli.Entry e = (SettingsCli.Entry)entries.get(i);
         String v = e.value() == null ? "" : e.value().toUpperCase(Locale.ROOT);
         byte col = !v.equals("ON") && !v.equals("TRUE") ? (!v.equals("OFF") && !v.equals("FALSE") ? PanelCanvas.GOLD : PanelCanvas.RED) : PanelCanvas.GREEN;
         v = PanelCanvas.fit(v, Math.min(48, rw / 2));
         c.text(x, y, PanelCanvas.fit(e.key().toUpperCase(Locale.ROOT), rw - PanelFont.width(v) - 4), hot ? PanelCanvas.WHITE : PanelCanvas.TEXT);
         c.textRight(x + rw, y, v, col);
      }, (i) -> {
         SettingsCli.Entry e = (SettingsCli.Entry)entries.get(i);
         String err = SettingsCli.click(scope, e.key(), true, false);
         if (err != null) {
            s.say(err, PanelCanvas.RED);
         } else {
            scope.persist(server);
            s.say(e.key() + ": " + SettingsCli.currentValue(scope, e.key()), PanelCanvas.GREEN);
         }
      });
   }

   private static void fights(Session s, PanelCanvas c, MinecraftServer server, ServerPlayer viewer, int x0, int y0, int x1, int y1) {
      List<String[]> fights = new ArrayList();

      for(String b : botNames()) {
         String t = BotManager.getAttackTarget(b);
         if (t != null) {
            fights.add(new String[]{b, t});
         }
      }

      int lx = x0;
      if (x1 - x0 >= 200 && y1 - y0 >= 90) {
         int size = Math.min(y1 - y0, (x1 - x0) / 2);
         radar(c, server, viewer, x0, y0, size);
         lx = x0 + size + 4;
      }

      if (fights.isEmpty()) {
         c.text(lx, y0, PanelCanvas.fit("NO FIGHTS RIGHT NOW.", x1 - lx), PanelCanvas.DIM);
         s.scrollMax = 0;
      } else {
         list(s, c, lx, y0, x1, y1, fights.size(), 14, (i, x, y, rw, hot) -> {
            String[] f = (String[])fights.get(i);
            int half = (rw - 8) / 2;
            c.text(x, y, PanelCanvas.fit(f[0], half), PanelCanvas.TEXT);
            c.text(x + half + 1, y, ">", PanelCanvas.RED);
            c.text(x + half + 8, y, PanelCanvas.fit(f[1], half), PanelCanvas.TEXT);
            ServerPlayer a = server.getPlayerList().getPlayerByName(f[0]);
            ServerPlayer b = server.getPlayerList().getPlayerByName(f[1]);
            if (a != null) {
               c.bar(x, y + 9, half, 3, (double)(a.getHealth() / a.getMaxHealth()));
            }

            if (b != null) {
               c.bar(x + half + 8, y + 9, half, 3, (double)(b.getHealth() / b.getMaxHealth()));
            }

         }, (IntConsumer)null);
      }
   }

   private static void radar(PanelCanvas c, MinecraftServer server, ServerPlayer viewer, int x, int y, int size) {
      c.fill(x, y, size, size, PanelCanvas.DARK);
      c.outline(x, y, size, size, PanelCanvas.BG2);
      c.fill(x + size / 2, y + 1, 1, size - 2, PanelCanvas.BG2);
      c.fill(x + 1, y + size / 2, size - 2, 1, PanelCanvas.BG2);
      c.text(x + size / 2 - 2, y + 2, "N", PanelCanvas.DIM);
      double range = (double)32.0F;
      double k = (double)(size - 4) / ((double)2.0F * range);

      for(ServerPlayer p : viewer.level().players()) {
         double dx = p.getX() - viewer.getX();
         double dz = p.getZ() - viewer.getZ();
         if (!(Math.abs(dx) > range) && !(Math.abs(dz) > range)) {
            int px = x + size / 2 + (int)Math.round(dx * k);
            int pz = y + size / 2 + (int)Math.round(dz * k);
            byte col;
            if (p == viewer) {
               col = PanelCanvas.GOLD;
            } else if (ControlPanel.isBot(p)) {
               col = BotManager.getAttackTarget(p.getName().getString()) != null ? PanelCanvas.RED : PanelCanvas.CYAN;
            } else {
               col = PanelCanvas.WHITE;
            }

            c.fill(Math.max(x + 1, px - 1), Math.max(y + 1, pz - 1), 3, 3, col);
         }
      }

   }

   private static void button(Session s, PanelCanvas c, int x, int y, int bw, int bh, String label, byte bg, byte fg, Runnable run) {
      boolean hot = s.cx >= x && s.cx < x + bw && s.cy >= y && s.cy < y + bh;
      c.fill(x, y, bw, bh, hot ? PanelCanvas.BTN_HOT : bg);
      c.textCenter(x, y + (bh - 7) / 2, bw, label, hot ? PanelCanvas.WHITE : fg);
      s.btns.add(new Btn(x, y, bw, bh, run));
   }

   private static void list(Session s, PanelCanvas c, int x0, int y0, int x1, int y1, int n, int rowH, RowDraw draw, IntConsumer onClick) {
      int visible = Math.max(1, (y1 - y0) / rowH);
      s.scrollMax = Math.max(0, n - visible);
      int sc = Math.max(0, Math.min(s.scrollMax, (Integer)s.scrolls.getOrDefault(s.page, 0)));
      s.scrolls.put(s.page, sc);
      int lw = x1 - x0 - (s.scrollMax > 0 ? 5 : 0);

      for(int k = 0; k < visible && sc + k < n; ++k) {
         int i = sc + k;
         int y = y0 + k * rowH;
         boolean hot = onClick != null && s.cx >= x0 && s.cx < x0 + lw && s.cy >= y && s.cy < y + rowH - 1;
         c.fill(x0, y, lw, rowH - 1, hot ? PanelCanvas.BTN_HOT : (k % 2 == 0 ? PanelCanvas.BG2 : PanelCanvas.BG));
         if (onClick != null) {
            s.btns.add(new Btn(x0, y, lw, rowH - 1, () -> onClick.accept(i)));
         }

         draw.draw(i, x0 + 2, y + 1, lw - 4, hot);
      }

      if (s.scrollMax > 0) {
         int track = y1 - y0;
         c.fill(x1 - 3, y0, 3, track, PanelCanvas.DARK);
         int th = Math.max(4, track * visible / n);
         int ty = y0 + (track - th) * sc / s.scrollMax;
         c.fill(x1 - 3, ty, 3, th, PanelCanvas.DIM);
      }

   }

   private static void cmd(Session s, MinecraftServer server, ServerPlayer viewer, String command, String done) {
      CommandSourceStack src = server.createCommandSourceStack().withSuppressedOutput().withLevel(viewer.level()).withPosition(viewer.position());

      int r;
      try {
         r = server.getCommands().getDispatcher().execute(command, src);
      } catch (CommandSyntaxException e) {
         s.say(e.getRawMessage().getString(), PanelCanvas.RED);
         return;
      } catch (RuntimeException e) {
         VexBot.LOGGER.warn("[VexBot] Control panel command failed: {}", command, e);
         s.say("That didn't work", PanelCanvas.RED);
         return;
      }

      s.say(r > 0 ? done : "Nothing changed", r > 0 ? PanelCanvas.GREEN : PanelCanvas.GOLD);
   }

   static {
      NAV = new Page[]{PanelUi.Page.HOME, PanelUi.Page.BOTS, PanelUi.Page.TEAMS, PanelUi.Page.DIFFICULTY, PanelUi.Page.SETTINGS, PanelUi.Page.FIGHT};
      NAV_LABEL = new String[]{"HOME", "BOTS", "TEAMS", "DIFFICULTY", "SETTINGS", "FIGHTS"};
      PRESETS = new String[]{"easy", "medium", "hard", "expert", "perfect"};
      PRESET_SHORT = new String[]{"E", "M", "H", "X", "P"};
      PRESET_MID = new String[]{"EASY", "MED", "HARD", "EXP", "PERF"};
   }

   static enum Page {
      HOME,
      BOTS,
      BOT,
      TEAMS,
      TEAM,
      DIFFICULTY,
      SETTINGS,
      FIGHT;

      // $FF: synthetic method
      private static Page[] $values() {
         return new Page[]{HOME, BOTS, BOT, TEAMS, TEAM, DIFFICULTY, SETTINGS, FIGHT};
      }
   }

   private static record Btn(int x, int y, int w, int h, Runnable run) {
      boolean has(int px, int py) {
         return px >= this.x && px < this.x + this.w && py >= this.y && py < this.y + this.h;
      }
   }

   static final class Session {
      Page page;
      String bot;
      String team;
      final Map<Page, Integer> scrolls;
      int scrollMax;
      int cx;
      int cy;
      String status;
      byte statusColor;
      int statusUntil;
      int drawnAt;
      final List<Btn> btns;
      private PanelCanvas canvas;

      Session() {
         this.page = PanelUi.Page.HOME;
         this.scrolls = new EnumMap(Page.class);
         this.cx = -1;
         this.cy = -1;
         this.drawnAt = -1000;
         this.btns = new ArrayList();
      }

      PanelCanvas canvas(int cols, int rows) {
         if (this.canvas == null || this.canvas.cols != cols || this.canvas.rows != rows) {
            this.canvas = new PanelCanvas(cols, rows);
         }

         return this.canvas;
      }

      boolean due(int now) {
         int every = this.page != PanelUi.Page.FIGHT && this.page != PanelUi.Page.BOT && this.page != PanelUi.Page.BOTS && this.page != PanelUi.Page.TEAM ? 20 : 10;
         return now - this.drawnAt >= every || this.status != null && now >= this.statusUntil;
      }

      void scroll(int d) {
         this.scrolls.put(this.page, Math.max(0, Math.min(this.scrollMax, (Integer)this.scrolls.getOrDefault(this.page, 0) + d)));
      }

      void click(MinecraftServer server, ServerPlayer viewer) {
         for(int i = this.btns.size() - 1; i >= 0; --i) {
            if (((Btn)this.btns.get(i)).has(this.cx, this.cy)) {
               ((Btn)this.btns.get(i)).run.run();
               return;
            }
         }

      }

      void go(Page p) {
         this.page = p;
      }

      void back() {
         this.page = this.page == PanelUi.Page.BOT ? PanelUi.Page.BOTS : (this.page == PanelUi.Page.TEAM ? PanelUi.Page.TEAMS : PanelUi.Page.HOME);
      }

      void reset() {
         this.page = PanelUi.Page.HOME;
         this.scrolls.clear();
         this.status = null;
      }

      void say(String text, byte color) {
         this.status = text.replaceAll("§.", "").toUpperCase(Locale.ROOT);
         this.statusColor = color;
         this.statusUntil = this.drawnAt + 60;
      }
   }

   @FunctionalInterface
   private interface RowDraw {
      void draw(int var1, int var2, int var3, int var4, boolean var5);
   }
}
