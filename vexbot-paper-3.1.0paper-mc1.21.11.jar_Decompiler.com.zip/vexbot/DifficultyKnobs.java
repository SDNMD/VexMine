package vexbot;

import java.util.List;
import java.util.Locale;
import java.util.function.ToDoubleFunction;

public final class DifficultyKnobs {
   public static final List<Knob> ALL = List.of(new Knob("misschance", "Miss chance", "How often its aim lands off the head. Higher is sloppier.", "%", (double)5.0F, (double)25.0F, (double)0.0F, (double)100.0F, (p) -> p.missChance * (double)100.0F), new Knob("accuracy", "Technique accuracy", "How reliably it lands advanced techniques like crits and combos.", "%", (double)5.0F, (double)25.0F, (double)0.0F, (double)100.0F, (p) -> p.accuracy * (double)100.0F), new Knob("clutch", "Clutch accuracy", "How often a water-bucket clutch succeeds.", "%", (double)5.0F, (double)25.0F, (double)0.0F, (double)100.0F, (p) -> p.clutchAccuracy * (double)100.0F), new Knob("reaction", "Reaction time", "General reaction delay before it responds to what you do.", " ms", (double)50.0F, (double)250.0F, (double)0.0F, (double)2000.0F, (p) -> (double)p.reactionMinTicks * (double)50.0F), new Knob("shielddisablespeed", "Shield-break reaction", "How long it takes to react and axe your shield.", " ms", (double)50.0F, (double)250.0F, (double)0.0F, (double)3000.0F, (p) -> (double)p.shieldReactionMs), new Knob("shieldcharge", "Shield-break charge", "Axe charge it waits for before swinging at your shield.", "%", (double)5.0F, (double)25.0F, (double)0.0F, (double)100.0F, (p) -> p.shieldDisableCharge * (double)100.0F), new Knob("strafe", "Strafe width", "How wide it circles you while fighting.", "°", (double)5.0F, (double)15.0F, (double)0.0F, (double)90.0F, (p) -> p.strafeAngle), new Knob("crittiming", "Crit timing", "How close to perfect its critical-hit timing is. 100 is optimal.", "%", (double)5.0F, (double)25.0F, (double)0.0F, (double)100.0F, (p) -> ((double)1.0F + p.critThreshold / 0.15) * (double)100.0F), new Knob("anchorspeed", "Anchor place interval", "Ticks between respawn-anchor placements.", " ticks", (double)1.0F, (double)5.0F, (double)1.0F, (double)100.0F, (p) -> (double)p.anchorIntervalTicks), new Knob("stunslam", "Stun-slam chance", "Chance to follow an axe shield-break with a mace smash.", "%", (double)5.0F, (double)25.0F, (double)0.0F, (double)100.0F, (p) -> (double)p.stunSlamChance), new Knob("potspeed", "Potion throw gap", "Seconds between splash-potion throws.", " s", 0.05, (double)0.5F, 0.05, (double)5.0F, (p) -> p.potIntervalSeconds), new Knob("webdrainspeed", "Web-drain reaction", "Seconds before it scoops up the water you use to escape a web.", " s", 0.1, (double)0.5F, (double)0.0F, (double)5.0F, (p) -> p.webDrainDelaySeconds), new Knob("webescapespeed", "Web-escape delay", "Seconds before it starts escaping a web itself.", " s", 0.1, (double)0.5F, (double)0.0F, (double)5.0F, (p) -> p.webEscapeDelaySeconds), new Knob("reachflips", "Reach flips", "How often it gives up full reach. 0 means always full reach.", "", (double)1.0F, (double)3.0F, (double)0.0F, (double)10.0F, (p) -> (double)p.reachFlips), new Knob("cartskip", "Cart skip chance", "Share of cart opportunities it lets pass.", "%", (double)5.0F, (double)25.0F, (double)0.0F, (double)100.0F, (p) -> (double)p.cartSkipChance), new Knob("cartspeed", "Cart cooldown", "Ticks between TNT minecarts.", " ticks", (double)1.0F, (double)5.0F, (double)1.0F, (double)100.0F, (p) -> (double)p.cartCooldownTicks), new Knob("crystalspeed", "Crystal cooldown", "Ticks between end crystals.", " ticks", (double)1.0F, (double)5.0F, (double)0.0F, (double)100.0F, (p) -> (double)p.crystalCooldownTicks), new Knob("anchorgap", "Anchor cooldown", "Ticks between respawn anchors.", " ticks", (double)1.0F, (double)5.0F, (double)1.0F, (double)100.0F, (p) -> (double)p.anchorCooldownTicks), new Knob("elytramace", "Elytra-mace skill", "Elytra-mace level from 1 (easy) to 5 (full strength).", "", (double)1.0F, (double)1.0F, (double)1.0F, (double)5.0F, (p) -> (double)p.elytraMaceLevel), new Knob("crystalpvp", "Crystal PvP skill", "Crystal and anchor PvP level from 1 (easy) to 5 (full strength): seat choice, missed breaks, duds, hesitation.", "", (double)1.0F, (double)1.0F, (double)1.0F, (double)5.0F, (p) -> (double)p.crystalPvpLevel));

   private DifficultyKnobs() {
   }

   public static Knob byId(String id) {
      if (id == null) {
         return null;
      } else {
         String k = id.toLowerCase(Locale.ROOT);

         for(Knob kn : ALL) {
            if (kn.id.equals(k)) {
               return kn;
            }
         }

         Knob var10000;
         switch (k) {
            case "shieldreaction":
               var10000 = byId("shielddisablespeed");
               break;
            case "webdrain":
               var10000 = byId("webdrainspeed");
               break;
            case "webescape":
               var10000 = byId("webescapespeed");
               break;
            case "elytramacelevel":
               var10000 = byId("elytramace");
               break;
            case "crystal":
            case "crystallevel":
            case "crystalpvplevel":
            case "cpvp":
               var10000 = byId("crystalpvp");
               break;
            default:
               var10000 = null;
         }

         return var10000;
      }
   }

   public static String apply(DifficultyParams p, String knob, double v) {
      switch (knob.toLowerCase(Locale.ROOT)) {
         case "misschance":
            p.missChance = clamp01(v / (double)100.0F);
            return Math.round(v) + "% off-head";
         case "accuracy":
            p.accuracy = clamp01(v / (double)100.0F);
            return Math.round(v) + "% advanced tech";
         case "clutch":
            p.clutchAccuracy = clamp01(v / (double)100.0F);
            return Math.round(v) + "% water-bucket";
         case "reaction":
            int t = Math.max(0, (int)Math.round(v / (double)50.0F));
            p.reactionMinTicks = t;
            p.reactionMaxTicks = t;
            long var10 = Math.round(v);
            return var10 + " ms (" + t + " ticks)";
         case "shielddisablespeed":
         case "shieldreaction":
            p.shieldReactionMs = Math.max(0, (int)Math.round(v));
            return p.shieldReactionMs + " ms to react + disable your shield";
         case "shieldcharge":
            p.shieldDisableCharge = clamp01(v / (double)100.0F);
            return Math.round(v) + "% axe charge to pop shield";
         case "strafe":
            p.strafeAngle = Math.max((double)0.0F, Math.min((double)90.0F, v));
            return Math.round(p.strafeAngle) + "° strafe width";
         case "crittiming":
            double pct = Math.max((double)0.0F, Math.min((double)100.0F, v));
            p.critThreshold = -((double)1.0F - pct / (double)100.0F) * 0.15;
            return Math.round(pct) + "% crit timing";
         case "anchorspeed":
            p.anchorIntervalTicks = Math.max(1, (int)Math.round(v));
            return p.anchorIntervalTicks + " ticks anchor interval";
         case "stunslam":
            p.stunSlamChance = Math.max(0, Math.min(100, (int)Math.round(v)));
            return p.stunSlamChance + "% stun-slam chance";
         case "potspeed":
            p.potIntervalSeconds = Math.max(0.05, Math.min((double)5.0F, v));
            return p.potIntervalSeconds + " s between potion throws";
         case "webdrainspeed":
         case "webdrain":
            p.webDrainDelaySeconds = Math.max((double)0.0F, Math.min((double)5.0F, v));
            return p.webDrainDelaySeconds + " s to react + scoop escape water";
         case "webescapespeed":
         case "webescape":
            p.webEscapeDelaySeconds = Math.max((double)0.0F, Math.min((double)5.0F, v));
            return p.webEscapeDelaySeconds + " s to start escaping a web";
         case "reachflips":
            p.reachFlips = Math.max(0, Math.min(10, (int)Math.round(v)));
            return p.reachFlips + " reach flips (0 = always full reach)";
         case "cartskip":
            p.cartSkipChance = Math.max(0, Math.min(100, (int)Math.round(v)));
            return p.cartSkipChance + "% of carts skipped";
         case "cartspeed":
            p.cartCooldownTicks = Math.max(1, (int)Math.round(v));
            return p.cartCooldownTicks + " ticks between carts";
         case "crystalspeed":
            p.crystalCooldownTicks = Math.max(0, (int)Math.round(v));
            return p.crystalCooldownTicks + " ticks between crystals";
         case "anchorgap":
            p.anchorCooldownTicks = Math.max(1, (int)Math.round(v));
            return p.anchorCooldownTicks + " ticks between anchors";
         case "elytramace":
         case "elytramacelevel":
            p.elytraMaceLevel = Math.max(1, Math.min(5, (int)Math.round(v)));
            String var9 = levelName(p.elytraMaceLevel);
            return "elytra-mace " + var9 + " (" + p.elytraMaceLevel + "/5)" + (p.elytraMaceLevel == 5 ? " - full strength" : "");
         case "crystalpvp":
         case "crystal":
         case "crystallevel":
         case "crystalpvplevel":
         case "cpvp":
            p.crystalPvpLevel = Math.max(1, Math.min(5, (int)Math.round(v)));
            String var10000 = levelName(p.crystalPvpLevel);
            return "crystal PvP " + var10000 + " (" + p.crystalPvpLevel + "/5)" + (p.crystalPvpLevel == 5 ? " - full strength" : "");
         default:
            return null;
      }
   }

   public static String step(DifficultyParams p, Knob k, boolean up, boolean big) {
      double cur = k.get.applyAsDouble(p);
      double d = big ? k.bigStep : k.step;
      double next = Math.max(k.min, Math.min(k.max, cur + (up ? d : -d)));
      return apply(p, k.id, next);
   }

   public static String levelName(int lvl) {
      String var10000;
      switch (Math.max(1, Math.min(5, lvl))) {
         case 1 -> var10000 = "easy";
         case 2 -> var10000 = "medium";
         case 3 -> var10000 = "hard";
         case 4 -> var10000 = "expert";
         default -> var10000 = "professional";
      }

      return var10000;
   }

   private static double clamp01(double v) {
      return v < (double)0.0F ? (double)0.0F : (v > (double)1.0F ? (double)1.0F : v);
   }

   public static record Knob(String id, String label, String description, String unit, double step, double bigStep, double min, double max, ToDoubleFunction<DifficultyParams> get) {
      public String shown(DifficultyParams p) {
         double v = this.get.applyAsDouble(p);
         if (!this.id.equals("elytramace") && !this.id.equals("crystalpvp")) {
            boolean whole = this.step >= (double)1.0F && this.bigStep >= (double)1.0F;
            String var5 = whole ? String.valueOf(Math.round(v)) : String.format(Locale.ROOT, "%.2f", v);
            return var5 + this.unit;
         } else {
            String var10000 = DifficultyKnobs.levelName((int)Math.round(v));
            return var10000 + " (" + Math.round(v) + "/5)";
         }
      }
   }
}
