package vexbot.stats;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.LongAdder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.BotSettings;
import vexbot.VexBot;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.platform.Platform;

public final class Stats {
   private static final String ENDPOINT = System.getProperty("vexbot.stats.url", "https://api-mods.icondice.org/rest/v1/rpc/stats4_ingest");
   private static final String API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzQwMDAwMDAwLCJleHAiOjIwNDAwMDAwMDB9.H0owtzLy4NCkueVY-IE2AMDNBc58oUQnW4NsCbbA9-M";
   private static final int SCHEMA = 4;
   private static final int POST_INTERVAL_TICKS = 100;
   private static final long HEARTBEAT_MS = 20000L;
   private static final long THROTTLED_HOLD_MS = 30000L;
   private static final long REFUSED_HOLD_MS = 60000L;
   private static final Duration TIMEOUT = Duration.ofSeconds(6L);
   private static final Duration STOP_TIMEOUT = Duration.ofSeconds(2L);
   private static final int[] PROBE_SECONDS = new int[]{30, 60, 120, 300, 600};
   private static final int MAX_NAMES = 2000;
   private static final int NAMES_SENT = 20;
   public static final String BOTS_SPAWNED = "bots_spawned";
   public static final String DAMAGE_DEALT = "damage_dealt";
   public static final String BOT_KILLS = "bot_kills";
   public static final String KILLS_PLAYERS = "kills_players";
   public static final String KILLS_MOBS = "kills_mobs";
   public static final String KILLS_BOTS = "kills_bots";
   public static final String BOT_DEATHS = "bot_deaths";
   public static final String TEAMS_CREATED = "teams_created";
   public static final String BLOCKS_PLACED = "blocks_placed";
   public static final String BLOCKS_MINED = "blocks_mined";
   public static final String ARMOR_BROKEN = "armor_broken";
   public static final String ARMOR_USED = "armor_used";
   public static final String TOTEMS_POPPED = "totems_popped";
   public static final String TOTEMS_FORCED = "totems_forced";
   public static final String WEBS_PLACED = "webs_placed";
   private static final String[] ADDONS = new String[]{"vexsim", "vextrial", "vexshop", "vexpull"};
   private static final Map<String, LongAdder> COUNTERS = new ConcurrentHashMap();
   private static final Map<String, LongAdder> COMMANDS = new ConcurrentHashMap();
   private static final Map<String, LongAdder> EXT_PULLS = new ConcurrentHashMap();
   private static final Map<String, LongAdder> NAMES = new ConcurrentHashMap();
   private static volatile String installId = null;
   private static volatile long startedAt = System.currentTimeMillis();
   private static volatile int peakBots = 0;
   private static int tickCounter = ThreadLocalRandom.current().nextInt(100);
   private static boolean noticeShown = false;
   private static volatile boolean dirty = true;
   private static volatile int lastSentBots = -1;
   private static volatile long lastPostAt = 0L;
   private static volatile long holdUntil = 0L;
   private static volatile boolean online = true;
   private static volatile boolean inFlight = false;
   private static volatile int probes = 0;
   private static volatile long nextProbe = 0L;
   private static volatile boolean rejectedLogged = false;
   private static final HttpClient HTTP;

   private Stats() {
   }

   public static boolean enabled() {
      return BotSettings.statsEnabled && !ENDPOINT.isEmpty();
   }

   public static void add(String counter, long n) {
      if (enabled() && n > 0L) {
         ((LongAdder)COUNTERS.computeIfAbsent(counter, (k) -> new LongAdder())).add(n);
         dirty = true;
      }
   }

   public static void inc(String counter) {
      add(counter, 1L);
   }

   public static void kill(boolean victimIsBot, boolean victimIsPlayer) {
      if (enabled()) {
         inc("bot_kills");
         inc(victimIsBot ? "kills_bots" : (victimIsPlayer ? "kills_players" : "kills_mobs"));
      }
   }

   public static void command(String sub) {
      if (enabled() && sub != null && !sub.isEmpty()) {
         String key = sub.toLowerCase(Locale.ROOT);
         if (key.length() <= 24 && key.matches("[a-z_]+")) {
            ((LongAdder)COMMANDS.computeIfAbsent(key, (k) -> new LongAdder())).add(1L);
            dirty = true;
         }
      }
   }

   public static void extensionPulled(String id) {
      if (enabled() && id != null && id.matches("[a-z0-9-]{1,32}")) {
         ((LongAdder)EXT_PULLS.computeIfAbsent(id, (k) -> new LongAdder())).add(1L);
         dirty = true;
      }
   }

   public static void spawnedName(String name) {
      if (enabled() && name != null) {
         String key = name.toLowerCase(Locale.ROOT);
         if (key.matches("[a-z0-9_]{1,16}")) {
            LongAdder count = (LongAdder)NAMES.get(key);
            if (count == null) {
               if (NAMES.size() >= 2000) {
                  return;
               }

               count = (LongAdder)NAMES.computeIfAbsent(key, (k) -> new LongAdder());
            }

            count.add(1L);
            dirty = true;
         }
      }
   }

   public static void tick(MinecraftServer server) {
      if (enabled()) {
         if (!noticeShown) {
            noticeShown = true;
            VexBot.LOGGER.info("[VexBot] Anonymous usage stats are on (bot counts, kills, command names, popular bot names; never player names or IPs). Turn off: /vexbot settings stats off");
         }

         int bots = botsInWorld(server);
         if (bots > peakBots) {
            peakBots = bots;
         }

         if (++tickCounter >= 100) {
            tickCounter = 0;
            if (!inFlight) {
               long now = System.currentTimeMillis();
               if (online) {
                  if (now < holdUntil) {
                     return;
                  }

                  if (dirty || bots != lastSentBots || now - lastPostAt >= 20000L) {
                     post(server, bots);
                  }
               } else if (now >= nextProbe) {
                  probe(server);
               }

            }
         }
      }
   }

   private static int botsInWorld(MinecraftServer server) {
      int n = 0;

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (p instanceof BotPlayer) {
            ++n;
         }
      }

      return n;
   }

   private static void post(MinecraftServer server, int bots) {
      String body;
      try {
         dirty = false;
         body = wrap(payload(server, bots, false));
      } catch (Exception var5) {
         dirty = true;
         return;
      }

      inFlight = true;
      lastSentBots = bots;
      lastPostAt = System.currentTimeMillis();

      try {
         HTTP.sendAsync(request(body, TIMEOUT), BodyHandlers.ofString()).whenComplete((resp, err) -> {
            inFlight = false;
            int code = err == null && resp != null ? resp.statusCode() : -1;
            if (code >= 200 && code < 300) {
               if (resp.body() != null && ((String)resp.body()).contains("throttled")) {
                  dirty = true;
               }

            } else {
               dirty = true;
               if (code >= 0 && code < 500) {
                  if (code == 429) {
                     holdUntil = System.currentTimeMillis() + 30000L + ThreadLocalRandom.current().nextLong(30000L);
                  } else {
                     holdUntil = System.currentTimeMillis() + 60000L;
                     if (!rejectedLogged) {
                        rejectedLogged = true;
                        VexBot.LOGGER.warn("[VexBot] stats: the stats server refused an update (HTTP {})", code);
                     }
                  }
               } else {
                  goOffline();
               }

            }
         });
      } catch (Exception var4) {
         inFlight = false;
         dirty = true;
         goOffline();
      }

   }

   public static void stopping(MinecraftServer server) {
      if (enabled() && online && lastPostAt != 0L) {
         try {
            HTTP.sendAsync(request(wrap(payload(server, 0, true)), STOP_TIMEOUT), BodyHandlers.discarding()).get(STOP_TIMEOUT.toMillis(), TimeUnit.MILLISECONDS);
         } catch (Exception var2) {
         }

         lastSentBots = -1;
      }
   }

   private static void probe(MinecraftServer server) {
      inFlight = true;

      try {
         HttpRequest req = HttpRequest.newBuilder(URI.create(ENDPOINT)).timeout(TIMEOUT).method("HEAD", BodyPublishers.noBody()).build();
         HTTP.sendAsync(req, BodyHandlers.discarding()).whenComplete((resp, err) -> {
            inFlight = false;
            if (err == null && resp != null && resp.statusCode() < 500) {
               online = true;
               probes = 0;
               dirty = true;
               VexBot.LOGGER.info("[VexBot] stats: back online, sending again.");
               server.execute(() -> {
                  if (enabled() && online && !inFlight) {
                     post(server, botsInWorld(server));
                  }

               });
            } else {
               scheduleProbe();
            }

         });
      } catch (Exception var2) {
         inFlight = false;
         scheduleProbe();
      }

   }

   private static void goOffline() {
      if (online) {
         online = false;
         probes = 0;
         VexBot.LOGGER.info("[VexBot] stats: can't reach the stats server; pausing and checking quietly.");
      }

      scheduleProbe();
   }

   private static void scheduleProbe() {
      int idx = Math.min(probes, PROBE_SECONDS.length - 1);
      ++probes;
      double spread = (double)0.75F + ThreadLocalRandom.current().nextDouble() * (double)0.5F;
      nextProbe = System.currentTimeMillis() + (long)((double)((long)PROBE_SECONDS[idx] * 1000L) * spread);
   }

   private static HttpRequest request(String body, Duration timeout) {
      return HttpRequest.newBuilder(URI.create(ENDPOINT)).timeout(timeout).header("Content-Type", "application/json").header("apikey", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzQwMDAwMDAwLCJleHAiOjIwNDAwMDAwMDB9.H0owtzLy4NCkueVY-IE2AMDNBc58oUQnW4NsCbbA9-M").header("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlzcyI6InN1cGFiYXNlIiwiaWF0IjoxNzQwMDAwMDAwLCJleHAiOjIwNDAwMDAwMDB9.H0owtzLy4NCkueVY-IE2AMDNBc58oUQnW4NsCbbA9-M").POST(BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build();
   }

   private static String wrap(JsonObject payload) {
      JsonObject wrapper = new JsonObject();
      wrapper.add("p", payload);
      return wrapper.toString();
   }

   public static JsonObject payload(MinecraftServer server, int botsOnline, boolean stopping) {
      JsonObject o = new JsonObject();
      o.addProperty("schema", 4);
      o.addProperty("install", installId(server));
      o.addProperty("run", startedAt);
      o.addProperty("mod_version", modVersion());
      o.addProperty("mc_version", server.getServerVersion());
      o.addProperty("platform", "Paper".equalsIgnoreCase(Platform.get().loaderName()) ? "paper" : "fabric");
      o.addProperty("uptime_s", (System.currentTimeMillis() - startedAt) / 1000L);
      o.add("totals", sums(COUNTERS));
      o.add("commands", sums(COMMANDS));
      o.add("ext_pulls", sums(EXT_PULLS));
      o.add("names", topNames());
      if (stopping) {
         o.addProperty("stopping", true);
      }

      JsonArray exts = new JsonArray();

      for(String id : ADDONS) {
         if (Platform.get().isModLoaded(id)) {
            exts.add(id);
         }
      }

      o.add("extensions", exts);
      JsonObject gauges = new JsonObject();
      gauges.addProperty("bots_online", botsOnline);
      gauges.addProperty("peak_bots", Math.max(peakBots, botsOnline));
      o.add("gauges", gauges);
      return o;
   }

   private static JsonObject sums(Map<String, LongAdder> map) {
      JsonObject out = new JsonObject();

      for(Map.Entry<String, LongAdder> e : map.entrySet()) {
         out.addProperty((String)e.getKey(), ((LongAdder)e.getValue()).sum());
      }

      return out;
   }

   private static JsonObject topNames() {
      List<Map.Entry<String, Long>> all = new ArrayList(NAMES.size());

      for(Map.Entry<String, LongAdder> e : NAMES.entrySet()) {
         all.add(Map.entry((String)e.getKey(), ((LongAdder)e.getValue()).sum()));
      }

      all.sort((a, b) -> Long.compare((Long)b.getValue(), (Long)a.getValue()));
      JsonObject out = new JsonObject();

      for(int i = 0; i < Math.min(20, all.size()); ++i) {
         out.addProperty((String)((Map.Entry)all.get(i)).getKey(), (Number)((Map.Entry)all.get(i)).getValue());
      }

      return out;
   }

   public static String installId(MinecraftServer server) {
      String cached = installId;
      if (cached != null) {
         return cached;
      } else {
         synchronized(Stats.class) {
            if (installId != null) {
               return installId;
            } else {
               Path file = server.getServerDirectory().resolve("config").resolve("vexbot-install-id.txt");
               String id = null;

               try {
                  if (Files.isReadable(file)) {
                     String read = Files.readString(file).trim();
                     UUID.fromString(read);
                     id = read.toLowerCase(Locale.ROOT);
                  }
               } catch (Exception var8) {
                  id = null;
               }

               if (id == null) {
                  id = UUID.randomUUID().toString();

                  try {
                     Files.createDirectories(file.getParent());
                     Files.writeString(file, id);
                  } catch (Exception var7) {
                  }
               }

               installId = id;
               return id;
            }
         }
      }
   }

   private static String modVersion() {
      String v = Platform.get().modVersion();
      int cut = v.length();

      for(int i = 0; i < v.length(); ++i) {
         char c = v.charAt(i);
         if (c == '+' || c == '-' || c == ' ') {
            cut = i;
            break;
         }
      }

      return v.substring(0, cut);
   }

   public static void clear() {
      COUNTERS.clear();
      COMMANDS.clear();
      EXT_PULLS.clear();
      NAMES.clear();
      peakBots = 0;
      tickCounter = ThreadLocalRandom.current().nextInt(100);
      dirty = true;
      lastSentBots = -1;
      lastPostAt = 0L;
      holdUntil = 0L;
      online = true;
      probes = 0;
      nextProbe = 0L;
      startedAt = System.currentTimeMillis();
   }

   static {
      HTTP = HttpClient.newBuilder().version(Version.HTTP_1_1).connectTimeout(TIMEOUT).followRedirects(Redirect.NORMAL).build();
   }
}
