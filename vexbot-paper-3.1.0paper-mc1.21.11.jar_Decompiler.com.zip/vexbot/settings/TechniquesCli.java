package vexbot.settings;

import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import vexbot.i18n.VexText;

public final class TechniquesCli {
   private static final List<Def> DEFS;
   private static final Map<String, Def> BY_KEY;
   private static final Map<String, Object[]> BY_SUB;

   private TechniquesCli() {
   }

   private static Def d(String key, String[] aliases, String cat, Function<TechniqueConfig, Boolean> get, BiConsumer<TechniqueConfig, Boolean> set, String desc) {
      return new Def(key, aliases, cat, get, set, TechniquesCli.VarKind.NONE, (Function)null, (BiConsumer)null, List.of(), desc, false);
   }

   private static String norm(String s) {
      return s.toLowerCase(Locale.ROOT).replace("-", "").replace("_", "").replace(".", "");
   }

   private static String onOff(boolean b) {
      return b ? "on" : "off";
   }

   private static boolean parseBool(String v, boolean cur) {
      boolean var10000;
      switch (v.toLowerCase(Locale.ROOT)) {
         case "on":
         case "true":
         case "yes":
         case "1":
            var10000 = true;
            break;
         case "off":
         case "false":
         case "no":
         case "0":
            var10000 = false;
            break;
         default:
            throw new IllegalArgumentException("Use on or off (got '" + v + "')");
      }

      return var10000;
   }

   private static <E extends Enum<E>> String[] names(Class<E> t) {
      return (String[])Arrays.stream((Enum[])t.getEnumConstants()).map((e) -> e.name().toLowerCase(Locale.ROOT)).toArray((x$0) -> new String[x$0]);
   }

   private static String[] variantNames(VarKind k) {
      String[] var10000;
      switch (k.ordinal()) {
         case 0 -> var10000 = new String[0];
         case 1 -> var10000 = names(TechniqueConfig.StunSlamVariant.class);
         case 2 -> var10000 = names(TechniqueConfig.RocketMaceVariant.class);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public static CompletableFuture<Suggestions> suggestKeys(SuggestionsBuilder b) {
      List<String> out = new ArrayList();

      for(Def d : DEFS) {
         out.add(d.key());

         for(Sub s : d.subs()) {
            String var10001 = d.key();
            out.add(var10001 + "." + s.key());
         }
      }

      return SharedSuggestionProvider.suggest(out, b);
   }

   public static CompletableFuture<Suggestions> suggestState(String technique, SuggestionsBuilder b) {
      Object[] sub = BY_SUB.get(norm(technique));
      return sub != null && ((Sub)sub[1]).enumNames().length > 0 ? SharedSuggestionProvider.suggest(((Sub)sub[1]).enumNames(), b) : SharedSuggestionProvider.suggest(new String[]{"on", "off"}, b);
   }

   public static CompletableFuture<Suggestions> suggestVariants(String technique, SuggestionsBuilder b) {
      Def d = (Def)BY_KEY.get(norm(technique));
      return d != null && d.variant() != TechniquesCli.VarKind.NONE ? SharedSuggestionProvider.suggest(variantNames(d.variant()), b) : Suggestions.empty();
   }

   public static List<SettingView> settingViews() {
      List<SettingView> out = new ArrayList();

      for(Def d : DEFS) {
         String var10000 = d.desc();
         String desc = var10000 + (d.dangerous() ? " (dangerous)" : "");
         out.add(new SettingView(d.key(), d.aliases(), d.category(), desc, (String[])null, (c) -> onOff((Boolean)d.get().apply(c)), (c, v) -> d.set().accept(c, parseBool(v, (Boolean)d.get().apply(c)))));
         if (d.variant() != TechniquesCli.VarKind.NONE) {
            out.add(new SettingView(d.key() + "-style", new String[0], d.category(), "Which version of " + d.key() + " the bot uses", variantNames(d.variant()), d.variantGet(), (c, v) -> d.variantSet().accept(c, v.toLowerCase(Locale.ROOT))));
         }

         for(Sub sub : d.subs()) {
            boolean bool = sub.enumNames().length == 0;
            String var10003 = d.key();
            var10003 = var10003 + "-" + sub.key();
            String[] var10004 = new String[0];
            String var10005 = d.category();
            String var10006 = sub.desc();
            out.add(new SettingView(var10003, var10004, var10005, var10006 + " (part of " + d.key() + ")", bool ? null : sub.enumNames(), sub.get(), sub.set()));
         }
      }

      return out;
   }

   public static List<Row> rows() {
      List<Row> out = new ArrayList(DEFS.size());

      for(Def d : DEFS) {
         out.add(new Row(d.key(), d.category(), d.desc(), d.dangerous()));
      }

      return out;
   }

   public static boolean isOn(TechniqueConfig cfg, String key) {
      Def d = (Def)BY_KEY.get(norm(key));
      return d != null && Boolean.TRUE.equals(d.get().apply(cfg));
   }

   public static List<String> variants(String key) {
      Def d = (Def)BY_KEY.get(norm(key));
      return d != null && d.variant() != TechniquesCli.VarKind.NONE ? List.of(variantNames(d.variant())) : List.of();
   }

   public static String variantOf(TechniqueConfig cfg, String key) {
      Def d = (Def)BY_KEY.get(norm(key));
      return d != null && d.variantGet() != null ? (String)d.variantGet().apply(cfg) : null;
   }

   public static boolean setVariant(TechniqueConfig cfg, String key, String variant) {
      Def d = (Def)BY_KEY.get(norm(key));
      if (d != null && d.variantSet() != null && variants(key).contains(variant)) {
         d.variantSet().accept(cfg, variant);
         return true;
      } else {
         return false;
      }
   }

   public static boolean setOn(TechniqueConfig cfg, String key, boolean on) {
      Def d = (Def)BY_KEY.get(norm(key));
      if (d == null) {
         return false;
      } else {
         d.set().accept(cfg, on);
         return true;
      }
   }

   public static int apply(CommandSourceStack src, GameplaySettingsScope scope, String technique, String value) {
      if (!teamExists(src, scope)) {
         return 0;
      } else {
         TechniqueConfig cfg = scope.techniqueConfig();
         Object[] subHit = BY_SUB.get(norm(technique));
         if (subHit != null) {
            Def def = (Def)subHit[0];
            Sub sub = (Sub)subHit[1];
            String before = (String)sub.get().apply(cfg);

            try {
               if (sub.enumNames().length > 0) {
                  String want = value.toLowerCase(Locale.ROOT);
                  if (Arrays.stream(sub.enumNames()).noneMatch((n) -> n.equals(want))) {
                     src.sendFailure(VexText.literal("§cInvalid value '" + value + "' for " + def.key() + "." + sub.key() + "§c. Options: §e" + String.join(", ", sub.enumNames())));
                     return 0;
                  }
               }

               sub.set().accept(cfg, value);
            } catch (IllegalArgumentException e) {
               src.sendFailure(VexText.literal("§c" + e.getMessage()));
               return 0;
            }

            String after = (String)sub.get().apply(cfg);
            scope.persist(src.getServer());
            src.sendSuccess(() -> {
               String var10000 = def.key();
               return VexText.literal("§7[techniques] §e" + var10000 + "." + sub.key() + "§7: §f" + before + " §7→ §a" + after + scopeSuffix(scope));
            }, false);
            return 1;
         } else {
            Def def = (Def)BY_KEY.get(norm(technique));
            if (def == null) {
               src.sendFailure(VexText.literal("§cUnknown technique '" + technique + "'. §7Try §e/vexbot techniques list"));
               return 0;
            } else {
               boolean before = (Boolean)def.get().apply(cfg);

               boolean now;
               try {
                  now = parseBool(value, before);
               } catch (IllegalArgumentException e) {
                  src.sendFailure(VexText.literal("§c" + e.getMessage()));
                  return 0;
               }

               def.set().accept(cfg, now);
               scope.persist(src.getServer());
               src.sendSuccess(() -> {
                  String var10000 = def.key();
                  return VexText.literal("§7[techniques] §e" + var10000 + "§7: " + (before ? "§aon" : "§coff") + " §7→ " + (now ? "§aon" : "§coff") + scopeSuffix(scope));
               }, false);
               if (now && def.dangerous()) {
                  src.sendSuccess(() -> VexText.literal("§c⚠ shield-drain never stops chipping a raised shield. Legal cadence, but relentless — off by default for a reason."), false);
               }

               return 1;
            }
         }
      }
   }

   public static int applyVariant(CommandSourceStack src, GameplaySettingsScope scope, String technique, String value) {
      if (!teamExists(src, scope)) {
         return 0;
      } else {
         Def def = (Def)BY_KEY.get(norm(technique));
         if (def == null) {
            src.sendFailure(VexText.literal("§cUnknown technique '" + technique + "'."));
            return 0;
         } else if (def.variant() == TechniquesCli.VarKind.NONE) {
            src.sendFailure(VexText.literal("§c" + def.key() + " has no variants."));
            return 0;
         } else {
            TechniqueConfig cfg = scope.techniqueConfig();
            String before = (String)def.variantGet().apply(cfg);

            try {
               def.variantSet().accept(cfg, value);
            } catch (IllegalArgumentException var8) {
               src.sendFailure(VexText.literal("§cInvalid variant '" + value + "' for " + def.key() + "§c. Options: §e" + String.join(", ", variantNames(def.variant()))));
               return 0;
            }

            String after = (String)def.variantGet().apply(cfg);
            scope.persist(src.getServer());
            src.sendSuccess(() -> VexText.literal("§7[techniques] §e" + def.key() + "§7 variant: §f" + before + " §7→ §a" + after + scopeSuffix(scope)), false);
            return 1;
         }
      }
   }

   public static int listAll(CommandSourceStack src, GameplaySettingsScope scope) {
      if (!teamExists(src, scope)) {
         return 0;
      } else {
         TechniqueConfig cfg = scope.techniqueConfig();
         StringBuilder sb = new StringBuilder("§6── VexBot techniques" + scopeSuffix(scope) + " §6──");
         String cat = "";

         for(Def d : DEFS) {
            if (!d.category().equals(cat)) {
               cat = d.category();
               sb.append("\n§6— ").append(cat).append(" —");
            }

            boolean on = (Boolean)d.get().apply(cfg);
            sb.append("\n").append(on ? "§a" : "§7").append(d.key()).append(" §8[").append(on ? "§aON" : "§cOFF").append("§8]");
            if (d.variant() != TechniquesCli.VarKind.NONE) {
               sb.append(" §7variant=§e").append((String)d.variantGet().apply(cfg));
            }

            for(Sub s : d.subs()) {
               sb.append("\n  §8├ §7").append(s.key()).append(" §8[§f").append((String)s.get().apply(cfg)).append("§8]");
            }
         }

         sb.append("\n§8/vexbot techniques <name> on|off  ·  <name> variant <v>  ·  info <name>");
         String out = sb.toString();
         src.sendSuccess(() -> VexText.literal(out), false);
         return 1;
      }
   }

   public static int showOne(CommandSourceStack src, GameplaySettingsScope scope, String technique) {
      if (!teamExists(src, scope)) {
         return 0;
      } else {
         Def def = (Def)BY_KEY.get(norm(technique));
         if (def == null) {
            Object[] subHit = BY_SUB.get(norm(technique));
            if (subHit != null) {
               def = (Def)subHit[0];
            }
         }

         if (def == null) {
            src.sendFailure(VexText.literal("§cUnknown technique '" + technique + "'."));
            return 0;
         } else {
            TechniqueConfig cfg = scope.techniqueConfig();
            String var10002 = def.key();
            StringBuilder sb = new StringBuilder("§6" + var10002 + " §8(" + def.category() + ")");
            sb.append("\n§7").append(def.desc());
            sb.append("\n§7state: ").append((Boolean)def.get().apply(cfg) ? "§aON" : "§cOFF");
            if (def.variant() != TechniquesCli.VarKind.NONE) {
               String cur = (String)def.variantGet().apply(cfg);
               sb.append("\n§7variants: ");

               for(String n : variantNames(def.variant())) {
                  sb.append(n.equals(cur) ? "§a" + n + "§7 " : "§8" + n + "§7 ");
               }
            }

            for(Sub s : def.subs()) {
               sb.append("\n§7  ").append(s.key()).append(" = §f").append((String)s.get().apply(cfg)).append(" §8— ").append(s.desc());
               if (s.enumNames().length > 0) {
                  sb.append(" §8(").append(String.join(", ", s.enumNames())).append(")");
               }
            }

            if (def.dangerous()) {
               sb.append("\n§c⚠ off by default — relentless, reads as inhuman pressure");
            }

            String out = sb.toString();
            src.sendSuccess(() -> VexText.literal(out), false);
            return 1;
         }
      }
   }

   private static boolean teamExists(CommandSourceStack src, GameplaySettingsScope scope) {
      if (scope.teamExists()) {
         return true;
      } else {
         src.sendFailure(VexText.literal("§cNo team named '§e" + scope.teamName() + "§c'."));
         return false;
      }
   }

   private static String scopeSuffix(GameplaySettingsScope scope) {
      String t = scope.teamName();
      return t == null ? "" : " §8(team " + t + ")";
   }

   static {
      DEFS = List.of(d("mace-swap", new String[]{"maceswap", "attrswap"}, "core-swaps", (c) -> c.maceSwap, (c, v) -> c.maceSwap = v, "Build a sword's charge, deliver a mace hit on that cadence (stale-attribute swap)"), d("spear-mace-swap", new String[]{"spearmaceswap", "smswap"}, "core-swaps", (c) -> c.spearMaceSwap, (c, v) -> c.spearMaceSwap = v, "Spear held for reach, mace delivered — strongest while falling"), d("sword-windburst-swap", new String[]{"swordswap", "wbswap"}, "core-swaps", (c) -> c.swordWbSwap, (c, v) -> c.swordWbSwap = v, "Sword charge into a Wind Burst mace — a combo STARTER, launches the bot"), d("breach-swap", new String[]{"breachswap"}, "core-swaps", (c) -> c.breachSwap, (c, v) -> c.breachSwap = v, "Sword charge into a Breach mace vs heavy armour"), d("spear-reach-swap", new String[]{"reachswap", "spearreach"}, "core-swaps", (c) -> c.spearReachSwap, (c, v) -> c.spearReachSwap = v, "Engage from spear range (3.0-4.3) and deliver with the sword"), new Def("windcharge-mace", new String[]{"wcmace", "windmace"}, "fundamentals", (c) -> c.windchargeMace, (c, v) -> c.windchargeMace = v, TechniquesCli.VarKind.NONE, (Function)null, (BiConsumer)null, List.of(new Sub("crouchboost", new String[0], (c) -> onOff(c.wcCrouchBoost), (c, v) -> c.wcCrouchBoost = parseBool(v, c.wcCrouchBoost), "Crouch during the wind-charge launch for extra height"), new Sub("fullcooldown", new String[0], (c) -> onOff(c.wcFullCooldownDiscipline), (c, v) -> c.wcFullCooldownDiscipline = parseBool(v, c.wcFullCooldownDiscipline), "Wait for the full mace cooldown before the smash (max damage)"), new Sub("hitpreference", names(TechniqueConfig.HitPreference.class), (c) -> c.wcHitPreference.name().toLowerCase(Locale.ROOT), (c, v) -> c.wcHitPreference = TechniqueConfig.HitPreference.valueOf(v.toUpperCase(Locale.ROOT)), "vertical = more airtime, horizontal = more damage + knockback, auto = read the terrain")), "Wind charge up, then mace on the way down", false), d("hotbar-shield-tracking", new String[]{"hotbarshield", "shieldtrack"}, "fundamentals", (c) -> c.hotbarShieldTracking, (c, v) -> c.hotbarShieldTracking = v, "Keep a shield in the hotbar (totem stays in the offhand) and block with it"), d("elytra-wc-boost", new String[]{"wcboost", "elytraboost"}, "fundamentals", (c) -> c.elytraWcBoost, (c, v) -> c.elytraWcBoost = v, "Wind charge behind the bot mid-glide for a rocketless speed boost"), d("spear-dash", new String[]{"speardash", "lungedash"}, "movement", (c) -> c.spearDash, (c, v) -> c.spearDash = v, "Lunge-swap dash — swap to the spear, attack, swap back"), d("dash-chain", new String[]{"dashchain"}, "movement", (c) -> c.dashChain, (c, v) -> c.dashChain = v, "Chain dashes airborne instead of one per approach"), d("spear-macing", new String[]{"spearmacing", "spearmace"}, "movement", (c) -> c.spearMacing, (c, v) -> c.spearMacing = v, "The whole spear-mace combo (master switch for the controller)"), new Def("wc-reset", new String[]{"wcreset", "windreset"}, "movement", (c) -> c.wcReset, (c, v) -> c.wcReset = v, TechniquesCli.VarKind.NONE, (Function)null, (BiConsumer)null, List.of(new Sub("selfreset", new String[0], (c) -> onOff(c.wcSelfReset), (c, v) -> c.wcSelfReset = parseBool(v, c.wcSelfReset), "Also self-reset with a wind charge when Wind Burst didn't launch (new)")), "Mid-air wind-charge resets to reposition or re-height", false), d("pearl-catch-glide", new String[]{"catchglide", "pcglide"}, "pearl", (c) -> c.pearlCatchGlide, (c, v) -> c.pearlCatchGlide = v, "Glide with the elytra after a pearl catch"), d("pearl-grapple", new String[]{"farpearl", "grapple"}, "pearl", (c) -> c.pearlGrapple, (c, v) -> c.pearlGrapple = v, "Far pearl onto an airborne or distant target, then mace for height"), d("dive-bomb", new String[]{"divebomb"}, "elytra", (c) -> c.diveBomb, (c, v) -> c.diveBomb = v, "Unequip the elytra mid-flight and mace on the way down"), d("elytra-stun-slam", new String[]{"elytrastun"}, "elytra", (c) -> c.elytraStunSlam, (c, v) -> c.setElytraStunSlam(v), "Stun slam at dive-bomb speed (independent of the ground stun slam)"), d("elytra-preservation", new String[]{"preserve", "flightticking"}, "elytra", (c) -> c.elytraPreserve, (c, v) -> c.elytraPreserve = v, "Tick the elytra off and on each second so flight costs no durability"), d("ground-backstab", new String[]{"backstab"}, "anti-shield", (c) -> c.groundBackstab, (c, v) -> c.setGroundBackstab(v), "Orbit behind a turtling target and hit past the shield arc. Turning this on turns stun slam off"), d("elytra-backstab", new String[]{"airbackstab"}, "anti-shield", (c) -> c.elytraBackstab, (c, v) -> c.setElytraBackstab(v), "Bend the dive path to arrive behind a blocking target. Turning this on turns stun slam off"), new Def("stun-slam", new String[]{"stunslam"}, "anti-shield", (c) -> c.stunSlam, (c, v) -> c.setStunSlam(v), TechniquesCli.VarKind.STUN, (c) -> c.stunSlamVariant.name().toLowerCase(Locale.ROOT), (c, v) -> c.stunSlamVariant = TechniqueConfig.StunSlamVariant.valueOf(v.toUpperCase(Locale.ROOT)), List.of(), "Axe disables the shield, mace lands. Turning this on turns backstab off. optimal = 2 ticks | easy = spaced | legacy_1tick = pre-2.1.9 timing", false), d("spear-stun-slam", new String[]{"spearstun"}, "anti-shield", (c) -> c.spearStunSlam, (c, v) -> c.setSpearStunSlam(v), "Stun slam that finishes with the spear's falling hit instead of the mace"), new Def("shield-drain", new String[]{"shielddrain", "drain"}, "anti-shield", (c) -> c.shieldDrain, (c, v) -> c.shieldDrain = v, TechniquesCli.VarKind.NONE, (Function)null, (BiConsumer)null, List.of(), "Relentlessly chip a raised shield until it breaks", true), d("detap-spear-mace", new String[]{"detap", "detapspear"}, "finishers", (c) -> c.detapSpearMace, (c, v) -> c.detapSpearMace = v, "Jab-mode spear pops the totem, mace kills"), d("detap-breach", new String[]{"detapbreach"}, "finishers", (c) -> c.detapBreach, (c, v) -> c.detapBreach = v, "Breach mace pops a low target, dive finishes"), new Def("spear-double-pop", new String[]{"doublepop"}, "finishers", (c) -> c.spearDoublePop, (c, v) -> c.spearDoublePop = v, TechniquesCli.VarKind.NONE, (Function)null, (BiConsumer)null, List.of(new Sub("offhand", new String[0], (c) -> onOff(c.spearDoublePopOffhand), (c, v) -> c.spearDoublePopOffhand = parseBool(v, c.spearDoublePopOffhand), "Park the spear in the offhand so the mace stays ready (experimental)")), "Hold the spear while falling — momentum damage pops twice", false), d("wc-cancel", new String[]{"wccancel", "windcancel"}, "finishers", (c) -> c.wcCancel, (c, v) -> c.wcCancel = v, "Wind charge to cancel a whiffed smash and re-launch"), new Def("rocket-mace", new String[]{"rocketmace"}, "rocket-mace", (c) -> c.rocketMace, (c, v) -> c.rocketMace = v, TechniquesCli.VarKind.ROCKET, (c) -> c.rocketMaceVariant.name().toLowerCase(Locale.ROOT), (c, v) -> c.rocketMaceVariant = TechniqueConfig.RocketMaceVariant.valueOf(v.toUpperCase(Locale.ROOT)), List.of(), "Rocket-powered dives. OFF makes every bot rocketless. v1_climb_drop | v2_boost_turn_hit | v3_unequip_turn_reequip | v4_windburst_loop", false));
      BY_KEY = new LinkedHashMap();
      BY_SUB = new LinkedHashMap();

      for(Def def : DEFS) {
         BY_KEY.put(norm(def.key()), def);

         for(String a : def.aliases()) {
            BY_KEY.put(norm(a), def);
         }

         for(Sub sub : def.subs()) {
            Map var10000 = BY_SUB;
            String var10001 = def.key();
            var10000.put(norm(var10001 + "." + sub.key()), new Object[]{def, sub});
            BY_SUB.put(norm(sub.key()), new Object[]{def, sub});
         }
      }

   }

   private static enum VarKind {
      NONE,
      STUN,
      ROCKET;

      // $FF: synthetic method
      private static VarKind[] $values() {
         return new VarKind[]{NONE, STUN, ROCKET};
      }
   }

   private static record Sub(String key, String[] enumNames, Function<TechniqueConfig, String> get, BiConsumer<TechniqueConfig, String> set, String desc) {
   }

   private static record Def(String key, String[] aliases, String category, Function<TechniqueConfig, Boolean> get, BiConsumer<TechniqueConfig, Boolean> set, VarKind variant, Function<TechniqueConfig, String> variantGet, BiConsumer<TechniqueConfig, String> variantSet, List<Sub> subs, String desc, boolean dangerous) {
   }

   public static record Row(String key, String category, String description, boolean dangerous) {
   }

   public static record SettingView(String key, String[] aliases, String category, String description, String[] enumValues, Function<TechniqueConfig, String> get, BiConsumer<TechniqueConfig, String> set) {
   }
}
