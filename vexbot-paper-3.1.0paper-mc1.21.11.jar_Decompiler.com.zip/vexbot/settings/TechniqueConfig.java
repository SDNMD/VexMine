package vexbot.settings;

import com.google.gson.JsonObject;

public final class TechniqueConfig {
   public boolean maceSwap = false;
   public boolean spearMaceSwap = false;
   public boolean swordWbSwap = false;
   public boolean breachSwap = false;
   public boolean spearReachSwap = false;
   public boolean windchargeMace = true;
   public boolean wcCrouchBoost = false;
   public boolean wcFullCooldownDiscipline = true;
   public HitPreference wcHitPreference;
   public boolean hotbarShieldTracking;
   public boolean elytraWcBoost;
   public boolean spearDash;
   public boolean dashChain;
   public boolean spearMacing;
   public boolean wcReset;
   public boolean wcSelfReset;
   public boolean pearlCatch;
   public PearlCatchVariant pearlCatchVariant;
   public boolean pearlCatchGlide;
   public boolean pearlGrapple;
   public boolean diveBomb;
   public boolean elytraStunSlam;
   public boolean elytraPreserve;
   public boolean groundBackstab;
   public boolean elytraBackstab;
   public boolean stunSlam;
   public StunSlamVariant stunSlamVariant;
   public boolean spearStunSlam;
   public boolean shieldDrain;
   public boolean detapSpearMace;
   public boolean detapBreach;
   public boolean spearDoublePop;
   public boolean spearDoublePopOffhand;
   public boolean wcCancel;
   public boolean rocketMace;
   public RocketMaceVariant rocketMaceVariant;

   public TechniqueConfig() {
      this.wcHitPreference = TechniqueConfig.HitPreference.VERTICAL;
      this.hotbarShieldTracking = false;
      this.elytraWcBoost = false;
      this.spearDash = true;
      this.dashChain = true;
      this.spearMacing = true;
      this.wcReset = true;
      this.wcSelfReset = false;
      this.pearlCatch = true;
      this.pearlCatchVariant = TechniqueConfig.PearlCatchVariant.SMART;
      this.pearlCatchGlide = true;
      this.pearlGrapple = true;
      this.diveBomb = true;
      this.elytraStunSlam = true;
      this.elytraPreserve = false;
      this.groundBackstab = false;
      this.elytraBackstab = false;
      this.stunSlam = true;
      this.stunSlamVariant = TechniqueConfig.StunSlamVariant.OPTIMAL;
      this.spearStunSlam = false;
      this.shieldDrain = false;
      this.detapSpearMace = false;
      this.detapBreach = false;
      this.spearDoublePop = false;
      this.spearDoublePopOffhand = false;
      this.wcCancel = false;
      this.rocketMace = true;
      this.rocketMaceVariant = TechniqueConfig.RocketMaceVariant.V1_CLIMB_DROP;
   }

   public void setBackstab(boolean on) {
      this.groundBackstab = on;
      this.elytraBackstab = on;
      if (on) {
         this.stunSlam = false;
         this.spearStunSlam = false;
         this.elytraStunSlam = false;
      }

   }

   public void setStunSlam(boolean on) {
      this.stunSlam = on;
      if (on) {
         this.groundBackstab = false;
         this.elytraBackstab = false;
      }

   }

   public void setGroundBackstab(boolean on) {
      this.groundBackstab = on;
      if (on) {
         this.stunSlam = false;
         this.spearStunSlam = false;
         this.elytraStunSlam = false;
      }

   }

   public void setElytraBackstab(boolean on) {
      this.elytraBackstab = on;
      if (on) {
         this.stunSlam = false;
         this.spearStunSlam = false;
         this.elytraStunSlam = false;
      }

   }

   public void setSpearStunSlam(boolean on) {
      this.spearStunSlam = on;
      if (on) {
         this.groundBackstab = false;
         this.elytraBackstab = false;
      }

   }

   public void setElytraStunSlam(boolean on) {
      this.elytraStunSlam = on;
      if (on) {
         this.groundBackstab = false;
         this.elytraBackstab = false;
      }

   }

   public boolean backstabEnabled() {
      return this.groundBackstab || this.elytraBackstab;
   }

   public boolean stunSlamEnabled() {
      return this.stunSlam || this.spearStunSlam || this.elytraStunSlam;
   }

   public TechniqueConfig copy() {
      TechniqueConfig c = new TechniqueConfig();
      c.maceSwap = this.maceSwap;
      c.spearMaceSwap = this.spearMaceSwap;
      c.swordWbSwap = this.swordWbSwap;
      c.breachSwap = this.breachSwap;
      c.spearReachSwap = this.spearReachSwap;
      c.windchargeMace = this.windchargeMace;
      c.wcCrouchBoost = this.wcCrouchBoost;
      c.wcFullCooldownDiscipline = this.wcFullCooldownDiscipline;
      c.wcHitPreference = this.wcHitPreference;
      c.hotbarShieldTracking = this.hotbarShieldTracking;
      c.elytraWcBoost = this.elytraWcBoost;
      c.spearDash = this.spearDash;
      c.dashChain = this.dashChain;
      c.spearMacing = this.spearMacing;
      c.wcReset = this.wcReset;
      c.wcSelfReset = this.wcSelfReset;
      c.pearlCatch = this.pearlCatch;
      c.pearlCatchVariant = this.pearlCatchVariant;
      c.pearlCatchGlide = this.pearlCatchGlide;
      c.pearlGrapple = this.pearlGrapple;
      c.diveBomb = this.diveBomb;
      c.elytraStunSlam = this.elytraStunSlam;
      c.elytraPreserve = this.elytraPreserve;
      c.groundBackstab = this.groundBackstab;
      c.elytraBackstab = this.elytraBackstab;
      c.stunSlam = this.stunSlam;
      c.stunSlamVariant = this.stunSlamVariant;
      c.spearStunSlam = this.spearStunSlam;
      c.shieldDrain = this.shieldDrain;
      c.detapSpearMace = this.detapSpearMace;
      c.detapBreach = this.detapBreach;
      c.spearDoublePop = this.spearDoublePop;
      c.spearDoublePopOffhand = this.spearDoublePopOffhand;
      c.wcCancel = this.wcCancel;
      c.rocketMace = this.rocketMace;
      c.rocketMaceVariant = this.rocketMaceVariant;
      return c;
   }

   public void writeTo(JsonObject o) {
      o.addProperty("maceSwap", this.maceSwap);
      o.addProperty("spearMaceSwap", this.spearMaceSwap);
      o.addProperty("swordWbSwap", this.swordWbSwap);
      o.addProperty("breachSwap", this.breachSwap);
      o.addProperty("spearReachSwap", this.spearReachSwap);
      o.addProperty("windchargeMace", this.windchargeMace);
      o.addProperty("wcCrouchBoost", this.wcCrouchBoost);
      o.addProperty("wcFullCooldownDiscipline", this.wcFullCooldownDiscipline);
      o.addProperty("wcHitPreference", this.wcHitPreference.name());
      o.addProperty("hotbarShieldTracking", this.hotbarShieldTracking);
      o.addProperty("elytraWcBoost", this.elytraWcBoost);
      o.addProperty("spearDash", this.spearDash);
      o.addProperty("dashChain", this.dashChain);
      o.addProperty("spearMacing", this.spearMacing);
      o.addProperty("wcReset", this.wcReset);
      o.addProperty("wcSelfReset", this.wcSelfReset);
      o.addProperty("pearlCatch", this.pearlCatch);
      o.addProperty("pearlCatchVariant", this.pearlCatchVariant.name());
      o.addProperty("pearlCatchGlide", this.pearlCatchGlide);
      o.addProperty("pearlGrapple", this.pearlGrapple);
      o.addProperty("diveBomb", this.diveBomb);
      o.addProperty("elytraStunSlam", this.elytraStunSlam);
      o.addProperty("elytraPreserve", this.elytraPreserve);
      o.addProperty("groundBackstab", this.groundBackstab);
      o.addProperty("elytraBackstab", this.elytraBackstab);
      o.addProperty("stunSlam", this.stunSlam);
      o.addProperty("stunSlamVariant", this.stunSlamVariant.name());
      o.addProperty("spearStunSlam", this.spearStunSlam);
      o.addProperty("shieldDrain", this.shieldDrain);
      o.addProperty("detapSpearMace", this.detapSpearMace);
      o.addProperty("detapBreach", this.detapBreach);
      o.addProperty("spearDoublePop", this.spearDoublePop);
      o.addProperty("spearDoublePopOffhand", this.spearDoublePopOffhand);
      o.addProperty("wcCancel", this.wcCancel);
      o.addProperty("rocketMace", this.rocketMace);
      o.addProperty("rocketMaceVariant", this.rocketMaceVariant.name());
   }

   public void readFrom(JsonObject o) {
      this.maceSwap = b(o, "maceSwap", this.maceSwap);
      this.spearMaceSwap = b(o, "spearMaceSwap", this.spearMaceSwap);
      this.swordWbSwap = b(o, "swordWbSwap", this.swordWbSwap);
      this.breachSwap = b(o, "breachSwap", this.breachSwap);
      this.spearReachSwap = b(o, "spearReachSwap", this.spearReachSwap);
      this.windchargeMace = b(o, "windchargeMace", this.windchargeMace);
      this.wcCrouchBoost = b(o, "wcCrouchBoost", this.wcCrouchBoost);
      this.wcFullCooldownDiscipline = b(o, "wcFullCooldownDiscipline", this.wcFullCooldownDiscipline);
      this.wcHitPreference = (HitPreference)e(o, "wcHitPreference", HitPreference.class, this.wcHitPreference);
      this.hotbarShieldTracking = b(o, "hotbarShieldTracking", this.hotbarShieldTracking);
      this.elytraWcBoost = b(o, "elytraWcBoost", this.elytraWcBoost);
      this.spearDash = b(o, "spearDash", this.spearDash);
      this.dashChain = b(o, "dashChain", this.dashChain);
      this.spearMacing = b(o, "spearMacing", this.spearMacing);
      this.wcReset = b(o, "wcReset", this.wcReset);
      this.wcSelfReset = b(o, "wcSelfReset", this.wcSelfReset);
      this.pearlCatch = b(o, "pearlCatch", this.pearlCatch);
      if (o.has("pearlCatchVariant")) {
         PearlCatchVariant var10001;
         switch (o.get("pearlCatchVariant").getAsString()) {
            case "HIGHER":
            case "WINDCHARGE":
               var10001 = TechniqueConfig.PearlCatchVariant.HIGHER;
               break;
            case "INSTANT":
               var10001 = TechniqueConfig.PearlCatchVariant.INSTANT;
               break;
            case "ANGLE":
               var10001 = TechniqueConfig.PearlCatchVariant.ANGLE;
               break;
            case "STANDARD":
               var10001 = TechniqueConfig.PearlCatchVariant.STANDARD;
               break;
            default:
               var10001 = TechniqueConfig.PearlCatchVariant.SMART;
         }

         this.pearlCatchVariant = var10001;
      }

      this.pearlCatchGlide = b(o, "pearlCatchGlide", this.pearlCatchGlide);
      this.pearlGrapple = b(o, "pearlGrapple", this.pearlGrapple);
      this.diveBomb = b(o, "diveBomb", this.diveBomb);
      this.elytraStunSlam = b(o, "elytraStunSlam", this.elytraStunSlam);
      this.elytraPreserve = b(o, "elytraPreserve", this.elytraPreserve);
      this.groundBackstab = b(o, "groundBackstab", this.groundBackstab);
      this.elytraBackstab = b(o, "elytraBackstab", this.elytraBackstab);
      this.stunSlam = b(o, "stunSlam", this.stunSlam);
      this.stunSlamVariant = (StunSlamVariant)e(o, "stunSlamVariant", StunSlamVariant.class, this.stunSlamVariant);
      this.spearStunSlam = b(o, "spearStunSlam", this.spearStunSlam);
      this.shieldDrain = b(o, "shieldDrain", this.shieldDrain);
      this.detapSpearMace = b(o, "detapSpearMace", this.detapSpearMace);
      this.detapBreach = b(o, "detapBreach", this.detapBreach);
      this.spearDoublePop = b(o, "spearDoublePop", this.spearDoublePop);
      this.spearDoublePopOffhand = b(o, "spearDoublePopOffhand", this.spearDoublePopOffhand);
      this.wcCancel = b(o, "wcCancel", this.wcCancel);
      this.rocketMace = b(o, "rocketMace", this.rocketMace);
      this.rocketMaceVariant = (RocketMaceVariant)e(o, "rocketMaceVariant", RocketMaceVariant.class, this.rocketMaceVariant);
   }

   private static boolean b(JsonObject o, String k, boolean cur) {
      return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsBoolean() : cur;
   }

   private static <E extends Enum<E>> E e(JsonObject o, String k, Class<E> type, E cur) {
      if (o.has(k) && o.get(k).isJsonPrimitive()) {
         try {
            return (E)Enum.valueOf(type, o.get(k).getAsString());
         } catch (IllegalArgumentException var5) {
            return cur;
         }
      } else {
         return cur;
      }
   }

   public static enum PearlCatchVariant {
      SMART,
      STANDARD,
      HIGHER,
      INSTANT,
      ANGLE;

      // $FF: synthetic method
      private static PearlCatchVariant[] $values() {
         return new PearlCatchVariant[]{SMART, STANDARD, HIGHER, INSTANT, ANGLE};
      }
   }

   public static enum StunSlamVariant {
      OPTIMAL,
      EASY,
      LEGACY_1TICK;

      // $FF: synthetic method
      private static StunSlamVariant[] $values() {
         return new StunSlamVariant[]{OPTIMAL, EASY, LEGACY_1TICK};
      }
   }

   public static enum RocketMaceVariant {
      V1_CLIMB_DROP,
      V2_BOOST_TURN_HIT,
      V3_UNEQUIP_TURN_REEQUIP,
      V4_WINDBURST_LOOP;

      // $FF: synthetic method
      private static RocketMaceVariant[] $values() {
         return new RocketMaceVariant[]{V1_CLIMB_DROP, V2_BOOST_TURN_HIT, V3_UNEQUIP_TURN_REEQUIP, V4_WINDBURST_LOOP};
      }
   }

   public static enum HitPreference {
      VERTICAL,
      HORIZONTAL,
      AUTO;

      // $FF: synthetic method
      private static HitPreference[] $values() {
         return new HitPreference[]{VERTICAL, HORIZONTAL, AUTO};
      }
   }
}
