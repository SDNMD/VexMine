package vexbot.settings;

import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;
import vexbot.util.NameTagColour;
import vexbot.util.NameTagPainter;

public final class SettingsCli {
   private static final List<SettingDef> SETTINGS;
   private static final Map<String, SettingDef> BY_KEY;

   private SettingsCli() {
   }

   private static List<SettingDef> withTechniques(List<SettingDef> base) {
      ArrayList<SettingDef> out = new ArrayList(base);
      Set<String> taken = new HashSet();

      for(SettingDef d : base) {
         taken.add(normalize(d.key));

         for(String a : d.aliases) {
            taken.add(normalize(a));
         }
      }

      taken.add("pearlcatchglide");

      for(TechniquesCli.SettingView v : TechniquesCli.settingViews()) {
         if (taken.add(normalize(v.key()))) {
            List<String> aliases = new ArrayList();

            for(String a : v.aliases()) {
               if (taken.add(normalize(a))) {
                  aliases.add(a);
               }
            }

            boolean bool = v.enumValues() == null;
            out.add(def(v.key(), (String[])aliases.toArray((x$0) -> new String[x$0]), bool ? SettingsCli.Kind.BOOL : SettingsCli.Kind.ENUM, (s) -> (String)v.get().apply(s.techniqueConfig()), (s, val) -> {
               if (!bool && !Arrays.asList(v.enumValues()).contains(val.toLowerCase(Locale.ROOT))) {
                  throw new IllegalArgumentException("'§e" + val + "§r' is not an option. Use: " + String.join(", ", v.enumValues()) + ".");
               } else {
                  v.set().accept(s.techniqueConfig(), bool ? onOff(parseBool(val, "on".equals(v.get().apply(s.techniqueConfig())))) : val.toLowerCase(Locale.ROOT));
               }
            }, v.enumValues(), v.description()));
         }
      }

      return List.copyOf(out);
   }

   public static String techniqueCategory(String key) {
      for(TechniquesCli.SettingView v : TechniquesCli.settingViews()) {
         if (normalize(v.key()).equals(normalize(key))) {
            return v.category();
         }
      }

      return null;
   }

   public static List<String> settingKeys() {
      return SETTINGS.stream().map((s) -> s.key).toList();
   }

   public static CompletableFuture<Suggestions> suggestSettings(CommandSourceStack source, SuggestionsBuilder builder) {
      return SharedSuggestionProvider.suggest(settingKeys(), builder);
   }

   public static CompletableFuture<Suggestions> suggestValues(CommandSourceStack source, SuggestionsBuilder builder, String settingRaw) {
      SettingDef def = resolve(settingRaw);
      if (def == null) {
         return builder.buildFuture();
      } else if (def.kind == SettingsCli.Kind.BOOL) {
         return SharedSuggestionProvider.suggest(new String[]{"on", "off", "toggle", "true", "false"}, builder);
      } else if (def.kind == SettingsCli.Kind.PERCENT) {
         return SharedSuggestionProvider.suggest(new String[]{"0", "25", "50", "75", "100"}, builder);
      } else if (def.kind == SettingsCli.Kind.NUMBER) {
         return SharedSuggestionProvider.suggest(new String[]{"2", "3", "4", "5", "6", "8"}, builder);
      } else {
         return def.kind == SettingsCli.Kind.STRING ? SharedSuggestionProvider.suggest(TeamManager.teamNames(), builder) : SharedSuggestionProvider.suggest(def.enumValues, builder);
      }
   }

   public static int listAll(CommandSourceStack source, GameplaySettingsScope scope) {
      if (!scope.teamExists()) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + scope.teamName() + "§r'."));
         return 0;
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] Settings (" + scope.scopeLabel() + "):"), false);

         for(SettingDef def : SETTINGS) {
            String current = (String)def.getter.apply(scope);
            source.sendSuccess(() -> VexText.literal("  §e" + def.key + "§r = §f" + current + " §8— " + def.description), false);
         }

         source.sendSuccess(() -> VexText.literal("§8Use §e/vexbot " + (scope.isTeamScope() ? "teamsettings <team> " : "settings ") + "<setting> <value>§8 to change."), false);
         return SETTINGS.size();
      }
   }

   public static int showOne(CommandSourceStack source, GameplaySettingsScope scope, String settingRaw) {
      if (!scope.teamExists()) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + scope.teamName() + "§r'."));
         return 0;
      } else {
         SettingDef def = resolve(settingRaw);
         if (def == null) {
            source.sendFailure(VexText.literal("[VexBot] Unknown setting '§e" + settingRaw + "§r'. Run §e/vexbot settings list§r for all keys."));
            return 0;
         } else {
            String current = (String)def.getter.apply(scope);
            String options = def.kind == SettingsCli.Kind.BOOL ? "on, off, toggle" : (def.kind == SettingsCli.Kind.PERCENT ? "0–100 (percent)" : (def.kind == SettingsCli.Kind.NUMBER ? (def.rangeHint != null ? def.rangeHint : "a number") : (def.kind == SettingsCli.Kind.STRING ? "any team name" : String.join(", ", def.enumValues))));
            source.sendSuccess(() -> VexText.literal("[VexBot] " + scope.scopeLabel() + " §e" + def.key + "§r = §f" + current), false);
            source.sendSuccess(() -> VexText.literal("§8" + def.description + " — valid: " + options), false);
            return 1;
         }
      }
   }

   public static int apply(CommandSourceStack source, GameplaySettingsScope scope, String settingRaw, String valueRaw) {
      if (!scope.teamExists()) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + scope.teamName() + "§r'."));
         return 0;
      } else {
         SettingDef def = resolve(settingRaw);
         if (def == null) {
            source.sendFailure(VexText.literal("[VexBot] Unknown setting '§e" + settingRaw + "§r'. Run §e/vexbot settings list§r for all keys."));
            return 0;
         } else if (valueRaw != null && !valueRaw.isBlank()) {
            scope.ensureTeam();
            String before = (String)def.getter.apply(scope);

            try {
               def.setter.accept(scope, valueRaw.trim());
            } catch (IllegalArgumentException e) {
               source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
               return 0;
            }

            String after = (String)def.getter.apply(scope);
            scope.persist(source.getServer());
            EffectiveSettings.invalidate();
            source.sendSuccess(() -> VexText.literal("[VexBot] " + scope.scopeLabel() + " §e" + def.key + "§r: §f" + before + " §7→ §f" + after), false);
            if (def.key.equals("botdontleave")) {
               source.sendSuccess(() -> VexText.literal("§7[VexBot] botdontleave is a §fGLOBAL§7 setting — it applies to every bot in the world, not just this team."), false);
               source.sendSuccess(() -> VexText.literal("§7[VexBot] This is about §fLEAVING THE WORLD§7 — bots come back when you rejoin. If you wanted bots to stay after they §fDIE§7, that is §e/vexbot settings botleaveondeath false§7."), false);
            }

            if (def.key.equals("doblockexplosion")) {
               String who = scope.teamName() == null ? "every real player and bot that is §fNOT on a team§7. Team members follow their team's setting: §e/vexbot team <name> settings doblockexplosion§7" : "every member of team §f" + scope.teamName() + "§7, players and bots";
               source.sendSuccess(() -> VexText.literal("§7[VexBot] Applies to " + who + "."), false);
            }

            if (def.key.equals("botleaveondeath")) {
               source.sendSuccess(() -> VexText.literal("§7[VexBot] This is about §fDYING§7. If you wanted bots to survive closing and reopening the world, that is §e/vexbot settings botdontleave on§7."), false);
            }

            if (def.key.equals("orbitalstrike") && "on".equals(after)) {
               source.sendSuccess(() -> VexText.literal("§c⚠ Orbital Strike is ON — this can be VERY destructive. Bots will fire Orbital Strike Cannon rods from their kit (rains thousands of TNT). Only use it where you're happy to nuke the terrain."), false);
            }

            return 1;
         } else {
            return showOne(source, scope, settingRaw);
         }
      }
   }

   public static List<Entry> entries(GameplaySettingsScope scope) {
      ArrayList<Entry> out = new ArrayList(SETTINGS.size());

      for(SettingDef d : SETTINGS) {
         out.add(new Entry(d.key, d.kind.name(), d.description, distinctValues(d), safeGet(d, scope)));
      }

      return out;
   }

   public static String currentValue(GameplaySettingsScope scope, String key) {
      SettingDef d = resolve(key);
      return d == null ? null : safeGet(d, scope);
   }

   private static String safeGet(SettingDef d, GameplaySettingsScope scope) {
      try {
         return (String)d.getter.apply(scope);
      } catch (Exception var3) {
         return "?";
      }
   }

   public static String click(GameplaySettingsScope scope, String key, boolean forward, boolean big) {
      SettingDef d = resolve(key);
      if (d == null) {
         return "Unknown setting '" + key + "'.";
      } else {
         scope.ensureTeam();

         try {
            switch (d.kind.ordinal()) {
               case 0:
                  d.setter.accept(scope, "toggle");
                  break;
               case 1:
                  List<String> vals = distinctValues(d);
                  if (vals.isEmpty()) {
                     return "That setting has no values to cycle.";
                  }

                  String cur = normalize(safeGet(d, scope));
                  int idx = 0;

                  for(int i = 0; i < vals.size(); ++i) {
                     if (normalize((String)vals.get(i)).equals(cur)) {
                        idx = i;
                        break;
                     }
                  }

                  idx = (idx + (forward ? 1 : vals.size() - 1)) % vals.size();
                  d.setter.accept(scope, (String)vals.get(idx));
                  break;
               case 2:
                  int cur = (int)leadingNumber(safeGet(d, scope));
                  int step = big ? 25 : 5;
                  int next = Math.max(0, Math.min(100, cur + (forward ? step : -step)));
                  d.setter.accept(scope, String.valueOf(next));
                  break;
               case 3:
                  return "Set this one with §e/vexbot settings " + d.key + " <value>§r.";
               case 4:
                  double cur = leadingNumber(safeGet(d, scope));
                  double[] steps = numberSteps(d.key);
                  double step = big ? steps[1] : steps[0];
                  double next = cur + (forward ? step : -step);
                  d.setter.accept(scope, String.format(Locale.ROOT, "%.2f", next));
            }

            return null;
         } catch (IllegalArgumentException e) {
            return e.getMessage();
         }
      }
   }

   public static double[] numberSteps(String key) {
      double[] var10000;
      switch (normalize(key)) {
         case "attackrange" -> var10000 = new double[]{(double)0.25F, (double)0.5F};
         case "lootpackradius" -> var10000 = new double[]{(double)5.0F, (double)25.0F};
         case "buildupminheight" -> var10000 = new double[]{(double)1.0F, (double)5.0F};
         case "botping" -> var10000 = new double[]{(double)10.0F, (double)50.0F};
         default -> var10000 = new double[]{(double)0.5F, (double)1.0F};
      }

      return var10000;
   }

   private static List<String> distinctValues(SettingDef d) {
      if (d.enumValues == null) {
         return List.of();
      } else {
         LinkedHashMap<String, String> seen = new LinkedHashMap();

         for(String v : d.enumValues) {
            seen.putIfAbsent(normalize(v), v);
         }

         return List.copyOf(seen.values());
      }
   }

   private static double leadingNumber(String display) {
      Matcher m = Pattern.compile("-?\\d+(?:\\.\\d+)?").matcher(display);
      return m.find() ? Double.parseDouble(m.group()) : (double)0.0F;
   }

   private static SettingDef resolve(String raw) {
      return raw == null ? null : (SettingDef)BY_KEY.get(normalize(raw));
   }

   private static String normalize(String raw) {
      return raw.toLowerCase(Locale.ROOT).replace("-", "").replace("_", "");
   }

   private static String onOff(boolean v) {
      return v ? "on" : "off";
   }

   private static boolean parseBool(String raw, boolean current) {
      boolean var10000;
      switch (normalize(raw)) {
         case "on":
         case "true":
         case "yes":
         case "enable":
         case "enabled":
         case "1":
            var10000 = true;
            break;
         case "off":
         case "false":
         case "no":
         case "disable":
         case "disabled":
         case "0":
            var10000 = false;
            break;
         case "toggle":
            var10000 = !current;
            break;
         default:
            throw new IllegalArgumentException("Invalid boolean '§e" + raw + "§r'. Use: on, off, toggle.");
      }

      return var10000;
   }

   private static String hearts(double v) {
      return v == Math.rint(v) ? String.valueOf((int)v) : String.valueOf(v);
   }

   private static double parseNumber(String raw) {
      double d = Double.parseDouble(raw);
      if (Double.isNaN(d)) {
         throw new NumberFormatException("Not a number: '" + raw + "'");
      } else {
         return d;
      }
   }

   private static double parseHearts(String raw) {
      String n = raw.trim();
      if (n.toLowerCase(Locale.ROOT).endsWith("hearts")) {
         n = n.substring(0, n.length() - 6).trim();
      } else if (n.toLowerCase(Locale.ROOT).endsWith("hp")) {
         try {
            return Math.clamp(parseNumber(n.substring(0, n.length() - 2).trim()) / (double)2.0F, (double)0.5F, (double)10.0F);
         } catch (NumberFormatException var4) {
         }
      }

      try {
         return Math.clamp(parseNumber(n), (double)0.5F, (double)10.0F);
      } catch (NumberFormatException var3) {
         throw new IllegalArgumentException("Invalid hearts value '§e" + raw + "§r'. Use a number from 0.5 to 10.");
      }
   }

   private static int parsePercent(String raw) {
      String n = raw.trim();
      if (n.endsWith("%")) {
         n = n.substring(0, n.length() - 1).trim();
      }

      try {
         return Math.clamp((long)Integer.parseInt(n), 0, 100);
      } catch (NumberFormatException var3) {
         throw new IllegalArgumentException("Invalid percent '§e" + raw + "§r'. Use an integer from 0 to 100.");
      }
   }

   private static <E extends Enum<E>> E parseEnum(String raw, Class<E> type, String label) {
      String n = normalize(raw);

      for(E constant : (Enum[])type.getEnumConstants()) {
         if (normalize(constant.name()).equals(n)) {
            return constant;
         }
      }

      String valid = String.join(", ", enumNames(type));
      throw new IllegalArgumentException("Invalid " + label + " '§e" + raw + "§r'. Use: " + valid + ".");
   }

   private static TechniqueConfig.PearlCatchVariant parsePearlCatchType(String raw) {
      TechniqueConfig.PearlCatchVariant var10000;
      switch (normalize(raw)) {
         case "smart":
         case "auto":
         case "best":
            var10000 = TechniqueConfig.PearlCatchVariant.SMART;
            break;
         case "standard":
         case "still":
         case "normal":
            var10000 = TechniqueConfig.PearlCatchVariant.STANDARD;
            break;
         case "higher":
         case "windcharge":
         case "wc":
         case "jump":
         case "high":
            var10000 = TechniqueConfig.PearlCatchVariant.HIGHER;
            break;
         case "instant":
         case "quick":
         case "fast":
         case "offhand":
            var10000 = TechniqueConfig.PearlCatchVariant.INSTANT;
            break;
         case "angle":
         case "angled":
         case "diagonal":
            var10000 = TechniqueConfig.PearlCatchVariant.ANGLE;
            break;
         default:
            throw new IllegalArgumentException("Invalid pearlcatchtype '§e" + raw + "§r'. Use: smart, standard, higher, instant, angle.");
      }

      return var10000;
   }

   private static double parseAttackRange(String raw) {
      String v = raw.trim().toLowerCase(Locale.ROOT);
      if (!v.equals("default") && !v.equals("vanilla") && !v.equals("reset")) {
         double d;
         try {
            d = Double.parseDouble(v);
         } catch (NumberFormatException var5) {
            throw new IllegalArgumentException("attackrange must be a number of blocks (1.0–6.0), or 'default' for vanilla 3.0.");
         }

         if (!(d < (double)1.0F) && !(d > (double)6.0F)) {
            return d;
         } else {
            throw new IllegalArgumentException("attackrange must be between 1.0 and 6.0 blocks (vanilla is 3.0).");
         }
      } else {
         return (double)3.0F;
      }
   }

   private static BotSettings.GameLogs parseGameLogs(String v, BotSettings.GameLogs fallback) {
      if (v == null) {
         return fallback;
      } else {
         BotSettings.GameLogs var10000;
         switch (v.toLowerCase(Locale.ROOT)) {
            case "detailed":
            case "detail":
            case "verbose":
            case "all":
            case "full":
               var10000 = BotSettings.GameLogs.DETAILED;
               break;
            case "brief":
            case "normal":
            case "default":
            case "short":
               var10000 = BotSettings.GameLogs.BRIEF;
               break;
            case "simple":
            case "quiet":
            case "minimal":
            case "off":
            case "none":
               var10000 = BotSettings.GameLogs.SIMPLE;
               break;
            default:
               throw new IllegalArgumentException("Invalid gamelogs '§e" + v + "§r'. Use: detailed, brief, simple.");
         }

         return var10000;
      }
   }

   private static BotSettings.BridgeMode parseBridgeMode(String raw) {
      BotSettings.BridgeMode var10000;
      switch (normalize(raw)) {
         case "ninja":
         case "crouch":
         case "safe":
         case "backwards":
            var10000 = BotSettings.BridgeMode.NINJA;
            break;
         case "god":
         case "godbridge":
         case "gobridge":
         case "fast":
            var10000 = BotSettings.BridgeMode.GOD;
            break;
         case "moonwalk":
         case "moon":
         case "sideways":
            var10000 = BotSettings.BridgeMode.MOONWALK;
            break;
         default:
            throw new IllegalArgumentException("Invalid bridgemode '§e" + raw + "§r'. Use: ninja, god, moonwalk.");
      }

      return var10000;
   }

   private static BotSettings.CartMode parseCartMode(String raw) {
      BotSettings.CartMode var10000;
      switch (normalize(raw)) {
         case "precart" -> var10000 = BotSettings.CartMode.PRE_CART;
         case "prerail" -> var10000 = BotSettings.CartMode.PRE_RAIL;
         case "instacart" -> var10000 = BotSettings.CartMode.INSTA_CART;
         case "xbowcart" -> var10000 = BotSettings.CartMode.XBOW_CART;
         case "smart" -> var10000 = BotSettings.CartMode.SMART;
         default -> throw new IllegalArgumentException("Invalid cartmode '§e" + raw + "§r'. Use: smart, precart, pre_rail, instacart, xbow_cart.");
      }

      return var10000;
   }

   private static String cartModeLabel(BotSettings.CartMode mode) {
      String var10000;
      switch (mode) {
         case PRE_CART -> var10000 = "precart";
         case PRE_RAIL -> var10000 = "pre_rail";
         case INSTA_CART -> var10000 = "instacart";
         case XBOW_CART -> var10000 = "xbow_cart";
         case SMART -> var10000 = "smart";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private static <E extends Enum<E>> String[] enumNames(Class<E> type) {
      return (String[])Arrays.stream((Enum[])type.getEnumConstants()).map((e) -> e.name().toLowerCase(Locale.ROOT)).toArray((x$0) -> new String[x$0]);
   }

   private static SettingDef def(String key, String[] aliases, Kind kind, Function<GameplaySettingsScope, String> getter, BiConsumer<GameplaySettingsScope, String> setter, String[] enumValues, String description) {
      return def(key, aliases, kind, getter, setter, enumValues, description, (String)null);
   }

   private static SettingDef def(String key, String[] aliases, Kind kind, Function<GameplaySettingsScope, String> getter, BiConsumer<GameplaySettingsScope, String> setter, String[] enumValues, String description, String rangeHint) {
      return new SettingDef(key, aliases, kind, getter, setter, enumValues, description, rangeHint);
   }

   static {
      SETTINGS = withTechniques(List.of(def("riptideanywhere", new String[]{"riptide_anywhere", "dryriptide", "riptide"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.riptideAnywhere()), (s, v) -> s.setRiptideAnywhere(parseBool(v, s.riptideAnywhere())), (String[])null, "Riptide without rain/water (Trident Mace on dry ground)"), def("equiparmor", new String[]{"equip_armor", "armor"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.equipArmor()), (s, v) -> s.setEquipArmor(parseBool(v, s.equipArmor())), (String[])null, "Auto-equip better armour from inventory"), def("revengemode", new String[]{"revenge", "revenge_mode"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.revengeMode()), (s, v) -> s.setRevengeMode(parseBool(v, s.revengeMode())), (String[])null, "Retaliate when a player hits the bot"), def("bunnyhop", new String[]{"bunny_hop", "bhop"}, SettingsCli.Kind.ENUM, (s) -> s.bunnyHopMode().name().toLowerCase(Locale.ROOT), (s, v) -> s.setBunnyHopMode((BotSettings.BunnyHopMode)parseEnum(v, BotSettings.BunnyHopMode.class, "bunnyhop")), enumNames(BotSettings.BunnyHopMode.class), "Sprint-jump: off, on, smart"), def("retreat", new String[]{"retreattoheal", "heal"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.retreat()), (s, v) -> s.setRetreat(parseBool(v, s.retreat())), (String[])null, "Flee combat to eat when HP is low"), def("retreattohealthreshold", new String[]{"healthreshold", "retreathearts", "healhearts"}, SettingsCli.Kind.NUMBER, (s) -> hearts(s.retreatHealthHearts()), (s, v) -> s.setRetreatHealthHearts(parseHearts(v)), (String[])null, "Hearts left at which the bot retreats to heal (0.5–10, default 4)"), def("targetplayers", new String[]{"target_players", "players"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.targetPlayers()), (s, v) -> {
         s.setTargetPlayers(parseBool(v, s.targetPlayers()));
         s.reconcileAutoTarget();
      }, (String[])null, "Auto-target includes real players"), def("autotarget", new String[]{"auto_target"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.autoTarget()), (s, v) -> {
         boolean next = parseBool(v, s.autoTarget());
         if (next && !s.targetPlayers() && !s.targetBots() && !s.targetMobs()) {
            throw new IllegalArgumentException("Enable targetplayers, targetbots, or targetmobs first.");
         } else {
            s.setAutoTarget(next);
         }
      }, (String[])null, "Hunt automatically when no team directive"), def("targetbots", new String[]{"target_bots", "bots"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.targetBots()), (s, v) -> {
         s.setTargetBots(parseBool(v, s.targetBots()));
         s.reconcileAutoTarget();
      }, (String[])null, "Auto-target includes other VexBots"), def("targetmobs", new String[]{"target_mobs", "mobs"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.targetMobs()), (s, v) -> {
         s.setTargetMobs(parseBool(v, s.targetMobs()));
         s.reconcileAutoTarget();
      }, (String[])null, "Auto-target includes hostile mobs"), def("usepotions", new String[]{"potions", "use_potions"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.usePotions()), (s, v) -> s.setUsePotions(parseBool(v, s.usePotions())), (String[])null, "Pot up, re-pot, splash heal when low"), def("carting", new String[]{"usecarting", "use_carting", "tntcarting"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useCarting()), (s, v) -> s.setUseCarting(parseBool(v, s.useCarting())), (String[])null, "TNT minecart PvP when items are available"), def("stats", new String[]{"telemetry", "livestats"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.statsEnabled()), (s, v) -> s.setStatsEnabled(parseBool(v, s.statsEnabled())), (String[])null, "Anonymous usage stats for the public VexBot stats page (mods.icondice.org/vexbot/stats): bots online, kills, deaths, damage, blocks, armour, totems, teams, command and add-on names, the most-used bot names. Never player names, UUIDs, IPs, coordinates or chat. Global, ON by default"), def("attackrange", new String[]{"attack_range", "reach", "meleerange", "melee_range"}, SettingsCli.Kind.NUMBER, (s) -> {
         String var10000 = String.format(Locale.ROOT, "%.2f", s.attackRange());
         return var10000 + (Math.abs(s.attackRange() - (double)3.0F) < 1.0E-6 ? " (vanilla)" : "");
      }, (s, v) -> s.setAttackRange(parseAttackRange(v)), (String[])null, "Melee reach in blocks (1.0–6.0, default 3.0 = vanilla; \"default\" resets it)", "1.0–6.0 (blocks), or \"default\""), def("bridgemode", new String[]{"bridge_mode", "bridge", "bridging"}, SettingsCli.Kind.ENUM, (s) -> s.bridgeMode().name().toLowerCase(Locale.ROOT), (s, v) -> s.setBridgeMode(parseBridgeMode(v)), new String[]{"ninja", "god", "moonwalk"}, "How bots bridge a gap: ninja (crouch backwards, safest), god (sprint forwards, fast), moonwalk (sideways)"), def("cartmode", new String[]{"cart_mode", "cart"}, SettingsCli.Kind.ENUM, (s) -> cartModeLabel(s.cartMode()), (s, v) -> s.setCartMode(parseCartMode(v)), new String[]{"smart", "precart", "pre_rail", "prerail", "instacart", "xbow_cart", "xbowcart"}, "Cart sequence: smart (picks per cart), precart, pre_rail, instacart, xbow_cart"), def("wander", new String[]{"wanderwhenidle", "wander_when_idle"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.wanderWhenIdle()), (s, v) -> s.setWanderWhenIdle(parseBool(v, s.wanderWhenIdle())), (String[])null, "Wander within 10 blocks when idle"), def("ignorecreative", new String[]{"ignore_creative", "creative"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.ignoreCreative()), (s, v) -> s.setIgnoreCreative(parseBool(v, s.ignoreCreative())), (String[])null, "Do not attack creative-mode players"), def("gamelogs", new String[]{"gamelog", "logs", "logging", "loglevel", "log_level"}, SettingsCli.Kind.ENUM, (s) -> s.gameLogs().name().toLowerCase(Locale.ROOT), (s, v) -> s.setGameLogs(parseGameLogs(v, s.gameLogs())), new String[]{"detailed", "brief", "simple"}, "How much VexBot writes to the server log: detailed (the play-by-play — every step of a regear, a status line per bot every 5s), brief (one line per thing that actually happens — the default), simple (warnings and errors only). Warnings and errors always show, whatever this is set to (GLOBAL)"), def("botdontleave", new String[]{"dontleave", "keepbots", "persistbots", "botspersist"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.botDontLeave()), (s, v) -> s.setBotDontLeave(parseBool(v, s.botDontLeave())), (String[])null, "Bots survive a world restart — gear, position and health are saved on exit and restored on the next start (GLOBAL, applies to every bot)"), def("botadvancements", new String[]{"bot_advancements", "advancements"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.botAdvancements()), (s, v) -> s.setBotAdvancements(parseBool(v, s.botAdvancements())), (String[])null, "Bots earn advancements like players (GLOBAL). Default OFF: each bot item swap re-checked ~1,300 advancement criteria — a big share of the server tick with many bots"), def("botspawnmobs", new String[]{"bot_spawn_mobs", "botsspawnmobs", "botmobspawning"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.botSpawnMobs()), (s, v) -> s.setBotSpawnMobs(parseBool(v, s.botSpawnMobs())), (String[])null, "Mobs spawn around bots like around players (GLOBAL, default ON — bots keep mob farms running). OFF = only real players make mobs spawn: much cheaper with many bots"), def("enderpearl", new String[]{"useenderpearl", "use_ender_pearl", "pearl"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useEnderPearl()), (s, v) -> s.setUseEnderPearl(parseBool(v, s.useEnderPearl())), (String[])null, "Pearl away instead of retreating on foot when low HP"), def("pearlchasing", new String[]{"pearlchase", "chasepearl", "offensivepearl"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.pearlChasing()), (s, v) -> s.setPearlChasing(parseBool(v, s.pearlChasing())), (String[])null, "Pearl toward the target to close distance (pearl chasing)"), def("botleaveondeath", new String[]{"leaveondeath", "leaveonkill", "removeondeath", "kickondeath"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.botLeaveOnDeath()), (s, v) -> s.setBotLeaveOnDeath(parseBool(v, s.botLeaveOnDeath())), (String[])null, "Bot disconnects when killed (off = it respawns and keeps playing)"), def("kitpotiondosplash", new String[]{"kitpotionsplash", "splashkit", "kitsplash"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.kitPotionDoSplash()), (s, v) -> s.setKitPotionDoSplash(parseBool(v, s.kitPotionDoSplash())), (String[])null, "Throw Kit Potions as splashes — everyone in range gets the kit (off = right-click restocks you)"), def("gotomining", new String[]{"gotomine", "gotodig", "marchmining"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.gotoMining()), (s, v) -> s.setGotoMining(parseBool(v, s.gotoMining())), (String[])null, "/vexbot goto and team goto mine through blocks in the way (off = walk, climb and swim only)"), def("advancedspawn", new String[]{"kitspawn", "spawnwithkit", "advspawn"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.advancedSpawn()), (s, v) -> s.setAdvancedSpawn(parseBool(v, s.advancedSpawn())), (String[])null, "Enable /vexbot spawn <name> <pos> <kit> and /vexbot team <team> massspawn <amount> <kit|randomgear>"), def("silent", new String[]{"silentcommands", "quiet", "nomessages"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.silentCommands()), (s, v) -> s.setSilentCommands(parseBool(v, s.silentCommands())), (String[])null, "Suppress VexBot command confirmation messages (commands run with no chat feedback)"), def("orbitalstrike", new String[]{"orbital", "osc", "orbitalstrikecannon"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useOrbitalStrike()), (s, v) -> s.setUseOrbitalStrike(parseBool(v, s.useOrbitalStrike())), (String[])null, "§cVERY DESTRUCTIVE§r — bots FIRE an Orbital Strike Cannon rod if their kit has one. Works with both OSC datapacks (Stepan1411's, and Orbital Strike Cannon Datapack & Mod: Nuke, Stab, Law-Nuke, Wither Nuke, Arrow Shot, Wolf Rod). Nukes are fired from 32+ blocks and the bot runs from the strike"), def("buildup", new String[]{"scaffold", "scaffolding", "towerup"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useScaffolding()), (s, v) -> s.setUseScaffolding(parseBool(v, s.useScaffolding())), (String[])null, "Bots build to elevated targets that built/flew up (never to wind-charge launches)"), def("nametagcolour", new String[]{"nametagcolor", "namecolour", "namecolor", "tagcolour", "tagcolor"}, SettingsCli.Kind.ENUM, (s) -> s.nameTagColour(), (s, v) -> s.setNameTagColour(NameTagColour.parse(v)), NameTagColour.suggestions(), "Colour of the floating nametag: a colour name (red, teal, crimson, lavender …) or none"), def("pearlcatchtype", new String[]{"pearlcatch_type", "pearltype", "catchtype"}, SettingsCli.Kind.ENUM, (s) -> s.pearlCatchType().name().toLowerCase(Locale.ROOT), (s, v) -> s.setPearlCatchType(parsePearlCatchType(v)), new String[]{"smart", "standard", "higher", "instant", "angle"}, "Which pearl catch the bot does. §esmart§r is the default and picking anything else is NOT RECOMMENDED — smart chooses per situation and will beat a fixed choice: right on top of you and grounded it uses standard, far out it uses angle and hands the descent to the spear dash, and the rest of the time it uses higher for the most height. The fixed ones: standard = straight up, pearl then charge. higher = charge its own feet first, then throw at the PEAK of that launch. instant = charge in the offhand, both throws back to back, for finishing someone low. angle = aim at them instead of straight up, landing out over them. Wall catches are automatic in all of them"), def("chorusescape", new String[]{"chorus", "chorusfruit", "chorusteleport"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.chorusEscape()), (s, v) -> s.setChorusEscape(parseBool(v, s.chorusEscape())), (String[])null, "Bots trapped in a cobweb and boxed in eat a chorus fruit (if they have one) to teleport out"), def("fireescape", new String[]{"firebucket", "escapefire", "lavaescape", "waterdouse"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.fireEscape()), (s, v) -> s.setFireEscape(parseBool(v, s.fireEscape())), (String[])null, "Burning bots with no Fire Resistance water-bucket their own feet to douse, then take the water back (default off)"), def("enderchestregear", new String[]{"enderregear", "ender_chest_regear", "echestregear"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.enderChestRegear()), (s, v) -> s.setEnderChestRegear(parseBool(v, s.enderChestRegear())), (String[])null, "Regear out of the ENDER CHEST, the way it is done on an SMP: pearl away, put the chest down beside itself, take the shulker out, restock from it, put the shulker back and take the chest with it. It waits for room before opening anything and breaks off if the opponent closes in. Needs an ender chest in the bag and a useful shulker inside it. Default ON"), def("shulkersteal", new String[]{"stealshulker", "shulker_steal", "raidshulker"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.shulkerSteal()), (s, v) -> s.setShulkerSteal(parseBool(v, s.shulkerSteal())), (String[])null, "Bots mine an opponent's placed shulker box mid-resupply and take the drop"), def("webescape", new String[]{"web_escape", "cobwebescape", "escapecobwebs"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.webEscape()), (s, v) -> s.setWebEscape(parseBool(v, s.webEscape())), (String[])null, "Webbed bots escape: water bucket first, then ender pearl, then mining (head-only webs pearl out)"), def("waterbucketclutch", new String[]{"waterbucketcluch", "water_bucket_clutch", "mlgclutch", "waterclutch"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.waterBucketClutch()), (s, v) -> s.setWaterBucketClutch(parseBool(v, s.waterBucketClutch())), (String[])null, "Falling bots do a water-bucket MLG clutch to negate fall damage (difficulty 'clutch' sets the success rate)"), def("usebows", new String[]{"bows", "usebow", "bowing"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useBows()), (s, v) -> s.setUseBows(parseBool(v, s.useBows())), (String[])null, "Bot may bow/crossbow a FAR target instead of chasing (cart PvP flame-bow unaffected)"), def("cartdoctrine", new String[]{"cart_doctrine", "cartrule", "cartplay"}, SettingsCli.Kind.ENUM, (s) -> s.cartDoctrine().name().toLowerCase(Locale.ROOT), (s, v) -> s.setCartDoctrine((BotSettings.CartDoctrine)parseEnum(v, BotSettings.CartDoctrine.class, "cartdoctrine")), enumNames(BotSettings.CartDoctrine.class), "How the bot decides WHEN to cart. §erelentless§r (default) carts whenever the cooldown is up — the long-standing behaviour. Every cart TECHNIQUE (block cart, offhand cart, distance-scaled insta-cart, arrow-miss recovery, two-crossbow chains) runs in both modes. §eguide§r adds expert cart DOCTRINE on top: melee is the primary weapon and carts open a health gap or take the kill — it will not cart from sword range with no HP lead, leaves an exchange at 7 hearts, and keeps a wider self-blast distance as its health falls"), def("healing", new String[]{"healingmode", "healing_mode", "healstyle"}, SettingsCli.Kind.ENUM, (s) -> s.healingMode().name().toLowerCase(Locale.ROOT), (s, v) -> s.setHealingMode((BotSettings.HealingMode)parseEnum(v, BotSettings.HealingMode.class, "healing")), enumNames(BotSettings.HealingMode.class), "How a bot heals under pressure. §eadvanced§r (default) BUYS the gap first: a short 10-12 block pearl, or a web on the opponent, or a knockback hit to shove them off — then eats. §eold§r is the long-standing behaviour: break off and run to eat, which hands the opponent a free window"), def("offhand", new String[]{"prefer", "offhandpref", "offhand_preference"}, SettingsCli.Kind.ENUM, (s) -> s.offhandPreference().name().toLowerCase(Locale.ROOT), (s, v) -> s.setOffhandPreference((BotSettings.OffhandPreference)parseEnum(v, BotSettings.OffhandPreference.class, "offhand")), enumNames(BotSettings.OffhandPreference.class), "What the bot keeps in its off-hand. §eauto§r (default) is the old kit-dependent rule — a pure-sword bot shields while healthy and totems low down, every other kit totems always — which is why the off-hand looked inconsistent as gear changed. §etotem§r and §eshield§r are explicit and ignore the kit; §eshield§r still swaps to a totem at §eoffhandtotemhearts§r (default 4 hearts)"), def("offhandtotemhearts", new String[]{"offhand_totem_hearts", "totemhearts"}, SettingsCli.Kind.NUMBER, (s) -> hearts(s.offhandTotemHearts()), (s, v) -> s.setOffhandTotemHearts(parseHearts(v)), (String[])null, "Health, in HEARTS, at which an explicit §eshield§r off-hand preference gives way to a totem. Ignored under §eauto§r and §etotem§r"), def("strafeincombo", new String[]{"strafe_in_combo", "combostrafe"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.strafeInCombo()), (s, v) -> s.setStrafeInCombo(parseBool(v, s.strafeInCombo())), (String[])null, "Keep strafing while comboing instead of standing square to the target. Realism — a human never stops moving mid-combo. Default ON"), def("buildupminheight", new String[]{"buildup_min_height", "towerminheight", "buildupheight"}, SettingsCli.Kind.NUMBER, (s) -> String.valueOf(s.buildUpMinHeight()), (s, v) -> s.setBuildUpMinHeight(Math.max((double)1.0F, Math.min((double)32.0F, parseNumber(v)))), (String[])null, "How far ABOVE the bot a target must be before buildup towers at it (1-32, default 4). Lower it and bots tower at someone standing on a single block", "1–32 (blocks)"), def("botping", new String[]{"bot_ping", "bot-ping", "ping", "latency"}, SettingsCli.Kind.NUMBER, (s) -> s.botPing() + " ms", (s, v) -> s.setBotPing((int)Math.round(Math.max((double)0.0F, Math.min((double)5000.0F, parseNumber(v.replaceAll("(?i)\\s*ms$", "")))))), (String[])null, "The ping bots show in the tab list, in milliseconds (0-5000, default 0). Only what the tab list shows - the bots do not play any slower", "0–5000 (ms)"), def("placeblocksmoving", new String[]{"place_blocks_moving", "placeblockswhilemoving", "jumpplace", "blockhop"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.placeBlocksMoving()), (s, v) -> s.setPlaceBlocksMoving(parseBool(v, s.placeBlocksMoving())), (String[])null, "On a long run to its target (over 20 blocks) the bot sprint-jumps and places a block where each jump lands, lands on it and jumps off it — until it is 7 blocks away. Uses ordinary building blocks, never obsidian, anchors or glowstone. Default OFF"), def("chasespread", new String[]{"chase_spread", "spreadout", "spread"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.chaseSpread()), (s, v) -> s.setChaseSpread(parseBool(v, s.chaseSpread())), (String[])null, "Bots running in on the same target spread out side by side instead of one clump — about 2 blocks apart from 17 blocks out, closing up by 7 blocks so the fight itself is unchanged. Default ON"), def("macetotem", new String[]{"mace_totem", "macetotemguard", "totemonmacedive", "maceland"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.maceTotem()), (s, v) -> s.setMaceTotem(parseBool(v, s.maceTotem())), (String[])null, "When someone is about to land on the bot with a mace (elytra mace, wind charge drop, a fall) and its offhand has no totem, it holds a totem in its main hand until they land. A totem already in the offhand needs nothing. Default ON"), def("speednojump", new String[]{"speed_no_jump", "speed2nojump", "nojumpspeed", "speednohop"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.speedNoJump()), (s, v) -> s.setSpeedNoJump(parseBool(v, s.speedNoJump())), (String[])null, "Bots with Speed II or higher run instead of sprint-jumping while chasing or following: at that speed a sprint is faster than a sprint-jump. Jumps over blocks, crits and jump resets still happen. Default ON"), def("doblockexplosion", new String[]{"do_block_explosion", "blockexplosion", "blockexplosions", "explosionblockdamage"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.doBlockExplosion()), (s, v) -> s.setDoBlockExplosion(parseBool(v, s.doBlockExplosion())), (String[])null, "Whether explosions someone sets off break blocks: end crystals, respawn anchors, beds and TNT. Off = they still hurt, but no block breaks and no fire. The global setting covers every real player and bot NOT on a team; a team's own setting covers its members. Default ON"), def("lootpackradius", new String[]{"loot_pack_radius", "shulkerloot", "packloot"}, SettingsCli.Kind.NUMBER, (s) -> String.valueOf(s.lootPackRadius()), (s, v) -> s.setLootPackRadius(Math.max((double)0.0F, Math.min((double)256.0F, parseNumber(v)))), (String[])null, "How far around itself a bot must see NO enemy before it packs surplus loot into an empty shulker box instead of dropping it (0-256, default 100). §e0§r turns the packing off", "0–256 (blocks)"), def("pickuploot", new String[]{"pickup_loot", "lootpickup", "takeloot", "pickup"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.pickupLoot()), (s, v) -> s.setPickupLoot(parseBool(v, s.pickupLoot())), (String[])null, "Bots pick items up off the ground: FFA loot runs, kill-drop hoovering, walking to a better dropped armour piece, and plain walk-over pickup. Turn it OFF and a bot takes nothing off the floor — it will not eat the items you dropped. Default ON"), def("hitweb", new String[]{"hit_web", "knockbackweb", "webhit"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.hitWeb()), (s, v) -> s.setHitWeb(parseBool(v, s.hitWeb())), (String[])null, "When webbing, 50% chance to KNOCKBACK-hit the opponent then place the web where they'll land (instead of a normal web)"), def("fastshield", new String[]{"fastshieldcooldown", "fast_shield_cooldown", "shieldcd"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.fastShieldCooldown()), (s, v) -> s.setFastShieldCooldown(parseBool(v, s.fastShieldCooldown())), (String[])null, "Shield disable cooldown 2.5s instead of 5s"), def("speardash", new String[]{"use_spear_dash", "spear"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useSpearDash()), (s, v) -> s.setUseSpearDash(parseBool(v, s.useSpearDash())), (String[])null, "Horizontal spear dash at wind-charge apex"), def("backstab", new String[]{"backstabbing", "back_stab"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useBackstab()), (s, v) -> s.setUseBackstab(parseBool(v, s.useBackstab())), (String[])null, "Beat a raised shield by getting BEHIND it instead of stunning it: spear-dash past the target, turn 180° and mace their back. The easier answer to a shield. Turning this ON turns stunslam OFF — they are alternatives, and a bot cannot commit to both"), def("stunslam", new String[]{"stun_slam", "stun"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useStunSlam()), (s, v) -> s.setUseStunSlam(parseBool(v, s.useStunSlam())), (String[])null, "Axe-disable a raised shield, then smash through it. Turning this ON turns backstab OFF — they are alternatives"), def("stunslamchance", new String[]{"stun_slam_chance", "stunslampercent", "stun_slam_percent"}, SettingsCli.Kind.PERCENT, (s) -> s.stunSlamChance() + "%", (s, v) -> s.setStunSlamChance(parsePercent(v)), (String[])null, "Stun slam attempt chance (0–100%) when stun slam is enabled"), def("webdrain", new String[]{"web_drain", "drain"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useWebDrain()), (s, v) -> s.setUseWebDrain(parseBool(v, s.useWebDrain())), (String[])null, "Scoop a webbed target's escape water with an empty bucket"), def("webdrainchance", new String[]{"web_drain_chance", "webdrainpercent", "web_drain_percent"}, SettingsCli.Kind.PERCENT, (s) -> s.webDrainChance() + "%", (s, v) -> s.setWebDrainChance(parsePercent(v)), (String[])null, "Web drain chance (0–100%) per opportunity when web drain is enabled"), def("jumpresetchance", new String[]{"jump_reset_chance", "jumpreset", "jump_reset"}, SettingsCli.Kind.PERCENT, (s) -> s.jumpResetChance() + "%", (s, v) -> s.setJumpResetChance(parsePercent(v)), (String[])null, "Jump-reset chance (0–100%): jump before the opponent's hit to cut knockback taken"), def("counterstunchance", new String[]{"counter_stun_chance", "counterstun", "counter_stun"}, SettingsCli.Kind.PERCENT, (s) -> s.counterStunChance() + "%", (s, v) -> s.setCounterStunChance(parsePercent(v)), (String[])null, "Counter-stun chance (0–100%): fly out (jump + S) of a hard incoming hit"), def("shieldmacedive", new String[]{"shield_on_mace_dive", "shieldmace", "macedive"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.shieldOnMaceDive()), (s, v) -> s.setShieldOnMaceDive(parseBool(v, s.shieldOnMaceDive())), (String[])null, "Raise shield against incoming fall attacks"), def("pearlcatch", new String[]{"use_pearl_catch", "pearl_catch"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.usePearlCatch()), (s, v) -> s.setUsePearlCatch(parseBool(v, s.usePearlCatch())), (String[])null, "Wind charge + pearl stack for bigger mace falls"), def("elytraglide", new String[]{"elytra_glide", "glide"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.elytraGlide()), (s, v) -> s.setElytraGlide(parseBool(v, s.elytraGlide())), (String[])null, "Pearl-catch glides the elytra onto far targets before smashing"), def("usecobwebs", new String[]{"cobwebs", "use_cobwebs"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useCobwebs()), (s, v) -> s.setUseCobwebs(parseBool(v, s.useCobwebs())), (String[])null, "Place cobwebs to slow targets"), def("elytramace", new String[]{"useelytramace", "use_elytra_mace", "elytra"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useElytraMace()), (s, v) -> s.setUseElytraMace(parseBool(v, s.useElytraMace())), (String[])null, "Elytra + wind charge mace dive combo"), def("elytraspear", new String[]{"useelytraspear", "use_elytra_spear", "spearfly"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.useElytraSpear()), (s, v) -> s.setUseElytraSpear(parseBool(v, s.useElytraSpear())), (String[])null, "Elytra + rocket spear charge-attack fly-through"), def("shulker-regear", new String[]{"shulkerregear", "shulker_regear", "regearshulker", "regear-shulker", "boxregear"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.shulkerRegear()), (s, v) -> s.setShulkerRegear(parseBool(v, s.shulkerRegear())), (String[])null, "Break off and regear from a shulker box the bot is CARRYING: retreat, place the box, take what it needs, mine the box back up. Also fires when the box holds a straight upgrade - a better armour piece than the one worn, or a totem when the bot has none - not only when a supply has run low. Off leaves the bot to fight with what it is holding, and disables the ender-chest regear with it. Default ON"), def("tags", new String[]{"tag", "nametags", "nametag", "prefixtags", "showtags"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.showTags()), (s, v) -> {
         s.setShowTags(parseBool(v, s.showTags()));
         NameTagPainter.repaint();
      }, (String[])null, "Bold prefix tags on floating nametags: light-blue BOT on every bot, yellow DEV on the developers. Also toggled with /vexbot tag on|off. Default OFF"), def("spread-out", new String[]{"spreadout", "spread_out", "disperse", "nozerg"}, SettingsCli.Kind.BOOL, (s) -> onOff(s.spreadOut()), (s, v) -> s.setSpreadOut(parseBool(v, s.spreadOut())), (String[])null, "With more than 100 bots on a team, the team forms up in a rectangle behind its target while CHASING instead of collapsing into one pile. Drops the formation and fights normally the moment anyone is in contact. Per team: /vexbot team <team> spread-out true|false. Default OFF")));
      BY_KEY = new LinkedHashMap();

      for(SettingDef def : SETTINGS) {
         BY_KEY.put(normalize(def.key), def);

         for(String alias : def.aliases) {
            BY_KEY.put(normalize(alias), def);
         }
      }

   }

   private static enum Kind {
      BOOL,
      ENUM,
      PERCENT,
      STRING,
      NUMBER;

      // $FF: synthetic method
      private static Kind[] $values() {
         return new Kind[]{BOOL, ENUM, PERCENT, STRING, NUMBER};
      }
   }

   private static record SettingDef(String key, String[] aliases, Kind kind, Function<GameplaySettingsScope, String> getter, BiConsumer<GameplaySettingsScope, String> setter, String[] enumValues, String description, String rangeHint) {
   }

   public static record Entry(String key, String kind, String description, List<String> values, String value) {
   }
}
