package vexbot.settings;

import net.minecraft.server.MinecraftServer;
import vexbot.BotSettings;
import vexbot.DifficultyParams;
import vexbot.SettingsPersistence;
import vexbot.stats.Stats;
import vexbot.team.TeamManager;
import vexbot.util.NameTagPainter;

public final class GameplaySettingsScope {
   private final String teamName;

   private GameplaySettingsScope(String teamName) {
      this.teamName = teamName;
   }

   public static GameplaySettingsScope global() {
      return new GameplaySettingsScope((String)null);
   }

   public static GameplaySettingsScope forTeam(String teamName) {
      return new GameplaySettingsScope(teamName);
   }

   public boolean isTeamScope() {
      return this.teamName != null;
   }

   public String teamName() {
      return this.teamName;
   }

   public String scopeLabel() {
      return this.teamName != null ? "team §e" + this.teamName + "§r" : "global";
   }

   public TeamManager.BotTeam team() {
      return this.teamName == null ? null : TeamManager.get(this.teamName);
   }

   public boolean teamExists() {
      return this.teamName == null || TeamManager.exists(this.teamName);
   }

   public void ensureTeam() {
      if (this.teamName != null) {
         TeamManager.getOrCreate(this.teamName);
      }

   }

   public boolean equipArmor() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.equipArmor : BotSettings.equipArmor;
   }

   public void setEquipArmor(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.equipArmor = v;
      } else {
         BotSettings.equipArmor = v;
      }

   }

   public boolean revengeMode() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.revengeMode : BotSettings.revengeMode;
   }

   public void setRevengeMode(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.revengeMode = v;
      } else {
         BotSettings.revengeMode = v;
      }

   }

   public BotSettings.BunnyHopMode bunnyHopMode() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.bunnyHopMode : BotSettings.bunnyHopMode;
   }

   public void setBunnyHopMode(BotSettings.BunnyHopMode m) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.bunnyHopMode = m;
      } else {
         BotSettings.bunnyHopMode = m;
      }

   }

   public boolean retreat() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.retreat : BotSettings.retreat;
   }

   public void setRetreat(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.retreat = v;
      } else {
         BotSettings.retreat = v;
      }

   }

   public boolean targetPlayers() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.targetPlayers : BotSettings.targetPlayers;
   }

   public void setTargetPlayers(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.targetPlayers = v;
      } else {
         BotSettings.targetPlayers = v;
      }

   }

   public boolean autoTarget() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.autoTarget : BotSettings.autoTarget;
   }

   public void setAutoTarget(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.autoTarget = v;
      } else {
         BotSettings.autoTarget = v;
      }

   }

   public boolean targetBots() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.targetBots : BotSettings.targetBots;
   }

   public void setTargetBots(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.targetBots = v;
      } else {
         BotSettings.targetBots = v;
      }

   }

   public boolean targetMobs() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.targetMobs : BotSettings.targetMobs;
   }

   public void setTargetMobs(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.targetMobs = v;
      } else {
         BotSettings.targetMobs = v;
      }

   }

   public boolean usePotions() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.usePotions : BotSettings.usePotions;
   }

   public void setUsePotions(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.usePotions = v;
      } else {
         BotSettings.usePotions = v;
      }

   }

   public BotSettings.Difficulty difficulty() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.difficulty : BotSettings.difficulty;
   }

   public void setDifficulty(BotSettings.Difficulty d) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.difficulty = d;
         t.difficultyParams = DifficultyParams.forPreset(d);
      } else {
         BotSettings.difficulty = d;
         BotSettings.difficultyParams = DifficultyParams.forPreset(d);
      }

   }

   public DifficultyParams difficultyParams() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.difficultyParams : BotSettings.difficultyParams;
   }

   public boolean useCarting() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useCarting : BotSettings.useCarting;
   }

   public void setUseCarting(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useCarting = v;
      } else {
         BotSettings.useCarting = v;
      }

   }

   public boolean statsEnabled() {
      return BotSettings.statsEnabled;
   }

   public void setStatsEnabled(boolean v) {
      BotSettings.statsEnabled = v;
      if (!v) {
         Stats.clear();
      }

   }

   public double attackRange() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.attackRange : BotSettings.attackRange;
   }

   public void setAttackRange(double r) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.attackRange = r;
      } else {
         BotSettings.attackRange = r;
      }

   }

   public BotSettings.BridgeMode bridgeMode() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.bridgeMode : BotSettings.bridgeMode;
   }

   public void setBridgeMode(BotSettings.BridgeMode m) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.bridgeMode = m;
      } else {
         BotSettings.bridgeMode = m;
      }

   }

   public BotSettings.CartMode cartMode() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.cartMode : BotSettings.cartMode;
   }

   public void setCartMode(BotSettings.CartMode m) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.cartMode = m;
      } else {
         BotSettings.cartMode = m;
      }

   }

   public boolean wanderWhenIdle() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.wanderWhenIdle : BotSettings.wanderWhenIdle;
   }

   public void setWanderWhenIdle(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.wanderWhenIdle = v;
      } else {
         BotSettings.wanderWhenIdle = v;
      }

   }

   public boolean ignoreCreative() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.ignoreCreative : BotSettings.ignoreCreative;
   }

   public void setIgnoreCreative(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.ignoreCreative = v;
      } else {
         BotSettings.ignoreCreative = v;
      }

   }

   public BotSettings.GameLogs gameLogs() {
      return BotSettings.gameLogs;
   }

   public void setGameLogs(BotSettings.GameLogs v) {
      BotSettings.gameLogs = v;
   }

   public boolean botAdvancements() {
      return BotSettings.botAdvancements;
   }

   public void setBotAdvancements(boolean v) {
      BotSettings.botAdvancements = v;
   }

   public boolean botSpawnMobs() {
      return BotSettings.botSpawnMobs;
   }

   public void setBotSpawnMobs(boolean v) {
      BotSettings.botSpawnMobs = v;
   }

   public boolean botDontLeave() {
      return BotSettings.botDontLeave;
   }

   public void setBotDontLeave(boolean v) {
      BotSettings.botDontLeave = v;
   }

   public boolean useEnderPearl() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useEnderPearl : BotSettings.useEnderPearl;
   }

   public void setUseEnderPearl(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useEnderPearl = v;
      } else {
         BotSettings.useEnderPearl = v;
      }

   }

   public boolean pearlChasing() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.pearlChasing : BotSettings.pearlChasing;
   }

   public void setPearlChasing(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.pearlChasing = v;
      } else {
         BotSettings.pearlChasing = v;
      }

   }

   public boolean botLeaveOnDeath() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.botLeaveOnDeath : BotSettings.botLeaveOnDeath;
   }

   public void setBotLeaveOnDeath(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.botLeaveOnDeath = v;
      } else {
         BotSettings.botLeaveOnDeath = v;
      }

   }

   public boolean useScaffolding() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useScaffolding : BotSettings.useScaffolding;
   }

   public void setUseScaffolding(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useScaffolding = v;
      } else {
         BotSettings.useScaffolding = v;
      }

   }

   public boolean chorusEscape() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.chorusEscape : BotSettings.chorusEscape;
   }

   public void setChorusEscape(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.chorusEscape = v;
      } else {
         BotSettings.chorusEscape = v;
      }

   }

   public boolean fireEscape() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.fireEscape : BotSettings.fireEscape;
   }

   public void setFireEscape(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.fireEscape = v;
      } else {
         BotSettings.fireEscape = v;
      }

   }

   public boolean shulkerSteal() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.shulkerSteal : BotSettings.shulkerSteal;
   }

   public void setShulkerSteal(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.shulkerSteal = v;
      } else {
         BotSettings.shulkerSteal = v;
      }

   }

   public boolean enderChestRegear() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.enderChestRegear : BotSettings.enderChestRegear;
   }

   public void setEnderChestRegear(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.enderChestRegear = v;
      } else {
         BotSettings.enderChestRegear = v;
      }

   }

   public boolean spreadOut() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.spreadOut : BotSettings.spreadOut;
   }

   public void setSpreadOut(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.spreadOut = v;
      } else {
         BotSettings.spreadOut = v;
      }

   }

   public boolean showTags() {
      return BotSettings.showTags;
   }

   public void setShowTags(boolean v) {
      BotSettings.showTags = v;
   }

   public boolean shulkerRegear() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.shulkerRegear : BotSettings.shulkerRegear;
   }

   public void setShulkerRegear(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.shulkerRegear = v;
      } else {
         BotSettings.shulkerRegear = v;
      }

   }

   public boolean webEscape() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.webEscape : BotSettings.webEscape;
   }

   public void setWebEscape(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.webEscape = v;
      } else {
         BotSettings.webEscape = v;
      }

   }

   public boolean waterBucketClutch() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.waterBucketClutch : BotSettings.waterBucketClutch;
   }

   public void setWaterBucketClutch(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.waterBucketClutch = v;
      } else {
         BotSettings.waterBucketClutch = v;
      }

   }

   public boolean hitWeb() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.hitWeb : BotSettings.hitWeb;
   }

   public void setHitWeb(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.hitWeb = v;
      } else {
         BotSettings.hitWeb = v;
      }

   }

   public BotSettings.HealingMode healingMode() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.healingMode : BotSettings.healingMode;
   }

   public void setHealingMode(BotSettings.HealingMode v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.healingMode = v;
      } else {
         BotSettings.healingMode = v;
      }

   }

   public BotSettings.OffhandPreference offhandPreference() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.offhandPreference : BotSettings.offhandPreference;
   }

   public void setOffhandPreference(BotSettings.OffhandPreference v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.offhandPreference = v;
      } else {
         BotSettings.offhandPreference = v;
      }

   }

   public double offhandTotemHearts() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.offhandTotemHearts : BotSettings.offhandTotemHearts;
   }

   public void setOffhandTotemHearts(double v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.offhandTotemHearts = v;
      } else {
         BotSettings.offhandTotemHearts = v;
      }

   }

   public boolean strafeInCombo() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.strafeInCombo : BotSettings.strafeInCombo;
   }

   public void setStrafeInCombo(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.strafeInCombo = v;
      } else {
         BotSettings.strafeInCombo = v;
      }

   }

   public int botPing() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.botPing : BotSettings.botPing;
   }

   public void setBotPing(int v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.botPing = v;
      } else {
         BotSettings.botPing = v;
      }

   }

   public boolean placeBlocksMoving() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.placeBlocksMoving : BotSettings.placeBlocksMoving;
   }

   public void setPlaceBlocksMoving(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.placeBlocksMoving = v;
      } else {
         BotSettings.placeBlocksMoving = v;
      }

   }

   public boolean chaseSpread() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.chaseSpread : BotSettings.chaseSpread;
   }

   public void setChaseSpread(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.chaseSpread = v;
      } else {
         BotSettings.chaseSpread = v;
      }

   }

   public boolean maceTotem() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.maceTotem : BotSettings.maceTotem;
   }

   public void setMaceTotem(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.maceTotem = v;
      } else {
         BotSettings.maceTotem = v;
      }

   }

   public boolean speedNoJump() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.speedNoJump : BotSettings.speedNoJump;
   }

   public void setSpeedNoJump(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.speedNoJump = v;
      } else {
         BotSettings.speedNoJump = v;
      }

   }

   public boolean doBlockExplosion() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.doBlockExplosion : BotSettings.doBlockExplosion;
   }

   public void setDoBlockExplosion(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.doBlockExplosion = v;
      } else {
         BotSettings.doBlockExplosion = v;
      }

   }

   public double buildUpMinHeight() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.buildUpMinHeight : BotSettings.buildUpMinHeight;
   }

   public void setBuildUpMinHeight(double v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.buildUpMinHeight = v;
      } else {
         BotSettings.buildUpMinHeight = v;
      }

   }

   public double lootPackRadius() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.lootPackRadius : BotSettings.lootPackRadius;
   }

   public void setLootPackRadius(double v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.lootPackRadius = v;
      } else {
         BotSettings.lootPackRadius = v;
      }

   }

   public boolean pickupLoot() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.pickupLoot : BotSettings.pickupLoot;
   }

   public void setPickupLoot(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.pickupLoot = v;
      } else {
         BotSettings.pickupLoot = v;
      }

   }

   public BotSettings.CartDoctrine cartDoctrine() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.cartDoctrine : BotSettings.cartDoctrine;
   }

   public void setCartDoctrine(BotSettings.CartDoctrine v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.cartDoctrine = v;
      } else {
         BotSettings.cartDoctrine = v;
      }

   }

   public boolean useBows() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useBows : BotSettings.useBows;
   }

   public void setUseBows(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useBows = v;
      } else {
         BotSettings.useBows = v;
      }

   }

   public boolean useOrbitalStrike() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useOrbitalStrike : BotSettings.useOrbitalStrike;
   }

   public void setUseOrbitalStrike(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useOrbitalStrike = v;
      } else {
         BotSettings.useOrbitalStrike = v;
      }

   }

   public double retreatHealthHearts() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.retreatHealthHearts : BotSettings.retreatHealthHearts;
   }

   public void setRetreatHealthHearts(double v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.retreatHealthHearts = v;
      } else {
         BotSettings.retreatHealthHearts = v;
      }

   }

   public boolean kitPotionDoSplash() {
      return BotSettings.kitPotionDoSplash;
   }

   public void setKitPotionDoSplash(boolean v) {
      BotSettings.kitPotionDoSplash = v;
   }

   public boolean gotoMining() {
      return BotSettings.gotoMining;
   }

   public void setGotoMining(boolean v) {
      BotSettings.gotoMining = v;
   }

   public boolean advancedSpawn() {
      return BotSettings.advancedSpawn;
   }

   public void setAdvancedSpawn(boolean v) {
      BotSettings.advancedSpawn = v;
   }

   public boolean silentCommands() {
      return BotSettings.silentCommands;
   }

   public void setSilentCommands(boolean v) {
      BotSettings.silentCommands = v;
   }

   public boolean nullPortalJoinTeam() {
      return BotSettings.nullPortalJoinTeam;
   }

   public void setNullPortalJoinTeam(boolean v) {
      BotSettings.nullPortalJoinTeam = v;
   }

   public String nameTagColour() {
      TeamManager.BotTeam t = this.team();
      return t != null && t.nameTagColour != null && !"none".equals(t.nameTagColour) ? t.nameTagColour : BotSettings.nameTagColour;
   }

   public void setNameTagColour(String v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.nameTagColour = v;
      } else {
         BotSettings.nameTagColour = v;
      }

      NameTagPainter.repaint();
   }

   public String nullPortalTeam() {
      return BotSettings.nullPortalTeam;
   }

   public void setNullPortalTeam(String v) {
      String t = v == null ? "" : v.trim();
      if (t.isEmpty()) {
         throw new IllegalArgumentException("Team name can't be empty.");
      } else {
         BotSettings.nullPortalTeam = t;
      }
   }

   public boolean fastShieldCooldown() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.fastShieldCooldown : BotSettings.fastShieldCooldown;
   }

   public void setFastShieldCooldown(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.fastShieldCooldown = v;
      } else {
         BotSettings.fastShieldCooldown = v;
      }

   }

   public boolean useSpearDash() {
      return this.techniqueConfig().spearDash;
   }

   public void setUseSpearDash(boolean v) {
      this.techniqueConfig().spearDash = v;
   }

   public boolean useStunSlam() {
      return this.techniqueConfig().stunSlam;
   }

   public void setUseStunSlam(boolean v) {
      this.techniqueConfig().setStunSlam(v);
   }

   public boolean useBackstab() {
      return this.techniqueConfig().backstabEnabled();
   }

   public void setUseBackstab(boolean v) {
      this.techniqueConfig().setBackstab(v);
   }

   public boolean useWebDrain() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useWebDrain : BotSettings.useWebDrain;
   }

   public void setUseWebDrain(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useWebDrain = v;
      } else {
         BotSettings.useWebDrain = v;
      }

   }

   public int webDrainChance() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.webDrainChance : BotSettings.webDrainChance;
   }

   public void setWebDrainChance(int v) {
      TeamManager.BotTeam t = this.team();
      int c = Math.max(0, Math.min(100, v));
      if (t != null) {
         t.webDrainChance = c;
      } else {
         BotSettings.webDrainChance = c;
      }

   }

   public int jumpResetChance() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.jumpResetChance : BotSettings.jumpResetChance;
   }

   public void setJumpResetChance(int v) {
      TeamManager.BotTeam t = this.team();
      int c = Math.max(0, Math.min(100, v));
      if (t != null) {
         t.jumpResetChance = c;
      } else {
         BotSettings.jumpResetChance = c;
      }

   }

   public int counterStunChance() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.counterStunChance : BotSettings.counterStunChance;
   }

   public void setCounterStunChance(int v) {
      TeamManager.BotTeam t = this.team();
      int c = Math.max(0, Math.min(100, v));
      if (t != null) {
         t.counterStunChance = c;
      } else {
         BotSettings.counterStunChance = c;
      }

   }

   public int stunSlamChance() {
      return this.difficultyParams().stunSlamChance;
   }

   public void setStunSlamChance(int v) {
      this.difficultyParams().stunSlamChance = Math.max(0, Math.min(100, v));
   }

   public boolean shieldOnMaceDive() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.shieldOnMaceDive : BotSettings.shieldOnMaceDive;
   }

   public void setShieldOnMaceDive(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.shieldOnMaceDive = v;
      } else {
         BotSettings.shieldOnMaceDive = v;
      }

   }

   public TechniqueConfig techniqueConfig() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.techniques : BotSettings.techniques;
   }

   public TechniqueConfig.PearlCatchVariant pearlCatchType() {
      return this.techniqueConfig().pearlCatchVariant;
   }

   public void setPearlCatchType(TechniqueConfig.PearlCatchVariant v) {
      this.techniqueConfig().pearlCatchVariant = v;
   }

   public boolean usePearlCatch() {
      return this.techniqueConfig().pearlCatch;
   }

   public void setUsePearlCatch(boolean v) {
      this.techniqueConfig().pearlCatch = v;
   }

   public boolean elytraGlide() {
      return this.techniqueConfig().pearlCatchGlide;
   }

   public void setElytraGlide(boolean v) {
      this.techniqueConfig().pearlCatchGlide = v;
   }

   public boolean useCobwebs() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useCobwebs : BotSettings.useCobwebs;
   }

   public void setUseCobwebs(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useCobwebs = v;
      } else {
         BotSettings.useCobwebs = v;
      }

   }

   public boolean riptideAnywhere() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.riptideAnywhere : BotSettings.riptideAnywhere;
   }

   public void setRiptideAnywhere(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.riptideAnywhere = v;
      } else {
         BotSettings.riptideAnywhere = v;
      }

   }

   public boolean useElytraMace() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useElytraMace : BotSettings.useElytraMace;
   }

   public void setUseElytraMace(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useElytraMace = v;
      } else {
         BotSettings.useElytraMace = v;
      }

   }

   public boolean useElytraSpear() {
      TeamManager.BotTeam t = this.team();
      return t != null ? t.useElytraSpear : BotSettings.useElytraSpear;
   }

   public void setUseElytraSpear(boolean v) {
      TeamManager.BotTeam t = this.team();
      if (t != null) {
         t.useElytraSpear = v;
      } else {
         BotSettings.useElytraSpear = v;
      }

   }

   public void reconcileAutoTarget() {
      if (!this.targetPlayers() && !this.targetBots() && !this.targetMobs()) {
         this.setAutoTarget(false);
      }

   }

   public void persist(MinecraftServer server) {
      SettingsPersistence.save(server);
   }
}
