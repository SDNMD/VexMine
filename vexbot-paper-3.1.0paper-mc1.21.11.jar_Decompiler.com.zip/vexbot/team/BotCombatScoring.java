package vexbot.team;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.bot.ai.ArmorEvaluator;
import vexbot.bot.ai.ItemEvaluator;

public final class BotCombatScoring {
   private static final EquipmentSlot[] ARMOR;

   private BotCombatScoring() {
   }

   public static double score(ServerPlayer bot) {
      if (bot == null) {
         return (double)0.0F;
      } else {
         double total = (double)0.0F;

         for(EquipmentSlot slot : ARMOR) {
            total += ArmorEvaluator.score(bot.getItemBySlot(slot));
         }

         total += ItemEvaluator.scoreWeapon(bot.getMainHandItem());
         ItemStack off = bot.getOffhandItem();
         if (off.is(Items.SHIELD)) {
            total += ItemEvaluator.scoreShield(off);
         } else {
            total += ItemEvaluator.scoreWeapon(off);
         }

         Inventory inv = bot.getInventory();

         for(int i = 0; i < inv.getContainerSize(); ++i) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty()) {
               if (stack.is(Items.TOTEM_OF_UNDYING)) {
                  total += (double)6.0F;
               } else if (stack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                  total += (double)4.0F;
               } else if (stack.is(Items.GOLDEN_APPLE)) {
                  ++total;
               } else if (stack.is(Items.MACE)) {
                  total += (double)12.0F;
               } else if (stack.is(Items.ELYTRA)) {
                  total += (double)5.0F;
               }
            }
         }

         return total;
      }
   }

   static {
      ARMOR = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   }
}
