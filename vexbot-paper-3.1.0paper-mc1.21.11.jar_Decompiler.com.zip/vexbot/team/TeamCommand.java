package vexbot.team;

import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;
import vexbot.SettingsPersistence;
import vexbot.bot.BotManager;
import vexbot.bot.ai.FollowFormation;
import vexbot.i18n.VexText;

public final class TeamCommand {
   private TeamCommand() {
   }

   private static TeamManager.BotTeam team(CommandSourceStack source, String name) {
      TeamManager.BotTeam t = TeamManager.get(name);
      if (t == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '" + name + "'."));
         return null;
      } else {
         return t;
      }
   }

   public static int show(CommandSourceStack source, String name) {
      TeamManager.BotTeam t = team(source, name);
      if (t == null) {
         return 0;
      } else {
         TeamTactics tc = t.tactics;
         StringBuilder sb = new StringBuilder("[VexBot] Battle orders for §e" + name + "§r:");
         sb.append("\n  formation §e").append(tc.formation.name().toLowerCase(Locale.ROOT)).append("§r  size §e").append(tc.formationSize).append("§r  spacing §e").append(String.format(Locale.ROOT, "%.1f", tc.spacing)).append("§r  speed §e").append(String.format(Locale.ROOT, "%.1fx", tc.movementSpeed));
         sb.append("\n  boss §e").append(tc.hasBoss() ? tc.boss : "none").append("§r  protect §e").append(tc.protectBoss).append("§r  focusTarget §e").append(tc.focusBossTarget).append("§r  follow §e").append(tc.followBoss);
         sb.append("\n  shields §e").append(tc.shieldBehaviour.name().toLowerCase(Locale.ROOT)).append("§r  ranged §e").append(tc.rangedPositioning.name().toLowerCase(Locale.ROOT)).append("§r  priority §e").append(tc.targetPriority.name().toLowerCase(Locale.ROOT));
         sb.append("\n  regroup §e").append((int)tc.regroupDistance).append("§r  maxFromBoss §e").append((int)tc.maxDistanceFromBoss).append("§r  horn §e").append(tc.hornArmed() ? tc.hornType + " by " + tc.hornPlayer : "off");
         String out = sb.toString();
         source.sendSuccess(() -> VexText.literal(out), false);
         return 1;
      }
   }

   public static int setFormation(CommandSourceStack source, String name, String shape, int size) {
      TeamManager.BotTeam t = team(source, name);
      if (t == null) {
         return 0;
      } else {
         FollowFormation.Type f = FollowFormation.fromString(shape);
         if (f == FollowFormation.Type.NONE && !isNoneWord(shape)) {
            source.sendFailure(VexText.literal("[VexBot] Unknown formation '§e" + shape + "§r'. Try: none, " + String.join(", ", FollowFormation.names()) + "."));
            return 0;
         } else {
            t.tactics.formation = f;
            if (size > 0) {
               t.tactics.formationSize = size;
            }

            SettingsPersistence.save(source.getServer());
            source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r formation: §e" + f.name().toLowerCase(Locale.ROOT) + "§r (size " + t.tactics.formationSize + ")."), false);
            return 1;
         }
      }
   }

   public static int setBoss(CommandSourceStack source, String name, String botName) {
      TeamManager.BotTeam t = team(source, name);
      if (t == null) {
         return 0;
      } else if (botName != null && !botName.isBlank()) {
         String resolved = BotManager.resolveCanonicalBotName(botName);
         if (resolved == null) {
            source.sendFailure(VexText.literal("[VexBot] No bot named '§e" + botName + "§r'."));
            return 0;
         } else if (t.getBotNames().stream().noneMatch((n) -> n.equalsIgnoreCase(resolved))) {
            source.sendFailure(VexText.literal("[VexBot] §e" + resolved + "§r is not on team §e" + name + "§r. Add it first."));
            return 0;
         } else {
            t.tactics.boss = resolved;
            SettingsPersistence.save(source.getServer());
            source.sendSuccess(() -> VexText.literal("[VexBot] §e" + resolved + "§r is now the boss of team §e" + name + "§r."), false);
            return 1;
         }
      } else {
         t.tactics.boss = "";
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r has no boss."), false);
         return 1;
      }
   }

   public static int setHorn(CommandSourceStack source, String name, String player, String variant, String shape) {
      TeamManager.BotTeam t = team(source, name);
      if (t == null) {
         return 0;
      } else {
         String v = TeamHornSummon.normalise(variant);
         if (!TeamHornSummon.isValidVariant(v)) {
            source.sendFailure(VexText.literal("[VexBot] '§e" + variant + "§r' is not a goat horn. Try: any, " + String.join(", ", TeamHornSummon.VARIANTS) + "."));
            return 0;
         } else {
            t.tactics.hornPlayer = player == null ? "" : player;
            t.tactics.hornType = v;
            if (shape != null && !shape.isBlank()) {
               FollowFormation.Type f = FollowFormation.fromString(shape);
               if (f == FollowFormation.Type.NONE) {
                  source.sendFailure(VexText.literal("[VexBot] '§e" + shape + "§r' is not a formation. Try: " + String.join(", ", FollowFormation.names()) + "."));
                  return 0;
               }

               t.tactics.hornFormation = f;
            }

            TeamHornSummon.forget(name);
            SettingsPersistence.save(source.getServer());
            String shown = t.tactics.hornFormation.name().toLowerCase(Locale.ROOT);
            source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r answers §e" + v + "§r horns blown by §e" + t.tactics.hornPlayer + "§r — forming up in §e" + shown + "§r."), false);
            return 1;
         }
      }
   }

   public static int clearHorn(CommandSourceStack source, String name) {
      TeamManager.BotTeam t = team(source, name);
      if (t == null) {
         return 0;
      } else {
         t.tactics.hornPlayer = "";
         t.tactics.hornType = "";
         TeamHornSummon.forget(name);
         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r no longer answers a horn."), false);
         return 1;
      }
   }

   public static int blowHornNow(CommandSourceStack source, String name) {
      TeamManager.BotTeam t = team(source, name);
      if (t == null) {
         return 0;
      } else {
         ServerPlayer who = source.getPlayer();
         String leader = who != null ? who.getName().getString() : t.tactics.hornPlayer;
         if (leader != null && !leader.isBlank()) {
            TeamHornSummon.Blow blow = TeamHornSummon.toggle(t, leader);
            int n = blow.count();
            if (blow.formedUp()) {
               source.sendSuccess(() -> VexText.literal("[VexBot] §a" + n + "§r bot(s) of team §e" + name + "§r forming up on §e" + blow.leader() + "§r."), false);
            } else {
               source.sendSuccess(() -> VexText.literal("[VexBot] §a" + n + "§r bot(s) of team §e" + name + "§r standing down."), false);
            }

            return n > 0 ? 1 : 0;
         } else {
            source.sendFailure(VexText.literal("[VexBot] Run this as a player, or bind a horn player first."));
            return 0;
         }
      }
   }

   public static int setToggle(CommandSourceStack source, String name, String key, boolean value) {
      TeamManager.BotTeam t = team(source, name);
      if (t == null) {
         return 0;
      } else {
         TeamTactics tc = t.tactics;
         switch (key) {
            case "protectboss":
               tc.protectBoss = value;
               break;
            case "focusbosstarget":
               tc.focusBossTarget = value;
               break;
            case "followboss":
               tc.followBoss = value;
               break;
            case "maintainformation":
               tc.maintainFormation = value;
               break;
            case "retreatwhenlow":
               tc.retreatWhenLow = value;
               break;
            default:
               source.sendFailure(VexText.literal("[VexBot] Unknown toggle '" + key + "'."));
               return 0;
         }

         SettingsPersistence.save(source.getServer());
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + name + "§r " + key + ": §e" + value + "§r."), false);
         return 1;
      }
   }

   private static boolean isNoneWord(String s) {
      String v = s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
      return v.equals("none") || v.equals("off") || v.equals("clear") || v.equals("free");
   }
}
