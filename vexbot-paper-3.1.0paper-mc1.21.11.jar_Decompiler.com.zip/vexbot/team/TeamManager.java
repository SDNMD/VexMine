package vexbot.team;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.BotSettings;
import vexbot.DifficultyParams;
import vexbot.bot.BotManager;
import vexbot.bot.loadout.RandomGearConfig;
import vexbot.nick.NickManager;
import vexbot.settings.TechniqueConfig;
import vexbot.stats.Stats;

public final class TeamManager {
   private static final Map<String, BotTeam> TEAMS = new LinkedHashMap();
   private static volatile long rosterVersion = 0L;
   private static final Map<String, TeamCacheEntry> teamForBotCache = new HashMap();
   private static final Map<String, TeamCacheEntry> teamForMemberCache = new HashMap();
   private static final int MEMBER_CACHE_MAX = 512;
   private static final Map<String, TeamCacheEntry> teamForBotExact = new HashMap();
   private static final Map<String, TeamCacheEntry> teamForMemberExact = new HashMap();
   public static volatile boolean loadingFromDisk = false;
   private static MinecraftServer rebalanceServer;

   private static boolean isAscii(String s) {
      for(int i = 0; i < s.length(); ++i) {
         if (s.charAt(i) >= 128) {
            return false;
         }
      }

      return true;
   }

   private static void bumpRosterVersion() {
      ++rosterVersion;
      teamForBotCache.clear();
      teamForBotExact.clear();
      teamForMemberExact.clear();
   }

   private TeamManager() {
   }

   private static BotTeam resolve(String name) {
      if (name == null) {
         return null;
      } else {
         BotTeam exact = (BotTeam)TEAMS.get(name);
         if (exact != null) {
            return exact;
         } else {
            for(BotTeam t : TEAMS.values()) {
               if (t.name.equalsIgnoreCase(name)) {
                  return t;
               }
            }

            return null;
         }
      }
   }

   public static synchronized String canonicalName(String name) {
      BotTeam t = resolve(name);
      return t == null ? null : t.name;
   }

   public static synchronized BotTeam getOrCreate(String name) {
      BotTeam existing = resolve(name);
      return existing != null ? existing : (BotTeam)TEAMS.computeIfAbsent(name, (n) -> {
         if (!loadingFromDisk) {
            Stats.inc("teams_created");
         }

         BotTeam t = new BotTeam(n);
         t.bridgeMode = BotSettings.bridgeMode;
         t.attackRange = BotSettings.attackRange;
         t.equipArmor = BotSettings.equipArmor;
         t.usePotions = BotSettings.usePotions;
         t.retreat = BotSettings.retreat;
         t.useCobwebs = BotSettings.useCobwebs;
         t.bunnyHopMode = BotSettings.bunnyHopMode;
         t.autoTarget = BotSettings.autoTarget;
         t.targetPlayers = BotSettings.targetPlayers;
         t.targetBots = BotSettings.targetBots;
         t.targetMobs = BotSettings.targetMobs;
         t.difficulty = BotSettings.difficulty;
         t.difficultyParams = BotSettings.difficultyParams.copy();
         t.useCarting = BotSettings.useCarting;
         t.cartMode = BotSettings.cartMode;
         t.techniques = BotSettings.techniques.copy();
         t.ignoreCreative = BotSettings.ignoreCreative;
         t.useEnderPearl = BotSettings.useEnderPearl;
         t.pearlChasing = BotSettings.pearlChasing;
         t.botLeaveOnDeath = true;
         t.useScaffolding = BotSettings.useScaffolding;
         t.chorusEscape = BotSettings.chorusEscape;
         t.fireEscape = BotSettings.fireEscape;
         t.shulkerSteal = BotSettings.shulkerSteal;
         t.spreadOut = BotSettings.spreadOut;
         t.shulkerRegear = BotSettings.shulkerRegear;
         t.enderChestRegear = BotSettings.enderChestRegear;
         t.webEscape = BotSettings.webEscape;
         t.waterBucketClutch = BotSettings.waterBucketClutch;
         t.hitWeb = BotSettings.hitWeb;
         t.pickupLoot = BotSettings.pickupLoot;
         t.buildUpMinHeight = BotSettings.buildUpMinHeight;
         t.botPing = BotSettings.botPing;
         t.doBlockExplosion = BotSettings.doBlockExplosion;
         t.speedNoJump = BotSettings.speedNoJump;
         t.maceTotem = BotSettings.maceTotem;
         t.chaseSpread = BotSettings.chaseSpread;
         t.placeBlocksMoving = BotSettings.placeBlocksMoving;
         t.lootPackRadius = BotSettings.lootPackRadius;
         t.healingMode = BotSettings.healingMode;
         t.offhandPreference = BotSettings.offhandPreference;
         t.offhandTotemHearts = BotSettings.offhandTotemHearts;
         t.strafeInCombo = BotSettings.strafeInCombo;
         t.cartDoctrine = BotSettings.cartDoctrine;
         t.useBows = BotSettings.useBows;
         t.useOrbitalStrike = BotSettings.useOrbitalStrike;
         t.retreatHealthHearts = BotSettings.retreatHealthHearts;
         t.wanderWhenIdle = BotSettings.wanderWhenIdle;
         t.riptideAnywhere = BotSettings.riptideAnywhere;
         t.useElytraMace = BotSettings.useElytraMace;
         t.useElytraSpear = BotSettings.useElytraSpear;
         t.useSpearDash = BotSettings.useSpearDash;
         t.useStunSlam = BotSettings.useStunSlam;
         t.useWebDrain = BotSettings.useWebDrain;
         t.webDrainChance = BotSettings.webDrainChance;
         t.jumpResetChance = BotSettings.jumpResetChance;
         t.counterStunChance = BotSettings.counterStunChance;
         t.randomGearConfig = BotSettings.randomGearConfig.copy();
         t.shieldOnMaceDive = BotSettings.shieldOnMaceDive;
         t.fastShieldCooldown = BotSettings.fastShieldCooldown;
         t.usePearlCatch = BotSettings.usePearlCatch;
         t.elytraGlide = BotSettings.elytraGlide;
         t.revengeMode = BotSettings.revengeMode;
         return t;
      });
   }

   public static synchronized BotTeam get(String name) {
      return resolve(name);
   }

   public static synchronized boolean exists(String name) {
      return resolve(name) != null;
   }

   public static synchronized void delete(String name) {
      BotTeam gone = resolve(name);
      if (gone != null) {
         TEAMS.remove(gone.name);
         bumpRosterVersion();

         for(BotTeam t : TEAMS.values()) {
            t.allies.removeIf((s) -> s.equalsIgnoreCase(gone.name));
            t.targetTeamNames.removeIf((s) -> s.equalsIgnoreCase(gone.name));
            if (t.mode == TeamManager.TargetMode.SPECIFIC_TEAMS && t.targetTeamNames.isEmpty()) {
               t.mode = TeamManager.TargetMode.NONE;
            }
         }

      }
   }

   public static synchronized List<BotTeam> allTeams() {
      return new ArrayList(TEAMS.values());
   }

   public static synchronized Set<String> teamNames() {
      return new LinkedHashSet(TEAMS.keySet());
   }

   private static boolean containsIgnoreCase(Collection<String> set, String query) {
      if (query == null) {
         return false;
      } else {
         for(String s : set) {
            if (s != null && s.equalsIgnoreCase(query)) {
               return true;
            }
         }

         return false;
      }
   }

   private static void removeIgnoreCase(Set<String> set, String value) {
      if (value != null) {
         set.removeIf((s) -> s != null && s.equalsIgnoreCase(value));
      }
   }

   public static synchronized boolean isMemberOfTeam(String teamName, String memberName) {
      BotTeam t = resolve(teamName);
      if (t != null && memberName != null) {
         return containsIgnoreCase(t.botNames, memberName) || containsIgnoreCase(t.playerNames, memberName);
      } else {
         return false;
      }
   }

   public static synchronized void setTeamBots(String teamName, Collection<String> bots) {
      BotTeam team = getOrCreate(teamName);
      LinkedHashSet<String> clean = new LinkedHashSet();

      for(String b : bots) {
         if (b != null && !b.isBlank() && !BotManager.isPracticeBot(b) && !containsIgnoreCase(clean, b)) {
            clean.add(b.strip());
         }
      }

      for(BotTeam t : TEAMS.values()) {
         if (t != team) {
            for(String bot : clean) {
               removeIgnoreCase(t.botNames, bot);
            }
         }
      }

      team.botNames.clear();
      team.botNames.addAll(clean);
      bumpRosterVersion();
      if (rebalanceServer != null) {
         TeamTargetBalancer.rebalance(rebalanceServer, team.name);
      }

   }

   public static synchronized int addBotsToTeam(String teamName, Collection<String> bots) {
      BotTeam team = getOrCreate(teamName);
      LinkedHashSet<String> merged = new LinkedHashSet(team.botNames);
      int before = merged.size();

      for(String b : bots) {
         if (!BotManager.isPracticeBot(b) && !containsIgnoreCase(merged, b)) {
            merged.add(b);
         }
      }

      setTeamBots(teamName, merged);
      return merged.size() - before;
   }

   public static synchronized int removeBotsFromTeam(String teamName, Collection<String> bots) {
      BotTeam t = resolve(teamName);
      if (t == null) {
         return 0;
      } else {
         int before = t.botNames.size();

         for(String b : bots) {
            removeIgnoreCase(t.botNames, b);
         }

         bumpRosterVersion();
         if (rebalanceServer != null) {
            TeamTargetBalancer.rebalance(rebalanceServer, t.name);
         }

         return before - t.botNames.size();
      }
   }

   public static synchronized void setRebalanceServer(MinecraftServer server) {
      rebalanceServer = server;
   }

   public static synchronized boolean removeBotFromAllTeams(String botName) {
      if (botName != null && !botName.isBlank()) {
         BotTeam affected = getTeamForBot(botName);
         boolean changed = false;

         for(BotTeam t : TEAMS.values()) {
            int before = t.botNames.size();
            removeIgnoreCase(t.botNames, botName);
            if (t.botNames.size() != before) {
               changed = true;
            }

            if (t.botTargetAssignments.keySet().removeIf((k) -> k != null && k.equalsIgnoreCase(botName))) {
               t.assignmentIndex = null;
            }
         }

         if (changed) {
            bumpRosterVersion();
         }

         if (changed && affected != null && rebalanceServer != null && affected.getMode() == TeamManager.TargetMode.SPECIFIC && affected.getTargetNames().size() >= 2) {
            TeamTargetBalancer.rebalance(rebalanceServer, affected.getName());
         }

         return changed;
      } else {
         return false;
      }
   }

   public static synchronized String getAssignedTarget(String botName) {
      BotTeam team = getTeamForBot(botName);
      return team != null && (team.getMode() == TeamManager.TargetMode.SPECIFIC || team.getMode() == TeamManager.TargetMode.SPECIFIC_TEAMS) ? team.assignedTarget(botName) : null;
   }

   public static synchronized void addPlayerToTeam(String teamName, String playerName) {
      for(BotTeam t : TEAMS.values()) {
         removeIgnoreCase(t.playerNames, playerName);
      }

      BotTeam team = getOrCreate(teamName);
      team.playerNames.add(playerName);
      bumpRosterVersion();
   }

   public static synchronized void removePlayerFromTeam(String teamName, String playerName) {
      BotTeam team = resolve(teamName);
      if (team != null && playerName != null) {
         removeIgnoreCase(team.playerNames, playerName);
         bumpRosterVersion();
      }
   }

   public static synchronized void setTeamPlayers(String teamName, Collection<String> players) {
      BotTeam team = getOrCreate(teamName);
      Set<String> previous = new LinkedHashSet(team.playerNames);
      LinkedHashSet<String> normalized = new LinkedHashSet();
      if (players != null) {
         for(String p : players) {
            if (p != null && !p.isBlank()) {
               String trimmed = p.strip();
               if (!containsIgnoreCase(normalized, trimmed)) {
                  normalized.add(trimmed);
               }
            }
         }
      }

      for(BotTeam t : TEAMS.values()) {
         if (t != team) {
            for(String p : normalized) {
               removeIgnoreCase(t.playerNames, p);
            }
         }
      }

      for(String old : previous) {
         if (!containsIgnoreCase(normalized, old)) {
            removeIgnoreCase(team.playerNames, old);
         }
      }

      team.playerNames.clear();
      team.playerNames.addAll(normalized);
      bumpRosterVersion();
   }

   public static synchronized BotTeam getTeamForBot(String botName) {
      if (botName == null) {
         return null;
      } else {
         botName = NickManager.realNameOf(botName);
         TeamCacheEntry exact = (TeamCacheEntry)teamForBotExact.get(botName);
         if (exact != null && exact.version == rosterVersion) {
            return exact.team;
         } else {
            String key = botName.toLowerCase(Locale.ROOT);
            TeamCacheEntry cached = (TeamCacheEntry)teamForBotCache.get(key);
            if (cached == null || cached.version != rosterVersion) {
               BotTeam found = null;

               for(BotTeam t : TEAMS.values()) {
                  if (containsIgnoreCase(t.botNames, botName)) {
                     found = t;
                     break;
                  }
               }

               if (teamForBotCache.size() > 512) {
                  teamForBotCache.clear();
                  teamForBotExact.clear();
               }

               cached = new TeamCacheEntry(rosterVersion, found);
               teamForBotCache.put(key, cached);
            }

            if (teamForBotExact.size() > 512) {
               teamForBotExact.clear();
            }

            teamForBotExact.put(botName, cached);
            return cached.team;
         }
      }
   }

   public static synchronized BotTeam getTeamForMember(String memberName) {
      if (memberName == null) {
         return null;
      } else {
         memberName = NickManager.realNameOf(memberName);
         TeamCacheEntry exact = (TeamCacheEntry)teamForMemberExact.get(memberName);
         if (exact != null && exact.version == rosterVersion) {
            return exact.team;
         } else {
            String key = memberName.toLowerCase(Locale.ROOT);
            TeamCacheEntry cached = (TeamCacheEntry)teamForMemberCache.get(key);
            if (cached == null || cached.version != rosterVersion) {
               BotTeam found = null;

               for(BotTeam t : TEAMS.values()) {
                  if (containsIgnoreCase(t.botNames, memberName) || containsIgnoreCase(t.playerNames, memberName)) {
                     found = t;
                     break;
                  }
               }

               if (teamForMemberCache.size() > 512) {
                  teamForMemberCache.clear();
                  teamForMemberExact.clear();
               }

               cached = new TeamCacheEntry(rosterVersion, found);
               teamForMemberCache.put(key, cached);
            }

            if (teamForMemberExact.size() > 512) {
               teamForMemberExact.clear();
            }

            teamForMemberExact.put(memberName, cached);
            return cached.team;
         }
      }
   }

   public static synchronized boolean isAlliedWithBot(String botName, String otherName) {
      BotTeam mine = getTeamForBot(botName);
      if (mine == null) {
         return false;
      } else {
         BotTeam theirs = getTeamForMember(otherName);
         if (theirs == null) {
            return false;
         } else {
            return theirs.getName().equals(mine.getName()) ? true : containsIgnoreCase(mine.allies, theirs.getName());
         }
      }
   }

   public static synchronized boolean addAlliance(String teamA, String teamB) {
      BotTeam a = resolve(teamA);
      BotTeam b = resolve(teamB);
      if (a != null && b != null && a != b) {
         boolean changed = false;
         if (!containsIgnoreCase(a.allies, b.getName())) {
            a.allies.add(b.getName());
            changed = true;
         }

         if (!containsIgnoreCase(b.allies, a.getName())) {
            b.allies.add(a.getName());
            changed = true;
         }

         return changed;
      } else {
         return false;
      }
   }

   public static synchronized boolean removeAlliance(String teamA, String teamB) {
      BotTeam a = resolve(teamA);
      BotTeam b = resolve(teamB);
      boolean changed = false;
      String nameA = a != null ? a.name : teamA;
      String nameB = b != null ? b.name : teamB;
      if (a != null) {
         changed |= a.allies.removeIf((s) -> s.equalsIgnoreCase(nameB));
      }

      if (b != null) {
         changed |= b.allies.removeIf((s) -> s.equalsIgnoreCase(nameA));
      }

      return changed;
   }

   public static synchronized int clearAlliances(String teamName) {
      BotTeam t = resolve(teamName);
      if (t == null) {
         return 0;
      } else {
         int n = t.allies.size();

         for(String allyName : new ArrayList(t.allies)) {
            BotTeam other = resolve(allyName);
            if (other != null) {
               other.allies.removeIf((s) -> s.equalsIgnoreCase(t.name));
            }
         }

         t.allies.clear();
         return n;
      }
   }

   public static synchronized void loadAllies(String teamName, Collection<String> allyNames) {
      BotTeam t = resolve(teamName);
      if (t != null) {
         t.allies.clear();

         for(String a : allyNames) {
            if (a != null && !a.isBlank()) {
               t.allies.add(a.strip());
            }
         }

      }
   }

   public static synchronized void setMode(String teamName, TargetMode mode) {
      BotTeam t = resolve(teamName);
      if (t != null) {
         t.mode = mode;
      }

   }

   public static synchronized void setTeamRevengeMode(String teamName, boolean value) {
      BotTeam t = resolve(teamName);
      if (t != null) {
         t.revengeMode = value;
      }

   }

   public static synchronized void setTargets(String teamName, Collection<String> players) {
      BotTeam t = resolve(teamName);
      if (t != null) {
         t.targetNames.clear();

         for(String p : players) {
            if (p != null && !p.isBlank()) {
               t.targetNames.add(p.strip());
            }
         }

         t.mode = t.targetNames.isEmpty() ? TeamManager.TargetMode.NONE : TeamManager.TargetMode.SPECIFIC;
         if (rebalanceServer != null) {
            TeamTargetBalancer.rebalance(rebalanceServer, t.name);
         }

      }
   }

   public static boolean targetNamesContains(Collection<String> names, String query) {
      if (query != null && names != null) {
         String want = query.strip();

         for(String n : names) {
            if (n != null && n.equalsIgnoreCase(want)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean toggleTargetName(Set<String> targets, String name) {
      String existing = findTargetNameIgnoreCase(targets, name);
      if (existing != null) {
         targets.remove(existing);
         return false;
      } else {
         targets.add(name.strip());
         return true;
      }
   }

   private static String findTargetNameIgnoreCase(Set<String> names, String query) {
      if (query != null && names != null) {
         String want = query.strip();

         for(String n : names) {
            if (n != null && n.equalsIgnoreCase(want)) {
               return n;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public static synchronized void setTargetTeams(String teamName, Collection<String> teamNames) {
      BotTeam t = resolve(teamName);
      if (t != null) {
         t.targetTeamNames.clear();

         for(String otherTeam : teamNames) {
            if (otherTeam != null && !otherTeam.equalsIgnoreCase(t.name)) {
               BotTeam other = resolve(otherTeam);
               String stored = other != null ? other.name : otherTeam;
               if (!containsIgnoreCase(t.targetTeamNames, stored)) {
                  t.targetTeamNames.add(stored);
               }
            }
         }

         t.mode = t.targetTeamNames.isEmpty() ? TeamManager.TargetMode.NONE : TeamManager.TargetMode.SPECIFIC_TEAMS;
      }
   }

   public static synchronized boolean pruneStaleSpecificPlayerTargets(MinecraftServer server) {
      boolean changed = false;

      for(BotTeam t : TEAMS.values()) {
         if (!t.targetNames.isEmpty()) {
            Iterator<String> it = t.targetNames.iterator();

            while(it.hasNext()) {
               if (shouldRemoveSpecificPlayerTarget(server, t, (String)it.next())) {
                  it.remove();
                  changed = true;
               }
            }

            if (t.mode == TeamManager.TargetMode.SPECIFIC && t.targetNames.isEmpty()) {
               t.mode = TeamManager.TargetMode.NONE;
               changed = true;
            }
         }
      }

      return changed;
   }

   private static boolean shouldRemoveSpecificPlayerTarget(MinecraftServer server, BotTeam attackerTeam, String targetName) {
      ServerPlayer p = BotManager.resolveTrackedBotPlayer(server, targetName);
      if (p == null) {
         p = BotManager.resolveNonBotPlayerByName(server, targetName);
      }

      if (p == null) {
         return BotManager.isTrackedBotName(targetName) ? false : false;
      } else {
         String resolved = p.getName().getString();
         BotTeam targetMemberTeam = getTeamForMember(resolved);
         return targetMemberTeam != null && targetMemberTeam.getName().equals(attackerTeam.getName());
      }
   }

   public static synchronized boolean pruneInvalidTargetTeamEntries() {
      boolean changed = false;

      for(BotTeam t : TEAMS.values()) {
         if (!t.targetTeamNames.isEmpty()) {
            int before = t.targetTeamNames.size();
            t.targetTeamNames.removeIf((ot) -> resolve(ot) == null || ot.equalsIgnoreCase(t.getName()));
            if (t.targetTeamNames.size() != before) {
               changed = true;
            }

            if (t.mode == TeamManager.TargetMode.SPECIFIC_TEAMS && t.targetTeamNames.isEmpty()) {
               t.mode = TeamManager.TargetMode.NONE;
               changed = true;
            }
         }
      }

      return changed;
   }

   public static enum TargetMode {
      NONE,
      ALL_PLAYERS,
      SPECIFIC,
      SPECIFIC_TEAMS;

      // $FF: synthetic method
      private static TargetMode[] $values() {
         return new TargetMode[]{NONE, ALL_PLAYERS, SPECIFIC, SPECIFIC_TEAMS};
      }
   }

   public static final class BotTeam {
      private final String name;
      private final Set<String> botNames = new LinkedHashSet();
      private final Set<String> playerNames = new LinkedHashSet();
      private TargetMode mode;
      private final Set<String> targetNames;
      private final Set<String> targetTeamNames;
      private final Set<String> allies;
      private final Map<String, String> botTargetAssignments;
      public volatile boolean revengeMode;
      public final TeamTactics tactics;
      public volatile String nameTagColour;
      public volatile String teamSkin;
      public volatile String namePool;
      public volatile BotSettings.BridgeMode bridgeMode;
      public volatile double attackRange;
      public volatile boolean equipArmor;
      public volatile boolean usePotions;
      public volatile boolean retreat;
      public volatile boolean useCobwebs;
      public volatile BotSettings.BunnyHopMode bunnyHopMode;
      public volatile boolean autoTarget;
      public volatile boolean targetPlayers;
      public volatile boolean targetBots;
      public volatile boolean targetMobs;
      public volatile BotSettings.Difficulty difficulty;
      public volatile DifficultyParams difficultyParams;
      public volatile boolean useCarting;
      public volatile BotSettings.CartMode cartMode;
      public volatile boolean ignoreCreative;
      public volatile boolean useEnderPearl;
      public volatile boolean pearlChasing;
      public volatile boolean botLeaveOnDeath;
      public volatile boolean useScaffolding;
      public volatile boolean chorusEscape;
      public volatile boolean fireEscape;
      public volatile boolean shulkerSteal;
      public volatile boolean spreadOut;
      public volatile boolean shulkerRegear;
      public volatile boolean enderChestRegear;
      public volatile boolean webEscape;
      public volatile boolean waterBucketClutch;
      public volatile boolean hitWeb;
      public volatile boolean pickupLoot;
      public volatile double buildUpMinHeight;
      public volatile int botPing;
      public volatile boolean doBlockExplosion;
      public volatile boolean speedNoJump;
      public volatile boolean maceTotem;
      public volatile boolean chaseSpread;
      public volatile boolean placeBlocksMoving;
      public volatile double lootPackRadius;
      public volatile BotSettings.HealingMode healingMode;
      public volatile BotSettings.OffhandPreference offhandPreference;
      public volatile double offhandTotemHearts;
      public volatile boolean strafeInCombo;
      public volatile BotSettings.CartDoctrine cartDoctrine;
      public volatile boolean useBows;
      public volatile boolean useOrbitalStrike;
      public volatile double retreatHealthHearts;
      public volatile boolean wanderWhenIdle;
      public volatile boolean riptideAnywhere;
      public volatile boolean useElytraMace;
      public volatile boolean useElytraSpear;
      public volatile boolean useSpearDash;
      public volatile boolean useStunSlam;
      public volatile boolean useWebDrain;
      public volatile int webDrainChance;
      public volatile int jumpResetChance;
      public volatile int counterStunChance;
      public RandomGearConfig randomGearConfig;
      public volatile boolean shieldOnMaceDive;
      public volatile boolean fastShieldCooldown;
      public volatile boolean usePearlCatch;
      public volatile boolean elytraGlide;
      public volatile TechniqueConfig techniques;
      private Map<String, String> assignmentIndex;
      private boolean assignmentIndexAscii;

      BotTeam(String name) {
         this.mode = TeamManager.TargetMode.NONE;
         this.targetNames = new LinkedHashSet();
         this.targetTeamNames = new LinkedHashSet();
         this.allies = new LinkedHashSet();
         this.botTargetAssignments = new HashMap();
         this.revengeMode = true;
         this.tactics = new TeamTactics();
         this.nameTagColour = "none";
         this.teamSkin = "";
         this.namePool = "";
         this.bridgeMode = BotSettings.BridgeMode.NINJA;
         this.attackRange = (double)3.0F;
         this.equipArmor = true;
         this.usePotions = true;
         this.retreat = false;
         this.useCobwebs = true;
         this.bunnyHopMode = BotSettings.BunnyHopMode.ON;
         this.autoTarget = false;
         this.targetPlayers = true;
         this.targetBots = false;
         this.targetMobs = false;
         this.difficulty = BotSettings.Difficulty.PERFECT;
         this.difficultyParams = DifficultyParams.forPreset(BotSettings.Difficulty.PERFECT);
         this.useCarting = true;
         this.cartMode = BotSettings.CartMode.SMART;
         this.ignoreCreative = true;
         this.useEnderPearl = false;
         this.pearlChasing = true;
         this.botLeaveOnDeath = true;
         this.useScaffolding = false;
         this.chorusEscape = true;
         this.fireEscape = false;
         this.shulkerSteal = true;
         this.spreadOut = BotSettings.spreadOut;
         this.shulkerRegear = BotSettings.shulkerRegear;
         this.enderChestRegear = BotSettings.enderChestRegear;
         this.webEscape = true;
         this.waterBucketClutch = true;
         this.hitWeb = false;
         this.pickupLoot = true;
         this.buildUpMinHeight = (double)4.0F;
         this.botPing = 0;
         this.doBlockExplosion = true;
         this.speedNoJump = true;
         this.maceTotem = true;
         this.chaseSpread = true;
         this.placeBlocksMoving = false;
         this.lootPackRadius = (double)100.0F;
         this.healingMode = BotSettings.HealingMode.ADVANCED;
         this.offhandPreference = BotSettings.OffhandPreference.AUTO;
         this.offhandTotemHearts = (double)4.0F;
         this.strafeInCombo = true;
         this.cartDoctrine = BotSettings.CartDoctrine.RELENTLESS;
         this.useBows = true;
         this.useOrbitalStrike = false;
         this.retreatHealthHearts = (double)4.0F;
         this.wanderWhenIdle = false;
         this.riptideAnywhere = false;
         this.useElytraMace = true;
         this.useElytraSpear = true;
         this.useSpearDash = true;
         this.useStunSlam = true;
         this.useWebDrain = true;
         this.webDrainChance = 100;
         this.jumpResetChance = 50;
         this.counterStunChance = 30;
         this.randomGearConfig = new RandomGearConfig();
         this.shieldOnMaceDive = true;
         this.fastShieldCooldown = false;
         this.usePearlCatch = true;
         this.elytraGlide = true;
         this.techniques = new TechniqueConfig();
         this.name = name;
      }

      public String getName() {
         return this.name;
      }

      public Set<String> getBotNames() {
         return Collections.unmodifiableSet(this.botNames);
      }

      public Set<String> getPlayerNames() {
         return Collections.unmodifiableSet(this.playerNames);
      }

      public TargetMode getMode() {
         return this.mode;
      }

      public Set<String> getTargetNames() {
         return Collections.unmodifiableSet(this.targetNames);
      }

      public Set<String> getTargetTeamNames() {
         return Collections.unmodifiableSet(this.targetTeamNames);
      }

      public Set<String> getAllies() {
         return Collections.unmodifiableSet(this.allies);
      }

      public Map<String, String> getBotTargetAssignments() {
         return Collections.unmodifiableMap(this.botTargetAssignments);
      }

      public boolean isRevengeMode() {
         return this.revengeMode;
      }

      void clearTargetAssignments() {
         this.botTargetAssignments.clear();
         this.assignmentIndex = null;
      }

      void setTargetAssignment(String botName, String targetPlayer) {
         if (botName != null && targetPlayer != null) {
            this.botTargetAssignments.put(botName, targetPlayer);
            this.assignmentIndex = null;
         }
      }

      String assignedTarget(String botName) {
         if (this.botTargetAssignments.isEmpty()) {
            return null;
         } else {
            if (this.assignmentIndex == null) {
               Map<String, String> idx = new HashMap();
               boolean ascii = true;

               for(Map.Entry<String, String> e : this.botTargetAssignments.entrySet()) {
                  String k = (String)e.getKey();
                  if (k != null) {
                     if (!TeamManager.isAscii(k)) {
                        ascii = false;
                        break;
                     }

                     idx.putIfAbsent(k.toLowerCase(Locale.ROOT), (String)e.getValue());
                  }
               }

               this.assignmentIndex = idx;
               this.assignmentIndexAscii = ascii;
            }

            if (this.assignmentIndexAscii && TeamManager.isAscii(botName)) {
               return (String)this.assignmentIndex.get(botName.toLowerCase(Locale.ROOT));
            } else {
               for(Map.Entry<String, String> e : this.botTargetAssignments.entrySet()) {
                  if (e.getKey() != null && ((String)e.getKey()).equalsIgnoreCase(botName)) {
                     return (String)e.getValue();
                  }
               }

               return null;
            }
         }
      }
   }

   private static record TeamCacheEntry(long version, BotTeam team) {
   }
}
