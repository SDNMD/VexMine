package vexbot.team;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.SettingsPersistence;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.bot.ai.FollowFormation;
import vexbot.bot.ai.InvisibleSuitUp;
import vexbot.compat.McCompat;
import vexbot.i18n.VexText;

public final class TeamHornSummon {
   public static final List<String> VARIANTS = List.of("ponder", "sing", "seek", "feel", "admire", "call", "yearn", "dream");
   public static final String ANY = "any";
   private static final long RESUMMON_COOLDOWN_MS = 1500L;
   private static final Map<String, Long> lastSummon = new ConcurrentHashMap();
   private static final Map<String, Boolean> formedUp = new ConcurrentHashMap();
   private static final double CHARGE_RANGE = (double)64.0F;

   private TeamHornSummon() {
   }

   public static String normalise(String variant) {
      if (variant == null) {
         return "";
      } else {
         String v = variant.trim().toLowerCase(Locale.ROOT);
         if (v.startsWith("minecraft:")) {
            v = v.substring("minecraft:".length());
         }

         if (v.endsWith("_goat_horn")) {
            v = v.substring(0, v.length() - "_goat_horn".length());
         }

         return v;
      }
   }

   public static boolean isValidVariant(String variant) {
      String v = normalise(variant);
      return v.equals("any") || VARIANTS.contains(v);
   }

   public static boolean onUseItem(ServerPlayer player, ItemStack stack) {
      if (player == null) {
         return false;
      } else {
         String blown = normalise(McCompat.instrumentId(stack));
         if (blown.isEmpty()) {
            return false;
         } else {
            String who = player.getName().getString();

            for(TeamManager.BotTeam team : TeamManager.allTeams()) {
               TeamTactics t = team.tactics;
               if (t != null && t.hornArmed() && (t.hornPlayer == null || t.hornPlayer.isBlank() || t.hornPlayer.equalsIgnoreCase(who))) {
                  String want = normalise(t.hornType);
                  if (want.equals("any") || want.equals(blown)) {
                     long now = System.currentTimeMillis();
                     String key = team.getName().toLowerCase(Locale.ROOT);
                     Long prev = (Long)lastSummon.get(key);
                     if (prev == null || now - prev >= 1500L) {
                        lastSummon.put(key, now);
                        ServerPlayer mark = lookedAt(player, team);
                        if (mark != null) {
                           String order = charge(team, mark, player.level().getServer());
                           if (order != null) {
                              tell(player, VexText.literal("§6♪ §e" + team.getName() + " §7heard the §e" + blown + " §7horn — §cattacking " + order + "§7."));
                              continue;
                           }
                        }

                        Blow blow = toggle(team, who);
                        if (blow.count() != 0) {
                           if (!blow.formedUp()) {
                              tell(player, VexText.literal("§6♪ §e" + team.getName() + " §7heard the §e" + blown + " §7horn — §a" + blow.count() + " §7standing down."));
                           } else {
                              String var10001 = team.getName();
                              tell(player, VexText.literal("§6♪ §e" + var10001 + " §7heard the §e" + blown + " §7horn — §a" + blow.count() + " §7forming up on §e" + blow.leader() + " §7(§b" + t.hornFormation.name().toLowerCase(Locale.ROOT) + "§7)."));
                           }
                        }
                     }
                  }
               }
            }

            return false;
         }
      }
   }

   private static ServerPlayer lookedAt(ServerPlayer blower, TeamManager.BotTeam team) {
      Vec3 eye = blower.getEyePosition();
      Vec3 dir = blower.getViewVector(1.0F);
      ServerPlayer best = null;
      double bestAngle = Double.MAX_VALUE;

      for(ServerPlayer p : blower.level().getServer().getPlayerList().getPlayers()) {
         if (p != blower && p.level() == blower.level() && p.isAlive() && !p.isSpectator()) {
            Vec3 to = p.position().add((double)0.0F, (double)p.getBbHeight() * (double)0.5F, (double)0.0F).subtract(eye);
            double dist = to.length();
            if (!(dist > (double)64.0F) && !(dist < (double)1.0F)) {
               double angle = Math.toDegrees(Math.acos(Math.max((double)-1.0F, Math.min((double)1.0F, to.normalize().dot(dir)))));
               double allow = Math.max((double)4.0F, Math.toDegrees(Math.atan(0.9 / dist)));
               if (!(angle > allow) && !(angle >= bestAngle) && blower.hasLineOfSight(p) && !onSide(team, p.getScoreboardName())) {
                  best = p;
                  bestAngle = angle;
               }
            }
         }
      }

      return best;
   }

   private static boolean onSide(TeamManager.BotTeam team, String name) {
      TeamManager.BotTeam other = TeamManager.getTeamForMember(name);
      if (other == null) {
         return false;
      } else if (other.getName().equalsIgnoreCase(team.getName())) {
         return true;
      } else {
         for(String a : team.getAllies()) {
            if (a.equalsIgnoreCase(other.getName())) {
               return true;
            }
         }

         return false;
      }
   }

   private static String charge(TeamManager.BotTeam team, ServerPlayer mark, MinecraftServer server) {
      if (team.getBotNames().isEmpty()) {
         return null;
      } else {
         String markName = mark.getScoreboardName();
         TeamManager.BotTeam markTeam = TeamManager.getTeamForMember(markName);
         String order;
         if (markTeam != null) {
            TeamManager.setTargetTeams(team.getName(), List.of(markTeam.getName()));
            order = "team §e" + markTeam.getName();
         } else {
            TeamManager.setTargets(team.getName(), List.of(markName));
            order = "§e" + markName;
         }

         if (isFormedUp(team.getName())) {
            dismiss(team);
         } else {
            for(String botName : team.getBotNames()) {
               BotManager.clearFollowTarget(botName);
            }
         }

         if (server != null) {
            for(String botName : team.getBotNames()) {
               ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, botName);
               if (bot != null) {
                  InvisibleSuitUp.callToArms(bot);
               }
            }

            TeamTargetBalancer.rebalance(server, team.getName());
            SettingsPersistence.save(server);
         }

         return order;
      }
   }

   private static void tell(ServerPlayer player, Component msg) {
      if (!BotSettings.silentCommands) {
         player.sendSystemMessage(msg);
      }

   }

   public static Blow toggle(TeamManager.BotTeam team, String blower) {
      if (team == null) {
         return new Blow(false, 0, blower);
      } else {
         TeamTactics t = team.tactics;
         String key = team.getName().toLowerCase(Locale.ROOT);
         if (Boolean.TRUE.equals(formedUp.get(key))) {
            return new Blow(false, dismiss(team), leaderFor(team, blower));
         } else {
            String leader = leaderFor(team, blower);
            FollowFormation.Type shape = t == null ? FollowFormation.Type.LINE : t.hornFormation;
            int size = t == null ? 0 : t.formationSize;
            int n = summon(team, leader, shape, size);
            if (n > 0) {
               formedUp.put(key, true);
            }

            return new Blow(true, n, leader);
         }
      }
   }

   private static String leaderFor(TeamManager.BotTeam team, String blower) {
      TeamTactics t = team.tactics;
      if (t != null) {
         if (t.hornPlayer != null && !t.hornPlayer.isBlank()) {
            return t.hornPlayer;
         }

         if (t.hasBoss()) {
            return t.boss;
         }
      }

      return blower;
   }

   public static int dismiss(TeamManager.BotTeam team) {
      if (team == null) {
         return 0;
      } else {
         int n = 0;

         for(String botName : team.getBotNames()) {
            BotManager.clearFollowTarget(botName);
            ++n;
         }

         formedUp.put(team.getName().toLowerCase(Locale.ROOT), false);
         TeamFormationOrders.standDown(team.getName());
         return n;
      }
   }

   public static void markStoodDown(String teamName) {
      if (teamName != null) {
         formedUp.put(teamName.toLowerCase(Locale.ROOT), false);
         TeamFormationOrders.standDown(teamName);
      }
   }

   public static boolean isFormedUp(String teamName) {
      return teamName != null && Boolean.TRUE.equals(formedUp.get(teamName.toLowerCase(Locale.ROOT)));
   }

   public static void markFormedUp(String teamName) {
      if (teamName != null) {
         formedUp.put(teamName.toLowerCase(Locale.ROOT), true);
         TeamFormationOrders.resume(teamName);
      }
   }

   public static int summon(TeamManager.BotTeam team, String leader, FollowFormation.Type formation, int rowWidth) {
      if (team != null && leader != null) {
         FollowFormation.Type f = formation == null ? FollowFormation.Type.LINE : formation;
         TeamFormationOrders.resume(team.getName());
         int n = 0;
         MinecraftServer server = VexBot.SERVER;

         for(String botName : team.getBotNames()) {
            if (server != null) {
               ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, botName);
               if (bot != null) {
                  InvisibleSuitUp.callToArms(bot);
               }
            }

            if (!botName.equalsIgnoreCase(leader)) {
               BotManager.setFollowTarget(botName, leader, f, rowWidth);
               ++n;
            }
         }

         return n;
      } else {
         return 0;
      }
   }

   public static String[] hornSuggestions() {
      String[] out = new String[VARIANTS.size() + 1];
      out[0] = "any";

      for(int i = 0; i < VARIANTS.size(); ++i) {
         out[i + 1] = (String)VARIANTS.get(i);
      }

      return out;
   }

   public static void forget(String teamName) {
      if (teamName != null) {
         String key = teamName.toLowerCase(Locale.ROOT);
         lastSummon.remove(key);
         formedUp.remove(key);
      }
   }

   public static record Blow(boolean formedUp, int count, String leader) {
   }
}
