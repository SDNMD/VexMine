package vexbot.team;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import vexbot.bot.BotManager;

public final class TeamTargetBalancer {
   private static final long MOVE_COOLDOWN_MS = 10000L;
   private static final double GEAR_GAP = 0.15;
   private static final int MAX_SWAPS_PER_PASS = 2;
   private static final double TRAVEL_WEIGHT = 0.05;
   private static final Map<String, Long> LAST_MOVED = new HashMap();

   private TeamTargetBalancer() {
   }

   public static synchronized void rebalanceAll(MinecraftServer server) {
      for(TeamManager.BotTeam team : TeamManager.allTeams()) {
         rebalance(server, team.getName());
      }

   }

   public static synchronized void tick(MinecraftServer server) {
      for(TeamManager.BotTeam team : TeamManager.allTeams()) {
         boolean splits = team.getMode() == TeamManager.TargetMode.SPECIFIC || team.getMode() == TeamManager.TargetMode.SPECIFIC_TEAMS;
         if (splits || !team.getBotTargetAssignments().isEmpty()) {
            rebalance(server, team.getName());
         }
      }

   }

   public static synchronized void rebalance(MinecraftServer server, String teamName) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team != null) {
         List<ServerPlayer> live = new ArrayList();

         for(String botName : team.getBotNames()) {
            ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, botName);
            if (bot != null && bot.isAlive() && !bot.isSpectator()) {
               live.add(bot);
            }
         }

         if (live.isEmpty()) {
            team.clearTargetAssignments();
         } else {
            Map<Level, Integer> perLevel = new HashMap();

            for(ServerPlayer b : live) {
               perLevel.merge(b.level(), 1, Integer::sum);
            }

            Level home = (Level)((Map.Entry)Collections.max(perLevel.entrySet(), Entry.comparingByValue())).getKey();
            List<ServerPlayer> targetPlayers = new ArrayList();

            for(ServerPlayer t : resolveTargetPlayers(server, team)) {
               if (t.level() == home) {
                  targetPlayers.add(t);
               }
            }

            if (targetPlayers.size() < 2) {
               team.clearTargetAssignments();
            } else {
               List<String> targets = new ArrayList();

               for(ServerPlayer t : targetPlayers) {
                  targets.add(t.getName().getString());
               }

               List<ScoredBot> bots = new ArrayList();

               for(ServerPlayer b : live) {
                  if (b.level() == home) {
                     double[] d = new double[targetPlayers.size()];

                     for(int i = 0; i < d.length; ++i) {
                        d[i] = (double)b.distanceTo((Entity)targetPlayers.get(i));
                     }

                     bots.add(new ScoredBot(b.getScoreboardName(), BotCombatScoring.score(b), d));
                  }
               }

               if (bots.size() < 2) {
                  team.clearTargetAssignments();
               } else {
                  int n = targets.size();
                  Map<String, Integer> sideOf = new HashMap();
                  Map<String, String> old = team.getBotTargetAssignments();
                  List<ScoredBot> unplaced = new ArrayList();

                  for(ScoredBot sb : bots) {
                     int side = indexOfTarget(targets, pinOf(old, sb.name));
                     if (side >= 0) {
                        sideOf.put(sb.name, side);
                     } else {
                        unplaced.add(sb);
                     }
                  }

                  int[] count = new int[n];
                  double[] power = new double[n];

                  for(ScoredBot sb : bots) {
                     Integer s = (Integer)sideOf.get(sb.name);
                     if (s != null) {
                        ++count[s];
                        int var10001 = s;
                        power[var10001] += sb.power;
                     }
                  }

                  unplaced.sort((ax, bx) -> Double.compare(bx.power, ax.power));

                  for(ScoredBot sb : unplaced) {
                     int s = placeSide(sb, count, power);
                     sideOf.put(sb.name, s);
                     int var10002 = count[s]++;
                     power[s] += sb.power;
                  }

                  long now = System.currentTimeMillis();

                  for(int guard = 0; guard < bots.size(); ++guard) {
                     int big = 0;
                     int small = 0;

                     for(int i = 1; i < n; ++i) {
                        if (count[i] > count[big]) {
                           big = i;
                        }

                        if (count[i] < count[small]) {
                           small = i;
                        }
                     }

                     if (count[big] - count[small] <= 1) {
                        break;
                     }

                     double want = (power[big] - power[small]) / (double)2.0F;
                     ScoredBot pick = null;
                     double pickScore = Double.MAX_VALUE;

                     for(ScoredBot sb : bots) {
                        if ((Integer)sideOf.get(sb.name) == big) {
                           double score = Math.abs(sb.power - want) + 0.05 * sb.dist[small];
                           if (score < pickScore) {
                              pickScore = score;
                              pick = sb;
                           }
                        }
                     }

                     if (pick == null) {
                        break;
                     }

                     sideOf.put(pick.name, small);
                     int var77 = count[big]--;
                     var77 = count[small]++;
                     power[big] -= pick.power;
                     power[small] += pick.power;
                     LAST_MOVED.put(pick.name.toLowerCase(Locale.ROOT), now);
                  }

                  for(int swaps = 0; swaps < 2; ++swaps) {
                     int strong = 0;
                     int weak = 0;

                     for(int i = 1; i < n; ++i) {
                        if (power[i] > power[strong]) {
                           strong = i;
                        }

                        if (power[i] < power[weak]) {
                           weak = i;
                        }
                     }

                     double gap = power[strong] - power[weak];
                     double avg = (double)0.0F;

                     for(double p : power) {
                        avg += p;
                     }

                     avg /= (double)n;
                     if (strong == weak || avg <= (double)0.0F || gap < 0.15 * avg) {
                        break;
                     }

                     ScoredBot bestA = null;
                     ScoredBot bestB = null;
                     double bestGap = gap;

                     for(ScoredBot a : bots) {
                        if ((Integer)sideOf.get(a.name) == strong && !recentlyMoved(a.name, now)) {
                           for(ScoredBot b : bots) {
                              if ((Integer)sideOf.get(b.name) == weak && !recentlyMoved(b.name, now)) {
                                 double d = a.power - b.power;
                                 if (!(d <= (double)0.0F)) {
                                    double newGap = Math.abs(gap - (double)2.0F * d);
                                    double travel = a.dist[weak] + b.dist[strong] - (a.dist[strong] + b.dist[weak]);
                                    double score = newGap + 0.05 * Math.max((double)0.0F, travel);
                                    if (newGap < gap * (double)0.75F && score < bestGap) {
                                       bestGap = score;
                                       bestA = a;
                                       bestB = b;
                                    }
                                 }
                              }
                           }
                        }
                     }

                     if (bestA == null) {
                        break;
                     }

                     sideOf.put(bestA.name, weak);
                     sideOf.put(bestB.name, strong);
                     power[strong] += bestB.power - bestA.power;
                     power[weak] += bestA.power - bestB.power;
                     LAST_MOVED.put(bestA.name.toLowerCase(Locale.ROOT), now);
                     LAST_MOVED.put(bestB.name.toLowerCase(Locale.ROOT), now);
                  }

                  team.clearTargetAssignments();

                  for(ScoredBot sb : bots) {
                     team.setTargetAssignment(sb.name, (String)targets.get((Integer)sideOf.get(sb.name)));
                  }

                  if (LAST_MOVED.size() > 4096) {
                     LAST_MOVED.values().removeIf((tx) -> now - tx > 10000L);
                  }

               }
            }
         }
      }
   }

   public static synchronized boolean isSplitTarget(MinecraftServer server, TeamManager.BotTeam team, String name) {
      if (team != null && name != null) {
         if (team.getMode() == TeamManager.TargetMode.SPECIFIC_TEAMS) {
            return isSplitTeamTarget(server, team, name);
         } else {
            List<String> targets = resolveTargets(server, team);
            return targets.size() >= 2 && indexOfTarget(targets, name) >= 0;
         }
      } else {
         return false;
      }
   }

   private static boolean isSplitTeamTarget(MinecraftServer server, TeamManager.BotTeam team, String name) {
      Set<String> wanted = new HashSet();

      for(String t : team.getTargetTeamNames()) {
         wanted.add(t.toLowerCase(Locale.ROOT));
      }

      Set<String> allies = new HashSet();

      for(String a : team.getAllies()) {
         allies.add(a.toLowerCase(Locale.ROOT));
      }

      TeamManager.BotTeam lastTeam = null;
      boolean lastWanted = false;
      int count = 0;
      boolean named = false;

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         boolean nameHit = !named && p.getScoreboardName().equalsIgnoreCase(name);
         if (count < 2 || nameHit) {
            TeamManager.BotTeam theirs = TeamManager.getTeamForMember(p.getScoreboardName());
            if (theirs != null && theirs != team) {
               if (theirs != lastTeam) {
                  String key = theirs.getName().toLowerCase(Locale.ROOT);
                  lastWanted = wanted.contains(key) && !allies.contains(key);
                  lastTeam = theirs;
               }

               if (lastWanted && p.isAlive() && !p.isSpectator() && (!team.ignoreCreative || !p.isCreative())) {
                  ++count;
                  if (nameHit) {
                     named = true;
                  }

                  if (named && count >= 2) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private static List<String> resolveTargets(MinecraftServer server, TeamManager.BotTeam team) {
      List<String> out = new ArrayList();

      for(ServerPlayer p : resolveTargetPlayers(server, team)) {
         out.add(p.getName().getString());
      }

      return out;
   }

   private static List<ServerPlayer> resolveTargetPlayers(MinecraftServer server, TeamManager.BotTeam team) {
      List<ServerPlayer> out = new ArrayList();
      if (team.getMode() == TeamManager.TargetMode.SPECIFIC) {
         for(String name : team.getTargetNames()) {
            ServerPlayer p = BotManager.resolveNonBotPlayerByName(server, name);
            if (p == null) {
               p = BotManager.resolveTrackedBotPlayer(server, name);
            }

            addIfLive(out, p, team.ignoreCreative);
         }
      } else if (team.getMode() == TeamManager.TargetMode.SPECIFIC_TEAMS) {
         Set<String> wanted = new HashSet();

         for(String t : team.getTargetTeamNames()) {
            wanted.add(t.toLowerCase(Locale.ROOT));
         }

         Set<String> allies = new HashSet();

         for(String a : team.getAllies()) {
            allies.add(a.toLowerCase(Locale.ROOT));
         }

         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            TeamManager.BotTeam theirs = TeamManager.getTeamForMember(p.getScoreboardName());
            if (theirs != null && theirs != team) {
               String key = theirs.getName().toLowerCase(Locale.ROOT);
               if (wanted.contains(key) && !allies.contains(key)) {
                  addIfLive(out, p, team.ignoreCreative);
               }
            }
         }
      }

      out.sort(Comparator.comparing((px) -> px.getName().getString()));
      return out;
   }

   private static void addIfLive(List<ServerPlayer> out, ServerPlayer p, boolean ignoreCreative) {
      if (p != null && p.isAlive() && !p.isSpectator() && (!ignoreCreative || !p.isCreative())) {
         if (!out.contains(p)) {
            out.add(p);
         }

      }
   }

   private static String pinOf(Map<String, String> pins, String botName) {
      for(Map.Entry<String, String> e : pins.entrySet()) {
         if (e.getKey() != null && ((String)e.getKey()).equalsIgnoreCase(botName)) {
            return (String)e.getValue();
         }
      }

      return null;
   }

   private static int placeSide(ScoredBot sb, int[] count, double[] power) {
      int min = Integer.MAX_VALUE;

      for(int c : count) {
         min = Math.min(min, c);
      }

      int nearest = -1;
      int weakest = -1;
      double avg = (double)0.0F;

      for(double p : power) {
         avg += p;
      }

      avg /= (double)power.length;

      for(int i = 0; i < count.length; ++i) {
         if (count[i] == min) {
            if (nearest < 0 || sb.dist[i] < sb.dist[nearest]) {
               nearest = i;
            }

            if (weakest < 0 || power[i] < power[weakest] - 1.0E-6) {
               weakest = i;
            }
         }
      }

      return power[nearest] - power[weakest] > 0.15 * Math.max(avg, (double)1.0F) ? weakest : nearest;
   }

   private static boolean recentlyMoved(String botName, long now) {
      Long t = (Long)LAST_MOVED.get(botName.toLowerCase(Locale.ROOT));
      return t != null && now - t < 10000L;
   }

   private static int indexOfTarget(List<String> targets, String pinned) {
      if (pinned == null) {
         return -1;
      } else {
         for(int i = 0; i < targets.size(); ++i) {
            if (((String)targets.get(i)).equalsIgnoreCase(pinned)) {
               return i;
            }
         }

         return -1;
      }
   }

   private static record ScoredBot(String name, double power, double[] dist) {
   }
}
