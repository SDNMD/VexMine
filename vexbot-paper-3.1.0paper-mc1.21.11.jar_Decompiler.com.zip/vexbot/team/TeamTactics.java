package vexbot.team;

import vexbot.bot.ai.FollowFormation;

public final class TeamTactics {
   public volatile FollowFormation.Type formation;
   public volatile int formationSize;
   public volatile double spacing;
   public volatile double movementSpeed;
   public volatile String boss;
   public volatile boolean protectBoss;
   public volatile boolean focusBossTarget;
   public volatile boolean followBoss;
   public volatile boolean maintainFormation;
   public volatile boolean retreatWhenLow;
   public volatile ShieldBehaviour shieldBehaviour;
   public volatile RangedPositioning rangedPositioning;
   public volatile TargetPriority targetPriority;
   public volatile double regroupDistance;
   public volatile double maxDistanceFromBoss;
   public volatile String hornPlayer;
   public volatile String hornType;
   public volatile FollowFormation.Type hornFormation;

   public TeamTactics() {
      this.formation = FollowFormation.Type.NONE;
      this.formationSize = 10;
      this.spacing = (double)2.0F;
      this.movementSpeed = (double)1.0F;
      this.boss = "";
      this.protectBoss = true;
      this.focusBossTarget = true;
      this.followBoss = true;
      this.maintainFormation = true;
      this.retreatWhenLow = false;
      this.shieldBehaviour = TeamTactics.ShieldBehaviour.FREE;
      this.rangedPositioning = TeamTactics.RangedPositioning.ANYWHERE;
      this.targetPriority = TeamTactics.TargetPriority.INDEPENDENT;
      this.regroupDistance = (double)15.0F;
      this.maxDistanceFromBoss = (double)20.0F;
      this.hornPlayer = "";
      this.hornType = "";
      this.hornFormation = FollowFormation.Type.LINE;
   }

   public boolean hasBoss() {
      return this.boss != null && !this.boss.isBlank();
   }

   public boolean hornArmed() {
      return this.hornType != null && !this.hornType.isBlank();
   }

   public boolean active() {
      return this.formation != FollowFormation.Type.NONE || this.hasBoss() || this.hornArmed() || this.targetPriority != TeamTactics.TargetPriority.INDEPENDENT;
   }

   public static enum ShieldBehaviour {
      FREE,
      SHIELDS_UP,
      SHIELD_WALL;

      // $FF: synthetic method
      private static ShieldBehaviour[] $values() {
         return new ShieldBehaviour[]{FREE, SHIELDS_UP, SHIELD_WALL};
      }
   }

   public static enum RangedPositioning {
      ANYWHERE,
      BEHIND_FRONTLINE,
      INSIDE;

      // $FF: synthetic method
      private static RangedPositioning[] $values() {
         return new RangedPositioning[]{ANYWHERE, BEHIND_FRONTLINE, INSIDE};
      }
   }

   public static enum TargetPriority {
      INDEPENDENT,
      BOSS_TARGET,
      WEAKEST,
      BOSS_ATTACKER;

      // $FF: synthetic method
      private static TargetPriority[] $values() {
         return new TargetPriority[]{INDEPENDENT, BOSS_TARGET, WEAKEST, BOSS_ATTACKER};
      }
   }

   public static enum GroupAction {
      NONE,
      JUMP,
      SWING,
      CROUCH,
      WAVE;

      // $FF: synthetic method
      private static GroupAction[] $values() {
         return new GroupAction[]{NONE, JUMP, SWING, CROUCH, WAVE};
      }
   }
}
