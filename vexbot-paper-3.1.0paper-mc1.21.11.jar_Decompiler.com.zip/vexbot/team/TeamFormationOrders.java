package vexbot.team;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.bot.BotManager;
import vexbot.bot.ai.FollowFormation;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;

public final class TeamFormationOrders {
   private static final int INTERVAL = 10;
   private static int tickCounter = 0;
   private static final double WEAKEST_RADIUS = (double)32.0F;
   private static final Map<String, Escort> ESCORTS = new ConcurrentHashMap();
   private static final Map<String, String> ESCORT_SIG = new ConcurrentHashMap();
   private static final Map<String, Set<String>> ESCORT_SEEN = new ConcurrentHashMap();
   private static final Map<String, Lock> LOCKS = new ConcurrentHashMap();
   private static final Set<String> DETACHED = ConcurrentHashMap.newKeySet();
   private static final Map<String, String> STOOD_DOWN = new ConcurrentHashMap();
   private static final Map<String, SlotPlan> SLOT_PLANS = new ConcurrentHashMap();

   private TeamFormationOrders() {
   }

   private static String escortSig(TeamTactics tc) {
      boolean want = tc.hasBoss() && tc.followBoss && tc.formation != FollowFormation.Type.NONE;
      return want ? key(tc.boss) + "|" + String.valueOf(tc.formation) + "|" + tc.formationSize : "";
   }

   public static void standDown(String teamName) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team != null) {
         STOOD_DOWN.put(key(team.getName()), escortSig(team.tactics));
      }

   }

   public static void resume(String teamName) {
      if (teamName != null) {
         STOOD_DOWN.remove(key(teamName));
      }

   }

   public static boolean isStoodDown(String teamName) {
      return teamName != null && STOOD_DOWN.containsKey(key(teamName));
   }

   private static ServerPlayer bossPlayer(MinecraftServer server, TeamTactics tc) {
      if (!tc.hasBoss()) {
         return null;
      } else {
         ServerPlayer b = BotManager.resolvePlayerOrBotByName(server, tc.boss);
         return b != null && b.isAlive() ? b : null;
      }
   }

   private static String bossTarget(TeamTactics tc, ServerPlayer boss) {
      String t = BotManager.currentTargetName(tc.boss);
      if (t != null) {
         return t;
      } else {
         LivingEntity hit = boss.getLastHurtMob();
         if (hit instanceof ServerPlayer) {
            ServerPlayer sp = (ServerPlayer)hit;
            if (sp.isAlive() && !sp.isSpectator() && boss.tickCount - boss.getLastHurtMobTimestamp() < 200) {
               return sp.getName().getString();
            }
         }

         return null;
      }
   }

   private static String key(String s) {
      return s == null ? "" : s.toLowerCase(Locale.ROOT);
   }

   public static void onServerTick(MinecraftServer server) {
      if (++tickCounter % 10 == 0) {
         Set<String> live = new HashSet();

         for(TeamManager.BotTeam team : TeamManager.allTeams()) {
            live.add(key(team.getName()));
            applyBossEscort(team, team.tactics);
            applyTargets(server, team, team.tactics);
         }

         for(Map.Entry<String, Escort> e : new ArrayList(ESCORTS.entrySet())) {
            if (!live.contains(((Escort)e.getValue()).team())) {
               releaseEscort((String)e.getKey());
            }
         }

         for(Map.Entry<String, Lock> e : new ArrayList(LOCKS.entrySet())) {
            if (!live.contains(((Lock)e.getValue()).team())) {
               releaseLock((String)e.getKey());
            }
         }

         ESCORT_SIG.keySet().retainAll(live);
         ESCORT_SEEN.keySet().retainAll(live);
         STOOD_DOWN.keySet().retainAll(live);
      }
   }

   private static void applyBossEscort(TeamManager.BotTeam team, TeamTactics tc) {
      String tk = key(team.getName());
      String base = escortSig(tc);
      String downAt = (String)STOOD_DOWN.get(tk);
      if (downAt != null && !downAt.equals(base)) {
         STOOD_DOWN.remove(tk);
         downAt = null;
      }

      boolean want = !base.isEmpty() && downAt == null;
      String sig = want ? base : "";
      if (!sig.equals(ESCORT_SIG.getOrDefault(tk, ""))) {
         for(Map.Entry<String, Escort> e : new ArrayList(ESCORTS.entrySet())) {
            if (((Escort)e.getValue()).team().equals(tk)) {
               releaseEscort((String)e.getKey());
            }
         }

         ESCORT_SEEN.put(tk, ConcurrentHashMap.newKeySet());
         ESCORT_SIG.put(tk, sig);
      }

      for(Map.Entry<String, Escort> e : new ArrayList(ESCORTS.entrySet())) {
         if (((Escort)e.getValue()).team().equals(tk)) {
            String bot = ((Escort)e.getValue()).bot();
            if (!TeamManager.isMemberOfTeam(team.getName(), bot) || bot.equalsIgnoreCase(tc.boss)) {
               releaseEscort((String)e.getKey());
            }
         }
      }

      if (want) {
         Set<String> seen = (Set)ESCORT_SEEN.computeIfAbsent(tk, (k) -> ConcurrentHashMap.newKeySet());

         for(String mate : team.getBotNames()) {
            if (!mate.equalsIgnoreCase(tc.boss) && seen.add(key(mate)) && BotManager.getFollowTarget(mate) == null) {
               BotManager.setFollowTarget(mate, tc.boss, tc.formation, tc.formationSize);
               ESCORTS.put(key(mate), new Escort(tk, tc.boss, mate));
            }
         }

      }
   }

   private static void releaseEscort(String botKey) {
      DETACHED.remove(botKey);
      Escort e = (Escort)ESCORTS.remove(botKey);
      if (e != null) {
         String now = BotManager.getFollowTarget(e.bot());
         if (now != null && now.equalsIgnoreCase(e.boss())) {
            BotManager.clearFollowTarget(e.bot());
         }

      }
   }

   private static void applyTargets(MinecraftServer server, TeamManager.BotTeam team, TeamTactics tc) {
      ServerPlayer boss = bossPlayer(server, tc);
      String chosen = null;
      if (boss != null && tc.protectBoss) {
         chosen = attackerOf(boss, team);
      }

      if (chosen == null) {
         String var10000;
         switch (tc.targetPriority) {
            case INDEPENDENT -> var10000 = tc.focusBossTarget && boss != null ? bossTarget(tc, boss) : null;
            case BOSS_TARGET -> var10000 = boss != null ? bossTarget(tc, boss) : null;
            case BOSS_ATTACKER -> var10000 = boss != null ? attackerOf(boss, team) : null;
            case WEAKEST -> var10000 = weakestEnemy(server, team, boss);
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         chosen = var10000;
      }

      if (chosen != null && (TeamManager.isMemberOfTeam(team.getName(), chosen) || allied(team, chosen))) {
         chosen = null;
      }

      String tk = key(team.getName());

      for(String mate : team.getBotNames()) {
         if (!mate.equalsIgnoreCase(tc.boss) || tc.targetPriority == TeamTactics.TargetPriority.WEAKEST) {
            String mk = key(mate);
            String held = BotManager.getAttackTarget(mate);
            if (chosen == null) {
               releaseLock(mk);
            } else if (held == null || !chosen.equalsIgnoreCase(held)) {
               if (!tc.maintainFormation && ESCORTS.containsKey(mk)) {
                  DETACHED.add(mk);
               }

               BotManager.setAttackTarget(mate, chosen, tc.maintainFormation);
               LOCKS.put(mk, new Lock(tk, chosen, mate));
            }
         }
      }

      for(Map.Entry<String, Lock> e : new ArrayList(LOCKS.entrySet())) {
         if (((Lock)e.getValue()).team().equals(tk) && !TeamManager.isMemberOfTeam(team.getName(), ((Lock)e.getValue()).bot())) {
            releaseLock((String)e.getKey());
         }
      }

   }

   public static boolean isTeamOrder(String botName, String target) {
      Lock l = (Lock)LOCKS.get(key(botName));
      return l != null && target != null && l.target().equalsIgnoreCase(target);
   }

   private static void releaseLock(String botKey) {
      Lock l = (Lock)LOCKS.remove(botKey);
      if (l != null) {
         String held = BotManager.getAttackTarget(l.bot());
         if (held != null && held.equalsIgnoreCase(l.target())) {
            BotManager.clearAttackTarget(l.bot());
         }

         Escort e = (Escort)ESCORTS.get(botKey);
         if (DETACHED.remove(botKey) && e != null && BotManager.getFollowTarget(e.bot()) == null) {
            TeamManager.BotTeam team = TeamManager.get(e.team());
            if (team != null && team.tactics.formation != FollowFormation.Type.NONE) {
               BotManager.setFollowTarget(e.bot(), e.boss(), team.tactics.formation, team.tactics.formationSize);
            }
         }

      }
   }

   private static String attackerOf(ServerPlayer boss, TeamManager.BotTeam team) {
      LivingEntity a = boss.getLastHurtByMob();
      if (a instanceof ServerPlayer sp) {
         if (sp.isAlive() && !sp.isSpectator() && !sp.isCreative()) {
            String n = sp.getName().getString();
            if (!TeamManager.isMemberOfTeam(team.getName(), n) && !allied(team, n)) {
               return n;
            }

            return null;
         }
      }

      return null;
   }

   private static String weakestEnemy(MinecraftServer server, TeamManager.BotTeam team, ServerPlayer boss) {
      List<ServerPlayer> mates = new ArrayList();
      if (boss == null) {
         for(String n : team.getBotNames()) {
            ServerPlayer p = BotManager.resolveTrackedBotPlayer(server, n);
            if (p != null && p.isAlive()) {
               mates.add(p);
            }
         }
      }

      ServerPlayer anchor = boss != null ? boss : (mates.isEmpty() ? null : (ServerPlayer)mates.get(0));
      if (anchor == null) {
         return null;
      } else {
         double cy;
         double cz;
         double cx;
         if (boss != null) {
            cx = boss.getX();
            cy = boss.getY();
            cz = boss.getZ();
         } else {
            cx = (double)0.0F;
            cy = (double)0.0F;
            cz = (double)0.0F;

            for(ServerPlayer m : mates) {
               cx += m.getX();
               cy += m.getY();
               cz += m.getZ();
            }

            cx /= (double)mates.size();
            cy /= (double)mates.size();
            cz /= (double)mates.size();
         }

         boolean ignoreCreative = team.ignoreCreative;
         boolean targetBots = team.targetBots;
         boolean targetPlayers = team.targetPlayers;
         String best = null;
         double bestHp = Double.MAX_VALUE;

         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isAlive() && !p.isSpectator() && p.level() == anchor.level() && (!ignoreCreative || !p.isCreative())) {
               String n = p.getName().getString();
               if (!TeamManager.isMemberOfTeam(team.getName(), n) && !allied(team, n)) {
                  boolean isBot = McCompat.tags(p).contains("vexbot");
                  if (isBot) {
                     if (!targetBots) {
                        continue;
                     }
                  } else if (!targetPlayers) {
                     continue;
                  }

                  double dx = p.getX() - cx;
                  double dy = p.getY() - cy;
                  double dz = p.getZ() - cz;
                  if (!(dx * dx + dy * dy + dz * dz > (double)1024.0F)) {
                     double hp = (double)(p.getHealth() + p.getAbsorptionAmount());
                     if (hp < bestHp) {
                        bestHp = hp;
                        best = n;
                     }
                  }
               }
            }
         }

         return best;
      }
   }

   private static boolean allied(TeamManager.BotTeam team, String name) {
      TeamManager.BotTeam other = TeamManager.getTeamForMember(name);
      if (other == null) {
         return false;
      } else {
         for(String a : team.getAllies()) {
            if (a.equalsIgnoreCase(other.getName())) {
               return true;
            }
         }

         return false;
      }
   }

   public static TeamTactics tacticsFor(String botName) {
      TeamManager.BotTeam t = TeamManager.getTeamForBot(botName);
      return t == null ? null : t.tactics;
   }

   public static double regroupDistance(String botName, String followName) {
      TeamTactics tc = tacticsFor(botName);
      if (tc != null && tc.hasBoss() && tc.maintainFormation && followName != null) {
         return tc.boss.equalsIgnoreCase(followName) ? tc.regroupDistance : (double)-1.0F;
      } else {
         return (double)-1.0F;
      }
   }

   public static ServerPlayer leashTarget(MinecraftServer server, ServerPlayer bot, boolean returning) {
      String name = bot.getScoreboardName();
      TeamManager.BotTeam team = TeamManager.getTeamForBot(name);
      TeamTactics tc = team == null ? null : team.tactics;
      if (tc != null && tc.hasBoss() && tc.followBoss && !name.equalsIgnoreCase(tc.boss)) {
         if (isStoodDown(team.getName())) {
            return null;
         } else {
            ServerPlayer boss = bossPlayer(server, tc);
            if (boss != null && boss.level() == bot.level()) {
               double limit = Math.max((double)4.0F, tc.maxDistanceFromBoss);
               return (double)bot.distanceTo(boss) > (returning ? limit - (double)4.0F : limit) ? boss : null;
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   public static int slotIndex(MinecraftServer server, String botName, String leaderName, List<String> group, FollowFormation.Type formation, int rowWidth, boolean centreTaken) {
      int plain = -1;

      for(int i = 0; i < group.size(); ++i) {
         if (((String)group.get(i)).equalsIgnoreCase(botName)) {
            plain = i;
            break;
         }
      }

      TeamTactics tc = tacticsFor(botName);
      if (plain >= 0 && tc != null && tc.rangedPositioning != TeamTactics.RangedPositioning.ANYWHERE && formation != FollowFormation.Type.NONE && group.size() >= 2) {
         String k = key(leaderName) + "|" + String.valueOf(formation) + "|" + rowWidth + "|" + String.valueOf(tc.rangedPositioning) + "|" + String.join(",", group);
         long tick = (long)server.getTickCount();
         SlotPlan plan = (SlotPlan)SLOT_PLANS.get(k);
         if (plan == null || plan.tick() != tick) {
            if (SLOT_PLANS.size() > 64) {
               SLOT_PLANS.clear();
            }

            plan = new SlotPlan(tick, plan(server, group, formation, rowWidth, tc.rangedPositioning, centreTaken));
            SLOT_PLANS.put(k, plan);
         }

         return (Integer)plan.index().getOrDefault(key(botName), plain);
      } else {
         return plain;
      }
   }

   private static Map<String, Integer> plan(MinecraftServer server, List<String> group, FollowFormation.Type formation, int rowWidth, TeamTactics.RangedPositioning mode, boolean centreTaken) {
      int n = group.size();
      boolean shift = centreTaken && FollowFormation.reservesCentre(formation);
      double[] rank = new double[n];

      for(int i = 0; i < n; ++i) {
         double[] off = FollowFormation.localOffset(formation, shift ? i + 1 : i, shift ? n + 1 : n, rowWidth);
         rank[i] = mode == TeamTactics.RangedPositioning.BEHIND_FRONTLINE ? off[0] : -Math.hypot(off[0], off[1]);
      }

      Integer[] slots = new Integer[n];

      for(int i = 0; i < n; ++i) {
         slots[i] = i;
      }

      Arrays.sort(slots, (a, b) -> Double.compare(rank[a], rank[b]));
      List<String> ordered = new ArrayList(n);
      List<String> archers = new ArrayList();

      for(String g : group) {
         if (isArcher(server, g)) {
            archers.add(g);
         } else {
            ordered.add(g);
         }
      }

      ordered.addAll(archers);
      Map<String, Integer> out = new HashMap();

      for(int j = 0; j < n; ++j) {
         out.put(key((String)ordered.get(j)), slots[j]);
      }

      return out;
   }

   private static boolean isArcher(MinecraftServer server, String name) {
      ServerPlayer p = BotManager.resolveTrackedBotPlayer(server, name);
      if (p == null) {
         return false;
      } else {
         boolean bow = false;
         boolean melee = false;

         for(int i = 0; i < 9; ++i) {
            ItemStack st = p.getInventory().getItem(i);
            if (!st.isEmpty()) {
               if (st.is(Items.BOW) || st.is(Items.CROSSBOW)) {
                  bow = true;
               }

               if (st.is(ItemTags.SWORDS) || st.is(ItemTags.AXES) || st.is(ItemTags.SPEARS) || st.is(Items.MACE) || st.is(Items.TRIDENT)) {
                  melee = true;
               }
            }
         }

         return bow && !melee;
      }
   }

   public static int groupAction(MinecraftServer server, String teamName, TeamTactics.GroupAction action) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         return 0;
      } else {
         int n = 0;

         for(String botName : team.getBotNames()) {
            ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, botName);
            if (bot != null) {
               switch (action) {
                  case JUMP:
                     BotCommands.jumpOnce(server, botName);
                     break;
                  case SWING:
                     McCompat.swing(bot, InteractionHand.MAIN_HAND);
                     break;
                  case WAVE:
                     McCompat.swing(bot, InteractionHand.MAIN_HAND);
                     BotCommands.jumpOnce(server, botName);
                     break;
                  case CROUCH:
                     bot.setShiftKeyDown(!bot.isShiftKeyDown());
                  case NONE:
               }

               ++n;
            }
         }

         return n;
      }
   }

   private static record Escort(String team, String boss, String bot) {
   }

   private static record Lock(String team, String target, String bot) {
   }

   private static record SlotPlan(long tick, Map<String, Integer> index) {
   }
}
