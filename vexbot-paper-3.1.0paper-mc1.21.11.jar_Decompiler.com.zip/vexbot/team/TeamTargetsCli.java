package vexbot.team;

import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.SettingsPersistence;
import vexbot.i18n.VexText;

public final class TeamTargetsCli {
   public static final String[] MODE_SUGGESTIONS = new String[]{"none", "all", "specific", "teams"};

   private TeamTargetsCli() {
   }

   public static CompletableFuture<Suggestions> suggestModes(CommandSourceStack source, SuggestionsBuilder builder) {
      return SharedSuggestionProvider.suggest(MODE_SUGGESTIONS, builder);
   }

   public static CompletableFuture<Suggestions> suggestOtherTeams(CommandSourceStack source, SuggestionsBuilder builder, String selfTeam) {
      List<String> names = TeamManager.teamNames().stream().filter((n) -> !n.equalsIgnoreCase(selfTeam)).sorted().toList();
      return SharedSuggestionProvider.suggest(names, builder);
   }

   public static CompletableFuture<Suggestions> suggestAttackablePlayers(CommandSourceStack source, SuggestionsBuilder builder, String teamName) {
      MinecraftServer server = source.getServer();
      List<String> names = new ArrayList();

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (!p.isSpectator()) {
            String name = p.getName().getString();
            if (!TeamManager.isMemberOfTeam(teamName, name)) {
               names.add(name);
            }
         }
      }

      names.sort(String::compareToIgnoreCase);
      return SharedSuggestionProvider.suggest(names, builder);
   }

   public static int show(CommandSourceStack source, String teamName) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else {
         TeamManager.TargetMode mode = team.getMode();
         String var10000;
         switch (mode) {
            case NONE -> var10000 = "§cnone §8(stop)";
            case ALL_PLAYERS -> var10000 = "§aall §8(attack everyone)";
            case SPECIFIC -> var10000 = "§bspecific";
            case SPECIFIC_TEAMS -> var10000 = "§9teams";
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         String modeLabel = var10000;
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r targeting:"), false);
         source.sendSuccess(() -> VexText.literal("  mode = " + modeLabel), false);
         source.sendSuccess(() -> VexText.literal("  revenge = §f" + (team.isRevengeMode() ? "on" : "off")), false);
         if (!team.getTargetNames().isEmpty()) {
            source.sendSuccess(() -> VexText.literal("  targets = §f" + String.join("§7, §f", team.getTargetNames())), false);
         }

         if (!team.getTargetTeamNames().isEmpty()) {
            source.sendSuccess(() -> VexText.literal("  target_teams = §f" + String.join("§7, §f", team.getTargetTeamNames())), false);
         }

         source.sendSuccess(() -> VexText.literal("§8Use §e/vexbot team " + teamName + " targets mode <none|all|specific|teams>§8, or §eadd/remove/addteam§8."), false);
         return 1;
      }
   }

   public static int setMode(CommandSourceStack source, String teamName, String rawMode) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else {
         TeamManager.TargetMode mode = parseMode(rawMode);
         if (mode == null) {
            source.sendFailure(VexText.literal("[VexBot] Unknown mode '§e" + rawMode + "§r'. Use: none, all, specific, teams."));
            return 0;
         } else {
            switch (mode) {
               case NONE:
                  TeamManager.setTargets(teamName, List.of());
                  TeamManager.setTargetTeams(teamName, List.of());
                  TeamManager.setMode(teamName, TeamManager.TargetMode.NONE);
                  break;
               case ALL_PLAYERS:
                  TeamManager.setMode(teamName, TeamManager.TargetMode.ALL_PLAYERS);
                  break;
               case SPECIFIC:
                  TeamManager.setMode(teamName, TeamManager.TargetMode.SPECIFIC);
                  break;
               case SPECIFIC_TEAMS:
                  TeamManager.setMode(teamName, TeamManager.TargetMode.SPECIFIC_TEAMS);
            }

            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r mode set to §f" + modeLabel(mode) + "§r."), false);
            return 1;
         }
      }
   }

   public static int addTarget(CommandSourceStack source, String teamName, String playerName) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else if (TeamManager.isMemberOfTeam(teamName, playerName)) {
         source.sendFailure(VexText.literal("[VexBot] §e" + playerName + "§r is on team §e" + teamName + "§r's roster — cannot attack. Remove them with §e/vexbot team " + teamName + " members remove " + playerName + "§r."));
         return 0;
      } else {
         Set<String> targets = new LinkedHashSet(team.getTargetNames());
         if (TeamManager.targetNamesContains(targets, playerName)) {
            source.sendFailure(VexText.literal("[VexBot] §e" + playerName + "§r is already a target."));
            return 0;
         } else {
            targets.add(playerName.strip());
            TeamManager.setTargets(teamName, targets);
            persist(source);
            int n = targets.size();
            source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r now targeting §e" + playerName + "§r" + (n >= 2 ? " §7(§f" + n + " §7targets)" : "") + "."), false);
            return 1;
         }
      }
   }

   public static int removeTarget(CommandSourceStack source, String teamName, String playerName) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else {
         Set<String> targets = new LinkedHashSet(team.getTargetNames());
         if (!TeamManager.targetNamesContains(targets, playerName)) {
            source.sendFailure(VexText.literal("[VexBot] §e" + playerName + "§r is not in team §e" + teamName + "§r's target list."));
            return 0;
         } else {
            TeamManager.toggleTargetName(targets, playerName);
            TeamManager.setTargets(teamName, targets);
            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Removed §e" + playerName + "§r from team §e" + teamName + "§r targets."), false);
            return 1;
         }
      }
   }

   public static int clearTargets(CommandSourceStack source, String teamName) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else {
         TeamManager.setTargets(teamName, List.of());
         persist(source);
         source.sendSuccess(() -> VexText.literal("[VexBot] Cleared all player targets for team §e" + teamName + "§r."), false);
         return 1;
      }
   }

   public static int addTargetTeam(CommandSourceStack source, String teamName, String otherTeam) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else if (teamName.equalsIgnoreCase(otherTeam)) {
         source.sendFailure(VexText.literal("[VexBot] A team cannot target itself."));
         return 0;
      } else if (!TeamManager.exists(otherTeam)) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + otherTeam + "§r'."));
         return 0;
      } else {
         String other = TeamManager.canonicalName(otherTeam);
         Set<String> teams = new LinkedHashSet(team.getTargetTeamNames());
         if (findTeamIgnoreCase(teams, other) != null) {
            source.sendFailure(VexText.literal("[VexBot] Team §e" + other + "§r is already targeted."));
            return 0;
         } else {
            teams.add(other);
            TeamManager.setTargetTeams(teamName, teams);
            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r now targets team §e" + other + "§r."), false);
            return 1;
         }
      }
   }

   public static int removeTargetTeam(CommandSourceStack source, String teamName, String otherTeam) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else {
         Set<String> teams = new LinkedHashSet(team.getTargetTeamNames());
         String existing = findTeamIgnoreCase(teams, otherTeam);
         if (existing == null) {
            source.sendFailure(VexText.literal("[VexBot] Team §e" + otherTeam + "§r is not in §e" + teamName + "§r's target list."));
            return 0;
         } else {
            teams.remove(existing);
            TeamManager.setTargetTeams(teamName, teams);
            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Removed team §e" + existing + "§r from §e" + teamName + "§r targets."), false);
            return 1;
         }
      }
   }

   public static int clearTargetTeams(CommandSourceStack source, String teamName) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else {
         TeamManager.setTargetTeams(teamName, List.of());
         persist(source);
         source.sendSuccess(() -> VexText.literal("[VexBot] Cleared all team targets for §e" + teamName + "§r."), false);
         return 1;
      }
   }

   public static int setRevenge(CommandSourceStack source, String teamName, String raw) {
      TeamManager.BotTeam team = requireTeam(source, teamName);
      if (team == null) {
         return 0;
      } else {
         boolean next;
         try {
            next = parseBool(raw, team.isRevengeMode());
         } catch (IllegalArgumentException e) {
            source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
            return 0;
         }

         TeamManager.setTeamRevengeMode(teamName, next);
         persist(source);
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r revenge mode set to §f" + (next ? "on" : "off") + "§r."), false);
         return 1;
      }
   }

   private static TeamManager.BotTeam requireTeam(CommandSourceStack source, String teamName) {
      if (!TeamManager.exists(teamName)) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return null;
      } else {
         return TeamManager.get(teamName);
      }
   }

   private static void persist(CommandSourceStack source) {
      SettingsPersistence.save(source.getServer());
   }

   private static TeamManager.TargetMode parseMode(String raw) {
      if (raw == null) {
         return null;
      } else {
         TeamManager.TargetMode var10000;
         switch (normalize(raw)) {
            case "none":
            case "stop":
            case "off":
               var10000 = TeamManager.TargetMode.NONE;
               break;
            case "all":
            case "allplayers":
               var10000 = TeamManager.TargetMode.ALL_PLAYERS;
               break;
            case "specific":
            case "spec":
               var10000 = TeamManager.TargetMode.SPECIFIC;
               break;
            case "teams":
            case "specificteams":
            case "specteams":
               var10000 = TeamManager.TargetMode.SPECIFIC_TEAMS;
               break;
            default:
               var10000 = null;
         }

         return var10000;
      }
   }

   private static String modeLabel(TeamManager.TargetMode mode) {
      String var10000;
      switch (mode) {
         case NONE -> var10000 = "none";
         case ALL_PLAYERS -> var10000 = "all";
         case SPECIFIC -> var10000 = "specific";
         case SPECIFIC_TEAMS -> var10000 = "teams";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private static boolean parseBool(String raw, boolean current) {
      boolean var10000;
      switch (normalize(raw)) {
         case "on":
         case "true":
         case "yes":
         case "enable":
         case "1":
            var10000 = true;
            break;
         case "off":
         case "false":
         case "no":
         case "disable":
         case "0":
            var10000 = false;
            break;
         case "toggle":
            var10000 = !current;
            break;
         default:
            throw new IllegalArgumentException("Invalid value '§e" + raw + "§r'. Use: on, off, toggle.");
      }

      return var10000;
   }

   private static String normalize(String raw) {
      return raw.toLowerCase(Locale.ROOT).replace("-", "").replace("_", "");
   }

   private static String findTeamIgnoreCase(Set<String> teams, String query) {
      for(String t : teams) {
         if (t.equalsIgnoreCase(query)) {
            return t;
         }
      }

      return null;
   }
}
