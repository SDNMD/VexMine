package vexbot.team;

import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.SettingsPersistence;
import vexbot.bot.BotManager;
import vexbot.gui.PlayerMenuHelper;
import vexbot.i18n.VexText;

public final class TeamCreateCli {
   private TeamCreateCli() {
   }

   public static CompletableFuture<Suggestions> suggestBots(CommandSourceStack source, SuggestionsBuilder builder) {
      List<String> names = new ArrayList(BotManager.getBotNames());
      names.sort(String::compareToIgnoreCase);
      return SharedSuggestionProvider.suggest(names, builder);
   }

   public static CompletableFuture<Suggestions> suggestOnlineHumans(CommandSourceStack source, SuggestionsBuilder builder) {
      MinecraftServer server = source.getServer();
      List<String> names = new ArrayList();

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (PlayerMenuHelper.isRealPlayer(p) && !p.isSpectator()) {
            names.add(p.getName().getString());
         }
      }

      names.sort(String::compareToIgnoreCase);
      return SharedSuggestionProvider.suggest(names, builder);
   }

   public static int show(CommandSourceStack source, String teamName) {
      TeamManager.getOrCreate(teamName);
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         return 0;
      } else {
         String bots = team.getBotNames().isEmpty() ? "§8(none)" : "§f" + String.join("§7, §f", team.getBotNames());
         String players = team.getPlayerNames().isEmpty() ? "§8(none)" : "§f" + String.join("§7, §f", team.getPlayerNames());
         source.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + teamName + "§r roster:"), false);
         source.sendSuccess(() -> VexText.literal("  bots = " + bots), false);
         source.sendSuccess(() -> VexText.literal("  players = " + players), false);
         source.sendSuccess(() -> VexText.literal("§8Use §e/vexbot team create " + teamName + " addbot/removebot/addplayer/removeplayer§8."), false);
         return 1;
      }
   }

   public static int addBot(CommandSourceStack source, String teamName, String botName) {
      if (!isKnownBot(botName)) {
         source.sendFailure(VexText.literal("[VexBot] No bot named '§e" + botName + "§r'. Spawn it first with §e/vexbot spawn§r."));
         return 0;
      } else {
         TeamManager.BotTeam team = TeamManager.getOrCreate(teamName);
         Set<String> bots = new LinkedHashSet(team.getBotNames());
         if (containsIgnoreCase(bots, botName)) {
            source.sendFailure(VexText.literal("[VexBot] §e" + botName + "§r is already on team §e" + teamName + "§r."));
            return 0;
         } else {
            bots.add(resolveBotName(botName));
            TeamManager.setTeamBots(teamName, bots);
            BotManager.clearFollowTarget(resolveBotName(botName));
            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Added bot §e" + botName + "§r to team §e" + teamName + "§r."), false);
            return 1;
         }
      }
   }

   public static int removeBot(CommandSourceStack source, String teamName, String botName) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else {
         Set<String> bots = new LinkedHashSet(team.getBotNames());
         String existing = findIgnoreCase(bots, botName);
         if (existing == null) {
            source.sendFailure(VexText.literal("[VexBot] §e" + botName + "§r is not on team §e" + teamName + "§r."));
            return 0;
         } else {
            bots.remove(existing);
            TeamManager.setTeamBots(teamName, bots);
            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Removed bot §e" + existing + "§r from team §e" + teamName + "§r."), false);
            return 1;
         }
      }
   }

   public static int addPlayer(CommandSourceStack source, String teamName, String playerName) {
      if (playerName != null && !playerName.isBlank()) {
         TeamManager.BotTeam other = TeamManager.getTeamForMember(playerName);
         if (other != null && !other.getName().equalsIgnoreCase(teamName)) {
            source.sendFailure(VexText.literal("[VexBot] §e" + playerName + "§r is on team §e" + other.getName() + "§r. Remove them there first, or use §e/vexbot team leave§r."));
            return 0;
         } else {
            ServerPlayer live = BotManager.resolveNonBotPlayerByName(source.getServer(), playerName);
            String resolved = live != null ? live.getName().getString() : playerName.strip();
            TeamManager.addPlayerToTeam(teamName, resolved);
            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Added player §e" + resolved + "§r to team §e" + teamName + "§r."), false);
            return 1;
         }
      } else {
         source.sendFailure(VexText.literal("[VexBot] Player name cannot be empty."));
         return 0;
      }
   }

   public static int removePlayer(CommandSourceStack source, String teamName, String playerName) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else {
         String existing = findIgnoreCase(team.getPlayerNames(), playerName);
         if (existing == null) {
            source.sendFailure(VexText.literal("[VexBot] §e" + playerName + "§r is not on team §e" + teamName + "§r."));
            return 0;
         } else {
            TeamManager.removePlayerFromTeam(teamName, existing);
            persist(source);
            source.sendSuccess(() -> VexText.literal("[VexBot] Removed player §e" + existing + "§r from team §e" + teamName + "§r."), false);
            return 1;
         }
      }
   }

   public static int clearBots(CommandSourceStack source, String teamName) {
      TeamManager.getOrCreate(teamName);
      TeamManager.setTeamBots(teamName, List.of());
      persist(source);
      source.sendSuccess(() -> VexText.literal("[VexBot] Cleared all bots from team §e" + teamName + "§r."), false);
      return 1;
   }

   public static int clearPlayers(CommandSourceStack source, String teamName) {
      TeamManager.getOrCreate(teamName);
      TeamManager.setTeamPlayers(teamName, List.of());
      persist(source);
      source.sendSuccess(() -> VexText.literal("[VexBot] Cleared all players from team §e" + teamName + "§r."), false);
      return 1;
   }

   public static int clearRoster(CommandSourceStack source, String teamName) {
      TeamManager.getOrCreate(teamName);
      TeamManager.setTeamBots(teamName, List.of());
      TeamManager.setTeamPlayers(teamName, List.of());
      persist(source);
      source.sendSuccess(() -> VexText.literal("[VexBot] Cleared full roster for team §e" + teamName + "§r."), false);
      return 1;
   }

   private static void persist(CommandSourceStack source) {
      SettingsPersistence.save(source.getServer());
   }

   private static boolean isKnownBot(String name) {
      return BotManager.getBotNames().stream().anyMatch((n) -> n.equalsIgnoreCase(name)) || BotManager.isTrackedBotName(name);
   }

   private static String resolveBotName(String name) {
      for(String n : BotManager.getBotNames()) {
         if (n.equalsIgnoreCase(name)) {
            return n;
         }
      }

      return name.strip();
   }

   private static boolean containsIgnoreCase(Set<String> set, String query) {
      return findIgnoreCase(set, query) != null;
   }

   private static String findIgnoreCase(Set<String> set, String query) {
      if (query == null) {
         return null;
      } else {
         for(String s : set) {
            if (s != null && s.equalsIgnoreCase(query)) {
               return s;
            }
         }

         return null;
      }
   }
}
