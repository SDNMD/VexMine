package vexbot;

import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import vexbot.bot.loadout.RandomGearConfig;
import vexbot.settings.TechniqueConfig;

public final class BotSettings {
   public static volatile boolean equipArmor = true;
   public static volatile boolean usePotions = true;
   public static volatile boolean revengeMode = true;
   public static volatile boolean retreat = false;
   public static volatile boolean useCobwebs = true;
   public static volatile BunnyHopMode bunnyHopMode;
   public static volatile boolean autoTarget;
   public static volatile boolean targetPlayers;
   public static volatile boolean targetBots;
   public static volatile boolean targetMobs;
   public static volatile Difficulty difficulty;
   public static volatile DifficultyParams difficultyParams;
   public static final Map<String, DifficultyParams> botDifficulties;
   public static volatile boolean ffaRandomDifficulties;
   public static volatile CartDoctrine cartDoctrine;
   public static volatile boolean useCarting;
   public static final double VANILLA_ATTACK_RANGE = (double)3.0F;
   public static volatile double attackRange;
   public static volatile boolean statsEnabled;
   public static volatile BridgeMode bridgeMode;
   public static volatile GameLogs gameLogs;
   public static volatile CartMode cartMode;
   public static volatile boolean ignoreCreative;
   public static volatile boolean openDoors;
   public static volatile boolean wanderWhenIdle;
   public static volatile boolean useEnderPearl;
   public static volatile boolean botDontLeave;
   public static volatile boolean pearlChasing;
   public static volatile boolean botLeaveOnDeath;
   public static volatile boolean chorusEscape;
   public static volatile boolean fireEscape;
   public static volatile boolean enderChestRegear;
   public static volatile String namePool;
   public static volatile boolean shulkerSteal;
   public static volatile boolean shulkerRegear;
   public static volatile boolean showTags;
   public static volatile boolean spreadOut;
   public static volatile TechniqueConfig techniques;
   public static volatile boolean webEscape;
   public static volatile boolean waterBucketClutch;
   public static volatile boolean useBows;
   public static volatile boolean hitWeb;
   public static volatile boolean pickupLoot;
   public static volatile double buildUpMinHeight;
   public static volatile int botPing;
   public static volatile boolean doBlockExplosion;
   public static volatile boolean speedNoJump;
   public static volatile boolean maceTotem;
   public static volatile boolean chaseSpread;
   public static volatile boolean placeBlocksMoving;
   public static volatile boolean botAdvancements;
   public static volatile boolean botSpawnMobs;
   public static volatile double lootPackRadius;
   public static volatile HealingMode healingMode;
   public static volatile OffhandPreference offhandPreference;
   public static volatile double offhandTotemHearts;
   public static volatile boolean strafeInCombo;
   public static volatile String spawnAreaDim;
   public static volatile double spawnAreaX1;
   public static volatile double spawnAreaY1;
   public static volatile double spawnAreaZ1;
   public static volatile double spawnAreaX2;
   public static volatile double spawnAreaY2;
   public static volatile double spawnAreaZ2;
   public static volatile boolean useOrbitalStrike;
   private static final Map<String, PlayStyle> adaptiveResolved;
   public static final Map<PlayStyle, Integer> playStyleChances;
   public static final Map<String, PlayStyle> playStyles;
   private static final Map<String, PlayStyle> playStylesNorm;
   public static volatile double retreatHealthHearts;
   public static volatile boolean useScaffolding;
   public static volatile boolean kitPotionDoSplash;
   public static volatile boolean gotoMining;
   public static volatile boolean advancedSpawn;
   public static volatile boolean silentCommands;
   public static volatile boolean nullPortalJoinTeam;
   public static volatile String nameTagColour;
   public static volatile String nullPortalTeam;
   public static volatile boolean nullPortalBreakAfterSpawn;
   public static volatile boolean nullPortalSkin;
   public static volatile double nullPortalJamatopChance;
   public static volatile double nullPortalCommanderChance;
   public static volatile double nullPortalSpecialChance;
   public static volatile String nullPortalCommanderKit;
   public static volatile String nullPortalSpecialKit;
   public static volatile String nullPortalLeader;
   public static volatile String nullPortalSpokeKit;
   public static volatile boolean riptideAnywhere;
   public static volatile boolean useElytraMace;
   public static volatile boolean useElytraSpear;
   public static volatile boolean useSpearDash;
   public static volatile boolean useStunSlam;
   public static volatile boolean useWebDrain;
   public static volatile int webDrainChance;
   public static volatile int jumpResetChance;
   public static volatile int counterStunChance;
   public static RandomGearConfig randomGearConfig;
   public static RandomGearConfig randomChestLootConfig;
   public static volatile boolean shieldOnMaceDive;
   public static volatile boolean fastShieldCooldown;
   public static volatile boolean usePearlCatch;
   public static volatile boolean elytraGlide;
   public static volatile boolean movementFrozen;

   private BotSettings() {
   }

   public static DifficultyParams botDifficultyFor(String botName) {
      return botName == null ? null : (DifficultyParams)botDifficulties.get(botName);
   }

   public static float getAccuracy() {
      return (float)difficultyParams.accuracy;
   }

   public static boolean roll() {
      return Math.random() < (double)getAccuracy();
   }

   public static float getClutchAccuracy() {
      return (float)difficultyParams.clutchAccuracy;
   }

   public static boolean rollClutch() {
      return Math.random() < (double)getClutchAccuracy();
   }

   public static PlayStyle adaptiveResolvedFor(String botName) {
      return botName == null ? BotSettings.PlayStyle.DEFAULT : (PlayStyle)adaptiveResolved.getOrDefault(botName, BotSettings.PlayStyle.DEFAULT);
   }

   public static void setAdaptiveResolved(String botName, PlayStyle style) {
      if (botName != null && style != null && style != BotSettings.PlayStyle.ADAPTIVE) {
         PlayStyle prev = (PlayStyle)adaptiveResolved.put(botName, style);
         if (prev != style) {
            EffectiveSettings.invalidate();
         }

      }
   }

   public static PlayStyle rollPlayStyle(Random rng) {
      int total = 0;

      for(int w : playStyleChances.values()) {
         total += Math.max(0, w);
      }

      if (total <= 0) {
         return null;
      } else {
         int roll = rng.nextInt(total);

         for(PlayStyle st : BotSettings.PlayStyle.values()) {
            int w = Math.max(0, (Integer)playStyleChances.getOrDefault(st, 0));
            if (w != 0) {
               if (roll < w) {
                  return st;
               }

               roll -= w;
            }
         }

         return BotSettings.PlayStyle.DEFAULT;
      }
   }

   public static PlayStyle playStyleFor(String botName) {
      if (botName == null) {
         return BotSettings.PlayStyle.DEFAULT;
      } else {
         PlayStyle direct = (PlayStyle)playStyles.get(botName);
         if (direct != null) {
            return direct;
         } else {
            return playStylesNorm.isEmpty() ? BotSettings.PlayStyle.DEFAULT : (PlayStyle)playStylesNorm.getOrDefault(botName.toLowerCase(Locale.ROOT), BotSettings.PlayStyle.DEFAULT);
         }
      }
   }

   public static void setPlayStyle(String botName, PlayStyle style) {
      if (botName != null && !botName.isBlank()) {
         playStyles.keySet().removeIf((k) -> k.equalsIgnoreCase(botName));
         playStylesNorm.remove(botName.toLowerCase(Locale.ROOT));
         if (style != null && style != BotSettings.PlayStyle.DEFAULT) {
            playStyles.put(botName, style);
            playStylesNorm.put(botName.toLowerCase(Locale.ROOT), style);
         }

      }
   }

   public static void reindexPlayStyles() {
      playStylesNorm.clear();

      for(Map.Entry<String, PlayStyle> e : playStyles.entrySet()) {
         playStylesNorm.put(((String)e.getKey()).toLowerCase(Locale.ROOT), (PlayStyle)e.getValue());
      }

   }

   static {
      bunnyHopMode = BotSettings.BunnyHopMode.ON;
      autoTarget = false;
      targetPlayers = true;
      targetBots = false;
      targetMobs = false;
      difficulty = BotSettings.Difficulty.PERFECT;
      difficultyParams = DifficultyParams.forPreset(BotSettings.Difficulty.PERFECT);
      botDifficulties = new ConcurrentHashMap();
      ffaRandomDifficulties = false;
      cartDoctrine = BotSettings.CartDoctrine.RELENTLESS;
      useCarting = true;
      attackRange = (double)3.0F;
      statsEnabled = true;
      bridgeMode = BotSettings.BridgeMode.NINJA;
      gameLogs = BotSettings.GameLogs.BRIEF;
      cartMode = BotSettings.CartMode.SMART;
      ignoreCreative = true;
      openDoors = true;
      wanderWhenIdle = false;
      useEnderPearl = false;
      botDontLeave = false;
      pearlChasing = true;
      botLeaveOnDeath = true;
      chorusEscape = true;
      fireEscape = false;
      enderChestRegear = true;
      namePool = "";
      shulkerSteal = true;
      shulkerRegear = true;
      showTags = false;
      spreadOut = false;
      techniques = new TechniqueConfig();
      webEscape = true;
      waterBucketClutch = true;
      useBows = true;
      hitWeb = false;
      pickupLoot = true;
      buildUpMinHeight = (double)4.0F;
      botPing = 0;
      doBlockExplosion = true;
      speedNoJump = true;
      maceTotem = true;
      chaseSpread = true;
      placeBlocksMoving = false;
      botAdvancements = false;
      botSpawnMobs = true;
      lootPackRadius = (double)100.0F;
      healingMode = BotSettings.HealingMode.ADVANCED;
      offhandPreference = BotSettings.OffhandPreference.AUTO;
      offhandTotemHearts = (double)4.0F;
      strafeInCombo = true;
      spawnAreaDim = null;
      useOrbitalStrike = false;
      adaptiveResolved = new ConcurrentHashMap();
      playStyleChances = new ConcurrentHashMap(Map.of(BotSettings.PlayStyle.DEFAULT, 25, BotSettings.PlayStyle.SAFE, 15, BotSettings.PlayStyle.DEFENSIVE, 15, BotSettings.PlayStyle.BALANCED, 20, BotSettings.PlayStyle.AGGRESSIVE, 25, BotSettings.PlayStyle.ADAPTIVE, 0));
      playStyles = new ConcurrentHashMap();
      playStylesNorm = new ConcurrentHashMap();
      retreatHealthHearts = (double)4.0F;
      useScaffolding = false;
      kitPotionDoSplash = false;
      gotoMining = true;
      advancedSpawn = false;
      silentCommands = false;
      nullPortalJoinTeam = true;
      nameTagColour = "none";
      nullPortalTeam = "null";
      nullPortalBreakAfterSpawn = false;
      nullPortalSkin = true;
      nullPortalJamatopChance = 0.9;
      nullPortalCommanderChance = (double)4.0F;
      nullPortalSpecialChance = (double)15.0F;
      nullPortalCommanderKit = "";
      nullPortalSpecialKit = "";
      nullPortalLeader = "jamatop";
      nullPortalSpokeKit = "";
      riptideAnywhere = false;
      useElytraMace = true;
      useElytraSpear = true;
      useSpearDash = true;
      useStunSlam = true;
      useWebDrain = true;
      webDrainChance = 100;
      jumpResetChance = 50;
      counterStunChance = 30;
      randomGearConfig = new RandomGearConfig();
      randomChestLootConfig = new RandomGearConfig();
      shieldOnMaceDive = true;
      fastShieldCooldown = false;
      usePearlCatch = true;
      elytraGlide = true;
      movementFrozen = false;
   }

   public static enum BunnyHopMode {
      OFF,
      ON,
      SMART;

      // $FF: synthetic method
      private static BunnyHopMode[] $values() {
         return new BunnyHopMode[]{OFF, ON, SMART};
      }
   }

   public static enum Difficulty {
      EASY,
      MEDIUM,
      HARD,
      EXPERT,
      PERFECT;

      // $FF: synthetic method
      private static Difficulty[] $values() {
         return new Difficulty[]{EASY, MEDIUM, HARD, EXPERT, PERFECT};
      }
   }

   public static enum BridgeMode {
      NINJA,
      GOD,
      MOONWALK;

      // $FF: synthetic method
      private static BridgeMode[] $values() {
         return new BridgeMode[]{NINJA, GOD, MOONWALK};
      }
   }

   public static enum GameLogs {
      DETAILED,
      BRIEF,
      SIMPLE;

      // $FF: synthetic method
      private static GameLogs[] $values() {
         return new GameLogs[]{DETAILED, BRIEF, SIMPLE};
      }
   }

   public static enum CartMode {
      PRE_CART,
      PRE_RAIL,
      INSTA_CART,
      XBOW_CART,
      SMART;

      // $FF: synthetic method
      private static CartMode[] $values() {
         return new CartMode[]{PRE_CART, PRE_RAIL, INSTA_CART, XBOW_CART, SMART};
      }
   }

   public static enum CartDoctrine {
      GUIDE,
      RELENTLESS;

      // $FF: synthetic method
      private static CartDoctrine[] $values() {
         return new CartDoctrine[]{GUIDE, RELENTLESS};
      }
   }

   public static enum HealingMode {
      ADVANCED,
      OLD;

      // $FF: synthetic method
      private static HealingMode[] $values() {
         return new HealingMode[]{ADVANCED, OLD};
      }
   }

   public static enum OffhandPreference {
      AUTO,
      TOTEM,
      SHIELD;

      // $FF: synthetic method
      private static OffhandPreference[] $values() {
         return new OffhandPreference[]{AUTO, TOTEM, SHIELD};
      }
   }

   public static enum PlayStyle {
      DEFAULT,
      SAFE,
      AGGRESSIVE,
      ADAPTIVE,
      DEFENSIVE,
      BALANCED;

      // $FF: synthetic method
      private static PlayStyle[] $values() {
         return new PlayStyle[]{DEFAULT, SAFE, AGGRESSIVE, ADAPTIVE, DEFENSIVE, BALANCED};
      }
   }
}
