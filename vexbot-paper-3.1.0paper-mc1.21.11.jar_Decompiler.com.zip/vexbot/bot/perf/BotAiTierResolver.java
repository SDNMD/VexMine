package vexbot.bot.perf;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import vexbot.compat.McCompat;

public final class BotAiTierResolver {
   private static final double SLEEP_DIST = (double)48.0F;
   private static final double LIGHT_DIST = (double)40.0F;
   private static final double NEARBY_PLAYER = (double)90.0F;
   private static final double AIR_CHASE_DIST = (double)50.0F;
   private static final ArrayList<ServerPlayer> UNTAGGED = new ArrayList();
   private static MinecraftServer untaggedServer;
   private static int untaggedTick = -1;
   private static int untaggedSize = -1;
   private static ServerPlayer untaggedLast;
   private static boolean untaggedBuilt;

   private BotAiTierResolver() {
   }

   public static BotAiTier resolve(ServerPlayer bot, LivingEntity target, double dist, boolean macePvpActive, boolean specialPvpExecuting) {
      if (!macePvpActive && !specialPvpExecuting) {
         if (target == null) {
            return humanWithin(bot, (double)90.0F) ? BotAiTier.LIGHT : BotAiTier.SLEEP;
         } else if (isAirborneTarget(bot, target) && dist <= (double)50.0F) {
            return BotAiTier.FULL;
         } else if (dist > (double)48.0F) {
            return BotAiTier.SLEEP;
         } else {
            return dist > (double)40.0F ? BotAiTier.LIGHT : BotAiTier.FULL;
         }
      } else {
         return BotAiTier.FULL;
      }
   }

   private static boolean isAirborneTarget(ServerPlayer bot, LivingEntity target) {
      if (target.onGround()) {
         return false;
      } else if (target.isFallFlying()) {
         return true;
      } else if (target.isAutoSpinAttack()) {
         return true;
      } else {
         return target.getY() - bot.getY() > (double)4.0F;
      }
   }

   private static boolean humanWithin(ServerPlayer bot, double range) {
      MinecraftServer server = bot.level().getServer();
      if (server == null) {
         return false;
      } else {
         String self = bot.getScoreboardName();

         for(ServerPlayer p : untaggedPlayers(server)) {
            if (!McCompat.tags(p).contains("vexbot") && p.level() == bot.level() && p.isAlive() && !p.isSpectator() && !p.getScoreboardName().equals(self) && !((double)bot.distanceTo(p) > range)) {
               return true;
            }
         }

         return false;
      }
   }

   private static List<ServerPlayer> untaggedPlayers(MinecraftServer server) {
      List<ServerPlayer> players = server.getPlayerList().getPlayers();
      if (!server.isSameThread()) {
         return players;
      } else {
         int size = players.size();
         ServerPlayer last = size == 0 ? null : (ServerPlayer)players.get(size - 1);
         int tick = server.getTickCount();
         if (server == untaggedServer && tick == untaggedTick && size == untaggedSize && last == untaggedLast) {
            if (!untaggedBuilt) {
               for(ServerPlayer p : players) {
                  if (!McCompat.tags(p).contains("vexbot")) {
                     UNTAGGED.add(p);
                  }
               }

               untaggedBuilt = true;
            }

            return UNTAGGED;
         } else {
            untaggedServer = server;
            untaggedTick = tick;
            untaggedSize = size;
            untaggedLast = last;
            untaggedBuilt = false;
            UNTAGGED.clear();
            return players;
         }
      }
   }
}
