package vexbot.bot.perf;

public enum BotAiTier {
   SLEEP,
   LIGHT,
   FULL;

   // $FF: synthetic method
   private static BotAiTier[] $values() {
      return new BotAiTier[]{SLEEP, LIGHT, FULL};
   }
}
