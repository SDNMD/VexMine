package vexbot.bot.loadout;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.LinkedHashMap;
import java.util.Map;

public final class RandomGearConfig {
   public static final String[] KEYS = new String[]{"allowleather", "allowcopper", "allowiron", "allowdiamond", "allownetherite", "allowcrystals", "allowanchors", "allowcarts", "allowmace", "allowtrident", "allowelytra", "allowbow", "allowcrossbow", "allowarrows", "allowwebs", "allowpearls", "allowtotems", "allowgapples", "allowegaps", "allowshields", "allowtools", "allowblocks", "allowwindcharges", "allowsnowballs", "allowbuckets", "allowenchants"};
   private final Map<String, Boolean> categories = new LinkedHashMap();
   private final Map<String, Boolean> foods = new LinkedHashMap();

   public boolean allow(String key) {
      return (Boolean)this.categories.getOrDefault(key, Boolean.TRUE);
   }

   public void setAllow(String key, boolean v) {
      this.categories.put(key, v);
   }

   public boolean foodAllowed(String name) {
      return (Boolean)this.foods.getOrDefault(name, Boolean.TRUE);
   }

   public void setFood(String name, boolean v) {
      this.foods.put(name, v);
   }

   public static boolean isValidKey(String key) {
      for(String k : KEYS) {
         if (k.equals(key)) {
            return true;
         }
      }

      return false;
   }

   public Map<String, Boolean> categories() {
      return this.categories;
   }

   public Map<String, Boolean> foods() {
      return this.foods;
   }

   public RandomGearConfig copy() {
      RandomGearConfig c = new RandomGearConfig();
      c.categories.putAll(this.categories);
      c.foods.putAll(this.foods);
      return c;
   }

   public void writeTo(JsonObject o) {
      JsonObject cats = new JsonObject();

      for(Map.Entry<String, Boolean> e : this.categories.entrySet()) {
         cats.addProperty((String)e.getKey(), (Boolean)e.getValue());
      }

      o.add("categories", cats);
      JsonObject fds = new JsonObject();

      for(Map.Entry<String, Boolean> e : this.foods.entrySet()) {
         fds.addProperty((String)e.getKey(), (Boolean)e.getValue());
      }

      o.add("foods", fds);
   }

   public void readFrom(JsonObject o) {
      if (o != null) {
         this.categories.clear();
         this.foods.clear();
         if (o.has("categories") && o.get("categories").isJsonObject()) {
            for(Map.Entry<String, JsonElement> e : o.getAsJsonObject("categories").entrySet()) {
               this.categories.put((String)e.getKey(), ((JsonElement)e.getValue()).getAsBoolean());
            }
         }

         if (o.has("foods") && o.get("foods").isJsonObject()) {
            for(Map.Entry<String, JsonElement> e : o.getAsJsonObject("foods").entrySet()) {
               this.foods.put((String)e.getKey(), ((JsonElement)e.getValue()).getAsBoolean());
            }
         }

      }
   }
}
