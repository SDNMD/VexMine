package vexbot.bot.loadout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ItemLike;
import vexbot.BotSettings;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;

public final class RandomGearGenerator {
   private static final Random RNG = new Random();
   private static final int[] TIER_W = new int[]{12, 14, 46, 22, 6};
   private static final String[] TIER_KEY = new String[]{"allowleather", "allowcopper", "allowiron", "allowdiamond", "allownetherite"};
   private static final Item[][] ARMOR_T;
   private static final Item[] SWORD_T;
   private static final Item[] AXE_T;
   private static final Item[] PICK_T;
   private static final Item[] SHOVEL_T;
   private static final int[] OFFHAND_W;
   private static final Item[] FOODS;
   private static final String[] FOOD_NAMES;
   private static final int[] FOODS_W;
   private static final Item[] STEWS;
   private static final String[] STEW_NAMES;
   private static final int P_ARMOR_SLOT = 80;
   private static final int P_SWORD = 72;
   private static final int P_AXE = 18;
   private static final int P_PICK = 18;
   private static final int P_SHOVEL = 14;
   private static final int P_MACE = 4;
   private static final int P_TRIDENT = 5;
   private static final int P_BOW = 12;
   private static final int P_XBOW = 10;
   private static final int P_FOOD = 88;
   private static final int P_GAPPLE = 24;
   private static final int P_EGAP = 4;
   private static final int P_PEARLS = 20;
   private static final int P_WEBS = 14;
   private static final int P_WATER = 12;
   private static final int P_BUCKET = 10;
   private static final int P_CRYSTAL = 7;
   private static final int P_ANCHOR = 4;
   private static final int P_WIND = 8;
   private static final int P_ELYTRA = 4;
   private static final int P_CART = 5;
   private static final int P_BLOCKS = 22;
   private static final int P_TOTEM2 = 4;
   private static final int P_SNOW = 6;

   private RandomGearGenerator() {
   }

   public static String[] foodNames() {
      String[] all = new String[FOOD_NAMES.length + STEW_NAMES.length];
      System.arraycopy(FOOD_NAMES, 0, all, 0, FOOD_NAMES.length);
      System.arraycopy(STEW_NAMES, 0, all, FOOD_NAMES.length, STEW_NAMES.length);
      return all;
   }

   public static void apply(ServerPlayer who) {
      apply(who, RNG);
   }

   public static void apply(ServerPlayer who, Random rng) {
      RandomGearConfig cfg = configFor(who);
      Inventory inv = who.getInventory();
      inv.clearContent();
      HolderLookup.RegistryLookup<Enchantment> ench = who.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
      boolean doEnch = cfg.allow("allowenchants");
      boolean[] tierOk = new boolean[5];
      int[] tw = (int[])TIER_W.clone();
      int tierSum = 0;

      for(int i = 0; i < 5; ++i) {
         tierOk[i] = cfg.allow(TIER_KEY[i]);
         if (!tierOk[i]) {
            tw[i] = 0;
         } else {
            tierSum += tw[i];
         }
      }

      boolean anyTier = tierSum > 0;
      int tier = anyTier ? weighted(rng, tw) : 0;
      if (anyTier) {
         EquipmentSlot[] slots = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

         for(int s = 0; s < 4; ++s) {
            if (chance(rng, 80)) {
               int at = driftDown(tier, rng, 18, tierOk);
               ItemStack piece = new ItemStack(ARMOR_T[at][s]);
               if (doEnch) {
                  enchantArmor(ench, piece, rng, tier, s == 3);
               }

               who.setItemSlot(slots[s], piece);
            }
         }
      }

      List<ItemStack> hotbar = new ArrayList();
      List<ItemStack> storage = new ArrayList();
      if (anyTier) {
         if (chance(rng, 72)) {
            hotbar.add(weapon(ench, SWORD_T[driftDown(tier, rng, 20, tierOk)], rng, tier, doEnch));
         }

         if (chance(rng, 18)) {
            hotbar.add(weapon(ench, AXE_T[driftDown(tier, rng, 20, tierOk)], rng, tier, doEnch));
         }

         if (cfg.allow("allowtools") && chance(rng, 18)) {
            hotbar.add(tool(ench, PICK_T[driftDown(tier, rng, 25, tierOk)], rng, tier, doEnch));
         }

         if (cfg.allow("allowtools") && chance(rng, 14)) {
            hotbar.add(tool(ench, SHOVEL_T[driftDown(tier, rng, 25, tierOk)], rng, tier, doEnch));
         }
      }

      boolean ranged = false;
      if (cfg.allow("allowmace") && chance(rng, 4)) {
         hotbar.add(new ItemStack(Items.MACE));
      }

      if (cfg.allow("allowtrident") && chance(rng, 5)) {
         hotbar.add(new ItemStack(Items.TRIDENT));
      }

      if (cfg.allow("allowbow") && chance(rng, 12)) {
         hotbar.add(bow(ench, Items.BOW, rng, tier, doEnch));
         ranged = true;
      }

      if (cfg.allow("allowcrossbow") && chance(rng, 10)) {
         hotbar.add(crossbow(ench, Items.CROSSBOW, rng, tier, doEnch));
         ranged = true;
      }

      if (ranged && cfg.allow("allowarrows")) {
         hotbar.add(new ItemStack(Items.ARROW, 8 + rng.nextInt(24)));
      }

      ItemStack offhand = ItemStack.EMPTY;
      switch (weighted(rng, OFFHAND_W)) {
         case 1:
            if (cfg.allow("allowshields")) {
               offhand = new ItemStack(Items.SHIELD);
            }
            break;
         case 2:
            if (cfg.allow("allowtotems")) {
               offhand = new ItemStack(Items.TOTEM_OF_UNDYING);
            }
      }

      if (chance(rng, 88)) {
         ItemStack f = food(rng, cfg);
         if (!f.isEmpty()) {
            hotbar.add(f);
         }
      }

      if (cfg.allow("allowgapples") && chance(rng, 24)) {
         hotbar.add(new ItemStack(Items.GOLDEN_APPLE, 1 + rng.nextInt(4)));
      }

      if (cfg.allow("allowegaps") && chance(rng, 4)) {
         hotbar.add(new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 1 + rng.nextInt(2)));
      }

      if (cfg.allow("allowpearls") && chance(rng, 20)) {
         hotbar.add(new ItemStack(Items.ENDER_PEARL, 1 + rng.nextInt(8)));
      }

      if (cfg.allow("allowwebs") && chance(rng, 14)) {
         hotbar.add(new ItemStack(Items.COBWEB, 4 + rng.nextInt(5)));
      }

      if (cfg.allow("allowbuckets") && chance(rng, 12)) {
         hotbar.add(new ItemStack(Items.WATER_BUCKET));
      }

      if (cfg.allow("allowbuckets") && chance(rng, 10)) {
         hotbar.add(new ItemStack(Items.BUCKET));
      }

      if (cfg.allow("allowcrystals") && chance(rng, 7)) {
         hotbar.add(new ItemStack(Items.END_CRYSTAL, 8 + rng.nextInt(16)));
         storage.add(new ItemStack(Items.OBSIDIAN, 16 + rng.nextInt(16)));
      }

      if (cfg.allow("allowanchors") && chance(rng, 4)) {
         hotbar.add(new ItemStack(Items.RESPAWN_ANCHOR, 2 + rng.nextInt(5)));
         storage.add(new ItemStack(Items.GLOWSTONE, 16 + rng.nextInt(16)));
      }

      if (cfg.allow("allowwindcharges") && chance(rng, 8)) {
         hotbar.add(new ItemStack(Items.WIND_CHARGE, 16 + rng.nextInt(32)));
      }

      if (cfg.allow("allowelytra") && chance(rng, 4)) {
         storage.add(new ItemStack(Items.ELYTRA));
         hotbar.add(new ItemStack(Items.FIREWORK_ROCKET, 16 + rng.nextInt(32)));
      }

      if (cfg.allow("allowcarts") && chance(rng, 5)) {
         hotbar.add(new ItemStack(Items.RAIL, 16 + rng.nextInt(32)));
         addMany(storage, Items.TNT_MINECART, 3 + rng.nextInt(4));
         hotbar.add(new ItemStack(Items.FLINT_AND_STEEL));
      }

      if (cfg.allow("allowblocks") && chance(rng, 22)) {
         storage.add(new ItemStack(Items.COBBLESTONE, 16 + rng.nextInt(48)));
      }

      if (cfg.allow("allowtotems") && chance(rng, 4)) {
         storage.add(new ItemStack(Items.TOTEM_OF_UNDYING));
      }

      if (cfg.allow("allowsnowballs") && chance(rng, 6)) {
         hotbar.add(new ItemStack(Items.SNOWBALL, 8 + rng.nextInt(8)));
      }

      int hi = 0;

      for(ItemStack s : hotbar) {
         if (s != null && !s.isEmpty()) {
            if (hi < 9) {
               inv.setItem(hi++, s);
            } else {
               storage.add(s);
            }
         }
      }

      int si = 9;

      for(ItemStack s : storage) {
         if (s != null && !s.isEmpty()) {
            if (si > 35) {
               break;
            }

            inv.setItem(si++, s);
         }
      }

      if (!offhand.isEmpty()) {
         who.setItemSlot(EquipmentSlot.OFFHAND, offhand);
      }

   }

   public static List<ItemStack> rollFfaChestContents(HolderLookup.Provider regs, RandomGearConfig cfg, Random rng) {
      HolderLookup.RegistryLookup<Enchantment> ench = regs.lookupOrThrow(Registries.ENCHANTMENT);
      boolean doEnch = cfg.allow("allowenchants");
      boolean[] tierOk = new boolean[5];
      int[] tw = (int[])TIER_W.clone();
      int tierSum = 0;

      for(int i = 0; i < 5; ++i) {
         tierOk[i] = cfg.allow(TIER_KEY[i]);
         if (!tierOk[i]) {
            tw[i] = 0;
         } else {
            tierSum += tw[i];
         }
      }

      boolean anyTier = tierSum > 0;
      int tier = anyTier ? weighted(rng, tw) : 0;
      List<ItemStack> out = new ArrayList();
      if (anyTier) {
         int pieces = chance(rng, 70) ? (chance(rng, 25) ? 2 : 1) : 0;
         EquipmentSlot[] var10000 = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
         List<Integer> order = new ArrayList(List.of(0, 1, 2, 3));
         Collections.shuffle(order, rng);

         for(int k = 0; k < pieces; ++k) {
            int s = (Integer)order.get(k);
            int at = driftDown(tier, rng, 18, tierOk);
            ItemStack piece = new ItemStack(ARMOR_T[at][s]);
            if (doEnch) {
               enchantArmor(ench, piece, rng, tier, s == 3);
            }

            out.add(piece);
         }

         if (chance(rng, 65)) {
            Item[] pool = chance(rng, 70) ? SWORD_T : AXE_T;
            out.add(weapon(ench, pool[driftDown(tier, rng, 20, tierOk)], rng, tier, doEnch));
         }
      }

      if (cfg.allow("allowgapples") && chance(rng, 60)) {
         out.add(new ItemStack(Items.GOLDEN_APPLE, 2 + rng.nextInt(3)));
      }

      if (cfg.allow("allowegaps") && chance(rng, 8)) {
         out.add(new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 1));
      }

      if (chance(rng, 35)) {
         boolean preferBow = chance(rng, 55);
         boolean gotRanged = true;
         if (preferBow && cfg.allow("allowbow")) {
            out.add(bow(ench, Items.BOW, rng, tier, doEnch));
         } else if (cfg.allow("allowcrossbow")) {
            out.add(crossbow(ench, Items.CROSSBOW, rng, tier, doEnch));
         } else if (cfg.allow("allowbow")) {
            out.add(bow(ench, Items.BOW, rng, tier, doEnch));
         } else {
            gotRanged = false;
         }

         if (gotRanged && cfg.allow("allowarrows")) {
            out.add(new ItemStack(Items.ARROW, 8 + rng.nextInt(16)));
         }
      }

      if (cfg.allow("allowblocks") && chance(rng, 55)) {
         out.add(new ItemStack(Items.COBBLESTONE, 16 + rng.nextInt(48)));
      }

      if (chance(rng, 70)) {
         ItemStack f = food(rng, cfg);
         if (!f.isEmpty()) {
            out.add(f);
         }
      }

      if (cfg.foodAllowed("cooked_beef") && chance(rng, 40)) {
         out.add(new ItemStack(Items.COOKED_BEEF, 3 + rng.nextInt(6)));
      }

      if (cfg.allow("allowpearls") && chance(rng, 25)) {
         out.add(new ItemStack(Items.ENDER_PEARL, 1 + rng.nextInt(4)));
      }

      if (cfg.allow("allowwebs") && chance(rng, 18)) {
         out.add(new ItemStack(Items.COBWEB, 3 + rng.nextInt(4)));
      }

      if (cfg.allow("allowtotems") && chance(rng, 12)) {
         out.add(new ItemStack(Items.TOTEM_OF_UNDYING));
      }

      if (cfg.allow("allowbuckets") && chance(rng, 15)) {
         out.add(new ItemStack(Items.WATER_BUCKET));
      }

      if (cfg.allow("allowwindcharges") && chance(rng, 12)) {
         out.add(new ItemStack(Items.WIND_CHARGE, 4 + rng.nextInt(8)));
      }

      return out;
   }

   public static ItemStack makeLootChestItem() {
      ItemStack chest = new ItemStack(Items.CHEST);
      chest.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
      chest.set(DataComponents.CUSTOM_NAME, VexText.literal("§dRandom Loot Chest"));
      CustomData.update(DataComponents.CUSTOM_DATA, chest, (tag) -> tag.putBoolean("VexBotLootChest", true));
      return chest;
   }

   public static void populateFfaChest(Container container, HolderLookup.Provider regs, RandomGearConfig cfg, Random rng) {
      List<ItemStack> loot = rollFfaChestContents(regs, cfg, rng);
      int size = container.getContainerSize();
      List<Integer> slots = new ArrayList();

      for(int i = 0; i < size; ++i) {
         slots.add(i);
      }

      Collections.shuffle(slots, rng);
      int si = 0;

      for(ItemStack st : loot) {
         if (st != null && !st.isEmpty() && si < slots.size()) {
            container.setItem((Integer)slots.get(si++), st);
         }
      }

      container.setChanged();
   }

   private static RandomGearConfig configFor(ServerPlayer who) {
      String name = who.getName().getString();
      TeamManager.BotTeam t = TeamManager.getTeamForBot(name);
      if (t == null) {
         t = TeamManager.getTeamForMember(name);
      }

      return t != null ? t.randomGearConfig : BotSettings.randomGearConfig;
   }

   private static int rollQuality(Random rng, int tier) {
      int good = 14 + tier * 4;
      int r = rng.nextInt(100);
      if (r < good) {
         return 2;
      } else {
         return r < good + 40 ? 1 : 0;
      }
   }

   private static ItemStack weapon(HolderLookup.RegistryLookup<Enchantment> ench, Item item, Random rng, int tier, boolean doEnch) {
      ItemStack s = new ItemStack(item);
      int q = doEnch ? rollQuality(rng, tier) : 0;
      if (q > 0) {
         boolean good = q == 2;
         ench(ench, s, Enchantments.SHARPNESS, good ? 3 + rng.nextInt(3) : 1 + rng.nextInt(2));
         if (chance(rng, good ? 75 : 40)) {
            ench(ench, s, Enchantments.UNBREAKING, good ? 3 : 1 + rng.nextInt(2));
         }

         if (good && chance(rng, 45)) {
            ench(ench, s, Enchantments.FIRE_ASPECT, 1 + rng.nextInt(2));
         }

         if (chance(rng, 25)) {
            ench(ench, s, Enchantments.KNOCKBACK, good ? 2 : 1);
         }
      }

      return s;
   }

   private static ItemStack tool(HolderLookup.RegistryLookup<Enchantment> ench, Item item, Random rng, int tier, boolean doEnch) {
      ItemStack s = new ItemStack(item);
      int q = doEnch ? rollQuality(rng, tier) : 0;
      if (q > 0) {
         boolean good = q == 2;
         ench(ench, s, Enchantments.EFFICIENCY, good ? 4 + rng.nextInt(2) : 1 + rng.nextInt(3));
         if (chance(rng, good ? 70 : 35)) {
            ench(ench, s, Enchantments.UNBREAKING, good ? 3 : 1 + rng.nextInt(2));
         }
      }

      return s;
   }

   private static ItemStack bow(HolderLookup.RegistryLookup<Enchantment> ench, Item item, Random rng, int tier, boolean doEnch) {
      ItemStack s = new ItemStack(item);
      int q = doEnch ? rollQuality(rng, tier) : 0;
      if (q > 0) {
         boolean good = q == 2;
         ench(ench, s, Enchantments.POWER, good ? 3 + rng.nextInt(3) : 1 + rng.nextInt(2));
         if (good && chance(rng, 30)) {
            ench(ench, s, Enchantments.FLAME, 1);
         }

         if (chance(rng, 20)) {
            ench(ench, s, Enchantments.PUNCH, good ? 2 : 1);
         }

         if (chance(rng, good ? 60 : 30)) {
            ench(ench, s, Enchantments.UNBREAKING, good ? 3 : 1 + rng.nextInt(2));
         }
      }

      return s;
   }

   private static ItemStack crossbow(HolderLookup.RegistryLookup<Enchantment> ench, Item item, Random rng, int tier, boolean doEnch) {
      ItemStack s = new ItemStack(item);
      int q = doEnch ? rollQuality(rng, tier) : 0;
      if (q > 0) {
         boolean good = q == 2;
         ench(ench, s, Enchantments.QUICK_CHARGE, good ? 2 + rng.nextInt(2) : 1);
         if (chance(rng, 50)) {
            ench(ench, s, Enchantments.MULTISHOT, 1);
         } else if (chance(rng, good ? 60 : 35)) {
            ench(ench, s, Enchantments.PIERCING, good ? 2 + rng.nextInt(3) : 1);
         }

         if (chance(rng, good ? 60 : 30)) {
            ench(ench, s, Enchantments.UNBREAKING, good ? 3 : 1 + rng.nextInt(2));
         }
      }

      return s;
   }

   private static void enchantArmor(HolderLookup.RegistryLookup<Enchantment> ench, ItemStack s, Random rng, int tier, boolean boots) {
      int q = rollQuality(rng, tier);
      if (q != 0) {
         boolean good = q == 2;
         ench(ench, s, Enchantments.PROTECTION, good ? 3 + rng.nextInt(2) : 1 + rng.nextInt(2));
         if (chance(rng, good ? 70 : 35)) {
            ench(ench, s, Enchantments.UNBREAKING, good ? 3 : 1 + rng.nextInt(2));
         }

         if (boots && chance(rng, 50)) {
            ench(ench, s, Enchantments.FEATHER_FALLING, good ? 3 + rng.nextInt(2) : 1 + rng.nextInt(2));
         }

      }
   }

   private static void ench(HolderLookup.RegistryLookup<Enchantment> lookup, ItemStack stack, ResourceKey<Enchantment> key, int level) {
      Holder<Enchantment> h = lookup.getOrThrow(key);
      if (((Enchantment)h.value()).canEnchant(stack)) {
         stack.enchant(h, level);
      }
   }

   private static int driftDown(int tier, Random rng, int downPct, boolean[] tierOk) {
      return tier > 0 && tierOk[tier - 1] && chance(rng, downPct) ? tier - 1 : tier;
   }

   private static boolean chance(Random rng, int percent) {
      return rng.nextInt(100) < percent;
   }

   private static void addMany(List<ItemStack> list, Item item, int n) {
      for(int k = 0; k < n; ++k) {
         list.add(new ItemStack(item));
      }

   }

   private static ItemStack food(Random rng, RandomGearConfig cfg) {
      if (chance(rng, 8)) {
         List<Item> stews = new ArrayList();

         for(int i = 0; i < STEWS.length; ++i) {
            if (cfg.foodAllowed(STEW_NAMES[i])) {
               stews.add(STEWS[i]);
            }
         }

         if (!stews.isEmpty()) {
            return new ItemStack((ItemLike)stews.get(rng.nextInt(stews.size())));
         }
      }

      int sum = 0;

      for(int i = 0; i < FOODS.length; ++i) {
         if (cfg.foodAllowed(FOOD_NAMES[i])) {
            sum += FOODS_W[i];
         }
      }

      if (sum <= 0) {
         return ItemStack.EMPTY;
      } else {
         int r = rng.nextInt(sum);

         for(int i = 0; i < FOODS.length; ++i) {
            if (cfg.foodAllowed(FOOD_NAMES[i])) {
               r -= FOODS_W[i];
               if (r < 0) {
                  return new ItemStack(FOODS[i], 3 + rng.nextInt(13));
               }
            }
         }

         return ItemStack.EMPTY;
      }
   }

   private static int weighted(Random rng, int[] weights) {
      int sum = 0;

      for(int w : weights) {
         sum += w;
      }

      if (sum <= 0) {
         return 0;
      } else {
         int r = rng.nextInt(sum);

         for(int i = 0; i < weights.length; ++i) {
            r -= weights[i];
            if (r < 0) {
               return i;
            }
         }

         return weights.length - 1;
      }
   }

   static {
      ARMOR_T = new Item[][]{{Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS}, {Items.COPPER_HELMET, Items.COPPER_CHESTPLATE, Items.COPPER_LEGGINGS, Items.COPPER_BOOTS}, {Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS}, {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS}, {Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS}};
      SWORD_T = new Item[]{Items.WOODEN_SWORD, Items.COPPER_SWORD, Items.IRON_SWORD, Items.DIAMOND_SWORD, Items.NETHERITE_SWORD};
      AXE_T = new Item[]{Items.WOODEN_AXE, Items.COPPER_AXE, Items.IRON_AXE, Items.DIAMOND_AXE, Items.NETHERITE_AXE};
      PICK_T = new Item[]{Items.WOODEN_PICKAXE, Items.COPPER_PICKAXE, Items.IRON_PICKAXE, Items.DIAMOND_PICKAXE, Items.NETHERITE_PICKAXE};
      SHOVEL_T = new Item[]{Items.WOODEN_SHOVEL, Items.COPPER_SHOVEL, Items.IRON_SHOVEL, Items.DIAMOND_SHOVEL, Items.NETHERITE_SHOVEL};
      OFFHAND_W = new int[]{55, 33, 12};
      FOODS = new Item[]{Items.COOKED_BEEF, Items.BREAD, Items.COOKED_PORKCHOP, Items.COOKED_CHICKEN, Items.COOKED_MUTTON, Items.COOKED_COD, Items.COOKED_SALMON, Items.COOKED_RABBIT, Items.BAKED_POTATO, Items.CARROT, Items.APPLE, Items.MELON_SLICE, Items.COOKIE, Items.PUMPKIN_PIE, Items.DRIED_KELP, Items.BEETROOT, Items.SWEET_BERRIES, Items.GLOW_BERRIES, Items.GOLDEN_CARROT, Items.CHORUS_FRUIT};
      FOOD_NAMES = new String[]{"cooked_beef", "bread", "cooked_porkchop", "cooked_chicken", "cooked_mutton", "cooked_cod", "cooked_salmon", "cooked_rabbit", "baked_potato", "carrot", "apple", "melon_slice", "cookie", "pumpkin_pie", "dried_kelp", "beetroot", "sweet_berries", "glow_berries", "golden_carrot", "chorus_fruit"};
      FOODS_W = new int[]{24, 20, 14, 14, 8, 8, 8, 5, 10, 6, 6, 6, 5, 5, 6, 4, 5, 3, 6, 2};
      STEWS = new Item[]{Items.MUSHROOM_STEW, Items.RABBIT_STEW, Items.BEETROOT_SOUP, Items.SUSPICIOUS_STEW};
      STEW_NAMES = new String[]{"mushroom_stew", "rabbit_stew", "beetroot_soup", "suspicious_stew"};
   }
}
