package vexbot.bot.loadout;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import vexbot.BotSettings;

public final class LootChestOps {
   public static final int MAX_RADIUS = 128;

   private LootChestOps() {
   }

   public static int replaceNearby(ServerLevel level, BlockPos centre, int radius) {
      int r = Math.max(1, Math.min(128, radius));
      Random rng = new Random();
      List<BlockPos> found = new ArrayList();
      int minCx = SectionPos.blockToSectionCoord(centre.getX() - r);
      int maxCx = SectionPos.blockToSectionCoord(centre.getX() + r);
      int minCz = SectionPos.blockToSectionCoord(centre.getZ() - r);
      int maxCz = SectionPos.blockToSectionCoord(centre.getZ() + r);

      for(int cx = minCx; cx <= maxCx; ++cx) {
         for(int cz = minCz; cz <= maxCz; ++cz) {
            LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
            if (chunk != null) {
               for(BlockEntity be : chunk.getBlockEntities().values()) {
                  BlockPos p = be.getBlockPos();
                  if (Math.abs(p.getX() - centre.getX()) <= r && Math.abs(p.getY() - centre.getY()) <= r && Math.abs(p.getZ() - centre.getZ()) <= r) {
                     BlockState st = be.getBlockState();
                     if (st.is(Blocks.CHEST) || st.is(Blocks.TRAPPED_CHEST)) {
                        found.add(p.immutable());
                     }
                  }
               }
            }
         }
      }

      int done = 0;

      for(BlockPos p : found) {
         BlockEntity var21 = level.getBlockEntity(p);
         if (var21 instanceof Container c) {
            c.clearContent();
            RandomGearGenerator.populateFfaChest(c, level.registryAccess(), BotSettings.randomChestLootConfig, rng);
            c.setChanged();
            ++done;
         }
      }

      return done;
   }
}
