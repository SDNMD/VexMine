package vexbot.bot;

import com.mojang.authlib.GameProfile;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Action;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.NameAndId;
import net.minecraft.server.players.UserBanListEntry;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;
import vexbot.SettingsPersistence;
import vexbot.VexBot;
import vexbot.bot.ai.FollowFormation;
import vexbot.bot.ai.MaceDiveForecast;
import vexbot.bot.ai.StunSlamDummy;
import vexbot.bot.ai.SwordPvpController;
import vexbot.bot.loadout.RandomGearGenerator;
import vexbot.command.ControlCli;
import vexbot.compat.McCompat;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.kit.KitManager;
import vexbot.nick.NickManager;
import vexbot.platform.Internals;
import vexbot.stats.Stats;
import vexbot.team.TeamFormationOrders;
import vexbot.team.TeamManager;
import vexbot.team.TeamTargetBalancer;
import vexbot.util.BotCommands;
import vexbot.util.BotMath;
import vexbot.util.VexLog;

public final class BotManager {
   private static final Set<String> trackedBots = ConcurrentHashMap.newKeySet();
   private static final Map<String, SwordPvpController> activeBots = new ConcurrentHashMap();
   private static final Map<String, Integer> missingTicks = new ConcurrentHashMap();
   private static final Map<String, String> followTargets = new ConcurrentHashMap();
   private static final Map<String, FollowFormation.Type> followFormations = new ConcurrentHashMap();
   private static final Map<String, Integer> followRowWidth = new ConcurrentHashMap();
   private static final Set<String> followElytra = ConcurrentHashMap.newKeySet();
   private static final Map<String, String> attackTargets = new ConcurrentHashMap();
   private static final Map<String, LookOrder> lookOrders = new ConcurrentHashMap();
   private static final Set<String> ffaLootBots = ConcurrentHashMap.newKeySet();
   private static final float LOOK_AT_MAX_ROT_PER_TICK = 14.0F;
   private static final Map<String, Integer> spawnWaitTicks = new ConcurrentHashMap();
   private static final int SPAWN_TIMEOUT_TICKS = 600;
   private static int tickCounter = 0;
   private static final ArrayDeque<Runnable> spawnQueue = new ArrayDeque();
   private static final Map<String, Object> queuedSpawns = new ConcurrentHashMap();
   private static final Map<String, Integer> cancelledSpawns = new ConcurrentHashMap();
   private static final int SPAWNS_PER_TICK = 4;
   private static final int MISSING_GRACE_TICKS = 100;
   private static final int AI_ATTACH_DELAY = 10;
   private static final Map<String, Integer> pendingAttach = new ConcurrentHashMap();
   private static final Map<String, String> pendingRevenge = new ConcurrentHashMap();
   private static final Map<String, ItemStack[]> pendingKit = new ConcurrentHashMap();
   private static final Map<String, ItemStack[]> pendingEnder = new ConcurrentHashMap();
   private static final Set<String> pendingRandomGear = ConcurrentHashMap.newKeySet();
   private static final Set<String> practiceBots = ConcurrentHashMap.newKeySet();
   public static final int MAX_BOT_NAME_LENGTH = 16;
   private static final Pattern VALID_BOT_NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");
   private static final AtomicInteger trackedVersion = new AtomicInteger();
   private static volatile TrackedIndex trackedIndex = new TrackedIndex(-1, Map.of(), false);
   private static final Map<String, ServerPlayer> RESOLVE_TAGGED = new HashMap();
   private static final Map<String, ServerPlayer> RESOLVE_UNTAGGED = new HashMap();
   private static int resolveIndexTick = -1;
   private static int resolveIndexPlayers = -1;
   private static int resolveIndexBuild = 0;
   private static String resolveKeyFor;
   private static String resolveKey;
   private static boolean botAdvancementsApplied = true;
   private static int followVersion = 0;
   private static int followMemoVersion = -1;
   private static final int FOLLOW_MEMO_MAX = 4096;
   private static final Object NO_FOLLOW = new Object();
   private static final Map<String, Object> followTargetMemo = new HashMap();
   private static final Map<String, FollowFormation.Type> followFormationMemo = new HashMap();
   private static final Map<String, Integer> followRowWidthMemo = new HashMap();
   private static final Map<String, Boolean> followElytraMemo = new HashMap();
   private static final Map<String, FollowGroup> followGroupMemo = new HashMap();
   private static final Map<String, FollowGroup> followGroupFlyMemo = new HashMap();
   private static final Map<String, ServerPlayer> BY_NAME = new HashMap();
   private static int byNameTick = -1;
   private static int byNameSize = -1;
   private static int byNameNicks = -1;
   private static ServerPlayer byNameLast;
   private static boolean byNameBuilt;
   private static boolean byNameUsable;
   private static boolean inServerTick;

   public static void setPendingRandomGear(String name) {
      if (name != null) {
         pendingRandomGear.add(name);
      }

   }

   public static void setPendingKit(String name, ItemStack[] stacks) {
      setPendingKit(name, stacks, (ItemStack[])null);
   }

   public static void setPendingKit(String name, ItemStack[] stacks, ItemStack[] ender) {
      if (name != null && stacks != null) {
         pendingKit.put(name, stacks);
         if (ender != null) {
            pendingEnder.put(name, ender);
         }

      }
   }

   private BotManager() {
   }

   public static void markPracticeBot(String name) {
      practiceBots.add(name.toLowerCase(Locale.ROOT));
   }

   public static void unmarkPracticeBot(String name) {
      if (name != null) {
         practiceBots.remove(name.toLowerCase(Locale.ROOT));
      }

   }

   public static boolean forceTarget(String botName, String targetName) {
      for(Map.Entry<String, SwordPvpController> e : activeBots.entrySet()) {
         if (((String)e.getKey()).equalsIgnoreCase(botName)) {
            ((SwordPvpController)e.getValue()).notifyHurtBy(targetName);
            return true;
         }
      }

      return false;
   }

   public static boolean isPracticeBot(String name) {
      return name != null && !practiceBots.isEmpty() && practiceBots.contains(name.toLowerCase(Locale.ROOT));
   }

   public static boolean spawn(MinecraftServer server, String name, double x, double y, double z, float yaw, float pitch, String dimensionId) {
      if (rejectBadName(name)) {
         return false;
      } else if (isBanned(server, name)) {
         VexBot.LOGGER.info("[VexBot] Not spawning '{}': that name is banned on this server.", name);
         return false;
      } else {
         return !tryReserveTrackedName(name) ? false : spawnInternal(server, name, x, y, z, yaw, pitch, dimensionId);
      }
   }

   public static boolean queueSpawn(MinecraftServer server, String name, double x, double y, double z, float yaw, float pitch, String dimensionId) {
      if (rejectBadName(name)) {
         return false;
      } else if (peekSpawnStaticBlockReason(server, name) != null) {
         return false;
      } else if (!tryReserveTrackedName(name)) {
         return false;
      } else {
         Object token = new Object();
         queuedSpawns.put(name, token);
         spawnQueue.add((Runnable)() -> {
            if (queuedSpawns.remove(name, token)) {
               spawnInternal(server, name, x, y, z, yaw, pitch, dimensionId);
            }
         });
         return true;
      }
   }

   private static boolean rejectBadName(String name) {
      String reason = invalidBotNameReason(name);
      if (reason == null && !name.equals(name.strip())) {
         reason = "'" + name + "' has leading or trailing whitespace.";
      }

      if (reason == null) {
         return false;
      } else {
         VexBot.LOGGER.warn("[VexBot] Refusing to spawn a bot: {}", reason);
         return true;
      }
   }

   public static String invalidBotNameReason(String name) {
      if (name != null && !name.isBlank()) {
         String n = name.strip();
         if (n.length() > 16) {
            return "'" + n + "' is " + n.length() + " characters — Minecraft names cap at 16.";
         } else {
            return !VALID_BOT_NAME.matcher(n).matches() ? "'" + n + "' contains characters Minecraft names cannot use — letters, numbers and underscores only." : null;
         }
      } else {
         return "Bot name cannot be empty.";
      }
   }

   private static boolean tryReserveTrackedName(String name) {
      if (name != null && trackedBots.contains(name)) {
         return false;
      } else {
         for(String existing : trackedBots) {
            if (existing.equalsIgnoreCase(name)) {
               return false;
            }
         }

         boolean added = trackedBots.add(name);
         trackedChanged();
         return added;
      }
   }

   private static void trackedChanged() {
      trackedVersion.incrementAndGet();
   }

   private static TrackedIndex trackedIndex() {
      int version = trackedVersion.get();
      TrackedIndex idx = trackedIndex;
      if (idx.version() == version) {
         return idx;
      } else {
         Map<String, String> byKey = new HashMap();
         boolean usable = true;

         for(String n : trackedBots) {
            String key = asciiLower(n);
            if (key == null || byKey.putIfAbsent(key, n) != null) {
               usable = false;
               break;
            }
         }

         idx = new TrackedIndex(version, byKey, usable);
         trackedIndex = idx;
         return idx;
      }
   }

   private static String asciiLower(String s) {
      int i = 0;

      for(int n = s.length(); i < n; ++i) {
         if (s.charAt(i) >= 128) {
            return null;
         }
      }

      return s.toLowerCase(Locale.ROOT);
   }

   private static boolean playerNameMatches(String query, ServerPlayer p) {
      return query != null && !query.isBlank() ? strippedNameMatches(query.strip(), p, true) : false;
   }

   private static boolean strippedNameMatches(String want, ServerPlayer p, boolean anyNicked) {
      GameProfile profile = p.getGameProfile();
      String profileName = profile != null ? profile.name() : null;
      if (profileName != null && profileName.equalsIgnoreCase(want)) {
         return true;
      } else if (p.getScoreboardName().strip().equalsIgnoreCase(want)) {
         return true;
      } else if (!anyNicked) {
         return false;
      } else {
         String was = NickManager.isNicked(p) ? NickManager.originalName(p.getUUID()) : null;
         return was != null && was.strip().equalsIgnoreCase(want);
      }
   }

   public static ServerPlayer resolveTrackedBotPlayer(MinecraftServer server, String trackedName) {
      if (trackedName != null && !trackedName.isBlank()) {
         if (!server.isSameThread()) {
            return scanTrackedBotPlayer(server, trackedName);
         } else {
            List<ServerPlayer> players = server.getPlayerList().getPlayers();
            int tick = server.getTickCount();
            if (tick != resolveIndexTick || players.size() != resolveIndexPlayers) {
               rebuildResolveIndex(players);
               resolveIndexTick = tick;
               resolveIndexPlayers = players.size();
            }

            String key;
            if (trackedName == resolveKeyFor) {
               key = resolveKey;
            } else {
               key = trackedName.strip().toLowerCase(Locale.ROOT);
               resolveKeyFor = trackedName;
               resolveKey = key;
            }

            ServerPlayer hit = (ServerPlayer)RESOLVE_TAGGED.get(key);
            if (hit == null) {
               hit = (ServerPlayer)RESOLVE_UNTAGGED.get(key);
            }

            return hit != null && !hit.isRemoved() && playerNameMatches(trackedName, hit) ? hit : scanTrackedBotPlayer(server, trackedName);
         }
      } else {
         return null;
      }
   }

   private static void rebuildResolveIndex(List<ServerPlayer> players) {
      ++resolveIndexBuild;
      RESOLVE_TAGGED.clear();
      RESOLVE_UNTAGGED.clear();
      boolean anyNicked = NickManager.anyNicked();

      for(ServerPlayer p : players) {
         if (p instanceof BotPlayer) {
            boolean tagged = McCompat.tags(p).contains("vexbot");
            GameProfile profile = p.getGameProfile();
            String profileName = profile != null && profile.name() != null ? profile.name().strip() : null;
            if (profileName != null) {
               indexKey(profileName, p, tagged);
            }

            String entityName = p.getScoreboardName().strip();
            if (!entityName.equals(profileName)) {
               indexKey(entityName, p, tagged);
            }

            if (anyNicked && NickManager.isNicked(p)) {
               String was = NickManager.originalName(p.getUUID());
               if (was != null) {
                  indexKey(was.strip(), p, tagged);
               }
            }
         }
      }

   }

   private static void indexKey(String name, ServerPlayer p, boolean tagged) {
      if (!name.isEmpty()) {
         String key = name.toLowerCase(Locale.ROOT);
         if (tagged) {
            RESOLVE_TAGGED.put(key, p);
         } else {
            RESOLVE_UNTAGGED.putIfAbsent(key, p);
         }

      }
   }

   private static ServerPlayer scanTrackedBotPlayer(MinecraftServer server, String trackedName) {
      ServerPlayer taggedFake = null;
      ServerPlayer untaggedFake = null;
      String want = trackedName.strip();
      boolean anyNicked = NickManager.anyNicked();

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (p instanceof BotPlayer && strippedNameMatches(want, p, anyNicked)) {
            if (McCompat.tags(p).contains("vexbot")) {
               taggedFake = p;
            } else if (untaggedFake == null) {
               untaggedFake = p;
            }
         }
      }

      if (taggedFake != null) {
         return taggedFake;
      } else {
         return untaggedFake;
      }
   }

   public static ServerPlayer resolveNonBotPlayerByName(MinecraftServer server, String name) {
      if (name != null && !name.isBlank()) {
         String want = name.strip();
         boolean anyNicked = NickManager.anyNicked();

         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!(p instanceof BotPlayer) && strippedNameMatches(want, p, anyNicked)) {
               return p;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public static ServerPlayer resolveOtherPlayerByName(MinecraftServer server, ServerPlayer exclude, String name) {
      if (name != null && !name.isBlank() && exclude != null) {
         ServerPlayer human = resolveNonBotPlayerByName(server, name);
         if (human != null && human != exclude) {
            return human;
         } else {
            String want = name.strip();
            boolean anyNicked = NickManager.anyNicked();

            for(ServerPlayer p : server.getPlayerList().getPlayers()) {
               if (p != exclude && p instanceof BotPlayer && strippedNameMatches(want, p, anyNicked)) {
                  return p;
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   public static String peekSpawnStaticBlockReason(MinecraftServer server, String name) {
      String badName = invalidBotNameReason(name);
      if (badName != null) {
         return badName;
      } else if (isBanned(server, name)) {
         return "'" + name + "' is banned on this server. /pardon " + name + " to spawn it again.";
      } else {
         for(String existing : trackedBots) {
            if (existing.equalsIgnoreCase(name)) {
               return "A bot named '" + name + "' already exists.";
            }
         }

         if (resolveNonBotPlayerByName(server, name) != null) {
            return "A player named '" + name + "' is already online.";
         } else {
            return null;
         }
      }
   }

   public static boolean isBanned(MinecraftServer server, String name) {
      if (server != null && name != null) {
         try {
            for(UserBanListEntry entry : server.getPlayerList().getBans().getEntries()) {
               NameAndId user = (NameAndId)entry.getUser();
               if (user != null && name.equalsIgnoreCase(user.name())) {
                  Date expires = entry.getExpires();
                  if (expires == null || expires.after(new Date())) {
                     return true;
                  }
               }
            }
         } catch (Throwable t) {
            VexBot.LOGGER.debug("[VexBot] Ban list check failed for '{}': {}", name, t.toString());
         }

         return false;
      } else {
         return false;
      }
   }

   private static boolean spawnInternal(MinecraftServer server, String name, double x, double y, double z, float yaw, float pitch, String dimensionId) {
      try {
         ResourceKey<Level> dimKey = ResourceKey.create(Registries.DIMENSION, Identifier.parse(dimensionId));
         ServerLevel level = server.getLevel(dimKey);
         if (level == null) {
            VexBot.LOGGER.warn("[VexBot] Unknown dimension '{}', using overworld.", dimensionId);
            dimKey = Level.OVERWORLD;
         }

         int result = BotPlayer.createFake(name, server, new Vec3(x, y, z), (double)yaw, (double)pitch, dimKey, GameType.SURVIVAL, false, () -> {
            trackedBots.remove(name);
            trackedChanged();
            if (TeamManager.removeBotFromAllTeams(name)) {
               SettingsPersistence.save(server);
            }

            VexBot.LOGGER.warn("[VexBot] Could not resolve UUID for '{}' — online mode may be required.", name);
         });
         if (result == 0) {
            trackedBots.remove(name);
            trackedChanged();
            if (TeamManager.removeBotFromAllTeams(name)) {
               SettingsPersistence.save(server);
            }

            VexBot.LOGGER.warn("[VexBot] Could not resolve UUID for '{}' — online mode may be required.", name);
            return false;
         } else {
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' spawning at ({}, {}, {}).", name, x, y, z);
            return true;
         }
      } catch (Throwable t) {
         trackedBots.remove(name);
         trackedChanged();
         if (TeamManager.removeBotFromAllTeams(name)) {
            SettingsPersistence.save(server);
         }

         VexBot.LOGGER.error("[VexBot] Failed to spawn '{}': {}", new Object[]{name, t.getMessage(), t});
         return false;
      }
   }

   public static void releaseTrackedBot(MinecraftServer server, String name) {
      name = canonicalOr(name);
      queuedSpawns.remove(name);
      if (trackedBots.remove(name)) {
         trackedChanged();
         if (TeamManager.removeBotFromAllTeams(name)) {
            SettingsPersistence.save(server);
         }

         forget(name);
         VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' left the server.", name);
      }
   }

   private static void applyBotWorldLoad(MinecraftServer server, BotResolution botResolution) {
      boolean adv = BotSettings.botAdvancements;
      boolean resume = adv && !botAdvancementsApplied;
      botAdvancementsApplied = adv;

      for(String name : trackedBots) {
         ServerPlayer bot = botResolution.resolve(name);
         if (bot != null) {
            if (!adv) {
               McCompat.stopAdvancementTriggers(bot);
            } else if (resume) {
               McCompat.resumeAdvancementTriggers(bot, server);
            }

            Internals.get().setAffectsSpawning(bot, BotSettings.botSpawnMobs);
            AttributeInstance range = bot.getAttribute(Attributes.WAYPOINT_RECEIVE_RANGE);
            if (range != null && range.getBaseValue() != (double)0.0F) {
               range.setBaseValue((double)0.0F);
            }
         }
      }

   }

   private static void applyBotPings(MinecraftServer server, BotResolution botResolution) {
      List<ServerPlayer> changed = new ArrayList();

      for(String name : trackedBots) {
         ServerPlayer bot = botResolution.resolve(name);
         if (bot != null && bot.connection != null) {
            int want = EffectiveSettings.of(name).botPing();
            if (bot.connection.latency() != want) {
               Internals.get().setLatency(bot, want);
               changed.add(bot);
            }
         }
      }

      if (!changed.isEmpty()) {
         server.getPlayerList().broadcastAll(new ClientboundPlayerInfoUpdatePacket(EnumSet.of(Action.UPDATE_LATENCY), changed));
      }

   }

   private static String canonicalOr(String name) {
      String c = resolveCanonicalBotName(name);
      return c != null ? c : name;
   }

   private static void forget(String name) {
      SwordPvpController ai = (SwordPvpController)activeBots.remove(name);
      ControlCli.forget(name);
      if (ai != null) {
         ai.shutdown();
      }

      queuedSpawns.remove(name);
      practiceBots.remove(name.toLowerCase(Locale.ROOT));
      missingTicks.remove(name);
      spawnWaitTicks.remove(name);
      clearFollowTarget(name);
      attackTargets.remove(name);
      clearLookAtTarget(name);
      pendingAttach.remove(name);
      pendingRevenge.remove(name);
      pendingKit.remove(name);
      pendingEnder.remove(name);
      pendingRandomGear.remove(name);
      ffaLootBots.removeIf((s) -> s.equalsIgnoreCase(name));
   }

   public static boolean kill(MinecraftServer server, String name) {
      return kill(server, name, false);
   }

   private static boolean kill(MinecraftServer server, String name, boolean keepTeams) {
      name = canonicalOr(name);
      if (!trackedBots.remove(name)) {
         return false;
      } else {
         trackedChanged();
         if (!keepTeams && TeamManager.removeBotFromAllTeams(name)) {
            SettingsPersistence.save(server);
         }

         if (BotPlayer.isSpawningPlayer(name)) {
            cancelledSpawns.put(name.toLowerCase(Locale.ROOT), 600);
         }

         forget(name);
         ServerPlayer resolved = resolveTrackedBotPlayer(server, name);
         if (resolved instanceof BotPlayer) {
            BotPlayer botPlayer = (BotPlayer)resolved;

            try {
               server.getPlayerList().remove(botPlayer);
            } catch (Throwable t) {
               VexBot.LOGGER.warn("[VexBot] Error removing '{}': {}", name, t.getMessage());
            }
         }

         return true;
      }
   }

   public static int killAll(MinecraftServer server) {
      boolean keepTeams = !server.isRunning() && BotSettings.botDontLeave;
      List<String> names = new ArrayList(trackedBots);
      SettingsPersistence.beginBatch();

      try {
         names.forEach((name) -> kill(server, name, keepTeams));
      } finally {
         SettingsPersistence.endBatch(server);
      }

      spawnQueue.clear();
      queuedSpawns.clear();
      return names.size();
   }

   public static Set<String> getBotNames() {
      return Collections.unmodifiableSet(trackedBots);
   }

   public static boolean isTrackedBotName(String name) {
      if (name != null && !name.isBlank()) {
         if (trackedBots.contains(name)) {
            return true;
         } else {
            TrackedIndex idx = trackedIndex();
            if (idx.usable()) {
               String key = asciiLower(name);
               if (key != null) {
                  return idx.byKey().containsKey(key);
               }
            }

            for(String existing : trackedBots) {
               if (existing.equalsIgnoreCase(name)) {
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   public static String resolveCanonicalBotName(String query) {
      if (query != null && !query.isBlank()) {
         String want = query.strip();
         if (trackedBots.contains(want)) {
            return want;
         } else {
            TrackedIndex idx = trackedIndex();
            if (idx.usable()) {
               String key = asciiLower(want);
               if (key != null) {
                  return (String)idx.byKey().get(key);
               }
            }

            for(String n : trackedBots) {
               if (n.equalsIgnoreCase(want)) {
                  return n;
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private static boolean followMemoUsable() {
      MinecraftServer s = VexBot.SERVER;
      if (s != null && s.isSameThread()) {
         if (followMemoVersion != followVersion) {
            followTargetMemo.clear();
            followFormationMemo.clear();
            followRowWidthMemo.clear();
            followElytraMemo.clear();
            followGroupMemo.clear();
            followGroupFlyMemo.clear();
            followMemoVersion = followVersion;
         }

         return true;
      } else {
         return false;
      }
   }

   private static <V> void followMemoPut(Map<String, V> memo, String key, V value) {
      if (memo.size() >= 4096) {
         memo.clear();
      }

      memo.put(key, value);
   }

   private static void removeFollowTargetIgnoreCase(String botName) {
      if (botName != null) {
         if (followTargets.entrySet().removeIf((e) -> ((String)e.getKey()).equalsIgnoreCase(botName))) {
            ++followVersion;
         }

      }
   }

   public static void setFollowTarget(String botName, String playerName) {
      setFollowTarget(botName, playerName, FollowFormation.Type.NONE);
   }

   public static void setFollowTarget(String botName, String playerName, FollowFormation.Type formation) {
      setFollowTarget(botName, playerName, formation, 3);
   }

   public static void setFollowTarget(String botName, String playerName, FollowFormation.Type formation, int rowWidth) {
      setFollowTarget(botName, playerName, formation, rowWidth, false);
   }

   public static void setFollowTarget(String botName, String playerName, FollowFormation.Type formation, int rowWidth, boolean elytra) {
      String canonical = resolveCanonicalBotName(botName);
      if (canonical != null) {
         attackTargets.entrySet().removeIf((e) -> ((String)e.getKey()).equalsIgnoreCase(canonical));
         removeFollowTargetIgnoreCase(canonical);
         clearLookAtTarget(canonical);
         followTargets.put(canonical, playerName);
         followFormations.put(canonical, formation == null ? FollowFormation.Type.NONE : formation);
         followRowWidth.put(canonical, rowWidth > 0 ? rowWidth : 3);
         followElytra.removeIf((s) -> s.equalsIgnoreCase(canonical));
         if (elytra) {
            followElytra.add(canonical);
         }

         ++followVersion;
      }
   }

   public static boolean isFollowElytra(String botName) {
      if (botName != null && !followElytra.isEmpty()) {
         if (followMemoUsable()) {
            Boolean hit = (Boolean)followElytraMemo.get(botName);
            if (hit != null) {
               return hit;
            } else {
               boolean v = scanFollowElytra(botName);
               followMemoPut(followElytraMemo, botName, v);
               return v;
            }
         } else {
            return scanFollowElytra(botName);
         }
      } else {
         return false;
      }
   }

   private static boolean scanFollowElytra(String botName) {
      for(String s : followElytra) {
         if (s.equalsIgnoreCase(botName)) {
            return true;
         }
      }

      return false;
   }

   public static void clearFollowTarget(String botName) {
      removeFollowTargetIgnoreCase(botName);
      if (botName != null) {
         boolean changed = followFormations.entrySet().removeIf((e) -> ((String)e.getKey()).equalsIgnoreCase(botName));
         changed |= followRowWidth.entrySet().removeIf((e) -> ((String)e.getKey()).equalsIgnoreCase(botName));
         changed |= followElytra.removeIf((s) -> s.equalsIgnoreCase(botName));
         if (changed) {
            ++followVersion;
         }
      }

   }

   public static int getFollowRowWidth(String botName) {
      if (botName != null && !followRowWidth.isEmpty()) {
         if (followMemoUsable()) {
            Integer hit = (Integer)followRowWidthMemo.get(botName);
            if (hit != null) {
               return hit;
            } else {
               int v = scanFollowRowWidth(botName);
               followMemoPut(followRowWidthMemo, botName, v);
               return v;
            }
         } else {
            return scanFollowRowWidth(botName);
         }
      } else {
         return 3;
      }
   }

   private static int scanFollowRowWidth(String botName) {
      for(Map.Entry<String, Integer> e : followRowWidth.entrySet()) {
         if (((String)e.getKey()).equalsIgnoreCase(botName)) {
            return (Integer)e.getValue();
         }
      }

      return 3;
   }

   public static String getFollowTarget(String botName) {
      if (botName != null && !followTargets.isEmpty()) {
         if (followMemoUsable()) {
            Object hit = followTargetMemo.get(botName);
            if (hit != null) {
               return hit == NO_FOLLOW ? null : (String)hit;
            } else {
               String v = scanFollowTarget(botName);
               followMemoPut(followTargetMemo, botName, v == null ? NO_FOLLOW : v);
               return v;
            }
         } else {
            return scanFollowTarget(botName);
         }
      } else {
         return null;
      }
   }

   private static String scanFollowTarget(String botName) {
      for(Map.Entry<String, String> e : followTargets.entrySet()) {
         if (((String)e.getKey()).equalsIgnoreCase(botName)) {
            return (String)e.getValue();
         }
      }

      return null;
   }

   public static boolean isInFfaLootMode(String botName) {
      return botName != null && !ffaLootBots.isEmpty() && ffaLootBots.contains(canonicalOr(botName));
   }

   public static void setFfaLootMode(String botName, boolean on) {
      if (botName != null) {
         String c = canonicalOr(botName);
         if (on) {
            ffaLootBots.add(c);
         } else {
            ffaLootBots.remove(c);
         }

      }
   }

   public static void clearFfaLootMode() {
      ffaLootBots.clear();
   }

   public static int ffaLootCount() {
      return ffaLootBots.size();
   }

   public static FollowFormation.Type getFollowFormation(String botName) {
      if (botName != null && !followFormations.isEmpty()) {
         if (followMemoUsable()) {
            FollowFormation.Type hit = (FollowFormation.Type)followFormationMemo.get(botName);
            if (hit != null) {
               return hit;
            } else {
               FollowFormation.Type v = scanFollowFormation(botName);
               followMemoPut(followFormationMemo, botName, v);
               return v;
            }
         } else {
            return scanFollowFormation(botName);
         }
      } else {
         return FollowFormation.Type.NONE;
      }
   }

   private static FollowFormation.Type scanFollowFormation(String botName) {
      for(Map.Entry<String, FollowFormation.Type> e : followFormations.entrySet()) {
         if (((String)e.getKey()).equalsIgnoreCase(botName)) {
            return (FollowFormation.Type)e.getValue();
         }
      }

      return FollowFormation.Type.NONE;
   }

   public static List<String> followGroup(String targetName) {
      List<String> group = new ArrayList();
      if (targetName == null) {
         return group;
      } else {
         for(Map.Entry<String, String> e : followTargets.entrySet()) {
            if (targetName.equalsIgnoreCase((String)e.getValue())) {
               group.add((String)e.getKey());
            }
         }

         group.sort(String.CASE_INSENSITIVE_ORDER);
         return group;
      }
   }

   public static List<String> followGroup(String targetName, boolean elytra) {
      if (targetName == null) {
         return new ArrayList();
      } else {
         return (List<String>)(followMemoUsable() ? new ArrayList(followGroupEntry(targetName, elytra).names) : scanFollowGroup(targetName, elytra));
      }
   }

   private static FollowGroup followGroupEntry(String targetName, boolean elytra) {
      Map<String, FollowGroup> memo = elytra ? followGroupFlyMemo : followGroupMemo;
      FollowGroup g = (FollowGroup)memo.get(targetName);
      if (g == null) {
         g = new FollowGroup(List.copyOf(scanFollowGroup(targetName, elytra)));
         followMemoPut(memo, targetName, g);
      }

      return g;
   }

   private static List<String> scanFollowGroup(String targetName, boolean elytra) {
      List<String> group = new ArrayList();

      for(Map.Entry<String, String> e : followTargets.entrySet()) {
         if (targetName.equalsIgnoreCase((String)e.getValue()) && isFollowElytra((String)e.getKey()) == elytra) {
            group.add((String)e.getKey());
         }
      }

      group.sort(String.CASE_INSENSITIVE_ORDER);
      return group;
   }

   public static List<String> followGroupAlive(MinecraftServer server, String targetName, boolean elytra) {
      if (server != null && targetName != null && server.isSameThread() && followMemoUsable()) {
         FollowGroup g = followGroupEntry(targetName, elytra);
         List<String> names = g.names;
         int n = names.size();
         if (n == 0) {
            return new ArrayList();
         } else {
            List<String> alive = new ArrayList(n);
            boolean reuse = g.hits != null && g.build == resolveIndexBuild && resolveIndexTick == server.getTickCount() && resolveIndexPlayers == server.getPlayerList().getPlayers().size();
            if (reuse) {
               for(int i = 0; i < n; ++i) {
                  ServerPlayer h = g.hits[i];
                  ServerPlayer p = h != null && !h.isRemoved() && h.getGameProfile() == g.profiles[i] ? h : resolveTrackedBotPlayer(server, (String)names.get(i));
                  if (p != null && p.isAlive() && !p.isRemoved()) {
                     alive.add((String)names.get(i));
                  }
               }
            } else {
               ServerPlayer[] hits = new ServerPlayer[n];
               GameProfile[] profiles = new GameProfile[n];
               int build = -1;

               for(int i = 0; i < n; ++i) {
                  String name = (String)names.get(i);
                  ServerPlayer p = resolveTrackedBotPlayer(server, name);
                  if (i == 0) {
                     build = resolveIndexBuild;
                  }

                  if (p != null && !p.isRemoved() && p == indexHit(name) && profileNameMatches(name, p)) {
                     hits[i] = p;
                     profiles[i] = p.getGameProfile();
                  }

                  if (p != null && p.isAlive() && !p.isRemoved()) {
                     alive.add(name);
                  }
               }

               g.hits = hits;
               g.profiles = profiles;
               g.build = build == resolveIndexBuild ? build : -1;
            }

            return (List<String>)(alive.isEmpty() ? new ArrayList(names) : alive);
         }
      } else {
         List<String> group = followGroup(targetName, elytra);
         if (server != null && !group.isEmpty()) {
            List<String> alive = new ArrayList(group.size());

            for(String name : group) {
               ServerPlayer p = resolveTrackedBotPlayer(server, name);
               if (p != null && p.isAlive() && !p.isRemoved()) {
                  alive.add(name);
               }
            }

            return alive.isEmpty() ? group : alive;
         } else {
            return group;
         }
      }
   }

   private static ServerPlayer indexHit(String trackedName) {
      String key = trackedName.strip().toLowerCase(Locale.ROOT);
      ServerPlayer hit = (ServerPlayer)RESOLVE_TAGGED.get(key);
      return hit != null ? hit : (ServerPlayer)RESOLVE_UNTAGGED.get(key);
   }

   private static boolean profileNameMatches(String query, ServerPlayer p) {
      GameProfile profile = p.getGameProfile();
      String profileName = profile != null ? profile.name() : null;
      return profileName != null && profileName.equalsIgnoreCase(query.strip());
   }

   public static void setAttackTarget(String botName, String playerName) {
      setAttackTarget(botName, playerName, false);
   }

   public static void setAttackTarget(String botName, String playerName, boolean keepFormation) {
      if (botName != null) {
         botName = canonicalOr(botName);
         if (!keepFormation) {
            removeFollowTargetIgnoreCase(botName);
         }

         clearLookAtTarget(botName);
         attackTargets.put(botName, playerName);
      }
   }

   public static void clearAttackTarget(String botName) {
      if (botName != null) {
         attackTargets.remove(canonicalOr(botName));
      }
   }

   public static String currentTargetName(String botName) {
      SwordPvpController ai = (SwordPvpController)activeBots.get(botName);
      if (ai == null) {
         for(Map.Entry<String, SwordPvpController> e : activeBots.entrySet()) {
            if (((String)e.getKey()).equalsIgnoreCase(botName)) {
               ai = (SwordPvpController)e.getValue();
               break;
            }
         }
      }

      if (ai == null) {
         return null;
      } else {
         LivingEntity t = ai.getTarget();
         return t != null && t.isAlive() ? t.getName().getString() : null;
      }
   }

   public static Collection<SwordPvpController> activeControllers() {
      return activeBots.values();
   }

   public static String getAttackTarget(String botName) {
      return botName != null && !attackTargets.isEmpty() ? (String)attackTargets.get(canonicalOr(botName)) : null;
   }

   public static void setLookAtTarget(String botName, String targetName) {
      if (targetName != null && !targetName.isBlank()) {
         setLookOrder(botName, BotManager.LookOrder.entity(targetName.strip()));
      }
   }

   public static void setLookPoint(String botName, Vec3 point) {
      if (point != null) {
         setLookOrder(botName, BotManager.LookOrder.point(point));
      }

   }

   public static void setLookAngle(String botName, Float yaw, Float pitch) {
      LookOrder prev = getLookOrder(botName);
      Float keepYaw = prev != null && prev.isAngle() ? prev.yaw() : null;
      Float keepPitch = prev != null && prev.isAngle() ? prev.pitch() : null;
      setLookOrder(botName, BotManager.LookOrder.angle(yaw != null ? yaw : keepYaw, pitch != null ? pitch : keepPitch));
   }

   private static void setLookOrder(String botName, LookOrder order) {
      String canonical = resolveCanonicalBotName(botName);
      if (canonical != null) {
         clearLookAtTarget(canonical);
         lookOrders.put(canonical, order);
      }
   }

   public static void clearLookAtTarget(String botName) {
      if (botName != null) {
         lookOrders.entrySet().removeIf((e) -> ((String)e.getKey()).equalsIgnoreCase(botName));
      }
   }

   public static LookOrder getLookOrder(String botName) {
      if (botName == null) {
         return null;
      } else {
         for(Map.Entry<String, LookOrder> e : lookOrders.entrySet()) {
            if (((String)e.getKey()).equalsIgnoreCase(botName)) {
               return (LookOrder)e.getValue();
            }
         }

         return null;
      }
   }

   public static String getLookAtTarget(String botName) {
      LookOrder order = getLookOrder(botName);
      return order == null ? null : order.entityName();
   }

   public static ServerPlayer resolvePlayerOrBotByName(MinecraftServer server, String name) {
      if (name != null && !name.isBlank()) {
         String want = name.strip();
         if (server.isSameThread() && inServerTick) {
            List<ServerPlayer> players = server.getPlayerList().getPlayers();
            int size = players.size();
            ServerPlayer last = size == 0 ? null : (ServerPlayer)players.get(size - 1);
            int tick = server.getTickCount();
            int nicks = NickManager.version();
            if (tick == byNameTick && size == byNameSize && last == byNameLast && nicks == byNameNicks) {
               if (!byNameBuilt) {
                  rebuildByName(players);
                  byNameBuilt = true;
               }

               if (byNameUsable) {
                  String key = asciiLower(want);
                  if (key != null) {
                     return (ServerPlayer)BY_NAME.get(key);
                  }
               }
            } else {
               byNameTick = tick;
               byNameSize = size;
               byNameLast = last;
               byNameNicks = nicks;
               byNameBuilt = false;
            }
         }

         boolean anyNicked = NickManager.anyNicked();

         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (strippedNameMatches(want, p, anyNicked)) {
               return p;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static void rebuildByName(List<ServerPlayer> players) {
      BY_NAME.clear();
      byNameUsable = true;
      boolean anyNicked = NickManager.anyNicked();

      for(ServerPlayer p : players) {
         GameProfile profile = p.getGameProfile();
         String profileName = profile != null ? profile.name() : null;
         if (profileName != null && !byNameKey(profileName, p)) {
            return;
         }

         if (!byNameKey(p.getScoreboardName().strip(), p)) {
            return;
         }

         if (anyNicked && NickManager.isNicked(p)) {
            String was = NickManager.originalName(p.getUUID());
            if (was != null && !byNameKey(was.strip(), p)) {
               return;
            }
         }
      }

   }

   private static boolean byNameKey(String name, ServerPlayer p) {
      String key = asciiLower(name);
      if (key == null) {
         byNameUsable = false;
         BY_NAME.clear();
         return false;
      } else {
         BY_NAME.putIfAbsent(key, p);
         return true;
      }
   }

   public static void tickLookAt(ServerPlayer bot, MinecraftServer server) {
      LookOrder order = getLookOrder(NickManager.realName(bot));
      if (order != null) {
         if (order.entityName() != null) {
            LivingEntity target = resolveOtherPlayerByName(server, bot, order.entityName());
            if (target != null && target.isAlive()) {
               applySmoothLookAt(bot, target.getX(), target.getEyeY(), target.getZ());
            } else {
               clearLookAtTarget(NickManager.realName(bot));
            }
         } else if (order.point() != null) {
            applySmoothLookAt(bot, order.point().x, order.point().y, order.point().z);
         } else {
            applySmoothAngles(bot, order.yaw() != null ? order.yaw() : bot.getYHeadRot(), order.pitch() != null ? order.pitch() : bot.getXRot());
         }
      }
   }

   private static void applySmoothLookAt(ServerPlayer bot, double tx, double ty, double tz) {
      float[] angles = BotMath.getAngles(bot.getEyePosition().x, bot.getEyePosition().y, bot.getEyePosition().z, tx, ty, tz);
      applySmoothAngles(bot, angles[0], angles[1]);
   }

   private static void applySmoothAngles(ServerPlayer bot, float wantYaw, float wantPitch) {
      float lookYaw = BotMath.smoothYawToward(bot.getYHeadRot(), wantYaw, 14.0F);
      lookYaw = BotMath.wrapDegrees(lookYaw);
      float pitchDiff = wantPitch - bot.getXRot();
      float pitchStep = Mth.clamp(pitchDiff, -14.0F, 14.0F);
      float lookPitch = Mth.clamp(bot.getXRot() + pitchStep, -90.0F, 90.0F);
      bot.setYRot(lookYaw);
      bot.setYHeadRot(lookYaw);
      bot.setYBodyRot(lookYaw);
      bot.setXRot(lookPitch);
   }

   public static void notifyBotHurtBy(String botName, String attackerName) {
      if (botName != null) {
         botName = canonicalOr(botName);
         SwordPvpController ai = (SwordPvpController)activeBots.get(botName);
         if (ai != null) {
            ai.notifyHurtBy(attackerName);
         }

         TeamManager.BotTeam team = TeamManager.getTeamForBot(botName);
         if (team != null && team.isRevengeMode()) {
            for(String mate : team.getBotNames()) {
               if (!mate.equalsIgnoreCase(botName)) {
                  SwordPvpController mateAi = (SwordPvpController)activeBots.get(canonicalOr(mate));
                  if (mateAi != null) {
                     mateAi.notifyHurtBy(attackerName);
                  }
               }
            }

         }
      }
   }

   public static void notifyPlayerHurtBy(String victimName, String attackerName) {
      if (victimName != null && attackerName != null && !followTargets.isEmpty()) {
         TeamManager.BotTeam victimTeam = TeamManager.getTeamForMember(victimName);
         String victimTeamName = victimTeam != null ? victimTeam.getName() : null;

         for(Map.Entry<String, String> e : followTargets.entrySet()) {
            String follow = (String)e.getValue();
            if (follow != null) {
               boolean guards = follow.equalsIgnoreCase(victimName) || victimTeamName != null && follow.equalsIgnoreCase(victimTeamName);
               if (guards) {
                  SwordPvpController ai = (SwordPvpController)activeBots.get(e.getKey());
                  if (ai != null) {
                     ai.notifyHurtBy(attackerName);
                  }
               }
            }
         }

      }
   }

   public static void onServerTick(MinecraftServer server) {
      inServerTick = true;

      try {
         serverTick(server);
      } finally {
         inServerTick = false;
      }

   }

   private static void serverTick(MinecraftServer server) {
      for(int i = 0; i < 4 && !spawnQueue.isEmpty(); ++i) {
         Runnable task = (Runnable)spawnQueue.poll();
         if (task != null) {
            task.run();
         }
      }

      if (!cancelledSpawns.isEmpty()) {
         cancelledSpawns.replaceAll((k, v) -> v - 1);
         cancelledSpawns.values().removeIf((v) -> v <= 0);
      }

      Map<String, ServerPlayer> playerSnapshot = new HashMap();

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         String n = p.getScoreboardName();
         ServerPlayer existing = (ServerPlayer)playerSnapshot.get(n);
         if (existing == null) {
            playerSnapshot.put(n, p);
         } else {
            boolean existingIsBot = McCompat.tags(existing).contains("vexbot");
            boolean candidateIsBot = McCompat.tags(p).contains("vexbot");
            if (!existingIsBot && candidateIsBot) {
               playerSnapshot.put(n, p);
            } else if (!existingIsBot && !candidateIsBot) {
               boolean eHero = existing instanceof BotPlayer;
               boolean cHero = p instanceof BotPlayer;
               if (!eHero && cHero) {
                  playerSnapshot.put(n, p);
               }
            }
         }
      }

      for(ServerPlayer p : playerSnapshot.values()) {
         if (p instanceof BotPlayer && p.isAlive()) {
            String bn = NickManager.realName(p);
            if (!cancelledSpawns.isEmpty() && cancelledSpawns.remove(bn.toLowerCase(Locale.ROOT)) != null && !isTrackedBotName(bn)) {
               try {
                  server.getPlayerList().remove(p);
               } catch (Throwable t) {
                  VexBot.LOGGER.warn("[VexBot] Error removing cancelled spawn '{}': {}", bn, t.getMessage());
               }
            } else if (tryReserveTrackedName(bn)) {
               if (!McCompat.tags(p).contains("vexbot")) {
                  p.addTag("vexbot");
               }

               VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' was in the world without an AI — re-registering so it attaches.", bn);
            }
         }
      }

      BotResolution botResolution = new BotResolution(server);

      for(String name : trackedBots) {
         ServerPlayer player = botResolution.resolve(name);
         if (player != null && !player.isAlive() && player instanceof BotPlayer && McCompat.tags(player).contains("vexbot") && EffectiveSettings.of(name).botLeaveOnDeath() && TeamManager.removeBotFromAllTeams(name)) {
            SettingsPersistence.save(server);
         }

         if (player != null && player.isAlive()) {
            if (player instanceof BotPlayer) {
               missingTicks.remove(name);
               ItemStack[] kit = (ItemStack[])pendingKit.remove(name);
               ItemStack[] kitEnder = (ItemStack[])pendingEnder.remove(name);
               if (kit != null) {
                  try {
                     KitManager.apply(player, kit);
                     KitManager.applyEnder(player, kitEnder);
                  } catch (Throwable t) {
                     VexBot.LOGGER.warn("[VexBot] pending kit apply failed for '{}': {}", name, t.getMessage());
                  }
               }

               if (pendingRandomGear.remove(name)) {
                  try {
                     RandomGearGenerator.apply(player);
                  } catch (Throwable t) {
                     VexBot.LOGGER.warn("[VexBot] pending random gear failed for '{}': {}", name, t.getMessage());
                  }
               }

               if (!McCompat.tags(player).contains("vexbot")) {
                  player.addTag("vexbot");
               }

               Integer warmupLeft = (Integer)pendingAttach.get(name);
               if (warmupLeft != null) {
                  if (getLookOrder(name) != null) {
                     tickLookAt(player, server);
                  } else {
                     lookAtNearestPlayer(player, server);
                  }

                  if (warmupLeft <= 0) {
                     pendingAttach.remove(name);
                     String revenge = (String)pendingRevenge.remove(name);
                     SwordPvpController newAI = new SwordPvpController(player, server);
                     if (revenge != null) {
                        newAI.notifyHurtBy(revenge);
                     }

                     activeBots.put(name, newAI);
                     VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' AI attached.", name);
                  } else {
                     pendingAttach.put(name, warmupLeft - 1);
                  }
               } else {
                  SwordPvpController existing = (SwordPvpController)activeBots.get(name);
                  boolean staleRef = existing != null && existing.getBot() != player;
                  if (existing == null || staleRef) {
                     if (staleRef) {
                        String revenge = existing.getRevengeTargetName();
                        if (revenge != null) {
                           pendingRevenge.put(name, revenge);
                        }

                        activeBots.remove(name);
                     }

                     if (player instanceof BotPlayer) {
                        player.addTag("vexbot");
                     }

                     BotCommands.stopMoving(server, name);
                     pendingAttach.put(name, 10);
                     lookAtNearestPlayer(player, server);
                     if (staleRef) {
                        VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' respawned — AI warmup started.", name);
                     } else {
                        Stats.inc("bots_spawned");
                        Stats.spawnedName(name);
                        VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' spawned at ({}, {}, {}) — AI warmup started.", name, player.getX(), player.getY(), player.getZ());
                     }
                  }
               }
            }
         } else if (BotPlayer.isSpawningPlayer(name)) {
         }
      }

      trackedBots.removeIf((namex) -> {
         if (queuedSpawns.containsKey(namex)) {
            missingTicks.remove(namex);
            return false;
         } else if (BotPlayer.isSpawningPlayer(namex)) {
            int waited = (Integer)spawnWaitTicks.merge(namex, 1, Integer::sum);
            if (waited < 600) {
               missingTicks.remove(namex);
               return false;
            } else {
               forget(namex);
               VexBot.LOGGER.warn("[VexBot] '{}' spawn timed out after {} ticks — releasing name reservation.", namex, 600);
               if (TeamManager.removeBotFromAllTeams(namex)) {
                  SettingsPersistence.save(server);
               }

               trackedChanged();
               return true;
            }
         } else {
            spawnWaitTicks.remove(namex);
            if (botResolution.resolve(namex) != null) {
               missingTicks.remove(namex);
               return false;
            } else {
               int absent = (Integer)missingTicks.merge(namex, 1, Integer::sum);
               if (absent < 100) {
                  return false;
               } else {
                  forget(namex);
                  if (TeamManager.removeBotFromAllTeams(namex)) {
                     SettingsPersistence.save(server);
                  }

                  VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' absent for {}+ ticks — cleaned up.", namex, 100);
                  trackedChanged();
                  return true;
               }
            }
         }
      });
      if (++tickCounter >= 20) {
         tickCounter = 0;
         applyBotPings(server, botResolution);
         applyBotWorldLoad(server, botResolution);

         for(String name : trackedBots) {
            ServerPlayer player = botResolution.resolve(name);
            if (player != null && player.gameMode.getGameModeForPlayer() != GameType.SURVIVAL) {
               player.setGameMode(GameType.SURVIVAL);
            }
         }

         if (TeamManager.pruneStaleSpecificPlayerTargets(server) || TeamManager.pruneInvalidTargetTeamEntries()) {
            SettingsPersistence.save(server);
         }

         TeamTargetBalancer.tick(server);
      }

      TeamManager.setRebalanceServer(server);

      try {
         TeamFormationOrders.onServerTick(server);
      } catch (RuntimeException e) {
         VexBot.LOGGER.error("[VexBot] team orders tick failed", e);
      }

      MaceDiveForecast.beginAiPass();

      try {
         for(Map.Entry<String, SwordPvpController> entry : activeBots.entrySet()) {
            ServerPlayer botEntity = ((SwordPvpController)entry.getValue()).getBot();
            if (botEntity.isAlive()) {
               try {
                  if (isPracticeBot((String)entry.getKey())) {
                     StunSlamDummy.tick(botEntity);
                  } else if (!ControlCli.isManual((String)entry.getKey())) {
                     ((SwordPvpController)entry.getValue()).tick();
                  }
               } catch (Throwable t) {
                  VexBot.LOGGER.error("[VexBot] AI tick crashed for '{}': {} — {}", new Object[]{entry.getKey(), t.getClass().getName(), t.getMessage(), t});
               } finally {
                  MaceDiveForecast.afterTick(botEntity);
               }
            }
         }
      } finally {
         MaceDiveForecast.endAiPass();
      }

   }

   private static void lookAtNearestPlayer(ServerPlayer bot, MinecraftServer server) {
      ServerPlayer nearest = null;
      double bestSq = Double.MAX_VALUE;

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (p != bot && !McCompat.tags(p).contains("vexbot")) {
            double sq = bot.distanceToSqr(p);
            if (sq < bestSq) {
               bestSq = sq;
               nearest = p;
            }
         }
      }

      if (nearest != null) {
         double dx = nearest.getX() - bot.getX();
         double dy = nearest.getEyeY() - bot.getEyeY();
         double dz = nearest.getZ() - bot.getZ();
         double horiz = Math.sqrt(dx * dx + dz * dz);
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
         bot.setYRot(yaw);
         bot.setXRot(pitch);
         bot.yRotO = yaw;
         bot.xRotO = pitch;
         bot.setYHeadRot(yaw);
         bot.setYBodyRot(yaw);
      }
   }

   private static record TrackedIndex(int version, Map<String, String> byKey, boolean usable) {
   }

   private static final class BotResolution {
      private final Map<String, ServerPlayer> tagged = new HashMap();
      private final Map<String, ServerPlayer> untagged = new HashMap();
      private static final Map<String, String> TRACKED_KEYS = new HashMap();

      BotResolution(MinecraftServer server) {
         boolean anyNicked = NickManager.anyNicked();

         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            boolean isTagged = McCompat.tags(p).contains("vexbot");
            boolean isBot = p instanceof BotPlayer || isTagged;
            if (isBot) {
               GameProfile profile = p.getGameProfile();
               String profileName = profile != null ? profile.name() : null;
               String entityName = p.getScoreboardName().strip();
               if (profileName != null) {
                  this.putKey(profileName.toLowerCase(Locale.ROOT), p, isTagged);
               }

               if (!entityName.equals(profileName)) {
                  this.putKey(entityName.toLowerCase(Locale.ROOT), p, isTagged);
               }

               if (anyNicked) {
                  String realName = NickManager.realName(p).strip();
                  if (!realName.equalsIgnoreCase(entityName)) {
                     this.putKey(realName.toLowerCase(Locale.ROOT), p, isTagged);
                  }
               }
            }
         }

      }

      private void putKey(String key, ServerPlayer p, boolean isTagged) {
         if (isTagged) {
            this.tagged.put(key, p);
         } else {
            this.untagged.putIfAbsent(key, p);
         }

      }

      ServerPlayer resolve(String trackedName) {
         if (trackedName != null && !trackedName.isBlank()) {
            String key = trackedKey(trackedName);
            ServerPlayer t = (ServerPlayer)this.tagged.get(key);
            return t != null ? t : (ServerPlayer)this.untagged.get(key);
         } else {
            return null;
         }
      }

      private static String trackedKey(String trackedName) {
         String key = (String)TRACKED_KEYS.get(trackedName);
         if (key == null) {
            key = trackedName.strip().toLowerCase(Locale.ROOT);
            if (TRACKED_KEYS.size() >= 4096) {
               TRACKED_KEYS.clear();
            }

            TRACKED_KEYS.put(trackedName, key);
         }

         return key;
      }
   }

   private static final class FollowGroup {
      final List<String> names;
      ServerPlayer[] hits;
      GameProfile[] profiles;
      int build = -1;

      FollowGroup(List<String> names) {
         this.names = names;
      }
   }

   public static record LookOrder(String entityName, Vec3 point, Float yaw, Float pitch) {
      public static LookOrder entity(String name) {
         return new LookOrder(name, (Vec3)null, (Float)null, (Float)null);
      }

      public static LookOrder point(Vec3 p) {
         return new LookOrder((String)null, p, (Float)null, (Float)null);
      }

      public static LookOrder angle(Float y, Float p) {
         return new LookOrder((String)null, (Vec3)null, y, p);
      }

      public boolean isAngle() {
         return this.entityName == null && this.point == null;
      }

      public String describe() {
         if (this.entityName != null) {
            return this.entityName;
         } else if (this.point != null) {
            return String.format(Locale.ROOT, "%.1f %.1f %.1f", this.point.x, this.point.y, this.point.z);
         } else {
            StringBuilder sb = new StringBuilder();
            if (this.yaw != null) {
               sb.append("yaw ").append(Math.round(this.yaw));
            }

            if (this.pitch != null) {
               sb.append(sb.length() > 0 ? ", " : "").append("pitch ").append(Math.round(this.pitch));
            }

            return sb.length() == 0 ? "nothing" : sb.toString();
         }
      }
   }
}
