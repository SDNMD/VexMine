package vexbot.bot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.PlayerEnderChestContainer;
import net.minecraft.world.item.ItemStack;
import vexbot.BotSettings;
import vexbot.VexBot;
import vexbot.fakeplayer.bot.BotPlayer;

public final class BotPersistence {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final String FILE = "vexbot_bots.json";
   private static final int SLOTS = 41;
   private static final Map<String, JsonObject> pending = new HashMap();

   private BotPersistence() {
   }

   private static Path file(MinecraftServer server) {
      return server.getServerDirectory().resolve("vexbot_bots.json");
   }

   public static void save(MinecraftServer server) {
      pending.clear();
      if (!BotSettings.botDontLeave) {
         try {
            Files.deleteIfExists(file(server));
         } catch (IOException var14) {
         }

      } else {
         RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
         JsonArray roster = new JsonArray();

         for(String name : BotManager.getBotNames()) {
            ServerPlayer bot = server.getPlayerList().getPlayerByName(name);
            if (bot != null && bot.isAlive() && bot instanceof BotPlayer) {
               JsonObject o = new JsonObject();
               o.addProperty("name", name);
               o.addProperty("dim", bot.level().dimension().identifier().toString());
               o.addProperty("x", bot.getX());
               o.addProperty("y", bot.getY());
               o.addProperty("z", bot.getZ());
               o.addProperty("yaw", bot.getYRot());
               o.addProperty("pitch", bot.getXRot());
               o.addProperty("health", bot.getHealth());
               JsonObject inv = new JsonObject();
               Inventory inventory = bot.getInventory();

               for(int i = 0; i < 41; ++i) {
                  ItemStack stack = inventory.getItem(i);
                  if (!stack.isEmpty()) {
                     JsonElement el = (JsonElement)ItemStack.CODEC.encodeStart(ops, stack).result().orElse((Object)null);
                     if (el != null) {
                        inv.add(String.valueOf(i), el);
                     }
                  }
               }

               o.add("inv", inv);
               JsonObject ender = new JsonObject();
               PlayerEnderChestContainer ec = bot.getEnderChestInventory();

               for(int i = 0; i < ec.getContainerSize(); ++i) {
                  ItemStack stack = ec.getItem(i);
                  if (!stack.isEmpty()) {
                     JsonElement el = (JsonElement)ItemStack.CODEC.encodeStart(ops, stack).result().orElse((Object)null);
                     if (el != null) {
                        ender.add(String.valueOf(i), el);
                     }
                  }
               }

               o.add("ender", ender);
               roster.add(o);
            }
         }

         try {
            JsonObject root = new JsonObject();
            root.add("bots", roster);
            Files.writeString(file(server), GSON.toJson(root));
            VexBot.LOGGER.info("[VexBot] botdontleave: saved {} bot(s) for the next session", roster.size());
         } catch (IOException e) {
            VexBot.LOGGER.error("[VexBot] botdontleave: could not save the bot roster", e);
         }

      }
   }

   public static void restore(MinecraftServer server) {
      pending.clear();
      Path path = file(server);
      if (Files.exists(path, new LinkOption[0])) {
         if (!BotSettings.botDontLeave) {
            try {
               Files.delete(path);
            } catch (IOException var9) {
            }

         } else {
            List<String> queued = new ArrayList();

            try {
               JsonObject root = (JsonObject)GSON.fromJson(Files.readString(path), JsonObject.class);
               if (root == null || !root.has("bots")) {
                  return;
               }

               for(JsonElement el : root.getAsJsonArray("bots")) {
                  JsonObject o = el.getAsJsonObject();
                  String name = o.get("name").getAsString();
                  boolean ok = BotManager.queueSpawn(server, name, o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(), o.get("yaw").getAsFloat(), o.get("pitch").getAsFloat(), o.get("dim").getAsString());
                  if (ok) {
                     pending.put(name, o);
                     queued.add(name);
                  }
               }
            } catch (Exception e) {
               VexBot.LOGGER.error("[VexBot] botdontleave: could not read the saved roster", e);
               return;
            }

            if (!queued.isEmpty()) {
               VexBot.LOGGER.info("[VexBot] botdontleave: restoring {} bot(s): {}", queued.size(), String.join(", ", queued));
            }

         }
      }
   }

   public static void onServerTick(MinecraftServer server) {
      if (!pending.isEmpty()) {
         RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
         pending.entrySet().removeIf((entry) -> {
            if (!BotManager.isTrackedBotName((String)entry.getKey())) {
               return true;
            } else {
               ServerPlayer bot = server.getPlayerList().getPlayerByName((String)entry.getKey());
               if (bot == null) {
                  return false;
               } else if (!(bot instanceof BotPlayer)) {
                  VexBot.LOGGER.warn("[VexBot] botdontleave: '{}' is a real player, not a bot — discarding the saved gear instead of overwriting them.", entry.getKey());
                  return true;
               } else {
                  JsonObject o = (JsonObject)entry.getValue();
                  Inventory inv = bot.getInventory();
                  inv.clearContent();
                  if (o.has("inv")) {
                     JsonObject saved = o.getAsJsonObject("inv");

                     for(String key : saved.keySet()) {
                        int slot = Integer.parseInt(key);
                        if (slot >= 0 && slot < 41) {
                           ItemStack.CODEC.parse(ops, saved.get(key)).result().ifPresent((st) -> inv.setItem(slot, st));
                        }
                     }
                  }

                  if (o.has("ender")) {
                     PlayerEnderChestContainer ec = bot.getEnderChestInventory();
                     JsonObject saved = o.getAsJsonObject("ender");

                     for(String key : saved.keySet()) {
                        int slot = Integer.parseInt(key);
                        if (slot >= 0 && slot < ec.getContainerSize()) {
                           ItemStack.CODEC.parse(ops, saved.get(key)).result().ifPresent((st) -> ec.setItem(slot, st));
                        }
                     }
                  }

                  if (o.has("health")) {
                     float hp = o.get("health").getAsFloat();
                     if (hp > 0.0F) {
                        bot.setHealth(Math.min(hp, bot.getMaxHealth()));
                     }
                  }

                  VexBot.LOGGER.info("[VexBot] botdontleave: restored '{}'", entry.getKey());
                  return true;
               }
            }
         });
      }
   }
}
