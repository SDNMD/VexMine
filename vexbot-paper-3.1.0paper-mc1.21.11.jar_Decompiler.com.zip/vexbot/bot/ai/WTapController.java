package vexbot.bot.ai;

public final class WTapController {
   private static final float STOP_SPRINT_AT = 0.85F;
   public static final float ATTACK_AT = 0.95F;
   public static final float SHIELD_DISABLE_ATTACK_AT = 0.6F;
   private boolean sprintStopped = false;

   public boolean shouldStopSprint(float chargeProgress) {
      if (chargeProgress < 0.15F) {
         this.sprintStopped = false;
      }

      if (!this.sprintStopped && chargeProgress >= 0.85F) {
         this.sprintStopped = true;
      }

      return this.sprintStopped;
   }

   public void onAttack() {
      this.sprintStopped = false;
   }

   public static boolean canAttack(float chargeProgress) {
      return chargeProgress >= 0.95F;
   }
}
