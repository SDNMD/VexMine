package vexbot.bot.ai;

import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.PiercingWeapon;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;
import vexbot.util.EnchantmentUtils;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.SwapEngine;

public final class SwapTechniques {
   private static final int CD_SWAP = 60;
   private static final int CD_LAUNCH = 80;
   private static final int CD_DETAP = 100;
   private static final int CD_BREACH = 60;
   private final ServerPlayer bot;
   private int cdMaceSwap;
   private int cdSpearMaceSwap;
   private int cdSwordWb;
   private int cdBreach;
   private int cdReach;
   private int cdDetapSpear;
   private int cdDetapBreach;
   private int detapStep = 0;
   private long detapDue = -1L;
   private LivingEntity detapTarget;
   private int detapPrevSlot = -1;
   private boolean launchedThisTick = false;

   public SwapTechniques(ServerPlayer bot) {
      this.bot = bot;
   }

   public boolean consumeLaunchFlag() {
      boolean f = this.launchedThisTick;
      this.launchedThisTick = false;
      return f;
   }

   public void tickCooldowns() {
      if (this.cdMaceSwap > 0) {
         --this.cdMaceSwap;
      }

      if (this.cdSpearMaceSwap > 0) {
         --this.cdSpearMaceSwap;
      }

      if (this.cdSwordWb > 0) {
         --this.cdSwordWb;
      }

      if (this.cdBreach > 0) {
         --this.cdBreach;
      }

      if (this.cdReach > 0) {
         --this.cdReach;
      }

      if (this.cdDetapSpear > 0) {
         --this.cdDetapSpear;
      }

      if (this.cdDetapBreach > 0) {
         --this.cdDetapBreach;
      }

   }

   public boolean isExecuting() {
      return this.detapStep > 0;
   }

   public void reset() {
      if (this.detapStep > 0 && this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      if (this.detapStep > 0 && this.detapPrevSlot >= 0) {
         InventoryUtils.select(this.bot.getInventory(), this.detapPrevSlot);
         EquipmentSync.syncNow(this.bot);
      }

      this.detapStep = 0;
      this.detapDue = -1L;
      this.detapTarget = null;
      this.detapPrevSlot = -1;
   }

   public boolean maybeSwapAttack(LivingEntity target, double dist, EffectiveSettings effs) {
      this.launchedThisTick = false;
      this.tickCooldowns();
      if (this.detapStep > 0) {
         return this.driveDetap();
      } else if (target != null && target.isAlive()) {
         TechniqueConfig cfg = effs.techniques();
         long now = this.bot.level().getGameTime();
         boolean falling = this.bot.fallDistance > (double)1.5F && !this.bot.isFallFlying();
         float charge = this.bot.getAttackStrengthScale(0.0F);
         if (cfg.detapSpearMace && this.cdDetapSpear <= 0 && target.getHealth() <= 8.0F && dist >= 2.2 && dist <= (double)4.0F && this.findSpear() >= 0 && this.findMace(false) >= 0) {
            this.detapStep = 1;
            this.detapDue = now;
            this.detapTarget = target;
            this.detapPrevSlot = InventoryUtils.selected(this.bot.getInventory());
            this.cdDetapSpear = 100;
            return this.driveDetap();
         } else if (cfg.detapBreach && this.cdDetapBreach <= 0 && target.getHealth() <= 8.0F && dist <= (double)3.0F && McCompat.invulnerableTime(target) <= 10 && this.findMace(true) >= 0) {
            SwapEngine.syncedAttack(this.bot, this.findMace(true), target);
            this.restore();
            this.cdDetapBreach = 60;
            return true;
         } else if (charge <= 0.9F) {
            return false;
         } else {
            int swordSlot = this.findSword();
            if (cfg.breachSwap && this.cdBreach <= 0 && swordSlot >= 0 && dist <= (double)3.0F && target.getArmorValue() >= 10) {
               int m = this.findMace(true);
               if (m >= 0 && this.heldIsSynced(swordSlot)) {
                  SwapEngine.staleSwapAttack(this.bot, m, target);
                  this.restoreTo(swordSlot);
                  this.cdBreach = 60;
                  return true;
               }
            }

            if (cfg.swordWbSwap && this.cdSwordWb <= 0 && swordSlot >= 0 && falling && dist <= (double)3.0F) {
               int m = this.findWindBurstMace();
               if (m >= 0 && this.heldIsSynced(swordSlot)) {
                  SwapEngine.staleSwapAttack(this.bot, m, target);
                  this.restoreTo(swordSlot);
                  this.cdSwordWb = 80;
                  this.launchedThisTick = true;
                  return true;
               }
            }

            if (cfg.spearMaceSwap && this.cdSpearMaceSwap <= 0 && falling && dist <= (double)4.0F) {
               int sp = this.findSpear();
               int m = this.findMace(false);
               if (sp >= 0 && m >= 0 && this.heldIsSynced(sp)) {
                  SwapEngine.staleSwapAttack(this.bot, m, target);
                  this.restoreTo(sp);
                  this.cdSpearMaceSwap = 60;
                  return true;
               }
            }

            if (cfg.maceSwap && this.cdMaceSwap <= 0 && dist <= (double)3.0F) {
               int m = this.findMace(false);
               if (m >= 0 && (falling || target.getArmorValue() < 10)) {
                  int wc = this.findWindCharge();
                  int pre = wc >= 0 && this.heldIsSynced(wc) ? wc : (swordSlot >= 0 && this.heldIsSynced(swordSlot) ? swordSlot : -1);
                  if (pre >= 0) {
                     SwapEngine.staleSwapAttack(this.bot, m, target);
                     this.restoreTo(pre);
                     this.cdMaceSwap = 60;
                     return true;
                  }
               }
            }

            if (cfg.spearReachSwap && this.cdReach <= 0 && swordSlot >= 0 && dist > (double)3.0F && dist <= 4.3 && McCompat.invulnerableTime(target) <= 10) {
               int sp = this.findSpear();
               if (sp >= 0 && this.heldIsSynced(sp)) {
                  SwapEngine.syncedAttack(this.bot, swordSlot, target);
                  this.restoreTo(sp);
                  this.cdReach = 60;
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private boolean driveDetap() {
      long now = this.bot.level().getGameTime();
      if (this.detapTarget != null && this.detapTarget.isAlive()) {
         if (now > this.detapDue + 5L) {
            this.reset();
            return false;
         } else if (now < this.detapDue) {
            return true;
         } else {
            int spear = this.findSpear();
            int mace = this.findMace(false);
            boolean inReach = (double)this.bot.distanceTo(this.detapTarget) <= (double)3.0F && this.bot.hasLineOfSight(this.detapTarget);
            switch (this.detapStep) {
               case 1:
                  if (spear < 0) {
                     this.reset();
                     return false;
                  }

                  InventoryUtils.select(this.bot.getInventory(), spear);
                  EquipmentSync.syncNow(this.bot);
                  SwapEngine.useDown(this.bot, InteractionHand.MAIN_HAND);
                  this.detapStep = 2;
                  this.detapDue = now + 1L;
                  return true;
               case 2:
                  ItemStack held = this.bot.getMainHandItem();
                  PiercingWeapon pw = (PiercingWeapon)held.get(DataComponents.PIERCING_WEAPON);
                  if (pw != null && this.bot.isUsingItem()) {
                     pw.attack(this.bot, EquipmentSlot.MAINHAND);
                  }

                  this.detapStep = 3;
                  this.detapDue = now + 1L;
                  return true;
               case 3:
                  SwapEngine.useUp(this.bot);
                  this.detapStep = this.bot.fallDistance > (double)1.5F && !this.bot.isFallFlying() ? 4 : 5;
                  this.detapDue = now + (long)(this.detapStep == 4 ? 1 : 10);
                  return true;
               case 4:
                  if (mace >= 0 && inReach) {
                     SwapEngine.syncedAttack(this.bot, mace, this.detapTarget);
                  }

                  this.restore();
                  this.reset();
                  return true;
               default:
                  int sword = this.findSword();
                  if (sword >= 0 && inReach) {
                     SwapEngine.syncedAttack(this.bot, sword, this.detapTarget);
                  }

                  this.restore();
                  this.reset();
                  return true;
            }
         }
      } else {
         this.reset();
         return false;
      }
   }

   private void restore() {
      this.restoreTo(this.detapPrevSlot >= 0 ? this.detapPrevSlot : this.findSword());
   }

   private void restoreTo(int slot) {
      if (slot >= 0 && slot <= 8) {
         InventoryUtils.select(this.bot.getInventory(), slot);
         EquipmentSync.syncNow(this.bot);
      }
   }

   private boolean heldIsSynced(int slot) {
      return InventoryUtils.selected(this.bot.getInventory()) == slot;
   }

   private int findSword() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.SWORDS)) {
            return i;
         }
      }

      return -1;
   }

   private int findSpear() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (!s.isEmpty() && s.get(DataComponents.PIERCING_WEAPON) != null) {
            return i;
         }
      }

      return -1;
   }

   private int findMace(boolean preferBreach) {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      int bestLvl = -1;

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.MACE)) {
            int lvl = EnchantmentUtils.getEnchantLevel(s, "breach");
            if (preferBreach) {
               if (lvl > bestLvl) {
                  bestLvl = lvl;
                  best = i;
               }
            } else if (best < 0) {
               best = i;
            }
         }
      }

      return preferBreach && bestLvl < 1 ? -1 : best;
   }

   private int findWindCharge() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.WIND_CHARGE)) {
            return i;
         }
      }

      return -1;
   }

   private int findWindBurstMace() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.MACE) && EnchantmentUtils.getEnchantLevel(s, "wind_burst") >= 1) {
            return i;
         }
      }

      return -1;
   }
}
