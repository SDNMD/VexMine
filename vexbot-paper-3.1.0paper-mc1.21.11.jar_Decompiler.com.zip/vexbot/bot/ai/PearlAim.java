package vexbot.bot.ai;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

final class PearlAim {
   private static final double SPEED = (double)1.5F;
   private static final double GRAVITY = 0.03;
   private static final double DRAG = 0.99;
   private static final int MAX_TICKS = 120;
   private static final double LAND_SLACK = 1.6;

   private PearlAim() {
   }

   static Shot solve(ServerPlayer bot, Vec3 aim) {
      Vec3 start = new Vec3(bot.getX(), bot.getEyeY() - 0.1, bot.getZ());
      Vec3 known = bot.getKnownMovement();
      Vec3 carry = new Vec3(known.x, bot.onGround() ? (double)0.0F : known.y, known.z);
      double dx = aim.x - start.x;
      double dz = aim.z - start.z;
      double dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < 0.3) {
         return null;
      } else {
         double ux = dx / dist;
         double uz = dz / dist;
         double along = carry.x * ux + carry.z * uz;
         double sideX = carry.x - along * ux;
         double sideZ = carry.z - along * uz;
         double side = Math.sqrt(sideX * sideX + sideZ * sideZ);
         double prevPitch = Double.NaN;
         double prevMiss = Double.NaN;
         List<Double> roots = new ArrayList();

         for(double p = (double)-89.0F; p <= (double)89.0F; ++p) {
            double miss = missAt(p, dist, aim.y - start.y, side, along, carry.y);
            if (!Double.isNaN(miss) && !Double.isNaN(prevMiss) && Math.signum(miss) != Math.signum(prevMiss)) {
               roots.add(refine(prevPitch, p, dist, aim.y - start.y, side, along, carry.y));
            }

            prevPitch = p;
            prevMiss = miss;
         }

         roots.sort(Comparator.reverseOrder());

         for(double pitch : roots) {
            double cosP = Math.cos(Math.toRadians(pitch));
            double h = (double)1.5F * cosP;
            double a = h * h - side * side;
            if (!(a < (double)0.0F)) {
               double vx = ux * Math.sqrt(a) - sideX;
               double vz = uz * Math.sqrt(a) - sideZ;
               float yaw = (float)Math.toDegrees(Math.atan2(-vx, vz));
               Vec3 v0 = (new Vec3(-Math.sin(Math.toRadians((double)yaw)) * cosP, -Math.sin(Math.toRadians(pitch)), Math.cos(Math.toRadians((double)yaw)) * cosP)).scale((double)1.5F).add(carry);
               Shot shot = replay(bot.level(), bot, start, v0, aim, dist, yaw, (float)pitch);
               if (shot != null) {
                  return shot;
               }
            }
         }

         return null;
      }
   }

   static Vec3 landing(ServerPlayer bot, float yaw, float pitch) {
      Vec3 start = new Vec3(bot.getX(), bot.getEyeY() - 0.1, bot.getZ());
      Vec3 known = bot.getKnownMovement();
      double cosP = Math.cos(Math.toRadians((double)pitch));
      Vec3 v = (new Vec3(-Math.sin(Math.toRadians((double)yaw)) * cosP, -Math.sin(Math.toRadians((double)pitch)), Math.cos(Math.toRadians((double)yaw)) * cosP)).scale((double)1.5F).add(known.x, bot.onGround() ? (double)0.0F : known.y, known.z);
      Vec3 pos = start;
      Level level = bot.level();

      for(int t = 0; t < 120; ++t) {
         v = new Vec3(v.x * 0.99, (v.y - 0.03) * 0.99, v.z * 0.99);
         Vec3 next = pos.add(v);
         BlockHitResult hit = level.clip(new ClipContext(pos, next, Block.COLLIDER, Fluid.NONE, bot));
         if (hit.getType() != Type.MISS) {
            return hit.getLocation();
         }

         if (next.y < (double)level.getMinY()) {
            return null;
         }

         pos = next;
      }

      return null;
   }

   private static double missAt(double pitch, double dist, double dy, double side, double along, double carryY) {
      double cosP = Math.cos(Math.toRadians(pitch));
      double h = (double)1.5F * cosP;
      double a = h * h - side * side;
      if (a < (double)0.0F) {
         return Double.NaN;
      } else {
         double vh = Math.sqrt(a) + along;
         if (vh <= 1.0E-4) {
            return Double.NaN;
         } else {
            double vy = (double)-1.5F * Math.sin(Math.toRadians(pitch)) + carryY;
            double x = (double)0.0F;
            double y = (double)0.0F;

            for(int t = 0; t < 120; ++t) {
               vy = (vy - 0.03) * 0.99;
               vh *= 0.99;
               double nx = x + vh;
               double ny = y + vy;
               if (nx >= dist) {
                  double f = (dist - x) / (nx - x);
                  return y + (ny - y) * f - dy;
               }

               x = nx;
               y = ny;
               if (ny - dy < (double)-64.0F) {
                  return Double.NaN;
               }
            }

            return Double.NaN;
         }
      }
   }

   private static double refine(double lo, double hi, double dist, double dy, double side, double along, double carryY) {
      double mlo = missAt(lo, dist, dy, side, along, carryY);

      for(int i = 0; i < 24; ++i) {
         double mid = (lo + hi) / (double)2.0F;
         double m = missAt(mid, dist, dy, side, along, carryY);
         if (Double.isNaN(m)) {
            break;
         }

         if (Math.signum(m) == Math.signum(mlo)) {
            lo = mid;
            mlo = m;
         } else {
            hi = mid;
         }
      }

      return (lo + hi) / (double)2.0F;
   }

   private static Shot replay(Level level, ServerPlayer bot, Vec3 start, Vec3 v0, Vec3 aim, double dist, float yaw, float pitch) {
      Vec3 pos = start;
      Vec3 v = v0;

      for(int t = 1; t <= 120; ++t) {
         v = new Vec3(v.x * 0.99, (v.y - 0.03) * 0.99, v.z * 0.99);
         Vec3 next = pos.add(v);
         BlockHitResult hit = level.clip(new ClipContext(pos, next, Block.COLLIDER, Fluid.NONE, bot));
         if (hit.getType() != Type.MISS) {
            Vec3 at = hit.getLocation();
            double hx = at.x - aim.x;
            double hz = at.z - aim.z;
            if (Math.sqrt(hx * hx + hz * hz) <= 1.6 && Math.abs(at.y - aim.y) <= (double)2.5F) {
               return new Shot(yaw, pitch, t, at);
            }

            return null;
         }

         double sx = next.x - start.x;
         double sz = next.z - start.z;
         if (sx * sx + sz * sz >= dist * dist) {
            return new Shot(yaw, pitch, t, next);
         }

         pos = next;
      }

      return null;
   }

   static record Shot(float yaw, float pitch, int ticks, Vec3 landing) {
   }
}
