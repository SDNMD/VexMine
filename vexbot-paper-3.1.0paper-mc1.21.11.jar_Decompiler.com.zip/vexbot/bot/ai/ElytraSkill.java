package vexbot.bot.ai;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.level.ServerPlayer;
import vexbot.EffectiveSettings;

final class ElytraSkill {
   private static final double[] SKIP_LAUNCH = new double[]{(double)0.5F, 0.32, (double)0.25F, 0.08, (double)0.0F};
   private static final int[] HESITATE_TICKS = new int[]{70, 55, 45, 30, 0};
   private static final double[] STEER = new double[]{0.35, 0.55, 0.65, 0.85, (double)1.0F};
   private static final double[] DIVE_ERROR = new double[]{1.9, 1.35, (double)1.0F, 0.45, (double)0.0F};
   private static final double[] WHIFF = new double[]{0.28, 0.17, 0.12, 0.04, (double)0.0F};
   private static final double[] CHAIN_CONTINUE = new double[]{(double)0.25F, 0.45, 0.6, 0.85, (double)1.0F};

   private ElytraSkill() {
   }

   static int level(ServerPlayer bot) {
      int lvl = EffectiveSettings.of(bot.getScoreboardName()).difficultyParams().elytraMaceLevel;
      return Math.max(1, Math.min(5, lvl));
   }

   private static double roll() {
      return ThreadLocalRandom.current().nextDouble();
   }

   static boolean skipLaunch(ServerPlayer bot) {
      return roll() < SKIP_LAUNCH[level(bot) - 1];
   }

   static int hesitateTicks(ServerPlayer bot) {
      return HESITATE_TICKS[level(bot) - 1];
   }

   static double steer(ServerPlayer bot) {
      return STEER[level(bot) - 1];
   }

   static double[] diveOffset(ServerPlayer bot) {
      double max = DIVE_ERROR[level(bot) - 1];
      if (max <= (double)0.0F) {
         return new double[]{(double)0.0F, (double)0.0F};
      } else {
         double a = roll() * Math.PI * (double)2.0F;
         double r = max * (0.4 + 0.6 * roll());
         return new double[]{Math.cos(a) * r, Math.sin(a) * r};
      }
   }

   static boolean whiff(ServerPlayer bot) {
      return roll() < WHIFF[level(bot) - 1];
   }

   static boolean continueChain(ServerPlayer bot) {
      return roll() < CHAIN_CONTINUE[level(bot) - 1];
   }
}
