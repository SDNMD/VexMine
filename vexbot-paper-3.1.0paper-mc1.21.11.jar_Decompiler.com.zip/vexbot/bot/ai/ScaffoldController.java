package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

public final class ScaffoldController {
   private static final double TOWER_MIN_DY = (double)4.0F;
   private static final double LAUNCH_VY = 0.7;
   private static final double START_MAX_HORIZ = (double)8.0F;
   private static final double DONE_DY = (double)0.5F;
   private static final double BRIDGE_DONE_HORIZ = (double)3.0F;
   private static final float GOD_PITCH = 73.0F;
   private static final float MOONWALK_PITCH = 70.0F;
   private static final float MOONWALK_YAW_OFF = 50.0F;
   private static final double EARLY_PLACE_FRAC = 0.55;
   private static final int GOD_RESET_EVERY = 8;
   private static final int MOONWALK_RESET_EVERY = 10;
   private int blocksSincePlaceReset = 0;
   private static final double EDGE_PLACE_FRAC = 0.45;
   private static final int STUCK_TICKS = 80;
   private static final int ABORT_COOLDOWN = 100;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private boolean active = false;
   private Mode mode;
   private boolean targetLaunched;
   private BlockPos supportPos;
   private double bestY;
   private double bestHoriz;
   private int ticksWithoutProgress;
   private int placeCooldown;
   private int cooldown;

   private double towerMinDy() {
      return EffectiveSettings.of(this.bot.getScoreboardName()).buildUpMinHeight();
   }

   public ScaffoldController(ServerPlayer bot, MinecraftServer server) {
      this.mode = ScaffoldController.Mode.TOWER;
      this.targetLaunched = false;
      this.supportPos = null;
      this.bestY = Double.NEGATIVE_INFINITY;
      this.bestHoriz = Double.POSITIVE_INFINITY;
      this.ticksWithoutProgress = 0;
      this.placeCooldown = 0;
      this.cooldown = 0;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isActive() {
      return this.active;
   }

   public void reset() {
      if (this.active) {
         this.bot.setShiftKeyDown(false);
         BotCommands.stopMoving(this.server, this.botName);
      }

      this.active = false;
      this.supportPos = null;
      this.bestY = Double.NEGATIVE_INFINITY;
      this.bestHoriz = Double.POSITIVE_INFINITY;
      this.ticksWithoutProgress = 0;
      this.placeCooldown = 0;
      this.targetLaunched = false;
   }

   public boolean tick(LivingEntity target) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.placeCooldown > 0) {
         --this.placeCooldown;
      }

      if (target != null && target.isAlive()) {
         double dy = target.getY() - this.bot.getY();
         double horiz = Math.hypot(target.getX() - this.bot.getX(), target.getZ() - this.bot.getZ());
         if (target.getDeltaMovement().y > 0.7 && !target.isFallFlying()) {
            this.targetLaunched = true;
         }

         if (dy < this.towerMinDy()) {
            this.targetLaunched = false;
         }

         if (!this.active) {
            if (this.cooldown > 0 || this.findBlock() == null) {
               return false;
            }

            if (dy >= this.towerMinDy() && horiz <= (double)8.0F && !this.targetLaunched) {
               this.mode = ScaffoldController.Mode.TOWER;
            } else {
               if (!(dy >= (double)-1.5F) || !(dy < this.towerMinDy()) || !(horiz > (double)3.0F) || !(horiz <= (double)8.0F) || !this.bot.onGround() || !this.gapTowards(target)) {
                  return false;
               }

               this.mode = ScaffoldController.Mode.BRIDGE;
            }

            this.active = true;
            this.supportPos = null;
            this.bestY = this.bot.getY();
            this.bestHoriz = horiz;
            this.ticksWithoutProgress = 0;
         }

         if (this.findBlock() != null && !(horiz > (double)14.0F)) {
            if (this.mode == ScaffoldController.Mode.BRIDGE && dy >= this.towerMinDy()) {
               this.mode = ScaffoldController.Mode.TOWER;
               this.supportPos = null;
               this.bestY = this.bot.getY();
               this.ticksWithoutProgress = 0;
            } else if (this.mode == ScaffoldController.Mode.TOWER && dy <= (double)0.5F && this.bot.onGround()) {
               if (horiz <= (double)3.0F) {
                  this.reset();
                  return false;
               }

               this.mode = ScaffoldController.Mode.BRIDGE;
               this.bot.setShiftKeyDown(false);
               this.bestHoriz = horiz;
               this.ticksWithoutProgress = 0;
            }

            return this.mode == ScaffoldController.Mode.TOWER ? this.tickTower() : this.tickBridge(target, horiz);
         } else {
            this.abort();
            return false;
         }
      } else {
         this.reset();
         return false;
      }
   }

   private boolean tickTower() {
      BlockSlot blocks = this.findBlock();
      if (this.bot.getY() > this.bestY + (double)0.5F) {
         this.bestY = this.bot.getY();
         this.ticksWithoutProgress = 0;
      } else if (++this.ticksWithoutProgress > 80) {
         this.abort();
         return false;
      }

      BotCommands.stopMoving(this.server, this.botName);
      BotCommands.setSprinting(this.server, this.botName, false);
      this.bot.setXRot(90.0F);
      this.bot.yHeadRot = this.bot.getYRot();
      this.holdBlock(blocks);
      Vec3 vel = this.bot.getDeltaMovement();
      this.bot.setDeltaMovement(vel.x * 0.4, vel.y, vel.z * 0.4);
      if (this.bot.onGround()) {
         this.supportPos = this.bot.blockPosition().below();
         BotCommands.jumpOnce(this.server, this.botName);
         return true;
      } else {
         if (this.supportPos != null && this.bot.getY() >= (double)this.supportPos.getY() + (double)2.0F) {
            BlockPos placePos = this.supportPos.above();
            ServerLevel level = this.bot.level();
            if (level.getBlockState(placePos).canBeReplaced() && !level.getBlockState(this.supportPos).isAir()) {
               Vec3 hitVec = Vec3.atCenterOf(this.supportPos).add((double)0.0F, (double)0.5F, (double)0.0F);
               BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, this.supportPos, false);
               this.bot.gameMode.useItemOn(this.bot, level, blocks.stack(this.bot), blocks.hand, hit);
               McCompat.swing(this.bot, blocks.hand);
               this.supportPos = null;
            }
         }

         return true;
      }
   }

   private boolean tickBridge(LivingEntity target, double horiz) {
      if (horiz <= (double)3.0F) {
         this.reset();
         return false;
      } else {
         BlockSlot blocks = this.findBlock();
         if (horiz < this.bestHoriz - (double)0.25F) {
            this.bestHoriz = horiz;
            this.ticksWithoutProgress = 0;
         } else if (++this.ticksWithoutProgress > 80) {
            this.abort();
            return false;
         }

         double tx = target.getX() - this.bot.getX();
         double tz = target.getZ() - this.bot.getZ();
         BotSettings.BridgeMode mode = EffectiveSettings.of(this.botName).bridgeMode();
         float awayYaw = (float)Math.toDegrees(Math.atan2(tx, -tz));
         float towardYaw = awayYaw + 180.0F;
         this.holdBlock(blocks);
         switch (mode) {
            case GOD:
               this.bot.setYRot(towardYaw);
               this.bot.yHeadRot = towardYaw;
               this.bot.setXRot(73.0F);
               BotCommands.setSprinting(this.server, this.botName, true);
               BotCommands.setMovement(this.server, this.botName, 0.9F, 0.0F);
               break;
            case MOONWALK:
               float sideYaw = towardYaw + 50.0F;
               this.bot.setYRot(sideYaw);
               this.bot.yHeadRot = sideYaw;
               this.bot.setXRot(70.0F);
               BotCommands.setSprinting(this.server, this.botName, false);
               BotCommands.setMovement(this.server, this.botName, 0.55F, 0.75F);
               break;
            default:
               this.bot.setYRot(awayYaw);
               this.bot.yHeadRot = awayYaw;
               this.bot.setXRot(76.0F);
               BotCommands.setSprinting(this.server, this.botName, false);
               BotCommands.setMovement(this.server, this.botName, -0.8F, 0.0F);
         }

         if (!this.bot.onGround()) {
            return true;
         } else {
            BlockPos support = this.bot.getOnPos();
            ServerLevel level = this.bot.level();
            if (level.getBlockState(support).isAir()) {
               return true;
            } else {
               Direction step = Math.abs(tx) >= Math.abs(tz) ? (tx > (double)0.0F ? Direction.EAST : Direction.WEST) : (tz > (double)0.0F ? Direction.SOUTH : Direction.NORTH);
               BlockPos next = support.relative(step);
               if (level.getBlockState(next).canBeReplaced()) {
                  boolean crouchBridge = mode == BotSettings.BridgeMode.NINJA;
                  this.bot.setShiftKeyDown(crouchBridge);
                  double var10000;
                  switch (step) {
                     case NORTH -> var10000 = this.bot.getZ() - (double)support.getZ();
                     case SOUTH -> var10000 = (double)(support.getZ() + 1) - this.bot.getZ();
                     case WEST -> var10000 = this.bot.getX() - (double)support.getX();
                     default -> var10000 = (double)(support.getX() + 1) - this.bot.getX();
                  }

                  double toEdge = var10000;
                  double placeFrac = crouchBridge ? 0.45 : 0.55;
                  if (toEdge <= placeFrac && this.placeCooldown == 0) {
                     Vec3 hitVec = Vec3.atCenterOf(support).add((double)step.getStepX() * (double)0.5F, (double)0.0F, (double)step.getStepZ() * (double)0.5F);
                     BlockHitResult hit = new BlockHitResult(hitVec, step, support, false);
                     this.bot.gameMode.useItemOn(this.bot, level, blocks.stack(this.bot), blocks.hand, hit);
                     McCompat.swing(this.bot, blocks.hand);
                     this.placeCooldown = crouchBridge ? 3 : 2;
                     int resetEvery = mode == BotSettings.BridgeMode.GOD ? 8 : (mode == BotSettings.BridgeMode.MOONWALK ? 10 : 0);
                     if (resetEvery > 0 && ++this.blocksSincePlaceReset >= resetEvery) {
                        this.blocksSincePlaceReset = 0;
                        if (this.bot.onGround()) {
                           BotCommands.jumpOnce(this.server, this.botName);
                        }
                     }
                  }
               } else {
                  this.bot.setShiftKeyDown(false);
               }

               return true;
            }
         }
      }
   }

   private boolean gapTowards(LivingEntity target) {
      double tx = target.getX() - this.bot.getX();
      double tz = target.getZ() - this.bot.getZ();
      Direction step = Math.abs(tx) >= Math.abs(tz) ? (tx > (double)0.0F ? Direction.EAST : Direction.WEST) : (tz > (double)0.0F ? Direction.SOUTH : Direction.NORTH);
      BlockPos next = this.bot.getOnPos().relative(step);
      ServerLevel level = this.bot.level();
      return level.getBlockState(next).canBeReplaced() && level.getBlockState(next.below()).canBeReplaced();
   }

   private void abort() {
      this.blocksSincePlaceReset = 0;
      this.reset();
      this.cooldown = 100;
   }

   private BlockSlot findBlock() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (isPillarBlock(inv.getItem(i))) {
            return new BlockSlot(i, InteractionHand.MAIN_HAND);
         }
      }

      if (isPillarBlock(this.bot.getOffhandItem())) {
         return new BlockSlot(40, InteractionHand.OFF_HAND);
      } else {
         return null;
      }
   }

   static boolean isPillarBlock(ItemStack stack) {
      if (!stack.isEmpty()) {
         Item var2 = stack.getItem();
         if (var2 instanceof BlockItem) {
            BlockItem bi = (BlockItem)var2;
            Block block = bi.getBlock();
            if (block instanceof EntityBlock) {
               return false;
            }

            if (block instanceof FallingBlock) {
               return false;
            }

            if (block != Blocks.CACTUS && block != Blocks.MAGMA_BLOCK && block != Blocks.TNT && block != Blocks.SLIME_BLOCK && block != Blocks.HONEY_BLOCK) {
               return McCompat.blocksMotion(block.defaultBlockState());
            }

            return false;
         }
      }

      return false;
   }

   private void holdBlock(BlockSlot blocks) {
      if (blocks.hand != InteractionHand.OFF_HAND) {
         Inventory inv = this.bot.getInventory();
         int slot = InventoryUtils.moveToHotbarSafe(inv, blocks.slot);
         InventoryUtils.select(inv, slot);
      }
   }

   private static enum Mode {
      TOWER,
      BRIDGE;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{TOWER, BRIDGE};
      }
   }

   private static record BlockSlot(int slot, InteractionHand hand) {
      ItemStack stack(ServerPlayer bot) {
         return this.hand == InteractionHand.OFF_HAND ? bot.getOffhandItem() : bot.getMainHandItem();
      }
   }
}
