package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.LedgeGuard;
import vexbot.util.VexLog;

public final class HealingController {
   private static final float LOW_HP = 10.0F;
   private static final float SAFE_HP = 14.0F;
   private static final int HUNGER_EAT_THRESHOLD = 10;
   private static final int STARVING_LEVEL = 6;
   private static final int HUNGER_FULL_THRESHOLD = 16;
   private boolean shieldBroken = false;
   private static final double RETREAT_SAFE_DIST = (double)12.0F;
   private static final int FORCE_CONSUME_TICKS = 40;
   private static final int EAT_TIMEOUT = 80;
   private static final int EAT_COOLDOWN_TICKS = 20;
   private static final int MAX_HEAL_TICKS = 400;
   private static final Random RNG = new Random();
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private boolean isHealing = false;
   private boolean hungerOnlyHeal = false;
   private boolean oneGapMode = false;
   private boolean retreatEnabled = false;
   private int healTicks = 0;
   private int eatingSlot = -1;
   private int eatingTicks = 0;
   private int eatingStartCount = 0;
   private int reentryCd = 0;
   private boolean forceConsumed = false;
   private int eatCooldownLeft = 0;
   private boolean syncHealRequested = false;
   private static final int SAFE_DROP = 4;
   private static final double PURSUE_HOLD_DIST = (double)6.0F;
   private static final double PURSUE_FAR_DIST = (double)12.0F;
   private static final int FLEE_CONFIRM_TICKS = 4;
   private int targetFleeingTicks = 0;
   private static final float[] FLEE_OFFSETS = new float[]{0.0F, 25.0F, -25.0F, 50.0F, -50.0F, 75.0F, -75.0F, 105.0F, -105.0F, 135.0F, -135.0F};
   private int gapBuyCooldown = 0;
   private EnderPearlController enderPearl;
   private CobwebTrapController cobwebTrap;

   public void setShieldBroken(boolean v) {
      this.shieldBroken = v;
   }

   private float shieldBrokenBonus() {
      return this.shieldBroken ? 4.0F : 0.0F;
   }

   private float lowHpThreshold() {
      return (float)(EffectiveSettings.of(this.botName).retreatHealthHearts() * (double)2.0F) + this.shieldBrokenBonus();
   }

   private float safeHp() {
      return Math.max(14.0F, this.lowHpThreshold() + 4.0F);
   }

   public HealingController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isHealing() {
      return this.isHealing;
   }

   public void requestSyncHeal() {
      this.syncHealRequested = true;
   }

   public boolean starving() {
      return this.bot.getFoodData().getFoodLevel() <= 6;
   }

   public boolean isRetreating() {
      return this.isHealing;
   }

   public void abortHealing() {
      this.exitHealing();
   }

   public void forceAbortWithLockout(int ticks) {
      this.reentryCd = Math.max(this.reentryCd, ticks);
      this.exitHealing();
   }

   public boolean tick(boolean inCombat, LivingEntity target, boolean crystalling) {
      float hp = this.bot.getHealth();
      int foodLevel = this.bot.getFoodData().getFoodLevel();
      boolean syncReq = this.syncHealRequested;
      this.syncHealRequested = false;
      if (this.gapBuyCooldown > 0) {
         --this.gapBuyCooldown;
      }

      if (crystalling && this.countTotems() >= 1 && !this.starving()) {
         if (this.isHealing) {
            this.exitHealing();
         }

         return false;
      } else {
         if (this.reentryCd > 0) {
            --this.reentryCd;
         }

         if (!this.isHealing) {
            if (this.reentryCd > 0 && hp > 6.0F && !this.starving()) {
               return false;
            }

            float thresholdBoost = 0.0F;
            boolean aheadOnHp = false;
            if (target != null && target.isAlive()) {
               float targetHp = target.getHealth();
               if (hp + 4.0F < targetHp) {
                  thresholdBoost = 2.0F;
               } else if (hp > targetHp + 2.0F) {
                  aheadOnHp = true;
               }
            }

            boolean lowHp = hp <= this.lowHpThreshold() + thresholdBoost;
            boolean lowHunger = foodLevel <= 10;
            boolean sync = syncReq && hp < this.bot.getMaxHealth() - 2.0F;
            if (target != null && target.isAlive() && target.getHealth() <= 4.0F && hp > 6.0F && !lowHunger) {
               return false;
            }

            boolean distanceHeal = !lowHp && !lowHunger && !sync && target != null && target.isAlive() && (double)this.bot.distanceTo(target) >= (double)10.0F && hp <= this.bot.getMaxHealth() - 4.0F;
            if (lowHp || lowHunger || sync || distanceHeal) {
               boolean hungerOnly = lowHunger && !lowHp && !sync;
               int slot = hungerOnly ? this.findBestRegularFood(-1) : this.findBestFood();
               if (hungerOnly && slot < 0) {
                  slot = this.findBestFood();
               }

               if (slot >= 0) {
                  boolean retreat = lowHp && EffectiveSettings.of(this.botName).retreat() && inCombat;
                  this.hungerOnlyHeal = hungerOnly;
                  this.oneGapMode = (aheadOnHp || distanceHeal) && !hungerOnly;
                  boolean flee = retreat && !aheadOnHp && !distanceHeal;
                  if (flee && !EffectiveSettings.of(this.botName).retreatOrdered() && EffectiveSettings.of(this.botName).healingMode() == BotSettings.HealingMode.ADVANCED && target != null && this.buyHealingGap(target)) {
                     flee = false;
                  }

                  this.enterHealing(slot, flee);
               }
            }
         }

         if (!this.isHealing) {
            return false;
         } else {
            label202: {
               ++this.healTicks;
               if (this.hungerOnlyHeal) {
                  if (foodLevel > 10) {
                     break label202;
                  }
               } else if (hp >= this.safeHp()) {
                  break label202;
               }

               if (this.healTicks > 400) {
                  VexBot.LOGGER.warn("[VexBot] '{}' heal timed out.", this.botName);
                  this.reentryCd = 60;
                  this.exitHealing();
                  return false;
               }

               this.tickRetreat(target);
               this.tickEating();
               return this.isHealing;
            }

            this.exitHealing();
            return false;
         }
      }
   }

   public void reset() {
      this.exitHealing();
   }

   private int countTotems() {
      Inventory inv = this.bot.getInventory();
      int count = 0;

      for(int i = 0; i <= 40; ++i) {
         if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
            ++count;
         }
      }

      return count;
   }

   private void tickRetreat(LivingEntity target) {
      if (this.retreatEnabled && target != null) {
         if (this.isTargetFleeing(target)) {
            ++this.targetFleeingTicks;
         } else {
            this.targetFleeingTicks = 0;
         }

         double dist = (double)this.bot.distanceTo(target);
         boolean farAway = dist > (double)12.0F;
         if (!farAway && this.targetFleeingTicks < 4) {
            if (dist >= (double)12.0F) {
               BotCommands.stopMoving(this.server, this.botName);
               this.clearSprint();
            } else {
               this.fleeFrom(target);
            }

         } else {
            if (dist > (double)6.0F) {
               this.pursueToward(target);
            } else {
               BotCommands.stopMoving(this.server, this.botName);
               this.clearSprint();
            }

         }
      } else {
         BotCommands.stopMoving(this.server, this.botName);
         this.clearSprint();
      }
   }

   private boolean isTargetFleeing(LivingEntity target) {
      Vec3 v = target.getDeltaMovement();
      double speed = Math.hypot(v.x, v.z);
      if (speed < 0.08) {
         return false;
      } else {
         double dx = target.getX() - this.bot.getX();
         double dz = target.getZ() - this.bot.getZ();
         double len = Math.hypot(dx, dz);
         if (len < 0.01) {
            return false;
         } else {
            double dot = (v.x * dx + v.z * dz) / (speed * len);
            return dot > (double)0.5F;
         }
      }
   }

   private void pursueToward(LivingEntity target) {
      this.clearSprint();
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      if (LedgeGuard.wouldFallDangerously(this.bot, dx, dz, 4)) {
         BotCommands.stopMoving(this.server, this.botName);
      } else {
         this.maybeStepJump(yaw);
         BotCommands.moveForward(this.server, this.botName);
      }
   }

   private void fleeFrom(LivingEntity threat) {
      this.clearSprint();
      double awayX = this.bot.getX() - threat.getX();
      double awayZ = this.bot.getZ() - threat.getZ();
      float idealYaw = (float)Math.toDegrees(Math.atan2(-awayX, awayZ));
      float chosenYaw = idealYaw;
      boolean foundOpen = false;

      for(float off : FLEE_OFFSETS) {
         float yaw = idealYaw + off;
         if (this.isDirectionOpen(yaw)) {
            chosenYaw = yaw;
            foundOpen = true;
            break;
         }
      }

      this.bot.setYRot(chosenYaw);
      this.bot.yHeadRot = chosenYaw;
      if (!foundOpen) {
         if (this.bot.onGround()) {
            BotCommands.jumpOnce(this.server, this.botName);
         }

         BotCommands.stopMoving(this.server, this.botName);
      } else {
         this.maybeStepJump(chosenYaw);
         BotCommands.moveForward(this.server, this.botName);
      }
   }

   private boolean isDirectionOpen(float yaw) {
      double rad = Math.toRadians((double)yaw);
      double dx = -Math.sin(rad);
      double dz = Math.cos(rad);
      if (LedgeGuard.wouldFallDangerously(this.bot, dx, dz, 4)) {
         return false;
      } else {
         Level level = this.bot.level();
         BlockPos feet = BlockPos.containing(this.bot.getX() + dx, this.bot.getY(), this.bot.getZ() + dz);
         BlockPos head = feet.above();
         BlockPos above = feet.above(2);
         boolean feetBlocked = isSolid(level, feet);
         boolean headBlocked = isSolid(level, head);
         if (!feetBlocked && !headBlocked) {
            return true;
         } else {
            return feetBlocked && !headBlocked && !isSolid(level, above);
         }
      }
   }

   private void maybeStepJump(float yaw) {
      if (this.bot.onGround()) {
         double rad = Math.toRadians((double)yaw);
         double dx = -Math.sin(rad);
         double dz = Math.cos(rad);
         Level level = this.bot.level();
         BlockPos feet = BlockPos.containing(this.bot.getX() + dx, this.bot.getY(), this.bot.getZ() + dz);
         if (isSolid(level, feet) && !isSolid(level, feet.above())) {
            BotCommands.jumpOnce(this.server, this.botName);
         }

      }
   }

   private static boolean isSolid(Level level, BlockPos pos) {
      return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
   }

   private void clearSprint() {
      this.bot.setSprinting(false);
      BotCommands.setSprinting(this.server, this.botName, false);
   }

   private void tickEating() {
      Inventory inv = this.bot.getInventory();
      if (this.eatingSlot >= 0 && this.eatingSlot < 9) {
         InventoryUtils.select(inv, this.eatingSlot);
      }

      ItemStack held = inv.getSelectedItem();
      boolean consumedOne = this.eatingSlot >= 0 && (!isFoodItem(held) || held.getCount() < this.eatingStartCount);
      if (consumedOne) {
         this.playFinishEatSounds();
         this.stopEatAction();
         if (this.oneGapMode) {
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' one-gap heal done — back to pressure.", this.botName);
            this.exitHealing();
         } else {
            float predictedHp = this.predictHpFromEffects();
            if (predictedHp >= this.safeHp()) {
               VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' food consumed, predicted hp={} — re-engaging.", this.botName, predictedHp);
               this.exitHealing();
            } else {
               this.eatCooldownLeft = 20;
            }
         }
      } else if (this.eatCooldownLeft > 0) {
         --this.eatCooldownLeft;
      } else if (this.eatingSlot < 0) {
         int next = this.hungerOnlyHeal ? this.findBestRegularFood(-1) : this.findBestFood();
         if (this.hungerOnlyHeal && next < 0) {
            next = this.findBestFood();
         }

         if (next < 0) {
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' out of food (hp={}).", this.botName, this.bot.getHealth());
            this.reentryCd = 100;
            this.exitHealing();
         } else {
            this.beginEatSlot(next, inv);
         }
      } else {
         ++this.eatingTicks;
         if (this.eatingTicks % 4 == 0 && !held.isEmpty()) {
            ServerLevel sl = this.bot.level();
            if (sl instanceof ServerLevel) {
               ItemStack particleStack = held.copy();
               ItemParticleOption particle = McCompat.itemParticle(particleStack);
               sl.sendParticles(particle, this.bot.getX() + (RNG.nextDouble() - (double)0.5F) * 0.3, this.bot.getEyeY() - 0.15, this.bot.getZ() + (RNG.nextDouble() - (double)0.5F) * 0.3, 3, 0.05, 0.05, 0.05, 0.05);
               float eatVol = 0.5F + (float)(RNG.nextDouble() * (double)0.5F);
               float eatPitch = 0.8F + (float)(RNG.nextDouble() * (double)0.4F);
               sl.playSound((Entity)null, this.bot.getX(), this.bot.getY(), this.bot.getZ(), SoundEvents.GENERIC_EAT, SoundSource.PLAYERS, eatVol, eatPitch);
            }
         }

         if (this.eatingTicks > 80) {
            VexBot.LOGGER.warn("[VexBot] '{}' eat hard-timeout on {}.", this.botName, held.getHoverName().getString());
            int stuck = this.eatingSlot;
            this.stopEatAction();
            int alt = this.findBestFoodExcl(stuck);
            if (alt < 0) {
               this.reentryCd = 60;
               this.exitHealing();
            } else {
               this.beginEatSlot(alt, inv);
            }
         } else if (this.eatingTicks >= 40 && !this.forceConsumed) {
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' force-consuming {} (vanilla didn't eat).", this.botName, held.getHoverName().getString());
            this.forceConsumeFood(held, inv);
            this.forceConsumed = true;
         } else {
            if (!this.bot.isUsingItem()) {
               this.bot.gameMode.useItem(this.bot, this.bot.level(), held, InteractionHand.MAIN_HAND);
            }

            if (!this.bot.isUsingItem()) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
            }

         }
      }
   }

   private void forceConsumeFood(ItemStack food, Inventory inv) {
      FoodProperties fp = (FoodProperties)food.get(DataComponents.FOOD);
      if (fp != null) {
         try {
            food.finishUsingItem(this.bot.level(), this.bot);
         } catch (Exception var5) {
            this.bot.getFoodData().eat(fp);
            food.shrink(1);
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' force-consumed (fallback shrink).", this.botName);
         }

         this.playFinishEatSounds();
         VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' force-consumed food (hp={}, hunger={}).", this.botName, this.bot.getHealth(), this.bot.getFoodData().getFoodLevel());
      }
   }

   private float predictHpFromEffects() {
      float hp = this.bot.getHealth();
      int hunger = this.bot.getFoodData().getFoodLevel();
      float sat = this.bot.getFoodData().getSaturationLevel();
      if (hunger >= 18 && sat > 0.0F) {
         hp += Math.min(sat, this.bot.getMaxHealth() - hp);
      }

      MobEffectInstance regen = this.bot.getEffect(MobEffects.REGENERATION);
      if (regen != null) {
         int ticks = regen.getDuration();
         int amplifier = regen.getAmplifier();
         int interval = Math.max(1, 50 / (amplifier + 1));
         float heals = (float)ticks / (float)interval;
         hp += heals;
      }

      float absorption = this.bot.getAbsorptionAmount();
      hp += absorption;
      return Math.min(this.bot.getMaxHealth() + absorption, hp);
   }

   private float predictHpAfterEating(ItemStack food) {
      float hp = this.bot.getHealth();
      if (food.isEmpty()) {
         return hp;
      } else {
         FoodProperties fp = (FoodProperties)food.get(DataComponents.FOOD);
         if (fp == null) {
            return hp;
         } else {
            int curHunger = this.bot.getFoodData().getFoodLevel();
            float curSat = this.bot.getFoodData().getSaturationLevel();
            int newHunger = Math.min(20, curHunger + fp.nutrition());
            float newSat = Math.min((float)newHunger, curSat + fp.saturation());
            if (newHunger >= 18 && newSat > 0.0F) {
               hp += newSat;
            }

            if (food.is(Items.GOLDEN_APPLE)) {
               hp += 4.0F;
               hp += 4.0F;
            } else if (food.is(Items.ENCHANTED_GOLDEN_APPLE)) {
               hp += 20.0F;
               hp += 8.0F;
            }

            return Math.min(this.bot.getMaxHealth() + 16.0F, hp);
         }
      }
   }

   private void beginEatSlot(int slot, Inventory inv) {
      if (slot >= 9) {
         slot = this.moveToHotbar(slot, inv);
      }

      this.eatingSlot = slot;
      this.eatingTicks = 0;
      this.eatingStartCount = inv.getItem(slot).getCount();
      this.forceConsumed = false;
      InventoryUtils.select(inv, slot);
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      ItemStack food = inv.getSelectedItem();
      this.bot.gameMode.useItem(this.bot, this.bot.level(), food, InteractionHand.MAIN_HAND);
      VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' eating {} (hp={}, hunger={}).", this.botName, inv.getSelectedItem().getHoverName().getString(), this.bot.getHealth(), this.bot.getFoodData().getFoodLevel());
   }

   private void stopEatAction() {
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      this.eatingSlot = -1;
      this.eatingTicks = 0;
      this.forceConsumed = false;
   }

   private void playFinishEatSounds() {
      ServerLevel var2 = this.bot.level();
      if (var2 instanceof ServerLevel) {
         ServerLevel sl = var2;
         double var10 = this.bot.getX();
         double y = this.bot.getY();
         double z = this.bot.getZ();
         float finishPitch = 0.6F + (float)(RNG.nextDouble() * (double)0.8F);
         sl.playSound((Entity)null, var10, y, z, SoundEvents.GENERIC_EAT, SoundSource.NEUTRAL, 1.0F, finishPitch);
         float burpPitch = 0.9F + (float)(RNG.nextDouble() * (double)0.1F);
         sl.playSound((Entity)null, var10, y, z, SoundEvents.PLAYER_BURP, SoundSource.PLAYERS, 0.5F, burpPitch);
      }
   }

   private int findBestFood() {
      return this.findBestFoodExcl(-1);
   }

   private int findBestFoodExcl(int exclude) {
      int ega = this.findItemExcl(Items.ENCHANTED_GOLDEN_APPLE, exclude);
      if (ega >= 0) {
         return ega;
      } else {
         int ga = this.findItemExcl(Items.GOLDEN_APPLE, exclude);
         return ga >= 0 ? ga : this.findBestRegularFood(exclude);
      }
   }

   private int findBestRegularFood(int exclude) {
      Inventory inv = this.bot.getInventory();
      int bestSlot = -1;
      float bestSat = -1.0F;

      for(int pass = 0; pass < 2; ++pass) {
         int from = pass == 0 ? 0 : 9;
         int to = pass == 0 ? 9 : 36;

         for(int i = from; i < to; ++i) {
            if (i != exclude) {
               ItemStack stack = inv.getItem(i);
               if (isFoodItem(stack) && !stack.is(Items.GOLDEN_APPLE) && !stack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
                  FoodProperties fp = (FoodProperties)stack.get(DataComponents.FOOD);
                  if (fp != null && fp.saturation() > bestSat) {
                     bestSat = fp.saturation();
                     bestSlot = i;
                  }
               }
            }
         }

         if (bestSlot >= 0) {
            break;
         }
      }

      return bestSlot;
   }

   private int findItemExcl(Item item, int exclude) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (i != exclude && inv.getItem(i).is(item)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (i != exclude && inv.getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private static boolean isFoodItem(ItemStack stack) {
      return !stack.isEmpty() && stack.get(DataComponents.FOOD) != null;
   }

   public void setGapTools(EnderPearlController pearl, CobwebTrapController web) {
      this.enderPearl = pearl;
      this.cobwebTrap = web;
   }

   private boolean buyHealingGap(LivingEntity target) {
      if (this.gapBuyCooldown > 0) {
         return false;
      } else {
         double dist = (double)this.bot.distanceTo(target);
         if (dist > (double)10.0F) {
            return true;
         } else if (this.enderPearl != null && this.enderPearl.tryThrow(target)) {
            this.gapBuyCooldown = 60;
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' bought a heal gap with a short pearl.", this.botName);
            return true;
         } else if (this.cobwebTrap != null && this.cobwebTrap.tryEmergencyWeb(target)) {
            this.gapBuyCooldown = 60;
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' bought a heal gap with a web.", this.botName);
            return true;
         } else if (dist <= (double)4.0F && this.bot.hasLineOfSight(target)) {
            double dx = target.getX() - this.bot.getX();
            double dz = target.getZ() - this.bot.getZ();
            double dy = target.getY() + (double)target.getBbHeight() * (double)0.5F - this.bot.getEyeY();
            float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
            float pitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
            this.bot.setYRot(yaw);
            this.bot.setXRot(pitch);
            this.bot.yHeadRot = yaw;
            EquipmentSync.syncNow(this.bot);
            this.bot.setSprinting(true);
            this.bot.attack(target);
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            this.gapBuyCooldown = 40;
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' bought a heal gap with a knockback hit.", this.botName);
            return true;
         } else {
            return false;
         }
      }
   }

   private void enterHealing(int foodSlot, boolean retreat) {
      this.isHealing = true;
      this.retreatEnabled = retreat;
      this.healTicks = 0;
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      this.clearSprint();
      this.beginEatSlot(foodSlot, this.bot.getInventory());
      VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' heal start (hp={}, hunger={}, retreat={}).", this.botName, this.bot.getHealth(), this.bot.getFoodData().getFoodLevel(), retreat);
   }

   private void exitHealing() {
      this.oneGapMode = false;
      this.syncHealRequested = false;
      if (this.isHealing) {
         this.stopEatAction();
         this.isHealing = false;
         this.retreatEnabled = false;
         this.healTicks = 0;
         this.eatCooldownLeft = 0;
         this.targetFleeingTicks = 0;
         BotCommands.stopMoving(this.server, this.botName);
         this.clearSprint();
         VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' heal done (hp={}, hunger={}).", this.botName, this.bot.getHealth(), this.bot.getFoodData().getFoodLevel());
      }
   }

   private int moveToHotbar(int slot, Inventory inv) {
      return InventoryUtils.moveToHotbarSafe(inv, slot);
   }
}
