package vexbot.bot.ai;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.EnchantmentUtils;
import vexbot.util.InventoryUtils;
import vexbot.util.LedgeGuard;

public final class MendingController {
   private static final float LOW_DURABILITY_FRACTION = 0.15F;
   private static final float REPAIRED_FRACTION = 0.9F;
   private static final float CRITICAL_FRACTION = 0.08F;
   private static final float THROW_PITCH = 78.0F;
   private static final float THROW_PITCH_STATIONARY = 90.0F;
   private static final int SAFE_WALK_DROP = 2;
   private static final int WINDUP_TICKS = 3;
   private static final int THROW_INTERVAL = 2;
   private int throwCooldown = 0;
   private static final EquipmentSlot[] ARMOR_SLOTS;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private boolean isMending = false;

   public MendingController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean tick(LivingEntity threat) {
      if (!this.needsMending()) {
         this.stopMending();
         return false;
      } else {
         int slot = this.findBottleSlot();
         if (slot < 0) {
            this.stopMending();
            return false;
         } else {
            boolean entering = !this.isMending;
            this.isMending = true;
            Inventory inv = this.bot.getInventory();
            slot = InventoryUtils.moveToHotbarSafe(inv, slot);
            InventoryUtils.select(inv, slot);
            if (threat != null && threat.isAlive()) {
               double ax = this.bot.getX() - threat.getX();
               double az = this.bot.getZ() - threat.getZ();
               if (ax * ax + az * az > 1.0E-4) {
                  this.bot.setYRot((float)Math.toDegrees(Math.atan2(-ax, az)));
               }
            }

            double lookX = -Math.sin(Math.toRadians((double)this.bot.getYRot()));
            double lookZ = Math.cos(Math.toRadians((double)this.bot.getYRot()));
            boolean canAdvance = !LedgeGuard.wouldFallDangerously(this.bot, lookX, lookZ, 2);
            this.bot.setShiftKeyDown(false);
            this.bot.setXRot(canAdvance ? 78.0F : 90.0F);
            this.bot.yHeadRot = this.bot.getYRot();
            if (canAdvance) {
               BotCommands.moveForward(this.server, this.botName);
               BotCommands.setSprinting(this.server, this.botName, false);
            } else {
               BotCommands.stopMoving(this.server, this.botName);
            }

            if (entering) {
               this.throwCooldown = 3;
            }

            if (this.throwCooldown > 0) {
               --this.throwCooldown;
               return true;
            } else {
               if (inv.getItem(slot).is(Items.EXPERIENCE_BOTTLE)) {
                  McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                  this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(slot), InteractionHand.MAIN_HAND);
               }

               this.throwCooldown = 2;
               return true;
            }
         }
      }
   }

   public boolean isMending() {
      return this.isMending;
   }

   public void abortMending() {
      this.stopMending();
   }

   private void stopMending() {
      if (this.isMending) {
         this.bot.setShiftKeyDown(false);
         BotCommands.stopMoving(this.server, this.botName);
      }

      this.isMending = false;
      this.throwCooldown = 0;
   }

   public boolean hasCriticalPiece() {
      for(EquipmentSlot armorSlot : ARMOR_SLOTS) {
         ItemStack piece = this.bot.getItemBySlot(armorSlot);
         if (!piece.isEmpty()) {
            int maxDamage = piece.getMaxDamage();
            if (maxDamage > 0 && EnchantmentUtils.hasEnchantAtLeast(piece, "mending", 1)) {
               int remaining = maxDamage - piece.getDamageValue();
               if ((float)remaining / (float)maxDamage <= 0.08F) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public boolean wantsToMend() {
      return this.needsMending() && this.findBottleSlot() >= 0;
   }

   private boolean needsMending() {
      float threshold = this.isMending ? 0.9F : 0.15F;

      for(EquipmentSlot armorSlot : ARMOR_SLOTS) {
         ItemStack piece = this.bot.getItemBySlot(armorSlot);
         if (!piece.isEmpty()) {
            int maxDamage = piece.getMaxDamage();
            if (maxDamage > 0 && EnchantmentUtils.hasEnchantAtLeast(piece, "mending", 1)) {
               int remaining = maxDamage - piece.getDamageValue();
               if ((float)remaining / (float)maxDamage <= threshold) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private int findBottleSlot() {
      Inventory inv = this.bot.getInventory();

      for(int pass = 0; pass < 2; ++pass) {
         int from = pass == 0 ? 0 : 9;
         int to = pass == 0 ? 9 : 36;

         for(int i = from; i < to; ++i) {
            if (inv.getItem(i).is(Items.EXPERIENCE_BOTTLE)) {
               return i;
            }
         }
      }

      return -1;
   }

   static {
      ARMOR_SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   }
}
