package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.PiercingWeapon;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;
import vexbot.util.BotCommands;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.StunSlam;
import vexbot.util.SwapEngine;

public final class SpearMaceController {
   private static final double DASH_TRIGGER_HORIZ = (double)3.0F;
   private static final double FULL_DASH_DIST = (double)14.0F;
   private static final double SHORT_DASH_DIST = (double)5.0F;
   private static final float DASH_PITCH_FAR = 0.0F;
   private static final float DASH_PITCH_NEAR = 40.0F;
   private static final int MOMENTUM_LEAD_TICKS = 8;
   private static final double SPEAR_REACH = (double)4.5F;
   private static final double OVERSHOOT_SPEED = 0.2;
   private static final int DASH_INTERVAL_TICKS = 4;
   private static final double DASH_CHAIN_SPEED = 0.45;
   private static final double ABOVE_HORIZ_THRESHOLD = 1.8;
   private static final double MIN_FALL_DIST = (double)1.5F;
   private static final double TRIGGER_RANGE = (double)40.0F;
   private static final int COOLDOWN_TICKS = 100;
   private static final double WINDBURST_LAUNCH_VEL = 0.4;
   private static final int MAX_RISING_TICKS = 60;
   private static final int MAX_DASH_TICKS = 90;
   private int dashesThisCombo = 0;
   private double lastDashGap = Double.MAX_VALUE;
   private boolean flyPastHit = false;
   private int lastDashTick = -100;
   private int tickCounter = 0;
   private boolean spearPopActive = false;
   private boolean spearPopOffhand = false;
   private int spearStunStep = 0;
   private boolean wcCancelUsed = false;
   private static final int MAX_SMASH_TICKS = 50;
   private static final int MAX_RECOVERY_TICKS = 30;
   private static final double AIRBORNE_START_VEL = 0.4;
   private static final double AIRBORNE_DASH_MIN_HEIGHT = (double)2.5F;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int spearSlot;
   private int maceSlot;
   private int windChargeSlot;
   private int prevSlot;
   private static final Random RNG = new Random();
   private final StunSlam stunSlam;
   private final ServerPlayer bot;
   private final MinecraftServer server;

   private double smashRange() {
      return (new EffectiveSettings(this.bot.getScoreboardName())).attackRange();
   }

   private void endSpearPop() {
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      if (this.spearPopOffhand) {
         OffhandManager.unpark(this.bot);
         this.spearPopOffhand = false;
      }

      this.spearPopActive = false;
      InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
      EquipmentSync.syncNow(this.bot);
   }

   public SpearMaceController(ServerPlayer bot, MinecraftServer server) {
      this.phase = SpearMaceController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldown = 0;
      this.spearSlot = -1;
      this.maceSlot = -1;
      this.windChargeSlot = -1;
      this.prevSlot = 0;
      this.stunSlam = new StunSlam();
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist) {
      ++this.tickCounter;
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target, dist);
         case 1 -> var10000 = this.tickLaunching();
         case 2 -> var10000 = this.tickRising(target);
         case 3 -> var10000 = this.tickDashing(target);
         case 4 -> var10000 = this.tickSmashing(target);
         case 5 -> var10000 = this.tickRecovery(target);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public boolean canCloseGap(double dist) {
      if (this.cooldown > 0) {
         return false;
      } else if (!(dist < (double)3.0F) && !(dist > (double)40.0F)) {
         TechniqueConfig cfg = (new EffectiveSettings(this.bot.getScoreboardName())).techniques();
         return !cfg.spearMacing ? false : this.comboItemsPresent();
      } else {
         return false;
      }
   }

   public boolean isExecuting() {
      return this.phase != SpearMaceController.Phase.IDLE;
   }

   public void reset() {
      if (this.phase != SpearMaceController.Phase.IDLE && this.bot.onGround()) {
         this.abort();
      }

   }

   private boolean tickIdle(LivingEntity target, double dist) {
      if (!EffectiveSettings.of(this.bot.getScoreboardName()).techniques().spearMacing) {
         return false;
      } else {
         if (this.spearSlot >= 0) {
            this.recoverSpearToHotbar();
         }

         if (target != null && target.isAlive()) {
            if (this.cooldown > 0) {
               return false;
            } else if (dist > (double)40.0F) {
               return false;
            } else {
               boolean onGroundStart = this.bot.onGround();
               double dxIdle = this.bot.getX() - target.getX();
               double dzIdle = this.bot.getZ() - target.getZ();
               double horizIdle = Math.sqrt(dxIdle * dxIdle + dzIdle * dzIdle);
               boolean airborneAbove = !onGroundStart && target.onGround() && this.bot.getY() - target.getY() >= (double)2.5F && horizIdle >= (double)3.0F;
               boolean airborneRising = !onGroundStart && !airborneAbove && this.bot.getDeltaMovement().y >= 0.4;
               if (!onGroundStart && !airborneAbove && !airborneRising) {
                  return false;
               } else if (onGroundStart && this.bot.getCooldowns().isOnCooldown(new ItemStack(Items.WIND_CHARGE))) {
                  return false;
               } else {
                  this.spearSlot = this.findLungeSpearSlot();
                  this.maceSlot = this.findWindBurstMaceSlot();
                  this.windChargeSlot = this.findWindChargeSlot();
                  if (this.spearSlot >= 0 && this.maceSlot >= 0) {
                     if (onGroundStart && this.windChargeSlot < 0) {
                        return false;
                     } else if (!EffectiveSettings.of(this.bot.getScoreboardName()).roll()) {
                        return false;
                     } else {
                        this.prevSlot = InventoryUtils.selected(this.bot.getInventory());
                        if (onGroundStart) {
                           this.enterPhase(SpearMaceController.Phase.LAUNCHING);
                        } else if (airborneAbove) {
                           this.enterPhase(SpearMaceController.Phase.DASHING);
                        } else {
                           this.enterPhase(SpearMaceController.Phase.RISING);
                        }

                        return true;
                     }
                  } else {
                     return false;
                  }
               }
            }
         } else {
            return false;
         }
      }
   }

   private boolean tickLaunching() {
      ++this.phaseTick;
      BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
      this.bot.setSprinting(false);
      InventoryUtils.select(this.bot.getInventory(), this.windChargeSlot);
      this.bot.setXRot(80.0F);
      if (this.phaseTick >= 2) {
         BotCommands.jumpOnce(this.server, this.bot.getScoreboardName());
         this.fireWindCharge();
         this.enterPhase(SpearMaceController.Phase.RISING);
      }

      return true;
   }

   private boolean tickRising(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (!this.comboItemsPresent()) {
            this.abort();
            return false;
         } else if (this.phaseTick > 60) {
            this.abort();
            return false;
         } else {
            this.recoverSpearToHotbar();
            Inventory inv = this.bot.getInventory();
            InventoryUtils.select(inv, this.holdSlotForCharge());
            this.faceTarget(target);
            this.driftToward(target);
            double yVel = this.bot.getDeltaMovement().y;
            double peakThreshold = -0.05 - RNG.nextDouble() * 0.03;
            if (yVel >= peakThreshold) {
               return true;
            } else {
               double dx = this.bot.getX() - target.getX();
               double dz = this.bot.getZ() - target.getZ();
               double horizDist = Math.sqrt(dx * dx + dz * dz);
               double triggerFuzz = (double)3.0F + (RNG.nextDouble() - (double)0.5F) * (double)4.0F;
               boolean dashAllowed = (new EffectiveSettings(this.bot.getScoreboardName())).useSpearDash();
               if (!(horizDist <= triggerFuzz) && dashAllowed) {
                  this.enterPhase(SpearMaceController.Phase.DASHING);
               } else {
                  InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                  this.enterPhase(SpearMaceController.Phase.SMASHING);
               }

               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickDashing(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (!this.comboItemsPresent()) {
            this.abort();
            return false;
         } else if (this.phaseTick <= 90 && !this.bot.onGround()) {
            this.recoverSpearToHotbar();
            double gapPast = Math.hypot(this.bot.getX() - target.getX(), this.bot.getZ() - target.getZ());
            boolean leaving = gapPast > this.lastDashGap + 0.2;
            this.lastDashGap = gapPast;
            if (leaving && this.spearSlot >= 0 && (double)this.bot.distanceTo(target) <= (double)4.5F && this.bot.getAttackStrengthScale(0.0F) > 0.9F) {
               this.faceTarget(target);
               this.bot.setYBodyRot(this.bot.getYRot());
               this.performFlyPastJab(target);
               this.flyPastHit = true;
               return true;
            } else {
               this.faceForDash(target);
               double horizSpeed = this.bot.getDeltaMovement().horizontalDistance();
               TechniqueConfig smCfg = (new EffectiveSettings(this.bot.getScoreboardName())).techniques();
               boolean chainOk = smCfg.dashChain || this.dashesThisCombo == 0;
               double gapNow = Math.hypot(this.bot.getX() - target.getX(), this.bot.getZ() - target.getZ());
               if (smCfg.dashChain && gapNow > (double)14.0F && this.bot.getDeltaMovement().y < -0.35 && horizSpeed < 0.35 && this.windChargeSlot >= 0 && this.windChargeSlot <= 8 && SwapEngine.fireWindChargeDown(this.bot, this.windChargeSlot)) {
                  return true;
               } else {
                  boolean correcting = this.flyPastHit || gapNow > 3.6 && leaving;
                  double speedGate = correcting ? 0.9 : 0.45;
                  boolean cadenceOk = this.tickCounter - this.lastDashTick >= 4;
                  if (cadenceOk && horizSpeed < speedGate && chainOk) {
                     this.flyPastHit = false;
                     ++this.dashesThisCombo;
                     this.performSpearDash(target);
                  } else {
                     InventoryUtils.select(this.bot.getInventory(), this.holdSlotForCharge());
                  }

                  double dx = this.bot.getX() - target.getX();
                  double dz = this.bot.getZ() - target.getZ();
                  double horizDist = Math.sqrt(dx * dx + dz * dz);
                  double aboveThreshFuzz = 1.8 + RNG.nextDouble() * (double)0.5F;
                  if (horizDist <= aboveThreshFuzz) {
                     InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                     this.enterPhase(SpearMaceController.Phase.SMASHING);
                  }

                  return true;
               }
            }
         } else {
            this.recoverSpearToHotbar();
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.enterPhase(SpearMaceController.Phase.SMASHING);
            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickSmashing(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (!this.comboItemsPresent()) {
            this.abort();
            return false;
         } else if (this.phaseTick > 50) {
            this.abort();
            return false;
         } else {
            this.recoverSpearToHotbar();
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.faceTarget(target);
            this.driftToward(target);
            double dist = (double)this.bot.distanceTo(target);
            boolean inRange = dist <= this.smashRange();
            boolean hasFall = this.bot.fallDistance > (double)1.5F && MaceSmashGates.botMayUseSmashFallBonus(this.bot);
            boolean landed = this.bot.onGround() && this.phaseTick > 3;
            TechniqueConfig smTech = (new EffectiveSettings(this.bot.getScoreboardName())).techniques();
            boolean fastFall = this.bot.getDeltaMovement().y <= -0.3;
            if (smTech.spearDoublePop && !target.isBlocking() && fastFall && dist >= 2.2 && dist <= (double)4.5F && this.spearSlot >= 0) {
               if (!this.spearPopActive) {
                  this.spearPopActive = true;
                  if (smTech.spearDoublePopOffhand) {
                     this.spearPopOffhand = OffhandManager.park(this.bot, this.spearSlot, 30);
                  }

                  if (!this.spearPopOffhand) {
                     InventoryUtils.select(this.bot.getInventory(), this.spearSlot);
                     EquipmentSync.syncNow(this.bot);
                  }

                  SwapEngine.useDown(this.bot, this.spearPopOffhand ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
               }

               this.faceTarget(target);
               if (landed || this.phaseTick > 46) {
                  this.endSpearPop();
               }

               return true;
            } else {
               if (this.spearPopActive) {
                  this.endSpearPop();
               }

               if (this.spearStunStep == 1 && fastFall && dist >= 2.2 && dist <= 4.3 && this.spearSlot >= 0) {
                  InventoryUtils.select(this.bot.getInventory(), this.spearSlot);
                  EquipmentSync.syncNow(this.bot);
                  SwapEngine.useDown(this.bot, InteractionHand.MAIN_HAND);
                  this.spearPopActive = true;
                  this.spearStunStep = 0;
                  this.faceTarget(target);
                  return true;
               } else {
                  if (smTech.spearStunSlam && target.isBlocking() && fastFall && dist >= 2.2 && dist <= 4.3 && this.spearSlot >= 0 && hasFall) {
                     int axe = this.findAxeSlot();
                     if (axe >= 0 && this.spearStunStep == 0 && McCompat.invulnerableTime(target) <= 10) {
                        SwapEngine.syncedAttack(this.bot, axe, target);
                        this.spearStunStep = 1;
                        return true;
                     }
                  }

                  if (smTech.wcCancel && !this.wcCancelUsed && !inRange && !landed && this.bot.getDeltaMovement().y < -0.4 && this.bot.getY() - (double)this.bot.level().getHeightmapPos(Types.MOTION_BLOCKING, this.bot.blockPosition()).getY() < (double)4.0F && this.windChargeSlot >= 0 && this.windChargeSlot <= 8 && SwapEngine.fireWindChargeDown(this.bot, this.windChargeSlot)) {
                     this.wcCancelUsed = true;
                     this.enterPhase(SpearMaceController.Phase.RISING);
                     return true;
                  } else if (inRange && hasFall) {
                     if (!this.bot.hasLineOfSight(target)) {
                        if (landed) {
                           this.abort();
                           return false;
                        } else {
                           return true;
                        }
                     } else {
                        this.bot.setSprinting(true);
                        EffectiveSettings ssEffs = EffectiveSettings.of(this.bot.getScoreboardName());
                        TechniqueConfig ssCfg = ssEffs.techniques();
                        StunSlam.Result ssRes = this.stunSlam.tick(this.bot, target, this.findAxeSlot(), this.maceSlot, ssCfg.stunSlamVariant, ssCfg.stunSlam, ssEffs);
                        if (ssRes == StunSlam.Result.HOLD) {
                           return true;
                        } else {
                           if (ssRes != StunSlam.Result.SMASHED) {
                              InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                              EquipmentSync.syncNow(this.bot);
                              this.bot.attack(target);
                              McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                           }

                           InventoryUtils.select(this.bot.getInventory(), this.holdSlotForCharge());
                           this.enterPhase(SpearMaceController.Phase.RECOVERY);
                           return true;
                        }
                     }
                  } else if (landed) {
                     this.abort();
                     return false;
                  } else {
                     return true;
                  }
               }
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickRecovery(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (!this.comboItemsPresent()) {
            this.abort();
            return false;
         } else if (this.phaseTick > 30) {
            this.abort();
            return false;
         } else {
            this.recoverSpearToHotbar();
            Inventory inv = this.bot.getInventory();
            InventoryUtils.select(inv, this.holdSlotForCharge());
            if (this.bot.getDeltaMovement().y >= 0.4) {
               this.enterPhase(SpearMaceController.Phase.RISING);
               return true;
            } else if ((new EffectiveSettings(this.bot.getScoreboardName())).techniques().wcSelfReset && !this.bot.onGround() && this.phaseTick <= 3 && this.windChargeSlot >= 0 && inv.getItem(this.windChargeSlot).is(Items.WIND_CHARGE) && SwapEngine.fireWindChargeDown(this.bot, this.windChargeSlot)) {
               this.enterPhase(SpearMaceController.Phase.RISING);
               return true;
            } else if (this.bot.onGround() && this.phaseTick > 5) {
               this.abort();
               return false;
            } else {
               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private void enterPhase(Phase p) {
      if (p == SpearMaceController.Phase.IDLE) {
         this.dashesThisCombo = 0;
         this.wcCancelUsed = false;
      }

      if (p != SpearMaceController.Phase.SMASHING) {
         this.spearStunStep = 0;
      }

      if (p == SpearMaceController.Phase.DASHING) {
         this.lastDashGap = Double.MAX_VALUE;
         this.flyPastHit = false;
      }

      if (this.spearPopActive && p != SpearMaceController.Phase.SMASHING) {
         this.endSpearPop();
      }

      this.phase = p;
      this.phaseTick = 0;
   }

   private void abort() {
      if (this.spearPopActive) {
         this.endSpearPop();
      }

      this.recoverSpearToHotbar();
      InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      this.cooldown = 50;
      this.enterPhase(SpearMaceController.Phase.IDLE);
   }

   private void performSpearDash(LivingEntity target) {
      if (this.bot.hasLineOfSight(target)) {
         Inventory inv = this.bot.getInventory();
         ItemStack spear = inv.getItem(this.spearSlot);
         if (getEnchantLevel(spear, "lunge") >= 3) {
            PiercingWeapon pw = (PiercingWeapon)spear.get(DataComponents.PIERCING_WEAPON);
            if (pw != null) {
               if (!((double)this.bot.distanceTo(target) <= (double)5.0F)) {
                  double gap = Math.hypot(this.bot.getX() - target.getX(), this.bot.getZ() - target.getZ());
                  double lead = this.bot.getDeltaMovement().horizontalDistance() * (double)8.0F;
                  if (!(gap - lead <= 1.8)) {
                     InventoryUtils.select(inv, this.spearSlot);
                     pw.attack(this.bot, EquipmentSlot.MAINHAND);
                     this.lastDashTick = this.tickCounter;
                     InventoryUtils.select(inv, this.holdSlotForCharge());
                  }
               }
            }
         }
      }
   }

   private void performFlyPastJab(LivingEntity target) {
      Inventory inv = this.bot.getInventory();
      ItemStack spear = inv.getItem(this.spearSlot);
      PiercingWeapon pw = (PiercingWeapon)spear.get(DataComponents.PIERCING_WEAPON);
      if (pw != null) {
         InventoryUtils.select(inv, this.spearSlot);
         EquipmentSync.syncNow(this.bot);
         pw.attack(this.bot, EquipmentSlot.MAINHAND);
         this.bot.resetAttackStrengthTicker();
         InventoryUtils.select(inv, this.holdSlotForCharge());
      }
   }

   private void faceForDash(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      double d = Math.sqrt(dx * dx + dz * dz);
      d = Math.max((double)0.0F, d - this.bot.getDeltaMovement().horizontalDistance() * (double)8.0F);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch;
      if (d >= (double)14.0F) {
         pitch = 0.0F;
      } else {
         double t = Math.max((double)0.0F, Math.min((double)1.0F, (d - (double)5.0F) / (double)9.0F));
         pitch = (float)((double)40.0F - (double)40.0F * t);
      }

      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      this.bot.setXRot(pitch);
   }

   private int holdSlotForCharge() {
      return this.windChargeSlot >= 0 && this.bot.getInventory().getItem(this.windChargeSlot).is(Items.WIND_CHARGE) ? this.windChargeSlot : this.maceSlot;
   }

   private void fireWindCharge() {
      SwapEngine.fireWindCharge(this.bot, this.windChargeSlot, 80.0F);
   }

   private void faceTarget(LivingEntity target) {
      double dx = target.getX() - this.bot.getEyePosition().x;
      double dy = target.getY() - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void driftToward(LivingEntity target) {
      String name = this.bot.getScoreboardName();
      double dist = (double)this.bot.distanceTo(target);
      if (dist > (double)1.5F) {
         BotCommands.moveForward(this.server, name);
         this.bot.setSprinting(dist > (double)3.0F);
      } else {
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
      }

   }

   private void recoverSpearToHotbar() {
      Inventory inv = this.bot.getInventory();
      if (this.spearSlot < 0 || this.spearSlot >= 9 || getEnchantLevel(inv.getItem(this.spearSlot), "lunge") < 3) {
         int spearAt = -1;

         for(int i = 0; i < 36; ++i) {
            if (getEnchantLevel(inv.getItem(i), "lunge") >= 3) {
               spearAt = i;
               break;
            }
         }

         if (spearAt >= 0) {
            if (spearAt < 9) {
               this.spearSlot = spearAt;
            } else {
               this.spearSlot = InventoryUtils.moveToHotbarSafe(inv, spearAt);
            }
         }
      }
   }

   private boolean comboItemsPresent() {
      Inventory inv = this.bot.getInventory();
      boolean spearAnywhere = false;
      boolean maceAnywhere = false;

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (!spearAnywhere && getEnchantLevel(s, "lunge") >= 3) {
            spearAnywhere = true;
         }

         if (!maceAnywhere && s.is(Items.MACE) && getEnchantLevel(s, "wind_burst") >= 1) {
            maceAnywhere = true;
         }

         if (spearAnywhere && maceAnywhere) {
            return true;
         }
      }

      if (!spearAnywhere && this.spearPopOffhand && getEnchantLevel(this.bot.getOffhandItem(), "lunge") >= 3) {
         spearAnywhere = true;
      }

      return spearAnywhere && maceAnywhere;
   }

   private int findAxeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.AXES)) {
            return i;
         }
      }

      return -1;
   }

   private int findLungeSpearSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (getEnchantLevel(inv.getItem(i), "lunge") >= 3) {
            return i;
         }
      }

      return -1;
   }

   private int findWindBurstMaceSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.MACE) && getEnchantLevel(s, "wind_burst") >= 1) {
            return i;
         }
      }

      return -1;
   }

   private int findWindChargeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.WIND_CHARGE)) {
            return i;
         }
      }

      return -1;
   }

   private static int getEnchantLevel(ItemStack stack, String enchantPath) {
      if (stack.isEmpty()) {
         return 0;
      } else {
         ItemEnchantments enc = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
         if (enc != null && !enc.isEmpty()) {
            for(Holder<Enchantment> h : enc.keySet()) {
               String path = (String)h.unwrapKey().map(ResourceKey::identifier).map((loc) -> loc.getPath()).orElse("");
               if (path.equals(enchantPath)) {
                  return enc.getLevel(h);
               }
            }

            return 0;
         } else {
            return 0;
         }
      }
   }

   private static enum Phase {
      IDLE,
      LAUNCHING,
      RISING,
      DASHING,
      SMASHING,
      RECOVERY;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, LAUNCHING, RISING, DASHING, SMASHING, RECOVERY};
      }
   }
}
