package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;
import vexbot.util.VexLog;

public final class EnderPearlController {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-Pearl");
   private static final float THROW_PITCH = -22.0F;
   private static final int COOLDOWN_TICKS = 120;
   private static final int OFFENSIVE_COOLDOWN_TICKS = 44;
   private static final int POST_LAND_WEB_BLOCK_TICKS = 20;
   private static final int PEARL_FLIGHT_MAX_TICKS = 60;
   private static final int JUMP_QUEUE_MAX_TICKS = 4;
   private static final double JUMP_BOOST_MIN_DIST = (double)20.0F;
   private static final int CHAIN_MIN_ELAPSED = 20;
   private static final int CHAIN_MAX_ELAPSED = 90;
   private static final double CHAIN_THREAT_DIST = (double)9.0F;
   private static final int LEAD_MAX_TICKS = 25;
   private static final double LEAD_TRUST = 0.85;
   private static final float[] ESCAPE_YAWS = new float[]{0.0F, 25.0F, -25.0F, 50.0F, -50.0F};
   private static final float[] ESCAPE_PITCHES = new float[]{-22.0F, -30.0F, -14.0F};
   private static final double ESCAPE_MIN_DIST = (double)5.0F;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private int cooldownLeft = 0;
   private int offensiveCooldownLeft = 0;
   private boolean chainUsed = false;
   private int pendingTicks = 0;
   private LivingEntity pendingEntity = null;
   private boolean pendingToward = false;
   private boolean offensivePearlInFlight = false;
   private int postLandWebBlock = 0;
   private int flightTicks = 0;
   private Vec3 prevBotPos = null;
   private final DiveLead lead = new DiveLead();
   private int noShotTicks = 0;
   private static final int NO_SHOT_RETRY_TICKS = 8;
   private static final int DROP_IN_MAX_TICKS = 60;
   private int dropInTicks = 0;
   private int dropInLastTick = -10;

   public EnderPearlController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isThrowPending() {
      return this.pendingEntity != null;
   }

   public boolean tryThrow(LivingEntity threat) {
      if (this.pendingEntity != null) {
         return false;
      } else if (this.pearlOnItemCooldown()) {
         return false;
      } else {
         if (this.cooldownLeft > 0) {
            int elapsed = 120 - this.cooldownLeft;
            boolean chased = !this.chainUsed && elapsed >= 20 && elapsed <= 90 && threat != null && threat.isAlive() && (double)this.bot.distanceTo(threat) <= (double)9.0F;
            if (!chased) {
               return false;
            }

            this.chainUsed = true;
            VexLog.detail(LOGGER, "[Pearl] {} double-pearls — {} chased through the first", this.botName, threat.getName().getString());
         }

         if (this.findInInventory() < 0) {
            return false;
         } else {
            this.cooldownLeft = 120;
            if (this.bot.onGround()) {
               BotCommands.jumpOnce(this.server, this.botName);
               this.pendingEntity = threat;
               this.pendingToward = false;
               this.pendingTicks = 4;
               return true;
            } else {
               return this.fireEscape(threat);
            }
         }
      }
   }

   public boolean tryThrowToward(LivingEntity target) {
      if (this.pendingEntity != null) {
         return false;
      } else if (this.pearlOnItemCooldown()) {
         return false;
      } else if (this.offensiveCooldownLeft > 0) {
         return false;
      } else if (target != null && target.isAlive()) {
         if (!this.bot.onGround()) {
            return false;
         } else if (!target.onGround()) {
            return false;
         } else if (this.findInInventory() < 0) {
            return false;
         } else if (this.noShotTicks > 0) {
            return false;
         } else if (this.aimAt(target) == null) {
            this.noShotTicks = 8;
            return false;
         } else {
            this.offensiveCooldownLeft = 44;
            if (this.bot.onGround() && (double)this.bot.distanceTo(target) >= (double)20.0F) {
               BotCommands.jumpOnce(this.server, this.botName);
               this.pendingEntity = target;
               this.pendingToward = true;
               this.pendingTicks = 4;
               return true;
            } else {
               return this.fireOffensive(target);
            }
         }
      } else {
         return false;
      }
   }

   private boolean fireEscape(LivingEntity threat) {
      double dx = this.bot.getX() - threat.getX();
      double dz = this.bot.getZ() - threat.getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len < 0.01) {
         dx = (double)1.0F;
         dz = (double)0.0F;
      } else {
         dx /= len;
         dz /= len;
      }

      float away = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float bestYaw = away;
      float bestPitch = -22.0F;
      double best = (double)-1.0F;

      for(float off : ESCAPE_YAWS) {
         for(float pitch : ESCAPE_PITCHES) {
            float yaw = away + off;
            Vec3 at = PearlAim.landing(this.bot, yaw, pitch);
            if (at != null && !(at.distanceTo(this.bot.position()) < (double)5.0F)) {
               BlockPos cell = BlockPos.containing(at);
               ServerLevel lvl = this.bot.level();
               if (!lvl.getFluidState(cell).is(FluidTags.LAVA) && !lvl.getFluidState(cell.below()).is(FluidTags.LAVA)) {
                  double fromThreat = at.distanceTo(threat.position());
                  if (fromThreat > best) {
                     best = fromThreat;
                     bestYaw = yaw;
                     bestPitch = pitch;
                  }
               }
            }
         }
      }

      if (best < (double)0.0F) {
         return false;
      } else {
         this.bot.setYRot(bestYaw);
         this.bot.setXRot(bestPitch);
         this.bot.yHeadRot = bestYaw;
         if (!this.useHeldPearl()) {
            return false;
         } else {
            VexLog.detail(LOGGER, "[Pearl] {} threw ender pearl away from {}", this.botName, threat.getName().getString());
            return true;
         }
      }
   }

   private boolean fireOffensive(LivingEntity target) {
      PearlAim.Shot shot = this.aimAt(target);
      if (shot == null) {
         return false;
      } else {
         this.bot.setYRot(shot.yaw());
         this.bot.setXRot(shot.pitch());
         this.bot.yHeadRot = shot.yaw();
         if (!this.useHeldPearl()) {
            return false;
         } else {
            this.offensivePearlInFlight = true;
            this.flightTicks = 0;
            this.prevBotPos = this.bot.position();
            VexLog.detail(LOGGER, "[Pearl] {} pearled TOWARD {} ({} ticks of flight)", this.botName, target.getName().getString(), shot.ticks());
            return true;
         }
      }
   }

   private PearlAim.Shot aimAt(LivingEntity target) {
      Vec3 base = new Vec3(target.getX(), target.getY() + 0.4, target.getZ());
      PearlAim.Shot shot = PearlAim.solve(this.bot, base);
      if (shot == null) {
         return null;
      } else {
         Vec3 v = this.lead.track(target);
         if (target.onGround() && !(Math.sqrt(v.x * v.x + v.z * v.z) <= 0.06)) {
            for(int i = 0; i < 2; ++i) {
               double t = (double)Math.min(shot.ticks(), 25) * 0.85;
               PearlAim.Shot led = PearlAim.solve(this.bot, base.add(v.x * t, (double)0.0F, v.z * t));
               if (led == null) {
                  break;
               }

               shot = led;
            }

            return shot;
         } else {
            return shot;
         }
      }
   }

   public boolean tickDropIn(LivingEntity target) {
      if (target != null && target.isAlive() && target.onGround()) {
         double hx = Math.floor(target.getX()) + (double)0.5F - this.bot.getX();
         double hz = Math.floor(target.getZ()) + (double)0.5F - this.bot.getZ();
         double h = Math.sqrt(hx * hx + hz * hz);
         if (!(this.bot.getY() - target.getY() < (double)2.0F) && !(h > (double)2.5F)) {
            if (!this.bot.onGround() && this.dropInTicks == 0) {
               return this.endDropIn();
            } else if (this.pendingEntity == null && !this.pearlOnItemCooldown() && this.offensiveCooldownLeft <= 0 && this.findInInventory() >= 0) {
               if (++this.dropInTicks > 60) {
                  this.offensiveCooldownLeft = 44;
                  return this.endDropIn();
               } else {
                  this.dropInLastTick = this.bot.tickCount;
                  this.bot.setShiftKeyDown(true);
                  if (this.bot.onGround() && this.clearDownTo(target)) {
                     BotCommands.stopMoving(this.server, this.botName);
                     this.bot.setXRot(90.0F);
                     if (this.useHeldPearl()) {
                        this.offensiveCooldownLeft = 44;
                        this.offensivePearlInFlight = true;
                        this.flightTicks = 0;
                        this.prevBotPos = this.bot.position();
                        VexLog.detail(LOGGER, "[Pearl] {} dropped a pearl down onto {}", this.botName, target.getName().getString());
                     }

                     this.endDropIn();
                     return true;
                  } else {
                     float yaw = (float)Math.toDegrees(Math.atan2(-hx, hz));
                     this.bot.setYRot(yaw);
                     this.bot.yHeadRot = yaw;
                     this.bot.setXRot(60.0F);
                     BotCommands.setMovement(this.server, this.botName, 0.5F, 0.0F);
                     return true;
                  }
               }
            } else {
               return this.endDropIn();
            }
         } else {
            return this.endDropIn();
         }
      } else {
         return this.endDropIn();
      }
   }

   private boolean clearDownTo(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      if (dx * dx + dz * dz > 0.81) {
         return false;
      } else {
         Vec3 from = new Vec3(this.bot.getX(), this.bot.getEyeY() - 0.1, this.bot.getZ());
         Vec3 to = new Vec3(this.bot.getX(), target.getY() + 0.3, this.bot.getZ());
         return this.bot.level().clip(new ClipContext(from, to, Block.COLLIDER, Fluid.NONE, this.bot)).getType() == Type.MISS;
      }
   }

   private boolean endDropIn() {
      if (this.dropInTicks > 0) {
         this.bot.setShiftKeyDown(false);
         BotCommands.stopMoving(this.server, this.botName);
      }

      this.dropInTicks = 0;
      return false;
   }

   private boolean useHeldPearl() {
      int pearlSlot = this.findInInventory();
      if (pearlSlot < 0) {
         return false;
      } else {
         pearlSlot = this.moveToHotbar(pearlSlot);
         InventoryUtils.select(this.bot.getInventory(), pearlSlot);
         ItemStack stack = this.bot.getInventory().getItem(pearlSlot);
         if (!stack.is(Items.ENDER_PEARL)) {
            return false;
         } else {
            try {
               return this.bot.gameMode.useItem(this.bot, this.bot.level(), stack, InteractionHand.MAIN_HAND).consumesAction();
            } catch (Exception e) {
               LOGGER.warn("[Pearl] {} throw failed: {}", this.botName, e.getMessage());
               return false;
            }
         }
      }
   }

   private boolean pearlOnItemCooldown() {
      return this.bot.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL));
   }

   public void tickPearlState(LivingEntity target) {
      if (target != null && target.isAlive()) {
         this.lead.track(target);
      }

      if (this.cooldownLeft > 0 && --this.cooldownLeft == 0) {
         this.chainUsed = false;
      }

      if (this.offensiveCooldownLeft > 0) {
         --this.offensiveCooldownLeft;
      }

      if (this.noShotTicks > 0) {
         --this.noShotTicks;
      }

      if (this.dropInTicks > 0 && this.bot.tickCount - this.dropInLastTick > 1) {
         this.endDropIn();
      }

      if (this.pendingEntity != null) {
         --this.pendingTicks;
         boolean rising = !this.bot.onGround() && this.bot.getDeltaMovement().y > 0.05;
         if (rising || this.pendingTicks <= 0) {
            LivingEntity e = this.pendingEntity;
            boolean toward = this.pendingToward;
            this.pendingEntity = null;
            if (e != null && e.isAlive()) {
               if (toward) {
                  this.fireOffensive(e);
               } else {
                  this.fireEscape(e);
               }
            }
         }
      }

      if (this.postLandWebBlock > 0) {
         --this.postLandWebBlock;
      }

      if (this.offensivePearlInFlight) {
         ++this.flightTicks;
         Vec3 now = this.bot.position();
         boolean teleported = this.prevBotPos != null && now.distanceTo(this.prevBotPos) > (double)3.0F;
         if (teleported || this.flightTicks >= 60) {
            this.offensivePearlInFlight = false;
            this.postLandWebBlock = 20;
         }

         this.prevBotPos = now;
      }
   }

   public boolean suppressesWebs() {
      return this.offensivePearlInFlight || this.postLandWebBlock > 0;
   }

   private int findInInventory() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.ENDER_PEARL)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(Items.ENDER_PEARL)) {
            return i;
         }
      }

      return -1;
   }

   private int moveToHotbar(int slot) {
      return InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), slot);
   }
}
