package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;

final class FightState {
   static final int ENCOUNTER_GAP_TICKS = 70;
   static final int OPENING_MAX_TICKS = 100;
   static final int COMBO_LINK_TICKS = 20;
   static final int COMBO_MIN_HITS = 2;
   private int targetId = -1;
   private boolean inFight = false;
   private boolean firstHitDone = false;
   private int lastExchangeTick = Integer.MIN_VALUE;
   private int tick = 0;
   private int fightStartTick = 0;
   private int lastTargetHurt = 0;
   private int lastSelfHurt = 0;
   private int ourChain = 0;
   private int ourLastHitTick = Integer.MIN_VALUE;
   private int theirChain = 0;
   private int theirLastHitTick = Integer.MIN_VALUE;
   private int ourLongestChain = 0;

   void tick(ServerPlayer bot, LivingEntity target) {
      ++this.tick;
      if (target == null) {
         this.inFight = false;
         this.targetId = -1;
         this.resetChains();
      } else if (target.getId() != this.targetId) {
         this.targetId = target.getId();
         this.inFight = true;
         this.firstHitDone = false;
         this.fightStartTick = this.tick;
         this.lastExchangeTick = Integer.MIN_VALUE;
         this.lastTargetHurt = target.hurtTime;
         this.lastSelfHurt = bot.hurtTime;
         this.resetChains();
      } else {
         this.inFight = true;
         boolean theyHurt = target.hurtTime > this.lastTargetHurt;
         boolean weHurt = bot.hurtTime > this.lastSelfHurt;
         this.lastTargetHurt = target.hurtTime;
         this.lastSelfHurt = bot.hurtTime;
         if (theyHurt || weHurt) {
            this.lastExchangeTick = this.tick;
            this.firstHitDone = true;
         }

         boolean theyGotHit = theyHurt && damagedBy(target, bot);
         boolean weGotHit = weHurt && damagedBy(bot, target);
         if (this.tick - this.ourLastHitTick > 20) {
            this.ourChain = 0;
         }

         if (this.tick - this.theirLastHitTick > 20) {
            this.theirChain = 0;
         }

         if (theyGotHit && weGotHit) {
            this.ourChain = 0;
            this.theirChain = 0;
         } else if (theyGotHit) {
            ++this.ourChain;
            this.ourLastHitTick = this.tick;
            this.theirChain = 0;
            if (this.ourChain > this.ourLongestChain) {
               this.ourLongestChain = this.ourChain;
            }
         } else if (weGotHit) {
            ++this.theirChain;
            this.theirLastHitTick = this.tick;
            this.ourChain = 0;
         }

      }
   }

   private static boolean damagedBy(LivingEntity victim, LivingEntity attacker) {
      DamageSource src = victim.getLastDamageSource();
      return src != null && src.getEntity() == attacker;
   }

   private void resetChains() {
      this.ourChain = this.theirChain = this.ourLongestChain = 0;
      this.ourLastHitTick = this.theirLastHitTick = Integer.MIN_VALUE;
   }

   boolean inFight() {
      return this.inFight;
   }

   boolean firstHitDone() {
      return this.firstHitDone;
   }

   boolean inEncounter() {
      return this.inFight && this.tick - this.lastExchangeTick <= 70;
   }

   boolean isOpening() {
      return this.inFight && !this.firstHitDone && this.tick - this.fightStartTick <= 100;
   }

   int comboHits() {
      return this.ourChain;
   }

   int incomingComboHits() {
      return this.theirChain;
   }

   boolean comboing() {
      return this.ourChain >= 2;
   }

   boolean beingCombod() {
      return this.theirChain >= 2;
   }

   int ticksSinceOurHit() {
      return this.ourLastHitTick == Integer.MIN_VALUE ? Integer.MAX_VALUE : this.tick - this.ourLastHitTick;
   }

   int ticksSinceHitTaken() {
      return this.theirLastHitTick == Integer.MIN_VALUE ? Integer.MAX_VALUE : this.tick - this.theirLastHitTick;
   }

   int longestCombo() {
      return this.ourLongestChain;
   }
}
