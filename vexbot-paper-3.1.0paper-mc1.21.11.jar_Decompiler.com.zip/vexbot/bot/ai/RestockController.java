package vexbot.bot.ai;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.PlayerEnderChestContainer;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.kit.KitManager;
import vexbot.kit.KitPotion;
import vexbot.stats.Stats;
import vexbot.team.TeamManager;
import vexbot.util.BotCommands;
import vexbot.util.ElytraFlight;
import vexbot.util.EnchantmentUtils;
import vexbot.util.InventoryUtils;
import vexbot.util.VexLog;
import vexbot.util.WebPlacer;

public final class RestockController {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-Restock");
   private static final int COOLDOWN_TICKS = 100;
   private static final int CHECK_INTERVAL = 10;
   private static final int SHULKER_SLOTS = 27;
   private static final int PEARL_MAX_WAIT = 60;
   private static final double PEARL_LANDED_DIST = (double)4.0F;
   private static final double SAFE_OPEN_DIST = (double)16.0F;
   private static final double COVER_OPEN_DIST = (double)6.0F;
   private static final double DISENGAGED_DIST = (double)20.0F;
   private static final double ABORT_DIST = (double)10.0F;
   private static final int HELD_BACK_COOLDOWN = 40;
   private static final int INTERRUPTED_COOLDOWN = 60;
   private static final int OPEN_TICKS = 60;
   private static final int EXTRACT_EVERY = 5;
   private static final int MINE_TIMEOUT = 120;
   private static final int COLLECT_TICKS = 20;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final EnderPearlController pearl;
   private final String botName;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int checkTick;
   private Vec3 pearlOrigin;
   private BlockPos placedPos;
   private ItemStack placedShulker;
   private List<Supply> activeMissing;
   private int slotBeforeMine;
   private float enderMineProgress;
   private boolean looted;
   private boolean extractDumped;
   private int extractedTotal;
   private int missedTotal;
   private int dumpedTotal;
   private int equippedTotal;
   private BlockPos minedPos;
   private BlockPos enderPos;
   private ItemStack placedEnder;
   private int enderSlotUsed;
   private final boolean[] everStocked;
   private final Set<String> warnedNoSource;
   private final List<Supply> supplies;
   private static final int ELYTRA_LAUNCH_TICKS = 20;
   private int elytraStashSlot;
   private static final int MAX_BOXES_PER_RUN = 4;
   private int boxesOpened;
   private boolean packMode;
   private Phase pendingFirst;
   private static final int MAX_ESCAPE_HOPS = 2;
   private int escapeHops;
   private static final Map<BlockPos, PlacedBox> PLACED_BOXES = new ConcurrentHashMap();
   private static final double TIER_CRITICAL = (double)10.0F;
   private static final double TIER_HEALING = (double)8.0F;
   private static final double TIER_CONTAINER = (double)7.0F;
   private static final double TIER_TOTEM = (double)6.0F;
   private static final double TIER_FAST = (double)5.0F;
   private static final double TIER_POTION = (double)3.0F;
   private static final double TIER_MISC = (double)2.0F;
   private static final double TIER_GEAR = (double)1.0F;
   private static final int SPARE_ARMOR_PER_SLOT = 1;
   private static final int SPARE_WEAPONS_PER_TYPE = 1;
   private static final double REGEAR_WEAR = 0.7;
   private final ItemStack[] checkStacks;
   private final Item[] tallyItems;
   private final int[] tallyCounts;
   private int tallySize;
   private double lastUpgradeWornScore;
   private final Set<String> missingKits;
   private static final int GROUND_SCAN_DEPTH = 5;
   private static final int ENDER_OPEN_TICKS = 8;
   private int returnedBoxSlot;
   private static final int CONTAINER_RESERVE = 2;

   public RestockController(ServerPlayer bot, MinecraftServer server, EnderPearlController pearl) {
      this.phase = RestockController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldown = 0;
      this.checkTick = 0;
      this.pearlOrigin = null;
      this.placedPos = null;
      this.placedShulker = ItemStack.EMPTY;
      this.activeMissing = null;
      this.slotBeforeMine = -1;
      this.enderMineProgress = 0.0F;
      this.looted = false;
      this.extractDumped = false;
      this.extractedTotal = 0;
      this.missedTotal = 0;
      this.dumpedTotal = 0;
      this.equippedTotal = 0;
      this.minedPos = null;
      this.enderPos = null;
      this.placedEnder = ItemStack.EMPTY;
      this.enderSlotUsed = -1;
      this.warnedNoSource = new HashSet();
      this.elytraStashSlot = -1;
      this.boxesOpened = 0;
      this.packMode = false;
      this.pendingFirst = RestockController.Phase.PLACE;
      this.escapeHops = 0;
      this.checkStacks = new ItemStack[36];
      this.tallyItems = new Item[37];
      this.tallyCounts = new int[37];
      this.tallySize = -1;
      this.lastUpgradeWornScore = Double.NaN;
      this.missingKits = new HashSet();
      this.returnedBoxSlot = -1;
      this.bot = bot;
      this.server = server;
      this.pearl = pearl;
      this.botName = bot.getScoreboardName();
      this.supplies = this.buildSupplies();
      this.everStocked = new boolean[this.supplies.size()];
   }

   public boolean isExecuting() {
      return this.phase != RestockController.Phase.IDLE;
   }

   public boolean tick(LivingEntity threat) {
      try {
         if (this.phase != RestockController.Phase.IDLE) {
            return this.tickRun(threat);
         } else {
            this.updateBaseline();
            if (this.cooldown > 0 && threat != null && threat.isAlive() && this.opponentDisengaged(threat)) {
               this.cooldown = 0;
            }

            if (this.cooldown > 0) {
               --this.cooldown;
               return false;
            } else if (++this.checkTick < 10) {
               return false;
            } else {
               this.checkTick = 0;
               List<Supply> low = this.currentLow();
               this.warnedNoSource.retainAll(keySet(low));
               boolean boxRegear = EffectiveSettings.of(this.botName).shulkerRegear();
               if (low.isEmpty()) {
                  if (!boxRegear) {
                     return false;
                  } else {
                     List<Supply> upgrade = this.shulkerUpgrade();
                     if (upgrade.isEmpty()) {
                        return false;
                     } else {
                        this.activeMissing = upgrade;
                        boolean started = this.beginRun(threat, false);
                        if (started) {
                           this.lastUpgradeWornScore = this.wornArmorScore();
                        }

                        return started;
                     }
                  }
               } else if (boxRegear && this.findShulkerSlot(low) >= 0) {
                  this.activeMissing = low;
                  this.lastUpgradeWornScore = Double.NaN;
                  return this.beginRun(threat, false);
               } else if (!boxRegear || !this.enderRegearEnabled() || this.findEnderChestSlot() < 0 || this.findEnderShulkerSlot(low) < 0 && !this.enderHasLoose(low)) {
                  int potionSlot = this.findKitPotion();
                  if (potionSlot >= 0 && this.useKitPotion(potionSlot)) {
                     this.cooldown = 100;
                     return true;
                  } else {
                     for(Supply s : low) {
                        if (this.warnedNoSource.add(s.key())) {
                           VexLog.brief(LOGGER, "[Restock] {} is low on '{}' but no carried shulker or kit potion contains it", this.botName, s.key());
                        }
                     }

                     return false;
                  }
               } else {
                  this.activeMissing = low;
                  this.lastUpgradeWornScore = Double.NaN;
                  return this.beginRun(threat, true);
               }
            }
         }
      } catch (Exception e) {
         LOGGER.error("[Restock] {} regear failed — aborting run", this.botName, e);

         try {
            this.reset();
         } catch (Exception var7) {
         }

         return false;
      }
   }

   public boolean tick() {
      return this.tick((LivingEntity)null);
   }

   public void reset() {
      BotCommands.stopMining(this.server, this.botName);
      if (this.placedPos != null) {
         this.recoverPlacedBox();
      }

      if (this.enderPos != null) {
         this.mineEnderChest();
      }

      this.restoreSlotAfterMining();
      this.boxesOpened = 0;
      this.packMode = false;
      this.phase = RestockController.Phase.IDLE;
      this.phaseTick = 0;
      this.pearlOrigin = null;
      this.releasePlacedClaim();
      this.placedPos = null;
      this.placedShulker = ItemStack.EMPTY;
      this.activeMissing = null;
      this.minedPos = null;
      this.looted = false;
      this.returnedBoxSlot = -1;
   }

   private boolean beginRun(LivingEntity threat, boolean viaEnderChest) {
      boolean canPearl = threat != null && EffectiveSettings.of(this.botName).useEnderPearl() && this.hasEnderPearl();
      Phase first = viaEnderChest ? RestockController.Phase.PLACE_ENDER : RestockController.Phase.PLACE;
      if (canPearl) {
         this.escapeHops = 0;
         this.pearlOrigin = this.bot.position();
         if (this.pearl.tryThrow(threat)) {
            this.phase = RestockController.Phase.PEARL_WAIT;
            this.phaseTick = 0;
            this.pendingFirst = first;
            VexLog.brief(LOGGER, "[Restock] {} ran low — pearling away to resupply{}", this.botName, viaEnderChest ? " from its ender chest" : "");
            return true;
         }
      }

      if (threat != null && this.startElytraEscape()) {
         this.escapeHops = 0;
         this.pearlOrigin = this.bot.position();
         this.phase = RestockController.Phase.ELYTRA_LAUNCH;
         this.phaseTick = 0;
         this.pendingFirst = first;
         VexLog.brief(LOGGER, "[Restock] {} ran low — flying away to resupply{}", this.botName, viaEnderChest ? " from its ender chest" : "");
         return true;
      } else if (!this.safeToOpenBox(threat)) {
         VexLog.brief(LOGGER, "[Restock] {} needs to resupply but {} is too close — holding", this.botName, threat.getName().getString());
         this.cooldown = 40;
         return false;
      } else {
         VexLog.brief(LOGGER, "[Restock] {} ran low — resupplying where it stands{}", this.botName, viaEnderChest ? " from its ender chest" : "");
         this.phase = first;
         this.phaseTick = 0;
         return true;
      }
   }

   private boolean startElytraEscape() {
      if (this.countInInventory(Items.FIREWORK_ROCKET) <= 0) {
         return false;
      } else if (!this.equipElytraForEscape()) {
         return false;
      } else {
         this.faceAwayForEscape();
         return true;
      }
   }

   private void faceAwayForEscape() {
      LivingEntity chaser = this.escapeThreat();
      if (chaser != null) {
         double dx = this.bot.getX() - chaser.getX();
         double dz = this.bot.getZ() - chaser.getZ();
         this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
         this.bot.setYHeadRot(this.bot.getYRot());
      }

      this.bot.setXRot(-35.0F);
   }

   private void restoreChestAfterEscape() {
      int slot = this.elytraStashSlot;
      this.elytraStashSlot = -1;
      if (slot >= 0 && !this.bot.isFallFlying()) {
         Inventory inv = this.bot.getInventory();
         ItemStack worn = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         ItemStack plate = inv.getItem(slot);
         if (worn.is(Items.ELYTRA) && ArmorEvaluator.getSlot(plate) == EquipmentSlot.CHEST) {
            ItemStack back = plate.copy();
            inv.setItem(slot, worn.copy());
            this.bot.setItemSlot(EquipmentSlot.CHEST, back);
         }
      }
   }

   private boolean equipElytraForEscape() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      this.elytraStashSlot = -1;
      if (chest.is(Items.ELYTRA)) {
         return true;
      } else {
         Inventory inv = this.bot.getInventory();
         int from = -1;

         for(int i = 0; i < inv.getContainerSize(); ++i) {
            if (inv.getItem(i).is(Items.ELYTRA) && this.isServiceable(inv.getItem(i))) {
               from = i;
               break;
            }
         }

         if (from < 0) {
            return false;
         } else {
            ItemStack elytra = inv.getItem(from).copy();
            inv.setItem(from, ItemStack.EMPTY);
            this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            if (!chest.isEmpty()) {
               inv.setItem(from, chest.copy());
               this.elytraStashSlot = from;
            }

            return true;
         }
      }
   }

   private void fireEscapeRocket() {
      Inventory inv = this.bot.getInventory();
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
            slot = i;
            break;
         }
      }

      if (slot < 0) {
         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
               slot = i;
               break;
            }
         }

         if (slot < 0) {
            return;
         }

         slot = InventoryUtils.moveToHotbarSafe(inv, slot);
      }

      int prev = InventoryUtils.selected(inv);
      InventoryUtils.select(inv, slot);
      this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(slot), InteractionHand.MAIN_HAND);
      InventoryUtils.select(inv, prev);
   }

   public boolean tryPackLoot() {
      if (this.phase == RestockController.Phase.IDLE && this.cooldown <= 0) {
         double radius = EffectiveSettings.of(this.botName).lootPackRadius();
         if (radius <= (double)0.0F) {
            return false;
         } else if (!EffectiveSettings.of(this.botName).pickupLoot()) {
            return false;
         } else if (this.findEmptyShulkerSlot() < 0) {
            return false;
         } else if (!this.hasSurplusToPack()) {
            return false;
         } else if (this.enemyWithinRadius(radius)) {
            return false;
         } else {
            this.packMode = true;
            this.phase = RestockController.Phase.PLACE;
            this.phaseTick = 0;
            this.looted = false;
            VexLog.brief(LOGGER, "[Restock] {} is clear for {} blocks — packing surplus into a shulker", this.botName, (int)radius);
            return true;
         }
      } else {
         return false;
      }
   }

   private int findEmptyShulkerSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (this.isShulkerBox(st)) {
            ItemContainerContents c = (ItemContainerContents)st.get(DataComponents.CONTAINER);
            if (c == null || McCompat.nonEmptyItems(c).isEmpty()) {
               return i;
            }
         }
      }

      return -1;
   }

   private boolean enemyWithinRadius(double r) {
      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (p.isAlive() && !p.isSpectator() && !p.isCreative() && p != this.bot && !p.getName().getString().equals(this.botName) && !TeamManager.isAlliedWithBot(this.botName, p.getName().getString()) && (double)this.bot.distanceTo(p) <= r) {
            return true;
         }
      }

      return false;
   }

   private boolean hasSurplusToPack() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (this.surplusBudget(inv.getItem(i)) > 0) {
            return true;
         }
      }

      return false;
   }

   private int surplusBudget(ItemStack st) {
      if (!st.isEmpty() && !this.isShulkerBox(st) && !st.is(Items.ENDER_CHEST)) {
         if (!isRestockWorthy(st)) {
            return 0;
         } else {
            return !ArmorEvaluator.isArmor(st) && !isWeaponLike(st) ? Math.max(0, this.countHeldLike(st) - this.carryTarget(st)) : 0;
         }
      } else {
         return 0;
      }
   }

   private void doStuffSurplus() {
      ServerLevel sl = this.bot.level();
      if (sl instanceof ServerLevel && this.placedPos != null) {
         BlockEntity var3 = sl.getBlockEntity(this.placedPos);
         if (var3 instanceof ShulkerBoxBlockEntity) {
            ShulkerBoxBlockEntity sbe = (ShulkerBoxBlockEntity)var3;
            Inventory var15 = this.bot.getInventory();
            int packed = 0;
            HashMap budget = new HashMap();

            for(int i = 0; i < 36; ++i) {
               ItemStack st = var15.getItem(i);
               if (!st.isEmpty()) {
                  budget.computeIfAbsent(st.getItem(), (k) -> this.surplusBudget(st));
               }
            }

            for(int i = 0; i < 36; ++i) {
               ItemStack st = var15.getItem(i);
               if (!st.isEmpty()) {
                  Item kind = st.getItem();
                  int left = (Integer)budget.getOrDefault(kind, 0);
                  if (left > 0) {
                     int move = Math.min(left, st.getCount());
                     int dest = this.firstRoomFor(sbe, st);
                     if (dest < 0) {
                        break;
                     }

                     ItemStack existing = sbe.getItem(dest);
                     if (existing.isEmpty()) {
                        ItemStack put = st.copy();
                        put.setCount(Math.min(move, st.getMaxStackSize()));
                        move = put.getCount();
                        sbe.setItem(dest, put);
                     } else {
                        int room = Math.min(move, existing.getMaxStackSize() - existing.getCount());
                        if (room <= 0) {
                           continue;
                        }

                        existing.grow(room);
                        move = room;
                     }

                     st.shrink(move);
                     if (st.isEmpty()) {
                        var15.setItem(i, ItemStack.EMPTY);
                     }

                     budget.put(kind, left - move);
                     packed += move;
                  }
               }
            }

            sbe.setChanged();
            int tossed = 0;

            for(int i = 0; i < 36; ++i) {
               ItemStack st = var15.getItem(i);
               if (!st.isEmpty() && !isRestockWorthy(st)) {
                  McCompat.drop(this.bot, st.copy(), false, false);
                  var15.setItem(i, ItemStack.EMPTY);
                  ++tossed;
               }
            }

            VexLog.brief(LOGGER, "[Restock] {} packed {} item(s) away and threw out {} junk stack(s)", this.botName, packed, tossed);
         }
      }
   }

   private int firstRoomFor(ShulkerBoxBlockEntity sbe, ItemStack like) {
      for(int i = 0; i < sbe.getContainerSize(); ++i) {
         ItemStack st = sbe.getItem(i);
         if (st.isEmpty()) {
            return i;
         }

         if (ItemStack.isSameItemSameComponents(st, like) && st.getCount() < st.getMaxStackSize()) {
            return i;
         }
      }

      return -1;
   }

   private LivingEntity escapeThreat() {
      LivingEntity best = null;
      double bestD = Double.MAX_VALUE;

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (p.isAlive() && !p.isSpectator() && !p.isCreative() && p != this.bot && !p.getName().getString().equals(this.botName) && !TeamManager.isAlliedWithBot(this.botName, p.getName().getString())) {
            double d = this.bot.distanceToSqr(p);
            if (d < bestD) {
               bestD = d;
               best = p;
            }
         }
      }

      return best;
   }

   private boolean opponentDisengaged(LivingEntity threat) {
      if (threat != null && threat.isAlive()) {
         double dist = this.bot.position().distanceTo(threat.position());
         if (dist >= (double)20.0F) {
            return true;
         } else {
            if (threat.isUsingItem()) {
               ItemStack use = threat.getUseItem();
               if (use.has(DataComponents.FOOD) || use.is(Items.POTION) || use.is(Items.MILK_BUCKET)) {
                  return true;
               }
            }

            return !this.bot.hasLineOfSight(threat) && dist >= (double)6.0F;
         }
      } else {
         return true;
      }
   }

   private boolean safeToOpenBox(LivingEntity threat) {
      if (threat != null && threat.isAlive()) {
         double dist = this.bot.position().distanceTo(threat.position());
         if (dist >= (double)16.0F) {
            return true;
         } else {
            return !this.bot.hasLineOfSight(threat) && dist >= (double)6.0F;
         }
      } else {
         return true;
      }
   }

   private void abortRun() {
      this.reset();
      this.cooldown = 60;
   }

   private boolean tickRun(LivingEntity threat) {
      ++this.phaseTick;
      if (this.phase != RestockController.Phase.PEARL_WAIT && this.phase != RestockController.Phase.ELYTRA_LAUNCH && threat != null && threat.isAlive() && this.bot.position().distanceTo(threat.position()) <= (double)10.0F && this.bot.hasLineOfSight(threat)) {
         VexLog.brief(LOGGER, "[Restock] {} broke off its resupply — {} closed in", this.botName, threat.getName().getString());
         this.abortRun();
         return false;
      } else {
         BotCommands.stopMoving(this.server, this.botName);
         switch (this.phase.ordinal()) {
            case 1:
               boolean landed = this.pearlOrigin != null && this.bot.position().distanceTo(this.pearlOrigin) > (double)4.0F && this.bot.onGround();
               if (landed || this.phaseTick >= 60) {
                  LivingEntity chaser = this.escapeThreat();
                  if (!this.safeToOpenBox(chaser)) {
                     if (this.escapeHops < 2 && chaser != null && this.hasEnderPearl() && EffectiveSettings.of(this.botName).useEnderPearl() && this.pearl.tryThrow(chaser)) {
                        ++this.escapeHops;
                        this.pearlOrigin = this.bot.position();
                        this.phaseTick = 0;
                        VexLog.detail(LOGGER, "[Restock] {} did not get clear — pearling again ({}/{})", this.botName, this.escapeHops, 2);
                        return true;
                     }

                     VexLog.brief(LOGGER, "[Restock] {} could not break off to resupply — back to the fight", this.botName);
                     this.finishRun();
                     this.cooldown = 40;
                     return true;
                  }

                  this.phase = this.pendingFirst;
                  this.phaseTick = 0;
               }

               return true;
            case 2:
               this.faceAwayForEscape();
               boolean gliding = this.bot.isFallFlying() || !this.bot.onGround() && ElytraFlight.beginGlide(this.bot);
               if (gliding) {
                  this.fireEscapeRocket();
                  this.elytraStashSlot = -1;
                  this.phase = RestockController.Phase.PEARL_WAIT;
                  this.phaseTick = 0;
                  return true;
               } else {
                  if (this.phaseTick >= 20) {
                     this.restoreChestAfterEscape();
                     this.finishRun();
                     this.cooldown = 40;
                     return true;
                  }

                  if (this.bot.onGround()) {
                     BotCommands.jumpOnce(this.server, this.botName);
                  }

                  return true;
               }
            case 3:
               if (!this.doPlaceEnderChest()) {
                  this.finishRun();
                  return true;
               }

               this.phase = RestockController.Phase.TAKE_SHULKER;
               this.phaseTick = 0;
               return true;
            case 4:
               if (this.phaseTick < 8) {
                  return true;
               } else {
                  int loose = this.takeLooseFromEnder();
                  if (!this.takeShulkerFromEnder()) {
                     if (loose <= 0) {
                        this.finishRun();
                        return true;
                     }

                     this.phase = RestockController.Phase.MINE_ENDER;
                     this.phaseTick = 0;
                     return true;
                  }

                  this.phase = RestockController.Phase.PLACE;
                  this.phaseTick = 0;
                  return true;
               }
            case 5:
               if (!this.doPlace()) {
                  this.finishRun();
                  return true;
               }

               ++this.boxesOpened;
               this.phase = RestockController.Phase.OPEN;
               this.phaseTick = 0;
               this.looted = false;
               this.resetExtractState();
               return true;
            case 6:
               this.lookAtPlaced();
               if (!this.packMode && this.phaseTick > 0 && this.phaseTick % 5 == 0) {
                  this.doExtract(1);
               }

               if (this.phaseTick >= 60) {
                  if (!this.looted) {
                     if (this.packMode) {
                        this.doStuffSurplus();
                     } else {
                        this.doExtract(Integer.MAX_VALUE);
                        this.logExtract();
                     }

                     this.looted = true;
                  }

                  this.closePlaced();
                  this.beginMining();
                  this.phase = RestockController.Phase.MINE;
                  this.phaseTick = 0;
               }

               return true;
            case 7:
               this.lookAtPlaced();
               ServerLevel sl = this.bot.level();
               if (sl instanceof ServerLevel && this.placedPos != null) {
                  if (sl.getBlockState(this.placedPos).isAir()) {
                     BotCommands.stopMining(this.server, this.botName);
                     this.minedPos = this.placedPos;
                     this.releasePlacedClaim();
                     this.placedPos = null;
                     this.phase = RestockController.Phase.COLLECT;
                     this.phaseTick = 0;
                     return true;
                  }

                  if (this.phaseTick >= 120) {
                     BotCommands.stopMining(this.server, this.botName);
                     this.recoverPlacedBox();
                     this.finishRun();
                  }

                  return true;
               }

               BotCommands.stopMining(this.server, this.botName);
               this.finishRun();
               return true;
            case 8:
               ServerLevel sl = this.bot.level();
               if (sl instanceof ServerLevel && this.minedPos != null) {
                  this.collectDroppedShulker(sl, this.minedPos);
               }

               if (this.phaseTick >= 20) {
                  VexLog.detail(LOGGER, "[Restock] {} mined shulker back up at {}", this.botName, this.minedPos);
                  this.minedPos = null;
                  if (this.enderPos != null) {
                     this.phase = RestockController.Phase.STOW_SHULKER;
                     this.phaseTick = 0;
                     return true;
                  }

                  List<Supply> still = this.packMode ? List.of() : this.currentLow();
                  if (!still.isEmpty() && this.boxesOpened < 4 && this.findShulkerSlot(still) >= 0) {
                     this.activeMissing = still;
                     this.phase = RestockController.Phase.PLACE;
                     this.phaseTick = 0;
                     VexLog.detail(LOGGER, "[Restock] {} still short — opening box {} of this run", this.botName, this.boxesOpened + 1);
                     return true;
                  }

                  this.finishRun();
               }

               return true;
            case 9:
               if (this.phaseTick < 8) {
                  return true;
               } else {
                  this.stowShulkerInEnder();
                  List<Supply> stillEnder = this.currentLow();
                  if (!stillEnder.isEmpty() && this.boxesOpened < 4 && this.findEnderShulkerSlot(stillEnder) >= 0) {
                     this.activeMissing = stillEnder;
                     this.phase = RestockController.Phase.TAKE_SHULKER;
                     this.phaseTick = 0;
                     return true;
                  }

                  this.phase = RestockController.Phase.MINE_ENDER;
                  this.phaseTick = 0;
                  return true;
               }
            case 10:
               if (this.enderPos != null) {
                  ServerLevel chaser = this.bot.level();
                  if (chaser instanceof ServerLevel && chaser.getBlockState(this.enderPos).is(Blocks.ENDER_CHEST)) {
                     if (this.phaseTick <= 1) {
                        this.enderMineProgress = 0.0F;
                        this.holdPickaxe();
                     }

                     WebPlacer.lookAt(this.bot, this.enderPos);
                     McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                     this.enderMineProgress += chaser.getBlockState(this.enderPos).getDestroyProgress(this.bot, chaser, this.enderPos);
                     if (this.enderMineProgress < 1.0F && this.phaseTick < 120) {
                        return true;
                     }
                  }
               }

               this.mineEnderChest();
               this.finishRun();
               return true;
            default:
               this.finishRun();
               return false;
         }
      }
   }

   private void beginMining() {
      Inventory inv = this.bot.getInventory();
      this.slotBeforeMine = InventoryUtils.selected(inv);
      int pick = this.findPickaxeSlot(inv);
      if (pick >= 0) {
         pick = InventoryUtils.moveToHotbarSafe(inv, pick);
         InventoryUtils.select(inv, pick);
      }

      this.lookAtPlaced();
      BotCommands.mineContinuous(this.server, this.botName);
   }

   private void collectDroppedShulker(ServerLevel sl, BlockPos pos) {
      AABB area = (new AABB(pos)).inflate((double)2.5F).expandTowards((double)0.0F, (double)-8.0F, (double)0.0F);

      for(ItemEntity ie : sl.getEntitiesOfClass(ItemEntity.class, area)) {
         ItemStack st = ie.getItem();
         if (this.isShulkerBox(st)) {
            int landing = this.bot.getInventory().getFreeSlot();
            ItemStack overflow = this.addToInventory(st.copy());
            if (overflow.isEmpty()) {
               ie.discard();
               if (this.enderPos != null) {
                  this.returnedBoxSlot = landing;
               }
            } else {
               ie.setItem(overflow);
            }
         }
      }

   }

   private void closePlaced() {
      if (this.placedPos != null) {
         ServerLevel sl = this.bot.level();
         if (sl instanceof ServerLevel) {
            BlockEntity sl = sl.getBlockEntity(this.placedPos);
            if (sl instanceof ShulkerBoxBlockEntity) {
               ShulkerBoxBlockEntity sbe = (ShulkerBoxBlockEntity)sl;
               sbe.stopOpen(this.bot);
            }
         }
      }

   }

   private void restoreSlotAfterMining() {
      if (this.slotBeforeMine >= 0 && this.slotBeforeMine < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.slotBeforeMine);
      }

      this.slotBeforeMine = -1;
   }

   private void holdPickaxe() {
      Inventory inv = this.bot.getInventory();
      if (this.slotBeforeMine < 0) {
         this.slotBeforeMine = InventoryUtils.selected(inv);
      }

      int pick = this.findPickaxeSlot(inv);
      if (pick >= 0) {
         InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, pick));
      }

   }

   private int findPickaxeSlot(Inventory inv) {
      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(ItemTags.PICKAXES)) {
            return i;
         }
      }

      return -1;
   }

   private void finishRun() {
      BotCommands.stopMining(this.server, this.botName);
      if (this.enderPos != null) {
         this.mineEnderChest();
      }

      this.restoreSlotAfterMining();
      this.boxesOpened = 0;
      this.packMode = false;
      this.phase = RestockController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldown = 100;
      this.pearlOrigin = null;
      this.releasePlacedClaim();
      this.placedPos = null;
      this.placedShulker = ItemStack.EMPTY;
      this.activeMissing = null;
      this.minedPos = null;
      this.looted = false;
      this.pendingFirst = RestockController.Phase.PLACE;
      this.enderSlotUsed = -1;
      this.returnedBoxSlot = -1;
   }

   static String placedBoxOwner(Level level, BlockPos pos) {
      PlacedBox pb = (PlacedBox)PLACED_BOXES.get(pos);
      return pb != null && pb.level() == level ? pb.owner() : null;
   }

   private void releasePlacedClaim() {
      if (this.placedPos != null) {
         PLACED_BOXES.computeIfPresent(this.placedPos, (k, v) -> v.owner().equals(this.botName) ? null : v);
      }
   }

   private boolean doPlace() {
      ServerLevel sl = this.bot.level();
      if (!(sl instanceof ServerLevel)) {
         return false;
      } else {
         int shulkerSlot = this.packMode ? this.findEmptyShulkerSlot() : this.findShulkerSlot(this.activeMissing != null ? this.activeMissing : this.currentLow());
         if (shulkerSlot < 0) {
            return false;
         } else {
            ItemStack shulkerItem = this.bot.getInventory().getItem(shulkerSlot).copy();
            Item var5 = shulkerItem.getItem();
            if (!(var5 instanceof BlockItem)) {
               return false;
            } else {
               BlockItem bi = (BlockItem)var5;
               Block var6 = bi.getBlock();
               if (!(var6 instanceof ShulkerBoxBlock)) {
                  return false;
               } else {
                  ShulkerBoxBlock shulkerBlock = (ShulkerBoxBlock)var6;
                  BlockPos placePos = this.findPlacementPos();
                  if (placePos == null) {
                     LOGGER.warn("[Restock] {} — no valid position to place shulker", this.botName);
                     return false;
                  } else {
                     sl.setBlock(placePos, shulkerBlock.defaultBlockState(), 3);
                     BlockEntity be = sl.getBlockEntity(placePos);
                     if (!(be instanceof ShulkerBoxBlockEntity)) {
                        sl.setBlock(placePos, Blocks.AIR.defaultBlockState(), 3);
                        return false;
                     } else {
                        ShulkerBoxBlockEntity sbe = (ShulkerBoxBlockEntity)be;
                        NonNullList shulkerItems = NonNullList.withSize(27, ItemStack.EMPTY);
                        ItemContainerContents contents = (ItemContainerContents)shulkerItem.get(DataComponents.CONTAINER);
                        if (contents != null) {
                           contents.copyInto(shulkerItems);
                        }

                        for(int i = 0; i < 27; ++i) {
                           sbe.setItem(i, ((ItemStack)shulkerItems.get(i)).copy());
                        }

                        sbe.setChanged();
                        sbe.startOpen(this.bot);
                        this.bot.getInventory().setItem(shulkerSlot, ItemStack.EMPTY);
                        this.placedShulker = shulkerItem;
                        this.placedPos = placePos;
                        PLACED_BOXES.put(placePos.immutable(), new PlacedBox(this.botName, sl));
                        VexLog.detail(LOGGER, "[Restock] {} placed shulker at {}", this.botName, placePos);
                        return true;
                     }
                  }
               }
            }
         }
      }
   }

   private void resetExtractState() {
      this.extractDumped = false;
      this.extractedTotal = 0;
      this.missedTotal = 0;
      this.dumpedTotal = 0;
      this.equippedTotal = 0;
   }

   private void logExtract() {
      VexLog.brief(LOGGER, "[Restock] {} extracted {} stacks ({} didn't fit), dumped {}, equipped {} armour", this.botName, this.extractedTotal, this.missedTotal, this.dumpedTotal, this.equippedTotal);
   }

   private int dumpJunk(ShulkerBoxBlockEntity sbe, Inventory inv) {
      int dumped = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack stack = inv.getItem(i);
         if (!stack.isEmpty() && !this.isUsefulItem(stack)) {
            for(int s = 0; s < 27; ++s) {
               if (sbe.getItem(s).isEmpty()) {
                  sbe.setItem(s, stack.copy());
                  inv.setItem(i, ItemStack.EMPTY);
                  ++dumped;
                  break;
               }
            }
         }
      }

      return dumped;
   }

   private void doExtract(int maxPulls) {
      if (this.placedPos != null) {
         ServerLevel sl = this.bot.level();
         if (sl instanceof ServerLevel) {
            BlockEntity var4 = sl.getBlockEntity(this.placedPos);
            if (!(var4 instanceof ShulkerBoxBlockEntity)) {
               return;
            }

            ShulkerBoxBlockEntity sbe = (ShulkerBoxBlockEntity)var4;
            Inventory var22 = this.bot.getInventory();
            if (!this.extractDumped) {
               this.dumpedTotal += this.dumpJunk(sbe, var22);
               this.extractDumped = true;
            }

            List<Integer> candidates = new ArrayList();

            for(int i = 0; i < 27; ++i) {
               ItemStack st = sbe.getItem(i);
               if (!st.isEmpty() && this.isNeededItem(st)) {
                  candidates.add(i);
               }
            }

            candidates.sort(Comparator.comparingDouble((ix) -> -this.needScore(sbe.getItem(ix))).thenComparingDouble((ix) -> -ArmorEvaluator.score(sbe.getItem(ix))));
            int extracted = 0;
            int missed = 0;
            int capped = 0;
            int pulls = 0;

            label79:
            for(int pass = 0; pass < 2; ++pass) {
               for(int i : candidates) {
                  ItemStack fromShulker = sbe.getItem(i);
                  if (!fromShulker.isEmpty()) {
                     int want = this.wantFor(fromShulker);
                     if (want <= 0) {
                        if (pass == 0) {
                           ++capped;
                        }
                     } else {
                        int room = this.roomKeepingReserve(fromShulker);
                        if (room <= 0) {
                           if (pass == 1) {
                              ++missed;
                           }
                        } else {
                           int takeCount = Math.min(want, fromShulker.getCount());
                           if (pass == 0) {
                              takeCount = Math.min(takeCount, fromShulker.getMaxStackSize());
                           }

                           takeCount = Math.min(takeCount, room);
                           ItemStack give = fromShulker.copy();
                           give.setCount(takeCount);
                           ItemStack leftover = this.addToInventory(give);
                           int moved = takeCount - leftover.getCount();
                           ItemStack remain = fromShulker.copy();
                           remain.shrink(moved);
                           sbe.setItem(i, remain.isEmpty() ? ItemStack.EMPTY : remain);
                           if (moved > 0 && pass == 0) {
                              ++extracted;
                           }

                           if (leftover.getCount() > 0 && pass == 1) {
                              ++missed;
                           }

                           if (moved > 0) {
                              ++pulls;
                              if (pulls >= maxPulls) {
                                 break label79;
                              }
                           }
                        }
                     }
                  }
               }
            }

            sbe.setChanged();
            this.extractedTotal += extracted;
            this.missedTotal += missed;
            this.equippedTotal += this.equipBetterArmor();
            return;
         }
      }

   }

   private double needScore(ItemStack st) {
      int want = this.wantFor(st);
      if (want <= 0) {
         return (double)0.0F;
      } else {
         int target = Math.max(1, this.targetFor(st));
         double deficit = Math.min((double)1.0F, (double)want / (double)target);
         double weight = this.classWeight(st);
         return weight * ((double)0.5F + deficit);
      }
   }

   private double classWeight(ItemStack st) {
      Item item = st.getItem();
      boolean hurt = (double)this.bot.getHealth() < (double)this.bot.getMaxHealth() * (double)0.5F;
      if (ArmorEvaluator.isArmor(st)) {
         EquipmentSlot slot = ArmorEvaluator.getSlot(st);
         boolean wornGone = slot != null && !this.isServiceable(this.bot.getItemBySlot(slot));
         return wornGone ? (double)10.0F : (double)1.0F;
      } else if (item == Items.ELYTRA) {
         return this.isServiceable(this.bot.getItemBySlot(EquipmentSlot.CHEST)) && !this.bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA) ? (double)1.0F : (this.countServiceableElytra() == 0 ? (double)10.0F : (double)1.0F);
      } else if (isWeaponLike(st)) {
         return this.countServiceableWeaponsLike(st) == 0 ? (double)10.0F : (double)1.5F;
      } else if (item == Items.SHIELD) {
         return this.countUsableShields() == 0 ? (double)8.0F : (double)1.5F;
      } else if (!isHealingItem(st)) {
         if (item == Items.TOTEM_OF_UNDYING) {
            return this.countInInventory(Items.TOTEM_OF_UNDYING) == 0 ? (double)10.0F : (double)6.0F;
         } else if (item != Items.ENDER_CHEST && !this.isShulkerBox(st)) {
            if (item != Items.ENDER_PEARL && item != Items.FIREWORK_ROCKET && item != Items.COBWEB && item != Items.WIND_CHARGE && !st.is(ItemTags.ARROWS) && !isBuildingBlock(st)) {
               if (item != Items.END_CRYSTAL && item != Items.OBSIDIAN && item != Items.RESPAWN_ANCHOR && item != Items.GLOWSTONE) {
                  if (item != Items.TNT_MINECART && !isRailItem(item)) {
                     if (item == Items.EXPERIENCE_BOTTLE) {
                        return (double)5.0F;
                     } else if (item != Items.SPLASH_POTION && item != Items.LINGERING_POTION && item != Items.POTION) {
                        if (st.has(DataComponents.FOOD)) {
                           return (double)4.0F;
                        } else {
                           return item == Items.WATER_BUCKET ? (double)3.0F : (double)2.0F;
                        }
                     } else {
                        return hurt ? (double)8.0F : (double)3.0F;
                     }
                  } else {
                     return (double)5.0F;
                  }
               } else {
                  return (double)5.0F;
               }
            } else {
               return (double)5.0F;
            }
         } else {
            return (double)7.0F;
         }
      } else {
         return this.healingCharges() != 0 && !hurt ? (double)8.0F : (double)10.0F;
      }
   }

   public static boolean isRestockWorthy(ItemStack st) {
      if (st.isEmpty()) {
         return false;
      } else {
         Item item = st.getItem();
         if (isHealingItem(st)) {
            return true;
         } else if (isWeaponLike(st)) {
            return true;
         } else if (ArmorEvaluator.isArmor(st)) {
            return true;
         } else if (isBuildingBlock(st)) {
            return true;
         } else if (isRailItem(item)) {
            return true;
         } else if (st.is(ItemTags.ARROWS)) {
            return true;
         } else if (st.is(ItemTags.PICKAXES)) {
            return true;
         } else if (st.has(DataComponents.FOOD)) {
            return true;
         } else if (KitPotion.getKitName(st) != null) {
            return true;
         } else {
            return item == Items.TOTEM_OF_UNDYING || item == Items.ENDER_PEARL || item == Items.FIREWORK_ROCKET || item == Items.COBWEB || item == Items.WIND_CHARGE || item == Items.EXPERIENCE_BOTTLE || item == Items.END_CRYSTAL || item == Items.OBSIDIAN || item == Items.RESPAWN_ANCHOR || item == Items.GLOWSTONE || item == Items.TNT_MINECART || item == Items.ELYTRA || item == Items.SHIELD || item == Items.ENDER_CHEST || item == Items.SPLASH_POTION || item == Items.LINGERING_POTION || item == Items.POTION || item == Items.WATER_BUCKET || item == Items.MILK_BUCKET || item == Items.BUCKET || item == Items.CHORUS_FRUIT || item == Items.BREEZE_ROD || item == Items.SHULKER_SHELL || item == Items.FLINT_AND_STEEL || item == Items.SHEARS || item == Items.HONEY_BOTTLE || item == Items.SNOWBALL || item == Items.EGG || item == Items.FIRE_CHARGE || item == Items.TNT || item == Items.LADDER || isShulkerBoxItem(st);
         }
      }
   }

   public static boolean isShulkerBoxItem(ItemStack st) {
      Item var2 = st.getItem();
      boolean var10000;
      if (var2 instanceof BlockItem bi) {
         if (bi.getBlock() instanceof ShulkerBoxBlock) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private static boolean isHealingItem(ItemStack st) {
      Item item = st.getItem();
      return item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE || item == Items.GOLDEN_CARROT;
   }

   private int healingCharges() {
      Inventory inv = this.bot.getInventory();
      int n = 0;

      for(int i = 0; i < inv.getContainerSize(); ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty() && isHealingItem(st)) {
            n += st.getCount();
         }
      }

      return n;
   }

   private int countServiceableElytra() {
      int n = this.isServiceable(this.bot.getItemBySlot(EquipmentSlot.CHEST)) && this.bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA) ? 1 : 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < inv.getContainerSize(); ++i) {
         ItemStack st = inv.getItem(i);
         if (st.is(Items.ELYTRA) && this.isServiceable(st)) {
            ++n;
         }
      }

      return n;
   }

   private static boolean isBuildingBlock(ItemStack st) {
      Item item = st.getItem();
      return st.is(ItemTags.PLANKS) || item == Items.COBBLESTONE || item == Items.DIRT || item == Items.END_STONE || item == Items.NETHERRACK || item == Items.STONE;
   }

   private int wantFor(ItemStack st) {
      if (ArmorEvaluator.isArmor(st)) {
         EquipmentSlot slot = ArmorEvaluator.getSlot(st);
         if (slot == null) {
            return 0;
         } else {
            ItemStack worn = this.bot.getItemBySlot(slot);
            int have = this.isServiceable(worn) ? 1 : 0;
            have += this.countCarriedServiceableArmorFor(slot);
            int want = Math.max(0, this.gearTarget(st, 2) - have);
            if (want == 0 && !isNearlyBroken(st) && !this.canMendInstead(worn) && ArmorEvaluator.score(st) > this.bestHeldArmorScore(slot)) {
               want = 1;
            }

            return want;
         }
      } else if (isWeaponLike(st)) {
         return Math.max(0, this.gearTarget(st, 2) - this.countServiceableWeaponsLike(st));
      } else {
         return st.is(Items.SHIELD) ? Math.max(0, this.carryTarget(st) - this.countUsableShields()) : this.carryTarget(st) - this.countHeldLike(st);
      }
   }

   private int targetFor(ItemStack st) {
      if (ArmorEvaluator.isArmor(st)) {
         return this.gearTarget(st, 2);
      } else {
         return isWeaponLike(st) ? this.gearTarget(st, 2) : this.carryTarget(st);
      }
   }

   private int gearTarget(ItemStack st, int builtIn) {
      TeamManager.BotTeam team = TeamManager.getTeamForBot(this.botName);
      int override = RestockPlan.carryTarget(team == null ? null : team.getName(), st);
      return override > 0 ? override : builtIn;
   }

   private double bestHeldArmorScore(EquipmentSlot slot) {
      ItemStack worn = this.bot.getItemBySlot(slot);
      double best = worn.isEmpty() ? Double.NEGATIVE_INFINITY : ArmorEvaluator.score(worn);
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack held = inv.getItem(i);
         if (!held.isEmpty() && ArmorEvaluator.getSlot(held) == slot && !isNearlyBroken(held)) {
            best = Math.max(best, ArmorEvaluator.score(held));
         }
      }

      return best;
   }

   private static boolean isWeaponLike(ItemStack st) {
      Item item = st.getItem();
      return st.is(ItemTags.SWORDS) || st.is(ItemTags.AXES) || st.is(ItemTags.SPEARS) || item == Items.MACE || item == Items.TRIDENT || item == Items.BOW || item == Items.CROSSBOW;
   }

   private static boolean sameWeaponType(ItemStack a, ItemStack b) {
      if (a.is(ItemTags.SWORDS)) {
         return b.is(ItemTags.SWORDS);
      } else if (a.is(ItemTags.AXES)) {
         return b.is(ItemTags.AXES);
      } else if (a.is(ItemTags.SPEARS)) {
         return b.is(ItemTags.SPEARS);
      } else {
         return a.getItem() == b.getItem();
      }
   }

   private int countServiceableWeaponsLike(ItemStack st) {
      int n = 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 41; ++i) {
         ItemStack held = inv.getItem(i);
         if (!held.isEmpty() && isWeaponLike(held) && sameWeaponType(st, held) && this.isServiceable(held)) {
            ++n;
         }
      }

      return n;
   }

   private int countCarriedServiceableArmorFor(EquipmentSlot slot) {
      int n = 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack held = inv.getItem(i);
         if (!held.isEmpty() && ArmorEvaluator.isArmor(held) && ArmorEvaluator.getSlot(held) == slot && this.isServiceable(held)) {
            ++n;
         }
      }

      return n;
   }

   private int equipBetterArmor() {
      if (InvisibleSuitUp.holdsArmour(this.bot)) {
         return 0;
      } else {
         int changed = 0;
         Inventory inv = this.bot.getInventory();

         for(EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack worn = this.bot.getItemBySlot(slot);
            if (!this.canMendInstead(worn)) {
               int bestIdx = -1;

               for(int i = 0; i < 36; ++i) {
                  ItemStack cand = inv.getItem(i);
                  if (!cand.isEmpty() && ArmorEvaluator.isArmor(cand) && ArmorEvaluator.getSlot(cand) == slot && !isNearlyBroken(cand) && (worn.isEmpty() || isNearlyBroken(worn) || !(ArmorEvaluator.score(cand) <= ArmorEvaluator.score(worn))) && (bestIdx < 0 || !(ArmorEvaluator.score(cand) <= ArmorEvaluator.score(inv.getItem(bestIdx))))) {
                     bestIdx = i;
                  }
               }

               if (bestIdx >= 0) {
                  ItemStack better = inv.getItem(bestIdx).copy();
                  inv.setItem(bestIdx, worn.isEmpty() ? ItemStack.EMPTY : worn.copy());
                  this.bot.setItemSlot(slot, better);
                  ++changed;
               }
            }
         }

         return changed;
      }
   }

   private boolean canMendInstead(ItemStack worn) {
      return !worn.isEmpty() && EnchantmentUtils.hasEnchantAtLeast(worn, "mending", 1) && this.countInInventory(Items.EXPERIENCE_BOTTLE) > 0;
   }

   private static boolean isWornOut(ItemStack st) {
      if (st.isEmpty()) {
         return true;
      } else if (st.isDamageableItem() && st.getMaxDamage() > 0) {
         return (double)st.getDamageValue() >= (double)st.getMaxDamage() * 0.7;
      } else {
         return false;
      }
   }

   private boolean isServiceable(ItemStack st) {
      return !st.isEmpty() && (!isWornOut(st) || this.canMendInstead(st));
   }

   private static boolean isNearlyBroken(ItemStack st) {
      if (st.isEmpty()) {
         return true;
      } else if (st.isDamageableItem() && st.getMaxDamage() > 0) {
         return st.getDamageValue() >= st.getMaxDamage() * 9 / 10;
      } else {
         return false;
      }
   }

   private void recoverPlacedBox() {
      if (this.placedPos != null) {
         ServerLevel sl = this.bot.level();
         if (sl instanceof ServerLevel) {
            BlockEntity var3 = sl.getBlockEntity(this.placedPos);
            if (!(var3 instanceof ShulkerBoxBlockEntity)) {
               this.releasePlacedClaim();
               this.placedPos = null;
               this.placedShulker = ItemStack.EMPTY;
               return;
            }

            ShulkerBoxBlockEntity sbe = (ShulkerBoxBlockEntity)var3;
            ItemStack rebuilt = this.placedShulker.isEmpty() ? new ItemStack(Items.SHULKER_BOX) : this.placedShulker.copy();
            List<ItemStack> leftover = new ArrayList(27);

            for(int i = 0; i < 27; ++i) {
               leftover.add(sbe.getItem(i).copy());
               sbe.setItem(i, ItemStack.EMPTY);
            }

            rebuilt.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(leftover));
            sbe.setChanged();
            rebuilt.setCount(1);
            sl.setBlock(this.placedPos, Blocks.AIR.defaultBlockState(), 3);
            if (this.bot.isDeadOrDying()) {
               McCompat.drop(this.bot, rebuilt, false);
            } else {
               ItemStack overflow = this.addToInventory(rebuilt);
               if (!overflow.isEmpty()) {
                  McCompat.drop(this.bot, overflow, false);
               }
            }

            this.releasePlacedClaim();
            VexLog.detail(LOGGER, "[Restock] {} mined shulker back up at {}", this.botName, this.placedPos);
            this.placedPos = null;
            this.placedShulker = ItemStack.EMPTY;
            return;
         }
      }

      this.releasePlacedClaim();
      this.placedPos = null;
   }

   private void lookAtPlaced() {
      if (this.placedPos != null) {
         double tx = (double)this.placedPos.getX() + (double)0.5F;
         double ty = (double)this.placedPos.getY() + (double)0.5F;
         double tz = (double)this.placedPos.getZ() + (double)0.5F;
         double dx = tx - this.bot.getX();
         double dy = ty - this.bot.getEyeY();
         double dz = tz - this.bot.getZ();
         double horiz = Math.sqrt(dx * dx + dz * dz);
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
         this.bot.setYRot(yaw);
         this.bot.yHeadRot = yaw;
         this.bot.setXRot(pitch);
      }
   }

   private Supply itemSupply(String key, BooleanSupplier relevant, int lowAt, Predicate<ItemStack> matches, Item... items) {
      return new Supply(key, relevant, () -> this.sumInInventory(items), lowAt, matches, items, false, (Item[])null);
   }

   private int sumInInventory(Item[] items) {
      int n = 0;

      for(Item item : items) {
         n += this.countInInventory(item);
      }

      return n;
   }

   private List<Supply> buildSupplies() {
      List<Supply> s = new ArrayList();
      s.add(new Supply("food", (BooleanSupplier)null, this::countFood, 2, (st) -> st.has(DataComponents.FOOD), (Item[])null, true, (Item[])null));
      s.add(new Supply("arrows", this::hasBowInHotbar, this::countArrows, 4, (st) -> st.is(ItemTags.ARROWS), (Item[])null, true, (Item[])null));
      s.add(this.itemSupply("ender_pearl", (BooleanSupplier)null, 2, (st) -> st.is(Items.ENDER_PEARL), Items.ENDER_PEARL));
      s.add(this.itemSupply("totem", (BooleanSupplier)null, 1, (st) -> st.is(Items.TOTEM_OF_UNDYING), Items.TOTEM_OF_UNDYING));
      s.add(this.itemSupply("throw_potion", (BooleanSupplier)null, 2, (st) -> st.is(Items.SPLASH_POTION) || st.is(Items.LINGERING_POTION), Items.SPLASH_POTION, Items.LINGERING_POTION));
      s.add(this.itemSupply("water_bucket", (BooleanSupplier)null, 1, (st) -> st.is(Items.WATER_BUCKET), Items.WATER_BUCKET));
      s.add(this.itemSupply("wind_charge", (BooleanSupplier)null, 2, (st) -> st.is(Items.WIND_CHARGE), Items.WIND_CHARGE));
      s.add(this.itemSupply("cobweb", (BooleanSupplier)null, 2, (st) -> st.is(Items.COBWEB), Items.COBWEB));
      s.add(this.itemSupply("end_crystal", (BooleanSupplier)null, 2, (st) -> st.is(Items.END_CRYSTAL), Items.END_CRYSTAL));
      s.add(this.itemSupply("respawn_anchor", (BooleanSupplier)null, 1, (st) -> st.is(Items.RESPAWN_ANCHOR), Items.RESPAWN_ANCHOR));
      s.add(new Supply("carts", () -> EffectiveSettings.of(this.botName).useCarting(), () -> Math.min(this.countInInventory(Items.TNT_MINECART), this.countRailsInInventory()), 3, (st) -> st.is(Items.TNT_MINECART) || isRailItem(st.getItem()), (Item[])null, true, new Item[]{Items.TNT_MINECART}));
      s.add(new Supply("armor", (BooleanSupplier)null, this::countWornArmor, 4, ArmorEvaluator::isArmor, (Item[])null, false, (Item[])null));
      s.add(new Supply("weapon", (BooleanSupplier)null, this::countWeapons, 1, (st) -> st.is(ItemTags.SWORDS) || st.is(ItemTags.AXES) || st.is(ItemTags.SPEARS) || st.is(Items.MACE) || st.is(Items.TRIDENT), (Item[])null, true, (Item[])null));
      s.add(new Supply("shield", (BooleanSupplier)null, this::countUsableShields, 1, (st) -> st.is(Items.SHIELD), (Item[])null, true, new Item[]{Items.SHIELD}));
      s.add(this.itemSupply("rockets", this::hasElytra, 2, (st) -> st.is(Items.FIREWORK_ROCKET), Items.FIREWORK_ROCKET));
      s.add(this.itemSupply("obsidian", (BooleanSupplier)null, 2, (st) -> st.is(Items.OBSIDIAN), Items.OBSIDIAN));
      s.add(this.itemSupply("glowstone", (BooleanSupplier)null, 2, (st) -> st.is(Items.GLOWSTONE), Items.GLOWSTONE));
      s.add(new Supply("blocks", (BooleanSupplier)null, this::countBuildingBlocks, 8, (st) -> st.is(ItemTags.PLANKS) || st.is(Items.COBBLESTONE) || st.is(Items.DIRT) || st.is(Items.END_STONE) || st.is(Items.OBSIDIAN), (Item[])null, true, (Item[])null));
      s.add(this.itemSupply("xp_bottle", (BooleanSupplier)null, 4, (st) -> st.is(Items.EXPERIENCE_BOTTLE), Items.EXPERIENCE_BOTTLE));
      s.add(this.itemSupply("gapple", (BooleanSupplier)null, 2, (st) -> st.is(Items.GOLDEN_APPLE) || st.is(Items.ENCHANTED_GOLDEN_APPLE), Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE));
      return s;
   }

   private static boolean isRelevant(Supply s) {
      return s.relevant() == null || s.relevant().getAsBoolean();
   }

   private int count(Supply s) {
      return s.items() != null ? this.sumInInventory(s.items()) : s.count().getAsInt();
   }

   private boolean stockedNow(Supply s) {
      if (s.carried()) {
         if (this.tallySize == 0) {
            return false;
         }

         if (s.needs() != null && !this.anyTallied(s.needs())) {
            return false;
         }
      }

      return this.count(s) >= s.lowAt();
   }

   private boolean anyTallied(Item[] items) {
      for(Item item : items) {
         for(int j = 0; j < this.tallySize; ++j) {
            if (this.tallyItems[j] == item) {
               return true;
            }
         }
      }

      return false;
   }

   private int countBuildingBlocks() {
      int n = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack st = this.stackAt(i);
         if (!st.isEmpty() && (st.is(ItemTags.PLANKS) || st.is(Items.COBBLESTONE) || st.is(Items.DIRT) || st.is(Items.END_STONE) || st.is(Items.OBSIDIAN))) {
            n += st.getCount();
         }
      }

      return n;
   }

   private int countWornArmor() {
      int n = 0;

      for(EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
         ItemStack worn = this.bot.getItemBySlot(slot);
         if (this.isServiceable(worn)) {
            ++n;
         }
      }

      return n;
   }

   private int countUsableShields() {
      int n = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack st = this.stackAt(i);
         if (st.is(Items.SHIELD) && this.isServiceable(st)) {
            ++n;
         }
      }

      ItemStack off = this.bot.getOffhandItem();
      if (off.is(Items.SHIELD) && this.isServiceable(off)) {
         ++n;
      }

      return n;
   }

   private int countWeapons() {
      int n = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack st = this.stackAt(i);
         if (!st.isEmpty() && this.isServiceable(st) && (st.is(ItemTags.SWORDS) || st.is(ItemTags.AXES) || st.is(ItemTags.SPEARS) || st.is(Items.MACE) || st.is(Items.TRIDENT))) {
            ++n;
         }
      }

      return n;
   }

   private boolean hasElytra() {
      if (this.bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA)) {
         return true;
      } else {
         return this.countInInventory(Items.ELYTRA) > 0;
      }
   }

   private void updateBaseline() {
      try {
         for(int i = 0; i < this.everStocked.length; ++i) {
            if (!this.everStocked[i]) {
               Supply s = (Supply)this.supplies.get(i);
               if (this.tallySize < 0) {
                  this.openCheck();
               }

               if (isRelevant(s) && this.stockedNow(s)) {
                  this.everStocked[i] = true;
               }
            }
         }
      } finally {
         this.tallySize = -1;
      }

   }

   private List<Supply> currentLow() {
      List<Supply> low = new ArrayList();
      this.openCheck();

      try {
         for(int i = 0; i < this.everStocked.length; ++i) {
            Supply s = (Supply)this.supplies.get(i);
            if (isRelevant(s) && this.everStocked[i] && this.count(s) < s.lowAt()) {
               low.add(s);
            }
         }
      } finally {
         this.tallySize = -1;
      }

      return low;
   }

   private void openCheck() {
      Inventory inv = this.bot.getInventory();
      int n = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         this.checkStacks[i] = st;
         n = this.tallyAdd(n, st);
      }

      this.tallySize = this.tallyAdd(n, this.bot.getOffhandItem());
   }

   private int tallyAdd(int n, ItemStack st) {
      if (st.isEmpty()) {
         return n;
      } else {
         Item item = st.getItem();

         for(int j = 0; j < n; ++j) {
            if (this.tallyItems[j] == item) {
               int[] var10000 = this.tallyCounts;
               var10000[j] += st.getCount();
               return n;
            }
         }

         this.tallyItems[n] = item;
         this.tallyCounts[n] = st.getCount();
         return n + 1;
      }
   }

   private int tallied(Item item) {
      for(int j = 0; j < this.tallySize; ++j) {
         if (this.tallyItems[j] == item) {
            return this.tallyCounts[j];
         }
      }

      return 0;
   }

   private ItemStack stackAt(int i) {
      return this.tallySize >= 0 ? this.checkStacks[i] : this.bot.getInventory().getItem(i);
   }

   private static Set<String> keySet(List<Supply> supplies) {
      Set<String> out = new HashSet();

      for(Supply s : supplies) {
         out.add(s.key());
      }

      return out;
   }

   private double wornArmorScore() {
      double total = (double)0.0F;

      for(EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
         ItemStack worn = this.bot.getItemBySlot(slot);
         if (!worn.isEmpty()) {
            total += ArmorEvaluator.score(worn);
         }
      }

      return total;
   }

   private List<Supply> shulkerUpgrade() {
      if (!Double.isNaN(this.lastUpgradeWornScore) && this.wornArmorScore() == this.lastUpgradeWornScore) {
         return List.of();
      } else {
         Inventory inv = this.bot.getInventory();
         boolean wantArmor = false;
         boolean wantTotem = false;
         boolean noTotem = this.countInInventory(Items.TOTEM_OF_UNDYING) == 0;

         for(int i = 0; i < 36 && (!wantArmor || !wantTotem); ++i) {
            ItemStack box = inv.getItem(i);
            if (this.isShulkerBox(box)) {
               ItemContainerContents contents = (ItemContainerContents)box.get(DataComponents.CONTAINER);
               if (contents != null) {
                  for(ItemStack st : McCompat.nonEmptyItems(contents)) {
                     if (noTotem && st.is(Items.TOTEM_OF_UNDYING)) {
                        wantTotem = true;
                     } else if (ArmorEvaluator.isArmor(st)) {
                        EquipmentSlot slot = ArmorEvaluator.getSlot(st);
                        if (slot != null) {
                           ItemStack worn = this.bot.getItemBySlot(slot);
                           double wornScore = worn.isEmpty() ? Double.NEGATIVE_INFINITY : ArmorEvaluator.score(worn);
                           if (ArmorEvaluator.score(st) > wornScore) {
                              wantArmor = true;
                           }
                        }
                     }
                  }
               }
            }
         }

         if (!wantArmor && !wantTotem) {
            return List.of();
         } else {
            List<Supply> out = new ArrayList();

            for(Supply s : this.supplies) {
               if (wantArmor && "armor".equals(s.key())) {
                  out.add(s);
               }

               if (wantTotem && "totem".equals(s.key())) {
                  out.add(s);
               }
            }

            if (!out.isEmpty()) {
               VexLog.brief(LOGGER, "[Restock] {} has an upgrade waiting in a carried shulker ({})", this.botName, keySet(out));
            }

            return out;
         }
      }
   }

   private int findShulkerSlot(List<Supply> missing) {
      if (missing != null && !missing.isEmpty()) {
         Inventory inv = this.bot.getInventory();
         if (keySet(missing).contains("armor")) {
            for(int i = 0; i < 36; ++i) {
               ItemStack stack = inv.getItem(i);
               if (this.isShulkerBox(stack) && this.holdsArmorUpgrade(stack)) {
                  return i;
               }
            }
         }

         for(int i = 0; i < 36; ++i) {
            ItemStack stack = inv.getItem(i);
            if (this.isShulkerBox(stack) && this.shulkerSuppliesAny(stack, missing)) {
               return i;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private boolean holdsArmorUpgrade(ItemStack shulker) {
      ItemContainerContents contents = (ItemContainerContents)shulker.get(DataComponents.CONTAINER);
      if (contents == null) {
         return false;
      } else {
         for(ItemStack st : McCompat.nonEmptyItems(contents)) {
            EquipmentSlot slot = ArmorEvaluator.getSlot(st);
            if (slot != null && !isNearlyBroken(st) && ArmorEvaluator.score(st) > this.bestHeldArmorScore(slot)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean shulkerSuppliesAny(ItemStack shulker, List<Supply> missing) {
      ItemContainerContents contents = (ItemContainerContents)shulker.get(DataComponents.CONTAINER);
      if (contents == null) {
         return false;
      } else {
         for(ItemStack s : McCompat.nonEmptyItems(contents)) {
            for(Supply sup : missing) {
               if (sup.matches().test(s)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private int findKitPotion() {
      for(int i = 0; i < 36; ++i) {
         String kitName = KitPotion.getKitName(this.bot.getInventory().getItem(i));
         if (kitName != null && !this.missingKits.contains(kitName)) {
            return i;
         }
      }

      return -1;
   }

   private boolean useKitPotion(int slot) {
      ItemStack stack = this.bot.getInventory().getItem(slot);
      String kitName = KitPotion.getKitName(stack);
      if (kitName == null) {
         return false;
      } else if (!KitManager.give(this.server, this.bot, kitName)) {
         this.missingKits.add(kitName);
         LOGGER.warn("[Restock] {} carries a kit potion for '{}' but that kit does not exist — skipping it", this.botName, kitName);
         return false;
      } else {
         VexLog.detail(LOGGER, "[Restock] {} used kit potion '{}' to restock", this.botName, kitName);
         return true;
      }
   }

   private boolean enderRegearEnabled() {
      return EffectiveSettings.of(this.botName).enderChestRegear();
   }

   private int findEnderChestSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.ENDER_CHEST)) {
            return i;
         }
      }

      return -1;
   }

   private int findEnderShulkerSlot(List<Supply> missing) {
      if (missing != null && !missing.isEmpty()) {
         PlayerEnderChestContainer ec = this.bot.getEnderChestInventory();

         for(int i = 0; i < ec.getContainerSize(); ++i) {
            ItemStack stack = ec.getItem(i);
            if (this.isShulkerBox(stack) && this.shulkerSuppliesAny(stack, missing)) {
               return i;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private boolean doPlaceEnderChest() {
      ServerLevel var2 = this.bot.level();
      if (var2 instanceof ServerLevel) {
         ServerLevel sl = var2;
         int chestSlot = this.findEnderChestSlot();
         if (chestSlot < 0) {
            return false;
         } else {
            BlockPos pos = this.findSidePlacementPos();
            if (pos == null) {
               LOGGER.warn("[Restock] {} — nowhere beside it to put the ender chest", this.botName);
               return false;
            } else {
               ItemStack chestItem = this.bot.getInventory().getItem(chestSlot).copy();
               sl.setBlock(pos, Blocks.ENDER_CHEST.defaultBlockState(), 3);
               if (!sl.getBlockState(pos).is(Blocks.ENDER_CHEST)) {
                  return false;
               } else {
                  this.bot.getInventory().setItem(chestSlot, ItemStack.EMPTY);
                  this.placedEnder = chestItem;
                  this.enderPos = pos;
                  WebPlacer.lookAt(this.bot, pos);
                  McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                  sl.playSound((Entity)null, pos, SoundEvents.ENDER_CHEST_OPEN, SoundSource.BLOCKS, 0.7F, 1.0F);
                  VexLog.detail(LOGGER, "[Restock] {} put its ender chest down at {}", this.botName, pos);
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private BlockPos findSidePlacementPos() {
      double lx = this.bot.getLookAngle().x;
      double lz = this.bot.getLookAngle().z;
      int leftX = (int)Math.round(-lz);
      int leftZ = (int)Math.round(lx);
      int rightX = -leftX;
      int rightZ = -leftZ;

      for(int[] d : new int[][]{{leftX, leftZ}, {rightX, rightZ}}) {
         if (d[0] != 0 || d[1] != 0) {
            BlockPos spot = this.groundedSpot(this.bot.blockPosition().offset(d[0], 0, d[1]));
            if (spot != null) {
               return spot;
            }
         }
      }

      return this.findPlacementPos();
   }

   private boolean takeShulkerFromEnder() {
      int slot = this.findEnderShulkerSlot(this.activeMissing != null ? this.activeMissing : this.currentLow());
      if (slot < 0) {
         return false;
      } else {
         PlayerEnderChestContainer ec = this.bot.getEnderChestInventory();
         ItemStack box = ec.getItem(slot).copy();
         if (box.isEmpty()) {
            return false;
         } else if (!this.bot.getInventory().add(box)) {
            return false;
         } else {
            ec.setItem(slot, ItemStack.EMPTY);
            this.enderSlotUsed = slot;
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            VexLog.detail(LOGGER, "[Restock] {} took a shulker out of its ender chest", this.botName);
            return true;
         }
      }
   }

   private boolean enderHasLoose(List<Supply> missing) {
      if (missing != null && !missing.isEmpty()) {
         PlayerEnderChestContainer ec = this.bot.getEnderChestInventory();

         for(int i = 0; i < ec.getContainerSize(); ++i) {
            ItemStack stack = ec.getItem(i);
            if (!stack.isEmpty() && !this.isShulkerBox(stack)) {
               for(Supply sup : missing) {
                  if (sup.matches().test(stack)) {
                     return true;
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private int takeLooseFromEnder() {
      List<Supply> missing = this.activeMissing != null ? this.activeMissing : this.currentLow();
      if (missing != null && !missing.isEmpty()) {
         PlayerEnderChestContainer ec = this.bot.getEnderChestInventory();
         Inventory inv = this.bot.getInventory();
         int taken = 0;

         for(int i = 0; i < ec.getContainerSize(); ++i) {
            ItemStack src = ec.getItem(i);
            if (!src.isEmpty() && !this.isShulkerBox(src)) {
               boolean wanted = false;

               for(Supply sup : missing) {
                  if (sup.matches().test(src)) {
                     wanted = true;
                     break;
                  }
               }

               if (wanted) {
                  int want = this.wantFor(src);
                  if (want > 0) {
                     ItemStack move = src.copy();
                     move.setCount(Math.min(want, src.getCount()));
                     int offered = move.getCount();
                     inv.add(move);
                     int moved = offered - move.getCount();
                     if (moved > 0) {
                        src.shrink(moved);
                        if (src.isEmpty()) {
                           ec.setItem(i, ItemStack.EMPTY);
                        }

                        ++taken;
                     }
                  }
               }
            }
         }

         if (taken > 0) {
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            this.equipBetterArmor();
            VexLog.detail(LOGGER, "[Restock] {} took {} loose stack(s) from its ender chest", this.botName, taken);
         }

         return taken;
      } else {
         return 0;
      }
   }

   private void stowShulkerInEnder() {
      PlayerEnderChestContainer ec = this.bot.getEnderChestInventory();
      Inventory inv = this.bot.getInventory();
      int i = this.returnedBoxSlot;
      this.returnedBoxSlot = -1;
      if (i >= 0 && i < 36) {
         ItemStack stack = inv.getItem(i);
         if (this.isShulkerBox(stack)) {
            int dest = this.enderSlotUsed >= 0 && ec.getItem(this.enderSlotUsed).isEmpty() ? this.enderSlotUsed : this.firstEmptyEnderSlot(ec);
            if (dest >= 0) {
               ec.setItem(dest, stack.copy());
               inv.setItem(i, ItemStack.EMPTY);
               McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
               VexLog.detail(LOGGER, "[Restock] {} put the shulker back in its ender chest", this.botName);
            }
         }
      }
   }

   private int firstEmptyEnderSlot(Container ec) {
      for(int i = 0; i < ec.getContainerSize(); ++i) {
         if (ec.getItem(i).isEmpty()) {
            return i;
         }
      }

      return -1;
   }

   private void mineEnderChest() {
      if (this.enderPos != null) {
         ServerLevel sl = this.bot.level();
         if (sl instanceof ServerLevel && sl.getBlockState(this.enderPos).is(Blocks.ENDER_CHEST)) {
            WebPlacer.lookAt(this.bot, this.enderPos);
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            sl.playSound((Entity)null, this.enderPos, SoundEvents.ENDER_CHEST_CLOSE, SoundSource.BLOCKS, 0.7F, 1.0F);
            sl.setBlock(this.enderPos, Blocks.AIR.defaultBlockState(), 3);
            Stats.inc("blocks_mined");
            ItemStack back = this.placedEnder.isEmpty() ? new ItemStack(Items.ENDER_CHEST) : this.placedEnder;
            if (this.bot.isDeadOrDying() || !this.bot.getInventory().add(back.copy())) {
               McCompat.drop(this.bot, back.copy(), false);
            }

            VexLog.detail(LOGGER, "[Restock] {} took its ender chest back up", this.botName);
         }

         this.enderPos = null;
         this.placedEnder = ItemStack.EMPTY;
         this.enderSlotUsed = -1;
      }
   }

   private BlockPos findPlacementPos() {
      double dx = this.bot.getLookAngle().x;
      double dz = this.bot.getLookAngle().z;
      int offX;
      int offZ;
      if (Math.abs(dx) >= Math.abs(dz)) {
         offX = dx > (double)0.0F ? 1 : -1;
         offZ = 0;
      } else {
         offX = 0;
         offZ = dz > (double)0.0F ? 1 : -1;
      }

      int[][] dirs = new int[][]{{offX, offZ}, {offZ, offX}, {-offZ, -offX}, {-offX, -offZ}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}};

      for(int[] d : dirs) {
         if (d[0] != 0 || d[1] != 0) {
            BlockPos col = this.bot.blockPosition().offset(d[0], 0, d[1]);
            BlockPos spot = this.groundedSpot(col);
            if (spot != null) {
               return spot;
            }
         }
      }

      return null;
   }

   private BlockPos groundedSpot(BlockPos col) {
      for(int dy = 0; dy <= 5; ++dy) {
         BlockPos pos = col.below(dy);
         BlockPos below = pos.below();
         if (this.bot.level().getBlockState(pos).isAir()) {
            boolean supported = !this.bot.level().getBlockState(below).getCollisionShape(this.bot.level(), below).isEmpty();
            if (supported) {
               return pos;
            }
         }
      }

      return null;
   }

   private boolean isShulkerBox(ItemStack stack) {
      boolean var10000;
      if (!stack.isEmpty()) {
         Item var3 = stack.getItem();
         if (var3 instanceof BlockItem) {
            BlockItem bi = (BlockItem)var3;
            if (bi.getBlock() instanceof ShulkerBoxBlock) {
               var10000 = true;
               return var10000;
            }
         }
      }

      var10000 = false;
      return var10000;
   }

   private int carryTarget(ItemStack st) {
      TeamManager.BotTeam team = TeamManager.getTeamForBot(this.botName);
      int override = RestockPlan.carryTarget(team == null ? null : team.getName(), st);
      return override > 0 ? override : builtInTarget(st);
   }

   public static int builtInTarget(ItemStack st) {
      Item item = st.getItem();
      if (item == Items.TOTEM_OF_UNDYING) {
         return 4;
      } else if (item == Items.ENDER_PEARL) {
         return 32;
      } else if (item != Items.GOLDEN_APPLE && item != Items.ENCHANTED_GOLDEN_APPLE) {
         if (item == Items.GOLDEN_CARROT) {
            return 32;
         } else if (item == Items.EXPERIENCE_BOTTLE) {
            return 64;
         } else if (item == Items.FIREWORK_ROCKET) {
            return 32;
         } else if (item == Items.WIND_CHARGE) {
            return 16;
         } else if (item == Items.END_CRYSTAL) {
            return 16;
         } else if (item == Items.OBSIDIAN) {
            return 16;
         } else if (item == Items.GLOWSTONE) {
            return 8;
         } else if (item == Items.RESPAWN_ANCHOR) {
            return 2;
         } else if (item == Items.COBWEB) {
            return 16;
         } else if (item == Items.WATER_BUCKET) {
            return 2;
         } else if (item != Items.MILK_BUCKET && item != Items.HONEY_BOTTLE) {
            if (item == Items.CHORUS_FRUIT) {
               return 8;
            } else if (item == Items.BREEZE_ROD) {
               return 8;
            } else if (item == Items.SHULKER_SHELL) {
               return 4;
            } else if (item != Items.SPLASH_POTION && item != Items.LINGERING_POTION) {
               if (item == Items.TNT_MINECART) {
                  return 12;
               } else if (isRailItem(item)) {
                  return 16;
               } else if (item == Items.FLINT_AND_STEEL) {
                  return 1;
               } else if (item == Items.SHIELD) {
                  return 2;
               } else if (item == Items.ELYTRA) {
                  return 1;
               } else if (st.is(ItemTags.PICKAXES)) {
                  return 1;
               } else if (item == Items.SHEARS) {
                  return 1;
               } else if (st.is(ItemTags.ARROWS)) {
                  return 64;
               } else if (st.has(DataComponents.FOOD)) {
                  return 32;
               } else if (!st.is(ItemTags.SWORDS) && !st.is(ItemTags.AXES) && !st.is(ItemTags.SPEARS) && item != Items.MACE && item != Items.TRIDENT && item != Items.BOW && item != Items.CROSSBOW) {
                  if (ArmorEvaluator.isArmor(st)) {
                     return 4;
                  } else if (KitPotion.getKitName(st) != null) {
                     return 1;
                  } else if (item == Items.BUCKET) {
                     return 1;
                  } else if (item == Items.POTION) {
                     return 4;
                  } else if (item != Items.SNOWBALL && item != Items.EGG) {
                     if (item != Items.FIRE_CHARGE && item != Items.TNT) {
                        if (item != Items.SLIME_BLOCK && item != Items.HAY_BLOCK) {
                           if (item == Items.LADDER) {
                              return 16;
                           } else {
                              return !st.is(ItemTags.PLANKS) && item != Items.COBBLESTONE && item != Items.DIRT && item != Items.END_STONE ? 8 : 64;
                           }
                        } else {
                           return 4;
                        }
                     } else {
                        return 8;
                     }
                  } else {
                     return 16;
                  }
               } else {
                  return 2;
               }
            } else {
               return 6;
            }
         } else {
            return 2;
         }
      } else {
         return 32;
      }
   }

   private int countHeldLike(ItemStack st) {
      Item item = st.getItem();
      boolean armour = ArmorEvaluator.isArmor(st);
      boolean weapon = st.is(ItemTags.SWORDS) || st.is(ItemTags.AXES) || st.is(ItemTags.SPEARS) || item == Items.MACE || item == Items.TRIDENT || item == Items.BOW || item == Items.CROSSBOW;
      int n = 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 41; ++i) {
         ItemStack held = inv.getItem(i);
         if (!held.isEmpty()) {
            if (armour) {
               if (ArmorEvaluator.isArmor(held) && this.isServiceable(held)) {
                  n += held.getCount();
               }
            } else if (weapon) {
               if ((held.is(ItemTags.SWORDS) || held.is(ItemTags.AXES) || held.is(ItemTags.SPEARS) || held.is(Items.MACE) || held.is(Items.TRIDENT) || held.is(Items.BOW) || held.is(Items.CROSSBOW)) && this.isServiceable(held)) {
                  n += held.getCount();
               }
            } else if (held.is(item)) {
               n += held.getCount();
            }
         }
      }

      return n;
   }

   private boolean isNeededItem(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         EffectiveSettings es = EffectiveSettings.of(this.botName);
         Item item = stack.getItem();
         if (item == Items.ENDER_CHEST) {
            return true;
         } else if (this.isShulkerBox(stack)) {
            return true;
         } else if (stack.has(DataComponents.FOOD)) {
            return true;
         } else if (stack.is(ItemTags.ARROWS)) {
            return true;
         } else if (item == Items.WIND_CHARGE) {
            return true;
         } else if (item == Items.COBWEB) {
            return true;
         } else if (item == Items.WATER_BUCKET) {
            return true;
         } else if (item == Items.TOTEM_OF_UNDYING) {
            return true;
         } else if (item != Items.SPLASH_POTION && item != Items.LINGERING_POTION) {
            if (item == Items.GLOWSTONE) {
               return true;
            } else if (!es.useCarting() || item != Items.TNT_MINECART && !isRailItem(item) && item != Items.FLINT_AND_STEEL) {
               if (item != Items.END_CRYSTAL && item != Items.OBSIDIAN) {
                  if (item == Items.RESPAWN_ANCHOR) {
                     return true;
                  } else if (item == Items.ENDER_PEARL) {
                     return true;
                  } else if (item == Items.EXPERIENCE_BOTTLE) {
                     return true;
                  } else if (item == Items.BREEZE_ROD) {
                     return true;
                  } else if (item == Items.FIREWORK_ROCKET) {
                     return true;
                  } else if (item == Items.CHORUS_FRUIT) {
                     return true;
                  } else if (stack.is(ItemTags.PICKAXES)) {
                     return true;
                  } else if (ArmorEvaluator.isArmor(stack)) {
                     return true;
                  } else if (KitPotion.getKitName(stack) != null) {
                     return true;
                  } else if (!stack.is(ItemTags.SWORDS) && !stack.is(ItemTags.AXES) && !stack.is(ItemTags.SPEARS)) {
                     if (item != Items.MACE && item != Items.TRIDENT) {
                        if (item != Items.BOW && item != Items.CROSSBOW) {
                           if (item == Items.SHIELD) {
                              return true;
                           } else if (item == Items.ELYTRA) {
                              return true;
                           } else if (item == Items.HONEY_BOTTLE) {
                              return true;
                           } else if (item == Items.MILK_BUCKET) {
                              return true;
                           } else if (item == Items.SHULKER_SHELL) {
                              return true;
                           } else if (item == Items.SHEARS) {
                              return true;
                           } else if (item == Items.BUCKET) {
                              return true;
                           } else if (item != Items.SNOWBALL && item != Items.EGG) {
                              if (item == Items.POTION) {
                                 return true;
                              } else if (item == Items.FIRE_CHARGE) {
                                 return true;
                              } else if (item == Items.TNT) {
                                 return true;
                              } else if (item == Items.SLIME_BLOCK) {
                                 return true;
                              } else if (item == Items.HAY_BLOCK) {
                                 return true;
                              } else if (item == Items.LADDER) {
                                 return true;
                              } else {
                                 return stack.is(ItemTags.PLANKS) || item == Items.COBBLESTONE || item == Items.DIRT || item == Items.END_STONE;
                              }
                           } else {
                              return true;
                           }
                        } else {
                           return true;
                        }
                     } else {
                        return true;
                     }
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      }
   }

   private boolean isUsefulItem(ItemStack stack) {
      if (stack.isEmpty()) {
         return true;
      } else if ((ArmorEvaluator.isArmor(stack) || isWeaponLike(stack) || stack.is(Items.SHIELD)) && isWornOut(stack) && !this.canMendInstead(stack)) {
         return false;
      } else if (this.isNeededItem(stack)) {
         return true;
      } else if (this.isShulkerBox(stack)) {
         return true;
      } else {
         Item item = stack.getItem();
         if (stack.is(ItemTags.SWORDS)) {
            return true;
         } else if (stack.is(ItemTags.AXES)) {
            return true;
         } else if (stack.is(ItemTags.PICKAXES)) {
            return true;
         } else if (stack.is(ItemTags.SPEARS)) {
            return true;
         } else if (item != Items.BOW && item != Items.CROSSBOW) {
            if (item != Items.MACE && item != Items.TRIDENT) {
               if (item == Items.BREEZE_ROD) {
                  return true;
               } else if (ArmorEvaluator.isArmor(stack)) {
                  return true;
               } else if (item == Items.SHIELD) {
                  return true;
               } else {
                  return item == Items.ENDER_PEARL;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      }
   }

   private boolean hasEnderPearl() {
      return this.countInInventory(Items.ENDER_PEARL) > 0;
   }

   private int countInInventory(Item item) {
      if (this.tallySize >= 0) {
         return this.tallied(item);
      } else {
         int count = 0;

         for(int i = 0; i < 36; ++i) {
            ItemStack stack = this.bot.getInventory().getItem(i);
            if (stack.is(item)) {
               count += stack.getCount();
            }
         }

         ItemStack off = this.bot.getOffhandItem();
         if (off.is(item)) {
            count += off.getCount();
         }

         return count;
      }
   }

   private int countRailsInInventory() {
      if (this.tallySize >= 0) {
         return this.tallied(Items.RAIL) + this.tallied(Items.POWERED_RAIL) + this.tallied(Items.DETECTOR_RAIL) + this.tallied(Items.ACTIVATOR_RAIL);
      } else {
         int count = 0;

         for(int i = 0; i < 36; ++i) {
            ItemStack stack = this.bot.getInventory().getItem(i);
            if (isRailItem(stack.getItem())) {
               count += stack.getCount();
            }
         }

         ItemStack off = this.bot.getOffhandItem();
         if (isRailItem(off.getItem())) {
            count += off.getCount();
         }

         return count;
      }
   }

   private static boolean isRailItem(Item item) {
      return item == Items.RAIL || item == Items.POWERED_RAIL || item == Items.DETECTOR_RAIL || item == Items.ACTIVATOR_RAIL;
   }

   private int countFood() {
      int count = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack stack = this.stackAt(i);
         if (stack.has(DataComponents.FOOD)) {
            count += stack.getCount();
         }
      }

      ItemStack off = this.bot.getOffhandItem();
      if (off.has(DataComponents.FOOD)) {
         count += off.getCount();
      }

      return count;
   }

   private int countArrows() {
      int count = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack s = this.stackAt(i);
         if (s.is(ItemTags.ARROWS)) {
            count += s.getCount();
         }
      }

      ItemStack off = this.bot.getOffhandItem();
      if (off.is(ItemTags.ARROWS)) {
         count += off.getCount();
      }

      return count;
   }

   private boolean hasBowInHotbar() {
      for(int i = 0; i < 9; ++i) {
         Item item = this.stackAt(i).getItem();
         if (item == Items.BOW || item == Items.CROSSBOW) {
            return true;
         }
      }

      return false;
   }

   private int freeSlots() {
      Inventory inv = this.bot.getInventory();
      int n = 0;

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).isEmpty()) {
            ++n;
         }
      }

      return n;
   }

   private boolean canMergeExisting(ItemStack stack) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack existing = inv.getItem(i);
         if (!existing.isEmpty() && ItemStack.isSameItemSameComponents(existing, stack) && existing.getCount() < existing.getMaxStackSize()) {
            return true;
         }
      }

      return false;
   }

   private int roomKeepingReserve(ItemStack stack) {
      Inventory inv = this.bot.getInventory();
      int room = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack existing = inv.getItem(i);
         if (!existing.isEmpty() && ItemStack.isSameItemSameComponents(existing, stack)) {
            room += Math.max(0, existing.getMaxStackSize() - existing.getCount());
         }
      }

      room += Math.max(0, this.freeSlots() - 2) * stack.getMaxStackSize();
      return room;
   }

   private ItemStack addToInventory(ItemStack stack) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36 && !stack.isEmpty(); ++i) {
         ItemStack existing = inv.getItem(i);
         if (!existing.isEmpty() && ItemStack.isSameItemSameComponents(existing, stack)) {
            int space = existing.getMaxStackSize() - existing.getCount();
            if (space > 0) {
               int take = Math.min(space, stack.getCount());
               existing.grow(take);
               stack.shrink(take);
            }
         }
      }

      for(int i = 0; i < 36 && !stack.isEmpty(); ++i) {
         if (inv.getItem(i).isEmpty()) {
            inv.setItem(i, stack.copy());
            return ItemStack.EMPTY;
         }
      }

      return stack;
   }

   private static enum Phase {
      IDLE,
      PEARL_WAIT,
      ELYTRA_LAUNCH,
      PLACE_ENDER,
      TAKE_SHULKER,
      PLACE,
      OPEN,
      MINE,
      COLLECT,
      STOW_SHULKER,
      MINE_ENDER;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, PEARL_WAIT, ELYTRA_LAUNCH, PLACE_ENDER, TAKE_SHULKER, PLACE, OPEN, MINE, COLLECT, STOW_SHULKER, MINE_ENDER};
      }
   }

   private static record PlacedBox(String owner, Level level) {
   }

   private static record Supply(String key, BooleanSupplier relevant, IntSupplier count, int lowAt, Predicate<ItemStack> matches, Item[] items, boolean carried, Item[] needs) {
   }
}
