package vexbot.bot.ai;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.VexBot;
import vexbot.team.TeamManager;
import vexbot.util.VexLog;

public final class MaceDiveForecast {
   private static final double SCAN_RANGE = (double)48.0F;
   private static final double MIN_HEIGHT = (double)1.5F;
   private static final double REACH = 3.3;
   private static final double SMASH_FALL = (double)1.5F;
   private static final int HORIZON = 40;
   private final ServerPlayer bot;
   private final String botName;
   private final Map<UUID, Vec3> lastPos = new HashMap();
   private final Map<UUID, Vec3> vel = new HashMap();
   private final Map<UUID, Dive> dives = new HashMap();
   private long lastTick = Long.MIN_VALUE;
   private Dive soonest = null;
   private UUID reported = null;

   MaceDiveForecast(ServerPlayer bot, String botName) {
      this.bot = bot;
      this.botName = botName;
   }

   Dive soonest() {
      return this.soonest;
   }

   Dive of(Entity diver) {
      return diver == null ? null : (Dive)this.dives.get(diver.getUUID());
   }

   void update() {
      long now = this.bot.level().getGameTime();
      if (now != this.lastTick) {
         long gap = this.lastTick == Long.MIN_VALUE ? 0L : now - this.lastTick;
         this.lastTick = now;
         this.dives.clear();
         this.soonest = null;
         Vec3 me = this.bot.position();
         double r2 = (double)2304.0F;
         boolean tracking = !this.lastPos.isEmpty();
         List<? extends Player> players = this.bot.level().players();
         OffGround air = tracking ? null : MaceDiveForecast.OffGround.of(this.bot.level(), players);
         if (air == null) {
            for(Player p : players) {
               this.visit(p, me, r2, tracking, gap);
            }
         } else {
            int n = air.upCount();
            int[] idx = air.upIdx;

            for(int k = 0; k < n; ++k) {
               this.visit(air.players[idx[k]], me, r2, false, gap);
            }
         }

         if (this.soonest != null && !this.soonest.diver().getUUID().equals(this.reported)) {
            this.reported = this.soonest.diver().getUUID();
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' sees {} diving on it: strike in {} ticks, ~{} damage", this.botName, this.soonest.diver().getScoreboardName(), this.soonest.ticks(), String.format("%.1f", this.soonest.damage()));
         } else if (this.soonest == null) {
            this.reported = null;
         }

         if (this.lastPos.size() > 128) {
            this.lastPos.clear();
            this.vel.clear();
         }

      }
   }

   private void visit(Player p, Vec3 me, double r2, boolean tracking, long gap) {
      if (p != this.bot) {
         boolean candidate = !p.onGround() && p.getY() - me.y >= (double)1.5F && p.distanceToSqr(this.bot) <= r2;
         if (candidate || tracking) {
            if (p.isAlive() && !p.isSpectator() && !p.isCreative()) {
               UUID id = p.getUUID();
               if (!candidate) {
                  if (this.lastPos.remove(id) != null) {
                     this.vel.remove(id);
                  }

               } else {
                  Vec3 pos = p.position();
                  Vec3 prev = (Vec3)this.lastPos.put(id, pos);
                  Vec3 v = (Vec3)this.vel.getOrDefault(id, Vec3.ZERO);
                  if (prev != null) {
                     if (gap > 0L) {
                        Vec3 step = pos.subtract(prev).scale((double)1.0F / (double)gap);
                        if (step.lengthSqr() > (double)36.0F) {
                           step = Vec3.ZERO;
                        }

                        v = v.scale(0.35).add(step.scale(0.65));
                        this.vel.put(id, v);
                     }

                     boolean mace = carries(p, true);
                     if (mace || carries(p, false)) {
                        if (!TeamManager.isAlliedWithBot(this.botName, p.getScoreboardName())) {
                           Dive d = this.simulate(p, pos, v, mace);
                           if (d != null) {
                              this.dives.put(id, d);
                              if (this.soonest == null || d.ticks() < this.soonest.ticks()) {
                                 this.soonest = d;
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static void beginAiPass() {
      MaceDiveForecast.OffGround.BY_LEVEL.clear();
      MaceDiveForecast.OffGround.passThread = Thread.currentThread();
   }

   public static void endAiPass() {
      MaceDiveForecast.OffGround.passThread = null;
      MaceDiveForecast.OffGround.BY_LEVEL.clear();
   }

   public static void afterTick(ServerPlayer bot) {
      if (Thread.currentThread() == MaceDiveForecast.OffGround.passThread) {
         OffGround og = (OffGround)MaceDiveForecast.OffGround.BY_LEVEL.get(bot.level());
         if (og != null) {
            og.reread(bot);
         }

      }
   }

   private Dive simulate(Player p, Vec3 pos, Vec3 v, boolean mace) {
      boolean gliding = p.isFallFlying();
      double steerPerTick2 = gliding ? 0.05 : 0.015;
      Vec3 target = new Vec3(this.bot.getX(), this.bot.getY() + (double)this.bot.getBbHeight() * (double)0.5F, this.bot.getZ());
      double eye = (double)p.getEyeHeight();
      double x = pos.x;
      double y = pos.y;
      double z = pos.z;
      double vx = v.x;
      double vy = v.y;
      double vz = v.z;
      double fall = Math.max((double)0.0F, p.fallDistance);

      for(int t = 0; t <= 40; ++t) {
         if (t > 0) {
            if (!gliding) {
               vy = (vy - 0.08) * 0.98;
            }

            x += vx;
            y += vy;
            z += vz;
            if (vy < (double)0.0F) {
               fall += -vy;
            }
         }

         if (y < this.bot.getY() - (double)1.0F) {
            return null;
         }

         double dx = target.x - x;
         double dz = target.z - z;
         double horiz = Math.max((double)0.0F, Math.sqrt(dx * dx + dz * dz) - steerPerTick2 * (double)t * (double)t);
         double dy = target.y - (y + eye);
         boolean reach = horiz * horiz + dy * dy <= 10.889999999999999;
         if (reach && (!mace || fall >= (double)1.5F) && vy < 0.05) {
            return new Dive(p, t, fall, this.estimateDamage(fall, mace), carriesAxe(p));
         }
      }

      return null;
   }

   private float estimateDamage(double fall, boolean mace) {
      double raw;
      if (mace) {
         double bonus = fall <= (double)3.0F ? (double)4.0F * fall : (fall <= (double)8.0F ? (double)12.0F + (double)2.0F * (fall - (double)3.0F) : (double)22.0F + (fall - (double)8.0F));
         raw = (double)9.0F + bonus;
      } else {
         raw = (double)10.0F;
      }

      double armor = (double)this.bot.getArmorValue();
      double tough = this.bot.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
      double f = Math.min((double)20.0F, Math.max(armor * 0.2, armor - raw / ((double)2.0F + tough / (double)4.0F)));
      double dmg = raw * ((double)1.0F - f / (double)25.0F);
      MobEffectInstance res = this.bot.getEffect(MobEffects.RESISTANCE);
      if (res != null) {
         dmg *= Math.max((double)0.0F, (double)1.0F - 0.2 * (double)(res.getAmplifier() + 1));
      }

      return (float)dmg;
   }

   private static boolean carriesAxe(Player p) {
      for(int i = 0; i < 36; ++i) {
         if (p.getInventory().getItem(i).is(ItemTags.AXES)) {
            return true;
         }
      }

      return p.getOffhandItem().is(ItemTags.AXES);
   }

   private static boolean carries(Player p, boolean mace) {
      for(int i = 0; i < 36; ++i) {
         if (is(p.getInventory().getItem(i), mace)) {
            return true;
         }
      }

      return is(p.getOffhandItem(), mace) || is(p.getMainHandItem(), mace);
   }

   private static boolean is(ItemStack s, boolean mace) {
      return mace ? s.is(Items.MACE) : StunSlamDummy.isMaceOrSpear(s) && !s.is(Items.MACE);
   }

   static record Dive(Player diver, int ticks, double fall, float damage, boolean axe) {
   }

   private static final class OffGround {
      static Thread passThread;
      static final IdentityHashMap<Object, OffGround> BY_LEVEL = new IdentityHashMap();
      final int size;
      final Player last;
      Player[] players;
      boolean[] up;
      Int2IntOpenHashMap slot;
      int[] upIdx;
      int upCount = -1;

      private OffGround(int size, Player last) {
         this.size = size;
         this.last = last;
      }

      static OffGround of(Object level, List<? extends Player> list) {
         if (Thread.currentThread() != passThread) {
            return null;
         } else {
            OffGround og = (OffGround)BY_LEVEL.get(level);
            int size = list.size();
            Player last = size == 0 ? null : (Player)list.get(size - 1);
            if (og != null && og.size == size && og.last == last) {
               if (og.players == null) {
                  og.build(list);
               }

               return og;
            } else {
               BY_LEVEL.put(level, new OffGround(size, last));
               return null;
            }
         }
      }

      private void build(List<? extends Player> list) {
         this.players = (Player[])list.toArray(new Player[0]);
         this.up = new boolean[this.players.length];
         this.upIdx = new int[this.players.length];
         this.slot = new Int2IntOpenHashMap(this.players.length);
         this.slot.defaultReturnValue(-1);

         for(int i = 0; i < this.players.length; ++i) {
            this.up[i] = !this.players[i].onGround();
            this.slot.put(this.players[i].getId(), i);
         }

      }

      int upCount() {
         if (this.upCount < 0) {
            int n = 0;

            for(int i = 0; i < this.up.length; ++i) {
               if (this.up[i]) {
                  this.upIdx[n++] = i;
               }
            }

            this.upCount = n;
         }

         return this.upCount;
      }

      void reread(Player p) {
         if (this.players != null) {
            int i = this.slot.get(p.getId());
            if (i >= 0 && this.players[i] == p) {
               boolean u = !p.onGround();
               if (this.up[i] != u) {
                  this.up[i] = u;
                  this.upCount = -1;
               }

            }
         }
      }
   }
}
