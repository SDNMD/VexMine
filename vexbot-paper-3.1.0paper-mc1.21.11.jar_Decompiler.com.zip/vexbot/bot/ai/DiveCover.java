package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

final class DiveCover {
   static final double SKY_HEIGHT = (double)12.0F;
   static final double LAUNCH_HEADROOM = (double)6.0F;
   private static final double HALF = 0.3;
   private static final int CACHE_TICKS = 5;
   private int cachedAt = Integer.MIN_VALUE;
   private int cachedId = Integer.MIN_VALUE;
   private boolean cached;

   boolean reachable(LivingEntity target, int now) {
      if (target.getId() == this.cachedId && now - this.cachedAt < 5 && now >= this.cachedAt) {
         return this.cached;
      } else {
         this.cachedId = target.getId();
         this.cachedAt = now;
         this.cached = reachable(target);
         return this.cached;
      }
   }

   static boolean reachable(LivingEntity target) {
      return !dugIn(target) && openAbove(target, (double)12.0F);
   }

   static boolean openAbove(LivingEntity e, double height) {
      Level level = e.level();
      AABB box = e.getBoundingBox();
      double cx = (box.minX + box.maxX) / (double)2.0F;
      double cz = (box.minZ + box.maxZ) / (double)2.0F;
      double y0 = box.maxY + 0.05;
      double[][] offs = new double[][]{{(double)0.0F, (double)0.0F}, {0.3, 0.3}, {0.3, -0.3}, {-0.3, 0.3}, {-0.3, -0.3}};

      for(double[] o : offs) {
         Vec3 from = new Vec3(cx + o[0], y0, cz + o[1]);
         Vec3 to = from.add((double)0.0F, height, (double)0.0F);
         if (level.clip(new ClipContext(from, to, Block.COLLIDER, Fluid.NONE, e)).getType() != Type.MISS) {
            return false;
         }
      }

      return true;
   }

   static boolean dugIn(LivingEntity t) {
      Level level = t.level();
      BlockPos eye = BlockPos.containing(t.getEyePosition());
      int walls = 0;

      for(Direction d : Plane.HORIZONTAL) {
         BlockPos p = eye.relative(d);
         if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty()) {
            ++walls;
         }
      }

      return walls >= 3;
   }
}
