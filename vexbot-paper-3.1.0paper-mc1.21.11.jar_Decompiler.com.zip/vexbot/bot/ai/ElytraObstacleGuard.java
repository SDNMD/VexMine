package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

final class ElytraObstacleGuard {
   private static final double MAX_LOOK_AHEAD = (double)24.0F;
   private static final double MIN_LOOK_AHEAD = (double)6.0F;
   private static final int LOOK_AHEAD_TICKS = 16;
   private static final float CLIMB_TRY_PITCH = -35.0F;
   private static final float[] YAW_TRIES = new float[]{18.0F, 34.0F, 52.0F, 74.0F};
   private static final int CRASH_TICKS = 10;
   private static final double CRASH_SPEED = 0.08;
   private static final double HALF_WIDTH = 0.45;

   private ElytraObstacleGuard() {
   }

   static float[] avoid(ServerPlayer bot, float desiredYaw, float desiredPitch) {
      double reach = lookAhead(bot);
      if (clear(bot, desiredYaw, desiredPitch, reach)) {
         return new float[]{desiredYaw, desiredPitch};
      } else if (clear(bot, desiredYaw, -35.0F, reach)) {
         return new float[]{desiredYaw, -35.0F};
      } else {
         for(float off : YAW_TRIES) {
            for(int side = 0; side < 2; ++side) {
               float yaw = Mth.wrapDegrees(desiredYaw + (side == 0 ? off : -off));
               if (clear(bot, yaw, desiredPitch, reach)) {
                  return new float[]{yaw, desiredPitch};
               }

               if (clear(bot, yaw, -35.0F, reach)) {
                  return new float[]{yaw, -35.0F};
               }
            }
         }

         return new float[]{desiredYaw, -80.0F};
      }
   }

   private static boolean clear(ServerPlayer bot, float yaw, float pitch, double reach) {
      Vec3 from = bot.getEyePosition();
      Vec3 dir = fromAngles(yaw, pitch);
      double len = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
      Vec3 side = len < 1.0E-4 ? new Vec3((double)1.0F, (double)0.0F, (double)0.0F) : new Vec3(-dir.z / len, (double)0.0F, dir.x / len);

      for(double off : new double[]{(double)0.0F, 0.45, -0.45}) {
         Vec3 origin = from.add(side.scale(off));
         BlockHitResult hit = bot.level().clip(new ClipContext(origin, origin.add(dir.scale(reach)), Block.COLLIDER, Fluid.NONE, bot));
         if (hit.getType() != Type.MISS) {
            return false;
         }
      }

      return true;
   }

   private static double lookAhead(ServerPlayer bot) {
      Vec3 v = bot.getDeltaMovement();
      double speed = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
      return Mth.clamp(speed * (double)16.0F, (double)6.0F, (double)24.0F);
   }

   private static Vec3 fromAngles(float yaw, float pitch) {
      double y = Math.toRadians((double)yaw);
      double p = Math.toRadians((double)pitch);
      double cosP = Math.cos(p);
      return new Vec3(-Math.sin(y) * cosP, -Math.sin(p), Math.cos(y) * cosP);
   }

   static final class CrashDetector {
      private Vec3 lastPos;
      private int stuckTicks;

      void reset() {
         this.lastPos = null;
         this.stuckTicks = 0;
      }

      boolean crashed(ServerPlayer bot) {
         Vec3 pos = bot.position();
         if (this.lastPos == null) {
            this.lastPos = pos;
            return false;
         } else {
            double moved = pos.distanceTo(this.lastPos);
            this.lastPos = pos;
            boolean going = moved >= 0.08;
            if (going && !bot.horizontalCollision) {
               this.stuckTicks = 0;
               return false;
            } else {
               return ++this.stuckTicks >= 10;
            }
         }
      }
   }
}
