package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;

public final class CartDoctrine {
   public static final float EXCHANGE_EXIT_HP = 14.0F;
   public static final float ENTER_EXCHANGE_HP = 18.0F;
   private static final float GAP_WORTH_CARTING = 4.0F;
   private static final float FINISH_HP = 8.0F;
   private static final double MELEE_RANGE = 3.6;

   private CartDoctrine() {
   }

   public static boolean isGuideDoctrine(String botName) {
      return EffectiveSettings.of(botName).cartDoctrine() == BotSettings.CartDoctrine.GUIDE;
   }

   public static Reason shouldCart(ServerPlayer bot, LivingEntity target, double dist, int sinceTargetPearled, int sinceTargetCartMiss) {
      if (target != null && target.isAlive()) {
         if (!isGuideDoctrine(bot.getScoreboardName())) {
            return CartDoctrine.Reason.RELENTLESS;
         } else {
            float myHp = bot.getHealth() + bot.getAbsorptionAmount();
            float theirHp = target.getHealth() + target.getAbsorptionAmount();
            if (theirHp <= 8.0F) {
               return CartDoctrine.Reason.FINISH;
            } else if (sinceTargetPearled <= 40) {
               return CartDoctrine.Reason.PUNISH_PEARL;
            } else if (sinceTargetCartMiss <= 30) {
               return CartDoctrine.Reason.PUNISH_MISS;
            } else if (myHp < 18.0F && myHp <= theirHp) {
               return CartDoctrine.Reason.NONE;
            } else if (dist <= 3.6 && myHp - theirHp < 4.0F) {
               return CartDoctrine.Reason.NONE;
            } else {
               return myHp + 4.0F >= theirHp ? CartDoctrine.Reason.OPEN_GAP : CartDoctrine.Reason.NONE;
            }
         }
      } else {
         return CartDoctrine.Reason.NONE;
      }
   }

   public static boolean selfDamageOk(ServerPlayer bot, LivingEntity target, Reason why) {
      float myHp = bot.getHealth() + bot.getAbsorptionAmount();
      if (why == CartDoctrine.Reason.FINISH && hasTotem(bot)) {
         return myHp >= 6.0F;
      } else {
         return myHp >= 12.0F;
      }
   }

   public static double selfMinDistance(ServerPlayer bot) {
      float myHp = bot.getHealth() + bot.getAbsorptionAmount();
      if (myHp >= 18.0F) {
         return (double)3.0F;
      } else {
         return myHp >= 12.0F ? (double)4.0F : (double)5.0F;
      }
   }

   public static double selfMinDistance(ServerPlayer bot, Reason why) {
      double d = selfMinDistance(bot);
      return why == CartDoctrine.Reason.FINISH ? Math.min((double)4.25F, d) : d;
   }

   public static boolean isFinishWindow(ServerPlayer bot, LivingEntity target) {
      if (target != null && target.isAlive()) {
         return target.getHealth() + target.getAbsorptionAmount() <= 8.0F && hasTotem(bot);
      } else {
         return false;
      }
   }

   private static boolean hasTotem(ServerPlayer bot) {
      ItemStack off = bot.getOffhandItem();
      return off != null && off.is(Items.TOTEM_OF_UNDYING);
   }

   public static enum Reason {
      FINISH,
      OPEN_GAP,
      PUNISH_PEARL,
      PUNISH_MISS,
      RELENTLESS,
      NONE;

      // $FF: synthetic method
      private static Reason[] $values() {
         return new Reason[]{FINISH, OPEN_GAP, PUNISH_PEARL, PUNISH_MISS, RELENTLESS, NONE};
      }
   }
}
