package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.util.InventoryUtils;
import vexbot.util.VexLog;

final class MaceTotemGuard {
   private static final int RAISE_TICKS = 6;
   private static final double DAMAGE_MARGIN = 1.15;
   private static final int MAX_HOLD_TICKS = 60;
   private static final int RELEASE_TICKS = 4;
   private final ServerPlayer bot;
   private final String botName;
   private final MaceDiveForecast forecast;
   private boolean holding = false;
   private int restoreSlot = -1;
   private int holdTicks = 0;
   private int quietTicks = 0;

   MaceTotemGuard(ServerPlayer bot, String botName, MaceDiveForecast forecast) {
      this.bot = bot;
      this.botName = botName;
      this.forecast = forecast;
   }

   boolean isHolding() {
      return this.holding;
   }

   boolean tick(int tickCount) {
      MaceDiveForecast.Dive dive = this.forecast.soonest();
      boolean shieldCovers = this.bot.isBlocking() && dive != null && !dive.axe();
      boolean incoming = dive != null && dive.ticks() <= 6 && this.lethal(dive) && !shieldCovers;
      if (this.holding) {
         ++this.holdTicks;
         this.quietTicks = incoming ? 0 : this.quietTicks + 1;
         if (this.quietTicks < 4 && this.holdTicks < 60 && !this.hasOffhandTotem() && EffectiveSettings.of(this.botName).maceTotem()) {
            int slot = this.findTotemSlot();
            if (slot < 0) {
               this.release();
               return false;
            } else {
               this.raise(slot);
               return true;
            }
         } else {
            this.release();
            return false;
         }
      } else if (incoming && !this.hasOffhandTotem() && EffectiveSettings.of(this.botName).maceTotem()) {
         int slot = this.findTotemSlot();
         if (slot < 0) {
            return false;
         } else {
            this.holding = true;
            this.holdTicks = 0;
            this.quietTicks = 0;
            this.restoreSlot = InventoryUtils.selected(this.bot.getInventory());
            this.raise(slot);
            VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' totem in main hand: {} lands in {} ticks for ~{} damage", this.botName, dive.diver().getScoreboardName(), dive.ticks(), String.format("%.1f", dive.damage()));
            return true;
         }
      } else {
         return false;
      }
   }

   void reassert() {
      if (this.holding) {
         int slot = this.findTotemSlot();
         if (slot >= 0) {
            this.raise(slot);
         }

      }
   }

   void reset() {
      if (this.holding) {
         this.release();
      }

   }

   private boolean lethal(MaceDiveForecast.Dive dive) {
      double hp = (double)(this.bot.getHealth() + this.bot.getAbsorptionAmount());
      return (double)dive.damage() * 1.15 >= hp;
   }

   private boolean hasOffhandTotem() {
      return this.bot.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
   }

   private int findTotemSlot() {
      Inventory inv = this.bot.getInventory();
      int held = InventoryUtils.selected(inv);
      if (inv.getItem(held).is(Items.TOTEM_OF_UNDYING)) {
         return held;
      } else {
         for(int i = 0; i < 36; ++i) {
            if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
               return i;
            }
         }

         return -1;
      }
   }

   private void raise(int slot) {
      Inventory inv = this.bot.getInventory();
      int hotbar = slot < 9 ? slot : InventoryUtils.moveToHotbarSafe(inv, slot);
      if (hotbar >= 0 && hotbar <= 8) {
         if (InventoryUtils.selected(inv) != hotbar) {
            InventoryUtils.select(inv, hotbar);
         }

         if (this.bot.isUsingItem() && this.bot.getUsedItemHand() == InteractionHand.MAIN_HAND) {
            this.bot.stopUsingItem();
         }

      }
   }

   private void release() {
      this.holding = false;
      Inventory inv = this.bot.getInventory();
      if (this.restoreSlot >= 0 && this.restoreSlot <= 8 && InventoryUtils.selected(inv) != this.restoreSlot) {
         InventoryUtils.select(inv, this.restoreSlot);
      }

      this.restoreSlot = -1;
      this.holdTicks = 0;
      this.quietTicks = 0;
   }
}
