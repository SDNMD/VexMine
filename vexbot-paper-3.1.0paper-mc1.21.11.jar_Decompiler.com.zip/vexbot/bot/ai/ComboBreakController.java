package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import vexbot.EffectiveSettings;
import vexbot.util.BotCommands;

final class ComboBreakController {
   private static final int JUMP_AT = 2;
   private static final int PEARL_AT = 4;
   private static final int JUMP_COOLDOWN = 12;
   private static final int PEARL_COOLDOWN = 60;
   private static final int CHAIN_FRESH_TICKS = 12;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private final Random rng = new Random();
   private int jumpCooldown = 0;
   private int pearlCooldown = 0;
   private int jumpRolledChain = -1;
   private int pearlRolledChain = -1;

   ComboBreakController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   void reset() {
      this.jumpCooldown = this.pearlCooldown = 0;
      this.jumpRolledChain = this.pearlRolledChain = -1;
   }

   boolean tick(LivingEntity target, FightState fightState, EffectiveSettings settings, EnderPearlController pearls) {
      if (this.jumpCooldown > 0) {
         --this.jumpCooldown;
      }

      if (this.pearlCooldown > 0) {
         --this.pearlCooldown;
      }

      if (!fightState.beingCombod()) {
         this.jumpRolledChain = this.pearlRolledChain = -1;
      }

      if (target != null && target.isAlive()) {
         if (!fightState.beingCombod()) {
            return false;
         } else if (fightState.ticksSinceHitTaken() > 12) {
            return false;
         } else {
            int chain = fightState.incomingComboHits();
            double accuracy = settings.difficultyParams().accuracy;
            if (chain >= 4 && this.pearlCooldown == 0 && settings.useEnderPearl() && chain != this.pearlRolledChain) {
               this.pearlRolledChain = chain;
               if (this.rng.nextDouble() < accuracy) {
                  this.pearlCooldown = 60;
                  if (pearls.tryThrow(target)) {
                     return true;
                  }
               }
            }

            if (chain >= 2 && this.jumpCooldown == 0 && this.bot.onGround() && chain != this.jumpRolledChain) {
               this.jumpRolledChain = chain;
               if (this.rng.nextDouble() < accuracy) {
                  this.jumpCooldown = 12;
                  BotCommands.jumpOnce(this.server, this.botName);
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }
}
