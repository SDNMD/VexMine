package vexbot.bot.ai;

import java.util.function.BiPredicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.compat.McCompat;
import vexbot.fakeplayer.bot.pathing.MovementHelper;
import vexbot.util.BotCommands;
import vexbot.util.BotMath;
import vexbot.util.InventoryUtils;
import vexbot.util.NearbyBlocks;

public final class PathFollower {
   private static final float MAX_TURN_PER_TICK = 50.0F;
   private static final double DOOR_PROBE = 1.1;
   private static final int REACT_STUCK_TICKS = 6;
   private static final int REACT_ESCAPE_TICKS = 30;
   private static final int SIDE_PROBE_LEN = 10;
   private static final double AVOID_PROGRESS = (double)3.0F;
   private static final int AVOID_COMMIT_MAX = 300;
   private static final double PROGRESS_EPS = 0.35;
   private static final double GOAL_RESET_DIST = (double)3.0F;
   private static final double WEB_PROBE = (double)3.5F;
   private static final double LAVA_PROBE = (double)4.5F;
   private static final double REACT_KNOCKBACK_VEL = 0.6;
   private static final int SWIM_LOW_AIR = 80;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private final LocalPlanner planner;
   private final WaterExit waterExit;
   private Vec3 lastPos = null;
   private int reactiveStuckTicks = 0;
   private int reactiveAvoidDir = 0;
   private int reactiveAvoidTicks = 0;
   private double avoidStartGoalDist = Double.MAX_VALUE;
   private int avoidCommitTicks = 0;
   private boolean avoidHazard = false;
   private double bestGoalDist = Double.MAX_VALUE;
   private Vec3 bestGoalRef = null;
   private int reactiveJumpCd = 0;
   private int windChargeCd = 0;
   private int reactiveKnockTicks = 0;
   private boolean chasing = false;
   private boolean wasSwimming = false;
   private int buttonPressCd = 0;

   public PathFollower(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
      this.planner = new LocalPlanner(bot);
      this.waterExit = new WaterExit(bot, server, this.botName);
   }

   public void chase(Entity target) {
      this.reactiveChase(target.position(), (Vec3)null);
   }

   public void chase(Vec3 goalPos) {
      this.reactiveChase(goalPos, (Vec3)null);
   }

   public void chase(Entity target, Vec3 facePos) {
      this.reactiveChase(target.position(), facePos);
   }

   public void chase(Vec3 goalPos, Vec3 facePos) {
      this.reactiveChase(goalPos, facePos);
   }

   private void reactiveChase(Vec3 goalPos, Vec3 facePos) {
      if (BotSettings.movementFrozen) {
         BotCommands.stopMoving(this.server, this.botName);
      } else {
         this.chasing = true;
         Level level = this.bot.level();
         Vec3 botPos = this.bot.position();
         boolean combat = facePos != null;
         if (this.lastPos != null) {
            botPos.distanceTo(this.lastPos);
         } else {
            double var10000 = (double)0.0F;
         }

         if (this.reactiveJumpCd > 0) {
            --this.reactiveJumpCd;
         }

         if (this.windChargeCd > 0) {
            --this.windChargeCd;
         }

         if (this.reactiveAvoidTicks > 0) {
            --this.reactiveAvoidTicks;
         }

         Vec3 vel = this.bot.getDeltaMovement();
         double horizVel = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
         if (horizVel > 0.6 && this.reactiveKnockTicks < 5) {
            ++this.reactiveKnockTicks;
            BotCommands.stopMoving(this.server, this.botName);
            this.bot.setSprinting(false);
            this.lastPos = botPos;
         } else {
            this.reactiveKnockTicks = 0;
            if ((!this.bot.isInWater() || this.bot.onGround() && !this.bot.isUnderWater()) && (!this.waterExit.active() || this.bot.onGround())) {
               NearbyBlocks blocks = new NearbyBlocks(level);
               if (!this.bot.isInWater() && waterAhead(blocks, botPos, goalPos, combat ? (double)3.0F : 1.2)) {
                  this.swimChase(goalPos, facePos);
                  this.wasSwimming = true;
                  this.lastPos = botPos;
               } else {
                  if (this.wasSwimming) {
                     this.bot.setSprinting(false);
                     this.bot.setJumping(false);
                     this.wasSwimming = false;
                  }

                  if (this.bot.onGround()) {
                     this.waterExit.reset();
                  }

                  Vec3 steerPt = this.planner.tick(goalPos, combat);
                  double dx;
                  double dz;
                  if (steerPt != null) {
                     dx = steerPt.x - botPos.x;
                     dz = steerPt.z - botPos.z;
                  } else {
                     dx = goalPos.x - botPos.x;
                     dz = goalPos.z - botPos.z;
                  }

                  double horizDist = Math.sqrt(dx * dx + dz * dz);
                  if (horizDist > 0.1) {
                     dx /= horizDist;
                     dz /= horizDist;
                  }

                  double ggx = goalPos.x - botPos.x;
                  double ggz = goalPos.z - botPos.z;
                  double goalLen = Math.sqrt(ggx * ggx + ggz * ggz);
                  if (goalLen > 0.1) {
                     ggx /= goalLen;
                     ggz /= goalLen;
                  }

                  if (this.bestGoalRef == null || this.bestGoalRef.distanceTo(goalPos) > (double)3.0F) {
                     this.bestGoalRef = goalPos;
                     this.bestGoalDist = goalLen;
                     this.reactiveStuckTicks = 0;
                  }

                  if (goalLen < this.bestGoalDist - 0.35) {
                     this.bestGoalDist = goalLen;
                     this.reactiveStuckTicks = 0;
                  } else if (this.bot.onGround()) {
                     ++this.reactiveStuckTicks;
                  }

                  boolean pressing = this.reactiveStuckTicks > 0;
                  if (this.lastPos != null && pressing && this.reactiveStuckTicks > 6 && this.reactiveAvoidTicks <= 0) {
                     this.planner.invalidate();
                     boolean fresh = this.reactiveAvoidDir == 0;
                     boolean progress = goalLen < this.avoidStartGoalDist - (double)3.0F;
                     boolean expired = this.avoidCommitTicks > 300;
                     if (fresh || progress || expired) {
                        int openL = this.sideOpenness(blocks, botPos, ggx, ggz, 1);
                        int openR = this.sideOpenness(blocks, botPos, ggx, ggz, -1);
                        if (openL != openR) {
                           this.reactiveAvoidDir = openL > openR ? 1 : -1;
                        } else if (expired) {
                           this.reactiveAvoidDir = -this.reactiveAvoidDir;
                        } else if (fresh) {
                           this.reactiveAvoidDir = 1;
                        }

                        this.avoidStartGoalDist = goalLen;
                        this.avoidCommitTicks = 0;
                     }

                     this.avoidHazard = false;
                     this.reactiveAvoidTicks = 30;
                     if (this.reactiveJumpCd <= 0) {
                        BotCommands.jumpOnce(this.server, this.botName);
                        this.reactiveJumpCd = 10;
                     }

                     this.reactiveStuckTicks = 0;
                  }

                  this.lastPos = botPos;
                  if (this.reactiveAvoidTicks > 0) {
                     ++this.avoidCommitTicks;
                     boolean frontOpen = !isSolidAt(blocks, BlockPos.containing(botPos.x + ggx * 0.6, botPos.y, botPos.z + ggz * 0.6)) && !isSolidAt(blocks, BlockPos.containing(botPos.x + ggx * 0.6, botPos.y + (double)1.0F, botPos.z + ggz * 0.6)) && !scanAhead(blocks, botPos, ggx, ggz, (double)3.5F, PathFollower::isWebAt) && !scanAhead(blocks, botPos, ggx, ggz, (double)4.5F, PathFollower::isLavaAt);
                     if (!this.bot.horizontalCollision && frontOpen) {
                        this.reactiveAvoidTicks = 0;
                     } else {
                        double px = this.reactiveAvoidDir > 0 ? -ggz : ggz;
                        double pz = this.reactiveAvoidDir > 0 ? ggx : -ggx;
                        double fwd = this.avoidHazard ? (double)0.0F : (double)0.5F;
                        dx = ggx * fwd + px;
                        dz = ggz * fwd + pz;
                        double len = Math.sqrt(dx * dx + dz * dz);
                        if (len > 1.0E-6) {
                           dx /= len;
                           dz /= len;
                        }
                     }
                  }

                  BlockPos feetAhead = BlockPos.containing(botPos.x + dx * (double)0.5F, botPos.y, botPos.z + dz * (double)0.5F);
                  BlockPos headAhead = feetAhead.above();
                  BlockPos aboveHead = feetAhead.above(2);
                  boolean blockFeet = isSolidAt(blocks, feetAhead);
                  boolean blockHead = isSolidAt(blocks, headAhead);
                  boolean canJumpUp = blockFeet && !blockHead && !isSolidAt(blocks, aboveHead);
                  boolean isWall = blockFeet && blockHead;
                  BlockPos here = this.bot.blockPosition();
                  boolean onLadder = isClimbableAt(blocks, here) || isClimbableAt(blocks, here.above());
                  BlockPos groundFront = BlockPos.containing(botPos.x + dx * 1.2, botPos.y - (double)1.0F, botPos.z + dz * 1.2);
                  boolean holeAhead = !isSolidAt(blocks, groundFront) && !isSolidAt(blocks, groundFront.below());
                  double goalHoriz = Math.hypot(goalPos.x - botPos.x, goalPos.z - botPos.z);
                  boolean webAhead = goalHoriz > 1.6 && scanAhead(blocks, botPos, dx, dz, (double)3.5F, PathFollower::isWebAt);
                  boolean lavaAhead = scanAhead(blocks, botPos, dx, dz, (double)4.5F, PathFollower::isLavaAt);
                  this.maybeOpenDoorAhead(botPos, new Vec3(botPos.x + dx, botPos.y, botPos.z + dz));
                  if ((webAhead || lavaAhead) && this.reactiveAvoidTicks <= 0) {
                     int openL = this.sideOpenness(blocks, botPos, ggx, ggz, 1);
                     int openR = this.sideOpenness(blocks, botPos, ggx, ggz, -1);
                     if (openL != openR) {
                        this.reactiveAvoidDir = openL > openR ? 1 : -1;
                     } else if (this.reactiveAvoidDir == 0) {
                        this.reactiveAvoidDir = 1;
                     }

                     this.avoidHazard = true;
                     this.reactiveAvoidTicks = 30;
                     this.avoidStartGoalDist = goalLen;
                     this.avoidCommitTicks = 0;
                  }

                  if (this.bot.onGround() && this.reactiveJumpCd <= 0 && !webAhead && !lavaAhead) {
                     if (canJumpUp) {
                        BotCommands.jumpOnce(this.server, this.botName);
                        this.reactiveJumpCd = 8;
                     } else if (onLadder) {
                        BotCommands.jumpOnce(this.server, this.botName);
                        this.reactiveJumpCd = 5;
                     } else if (holeAhead) {
                        BotCommands.jumpOnce(this.server, this.botName);
                        this.reactiveJumpCd = 12;
                     } else if (isWall && this.reactiveAvoidTicks <= 0) {
                        if (this.tryWindChargeOverWall(feetAhead, goalPos.y - botPos.y)) {
                           this.reactiveJumpCd = 12;
                        } else {
                           int openL = this.sideOpenness(blocks, botPos, ggx, ggz, 1);
                           int openR = this.sideOpenness(blocks, botPos, ggx, ggz, -1);
                           this.reactiveAvoidDir = openL >= openR ? 1 : -1;
                           this.reactiveAvoidTicks = 30;
                           BotCommands.jumpOnce(this.server, this.botName);
                           this.reactiveJumpCd = 10;
                        }
                     }
                  }

                  if (onLadder) {
                     this.faceMovement(dx, dz, facePos);
                     BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
                     this.bot.setSprinting(false);
                  } else if (combat) {
                     Vec3 steer = new Vec3(botPos.x + dx, botPos.y, botPos.z + dz);
                     this.steerStrafe(botPos, steer, facePos);
                  } else {
                     this.faceMovement(dx, dz, (Vec3)null);
                     BotCommands.moveForward(this.server, this.botName);
                  }

               }
            } else {
               this.swimChase(goalPos, facePos);
               this.wasSwimming = true;
               this.lastPos = botPos;
            }
         }
      }
   }

   private void steerStrafe(Vec3 botPos, Vec3 steer, Vec3 facePos) {
      double fdx = facePos.x - botPos.x;
      double fdz = facePos.z - botPos.z;
      if (fdx * fdx + fdz * fdz > 1.0E-6) {
         float faceYaw = (float)Math.toDegrees(Math.atan2(-fdx, fdz));
         this.bot.setYRot(BotMath.smoothYawToward(this.bot.getYRot(), faceYaw, 50.0F));
      }

      this.bot.setYBodyRot(this.bot.getYRot());
      double tdx = steer.x - botPos.x;
      double tdz = steer.z - botPos.z;
      double tlen = Math.sqrt(tdx * tdx + tdz * tdz);
      if (tlen < 0.05) {
         BotCommands.stopMoving(this.server, this.botName);
      } else {
         tdx /= tlen;
         tdz /= tlen;
         double yawRad = Math.toRadians((double)this.bot.getYRot());
         double sin = Math.sin(yawRad);
         double cos = Math.cos(yawRad);
         float forward = (float)(-sin * tdx + cos * tdz);
         float strafe = (float)(cos * tdx + sin * tdz);
         BotCommands.setMovement(this.server, this.botName, forward, strafe);
      }
   }

   private static boolean waterAhead(NearbyBlocks blocks, Vec3 from, Vec3 goal, double minDist) {
      double dx = goal.x - from.x;
      double dz = goal.z - from.z;
      double d = Math.sqrt(dx * dx + dz * dz);
      if (d < minDist) {
         return false;
      } else {
         dx /= d;
         dz /= d;
         int fy = Mth.floor(from.y);

         for(double step = 0.8; step <= (double)2.0F; step += 0.6) {
            int x = Mth.floor(from.x + dx * step);
            int z = Mth.floor(from.z + dz * step);
            BlockPos feet = new BlockPos(x, fy, z);
            if (blocks.solid(feet)) {
               return false;
            }

            for(int y = fy; y >= fy - 3; --y) {
               BlockPos p = new BlockPos(x, y, z);
               if (blocks.fluid(p).is(FluidTags.LAVA)) {
                  return false;
               }

               if (MovementHelper.isWater(blocks.level(), x, y, z)) {
                  return true;
               }

               if (y < fy && blocks.solid(p)) {
                  break;
               }
            }
         }

         return false;
      }
   }

   private void swimChase(Vec3 goalPos, Vec3 facePos) {
      Level level = this.bot.level();
      Vec3 botPos = this.bot.position();
      boolean combat = facePos != null;
      boolean inWater = this.bot.isInWater() && (!this.bot.onGround() || this.bot.isUnderWater());
      boolean lowAir = this.bot.isUnderWater() && this.bot.getAirSupply() < 80;
      boolean afloat = inWater || !this.bot.isInWater() && !this.bot.onGround() && this.waterExit.active();
      double surface = waterSurfaceY(level, botPos);
      boolean goalOnLand = !Double.isNaN(surface) && goalPos.y >= surface - 0.6;
      Vec3 exitPt = null;
      if (afloat && goalOnLand) {
         this.waterExit.tick(level, botPos, goalPos, surface);
         if (this.waterExit.busy()) {
            return;
         }

         exitPt = this.waterExit.steerTo();
      }

      Vec3 aim = exitPt != null ? exitPt : (combat ? facePos : goalPos);
      double dx = aim.x - botPos.x;
      double dz = aim.z - botPos.z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      if (horiz > 1.0E-4) {
         float wantYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float yaw = BotMath.smoothYawToward(this.bot.getYRot(), wantYaw, 50.0F);
         this.bot.setYRot(yaw);
         this.bot.setYBodyRot(yaw);
         this.bot.setYHeadRot(yaw);
      }

      if (afloat && goalOnLand && bankAhead(level, botPos, this.bot.getYRot(), surface)) {
         this.bot.setSprinting(false);
         BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
         this.bot.setJumping(true);
      } else {
         this.bot.setSprinting(true);
         BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
         if (!inWater) {
            this.bot.setJumping(false);
         } else if (lowAir) {
            this.bot.setXRot(-70.0F);
            this.bot.setJumping(!this.bot.isSwimming());
         } else {
            this.bot.setJumping(false);
            if (!this.bot.isSwimming() && !this.bot.isUnderWater()) {
               Vec3 v = this.bot.getDeltaMovement();
               if (v.y > -0.12) {
                  this.bot.setDeltaMovement(v.x, v.y - 0.04, v.z);
               }
            }

            if (!combat) {
               double aimY = goalOnLand ? surface - (double)0.5F : goalPos.y;
               double dyEye = aimY - this.bot.getEyeY();
               float wantPitch = (float)(-Math.toDegrees(Math.atan2(dyEye, Math.max(horiz, (double)1.0F))));
               if (this.bot.horizontalCollision) {
                  wantPitch = -45.0F;
               }

               this.bot.setXRot(Math.max(-85.0F, Math.min(85.0F, wantPitch)));
            }

         }
      }
   }

   private static double waterSurfaceY(Level level, Vec3 pos) {
      int x = Mth.floor(pos.x);
      int z = Mth.floor(pos.z);
      int y = Mth.floor(pos.y);
      BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(x, y - 1, z);
      int found = Integer.MIN_VALUE;

      for(int yy = y - 1; yy <= y + 2; ++yy) {
         p.setY(yy);
         if (level.getFluidState(p).is(FluidTags.WATER)) {
            found = yy;
            break;
         }
      }

      if (found == Integer.MIN_VALUE) {
         return Double.NaN;
      } else {
         int top = found;

         for(int i = 0; i < 24; ++i) {
            p.setY(top + 1);
            if (!level.getFluidState(p).is(FluidTags.WATER)) {
               break;
            }

            ++top;
         }

         p.setY(top);
         return (double)((float)top + level.getFluidState(p).getHeight(level, p));
      }
   }

   private static boolean bankAhead(Level level, Vec3 pos, float yaw, double surface) {
      double rad = Math.toRadians((double)yaw);
      double fx = -Math.sin(rad);
      double fz = Math.cos(rad);
      int sy = Mth.floor(surface - 0.01);

      for(double step = 0.7; step <= 1.31; step += 0.6) {
         int x = Mth.floor(pos.x + fx * step);
         int z = Mth.floor(pos.z + fz * step);
         double top = WaterExit.landTop(level, new BlockPos(x, sy, z), surface);
         if (!Double.isNaN(top)) {
            return top - surface <= 0.6;
         }
      }

      return false;
   }

   private void faceMovement(double dx, double dz, Vec3 facePos) {
      if (dx * dx + dz * dz > 1.0E-6) {
         float wantYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float smoothed = BotMath.smoothYawToward(this.bot.getYRot(), wantYaw, 50.0F);
         this.bot.setYRot(smoothed);
         if (facePos == null) {
            this.bot.setYHeadRot(smoothed);
         }
      }

      this.bot.setYBodyRot(this.bot.getYHeadRot());
   }

   private int sideOpenness(NearbyBlocks blocks, Vec3 botPos, double gx, double gz, int sign) {
      double px = sign > 0 ? -gz : gz;
      double pz = sign > 0 ? gx : -gx;
      double hx = gx * (double)0.5F + px;
      double hz = gz * (double)0.5F + pz;
      double len = Math.sqrt(hx * hx + hz * hz);
      if (len > 1.0E-6) {
         hx /= len;
         hz /= len;
      }

      int open = 0;

      for(int d = 1; d <= 10; ++d) {
         BlockPos f = BlockPos.containing(botPos.x + hx * (double)d, botPos.y, botPos.z + hz * (double)d);
         if (isSolidAt(blocks, f) || isSolidAt(blocks, f.above()) || isWebAt(blocks, f) || isWebAt(blocks, f.above()) || isLavaAt(blocks, f) || isLavaAt(blocks, f.below()) || !isSolidAt(blocks, f.below()) && !isSolidAt(blocks, f.below().below())) {
            break;
         }

         ++open;
      }

      return open;
   }

   private static boolean scanAhead(NearbyBlocks blocks, Vec3 botPos, double dx, double dz, double reach, BiPredicate<NearbyBlocks, BlockPos> test) {
      for(double d = (double)0.5F; d <= reach + 1.0E-9; ++d) {
         BlockPos f = BlockPos.containing(botPos.x + dx * d, botPos.y, botPos.z + dz * d);
         if (test.test(blocks, f) || test.test(blocks, f.above())) {
            return true;
         }
      }

      return false;
   }

   private static boolean isWebAt(NearbyBlocks blocks, BlockPos pos) {
      return blocks.state(pos).is(Blocks.COBWEB);
   }

   private static boolean isLavaAt(NearbyBlocks blocks, BlockPos pos) {
      return blocks.fluid(pos).is(FluidTags.LAVA);
   }

   private static boolean isSolidAt(NearbyBlocks blocks, BlockPos pos) {
      return blocks.solid(pos);
   }

   private boolean tryWindChargeOverWall(BlockPos wallFeet, double goalDy) {
      if (this.windChargeCd <= 0 && !(goalDy < (double)2.0F)) {
         if (!this.bot.onGround()) {
            return false;
         } else {
            int wcSlot = this.findWindChargeHotbarSlot();
            if (wcSlot < 0) {
               return false;
            } else {
               int prev = this.bot.getInventory().getSelectedSlot();
               InventoryUtils.select(this.bot.getInventory(), wcSlot);
               this.bot.setXRot(80.0F);
               BotCommands.jumpOnce(this.server, this.botName);
               ItemStack wc = this.bot.getMainHandItem();
               if (wc.is(Items.WIND_CHARGE)) {
                  ServerLevel sl = this.bot.level();
                  if (sl instanceof ServerLevel) {
                     wc.use(sl, this.bot, InteractionHand.MAIN_HAND);
                  }
               }

               InventoryUtils.select(this.bot.getInventory(), prev);
               this.windChargeCd = 40;
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private int findWindChargeHotbarSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.WIND_CHARGE)) {
            return i;
         }
      }

      return -1;
   }

   private static boolean isClimbableAt(NearbyBlocks blocks, BlockPos pos) {
      return blocks.state(pos).is(BlockTags.CLIMBABLE);
   }

   public boolean hasPath() {
      return this.chasing;
   }

   public boolean isSwimNav() {
      return this.wasSwimming;
   }

   public void reset() {
      this.chasing = false;
      this.lastPos = null;
      this.reactiveStuckTicks = 0;
      this.reactiveAvoidTicks = 0;
      this.reactiveAvoidDir = 0;
      this.avoidStartGoalDist = Double.MAX_VALUE;
      this.avoidCommitTicks = 0;
      this.avoidHazard = false;
      this.bestGoalDist = Double.MAX_VALUE;
      this.bestGoalRef = null;
      this.reactiveJumpCd = 0;
      this.windChargeCd = 0;
      this.reactiveKnockTicks = 0;
      if (this.wasSwimming) {
         this.bot.setJumping(false);
      }

      this.wasSwimming = false;
      this.waterExit.pause();
      this.planner.reset();
      BotCommands.stopMoving(this.server, this.botName);
   }

   private void maybeOpenDoorAhead(Vec3 botPos, Vec3 steer) {
      if (BotSettings.openDoors) {
         if (this.buttonPressCd > 0) {
            --this.buttonPressCd;
         }

         Level level = this.bot.level();
         int fy = (int)Math.floor(botPos.y + 0.1);
         this.openDoorAt(level, BlockPos.containing(botPos.x, (double)fy, botPos.z));
         double dx = steer.x - botPos.x;
         double dz = steer.z - botPos.z;
         double horiz = Math.sqrt(dx * dx + dz * dz);
         if (horiz > 0.01) {
            double ax = botPos.x + dx / horiz * 1.1;
            double az = botPos.z + dz / horiz * 1.1;
            this.openDoorAt(level, BlockPos.containing(ax, (double)fy, az));
         }

      }
   }

   private void openDoorAt(Level level, BlockPos pos) {
      BlockState st = level.getBlockState(pos);
      Block var5 = st.getBlock();
      if (var5 instanceof DoorBlock door) {
         if (st.hasProperty(DoorBlock.OPEN) && !(Boolean)st.getValue(DoorBlock.OPEN)) {
            BlockPos lower = st.getValue(DoorBlock.HALF) == DoubleBlockHalf.UPPER ? pos.below() : pos;
            BlockState lowerSt = level.getBlockState(lower);
            if (lowerSt.getBlock() instanceof DoorBlock && lowerSt.hasProperty(DoorBlock.OPEN) && !(Boolean)lowerSt.getValue(DoorBlock.OPEN)) {
               if (!door.type().canOpenByHand()) {
                  this.pressButtonNear(level, lower);
               } else {
                  level.setBlock(lower, (BlockState)lowerSt.setValue(DoorBlock.OPEN, true), 10);
                  BlockState upperSt = level.getBlockState(lower.above());
                  if (upperSt.getBlock() instanceof DoorBlock && upperSt.hasProperty(DoorBlock.OPEN)) {
                     level.setBlock(lower.above(), (BlockState)upperSt.setValue(DoorBlock.OPEN, true), 10);
                  }

                  level.playSound((Entity)null, lower, SoundEvents.WOODEN_DOOR_OPEN, SoundSource.BLOCKS, 1.0F, 1.0F);
                  level.gameEvent(this.bot, GameEvent.BLOCK_OPEN, lower);
               }
            }
         }
      }
   }

   private void pressButtonNear(Level level, BlockPos doorLower) {
      if (this.buttonPressCd <= 0) {
         BlockPos best = null;
         double bestSqr = (double)25.0F;
         Vec3 eye = this.bot.getEyePosition();

         for(int dx = -2; dx <= 2; ++dx) {
            for(int dy = -1; dy <= 2; ++dy) {
               for(int dz = -2; dz <= 2; ++dz) {
                  BlockPos cand = doorLower.offset(dx, dy, dz);
                  BlockState cs = level.getBlockState(cand);
                  if (cs.is(BlockTags.BUTTONS)) {
                     if (cs.hasProperty(BlockStateProperties.POWERED) && (Boolean)cs.getValue(BlockStateProperties.POWERED)) {
                        return;
                     }

                     double sqr = eye.distanceToSqr(Vec3.atCenterOf(cand));
                     if (sqr < bestSqr) {
                        bestSqr = sqr;
                        best = cand;
                     }
                  }
               }
            }
         }

         if (best != null) {
            BlockState btn = level.getBlockState(best);
            btn.useWithoutItem(level, this.bot, new BlockHitResult(Vec3.atCenterOf(best), Direction.UP, best, false));
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            this.buttonPressCd = 20;
         }
      }
   }
}
