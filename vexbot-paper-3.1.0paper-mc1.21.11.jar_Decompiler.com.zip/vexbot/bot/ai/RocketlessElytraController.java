package vexbot.bot.ai;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.ElytraFlight;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.SwapEngine;

public final class RocketlessElytraController {
   private static final int TICK_FIRE_PEARL = 1;
   private static final int TICK_FIRE_WC = 4;
   private static final int TICK_EQUIP_ELYTRA = 7;
   private static final int TICK_FIRE_WC_ONLY = 1;
   private static final int TICK_WC_ONLY_ELYTRA = 4;
   private static final double MIN_TRIGGER_DIST = (double)4.0F;
   private static final double MAX_TRIGGER_DIST = (double)48.0F;
   private static final double REHEIGHT_DELTA = (double)3.0F;
   private static final int REHEIGHT_COOLDOWN = 30;
   private static final double SMASH_ENTER_DIST = (double)8.0F;
   private static final double MIN_FALL_DIST = (double)1.5F;
   private static final int GLIDE_MAX_TICKS = 260;
   private static final int SMASH_MAX_TICKS = 60;
   private static final int COOLDOWN_TICKS = 80;
   private static final int SETTLE_MAX = 30;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private final DiveCover cover = new DiveCover();
   private Runnable onSmashLanded = null;
   private Phase phase;
   private int phaseTick;
   private int cooldownLeft;
   private int reheightCd;
   private boolean settled;
   private int settleTicks;
   private boolean pearlLaunch;
   private int prevSlot;
   private int maceSlot;
   private int windChargeSlot;
   private int pearlSlot;
   private int chestStashSlot;

   private double smashRange() {
      return (new EffectiveSettings(this.botName)).attackRange();
   }

   public RocketlessElytraController(ServerPlayer bot, MinecraftServer server) {
      this.phase = RocketlessElytraController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldownLeft = 0;
      this.reheightCd = 0;
      this.settled = false;
      this.settleTicks = 0;
      this.pearlLaunch = false;
      this.prevSlot = 0;
      this.maceSlot = -1;
      this.windChargeSlot = -1;
      this.pearlSlot = -1;
      this.chestStashSlot = -1;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public void setOnSmashLanded(Runnable cb) {
      this.onSmashLanded = cb;
   }

   public boolean isExecuting() {
      return this.phase != RocketlessElytraController.Phase.IDLE;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldownLeft > 0) {
         --this.cooldownLeft;
      }

      if (this.reheightCd > 0) {
         --this.reheightCd;
      }

      if (this.phase == RocketlessElytraController.Phase.IDLE) {
         if (!this.canStart(target, dist)) {
            return false;
         } else {
            this.beginLaunch();
            return true;
         }
      } else if (target != null && target.isAlive()) {
         boolean var10000;
         switch (this.phase.ordinal()) {
            case 1 -> var10000 = this.tickLaunching();
            case 2 -> var10000 = this.tickGliding(target);
            case 3 -> var10000 = this.tickReheight(target);
            case 4 -> var10000 = this.tickSmashing(target);
            default -> var10000 = false;
         }

         return var10000;
      } else {
         this.abort();
         return false;
      }
   }

   private boolean canStart(LivingEntity target, double dist) {
      if (this.cooldownLeft <= 0 && target != null && target.isAlive()) {
         if (!this.bot.onGround()) {
            return false;
         } else {
            boolean targetAirborne = !target.onGround() && target.fallDistance > (double)1.0F;
            if (targetAirborne || !(dist < (double)4.0F) && !(dist > (double)48.0F)) {
               this.maceSlot = this.findHotbar(Items.MACE);
               if (this.maceSlot < 0) {
                  return false;
               } else if (!this.hasUsableElytra()) {
                  return false;
               } else {
                  this.windChargeSlot = this.findAnywhere(Items.WIND_CHARGE);
                  if (this.windChargeSlot < 0) {
                     return false;
                  } else if (this.bot.getCooldowns().isOnCooldown(new ItemStack(Items.WIND_CHARGE))) {
                     return false;
                  } else if (!targetAirborne && !this.cover.reachable(target, this.bot.tickCount)) {
                     return false;
                  } else if (!DiveCover.openAbove(this.bot, (double)6.0F)) {
                     return false;
                  } else if (ElytraSkill.skipLaunch(this.bot)) {
                     this.cooldownLeft = ElytraSkill.hesitateTicks(this.bot);
                     return false;
                  } else {
                     this.pearlLaunch = EffectiveSettings.of(this.botName).usePearlCatch();
                     if (this.pearlLaunch) {
                        this.pearlSlot = this.findAnywhere(Items.ENDER_PEARL);
                        if (this.pearlSlot < 0) {
                           this.pearlLaunch = false;
                        }
                     }

                     return true;
                  }
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void beginLaunch() {
      Inventory inv = this.bot.getInventory();
      if (this.pearlLaunch && this.pearlSlot >= 9) {
         InventoryUtils.moveToHotbarSafe(inv, this.pearlSlot);
      }

      this.windChargeSlot = this.findAnywhere(Items.WIND_CHARGE);
      if (this.windChargeSlot >= 9) {
         this.windChargeSlot = InventoryUtils.moveToHotbarSafe(inv, this.windChargeSlot);
      }

      if (this.pearlLaunch) {
         this.pearlSlot = this.findHotbar(Items.ENDER_PEARL);
         if (this.pearlSlot < 0) {
            this.pearlLaunch = false;
         }
      }

      this.prevSlot = InventoryUtils.selected(this.bot.getInventory());
      this.chestStashSlot = -1;
      this.settled = false;
      this.settleTicks = 0;
      this.enterPhase(RocketlessElytraController.Phase.LAUNCHING);
   }

   private boolean tickLaunching() {
      BotCommands.stopMoving(this.server, this.botName);
      this.bot.setSprinting(false);
      BotCommands.stopLookInterpolation(this.server, this.botName);
      this.bot.setXRot(this.pearlLaunch ? -90.0F : 80.0F);
      this.bot.setYHeadRot(this.bot.getYRot());
      this.bot.setYBodyRot(this.bot.getYRot());
      if (!this.settled) {
         this.bot.setDeltaMovement((double)0.0F, this.bot.getDeltaMovement().y, (double)0.0F);
         double hSpeed = Math.hypot(this.bot.getDeltaMovement().x, this.bot.getDeltaMovement().z);
         if (this.bot.onGround() && hSpeed < 0.03 || ++this.settleTicks >= 30) {
            this.settled = true;
            this.phaseTick = 0;
         }

         return true;
      } else {
         ++this.phaseTick;
         int stillUntil = this.pearlLaunch ? 4 : 1;
         if (this.phaseTick <= stillUntil) {
            this.bot.setDeltaMovement((double)0.0F, this.bot.getDeltaMovement().y, (double)0.0F);
         }

         if (this.pearlLaunch) {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot >= 0 ? this.maceSlot : this.prevSlot);
            if (this.phaseTick == 1) {
               InventoryUtils.select(this.bot.getInventory(), this.pearlSlot);
               this.firePearlUp();
            } else if (this.phaseTick == 4) {
               InventoryUtils.select(this.bot.getInventory(), this.windChargeSlot);
               this.fireWindCharge();
            } else if (this.phaseTick > 4 && (!this.bot.onGround() || this.phaseTick >= 7)) {
               return this.equipAndGlide();
            }
         } else if (this.phaseTick == 1) {
            InventoryUtils.select(this.bot.getInventory(), this.windChargeSlot);
            this.fireWindCharge();
         } else if (this.phaseTick > 1 && (!this.bot.onGround() || this.phaseTick >= 4)) {
            return this.equipAndGlide();
         }

         return true;
      }
   }

   private void firePearlUp() {
      ItemStack pearl = this.bot.getMainHandItem();
      if (pearl.is(Items.ENDER_PEARL)) {
         try {
            this.bot.gameMode.useItem(this.bot, this.bot.level(), pearl, InteractionHand.MAIN_HAND);
         } catch (Exception var3) {
         }
      }

   }

   private boolean equipAndGlide() {
      if (!this.equipElytra()) {
         this.abort();
         return false;
      } else {
         ElytraFlight.beginGlide(this.bot);
         this.enterPhase(RocketlessElytraController.Phase.GLIDING);
         return true;
      }
   }

   private void fireWindCharge() {
      SwapEngine.fireWindCharge(this.bot, this.windChargeSlot, 80.0F);
   }

   private void maybeWindChargeBoost(LivingEntity target, double dist) {
      if ((new EffectiveSettings(this.bot.getScoreboardName())).techniques().elytraWcBoost) {
         if (!(dist <= (double)12.0F) && this.phaseTick % 15 == 0) {
            int wc = this.windChargeSlot;
            if (wc >= 0 && wc <= 8) {
               float back = this.bot.getYRot() + 180.0F;
               float prevYaw = this.bot.getYRot();
               float prevPitch = this.bot.getXRot();
               this.bot.setYRot(back);
               if (!SwapEngine.fireWindCharge(this.bot, wc, 10.0F)) {
                  this.bot.setYRot(prevYaw);
                  this.bot.setXRot(prevPitch);
               }

            }
         }
      }
   }

   private boolean tickGliding(LivingEntity target) {
      this.maybeWindChargeBoost(target, (double)this.bot.distanceTo(target));
      ++this.phaseTick;
      if (this.phaseTick > 260) {
         this.abort();
         return false;
      } else if (this.bot.onGround() && this.phaseTick > 5) {
         this.abort();
         return false;
      } else if (this.lostCover(target)) {
         this.abort();
         return false;
      } else {
         ElytraFlight.beginGlide(this.bot);
         if (this.pearlLaunch && this.reheightCd == 0 && target.getY() - this.bot.getY() > (double)3.0F && this.findAnywhere(Items.ENDER_PEARL) >= 0 && (new EffectiveSettings(this.bot.getScoreboardName())).techniques().wcReset) {
            this.enterPhase(RocketlessElytraController.Phase.REHEIGHT);
            return true;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot >= 0 ? this.maceSlot : this.prevSlot);
            this.faceTarget(target);
            Vec3 v = this.bot.getDeltaMovement();
            double dx = target.getX() - this.bot.getX();
            double dz = target.getZ() - this.bot.getZ();
            double hd = Math.sqrt(dx * dx + dz * dz);
            if (hd > (double)0.5F) {
               double speed = Math.max(0.4, Math.hypot(v.x, v.z));
               double nx = dx / hd * speed;
               double nz = dz / hd * speed;
               this.bot.setDeltaMovement(v.x * 0.6 + nx * 0.4, v.y, v.z * 0.6 + nz * 0.4);
            }

            boolean above = this.bot.getY() > target.getY() + (double)1.5F;
            if (above && (double)this.bot.distanceTo(target) <= (double)8.0F) {
               this.unequipElytra();
               this.enterPhase(RocketlessElytraController.Phase.SMASHING);
            }

            return true;
         }
      }
   }

   private boolean tickReheight(LivingEntity target) {
      ++this.phaseTick;
      BotCommands.stopLookInterpolation(this.server, this.botName);
      this.bot.setXRot(-90.0F);
      this.bot.setYHeadRot(this.bot.getYRot());
      this.bot.setYBodyRot(this.bot.getYRot());
      ElytraFlight.beginGlide(this.bot);
      if (this.phaseTick <= 4) {
         this.bot.setDeltaMovement((double)0.0F, this.bot.getDeltaMovement().y, (double)0.0F);
      }

      if (this.phaseTick == 1) {
         int slot = this.findAnywhere(Items.ENDER_PEARL);
         if (slot < 0) {
            this.backToGlide();
            return true;
         }

         if (slot >= 9) {
            slot = InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), slot);
         }

         InventoryUtils.select(this.bot.getInventory(), slot);
         this.firePearlUp();
      } else if (this.phaseTick == 4) {
         int slot = this.findAnywhere(Items.WIND_CHARGE);
         if (slot >= 0) {
            if (slot >= 9) {
               slot = InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), slot);
            }

            InventoryUtils.select(this.bot.getInventory(), slot);
            this.fireWindCharge();
         }
      } else if (this.phaseTick >= 7) {
         this.backToGlide();
      }

      return true;
   }

   private void backToGlide() {
      this.reheightCd = 30;
      ElytraFlight.beginGlide(this.bot);
      InventoryUtils.select(this.bot.getInventory(), this.maceSlot >= 0 ? this.maceSlot : this.prevSlot);
      this.enterPhase(RocketlessElytraController.Phase.GLIDING);
   }

   private boolean tickSmashing(LivingEntity target) {
      ++this.phaseTick;
      if (this.phaseTick > 60) {
         this.finish();
         return false;
      } else {
         InventoryUtils.select(this.bot.getInventory(), this.maceSlot >= 0 ? this.maceSlot : this.prevSlot);
         this.faceTarget(target);
         double dx = target.getX() - this.bot.getX();
         double dz = target.getZ() - this.bot.getZ();
         double hd = Math.sqrt(dx * dx + dz * dz);
         if (hd > 0.3) {
            double step = Math.min(0.42, hd * (double)0.5F);
            Vec3 v = this.bot.getDeltaMovement();
            this.bot.setDeltaMovement(dx / hd * step, v.y, dz / hd * step);
         }

         boolean canSmash = this.bot.fallDistance > (double)1.5F && !this.bot.isFallFlying() && MaceSmashGates.botMayUseSmashFallBonus(this.bot);
         if (canSmash && (double)this.bot.distanceTo(target) <= this.smashRange() && this.bot.hasLineOfSight(target)) {
            EquipmentSync.syncNow(this.bot);
            this.bot.attack(target);
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            if (this.onSmashLanded != null) {
               this.onSmashLanded.run();
            }

            this.finish();
            return false;
         } else if (this.bot.onGround() && this.phaseTick > 3) {
            this.finish();
            return false;
         } else {
            return true;
         }
      }
   }

   private boolean hasUsableElytra() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (isUsableElytra(chest)) {
         return true;
      } else {
         Inventory inv = this.bot.getInventory();

         for(int i = 0; i < 36; ++i) {
            if (isUsableElytra(inv.getItem(i))) {
               return true;
            }
         }

         return false;
      }
   }

   private static boolean isUsableElytra(ItemStack s) {
      return s.is(Items.ELYTRA) && s.getDamageValue() < s.getMaxDamage() - 1;
   }

   private boolean equipElytra() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (isUsableElytra(chest)) {
         return true;
      } else {
         Inventory inv = this.bot.getInventory();

         for(int i = 0; i < 36; ++i) {
            ItemStack s = inv.getItem(i);
            if (isUsableElytra(s)) {
               ItemStack elytra = s.copy();
               inv.setItem(i, chest.copy());
               this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
               this.chestStashSlot = i;
               return true;
            }
         }

         return false;
      }
   }

   private void unequipElytra() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (chest.is(Items.ELYTRA)) {
         Inventory inv = this.bot.getInventory();
         if (this.chestStashSlot >= 0 && this.chestStashSlot < 36) {
            ItemStack stashedNow = inv.getItem(this.chestStashSlot);
            boolean stashIntact = stashedNow.isEmpty() || !stashedNow.is(Items.ELYTRA) && ArmorEvaluator.getSlot(stashedNow) == EquipmentSlot.CHEST;
            if (!stashIntact) {
               for(int i = 0; i < 36; ++i) {
                  if (inv.getItem(i).isEmpty()) {
                     inv.setItem(i, chest.copy());
                     this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                     return;
                  }
               }
            }

            ItemStack stashed = inv.getItem(this.chestStashSlot).copy();
            inv.setItem(this.chestStashSlot, chest.copy());
            this.bot.setItemSlot(EquipmentSlot.CHEST, stashed);
         } else {
            ItemStack overflow = chest.copy();
            this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);

            for(int i = 0; i < 36; ++i) {
               if (inv.getItem(i).isEmpty()) {
                  inv.setItem(i, overflow);
                  return;
               }
            }

            McCompat.drop(this.bot, overflow, false);
         }

      }
   }

   private void faceTarget(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dy = target.getY() + (double)target.getBbHeight() * (double)0.5F - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getZ();
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      this.bot.setXRot(pitch);
   }

   private int findHotbar(Item item) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private int findAnywhere(Item item) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private void enterPhase(Phase p) {
      this.phase = p;
      this.phaseTick = 0;
   }

   private void finish() {
      this.cleanupFlight();
      this.cooldownLeft = 80;
      this.enterPhase(RocketlessElytraController.Phase.IDLE);
   }

   private boolean lostCover(LivingEntity target) {
      return target.onGround() && !this.cover.reachable(target, this.bot.tickCount);
   }

   private void abort() {
      this.cleanupFlight();
      this.cooldownLeft = 40;
      this.enterPhase(RocketlessElytraController.Phase.IDLE);
   }

   private void cleanupFlight() {
      if (this.bot.onGround()) {
         this.unequipElytra();
      }

      if (this.prevSlot >= 0 && this.prevSlot < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      BotCommands.stopMoving(this.server, this.botName);
   }

   public void reset() {
      if (this.phase != RocketlessElytraController.Phase.IDLE) {
         this.abort();
      }

   }

   private static enum Phase {
      IDLE,
      LAUNCHING,
      GLIDING,
      REHEIGHT,
      SMASHING;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, LAUNCHING, GLIDING, REHEIGHT, SMASHING};
      }
   }
}
