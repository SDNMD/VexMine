package vexbot.bot.ai;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

public final class ItemEvaluator {
   private ItemEvaluator() {
   }

   public static boolean isWeapon(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else if (stack.is(Items.MACE)) {
         return false;
      } else if (!stack.is(ItemTags.PICKAXES) && !stack.is(ItemTags.SHOVELS) && !stack.is(ItemTags.HOES)) {
         ItemAttributeModifiers mods = (ItemAttributeModifiers)stack.get(DataComponents.ATTRIBUTE_MODIFIERS);
         if (mods == null) {
            return false;
         } else {
            return mods.compute(Attributes.ATTACK_DAMAGE, (double)0.0F, EquipmentSlot.MAINHAND) > (double)0.0F;
         }
      } else {
         return false;
      }
   }

   public static double scoreWeapon(ItemStack stack) {
      if (!isWeapon(stack)) {
         return (double)0.0F;
      } else {
         ItemAttributeModifiers mods = (ItemAttributeModifiers)stack.get(DataComponents.ATTRIBUTE_MODIFIERS);
         double damage = mods.compute(Attributes.ATTACK_DAMAGE, (double)0.0F, EquipmentSlot.MAINHAND);
         double score = damage;
         ItemEnchantments enchantments = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
         if (enchantments != null && !enchantments.isEmpty()) {
            for(Holder<Enchantment> holder : enchantments.keySet()) {
               score += weaponEnchantValue(holder, enchantments.getLevel(holder));
            }
         }

         return score;
      }
   }

   public static boolean isMace(ItemStack stack) {
      return !stack.isEmpty() && stack.is(Items.MACE);
   }

   public static double scoreMace(ItemStack stack) {
      if (!isMace(stack)) {
         return (double)0.0F;
      } else {
         double score = (double)6.0F;
         ItemEnchantments enchantments = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
         if (enchantments != null && !enchantments.isEmpty()) {
            for(Holder<Enchantment> holder : enchantments.keySet()) {
               score += maceEnchantValue(holder, enchantments.getLevel(holder));
            }
         }

         return score;
      }
   }

   private static double maceEnchantValue(Holder<Enchantment> holder, int level) {
      double var10000;
      switch ((String)holder.unwrapKey().map(ResourceKey::identifier).map((loc) -> loc.getPath()).orElse("")) {
         case "density" -> var10000 = (double)10.0F * (double)level;
         case "breach" -> var10000 = (double)4.0F * (double)level;
         case "wind_burst" -> var10000 = (double)6.0F * (double)level;
         case "smite" -> var10000 = (double)1.0F * (double)level;
         case "fire_aspect" -> var10000 = (double)1.5F * (double)level;
         case "mending" -> var10000 = (double)5.0F;
         case "unbreaking" -> var10000 = (double)0.5F * (double)level;
         default -> var10000 = 0.3 * (double)level;
      }

      return var10000;
   }

   public static boolean isShield(ItemStack stack) {
      return !stack.isEmpty() && stack.is(Items.SHIELD);
   }

   public static double scoreShield(ItemStack stack) {
      if (!isShield(stack)) {
         return (double)0.0F;
      } else {
         double score = (double)2.0F;
         ItemEnchantments enchantments = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
         if (enchantments != null && !enchantments.isEmpty()) {
            for(Holder<Enchantment> holder : enchantments.keySet()) {
               score += shieldEnchantValue(holder, enchantments.getLevel(holder));
            }
         }

         return score;
      }
   }

   private static double weaponEnchantValue(Holder<Enchantment> holder, int level) {
      double var10000;
      switch ((String)holder.unwrapKey().map(ResourceKey::identifier).map((loc) -> loc.getPath()).orElse("")) {
         case "sharpness" -> var10000 = (double)2.5F * (double)level;
         case "smite" -> var10000 = (double)1.0F * (double)level;
         case "bane_of_arthropods" -> var10000 = 0.8 * (double)level;
         case "fire_aspect" -> var10000 = (double)1.5F * (double)level;
         case "looting" -> var10000 = (double)1.0F * (double)level;
         case "knockback" -> var10000 = (double)1.0F * (double)level;
         case "sweeping_edge" -> var10000 = (double)1.0F * (double)level;
         case "mending" -> var10000 = (double)5.0F;
         case "unbreaking" -> var10000 = (double)0.5F * (double)level;
         default -> var10000 = 0.3 * (double)level;
      }

      return var10000;
   }

   private static double shieldEnchantValue(Holder<Enchantment> holder, int level) {
      double var10000;
      switch ((String)holder.unwrapKey().map(ResourceKey::identifier).map((loc) -> loc.getPath()).orElse("")) {
         case "mending" -> var10000 = (double)5.0F;
         case "unbreaking" -> var10000 = (double)0.5F * (double)level;
         default -> var10000 = 0.1 * (double)level;
      }

      return var10000;
   }
}
