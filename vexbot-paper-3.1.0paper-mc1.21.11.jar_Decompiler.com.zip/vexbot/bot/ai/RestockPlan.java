package vexbot.bot.ai;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class RestockPlan {
   private static final Map<Item, Integer> GLOBAL = new ConcurrentHashMap();
   private static final Map<String, Map<Item, Integer>> TEAMS = new ConcurrentHashMap();

   private RestockPlan() {
   }

   public static int carryTarget(String teamName, ItemStack stack) {
      Item item = stack.getItem();
      if (teamName != null && !teamName.isBlank()) {
         Map<Item, Integer> t = (Map)TEAMS.get(teamName.toLowerCase(Locale.ROOT));
         if (t != null) {
            Integer v = (Integer)t.get(item);
            if (v != null) {
               return v;
            }
         }
      }

      Integer g = (Integer)GLOBAL.get(item);
      return g == null ? -1 : g;
   }

   public static void set(String teamName, Item item, int count) {
      Map<Item, Integer> target = teamName != null && !teamName.isBlank() ? (Map)TEAMS.computeIfAbsent(teamName.toLowerCase(Locale.ROOT), (k) -> new ConcurrentHashMap()) : GLOBAL;
      if (count <= 0) {
         target.remove(item);
      } else {
         target.put(item, count);
      }

   }

   public static void clear(String teamName) {
      if (teamName != null && !teamName.isBlank()) {
         TEAMS.remove(teamName.toLowerCase(Locale.ROOT));
      } else {
         GLOBAL.clear();
      }

   }

   public static Map<String, Integer> view(String teamName) {
      Map<Item, Integer> src = teamName != null && !teamName.isBlank() ? (Map)TEAMS.getOrDefault(teamName.toLowerCase(Locale.ROOT), Map.of()) : GLOBAL;
      Map<String, Integer> out = new LinkedHashMap();
      src.forEach((item, n) -> out.put(BuiltInRegistries.ITEM.getKey(item).toString(), n));
      return out;
   }

   public static void load(String teamName, Map<String, Integer> saved) {
      clear(teamName);
      saved.forEach((id, n) -> {
         Item item = resolve(id);
         if (item != null) {
            set(teamName, item, n);
         }

      });
   }

   public static Item resolve(String id) {
      Identifier key = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
      return key == null ? null : (Item)BuiltInRegistries.ITEM.getOptional(key).orElse((Object)null);
   }
}
