package vexbot.bot.ai;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.util.BotCommands;
import vexbot.util.ElytraFlight;
import vexbot.util.InventoryUtils;

public final class ElytraFollowController {
   private static final double ALTITUDE = (double)8.0F;
   private static final double FOLLOW_CATCHUP_DIST = (double)9.0F;
   private static final double FOLLOW_HOLD_DIST = (double)4.5F;
   private static final double ALT_TOLERANCE = (double)3.0F;
   private static final int ROCKET_INTERVAL = 40;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private boolean flying = false;
   private int chestSaveSlot = -1;
   private int rocketCd = 0;

   public ElytraFollowController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
   }

   public boolean isFlying() {
      return this.flying;
   }

   public boolean tickFly(Vec3 slotXZ, double leaderY) {
      if (!this.ensureElytra()) {
         this.land();
         return false;
      } else {
         this.flying = true;
         String name = this.bot.getScoreboardName();
         if (this.rocketCd > 0) {
            --this.rocketCd;
         }

         if (this.bot.onGround()) {
            BotCommands.jumpOnce(this.server, name);
            return true;
         } else {
            Vec3 goal = new Vec3(slotXZ.x, leaderY + (double)8.0F, slotXZ.z);
            Vec3 to = goal.subtract(this.bot.position());
            double horiz = Math.sqrt(to.x * to.x + to.z * to.z);
            float yaw = (float)Math.toDegrees(Math.atan2(-to.x, to.z));
            float pitch = (float)(-Math.toDegrees(Math.atan2(to.y, Math.max((double)0.5F, horiz))));
            if (pitch < -45.0F) {
               pitch = -45.0F;
            }

            if (pitch > 45.0F) {
               pitch = 45.0F;
            }

            this.bot.setYRot(yaw);
            this.bot.yHeadRot = yaw;
            this.bot.setXRot(pitch);
            if (!this.bot.isFallFlying()) {
               ElytraFlight.beginGlide(this.bot);
               if (this.rocketCd <= 0 && this.hasRocket()) {
                  this.fireRocket();
                  this.rocketCd = 40;
               }

               return true;
            } else {
               boolean behind = horiz > (double)9.0F;
               boolean tooLow = this.bot.getY() < goal.y - (double)3.0F;
               boolean closeOrAhead = horiz < (double)4.5F;
               if (this.rocketCd <= 0 && !closeOrAhead && (behind || tooLow) && this.hasRocket()) {
                  this.fireRocket();
                  this.rocketCd = 40;
               }

               return true;
            }
         }
      }
   }

   private boolean hasRocket() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
            return true;
         }
      }

      return false;
   }

   private void fireRocket() {
      Inventory inv = this.bot.getInventory();
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
            slot = i;
            break;
         }
      }

      if (slot < 0) {
         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
               slot = i;
               break;
            }
         }

         if (slot < 0) {
            return;
         }

         slot = InventoryUtils.moveToHotbarSafe(inv, slot);
      }

      int prev = InventoryUtils.selected(inv);
      InventoryUtils.select(inv, slot);
      this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(slot), InteractionHand.MAIN_HAND);
      InventoryUtils.select(inv, prev);
   }

   public void land() {
      if (this.flying) {
         this.flying = false;
         this.rocketCd = 0;
         if (this.chestSaveSlot >= 0) {
            ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
            int plateSlot = this.chestSaveSlot;
            if (!isChestPiece(this.bot.getInventory().getItem(plateSlot))) {
               plateSlot = -1;

               for(int i = 0; i < 36; ++i) {
                  if (isChestPiece(this.bot.getInventory().getItem(i))) {
                     plateSlot = i;
                     break;
                  }
               }
            }

            if (plateSlot >= 0) {
               ItemStack saved = this.bot.getInventory().getItem(plateSlot).copy();
               this.bot.getInventory().setItem(plateSlot, chest.copy());
               this.bot.setItemSlot(EquipmentSlot.CHEST, saved);
            }

            this.chestSaveSlot = -1;
         }

         if (this.bot.isFallFlying()) {
            this.bot.stopFallFlying();
         }

      }
   }

   public void reset() {
      this.land();
   }

   private boolean ensureElytra() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (ElytraFlight.isUsable(chest)) {
         return true;
      } else {
         int slot = this.findElytra();
         if (slot < 0) {
            return false;
         } else {
            ItemStack elytra = this.bot.getInventory().getItem(slot).copy();
            this.bot.getInventory().setItem(slot, ItemStack.EMPTY);
            this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            if (chest.is(Items.ELYTRA)) {
               this.bot.getInventory().setItem(slot, chest.copy());
            } else if (!chest.isEmpty()) {
               this.bot.getInventory().setItem(slot, chest.copy());
               this.chestSaveSlot = slot;
            } else {
               this.chestSaveSlot = -1;
            }

            return true;
         }
      }
   }

   private int findElytra() {
      for(int i = 0; i < 36; ++i) {
         if (ElytraFlight.isUsable(this.bot.getInventory().getItem(i))) {
            return i;
         }
      }

      return -1;
   }

   private static boolean isChestPiece(ItemStack s) {
      return ArmorEvaluator.getSlot(s) == EquipmentSlot.CHEST && !s.is(Items.ELYTRA);
   }
}
