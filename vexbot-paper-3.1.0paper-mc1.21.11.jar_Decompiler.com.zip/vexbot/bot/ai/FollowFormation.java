package vexbot.bot.ai;

import net.minecraft.world.phys.Vec3;

public final class FollowFormation {
   public static final int DEFAULT_SIZE = 6;
   public static final double SPACING = (double)2.0F;
   public static final int DEFAULT_ROW_WIDTH = 3;

   public static boolean isCentred(Type t) {
      return t == FollowFormation.Type.SQUARE || t == FollowFormation.Type.CIRCLE || t == FollowFormation.Type.HEXAGON || t == FollowFormation.Type.WALL;
   }

   public static boolean worldAligned(Type t) {
      return t == FollowFormation.Type.SQUARE || t == FollowFormation.Type.CIRCLE || t == FollowFormation.Type.HEXAGON;
   }

   private FollowFormation() {
   }

   public static Type fromString(String s) {
      if (s == null) {
         return FollowFormation.Type.NONE;
      } else {
         Type var10000;
         switch (s.toLowerCase()) {
            case "column":
            case "col":
            case "file":
            case "vertical":
            case "line-vertical":
               var10000 = FollowFormation.Type.COLUMN;
               break;
            case "line":
            case "abreast":
            case "horizontal":
               var10000 = FollowFormation.Type.LINE;
               break;
            case "rows":
            case "row":
               var10000 = FollowFormation.Type.ROWS;
               break;
            case "triangle":
            case "wedge":
            case "v":
            case "arrow":
               var10000 = FollowFormation.Type.TRIANGLE;
               break;
            case "grid":
               var10000 = FollowFormation.Type.GRID;
               break;
            case "square":
            case "box":
               var10000 = FollowFormation.Type.SQUARE;
               break;
            case "circle":
            case "ring":
            case "round":
            case "surround":
               var10000 = FollowFormation.Type.CIRCLE;
               break;
            case "hexagon":
            case "hex":
            case "hexagonal":
               var10000 = FollowFormation.Type.HEXAGON;
               break;
            case "wall":
            case "shieldwall":
            case "shield_wall":
            case "phalanx":
               var10000 = FollowFormation.Type.WALL;
               break;
            default:
               var10000 = FollowFormation.Type.NONE;
         }

         return var10000;
      }
   }

   public static String[] names() {
      return new String[]{"column", "line", "rows", "triangle", "grid", "square", "circle", "hexagon", "wall"};
   }

   public static double[] localOffset(Type type, int i, int n, int rowWidth) {
      return localOffset(type, i, n, rowWidth, (double)2.0F);
   }

   public static double[] localOffset(Type type, int i, int n, int rowWidth, double spacing) {
      double s = spacing > (double)0.0F ? spacing : (double)2.0F;
      int w = rowWidth > 0 ? rowWidth : 3;
      switch (type.ordinal()) {
         case 1:
            return new double[]{(double)(i + 1) * s, (double)0.0F};
         case 2:
            return new double[]{s, ((double)i - (double)(n - 1) / (double)2.0F) * s};
         case 3:
         case 5:
            int rows = (n + w - 1) / w;
            int r = i / w;
            int col = i % w;
            int width = Math.min(w, n - r * w);
            double back = (double)(r + 1) * s;
            return new double[]{back, ((double)col - (double)(width - 1) / (double)2.0F) * s};
         case 4:
            int r = 0;

            int start;
            for(start = 0; start + r + 1 <= i; ++r) {
               start += r + 1;
            }

            int posInRow = i - start;
            int width = r + 1;
            return new double[]{(double)(r + 1) * s, ((double)posInRow - (double)(width - 1) / (double)2.0F) * s};
         case 6:
            return squareOffset(i, size(rowWidth), s);
         case 7:
            return circleOffset(i, n, size(rowWidth), s);
         case 8:
            return hexOffset(i, s);
         case 9:
            int wide = size(rowWidth);
            int r = i / wide;
            int col = i % wide;
            int width = Math.min(wide, n - r * wide);
            return new double[]{(double)r * s, ((double)col - (double)(width - 1) / (double)2.0F) * s};
         default:
            return new double[]{(double)0.0F, (double)0.0F};
      }
   }

   private static int size(int rowWidth) {
      return rowWidth > 0 ? rowWidth : 6;
   }

   private static double[] squareOffset(int i, int size, double s) {
      int sq = Math.max(1, size);
      int seen = 0;

      for(int k = 0; k * 2 < sq; ++k) {
         int side = sq - 2 * k;
         int cells = side <= 1 ? 1 : 4 * side - 4;
         if (i < seen + cells) {
            int j = i - seen;
            int col;
            int row;
            if (side <= 1) {
               row = k;
               col = k;
            } else if (j < side) {
               col = k + j;
               row = k;
            } else if (j < side + (side - 1)) {
               col = k + side - 1;
               row = k + 1 + (j - side);
            } else if (j < side + 2 * (side - 1)) {
               int t = j - (side + side - 1);
               col = k + side - 2 - t;
               row = k + side - 1;
            } else {
               int t = j - (side + 2 * (side - 1));
               col = k;
               row = k + side - 2 - t;
            }

            double centre = (double)(sq - 1) / (double)2.0F;
            return new double[]{((double)row - centre) * s, ((double)col - centre) * s};
         }

         seen += cells;
      }

      return new double[]{(double)0.0F, (double)0.0F};
   }

   private static double[] circleOffset(int i, int n, int size, double s) {
      int count = Math.max(1, n);
      double radius = (double)Math.max(1, size - 1) * s / (double)2.0F;
      if (count > 1) {
         radius = Math.max(radius, s / ((double)2.0F * Math.sin(Math.PI / (double)count)));
      }

      double angle = (Math.PI * 2D) * (double)i / (double)count;
      return new double[]{Math.cos(angle) * radius, Math.sin(angle) * radius};
   }

   private static double[] hexOffset(int i, double s) {
      if (i == 0) {
         return new double[]{(double)0.0F, (double)0.0F};
      } else {
         int idx = i - 1;
         int seen = 0;

         for(int r = 1; r < 64; ++r) {
            int cells = 6 * r;
            if (idx < seen + cells) {
               int j = idx - seen;
               int edge = j / r;
               int step = j % r;
               double radius = (double)r * s;
               double a0 = Math.toRadians((double)60.0F * (double)edge);
               double a1 = Math.toRadians((double)60.0F * (double)(edge + 1));
               double x0 = Math.cos(a0) * radius;
               double z0 = Math.sin(a0) * radius;
               double x1 = Math.cos(a1) * radius;
               double z1 = Math.sin(a1) * radius;
               double t = (double)step / (double)r;
               return new double[]{x0 + (x1 - x0) * t, z0 + (z1 - z0) * t};
            }

            seen += cells;
         }

         return new double[]{(double)0.0F, (double)0.0F};
      }
   }

   public static boolean reservesCentre(Type t) {
      return t == FollowFormation.Type.HEXAGON;
   }

   public static Vec3 slotWorld(Type type, int i, int n, int rowWidth, Vec3 leaderPos, float leaderYawDeg, boolean centreTaken) {
      boolean shift = centreTaken && reservesCentre(type);
      return slotWorld(type, shift ? i + 1 : i, shift ? n + 1 : n, rowWidth, leaderPos, leaderYawDeg);
   }

   public static Vec3 slotWorldSpacedCentred(Type type, int i, int n, int rowWidth, Vec3 leaderPos, float leaderYawDeg, boolean centreTaken, double spacing) {
      boolean shift = centreTaken && reservesCentre(type);
      return slotWorldSpaced(type, shift ? i + 1 : i, shift ? n + 1 : n, rowWidth, leaderPos, leaderYawDeg, spacing);
   }

   public static Vec3 slotWorld(Type type, int i, int n, int rowWidth, Vec3 leaderPos, float leaderYawDeg) {
      return slotWorldSpaced(type, i, n, rowWidth, leaderPos, leaderYawDeg, (double)2.0F);
   }

   public static Vec3 slotWorldSpaced(Type type, int i, int n, int rowWidth, Vec3 leaderPos, float leaderYawDeg, double spacing) {
      if (type == FollowFormation.Type.NONE) {
         return leaderPos;
      } else {
         double[] off = localOffset(type, i, Math.max(1, n), rowWidth, spacing);
         double back = off[0];
         double side = off[1];
         double yaw = Math.toRadians((double)leaderYawDeg);
         double fx = -Math.sin(yaw);
         double fz = Math.cos(yaw);
         double rx = Math.cos(yaw);
         double rz = Math.sin(yaw);
         double x = leaderPos.x - fx * back + rx * side;
         double z = leaderPos.z - fz * back + rz * side;
         return new Vec3(x, leaderPos.y, z);
      }
   }

   public static enum Type {
      NONE,
      COLUMN,
      LINE,
      ROWS,
      TRIANGLE,
      GRID,
      SQUARE,
      CIRCLE,
      HEXAGON,
      WALL;

      // $FF: synthetic method
      private static Type[] $values() {
         return new Type[]{NONE, COLUMN, LINE, ROWS, TRIANGLE, GRID, SQUARE, CIRCLE, HEXAGON, WALL};
      }
   }
}
