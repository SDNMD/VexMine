package vexbot.bot.ai;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.bot.perf.BotAiTier;
import vexbot.bot.perf.BotAiTierResolver;
import vexbot.compat.McCompat;
import vexbot.fakeplayer.bot.BotPlayerActionPack;
import vexbot.march.TeamMarch;
import vexbot.march.TeamSurround;
import vexbot.path.PathWalker;
import vexbot.platform.Internals;
import vexbot.settings.TechniqueConfig;
import vexbot.stats.Stats;
import vexbot.team.TeamFormationOrders;
import vexbot.team.TeamManager;
import vexbot.team.TeamTactics;
import vexbot.team.TeamTargetBalancer;
import vexbot.util.BotCommands;
import vexbot.util.BotMath;
import vexbot.util.ElytraFlight;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.LedgeGuard;
import vexbot.util.MeleeWallGuard;
import vexbot.util.MeleeWeaponGuard;
import vexbot.util.SwapEngine;
import vexbot.util.UseSlowdown;
import vexbot.util.WebDetect;

public class SwordPvpController {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-AI");
   private double attackRange = (double)3.0F;
   private static final double FAR_PEARL_RANGE = (double)12.0F;
   private static final float PEARL_ESCAPE_FLOOR = 6.0F;
   private static final double SPEARMACE_OPENER_MIN = (double)10.0F;
   private static final double SPEARMACE_OPENER_MAX = (double)30.0F;
   private static final double FAR_PEARL_MAX = (double)36.0F;
   private static final float AIM_HEAD_MAX_ROT_PER_TICK = 32.0F;
   private static final double RANGED_MIN = (double)7.0F;
   private static final double RANGED_MAX = (double)20.0F;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final WTapController wTap;
   private final PathFollower pathFollower;
   private final ArmorManager armorManager;
   private final OffhandManager offhandManager;
   private final ShieldController shieldController;
   private final WeaponSelector weaponSelector;
   private final RangedController rangedController;
   private final HealingController healingController;
   private final LoadoutManager loadoutManager;
   private final StrafeController strafeController;
   private final ApproachStyle approachStyle = new ApproachStyle();
   private final FightState fightState = new FightState();
   private final SwingReach swingReach = new SwingReach();
   private final PotionController potionController;
   private final BunnyHopController bunnyHopController;
   private final CobwebEscapeController cobwebEscapeController;
   private final ChorusEscapeController chorusEscapeController;
   private final BubbleWebController bubbleWebController;
   private final RocketlessElytraController rocketlessElytraController;
   private final FireEscapeController fireEscapeController;
   private final CobwebTrapController cobwebTrapController;
   private final WaterBucketClutchController waterBucketClutchController;
   private final WebDrainController webDrainController;
   private final ElytraMaceController elytraMaceController;
   private final ElytraSpearController elytraSpearController;
   private final WindBurstElytraController windBurstElytraController;
   private final TridentMaceController tridentMaceController;
   private final MaceController maceController;
   private final SpearMaceController spearMaceController;
   private boolean lastMaceComboWasSpear = false;
   private final PearlCatchController pearlCatchController;
   private final PredictionWebController predictionWebController;
   private final HeadWebController headWebController;
   private final MendingController mendingController;
   private int mendDisengageTicks = 0;
   private static final int MEND_DISENGAGE_TICKS = 30;
   private int mendDisengageCooldown = 0;
   private static final int MEND_DISENGAGE_COOLDOWN = 200;
   private boolean mendIntent = false;
   private static final float MEND_INTENT_MIN_HP = 12.0F;
   private final ScaffoldController scaffoldController;
   private final BoatTravelController boatTravelController;
   private final JumpPlaceController jumpPlaceController;
   private final TunnelController tunnelController;
   private final OrbitalStrikeController orbitalStrikeController;
   private final MaceDiveForecast diveForecast;
   private final MaceTotemGuard maceTotemGuard;
   private LivingEntity fallDiver = null;
   private final IdleHumanizer idleHumanizer;
   private boolean maceTotemUp = false;
   private final CartController cartController;
   private final SwapTechniques swapTechniques;
   private int blockingTicks = 0;
   private int backstabTicks = 0;
   private int shieldHoldTicks = 0;
   private int idleNavTick = Integer.MIN_VALUE;
   private int shieldReraiseCd = 0;
   private static final int SHIELD_RERAISE_COOLDOWN = 30;
   private final CrossbowChargeController crossbowChargeController;
   private final CrystalPvpController crystalPvpController;
   private final AnchorPvpController anchorPvpController;
   private final EnderPearlController enderPearlController;
   private final ComboBreakController comboBreakController;
   private final ElytraFollowController elytraFollowController;
   private final RestockController restockController;
   private final ShulkerRaidController shulkerRaidController;
   private final WanderController wanderController;
   private LivingEntity target;
   private int stanceStuckTicks = 0;
   private int consumableHeldTicks = 0;
   private int tickCount;
   private boolean prevMacePvpActive = false;
   private final Set<Long> ffaLooted = new HashSet();
   private BlockPos ffaChestTarget;
   private int ffaRescanCooldown = 0;
   private int ffaLootCooldown = 0;
   private static final int FFA_LOOT_INTERVAL = 2;
   private boolean ffaChestOpened = false;
   private float ffaChopProgress = 0.0F;
   private static final int FFA_CHOP_MAX_TICKS = 40;
   private LivingEntity lastCombatTarget = null;
   private int killLootTicks = 0;
   private Vec3 killLootPos = null;
   private int ffaDropCooldown = 0;
   private final Set<UUID> ownJunkDrops = new HashSet();
   private static final int DROP_PICKUP_TIMEOUT = 200;
   private UUID ffaPickupDropId = null;
   private int ffaPickupTicks = 0;
   private UUID containerPickupId = null;
   private int containerPickupTicks = 0;
   private static final int MAX_BOTS_PER_CHEST = 3;
   private static final Map<Long, Map<String, Long>> ffaChestClaims = new ConcurrentHashMap();
   private boolean offhandWantShield = false;
   private boolean offhandShieldMode = true;
   private volatile String revengeTargetName = null;
   private LivingEntity revengeMobTarget = null;
   private LivingEntity escortThreat = null;
   private static final double ESCORT_LEASH = (double)32.0F;
   private boolean jumpedForCrit = false;
   private int critJumpTick = 0;
   private int critSwingHold = 0;
   private boolean pendingAttack = false;
   private boolean swingIsMiss = false;
   private float meleeForwardImpulse = 1.0F;
   private float meleeStrafeImpulse = 0.0F;
   private static final double MACE_DIVE_HEIGHT_MIN = (double)3.0F;
   private static final double MACE_DIVE_HORIZ_SQR = (double)12.25F;
   private static final double MACE_DIVE_FALL_VEL = -0.3;
   private static final int FALL_SHIELD_TICKS = 10;
   private static final double FALL_SHIELD_HOLD_HORIZ_SQR = (double)20.25F;
   private static final double FALL_SHIELD_LAND_HEIGHT = (double)0.5F;
   private static final int FALL_SHIELD_MAX_HOLD = 80;
   private static final int FALL_SHIELD_LEAD_TICKS = 10;
   private static final int MACE_DODGE_TICKS = 10;
   private static final int MACE_DODGE_REFRESH = 5;
   private int dodgeTicksLeft = 0;
   private int fallShieldTicksLeft = 0;
   private boolean fallDiveActive = false;
   private int fallShieldHoldTicks = 0;
   private float dodgeYaw = 0.0F;
   private boolean fallShieldUsesOffhand = false;
   private int mainHandShieldSlot = -1;
   private int mainHandShieldSrc = -1;
   private boolean wTapThisCycle = true;
   private boolean critThisCycle = true;
   private boolean comboThisCycle = false;
   private int reactionCountdown = -1;
   private final AxeController axeController;
   private int healPunishWindow = 0;
   private int armorPunishWindow = 0;
   private int targetPingMs = 0;
   private boolean targetHighPing = false;
   private int answerSwingWindow = 0;
   private float prevTargCharge = 0.0F;
   private int hitSelectHold = 0;
   private boolean hitSelectThisCycle = false;
   private int oppJumpResets = 0;
   private int uppercutRolledChain = -1;
   private boolean uppercutThisChain = false;
   private int jrJitter = 0;
   private int noKbHoldW = 0;
   private int prevTargetHurtTime = 0;
   private int targetHitObserve = 0;
   private float comboCadenceBoost = 0.0F;
   private int releaseAfterHit = 0;
   private int sprintHitHold = 0;
   private int shieldBaitCooldown = 0;
   private int overextendWindow = 0;
   private static final float JR_CHARGE_THRESHOLD = 0.85F;
   private static final double JR_RANGE = (double)3.5F;
   private static final double JR_FACING_DOT = 0.7;
   private static final int JR_COOLDOWN_TICKS = 15;
   private int jumpResetCooldown = 0;
   private static final Random RNG = new Random();
   private static final float COMBO_ATTACK_AT = 1.0F;
   private boolean inCombo = false;
   private int comboHitsLeft = 0;
   private static final float FINISH_HP = 10.0F;
   private Vec3 fleeLastPos = null;
   private Entity fleeLastTarget = null;
   private int fleeLastTick = -1;
   private Vec3 fleeVel;
   private static final double COMBO_SPACING = 2.7;
   private static final float COMBO_STRAFE_ANGLE = 34.0F;
   private static final float COMBO_STRAFE_SCALE = 0.55F;
   private static final int GOLDEN_RULE_MAX_WAIT = 6;
   private int swingHold;
   private boolean prevTargetOnGround;
   private LivingEntity readTarget;
   private int targetLandWindow;
   private static final int CRIT_DEFLECT_WINDOW = 3;
   private boolean prevTargetBlocking;
   private int mirrorPunishWindow;
   private static final int MIRROR_PUNISH_TICKS = 5;
   private boolean prevShieldDisabled;
   private static final float SHIELD_BROKEN_ADVANCE = 0.45F;
   private boolean shieldBrokenNow;
   private int autoCritWindow;
   private static final int AUTO_CRIT_TICKS = 8;
   private int critFollowUpWindow;
   private static final int CRIT_FOLLOWUP_TICKS = 12;
   private static final double CRIT_PUNISH_RANGE = 2.6;
   private int critChainWindow;
   private static final int CRIT_CHAIN_TICKS = 30;
   private static final double CRIT_CHAIN_RANGE = 3.4;
   private static final float CRIT_CHAIN_JUMP_CHARGE = 0.55F;
   private static final float CRIT_MIN_CHARGE = 0.92F;
   private static final double CRIT_ZONE_MAX = (double)2.0F;
   private int prevHurtTime;
   private boolean jumpResetPending;
   private int crouchDodgeTicks;
   private static final int CROUCH_DODGE_TICKS = 3;
   private static final int KNOCKBACK_MAX_TICKS = 10;
   private int knockbackTicks;
   private static final int GROUND_KB_YIELD_TICKS = 1;
   private int kbYieldWindow;
   private static final int COUNTER_STUN_TICKS = 8;
   private int counterStunWindow;
   private static final int COMBO_LOCK_HITS = 3;
   private static final int COMBO_LOCK_WINDOW = 40;
   private int comboLockHits;
   private int comboLockDecay;
   private final String botName;
   private EffectiveSettings effectiveSettings;
   private BotAiTier aiTier;
   private double dist;
   private boolean specialExecuting;
   private boolean cpvpMode;
   private boolean elytraOffense;
   private boolean healing;
   private boolean cartHealthOk;
   private WeaponSelector.WeaponType weapon;
   private boolean spearMaceOffered;
   private boolean blocking;
   private boolean targetEating;
   private boolean fireEscapeBusy;
   private static final double CONTAINER_PICKUP_RADIUS = (double)14.0F;
   private static final double SHARE_REACH = (double)4.5F;
   private String closerThanShare;
   private String closerThanRevenge;
   private float straightYaw;
   private float straightPitch;
   private static final int FEINT_DURATION_MIN = 3;
   private static final int FEINT_DURATION_MAX = 6;
   private static final int FEINT_COOLDOWN = 25;
   private int feintTimer;
   private int feintCooldown;
   private int feintDir;
   private double adaptiveScore;
   private static final int WIND_CHARGE_RESERVE = 32;
   private static final int WIND_CHARGE_RODS_PER_CHECK = 4;
   private static final int REACT_NONE = 0;
   private static final int REACT_DEFLECT = 1;
   private static final int REACT_PUNISH = 2;
   private static final int DEFLECT_WINDOW = 4;
   private static final int PUNISH_WINDOW = 14;
   private int hitReact;
   private int hitReactTicks;
   private int hitReactDelay;
   private boolean earlyCritThisCycle;
   private static final float CHAIN_HP_FRACTION = 0.8F;
   private static final int CRYSTAL_AFTER_CHAIN_TICKS = 60;
   private static final int MIRROR_TICKS = 60;
   private int crystalAfterChainUntil;
   private int oppAnchorTick;
   private int oppCrystalTick;
   private boolean anchorAfterCrystal;
   private static final double CRYSTAL_HIGH_GROUND = (double)1.0F;
   private static final double CPVP_FOLLOW_DIST = (double)3.0F;
   private static final double CPVP_CROWD_DIST = 1.8;
   private int cpvpStrafeDir;
   private int cpvpStrafeTicks;
   private static final int CPVP_ANCHOR_MIN_GAP_TICKS = 10;
   private int lastAnchorActiveTick;
   private static final int LOW_GROUND_RADIUS = 8;
   private static final int LOW_GROUND_MAX_DROP = 8;
   private static final int LOW_GROUND_MIN_DROP = 2;
   private static final double LOW_GROUND_PLACE_RANGE = (double)6.5F;
   private static final double FOLLOW_ENGAGE_RANGE = (double)64.0F;
   private static final double STANDOFF_ENTER_DIST = 0.8;
   private static final double STANDOFF_LEAVE_DIST = 1.4;
   private boolean atStandoff;
   private static final double SLOT_ENTER_DIST = 0.45;
   private static final double SLOT_LEAVE_DIST = 0.9;
   private boolean inFormationSlot;
   private float formationYaw;
   private boolean speedScaled;
   private boolean leashReturning;
   private boolean formationStance;

   public boolean isMendIntent() {
      return this.mendIntent;
   }

   private boolean maySpecial(boolean alreadyExecuting) {
      return alreadyExecuting || !this.mendIntent;
   }

   private int findHotbarTag(TagKey<Item> tag) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(tag)) {
            return i;
         }
      }

      return -1;
   }

   private static int ffaOtherClaimants(long key, long now, String me) {
      Map<String, Long> m = (Map)ffaChestClaims.get(key);
      if (m == null) {
         return 0;
      } else {
         int n = 0;

         for(Map.Entry<String, Long> e : m.entrySet()) {
            if (!((String)e.getKey()).equals(me) && e.getValue() != null && (Long)e.getValue() > now) {
               ++n;
            }
         }

         return n;
      }
   }

   public boolean isShieldBroken() {
      return this.shieldBrokenNow;
   }

   private boolean maceDiveIncoming(LivingEntity target) {
      if (!EffectiveSettings.of(this.botName).shieldOnMaceDive()) {
         return false;
      } else if (this.diveForecast.soonest() != null) {
         return true;
      } else if (target == null) {
         return false;
      } else {
         double dy = target.getY() - this.bot.getY();
         if (!(dy < (double)2.0F) && !(dy > (double)24.0F)) {
            if (this.fallVelY(target) > -0.15) {
               return false;
            } else {
               double dx = target.getX() - this.bot.getX();
               double dz = target.getZ() - this.bot.getZ();
               return Math.sqrt(dx * dx + dz * dz) <= (double)6.0F;
            }
         } else {
            return false;
         }
      }
   }

   public SwordPvpController(ServerPlayer bot, MinecraftServer server) {
      this.fleeVel = Vec3.ZERO;
      this.swingHold = 0;
      this.prevTargetOnGround = true;
      this.readTarget = null;
      this.targetLandWindow = 0;
      this.prevTargetBlocking = false;
      this.mirrorPunishWindow = 0;
      this.prevShieldDisabled = false;
      this.shieldBrokenNow = false;
      this.autoCritWindow = 0;
      this.critFollowUpWindow = 0;
      this.critChainWindow = 0;
      this.prevHurtTime = 0;
      this.jumpResetPending = false;
      this.crouchDodgeTicks = 0;
      this.knockbackTicks = 0;
      this.kbYieldWindow = 0;
      this.counterStunWindow = 0;
      this.comboLockHits = 0;
      this.comboLockDecay = 0;
      this.aiTier = BotAiTier.FULL;
      this.straightYaw = 0.0F;
      this.straightPitch = 0.0F;
      this.feintTimer = 0;
      this.feintCooldown = 0;
      this.feintDir = 0;
      this.adaptiveScore = (double)0.0F;
      this.hitReact = 0;
      this.hitReactTicks = 0;
      this.hitReactDelay = 0;
      this.earlyCritThisCycle = false;
      this.crystalAfterChainUntil = 0;
      this.oppAnchorTick = -10000;
      this.oppCrystalTick = -10000;
      this.anchorAfterCrystal = false;
      this.cpvpStrafeDir = 1;
      this.cpvpStrafeTicks = 0;
      this.lastAnchorActiveTick = -10000;
      this.atStandoff = false;
      this.inFormationSlot = false;
      this.formationYaw = 0.0F;
      this.speedScaled = true;
      this.leashReturning = false;
      this.formationStance = false;
      this.bot = bot;
      this.botName = bot.getScoreboardName();
      this.server = server;
      this.wTap = new WTapController();
      this.pathFollower = new PathFollower(bot, server);
      this.armorManager = new ArmorManager(bot, server);
      this.offhandManager = new OffhandManager(bot);
      this.shieldController = new ShieldController(bot);
      this.weaponSelector = new WeaponSelector(bot);
      this.rangedController = new RangedController(bot);
      this.crossbowChargeController = new CrossbowChargeController(bot);
      this.healingController = new HealingController(bot, server);
      this.loadoutManager = new LoadoutManager(bot);
      this.strafeController = new StrafeController();
      this.potionController = new PotionController(bot, server);
      this.bunnyHopController = new BunnyHopController(bot, server);
      this.axeController = new AxeController(bot);
      this.cobwebEscapeController = new CobwebEscapeController(bot);
      this.chorusEscapeController = new ChorusEscapeController(bot, server);
      this.bubbleWebController = new BubbleWebController(bot, server);
      this.fireEscapeController = new FireEscapeController(bot);
      this.cobwebTrapController = new CobwebTrapController(bot, server);
      this.waterBucketClutchController = new WaterBucketClutchController(bot);
      this.webDrainController = new WebDrainController(bot);
      this.elytraMaceController = new ElytraMaceController(bot, server);
      this.elytraSpearController = new ElytraSpearController(bot, server);
      this.windBurstElytraController = new WindBurstElytraController(bot, server);
      ElytraMaceController var10000 = this.elytraMaceController;
      WindBurstElytraController var10001 = this.windBurstElytraController;
      Objects.requireNonNull(var10001);
      var10000.setOnSmashLanded(var10001::armAfterSmash);
      this.rocketlessElytraController = new RocketlessElytraController(bot, server);
      RocketlessElytraController var3 = this.rocketlessElytraController;
      var10001 = this.windBurstElytraController;
      Objects.requireNonNull(var10001);
      var3.setOnSmashLanded(var10001::armAfterSmash);
      this.tridentMaceController = new TridentMaceController(bot, server);
      this.maceController = new MaceController(bot, server);
      this.spearMaceController = new SpearMaceController(bot, server);
      this.pearlCatchController = new PearlCatchController(bot, server);
      this.predictionWebController = new PredictionWebController(bot, server);
      this.headWebController = new HeadWebController(bot, server);
      this.mendingController = new MendingController(bot, server);
      this.scaffoldController = new ScaffoldController(bot, server);
      this.boatTravelController = new BoatTravelController(bot, server);
      this.jumpPlaceController = new JumpPlaceController(bot, server);
      this.tunnelController = new TunnelController(bot, server);
      this.orbitalStrikeController = new OrbitalStrikeController(bot, server);
      this.diveForecast = new MaceDiveForecast(bot, this.botName);
      this.maceTotemGuard = new MaceTotemGuard(bot, this.botName, this.diveForecast);
      this.idleHumanizer = new IdleHumanizer(bot, server, this.botName);
      this.cartController = new CartController(bot, server);
      this.swapTechniques = new SwapTechniques(bot);
      this.crystalPvpController = new CrystalPvpController(bot, server);
      this.anchorPvpController = new AnchorPvpController(bot, server);
      this.enderPearlController = new EnderPearlController(bot, server);
      this.comboBreakController = new ComboBreakController(bot, server);
      this.elytraFollowController = new ElytraFollowController(bot, server);
      this.restockController = new RestockController(bot, server, this.enderPearlController);
      this.shulkerRaidController = new ShulkerRaidController(bot, server);
      this.wanderController = new WanderController(bot, server);
      this.healingController.setGapTools(this.enderPearlController, this.cobwebTrapController);
   }

   public void tick() {
      ++this.tickCount;
      if (this.target != null) {
         this.targetVelocity();
      }

      ElytraFlight.guard(this.bot);
      InvisibleSuitUp.tick(this.bot);
      UseSlowdown.tick(this.bot);
      this.fireEscapeBusy = this.fireEscapeController.isActive() && this.fireEscapeController.tick();
      if (BotSettings.movementFrozen) {
         BotCommands.stopMoving(this.server, this.botName);
      }

      if (BotManager.getLookOrder(this.botName) != null) {
         this.shieldController.reset();
         BotCommands.stopMoving(this.server, this.botName);
         this.bot.setSprinting(false);
         BotManager.tickLookAt(this.bot, this.server);
      } else {
         this.diveForecast.update();
         this.maceTotemUp = this.maceTotemGuard.tick(this.tickCount);
         this.setSpeedScale(1.0F);
         ServerPlayer leashBoss = this.onOrderedFight() ? null : TeamFormationOrders.leashTarget(this.server, this.bot, this.leashReturning);
         this.leashReturning = leashBoss != null;
         if (leashBoss != null) {
            this.releaseFormationStance();
            this.shieldController.reset();
            this.escortThreat = null;
            this.elytraFollowController.land();
            LivingEntity prevTarget = this.target;
            this.target = leashBoss;
            this.pathFollower.chase(leashBoss.position(), leashBoss.position());
            this.target = prevTarget;
            this.bot.setSprinting(true);
            BotManager.tickLookAt(this.bot, this.server);
         } else {
            String followTarget = BotManager.getFollowTarget(this.botName);
            if (followTarget != null) {
               this.escortThreat = this.resolveEscortThreat(followTarget);
               if (this.escortThreat == null) {
                  this.shieldController.reset();
                  this.tickFollow(followTarget);
                  return;
               }

               this.releaseFormationStance();
               this.elytraFollowController.land();
            } else {
               this.escortThreat = null;
               this.elytraFollowController.land();
               this.releaseFormationStance();
            }

            if (BotManager.isInFfaLootMode(this.botName)) {
               boolean geared = this.ffaGeared();
               if (!geared) {
                  if (this.tickFfaLoot()) {
                     return;
                  }
               } else if (this.ffaChestTarget != null) {
                  this.releaseChest(false);
               }

               if (this.tickFfaPickup(geared)) {
                  return;
               }
            } else if (this.ffaChestTarget != null) {
               this.releaseChest(false);
            }

            try {
               if (!this.tickReadAndEscape()) {
                  if (this.tickUpkeep()) {
                     return;
                  }

                  if (this.tickSurvival()) {
                     return;
                  }

                  if (this.tickNoTarget()) {
                     return;
                  }

                  if (this.tickSpecials()) {
                     return;
                  }

                  if (this.tickWeaponChoice()) {
                     return;
                  }

                  if (this.tickMeleeOpeners()) {
                     return;
                  }

                  if (this.tickMeleeReads()) {
                     return;
                  }

                  this.tickMeleeExchange();
                  return;
               }
            } finally {
               this.enforceConsumingMovementLimits();
               if (!this.jumpedForCrit && this.critSwingHold <= 0) {
                  if (this.sprintHitHold > 0) {
                     this.meleeMove(this.botName, 1.0F, 0.0F);
                     this.bot.setSprinting(true);
                     BotCommands.setSprinting(this.server, this.botName, true);
                     --this.sprintHitHold;
                  }
               } else {
                  this.sprintOffForCrit();
                  if (this.critSwingHold > 0) {
                     --this.critSwingHold;
                  }
               }

            }

         }
      }
   }

   private boolean tickReadAndEscape() {
      this.effectiveSettings = EffectiveSettings.of(this.botName);
      this.attackRange = this.effectiveSettings.attackRange();
      this.applyReachAttribute();
      float offhandHp = this.bot.getHealth();
      BotSettings.OffhandPreference offhandPref = this.effectiveSettings.offhandPreference();
      if (offhandPref == BotSettings.OffhandPreference.TOTEM) {
         this.offhandShieldMode = false;
         this.offhandWantShield = false;
      } else if (offhandPref == BotSettings.OffhandPreference.SHIELD) {
         float totemHp = (float)(this.effectiveSettings.offhandTotemHearts() * (double)2.0F);
         if (this.offhandShieldMode) {
            if (offhandHp <= totemHp) {
               this.offhandShieldMode = false;
            }
         } else if (offhandHp >= totemHp + 4.0F) {
            this.offhandShieldMode = true;
         }

         this.offhandWantShield = this.offhandShieldMode;
      } else {
         float offhandLowHp = (float)(this.effectiveSettings.retreatHealthHearts() * (double)2.0F);
         if (this.offhandShieldMode) {
            if (offhandHp <= offhandLowHp) {
               this.offhandShieldMode = false;
            }
         } else if (offhandHp >= offhandLowHp + 4.0F) {
            this.offhandShieldMode = true;
         }

         this.offhandWantShield = this.offhandShieldMode && this.isPureSwordKit();
      }

      if (!this.offhandWantShield) {
         this.offhandManager.tickTotem();
      }

      this.enderPearlController.tickPearlState(this.target);
      boolean sleepSkip = this.aiTier == BotAiTier.SLEEP && this.target == null && this.bot.hurtTime == 0 && (this.tickCount & 3) != 0;
      if (!sleepSkip) {
         this.target = this.findTarget();
      }

      this.dist = this.target != null ? (double)this.bot.distanceTo(this.target) : Double.MAX_VALUE;
      this.fightState.tick(this.bot, this.target);
      if (!this.fightState.beingCombod()) {
         this.uppercutRolledChain = -1;
      }

      boolean macePvpActive = this.maceController.isExecuting() || this.elytraMaceController.isExecuting() || this.tridentMaceController.isExecuting() || this.elytraSpearController.isExecuting() || this.spearMaceController.isExecuting() || this.pearlCatchController.isExecuting() || this.rocketlessElytraController.isExecuting() || this.windBurstElytraController.isExecuting();
      this.specialExecuting = macePvpActive || this.cartController.isExecuting() || this.crystalPvpController.isExecuting() || this.anchorPvpController.isExecuting() || this.spearMaceController.isExecuting() || this.elytraMaceController.isExecuting() || this.windBurstElytraController.isExecuting() || this.tridentMaceController.isExecuting() || this.pearlCatchController.isExecuting();
      if (!sleepSkip) {
         this.aiTier = BotAiTierResolver.resolve(this.bot, this.target, this.dist, macePvpActive, this.specialExecuting);
      }

      this.cpvpMode = this.aiTier == BotAiTier.FULL && this.inCrystalPvpMode(this.target);
      boolean freshHit = this.bot.hurtTime > this.prevHurtTime;
      this.prevHurtTime = this.bot.hurtTime;
      if (freshHit) {
         this.noteBlastFrom(this.target);
         this.kbYieldWindow = 1;
         ++this.comboLockHits;
         this.comboLockDecay = 40;
         this.chooseHitReaction(this.cpvpMode, this.specialExecuting);
         if (this.hitReact == 0 && this.counterStunWindow == 0 && this.isHardIncomingHit() && EffectiveSettings.of(this.botName).rollCounterStun()) {
            this.counterStunWindow = 8;
            this.sprintHitHold = 0;
            this.releaseAfterHit = 0;
            this.sprintOffForCrit();
            if (this.bot.onGround()) {
               BotCommands.jumpOnce(this.server, this.botName);
            }
         }
      } else if (this.kbYieldWindow > 0) {
         --this.kbYieldWindow;
      }

      if (this.counterStunWindow > 0) {
         --this.counterStunWindow;
      }

      if (this.hitReactTicks > 0 && --this.hitReactTicks == 0) {
         this.hitReact = 0;
      }

      if (this.noKbHoldW > 0 && this.kbYieldWindow == 0) {
         --this.noKbHoldW;
      }

      if (this.comboLockDecay > 0) {
         --this.comboLockDecay;
      } else {
         this.comboLockHits = 0;
      }

      this.jumpResetPending = false;
      if (this.cpvpMode || this.specialExecuting) {
         this.crouchDodgeTicks = 0;
      }

      this.bot.setShiftKeyDown(this.crouchDodgeTicks > 0);
      if (this.crouchDodgeTicks > 0) {
         --this.crouchDodgeTicks;
      }

      if (this.aiTier != BotAiTier.SLEEP && this.tickCount % 100 == 0 && BotSettings.gameLogs == BotSettings.GameLogs.DETAILED) {
         LivingEntity lastHurtBy = this.bot.getLastHurtByMob();
         LOGGER.info("[VexBot-AI] {} | hp={} | tier={} | revengeTarget={} | autoTarget={} | lastHurtBy={} | playerCount={}", new Object[]{this.botName, this.bot.getHealth(), this.aiTier, this.revengeTargetName, this.effectiveSettings.autoTarget(), lastHurtBy != null ? lastHurtBy.getName().getString() : "null", this.bot.level().players().size()});
      }

      if (this.prevMacePvpActive && !macePvpActive) {
         this.waterBucketClutchController.suppressThisFall();
      }

      this.prevMacePvpActive = macePvpActive;
      if (!macePvpActive && !this.cpvpMode && this.waterBucketClutchController.tick()) {
         return true;
      } else if (this.fireEscapeBusy) {
         return true;
      } else if (this.effectiveSettings.fireEscape() && this.fireEscapeController.tick()) {
         return true;
      } else if (!this.bubbleWebController.isActive() && this.chorusEscapeController.tick()) {
         return true;
      } else {
         return !this.bubbleWebController.isActive() && this.cobwebEscapeController.tick();
      }
   }

   private boolean tickUpkeep() {
      if (this.webDrainController.tick(this.target)) {
         return true;
      } else {
         if (this.aiTier != BotAiTier.SLEEP) {
            this.crystalPvpController.tickDetap(this.target);
         }

         boolean criticalArmour = this.mendingController.hasCriticalPiece();
         this.mendIntent = this.mendingController.wantsToMend() && this.bot.getHealth() >= 12.0F && !this.cpvpMode && !this.crystalPvpController.isExecuting();
         if (this.mendDisengageTicks > 0) {
            --this.mendDisengageTicks;
         }

         if (this.mendDisengageCooldown > 0) {
            --this.mendDisengageCooldown;
         }

         if (this.mendIntent && this.target != null && this.target.isAlive() && this.dist < (double)5.0F && this.bot.getHealth() >= 12.0F && !this.specialExecuting && !this.mendingController.isMending() && this.mendDisengageTicks == 0 && this.mendDisengageCooldown == 0) {
            this.mendDisengageTicks = 30;
            this.mendDisengageCooldown = 200;
         }

         if (this.mendDisengageTicks > 0 && this.target != null && this.target.isAlive() && this.dist < (double)5.0F && this.bot.getHealth() >= 10.0F && !this.cpvpMode && !this.crystalPvpController.isExecuting() && !this.specialExecuting) {
            double awayX = this.bot.getX() - this.target.getX();
            double awayZ = this.bot.getZ() - this.target.getZ();
            if (awayX * awayX + awayZ * awayZ > 1.0E-4) {
               float awayYaw = (float)Math.toDegrees(Math.atan2(-awayX, awayZ));
               double lookX = -Math.sin(Math.toRadians((double)awayYaw));
               double lookZ = Math.cos(Math.toRadians((double)awayYaw));
               if (!LedgeGuard.wouldFallDangerously(this.bot, lookX, lookZ, 3)) {
                  this.bot.setYRot(awayYaw);
                  this.bot.yHeadRot = awayYaw;
                  this.bot.setXRot(0.0F);
                  BotCommands.setSprinting(this.server, this.botName, true);
                  BotCommands.moveForward(this.server, this.botName);
                  return true;
               }
            }

            this.mendDisengageTicks = 0;
         }

         double mendGap = criticalArmour ? (double)4.0F : (double)5.0F;
         float mendHp = criticalArmour ? 10.0F : 12.0F;
         double abortGap = criticalArmour ? (double)3.0F : (double)3.5F;
         float abortHp = criticalArmour ? 6.0F : 8.0F;
         boolean combatMendLull = this.target != null && this.target.isAlive() && this.dist >= mendGap && this.bot.getHealth() >= mendHp && !this.specialExecuting;
         if (this.target != null && this.target.isAlive() && !combatMendLull) {
            if (this.mendingController.isMending() && (this.dist < abortGap || this.bot.getHealth() < abortHp)) {
               this.mendingController.abortMending();
            }
         } else if (this.mendingController.tick(this.target)) {
            return true;
         }

         this.tickStanceWatchdog();
         if (!this.healingController.isHealing() && !this.cartController.isExecuting() && !this.crystalPvpController.isExecuting() && !this.anchorPvpController.isExecuting() && !this.spearMaceController.isExecuting() && !this.elytraMaceController.isExecuting() && !this.windBurstElytraController.isExecuting() && !this.rocketlessElytraController.isExecuting() && !this.elytraSpearController.isExecuting() && !this.tridentMaceController.isExecuting() && !this.pearlCatchController.isExecuting() && (!this.restockController.isExecuting() || !this.bot.isFallFlying()) && !this.potionController.isSplashing() && !this.jumpedForCrit) {
            if (this.tickCount % 20 == 0) {
               this.armorManager.equipFromInventory();
            }

            if (this.tickCount % 20 == 0) {
               this.craftWindChargesFromBreezeRods();
            }

            if (this.tickCount % 20 == 10) {
               this.craftPlanksFromLogs();
            }

            this.offhandManager.tick(this.offhandWantShield);
            this.loadoutManager.tick();
         }

         boolean isHealingNow = this.healingController.isHealing();
         double potDist = this.target != null ? (double)this.bot.distanceTo(this.target) : Double.MAX_VALUE;
         boolean potDrinking = this.potionController.tick(this.target, potDist, !isHealingNow);
         if (potDrinking && !isHealingNow) {
            this.rangedController.reset();
            this.shieldController.reset();
            return true;
         } else {
            isHealingNow = this.effectiveSettings.shieldOnMaceDive();
            boolean movementFrozen = BotSettings.movementFrozen;
            MaceDiveForecast.Dive dive = this.diveForecast.soonest();
            potDrinking = dive != null && dive.ticks() <= 10;
            if (potDrinking || this.target != null && this.isIncomingFallAttack(this.target)) {
               this.fallDiver = (LivingEntity)(potDrinking ? dive.diver() : this.target);
               this.fallDiveActive = true;
               this.fallShieldHoldTicks = 0;
               if (!movementFrozen && this.dodgeTicksLeft <= 5) {
                  this.startMaceDodge(this.fallDiver);
               }
            }

            if (this.fallDiveActive) {
               if (this.fallDiver == null || !this.fallDiver.isAlive()) {
                  this.fallDiver = this.target;
               }

               if (isHealingNow && this.shouldHoldFallShield(this.fallDiver) && ++this.fallShieldHoldTicks <= 80) {
                  this.fallShieldTicksLeft = 10;
               } else {
                  this.fallDiveActive = false;
                  this.fallShieldHoldTicks = 0;
               }
            }

            if (!isHealingNow) {
               this.fallShieldTicksLeft = 0;
               this.stopFallAttackShield();
            } else if (this.fallShieldTicksLeft > 0) {
               if (this.fallDiver != null && this.fallDiver != this.target) {
                  this.faceEntity(this.fallDiver);
               } else if (this.target != null) {
                  this.lookAtTarget();
               }

               this.tickFallAttackShield();
               --this.fallShieldTicksLeft;
            }

            if (!isHealingNow || this.fallShieldTicksLeft <= 0) {
               this.stopFallAttackShield();
            }

            if (this.maceTotemUp) {
               if (this.dodgeTicksLeft > 0 && !movementFrozen) {
                  this.tickMaceDodgeMovement();
                  --this.dodgeTicksLeft;
               }

               this.maceTotemGuard.reassert();
               return true;
            } else if (this.dodgeTicksLeft > 0 && !movementFrozen) {
               this.tickMaceDodgeMovement();
               --this.dodgeTicksLeft;
               return true;
            } else {
               return false;
            }
         }
      }
   }

   private boolean tickSurvival() {
      boolean inCombat = this.target != null;
      boolean crystalling = this.crystalPvpController.isExecuting() || this.cpvpMode;
      boolean safeStyle = this.effectiveSettings.playStyle() == BotSettings.PlayStyle.SAFE;
      boolean bubbleBadSpot = this.comboLockHits >= 3 || this.bot.getHealth() <= (float)(this.effectiveSettings.retreatHealthHearts() * (double)2.0F);
      if ((this.bubbleWebController.isActive() || this.target != null && !this.cpvpMode && !crystalling && safeStyle && bubbleBadSpot && this.bubbleWebController.canStart()) && this.bubbleWebController.tick(this.target, this.healingController, this.enderPearlController)) {
         return true;
      } else {
         boolean comboLocked = this.comboLockHits >= 3;
         boolean elytraExecuting = this.elytraMaceController.isExecuting() || this.windBurstElytraController.isExecuting() || this.rocketlessElytraController.isExecuting() || this.elytraSpearController.isExecuting();
         this.elytraOffense = this.target != null && this.aiTier == BotAiTier.FULL && !this.cpvpMode && this.effectiveSettings.useElytraMace() && (elytraExecuting || comboLocked && this.elytraMaceController.hasGearForCombo());
         boolean holdHealForOffense = this.elytraOffense && this.offhandManager.hasTotemInOffhand() && (elytraExecuting || !this.targetIsEating()) && !this.healingController.starving();
         float retreatHp = (float)(this.effectiveSettings.retreatHealthHearts() * (double)2.0F);
         if (this.target != null && !crystalling && this.comboBreakController.tick(this.target, this.fightState, this.effectiveSettings, this.enderPearlController)) {
            return true;
         } else {
            boolean criticalHp = this.bot.getHealth() <= 6.0F;
            if (this.target != null && !crystalling && (!holdHealForOffense || criticalHp) && this.bot.getHealth() <= retreatHp && !this.targetIsEating() && !this.totemSacrificeActive(this.target) && this.effectiveSettings.useEnderPearl() && this.enderPearlController.tryThrow(this.target)) {
               this.shieldController.reset();
               this.healingController.requestSyncHeal();
               return true;
            } else {
               boolean targetHealingNow = this.target != null && this.targetIsEating();
               this.healPunishWindow = 0;
               if (targetHealingNow && !crystalling && !holdHealForOffense) {
                  if (this.bot.getHealth() > 18.0F) {
                     this.healPunishWindow = 6;
                  } else {
                     this.healingController.requestSyncHeal();
                  }
               }

               if (this.target != null && !crystalling && !holdHealForOffense && this.bot.getHealth() <= retreatHp && !targetHealingNow && this.target.getHealth() >= 16.0F && !this.healingController.isHealing()) {
                  this.cobwebTrapController.tryEmergencyWeb(this.target);
               }

               if (this.healingController.starving() && !this.healingController.isHealing() && this.hasFoodInInventory()) {
                  this.spearMaceController.reset();
                  this.elytraMaceController.reset();
                  this.windBurstElytraController.reset();
                  this.rocketlessElytraController.reset();
                  this.elytraSpearController.reset();
                  this.pearlCatchController.reset();
                  this.maceController.reset();
               }

               if (holdHealForOffense) {
                  this.healingController.abortHealing();
                  this.healing = false;
               } else if (this.totemSacrificeActive(this.target) && !this.healingController.starving()) {
                  this.healingController.abortHealing();
                  this.healing = false;
               } else {
                  this.healing = this.healingController.tick(inCombat && !crystalling, this.target, crystalling);
               }

               if (this.healing) {
                  this.shieldController.reset();
               }

               if (this.healing && this.healingController.isRetreating() && !crystalling) {
                  this.bunnyHopController.tick(true);
                  this.rangedController.reset();
                  this.shieldController.reset();
                  return true;
               } else {
                  if (TeamMarch.hasOrder(this.botName)) {
                     ServerPlayer var10000 = this.bot;
                     MinecraftServer var10001 = this.server;
                     PathFollower var10002 = this.pathFollower;
                     Objects.requireNonNull(var10002);
                     if (TeamMarch.tick(var10000, var10001, var10002::chase)) {
                        return true;
                     }
                  }

                  ServerPlayer var11 = this.bot;
                  MinecraftServer var12 = this.server;
                  PathFollower var13 = this.pathFollower;
                  Objects.requireNonNull(var13);
                  if (TeamSurround.tick(var11, var12, var13::chase)) {
                     return true;
                  } else {
                     if (this.target != null && this.restockController.isExecuting()) {
                        if (this.restockController.tick(this.target)) {
                           return true;
                        }
                     } else if (this.target != null && !this.healing && !crystalling) {
                        if (this.restockController.tick(this.target)) {
                           return true;
                        }

                        if (!this.restockController.isExecuting() && this.shulkerRaidController.tick(this.target)) {
                           return true;
                        }
                     }

                     if (this.shulkerRaidController.isExecuting() && (this.healing || crystalling || this.restockController.isExecuting())) {
                        this.shulkerRaidController.reset();
                     }

                     return false;
                  }
               }
            }
         }
      }
   }

   private boolean tickNoTarget() {
      if (this.aiTier == BotAiTier.SLEEP && this.target == null) {
         if ((this.tickCount & 3) != 0 && this.bot.hurtTime == 0 && this.idleNavTick != this.tickCount - 1 && this.bot.onGround() && this.bot.getDeltaMovement().horizontalDistanceSqr() < 1.0E-4) {
            return true;
         } else {
            this.inCombo = false;
            this.comboHitsLeft = 0;
            this.critChainWindow = 0;
            this.axeController.reset();
            this.jumpedForCrit = false;
            this.critSwingHold = 0;
            this.sprintHitHold = 0;
            this.releaseHotbarShield();
            this.elytraMaceController.reset();
            this.windBurstElytraController.reset();
            this.rocketlessElytraController.reset();
            this.elytraSpearController.reset();
            this.tridentMaceController.reset();
            this.maceController.reset();
            this.spearMaceController.reset();
            this.pearlCatchController.reset();
            this.cartController.reset();
            this.swapTechniques.reset();
            this.crystalPvpController.reset();
            this.anchorPvpController.reset();
            this.shieldController.reset();
            this.rangedController.reset();
            this.cobwebTrapController.reset();
            this.predictionWebController.reset();
            this.headWebController.reset();
            this.chorusEscapeController.reset();
            this.bubbleWebController.reset();
            this.scaffoldController.reset();
            this.boatTravelController.reset();
            this.tunnelController.reset();
            this.comboBreakController.reset();
            this.orbitalStrikeController.reset();
            this.shulkerRaidController.reset();
            if (this.idleNavTick != this.tickCount - 1) {
               this.pathFollower.reset();
            }

            if (this.restockController.tick((LivingEntity)null)) {
               return true;
            } else if (this.idleNav(this.tickContainerPickup())) {
               return true;
            } else if (this.restockController.tryPackLoot()) {
               return true;
            } else {
               ServerPlayer var5 = this.bot;
               MinecraftServer var10 = this.server;
               PathFollower var15 = this.pathFollower;
               Objects.requireNonNull(var15);
               if (this.idleNav(TeamSurround.tick(var5, var10, var15::chase))) {
                  return true;
               } else {
                  var5 = this.bot;
                  var10 = this.server;
                  var15 = this.pathFollower;
                  Objects.requireNonNull(var15);
                  if (this.idleNav(TeamMarch.tick(var5, var10, var15::chase))) {
                     return true;
                  } else {
                     var5 = this.bot;
                     var10 = this.server;
                     var15 = this.pathFollower;
                     Objects.requireNonNull(var15);
                     if (this.idleNav(PathWalker.tick(var5, var10, var15::chase))) {
                        return true;
                     } else {
                        boolean fetchingArmor = this.armorManager.tickNavigation();
                        if (!fetchingArmor) {
                           this.idle();
                        }

                        return true;
                     }
                  }
               }
            }
         }
      } else if (this.target == null) {
         this.inCombo = false;
         this.comboHitsLeft = 0;
         this.critChainWindow = 0;
         this.axeController.reset();
         this.jumpedForCrit = false;
         this.critSwingHold = 0;
         this.sprintHitHold = 0;
         this.releaseHotbarShield();
         this.elytraMaceController.reset();
         this.windBurstElytraController.reset();
         this.rocketlessElytraController.reset();
         this.elytraSpearController.reset();
         this.tridentMaceController.reset();
         this.maceController.reset();
         this.spearMaceController.reset();
         this.pearlCatchController.reset();
         this.cartController.reset();
         this.swapTechniques.reset();
         this.crystalPvpController.reset();
         this.anchorPvpController.reset();
         this.shieldController.reset();
         this.rangedController.reset();
         this.cobwebTrapController.reset();
         this.predictionWebController.reset();
         this.headWebController.reset();
         this.chorusEscapeController.reset();
         this.bubbleWebController.reset();
         this.scaffoldController.reset();
         this.boatTravelController.reset();
         this.tunnelController.reset();
         this.orbitalStrikeController.reset();
         this.shulkerRaidController.reset();
         if (this.idleNavTick != this.tickCount - 1) {
            this.pathFollower.reset();
         }

         if (this.restockController.tick((LivingEntity)null)) {
            return true;
         } else if (this.idleNav(this.tickContainerPickup())) {
            return true;
         } else if (this.restockController.tryPackLoot()) {
            return true;
         } else {
            if (BotManager.isInFfaLootMode(this.botName)) {
               if (this.lastCombatTarget != null) {
                  if (!this.lastCombatTarget.isAlive()) {
                     this.killLootPos = this.lastCombatTarget.position();
                     this.killLootTicks = 200;
                  }

                  this.lastCombatTarget = null;
               }

               if (this.killLootTicks > 0) {
                  --this.killLootTicks;
                  if (this.idleNav(this.tickKillLootPickup())) {
                     return true;
                  }
               }
            } else {
               this.lastCombatTarget = null;
               this.killLootTicks = 0;
               this.killLootPos = null;
            }

            if (this.effectiveSettings.useCarting() && this.crossbowChargeController.tick()) {
               return true;
            } else {
               ServerPlayer var10001 = this.bot;
               MinecraftServer var10002 = this.server;
               PathFollower var10003 = this.pathFollower;
               Objects.requireNonNull(var10003);
               if (this.idleNav(TeamSurround.tick(var10001, var10002, var10003::chase))) {
                  return true;
               } else {
                  var10001 = this.bot;
                  var10002 = this.server;
                  var10003 = this.pathFollower;
                  Objects.requireNonNull(var10003);
                  if (this.idleNav(TeamMarch.tick(var10001, var10002, var10003::chase))) {
                     return true;
                  } else {
                     var10001 = this.bot;
                     var10002 = this.server;
                     var10003 = this.pathFollower;
                     Objects.requireNonNull(var10003);
                     if (this.idleNav(PathWalker.tick(var10001, var10002, var10003::chase))) {
                        return true;
                     } else {
                        boolean fetchingArmor = this.armorManager.tickNavigation();
                        if (!fetchingArmor) {
                           this.idle();
                        }

                        return true;
                     }
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   private boolean tickSpecials() {
      this.armorManager.resetNavigation();
      this.lastCombatTarget = this.target;
      this.updateAdaptiveStyle(this.target);
      Vec3 standoff = SpreadOut.standoffFor(this.bot, this.botName, this.target);
      if (standoff != null) {
         this.aimAtTarget();
         double sdx = standoff.x - this.bot.getX();
         double sdz = standoff.z - this.bot.getZ();
         double sd = Math.sqrt(sdx * sdx + sdz * sdz);
         if (sd < (this.atStandoff ? 1.4 : 0.8)) {
            this.pathFollower.reset();
            this.atStandoff = true;
            this.bot.setSprinting(false);
         } else {
            this.atStandoff = false;
            this.pathFollower.chase(standoff, this.target.position());
         }

         return true;
      } else {
         this.atStandoff = false;
         boolean diveIncoming = this.maceDiveIncoming(this.target);
         if (!this.healing && !diveIncoming && this.effectiveSettings.useScaffolding() && this.scaffoldController.tick(this.target)) {
            return true;
         } else if (!this.healing && this.boatTravelController.tick(this.target, this.dist)) {
            return true;
         } else if (this.healing || !this.effectiveSettings.techniques().pearlGrapple || !this.effectiveSettings.pearlChasing() || !this.tunnelController.stuck() || !this.enderPearlController.tryThrowToward(this.target) && !this.enderPearlController.tickDropIn(this.target)) {
            if (!this.healing && this.tunnelController.tick(this.target, this.dist)) {
               return true;
            } else if (!this.healing && this.effectiveSettings.useOrbitalStrike() && this.orbitalStrikeController.tick(this.target, this.dist)) {
               return true;
            } else if (this.aiTier == BotAiTier.FULL && !this.healing && !this.specialExecuting && !this.cpvpMode && this.target != null && this.swapTechniques.maybeSwapAttack(this.target, this.dist, this.effectiveSettings)) {
               if (this.swapTechniques.consumeLaunchFlag()) {
                  this.windBurstElytraController.armAfterSmash();
               }

               return true;
            } else {
               if (CartDoctrine.isGuideDoctrine(this.botName)) {
                  float floor = this.effectiveSettings.playStyle() == BotSettings.PlayStyle.AGGRESSIVE ? 12.0F : 14.0F;
                  this.cartHealthOk = this.bot.getHealth() + this.bot.getAbsorptionAmount() >= floor || CartDoctrine.isFinishWindow(this.bot, this.target);
               } else {
                  this.cartHealthOk = this.effectiveSettings.playStyle() != BotSettings.PlayStyle.SAFE || this.bot.getHealth() >= 14.0F;
               }

               boolean playerTarget = this.target instanceof Player;
               if (this.aiTier == BotAiTier.FULL && !this.healing && this.cartHealthOk && playerTarget && this.maySpecial(this.cartController.isExecuting()) && this.cartController.tick(this.target, this.dist)) {
                  return true;
               } else {
                  if (this.anchorPvpController.takeChainEnded()) {
                     this.crystalAfterChainUntil = this.tickCount + 60;
                  }

                  if (this.aiTier == BotAiTier.FULL && !this.healing && playerTarget) {
                     this.watchOpponentTool(this.target);
                     if (this.crystalPvpController.isExecuting()) {
                        boolean busy = this.crystalPvpController.tick(this.target, this.dist);
                        if (!this.crystalPvpController.isExecuting()) {
                           this.anchorAfterCrystal = true;
                        }

                        if (busy) {
                           if (this.crystalPvpController.isExecuting() && !this.crystalPvpController.isRepositioning()) {
                              this.cpvpFootwork(this.target, this.dist);
                           }

                           return true;
                        }
                     } else if (this.anchorPvpController.isExecuting()) {
                        this.lastAnchorActiveTick = this.tickCount;
                        if (this.anchorPvpController.tick(this.target, this.dist, false)) {
                           return true;
                        }
                     } else {
                        CpvpPick pick = this.pickCpvp(this.target);
                        if (pick == SwordPvpController.CpvpPick.CRYSTAL) {
                           if (this.crystalPvpController.tick(this.target, this.dist)) {
                              this.crystalAfterChainUntil = 0;
                              return true;
                           }

                           if (this.anchorPvpController.tick(this.target, this.dist, false)) {
                              this.lastAnchorActiveTick = this.tickCount;
                              this.anchorAfterCrystal = false;
                              return true;
                           }
                        } else {
                           if (this.anchorPvpController.tick(this.target, this.dist, pick == SwordPvpController.CpvpPick.CHAIN)) {
                              this.lastAnchorActiveTick = this.tickCount;
                              this.anchorAfterCrystal = false;
                              return true;
                           }

                           if (!this.anchorPvpController.isCoolingDown() && this.crystalPvpController.tick(this.target, this.dist)) {
                              return true;
                           }
                        }
                     }
                  }

                  if (this.cpvpMode && !this.target.isBlocking()) {
                     Vec3 lowGround = this.target.getY() > this.bot.getY() + (double)0.5F ? this.findLowGroundNearTarget(this.target) : null;
                     if (lowGround != null && this.bot.position().distanceTo(lowGround) > (double)1.5F) {
                        this.pathFollower.chase(lowGround, this.target.position());
                        this.lookAtTarget();
                        this.bot.setSprinting(true);
                     } else if (lowGround == null && this.dist > this.attackRange) {
                        if (this.effectiveSettings.techniques().pearlGrapple && this.effectiveSettings.pearlChasing() && !this.spearMaceController.canCloseGap(this.dist) && this.dist > (double)12.0F && this.dist < (double)36.0F && this.bot.hasLineOfSight(this.target) && !this.cobwebTrapController.placedWebRecently() && this.enderPearlController.tryThrowToward(this.target)) {
                           this.lookAtTarget();
                           return true;
                        }

                        if (this.effectiveSettings.useEnderPearl() && this.crystalPvpController.targetInHole(this.target) && this.bot.getY() > this.target.getY() + (double)0.5F && this.dist < (double)36.0F && this.bot.hasLineOfSight(this.target) && this.enderPearlController.tryThrowToward(this.target)) {
                           this.lookAtTarget();
                           return true;
                        }

                        this.pathFollower.chase((Entity)this.target, this.target.position());
                        this.lookAtTarget();
                        this.bot.setSprinting(true);
                     } else {
                        this.pathFollower.reset();
                        this.aimAtTarget();
                        if (!this.healing && this.dist <= this.attackRange && this.bot.hasLineOfSight(this.target) && this.bot.getAttackStrengthScale(0.0F) >= 0.9F) {
                           this.weaponSelector.selectWeapon(this.target, Math.min(this.dist, (double)7.0F), this.target.isBlocking());
                           EquipmentSync.syncNow(this.bot);
                           this.bot.setSprinting(true);
                           this.bot.attack(this.target);
                           McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                        }

                        BotCommands.stopMoving(this.server, this.botName);
                        this.bot.setSprinting(false);
                     }

                     return true;
                  } else {
                     return false;
                  }
               }
            }
         } else {
            return true;
         }
      }
   }

   private boolean tickWeaponChoice() {
      if (this.aiTier == BotAiTier.FULL && !this.healing && this.effectiveSettings.useCarting() && this.crossbowChargeController.tick()) {
         return true;
      } else {
         boolean seesShield = this.axeController.tickSeesShield(this.target);
         if (this.effectiveSettings.techniques().hotbarShieldTracking && !this.healing && this.target != null) {
            if (this.shieldReraiseCd > 0) {
               --this.shieldReraiseCd;
            }

            if (this.tickCount % 20 == 0 && this.findHotbarTag(ItemTags.SWORDS) >= 0) {
               Inventory inv = this.bot.getInventory();
               boolean inHotbar = false;

               for(int i = 0; i < 9; ++i) {
                  if (inv.getItem(i).is(Items.SHIELD)) {
                     inHotbar = true;
                     break;
                  }
               }

               if (!inHotbar) {
                  for(int i = 9; i < 36; ++i) {
                     if (inv.getItem(i).is(Items.SHIELD)) {
                        InventoryUtils.moveToHotbarSafe(inv, i);
                        break;
                     }
                  }
               }
            }

            int shieldSlot = -1;
            Inventory inv2 = this.bot.getInventory();

            for(int i = 0; i < 9; ++i) {
               if (inv2.getItem(i).is(Items.SHIELD)) {
                  shieldSlot = i;
                  break;
               }
            }

            boolean charging = this.dist <= (double)4.0F && this.target.isSprinting();
            if (shieldSlot >= 0 && charging && !this.bot.isUsingItem() && this.shieldHoldTicks <= 0 && this.shieldReraiseCd <= 0) {
               InventoryUtils.select(inv2, shieldSlot);
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
               this.shieldHoldTicks = 10;
               this.lookAtTarget();
               return true;
            }

            if (this.shieldHoldTicks > 0) {
               --this.shieldHoldTicks;
               if (this.shieldHoldTicks == 0) {
                  this.shieldReraiseCd = 30;
               }

               if (this.shieldHoldTicks == 0 && this.bot.isUsingItem()) {
                  this.bot.stopUsingItem();
               } else if (charging) {
                  this.lookAtTarget();
                  return true;
               }
            }
         } else {
            this.releaseHotbarShield();
         }

         if (this.target != null && this.target.isBlocking()) {
            ++this.blockingTicks;
            TechniqueConfig asCfg = this.effectiveSettings.techniques();
            if (asCfg.groundBackstab && !asCfg.stunSlamEnabled() && this.bot.onGround() && this.dist <= (double)4.5F && this.blockingTicks >= 8 && this.backstabTicks < 40) {
               ++this.backstabTicks;
               Vec3 look = this.target.getLookAngle().normalize();
               Vec3 toBot = this.bot.position().subtract(this.target.position()).normalize();
               double dot = look.x * toBot.x + look.z * toBot.z;
               if (!(dot < -0.17)) {
                  Vec3 cross = look.cross(new Vec3((double)0.0F, (double)1.0F, (double)0.0F));
                  boolean left = cross.x * toBot.x + cross.z * toBot.z > (double)0.0F;
                  BotCommands.setMovement(this.server, this.botName, 0.6F, left ? 1.0F : -1.0F);
                  this.lookAtTarget();
                  return true;
               }

               int sw = this.findHotbarTag(ItemTags.SWORDS);
               if (sw >= 0 && this.bot.getAttackStrengthScale(0.0F) > 0.9F) {
                  SwapEngine.syncedAttack(this.bot, sw, this.target);
                  this.backstabTicks = 0;
                  return true;
               }
            }

            if (asCfg.shieldDrain && this.bot.onGround() && this.dist <= (double)3.0F && this.blockingTicks >= 15 && McCompat.invulnerableTime(this.target) <= 10) {
               int axe = this.findHotbarTag(ItemTags.AXES);
               if (axe >= 0) {
                  SwapEngine.syncedAttack(this.bot, axe, this.target);
                  return true;
               }
            }
         } else {
            this.blockingTicks = 0;
            this.backstabTicks = 0;
         }

         this.weapon = !this.healing && !this.cartController.isExecuting() && !this.crystalPvpController.isExecuting() && !this.anchorPvpController.isExecuting() && !this.spearMaceController.isExecuting() && !this.tridentMaceController.isExecuting() && !this.cobwebTrapController.isPlacing() && !this.jumpedForCrit ? this.weaponSelector.selectWeapon(this.target, this.dist, seesShield) : WeaponSelector.WeaponType.SWORD;
         if ((this.weapon == WeaponSelector.WeaponType.BOW || this.weapon == WeaponSelector.WeaponType.CROSSBOW) && BotManager.isInFfaLootMode(this.botName)) {
            this.weapon = this.weaponSelector.selectWeapon(this.target, Math.min(this.dist, (double)7.0F), seesShield);
         }

         this.spearMaceOffered = false;
         if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && this.dist > (double)10.0F && this.dist <= (double)30.0F && this.maySpecial(this.spearMaceController.isExecuting())) {
            this.spearMaceOffered = true;
            if (this.spearMaceController.tick(this.target, this.dist)) {
               this.lastMaceComboWasSpear = true;
               return true;
            }
         }

         if (this.aiTier == BotAiTier.FULL && this.cartHealthOk && !this.healing && this.cartController.wantsToChaseForCart(this.target, this.dist)) {
            this.rangedController.reset();
            this.pathFollower.chase((Entity)this.target, this.target.position());
            this.lookAtTarget();
            this.bot.setSprinting(true);
            this.bunnyHopController.tick(true);
            return true;
         } else if (this.healing || this.cpvpMode || this.weapon != WeaponSelector.WeaponType.BOW && this.weapon != WeaponSelector.WeaponType.CROSSBOW) {
            return false;
         } else {
            this.shieldController.reset();
            this.rangedController.tick(this.target, this.weapon);
            this.manageRangedPosition(this.dist);
            return true;
         }
      }
   }

   private boolean tickMeleeOpeners() {
      this.rangedController.reset();
      if (this.targetIsInWeb() && !this.botIsInWeb()) {
         this.noKbHoldW = 0;
         this.sprintHitHold = 0;
      }

      if (!this.enderPearlController.suppressesWebs() && this.predictionWebController.tick(this.target)) {
         return true;
      } else if (!this.enderPearlController.suppressesWebs() && this.headWebController.tick(this.target)) {
         return true;
      } else if (this.cobwebTrapController.tick(this.target, this.critThisCycle, this.enderPearlController.suppressesWebs())) {
         return true;
      } else if (this.hitReact != 0 && !this.elytraOffense && !this.tridentMaceController.isExecuting() && this.runHitReaction()) {
         return true;
      } else {
         boolean knockedBack = this.knockbackTicks < 10 && (this.kbYieldWindow > 0 || this.isKnockedBack()) && !this.tridentMaceController.isExecuting() && !this.elytraOffense;
         if (knockedBack) {
            if (this.noKbHoldW > 0 && !this.isHardIncomingHit()) {
               --this.noKbHoldW;
               ++this.knockbackTicks;
               this.inCombo = false;
               this.aimAtTarget();
               BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
               if (this.critSwingHold == 0) {
                  this.bot.setSprinting(true);
               }

               return true;
            } else {
               ++this.knockbackTicks;
               this.inCombo = false;
               this.swingHold = 0;
               this.targetLandWindow = 0;
               this.critFollowUpWindow = 0;
               this.maceController.reset();
               this.tridentMaceController.reset();
               this.pathFollower.reset();
               this.aimAtTarget();
               if (this.counterStunWindow > 0) {
                  BotCommands.setMovement(this.server, this.botName, -1.0F, 0.0F);
                  this.sprintHitHold = 0;
                  this.sprintOffForCrit();
               } else {
                  BotCommands.stopMoving(this.server, this.botName);
                  this.bot.setSprinting(false);
               }

               return true;
            }
         } else {
            this.knockbackTicks = 0;
            if (!this.cpvpMode) {
               this.tryJumpReset();
            }

            if (this.weapon == WeaponSelector.WeaponType.SWORD && !this.inCombo && this.bot.onGround() && this.crouchDodgeTicks == 0 && this.bot.getAttackStrengthScale(0.0F) < 0.95F && this.dist <= this.attackRange + (double)0.5F && this.incomingCritDive()) {
               this.crouchDodgeTicks = 3;
            }

            boolean fireworksForElytraMace = this.elytraMaceController.hasFireworksForCombo();
            if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && !this.spearMaceOffered && !this.lastMaceComboWasSpear && this.maySpecial(this.spearMaceController.isExecuting())) {
               this.spearMaceOffered = true;
               if (this.spearMaceController.tick(this.target, this.dist)) {
                  this.lastMaceComboWasSpear = true;
                  return true;
               }
            }

            if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && this.effectiveSettings.useElytraMace() && this.maySpecial(this.elytraMaceController.isExecuting()) && this.elytraMaceController.tick(this.target, this.dist)) {
               this.lastMaceComboWasSpear = false;
               return true;
            } else if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && this.effectiveSettings.useElytraMace() && this.windBurstElytraController.tick(this.target, this.dist)) {
               this.lastMaceComboWasSpear = false;
               return true;
            } else if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && this.effectiveSettings.useElytraMace() && !fireworksForElytraMace && this.maySpecial(this.rocketlessElytraController.isExecuting()) && this.rocketlessElytraController.tick(this.target, this.dist)) {
               this.lastMaceComboWasSpear = false;
               return true;
            } else if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && this.effectiveSettings.useElytraSpear() && this.maySpecial(this.elytraSpearController.isExecuting()) && this.elytraSpearController.tick(this.target, this.dist)) {
               this.lastMaceComboWasSpear = false;
               return true;
            } else if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && (this.tridentMaceController.isExecuting() || TridentMaceController.canAttempt(this.bot)) && this.maySpecial(this.tridentMaceController.isExecuting()) && this.tridentMaceController.tick(this.target, this.dist)) {
               return true;
            } else if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && !this.spearMaceOffered && this.maySpecial(this.spearMaceController.isExecuting()) && this.spearMaceController.tick(this.target, this.dist)) {
               this.lastMaceComboWasSpear = true;
               return true;
            } else if (this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && !fireworksForElytraMace && this.maySpecial(this.pearlCatchController.isExecuting()) && this.pearlCatchController.tick(this.target, this.dist)) {
               return true;
            } else {
               return this.aiTier == BotAiTier.FULL && !this.healing && !this.cpvpMode && this.maySpecial(this.maceController.isExecuting()) && this.maceController.tick(this.target, this.dist);
            }
         }
      }
   }

   private boolean tickMeleeReads() {
      this.blocking = false;
      boolean swordFight = this.weapon == WeaponSelector.WeaponType.SWORD || this.weapon == WeaponSelector.WeaponType.AXE;
      if (!this.healing && swordFight) {
         boolean usingMainHandItem = this.bot.isUsingItem() && this.bot.getUsedItemHand() == InteractionHand.MAIN_HAND;
         boolean shieldAvail = this.offhandManager.hasShieldInOffhand() && !usingMainHandItem;
         if (this.comboShieldLock()) {
            this.shieldController.reset();
            this.blocking = false;
         } else {
            BotSettings.PlayStyle style = this.effectiveSettings.playStyle();
            boolean sacrificeNow = (style == BotSettings.PlayStyle.SAFE || style == BotSettings.PlayStyle.DEFENSIVE) && shieldAvail && this.dist <= (double)4.5F && !this.cpvpMode && WeaponSelector.getType(this.target.getMainHandItem()) == WeaponSelector.WeaponType.AXE;
            this.shieldController.setSacrifice(sacrificeNow);
            if (this.shieldBaitCooldown > 0) {
               --this.shieldBaitCooldown;
            } else if (shieldAvail && this.dist <= (double)3.5F && !this.cpvpMode) {
               float myCharge = this.bot.getAttackStrengthScale(0.0F);
               LivingEntity var9 = this.target;
               float var10000;
               if (var9 instanceof Player) {
                  Player pl = (Player)var9;
                  var10000 = pl.getAttackStrengthScale(0.0F);
               } else {
                  var10000 = 1.0F;
               }

               float theirCharge = var10000;
               if (myCharge >= 0.3F && myCharge <= 0.6F && theirCharge >= 0.6F && this.effectiveSettings.roll()) {
                  this.shieldController.requestBait(4 + RNG.nextInt(4));
                  this.shieldBaitCooldown = 60;
               }
            }

            this.shieldController.tick(this.target, shieldAvail);
            this.blocking = this.shieldController.isBlocking();
         }
      } else {
         this.shieldController.reset();
      }

      this.targetEating = this.targetIsEating();
      if (this.target != null) {
         if (this.target != this.readTarget) {
            this.readTarget = this.target;
            this.oppJumpResets = 0;
            this.comboCadenceBoost = 0.0F;
            this.jrJitter = 0;
            this.targetHitObserve = 0;
            this.prevTargetOnGround = this.target.onGround();
            this.prevTargetBlocking = this.target.isBlocking();
            this.prevTargetHurtTime = this.target.hurtTime;
            LivingEntity targetBlockingNow = this.target;
            float var10001;
            if (targetBlockingNow instanceof Player) {
               Player rp = (Player)targetBlockingNow;
               var10001 = rp.getAttackStrengthScale(0.0F);
            } else {
               var10001 = 0.0F;
            }

            this.prevTargCharge = var10001;
         }

         boolean landedNow = !this.prevTargetOnGround && this.target.onGround();
         this.prevTargetOnGround = this.target.onGround();
         if (landedNow) {
            this.targetLandWindow = 3;
         } else if (this.targetLandWindow > 0) {
            --this.targetLandWindow;
         }

         if (this.critFollowUpWindow > 0) {
            --this.critFollowUpWindow;
         }

         if (this.critChainWindow > 0) {
            --this.critChainWindow;
         }

         this.axeController.tickWindows();
         boolean targetBlockingNow = this.target.isBlocking();
         if (this.prevTargetBlocking && !targetBlockingNow && (double)this.bot.distanceTo(this.target) <= this.attackRange + (double)0.5F && EffectiveSettings.of(this.botName).roll()) {
            this.mirrorPunishWindow = 5;
         }

         this.prevTargetBlocking = targetBlockingNow;
         if (this.mirrorPunishWindow > 0) {
            --this.mirrorPunishWindow;
         }

         ItemStack offh = this.bot.getOffhandItem();
         boolean shieldDisabledNow = offh.is(Items.SHIELD) && this.bot.getCooldowns().isOnCooldown(offh);
         if (shieldDisabledNow && !this.prevShieldDisabled && (double)this.bot.distanceTo(this.target) <= this.attackRange + (double)1.0F && EffectiveSettings.of(this.botName).roll()) {
            this.autoCritWindow = 8;
         }

         this.prevShieldDisabled = shieldDisabledNow;
         this.shieldBrokenNow = shieldDisabledNow;
         if (shieldDisabledNow) {
            this.bot.setSprinting(false);
         }

         this.healingController.setShieldBroken(shieldDisabledNow);
         if (this.autoCritWindow > 0) {
            --this.autoCritWindow;
         }

         if (this.targetArmorMissing(this.target) && (double)this.bot.distanceTo(this.target) <= (double)36.0F) {
            this.armorPunishWindow = 20;
         } else if (this.armorPunishWindow > 0) {
            --this.armorPunishWindow;
         }

         LivingEntity tCharge = this.target;
         int var24;
         if (tCharge instanceof ServerPlayer) {
            ServerPlayer sp2 = (ServerPlayer)tCharge;
            var24 = sp2.connection.latency();
         } else {
            var24 = 0;
         }

         this.targetPingMs = var24;
         this.targetHighPing = this.targetPingMs > 100;
         tCharge = this.target;
         if (tCharge instanceof Player) {
            Player tp = (Player)tCharge;
            float tCharge = tp.getAttackStrengthScale(0.0F);
            if (this.prevTargCharge - tCharge >= 0.4F && (double)this.bot.distanceTo(this.target) <= this.attackRange + (double)0.5F && EffectiveSettings.of(this.botName).roll()) {
               this.answerSwingWindow = 4;
            }

            this.prevTargCharge = tCharge;
         }

         if (this.answerSwingWindow > 0) {
            --this.answerSwingWindow;
         }

         if (this.effectiveSettings.playStyle() == BotSettings.PlayStyle.BALANCED && this.target.getHealth() + 4.0F < this.bot.getHealth() && this.opponentAggressive()) {
            this.overextendWindow = 40;
         } else if (this.overextendWindow > 0) {
            --this.overextendWindow;
         }

         boolean targetFreshHurt = this.target.hurtTime > this.prevTargetHurtTime;
         this.prevTargetHurtTime = this.target.hurtTime;
         if (targetFreshHurt) {
            this.targetHitObserve = 3;
         } else if (this.targetHitObserve > 0) {
            --this.targetHitObserve;
            Vec3 tv = this.target.getDeltaMovement();
            double drift = Math.sqrt(tv.x * tv.x + tv.z * tv.z);
            if (!this.target.onGround() && tv.y > 0.3 && drift < 0.15) {
               if (this.oppJumpResets < 5) {
                  ++this.oppJumpResets;
               }

               this.targetHitObserve = 0;
            } else if (!this.target.onGround() && tv.y > 0.1) {
               this.comboCadenceBoost = Math.max(0.0F, this.comboCadenceBoost - 0.05F);
               this.targetHitObserve = 0;
            } else if (this.targetHitObserve == 0 && this.target.onGround()) {
               this.comboCadenceBoost = Math.min(0.15F, this.comboCadenceBoost + 0.05F);
            }
         }
      }

      return false;
   }

   private void tickMeleeExchange() {
      if (!this.targetEating) {
         float cycleCharge = this.bot.getAttackStrengthScale(0.0F);
         if (cycleCharge < 0.15F) {
            this.wTapThisCycle = true;
            this.critThisCycle = true;
            this.comboThisCycle = true;
            this.reactionCountdown = -1;
            this.hitSelectThisCycle = RNG.nextInt(100) < 45;
            EffectiveSettings cycleEs = EffectiveSettings.of(this.botName);
            this.earlyCritThisCycle = !this.hitSelectThisCycle && cycleEs.difficultyParams().reactionMaxTicks <= 2 && cycleEs.roll();
            this.jrJitter = this.oppJumpResets >= 2 ? RNG.nextInt(4) : 0;
            this.hitSelectHold = 0;
         }
      }

      if (this.dist > this.attackRange) {
         if (this.effectiveSettings.techniques().pearlGrapple && this.effectiveSettings.pearlChasing() && !this.spearMaceController.canCloseGap(this.dist) && this.dist > (double)12.0F && this.dist < (double)36.0F && this.bot.getHealth() > 6.0F && this.bot.hasLineOfSight(this.target) && !this.cobwebTrapController.placedWebRecently() && this.enderPearlController.tryThrowToward(this.target)) {
            if (this.bot.getHealth() <= this.bot.getMaxHealth() - 4.0F) {
               this.healingController.requestSyncHeal();
            }

            this.lookAtTarget();
            return;
         }

         this.releaseAfterHit = 0;
         this.sprintHitHold = 0;
         boolean punishWindow = this.targetEating || this.armorPunishWindow > 0 || this.overextendWindow > 0;
         boolean maceStyleKit = this.weapon == WeaponSelector.WeaponType.MACE || this.spearMaceController.isExecuting() || this.elytraMaceController.isExecuting() || this.rocketlessElytraController.isExecuting() || this.elytraSpearController.isExecuting() || this.windBurstElytraController.isExecuting() || this.tridentMaceController.isExecuting() || this.maceController.isExecuting();
         boolean openingWalk = this.fightState.isOpening() && !punishWindow && !maceStyleKit && (this.weapon == WeaponSelector.WeaponType.SWORD || this.weapon == WeaponSelector.WeaponType.AXE);
         this.releaseAfterHit = 0;
         this.sprintHitHold = 0;
         if (openingWalk) {
            double approachStrafe = EffectiveSettings.of(this.botName).difficultyParams().strafeAngle;
            boolean targetMoving = this.target.getDeltaMovement().horizontalDistanceSqr() > 0.0025;
            this.approachStyle.tick(this.dist, approachStrafe, targetMoving);
            if (this.approachStyle.paused() && !this.bot.isInWater()) {
               this.pathFollower.reset();
               BotCommands.stopMoving(this.server, this.botName);
               this.bot.setSprinting(false);
               this.lookAtTarget();
               return;
            }

            Vec3 walkGoal = this.approachStyle.goal(this.target, this.bot.position(), this.dist);
            Vec3 spread = this.effectiveSettings.chaseSpread() ? ChaseSpread.offsetFor(this.bot, this.target, this.dist) : null;
            this.pathFollower.chase(spread != null ? walkGoal.add(spread) : walkGoal, this.target.position());
         } else {
            Vec3 spread = this.effectiveSettings.chaseSpread() ? ChaseSpread.offsetFor(this.bot, this.target, this.dist) : null;
            if (spread != null) {
               this.pathFollower.chase(this.target.position().add(spread), this.target.position());
            } else {
               this.pathFollower.chase((Entity)this.target, this.target.position());
            }
         }

         this.lookAtTarget();
         if (!this.pathFollower.isSwimNav()) {
            if (punishWindow) {
               this.bot.setSprinting(true);
            } else if (openingWalk) {
               double approachStrafe = EffectiveSettings.of(this.botName).difficultyParams().strafeAngle;
               this.bot.setSprinting(this.approachStyle.shouldSprint(this.dist, approachStrafe) && !this.blocking);
            } else {
               float charge = this.bot.getAttackStrengthScale(0.0F);
               boolean nearAttackZone = this.dist <= this.attackRange + (double)1.5F;
               boolean wtapping = nearAttackZone && this.wTap.shouldStopSprint(charge) && this.wTapThisCycle;
               this.bot.setSprinting(!wtapping && !this.blocking);
            }
         }

         if (!this.cpvpMode && !this.pathFollower.isSwimNav() && (!(this.dist < (double)6.0F) || !this.targetIsInWeb())) {
            this.bunnyHopController.tick(!openingWalk || this.approachStyle.shouldHop(this.dist));
         }

         if (!this.cpvpMode && this.effectiveSettings.placeBlocksMoving()) {
            this.jumpPlaceController.tick(this.target, this.dist);
         } else {
            this.jumpPlaceController.reset();
         }
      } else if (this.bot.isInWater() && !this.bot.onGround()) {
         this.pathFollower.chase((Entity)this.target, this.target.position());
         this.lookAtTarget();
      } else {
         this.pathFollower.reset();
         this.aimAtTarget();
         if (this.targetIsInWeb() && !this.botIsInWeb()) {
            BotCommands.stopMoving(this.server, this.botName);
            this.bot.setSprinting(false);
         } else if (this.releaseAfterHit > 0 && this.sprintHitHold == 0 && !this.targetFleeing()) {
            --this.releaseAfterHit;
            BotCommands.setMovement(this.server, this.botName, 0.0F, 0.0F);
            this.bot.setSprinting(false);
            BotCommands.setSprinting(this.server, this.botName, false);
         } else {
            this.updateCombatMovement(this.blocking);
         }

         if (!this.cpvpMode) {
            this.bunnyHopController.tick(false);
         }
      }

      if (!this.blocking && !this.healing && (!this.cpvpMode || this.weapon == WeaponSelector.WeaponType.AXE)) {
         this.tryAttack(this.weapon);
      }

   }

   private void enforceConsumingMovementLimits() {
      if (this.bot.isUsingItem()) {
         if (!this.bot.getMainHandItem().has(DataComponents.KINETIC_WEAPON)) {
            this.bot.setSprinting(false);
            BotCommands.setSprinting(this.server, this.botName, false);
         }
      }
   }

   private LivingEntity findTarget() {
      if (BotManager.isInFfaLootMode(this.botName)) {
         String fb = this.botName;
         return this.findFfaTarget(fb, EffectiveSettings.of(fb));
      } else if (this.escortThreat != null) {
         return this.escortThreat;
      } else {
         EffectiveSettings es = EffectiveSettings.of(this.botName);
         String forcedAttack = BotManager.getAttackTarget(this.botName);
         if (forcedAttack != null) {
            ServerPlayer forced = BotManager.resolvePlayerOrBotByName(this.server, forcedAttack);
            if (forced != null && forced.isAlive() && !forced.isSpectator() && (!es.ignoreCreative() || !forced.isCreative()) && forced != this.bot && !forced.getScoreboardName().equals(this.botName) && !TeamManager.isAlliedWithBot(this.botName, forced.getScoreboardName())) {
               return forced;
            }

            BotManager.clearAttackTarget(this.botName);
         }

         label127: {
            LivingEntity lastHurtBy = this.bot.getLastHurtByMob();
            if (lastHurtBy instanceof ServerPlayer) {
               ServerPlayer lastAttacker = (ServerPlayer)lastHurtBy;
               if (lastAttacker.isAlive() && !lastAttacker.isSpectator() && (!es.ignoreCreative() || !lastAttacker.isCreative()) && lastAttacker != this.bot && !lastAttacker.getScoreboardName().equals(this.botName)) {
                  this.revengeTargetName = lastAttacker.getScoreboardName();
                  break label127;
               }
            }

            if (lastHurtBy != null && !(lastHurtBy instanceof ServerPlayer) && lastHurtBy.isAlive()) {
               this.revengeMobTarget = lastHurtBy;
            }
         }

         if (this.revengeTargetName != null && TeamManager.isAlliedWithBot(this.botName, this.revengeTargetName)) {
            this.revengeTargetName = null;
         }

         TeamManager.BotTeam team = TeamManager.getTeamForBot(this.botName);
         if (team == null) {
            if (es.revengeMode() && this.revengeTargetName != null) {
               ServerPlayer attacker = this.resolveRevenge(es);
               if (attacker != null) {
                  return attacker;
               }
            }

            if (es.revengeMode()) {
               LivingEntity mob = this.resolveMobRevenge();
               if (mob != null) {
                  return mob;
               }
            }

            return es.autoTarget() ? this.findAutoTarget(es, this.botName) : null;
         } else {
            if (team.isRevengeMode() && this.revengeTargetName != null) {
               ServerPlayer attacker = this.resolveRevenge(es);
               if (attacker != null) {
                  ServerPlayer share = this.pinnedTarget(es, this.botName);
                  if (share != null && share != attacker && TeamTargetBalancer.isSplitTarget(this.server, team, attacker.getScoreboardName())) {
                     if (this.shareOrCloser(share, attacker) != share) {
                        return attacker;
                     }
                  } else {
                     ServerPlayer near = this.nearestTeamTarget(team, es, this.botName);
                     if (near == null || near == attacker || !this.closerWins(attacker, near, true)) {
                        return attacker;
                     }
                  }
               }
            }

            if (team.isRevengeMode()) {
               LivingEntity mob = this.resolveMobRevenge();
               if (mob != null) {
                  return mob;
               }
            }

            Object var10000;
            switch (team.getMode()) {
               case ALL_PLAYERS -> var10000 = this.nearestPlayer((Set)null, es, this.botName);
               case SPECIFIC -> var10000 = this.resolveSpecificTeamTarget(team, es, this.botName);
               case SPECIFIC_TEAMS -> var10000 = this.shareOrCloser(this.pinnedTarget(es, this.botName), this.nearestFromTargetTeams(team.getName(), team.getTargetTeamNames(), es));
               case NONE -> var10000 = es.autoTarget() ? this.findAutoTarget(es, this.botName) : null;
               default -> throw new MatchException((String)null, (Throwable)null);
            }

            return (LivingEntity)var10000;
         }
      }
   }

   private void tickStanceWatchdog() {
      if (this.target != null && this.target.isAlive()) {
         ItemStack main = this.bot.getMainHandItem();
         boolean consumableHeld = main.has(DataComponents.FOOD) || main.is(Items.POTION) || main.is(Items.EXPERIENCE_BOTTLE);
         if (!consumableHeld) {
            this.stanceStuckTicks = 0;
            this.consumableHeldTicks = 0;
         } else {
            ++this.consumableHeldTicks;
            if (this.bot.isUsingItem()) {
               this.stanceStuckTicks = 0;
            } else {
               ++this.stanceStuckTicks;
            }

            if (this.stanceStuckTicks >= 50 || this.consumableHeldTicks >= 300) {
               VexBot.LOGGER.warn("[VexBot] '{}' wedged holding {} in combat ({} ticks idle, {} held) — forced recovery.", new Object[]{this.botName, main.getHoverName().getString(), this.stanceStuckTicks, this.consumableHeldTicks});
               this.stanceStuckTicks = 0;
               this.consumableHeldTicks = 0;
               this.healingController.forceAbortWithLockout(80);
               this.mendingController.abortMending();
               this.predictionWebController.reset();
               this.headWebController.reset();
               MeleeWeaponGuard.ensureWeapon(this.bot);
            }
         }
      } else {
         this.stanceStuckTicks = 0;
         this.consumableHeldTicks = 0;
      }
   }

   private LivingEntity findAutoTarget(EffectiveSettings es, String botName) {
      String myName = botName;
      LivingEntity best = null;
      double bestScore = Double.MAX_VALUE;
      if (es.targetPlayers() || es.targetBots()) {
         TeamManager.BotTeam myTeam = TeamManager.getTeamForBot(botName);

         for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
            if (p.isAlive() && !p.isSpectator() && (!es.ignoreCreative() || !p.isCreative()) && p != this.bot && !p.getScoreboardName().equals(myName) && (myTeam == null || !TeamManager.isAlliedWithBot(botName, p.getScoreboardName()))) {
               boolean isBot = McCompat.tags(p).contains("vexbot");
               if (isBot) {
                  if (!es.targetBots()) {
                     continue;
                  }
               } else if (!es.targetPlayers()) {
                  continue;
               }

               double score = this.targetPriority(p);
               if (score < bestScore) {
                  bestScore = score;
                  best = p;
               }
            }
         }
      }

      if (es.targetMobs()) {
         ServerLevel sl = this.bot.level();
         if (sl instanceof ServerLevel) {
            for(Mob mob : sl.getEntitiesOfClass(Mob.class, this.bot.getBoundingBox().inflate((double)64.0F), (mobx) -> mobx.isAlive() && mobx instanceof Enemy)) {
               double score = (double)this.bot.distanceTo(mob);
               if (mob.getHealth() <= 6.0F) {
                  score -= (double)10.0F;
               }

               if (score < bestScore) {
                  bestScore = score;
                  best = mob;
               }
            }
         }
      }

      return best;
   }

   private LivingEntity findFfaTarget(String botName, EffectiveSettings es) {
      LivingEntity best = null;
      double bestScore = Double.MAX_VALUE;
      TeamManager.BotTeam myTeam = TeamManager.getTeamForBot(botName);

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (p.isAlive() && !p.isSpectator() && (!es.ignoreCreative() || !p.isCreative()) && p != this.bot && !p.getScoreboardName().equals(botName) && (myTeam == null || !TeamManager.isAlliedWithBot(botName, p.getScoreboardName()))) {
            double score = this.targetPriority(p);
            if (score < bestScore) {
               bestScore = score;
               best = p;
            }
         }
      }

      return best;
   }

   private boolean ffaGeared() {
      Inventory inv = this.bot.getInventory();
      boolean weapon = false;
      int armor = 0;

      for(EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
         if (!this.bot.getItemBySlot(s).isEmpty()) {
            ++armor;
         }
      }

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty()) {
            WeaponSelector.WeaponType t = WeaponSelector.getType(st);
            if (t != WeaponSelector.WeaponType.SWORD && t != WeaponSelector.WeaponType.AXE && t != WeaponSelector.WeaponType.MACE) {
               if (ArmorEvaluator.isArmor(st)) {
                  ++armor;
               }
            } else {
               weapon = true;
            }
         }
      }

      return weapon && armor >= 2;
   }

   private boolean tickFfaLoot() {
      if (this.ffaChestTarget != null && !this.isLootableChest(this.ffaChestTarget)) {
         this.releaseChest(true);
      }

      if (this.ffaChestTarget == null) {
         if (this.ffaRescanCooldown > 0) {
            --this.ffaRescanCooldown;
         } else {
            this.ffaChestTarget = this.findNearestLootChest();
            this.ffaRescanCooldown = 10;
         }
      }

      if (this.ffaChestTarget == null) {
         return false;
      } else {
         String myName = this.botName;
         long now = this.bot.level().getGameTime();
         ((Map)ffaChestClaims.computeIfAbsent(this.ffaChestTarget.asLong(), (k) -> new ConcurrentHashMap())).put(myName, now + 40L);
         Vec3 c = Vec3.atCenterOf(this.ffaChestTarget);
         if (this.bot.position().distanceTo(c) > 2.6) {
            this.pathFollower.chase(c);
            this.bot.setSprinting(true);
            this.bunnyHopController.tick(true);
            return true;
         } else {
            this.pathFollower.reset();
            this.lookAtChest(this.ffaChestTarget);
            if (!this.ffaChestOpened) {
               this.setChestOpen(this.ffaChestTarget, true);
               this.ffaChestOpened = true;
            }

            this.maybeDeclutter();
            int invAxe = this.findInvAxeSlot();
            if (invAxe >= 0) {
               Inventory axInv = this.bot.getInventory();
               InventoryUtils.select(axInv, InventoryUtils.moveToHotbarSafe(axInv, invAxe));
               ServerLevel chopLevel = this.bot.level();
               float perTick = chopLevel.getBlockState(this.ffaChestTarget).getDestroyProgress(this.bot, chopLevel, this.ffaChestTarget);
               if (perTick >= 0.025F) {
                  McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                  this.ffaChopProgress += perTick;
                  if (this.ffaChopProgress >= 1.0F) {
                     BlockPos pos = this.ffaChestTarget;
                     this.releaseChest(true);
                     if (chopLevel.destroyBlock(pos, true, this.bot)) {
                        Stats.inc("blocks_mined");
                     }

                     this.ffaChopProgress = 0.0F;
                  }

                  return true;
               }

               this.ffaChopProgress = 0.0F;
            }

            if (this.ffaLootCooldown > 0) {
               --this.ffaLootCooldown;
               return true;
            } else if (this.lootAxeFromChest(this.ffaChestTarget)) {
               this.ffaLootCooldown = 2;
               return true;
            } else if (this.lootOneStack(this.ffaChestTarget)) {
               this.ffaLootCooldown = 2;
               return true;
            } else {
               this.releaseChest(true);
               return true;
            }
         }
      }
   }

   private int findInvAxeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (WeaponSelector.getType(inv.getItem(i)) == WeaponSelector.WeaponType.AXE) {
            return i;
         }
      }

      return -1;
   }

   private boolean lootAxeFromChest(BlockPos pos) {
      BlockEntity be = this.bot.level().getBlockEntity(pos);
      if (be instanceof Container c) {
         Inventory inv = this.bot.getInventory();

         for(int i = 0; i < c.getContainerSize(); ++i) {
            ItemStack st = c.getItem(i);
            if (!st.isEmpty() && WeaponSelector.getType(st) == WeaponSelector.WeaponType.AXE) {
               int before = st.getCount();
               ItemStack moving = st.copy();
               inv.add(moving);
               if (moving.getCount() != before) {
                  c.setItem(i, moving.isEmpty() ? ItemStack.EMPTY : moving);
                  c.setChanged();
                  McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private void releaseChest(boolean markLooted) {
      if (this.ffaChestTarget != null) {
         if (this.ffaChestOpened) {
            this.setChestOpen(this.ffaChestTarget, false);
            this.ffaChestOpened = false;
         }

         long key = this.ffaChestTarget.asLong();
         Map<String, Long> claim = (Map)ffaChestClaims.get(key);
         if (claim != null) {
            claim.remove(this.botName);
            if (claim.isEmpty()) {
               ffaChestClaims.remove(key);
            }
         }

         if (markLooted) {
            this.ffaLooted.add(key);
         }

         this.ffaChestTarget = null;
         this.ffaLootCooldown = 0;
         this.ffaChopProgress = 0.0F;
      }
   }

   public void shutdown() {
      this.releaseChest(false);
      this.restockController.reset();
      this.shulkerRaidController.reset();
   }

   private void setChestOpen(BlockPos pos, boolean open) {
      BlockEntity be = this.bot.level().getBlockEntity(pos);
      if (be instanceof Container container) {
         try {
            if (open) {
               container.startOpen(this.bot);
            } else {
               container.stopOpen(this.bot);
            }
         } catch (Throwable var6) {
         }
      }

   }

   private boolean isChestLike(BlockEntity be) {
      return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity;
   }

   private boolean isEmptyContainer(Container c) {
      for(int i = 0; i < c.getContainerSize(); ++i) {
         if (!c.getItem(i).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   private boolean isLootableChest(BlockPos pos) {
      if (this.ffaLooted.contains(pos.asLong())) {
         return false;
      } else {
         BlockEntity be = this.bot.level().getBlockEntity(pos);
         boolean var10000;
         if (this.isChestLike(be) && be instanceof Container) {
            Container c = (Container)be;
            if (!this.isEmptyContainer(c)) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      }
   }

   private BlockPos findNearestLootChest() {
      ServerLevel var2 = this.bot.level();
      if (!(var2 instanceof ServerLevel)) {
         return null;
      } else {
         ServerLevel sl = var2;
         int var23 = this.bot.blockPosition().getX() >> 4;
         int cz = this.bot.blockPosition().getZ() >> 4;
         BlockPos botPos = this.bot.blockPosition();
         String myName = this.botName;
         long now = var2.getGameTime();
         BlockPos best = null;
         double bestD = (double)2304.0F;

         for(int dx = -3; dx <= 3; ++dx) {
            for(int dz = -3; dz <= 3; ++dz) {
               LevelChunk chunk = sl.getChunkSource().getChunkNow(var23 + dx, cz + dz);
               if (chunk != null) {
                  for(Map.Entry<BlockPos, BlockEntity> e : chunk.getBlockEntities().entrySet()) {
                     BlockPos p = (BlockPos)e.getKey();
                     long key = p.asLong();
                     if (!this.ffaLooted.contains(key) && ffaOtherClaimants(key, now, myName) < 3) {
                        BlockEntity be = (BlockEntity)e.getValue();
                        if (this.isChestLike(be) && be instanceof Container) {
                           Container c = (Container)be;
                           if (!this.isEmptyContainer(c)) {
                              double d = botPos.distSqr(p);
                              if (d < bestD) {
                                 bestD = d;
                                 best = p.immutable();
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         return best;
      }
   }

   private boolean lootOneStack(BlockPos pos) {
      BlockEntity be = this.bot.level().getBlockEntity(pos);
      if (be instanceof Container c) {
         Inventory inv = this.bot.getInventory();

         for(int i = 0; i < c.getContainerSize(); ++i) {
            ItemStack st = c.getItem(i);
            if (!st.isEmpty()) {
               int before = st.getCount();
               ItemStack moving = st.copy();
               inv.add(moving);
               if (moving.getCount() != before) {
                  c.setItem(i, moving.isEmpty() ? ItemStack.EMPTY : moving);
                  c.setChanged();
                  McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                  this.armorManager.equipFromInventory();
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private void lookAtChest(BlockPos pos) {
      Vec3 eye = this.bot.getEyePosition();
      double dx = (double)pos.getX() + (double)0.5F - eye.x;
      double dy = (double)pos.getY() + (double)0.5F - eye.y;
      double dz = (double)pos.getZ() + (double)0.5F - eye.z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, horiz))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private boolean tickFfaPickup(boolean geared) {
      if (!EffectiveSettings.of(this.botName).pickupLoot()) {
         return false;
      } else {
         ItemEntity drop = this.findNearbyDrop();
         if (drop == null) {
            return false;
         } else if (geared && this.enemyWithin((double)8.0F)) {
            return false;
         } else {
            if (!drop.getUUID().equals(this.ffaPickupDropId)) {
               this.ffaPickupDropId = drop.getUUID();
               this.ffaPickupTicks = 0;
            }

            if (++this.ffaPickupTicks > 200) {
               this.skipDrop(drop);
               this.ffaPickupDropId = null;
               this.ffaPickupTicks = 0;
               this.pathFollower.reset();
               return false;
            } else {
               Vec3 dpos = drop.position();
               if (this.bot.position().distanceTo(dpos) > 1.2) {
                  this.pathFollower.chase(dpos, dpos);
                  return true;
               } else {
                  this.pathFollower.reset();
                  this.maybeDeclutter();
                  this.armorManager.equipFromInventory();
                  return true;
               }
            }
         }
      }
   }

   private void maybeDeclutter() {
      if (this.ffaDropCooldown > 0) {
         --this.ffaDropCooldown;
      } else if (this.bot.getInventory().getFreeSlot() < 0) {
         this.ffaDropCooldown = this.ffaDropJunk() ? 20 : 100;
      }
   }

   private boolean ffaDropJunk() {
      Inventory inv = this.bot.getInventory();
      boolean dropped = false;
      EnumMap<WeaponSelector.WeaponType, Integer> bestSlot = new EnumMap(WeaponSelector.WeaponType.class);
      EnumMap<WeaponSelector.WeaponType, Double> bestScore = new EnumMap(WeaponSelector.WeaponType.class);

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty()) {
            WeaponSelector.WeaponType t = WeaponSelector.getType(st);
            if (t != WeaponSelector.WeaponType.OTHER && t != WeaponSelector.WeaponType.EMPTY) {
               double sc = t == WeaponSelector.WeaponType.MACE ? ItemEvaluator.scoreMace(st) : ItemEvaluator.scoreWeapon(st);
               Double prev = (Double)bestScore.get(t);
               if (prev == null || sc > prev) {
                  bestScore.put(t, sc);
                  bestSlot.put(t, i);
               }
            }
         }
      }

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty()) {
            WeaponSelector.WeaponType t = WeaponSelector.getType(st);
            if (t != WeaponSelector.WeaponType.OTHER && t != WeaponSelector.WeaponType.EMPTY) {
               Integer keep = (Integer)bestSlot.get(t);
               if (keep != null && keep != i) {
                  this.tossSlot(i);
                  dropped = true;
               }
            }
         }
      }

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty() && ArmorEvaluator.isArmor(st)) {
            EquipmentSlot slot = ArmorEvaluator.getSlot(st);
            if (slot != null) {
               ItemStack worn = this.bot.getItemBySlot(slot);
               if (!worn.isEmpty() && ArmorEvaluator.score(st) <= ArmorEvaluator.score(worn)) {
                  this.tossSlot(i);
                  dropped = true;
               }
            }
         }
      }

      if (!dropped) {
         for(int i = 0; i < 36; ++i) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && !RestockController.isRestockWorthy(st)) {
               this.tossSlot(i);
               dropped = true;
               break;
            }
         }
      }

      return dropped;
   }

   private void skipDrop(ItemEntity drop) {
      if (this.ownJunkDrops.size() > 64) {
         this.ownJunkDrops.clear();
      }

      this.ownJunkDrops.add(drop.getUUID());
   }

   private void tossSlot(int slot) {
      Inventory inv = this.bot.getInventory();
      ItemStack st = inv.getItem(slot);
      if (!st.isEmpty()) {
         inv.setItem(slot, ItemStack.EMPTY);
         ItemEntity ent = McCompat.drop(this.bot, st, true, false);
         if (ent != null) {
            if (this.ownJunkDrops.size() > 64) {
               this.ownJunkDrops.clear();
            }

            this.ownJunkDrops.add(ent.getUUID());
         }

         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
      }
   }

   private boolean tickKillLootPickup() {
      if (this.killLootPos == null) {
         this.killLootTicks = 0;
         return false;
      } else if (!EffectiveSettings.of(this.botName).pickupLoot()) {
         return false;
      } else if (this.enemyWithin((double)8.0F)) {
         return false;
      } else {
         ItemEntity drop = this.findDropNear(this.killLootPos, (double)10.0F);
         if (drop == null) {
            this.killLootTicks = 0;
            this.killLootPos = null;
            return false;
         } else {
            Vec3 dpos = drop.position();
            if (this.bot.position().distanceTo(dpos) > 1.2) {
               this.pathFollower.chase(dpos, dpos);
               this.bot.setSprinting(true);
               return true;
            } else {
               this.pathFollower.reset();
               this.armorManager.equipFromInventory();
               return true;
            }
         }
      }
   }

   private boolean tickContainerPickup() {
      if (!EffectiveSettings.of(this.botName).pickupLoot()) {
         return false;
      } else {
         ItemEntity box = this.findNearbyContainerDrop();
         if (box == null) {
            return false;
         } else if (this.enemyWithin((double)8.0F)) {
            return false;
         } else {
            if (!box.getUUID().equals(this.containerPickupId)) {
               this.containerPickupId = box.getUUID();
               this.containerPickupTicks = 0;
            }

            if (++this.containerPickupTicks > 200) {
               this.skipDrop(box);
               this.containerPickupId = null;
               this.containerPickupTicks = 0;
               this.pathFollower.reset();
               return false;
            } else {
               Vec3 dpos = box.position();
               if (this.bot.position().distanceTo(dpos) > 1.2) {
                  this.pathFollower.chase(dpos, dpos);
                  this.bot.setSprinting(true);
                  return true;
               } else {
                  this.pathFollower.reset();
                  this.maybeDeclutter();
                  return true;
               }
            }
         }
      }
   }

   private ItemEntity findNearbyContainerDrop() {
      ServerLevel sl = this.bot.level();
      if (sl instanceof ServerLevel) {
         List sl = sl.getEntitiesOfClass(ItemEntity.class, this.bot.getBoundingBox().inflate((double)14.0F), (itx) -> itx.isAlive() && !itx.hasPickUpDelay() && !this.ownJunkDrops.contains(itx.getUUID()) && isRegearContainer(itx.getItem()));
         ItemEntity best = null;
         double bestD = Double.MAX_VALUE;

         for(ItemEntity it : sl) {
            double d = this.bot.distanceToSqr(it);
            if (d < bestD) {
               bestD = d;
               best = it;
            }
         }

         return best;
      } else {
         return null;
      }
   }

   private static boolean isRegearContainer(ItemStack st) {
      if (st.isEmpty()) {
         return false;
      } else if (st.is(Items.ENDER_CHEST)) {
         return true;
      } else {
         Item var2 = st.getItem();
         boolean var10000;
         if (var2 instanceof BlockItem) {
            BlockItem bi = (BlockItem)var2;
            if (bi.getBlock() instanceof ShulkerBoxBlock) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      }
   }

   private ItemEntity findDropNear(Vec3 center, double r) {
      ServerLevel sl = this.bot.level();
      if (sl instanceof ServerLevel) {
         List sl = sl.getEntitiesOfClass(ItemEntity.class, new AABB(center.subtract(r, r, r), center.add(r, r, r)), (itx) -> itx.isAlive() && !itx.hasPickUpDelay() && !this.ownJunkDrops.contains(itx.getUUID()));
         ItemEntity best = null;
         double bestD = Double.MAX_VALUE;

         for(ItemEntity it : sl) {
            double d = this.bot.distanceToSqr(it);
            if (d < bestD) {
               bestD = d;
               best = it;
            }
         }

         return best;
      } else {
         return null;
      }
   }

   private ItemEntity findNearbyDrop() {
      ServerLevel sl = this.bot.level();
      if (sl instanceof ServerLevel) {
         List sl = sl.getEntitiesOfClass(ItemEntity.class, this.bot.getBoundingBox().inflate((double)16.0F), (itx) -> itx.isAlive() && !itx.hasPickUpDelay() && !this.ownJunkDrops.contains(itx.getUUID()));
         ItemEntity best = null;
         double bestD = Double.MAX_VALUE;

         for(ItemEntity it : sl) {
            double d = this.bot.distanceToSqr(it);
            if (d < bestD) {
               bestD = d;
               best = it;
            }
         }

         return best;
      } else {
         return null;
      }
   }

   private boolean enemyWithin(double r) {
      String name = this.botName;
      EffectiveSettings es = EffectiveSettings.of(name);
      TeamManager.BotTeam myTeam = TeamManager.getTeamForBot(name);

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if ((double)this.bot.distanceTo(p) <= r && p.isAlive() && !p.isSpectator() && (!es.ignoreCreative() || !p.isCreative()) && p != this.bot && !p.getScoreboardName().equals(name) && (myTeam == null || !TeamManager.isAlliedWithBot(name, p.getScoreboardName()))) {
            return true;
         }
      }

      return false;
   }

   private LivingEntity resolveMobRevenge() {
      if (this.revengeMobTarget == null) {
         return null;
      } else if (!this.revengeMobTarget.isAlive()) {
         this.revengeMobTarget = null;
         return null;
      } else {
         return this.revengeMobTarget;
      }
   }

   private ServerPlayer resolveRevenge(EffectiveSettings es) {
      if (this.revengeTargetName == null) {
         return null;
      } else {
         ServerPlayer sp = BotManager.resolveOtherPlayerByName(this.server, this.bot, this.revengeTargetName);
         if (sp != null && !sp.isSpectator() && (!es.ignoreCreative() || !sp.isCreative())) {
            if (!sp.isAlive()) {
               return null;
            } else if (TeamManager.isAlliedWithBot(this.botName, sp.getScoreboardName())) {
               this.revengeTargetName = null;
               return null;
            } else {
               return sp;
            }
         } else {
            this.revengeTargetName = null;
            return null;
         }
      }
   }

   private ServerPlayer resolveSpecificTeamTarget(TeamManager.BotTeam team, EffectiveSettings es, String botName) {
      return this.shareOrCloser(this.pinnedTarget(es, botName), this.nearestPlayer(team.getTargetNames(), es, botName));
   }

   private ServerPlayer shareOrCloser(ServerPlayer share, ServerPlayer nearest) {
      if (share != null && nearest != null && nearest != share) {
         return this.closerWins(share, nearest, false) ? nearest : share;
      } else {
         this.closerThanShare = null;
         return share != null ? share : nearest;
      }
   }

   private boolean closerWins(ServerPlayer preferred, ServerPlayer nearest, boolean revenge) {
      double dPref = (double)this.bot.distanceTo(preferred);
      double dNear = (double)this.bot.distanceTo(nearest);
      String name = nearest.getScoreboardName();
      boolean was = name.equals(revenge ? this.closerThanRevenge : this.closerThanShare);
      boolean closer = dNear <= (double)4.5F && dPref > dNear + (was ? (double)1.0F : (double)3.0F) || dPref > dNear + (was ? (double)6.0F : (double)12.0F);
      if (revenge) {
         this.closerThanRevenge = closer ? name : null;
      } else {
         this.closerThanShare = closer ? name : null;
      }

      return closer;
   }

   private ServerPlayer nearestTeamTarget(TeamManager.BotTeam team, EffectiveSettings es, String botName) {
      ServerPlayer var10000;
      switch (team.getMode()) {
         case SPECIFIC -> var10000 = this.nearestPlayer(team.getTargetNames(), es, botName);
         case SPECIFIC_TEAMS -> var10000 = this.nearestFromTargetTeams(team.getName(), team.getTargetTeamNames(), es);
         default -> var10000 = null;
      }

      return var10000;
   }

   private ServerPlayer pinnedTarget(EffectiveSettings es, String botName) {
      String pinned = TeamManager.getAssignedTarget(botName);
      if (pinned == null) {
         return null;
      } else {
         ServerPlayer sp = BotManager.resolveNonBotPlayerByName(this.server, pinned);
         if (sp == null) {
            sp = BotManager.resolveOtherPlayerByName(this.server, this.bot, pinned);
         }

         return sp != null && sp.isAlive() && !sp.isSpectator() && (!es.ignoreCreative() || !sp.isCreative()) && !TeamManager.isAlliedWithBot(botName, sp.getScoreboardName()) ? sp : null;
      }
   }

   private ServerPlayer nearestPlayer(Set<String> allowed, EffectiveSettings es, String botName) {
      boolean ignoreCreative = es.ignoreCreative();
      TeamManager.BotTeam myTeam = TeamManager.getTeamForBot(botName);
      ServerPlayer best = null;
      double bestPriority = Double.MAX_VALUE;

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (p.isAlive() && !p.isSpectator() && (!ignoreCreative || !p.isCreative())) {
            String pName = p.getScoreboardName();
            if ((!McCompat.tags(p).contains("vexbot") || allowed != null && TeamManager.targetNamesContains(allowed, pName)) && (myTeam == null || !TeamManager.isAlliedWithBot(botName, pName)) && (allowed == null || TeamManager.targetNamesContains(allowed, pName))) {
               double priority = this.targetPriority(p);
               if (priority < bestPriority) {
                  bestPriority = priority;
                  best = p;
               }
            }
         }
      }

      return best;
   }

   private ServerPlayer nearestFromTargetTeams(String ownTeamName, Set<String> targetTeamNames, EffectiveSettings es) {
      if (targetTeamNames != null && !targetTeamNames.isEmpty()) {
         String selfName = this.botName;
         return (ServerPlayer)this.server.getPlayerList().getPlayers().stream().filter((p) -> p.isAlive() && !p.isSpectator()).filter((p) -> !p.getScoreboardName().equals(selfName)).filter((p) -> !es.ignoreCreative() || !p.isCreative()).filter((p) -> {
            TeamManager.BotTeam targetTeam = TeamManager.getTeamForMember(p.getScoreboardName());
            if (targetTeam == null) {
               return false;
            } else if (targetTeam.getName().equals(ownTeamName)) {
               return false;
            } else {
               return TeamManager.isAlliedWithBot(selfName, p.getScoreboardName()) ? false : targetTeamNames.contains(targetTeam.getName());
            }
         }).min(Comparator.comparingDouble((p) -> this.targetPriority(p))).orElse((Object)null);
      } else {
         return null;
      }
   }

   private double targetPriority(ServerPlayer p) {
      double score = (double)this.bot.distanceTo(p);
      if (p.isUsingItem()) {
         ItemStack used = p.getUseItem();
         boolean isConsuming = used.get(DataComponents.FOOD) != null || used.is(Items.POTION);
         if (isConsuming) {
            score -= (double)20.0F;
         }
      }

      if (p.getHealth() <= 6.0F) {
         score -= (double)10.0F;
      }

      return score;
   }

   private void lookAtTarget() {
      if (this.target != null) {
         float[] angles = BotMath.getAngles(this.bot.getEyePosition().x, this.bot.getEyePosition().y, this.bot.getEyePosition().z, this.target.getX(), this.target.getEyeY(), this.target.getZ());
         this.bot.setXRot(angles[1]);
         float headYaw = BotMath.smoothYawToward(this.bot.getYHeadRot(), angles[0], 32.0F);
         this.bot.setYHeadRot(BotMath.wrapDegrees(headYaw));
      }
   }

   private void aimAtTarget() {
      float[] angles = BotMath.getAngles(this.bot.getEyePosition().x, this.bot.getEyePosition().y, this.bot.getEyePosition().z, this.target.getX(), this.target.getEyeY(), this.target.getZ());
      float yaw = angles[0];
      float pitch = angles[1];
      this.straightYaw = yaw;
      this.straightPitch = pitch;
      if (this.pendingAttack) {
         this.bot.setYRot(yaw);
         this.bot.setXRot(pitch);
         this.bot.setYHeadRot(yaw);
         this.bot.setYBodyRot(yaw);
         this.meleeForwardImpulse = 1.0F;
         this.meleeStrafeImpulse = EffectiveSettings.of(this.botName).strafeInCombo() ? this.strafeController.attackTickStrafe() : 0.0F;
         this.pendingAttack = false;
      } else {
         EffectiveSettings es = EffectiveSettings.of(this.botName);
         float baseAngle = (float)es.difficultyParams().strafeAngle;
         float strafeAngleDeg = this.strafeController.getYawOffset(this.tickCount, baseAngle);
         float rad = (float)Math.toRadians((double)strafeAngleDeg);
         this.meleeForwardImpulse = (float)Math.cos((double)rad);
         this.meleeStrafeImpulse = (float)Math.sin((double)rad);
         float lookYaw = BotMath.smoothYawToward(this.bot.getYHeadRot(), yaw, 32.0F);
         lookYaw = BotMath.wrapDegrees(lookYaw);
         this.bot.setYRot(lookYaw);
         this.bot.setYHeadRot(lookYaw);
         this.bot.setYBodyRot(lookYaw);
         this.bot.setXRot(pitch);
      }

   }

   private void meleeMove(String name, float forward, float strafe) {
      float[] m = MeleeWallGuard.deflect(this.bot, forward, strafe);
      if (this.shieldBrokenNow && m[0] > 0.0F) {
         m[0] *= 0.45F;
      }

      BotCommands.setMovement(this.server, name, m[0], m[1]);
   }

   private void meleeBack(String name) {
      if (MeleeWallGuard.deflect(this.bot, -1.0F, 0.0F)[0] != 0.0F) {
         BotCommands.moveBackward(this.server, name);
      }
   }

   private void updateCombatMovement(boolean blocking) {
      double dist = (double)this.bot.distanceTo(this.target);
      float charge = this.bot.getAttackStrengthScale(0.0F);
      boolean wtapping = this.wTap.shouldStopSprint(charge);
      String name = this.botName;
      if (this.feintCooldown > 0) {
         --this.feintCooldown;
      }

      LivingEntity var9 = this.target;
      float var10000;
      if (var9 instanceof Player p) {
         var10000 = p.getAttackStrengthScale(0.0F);
      } else {
         var10000 = 0.0F;
      }

      float targCharge = var10000;
      if (this.feintTimer > 0) {
         --this.feintTimer;
         switch (this.feintDir) {
            case -1 -> BotCommands.moveLeft(this.server, name);
            case 1 -> BotCommands.moveRight(this.server, name);
            default -> BotCommands.moveBackward(this.server, name);
         }

         this.bot.setSprinting(false);
      } else if (this.feintCooldown <= 0 && dist <= this.attackRange && charge >= 0.3F && charge <= 0.6F && targCharge < 0.5F && EffectiveSettings.of(this.botName).roll()) {
         this.feintTimer = 3 + RNG.nextInt(4);
         this.feintCooldown = 25;
         this.feintDir = RNG.nextInt(3) - 1;
      } else {
         if (this.inCombo) {
            if (wtapping) {
               if (this.opponentAggressive()) {
                  this.meleeBack(name);
               } else {
                  BotCommands.setMovement(this.server, name, 0.0F, 0.0F);
               }

               this.bot.setSprinting(false);
            } else {
               float fwd = dist > 2.7 ? 1.0F : 0.0F;
               float side = 0.0F;
               if (EffectiveSettings.of(this.botName).strafeInCombo()) {
                  float rad = (float)Math.toRadians((double)this.strafeController.getYawOffset(this.tickCount, 34.0F));
                  side = (float)Math.sin((double)rad) * 0.55F;
                  if (fwd == 0.0F) {
                     fwd = Math.abs((float)Math.cos((double)rad)) * 0.25F;
                  }
               }

               this.meleeMove(name, fwd, side);
               this.bot.setSprinting(!blocking);
            }
         } else {
            this.meleeMove(name, this.meleeForwardImpulse, this.meleeStrafeImpulse);
            this.bot.setSprinting(!wtapping && !blocking);
         }

      }
   }

   private boolean isPureSwordKit() {
      if (this.bot.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA)) {
         return false;
      } else {
         Inventory inv = this.bot.getInventory();

         for(int i = 0; i < 36; ++i) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && (s.is(Items.MACE) || s.is(Items.ELYTRA) || s.is(Items.END_CRYSTAL) || s.is(Items.RESPAWN_ANCHOR) || s.is(Items.TNT_MINECART))) {
               return false;
            }
         }

         return true;
      }
   }

   private boolean targetIsEating() {
      if (this.target != null && this.target.isUsingItem()) {
         ItemStack used = this.target.getUseItem();
         return used.get(DataComponents.FOOD) != null || used.is(Items.POTION);
      } else {
         return false;
      }
   }

   private boolean idleNav(boolean driving) {
      if (driving) {
         this.idleNavTick = this.tickCount;
      }

      return driving;
   }

   private void releaseHotbarShield() {
      if (this.shieldHoldTicks > 0 && this.bot.isUsingItem() && this.bot.getUsedItemHand() == InteractionHand.MAIN_HAND && this.bot.getUseItem().is(Items.SHIELD)) {
         this.bot.stopUsingItem();
      }

      this.shieldHoldTicks = 0;
   }

   private boolean hasFoodInInventory() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty() && st.get(DataComponents.FOOD) != null) {
            return true;
         }
      }

      return false;
   }

   private boolean targetArmorMissing(LivingEntity t) {
      if (!(t instanceof Player)) {
         return false;
      } else {
         int empty = 0;
         if (t.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) {
            ++empty;
         }

         if (t.getItemBySlot(EquipmentSlot.CHEST).isEmpty()) {
            ++empty;
         }

         if (t.getItemBySlot(EquipmentSlot.LEGS).isEmpty()) {
            ++empty;
         }

         if (t.getItemBySlot(EquipmentSlot.FEET).isEmpty()) {
            ++empty;
         }

         return empty >= 2;
      }
   }

   private boolean totemSacrificeActive(LivingEntity t) {
      return t != null && t.isAlive() && t.getHealth() <= 6.0F && this.bot.getHealth() <= (float)(this.effectiveSettings.retreatHealthHearts() * (double)2.0F) && this.offhandManager.hasTotemInOffhand() && (double)this.bot.distanceTo(t) <= this.attackRange + (double)3.0F;
   }

   private float comboFireAt() {
      float at = 0.9F + this.comboCadenceBoost + (this.targetHighPing ? 0.08F : 0.0F);
      return Math.min(at, 1.0F);
   }

   private boolean shouldHoldSwing() {
      if (!this.hitSelectThisCycle) {
         return false;
      } else if (this.hitSelectHold >= 4 + this.jrJitter) {
         return false;
      } else {
         LivingEntity var2 = this.target;
         if (var2 instanceof Player) {
            Player tp = (Player)var2;
            boolean imminent = tp.getAttackStrengthScale(0.0F) >= 0.85F;
            return (imminent || this.oppJumpResets >= 2) && (double)this.bot.distanceTo(this.target) <= this.attackRange + 0.2;
         } else {
            return false;
         }
      }
   }

   private Vec3 targetVelocity() {
      if (this.fleeLastTick == this.tickCount && this.fleeLastTarget == this.target) {
         return this.fleeVel;
      } else {
         Vec3 now = this.target.position();
         if (this.fleeLastPos != null && this.fleeLastTarget == this.target && this.tickCount > this.fleeLastTick) {
            Vec3 step = now.subtract(this.fleeLastPos).scale((double)1.0F / (double)(this.tickCount - this.fleeLastTick));
            if (step.horizontalDistanceSqr() > (double)4.0F) {
               step = Vec3.ZERO;
            }

            this.fleeVel = this.fleeVel.scale((double)0.5F).add(step.scale((double)0.5F));
         } else {
            this.fleeVel = Vec3.ZERO;
         }

         this.fleeLastPos = now;
         this.fleeLastTarget = this.target;
         this.fleeLastTick = this.tickCount;
         return this.fleeVel;
      }
   }

   private boolean targetFleeing() {
      if (this.target == null) {
         return false;
      } else {
         Vec3 tv = this.targetVelocity();
         double sp = Math.sqrt(tv.x * tv.x + tv.z * tv.z);
         if (sp < 0.12) {
            return false;
         } else {
            double dx = this.target.getX() - this.bot.getX();
            double dz = this.target.getZ() - this.bot.getZ();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.01) {
               return false;
            } else {
               return (tv.x * dx + tv.z * dz) / (sp * len) > (double)0.5F;
            }
         }
      }
   }

   private boolean targetFinishable() {
      return this.target != null && this.target.getHealth() + this.target.getAbsorptionAmount() <= 10.0F && this.targetFleeing();
   }

   private boolean targetIsInWeb() {
      if (this.target == null) {
         return false;
      } else {
         BlockPos pos = BlockPos.containing(this.target.getX(), this.target.getY(), this.target.getZ());
         return this.bot.level().getBlockState(pos).is(Blocks.COBWEB);
      }
   }

   private boolean botIsInWeb() {
      return WebDetect.touchingWeb(this.bot);
   }

   private int rollReactionDelay() {
      return EffectiveSettings.of(this.botName).difficultyParams().rollReactionTicks(RNG);
   }

   private boolean readyToFire(float charge, float threshold) {
      if (charge < threshold) {
         return false;
      } else {
         if (this.reactionCountdown == -1) {
            this.reactionCountdown = this.rollReactionDelay();
         }

         if (this.reactionCountdown > 0) {
            --this.reactionCountdown;
            return false;
         } else {
            this.reactionCountdown = -1;
            return true;
         }
      }
   }

   private float[] pickSwingRotation(EffectiveSettings es) {
      float yaw = this.straightYaw;
      float pitch = this.straightPitch;
      float p = (float)es.difficultyParams().missChance;
      this.swingIsMiss = false;
      if (!(p <= 0.0F) && !(RNG.nextFloat() >= p)) {
         this.swingIsMiss = true;
         float yawOff = (RNG.nextFloat() - 0.5F) * 16.0F;
         float pitOff = (RNG.nextFloat() - 0.5F) * 12.0F;
         return new float[]{BotMath.wrapDegrees(yaw + yawOff), Math.max(-90.0F, Math.min(90.0F, pitch + pitOff))};
      } else {
         return new float[]{yaw, pitch};
      }
   }

   private void sprintOffForCrit() {
      this.bot.setSprinting(false);
      BotCommands.setSprinting(this.server, this.botName, false);
   }

   private void updateAdaptiveStyle(LivingEntity target) {
      String name = this.botName;
      if (BotSettings.playStyleFor(name) == BotSettings.PlayStyle.ADAPTIVE) {
         if (target != null) {
            double dx = this.bot.getX() - target.getX();
            double dz = this.bot.getZ() - target.getZ();
            double len = Math.hypot(dx, dz);
            double signal = (double)0.0F;
            if (len > 0.01) {
               Vec3 v = target.getDeltaMovement();
               double closing = (v.x * dx + v.z * dz) / len;
               if (closing > 0.1) {
                  ++signal;
               } else if (closing < -0.1) {
                  --signal;
               }
            }

            if (this.comboLockHits > 0) {
               signal += 0.8;
            }

            if (this.targetIsEating()) {
               --signal;
            }

            this.adaptiveScore = this.adaptiveScore * 0.97 + signal * 0.03;
            float botHp = this.bot.getHealth();
            float targetHp = target.getHealth();
            boolean losing = botHp <= 12.0F || botHp + 6.0F < targetHp || this.comboLockHits >= 3;
            BotSettings.PlayStyle resolved;
            if (losing) {
               resolved = BotSettings.PlayStyle.SAFE;
            } else if (this.adaptiveScore > 0.2) {
               resolved = BotSettings.PlayStyle.AGGRESSIVE;
            } else if (this.adaptiveScore < -0.2) {
               resolved = BotSettings.PlayStyle.AGGRESSIVE;
            } else {
               resolved = BotSettings.PlayStyle.DEFAULT;
            }

            BotSettings.setAdaptiveResolved(name, resolved);
         }
      }
   }

   private void critSwingNow(EffectiveSettings es, LivingEntity target) {
      EquipmentSync.syncNow(this.bot);
      float[] rot = this.pickSwingRotation(es);
      this.bot.setYRot(rot[0]);
      this.bot.setXRot(rot[1]);
      this.bot.setYHeadRot(rot[0]);
      this.bot.setYBodyRot(rot[0]);
      this.sprintOffForCrit();
      if (this.swingIsMiss) {
         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
         this.bot.resetAttackStrengthTicker();
      } else {
         boolean inReach = (double)this.bot.distanceTo(target) <= this.attackRange + (double)1.0F && this.bot.hasLineOfSight(target);
         if (inReach) {
            this.bot.attack(target);
            ServerLevel sl = this.bot.level();
            if (sl instanceof ServerLevel) {
               sl.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY((double)0.5F), target.getZ(), 14, (double)target.getBbWidth() * 0.4, (double)target.getBbHeight() * 0.3, (double)target.getBbWidth() * 0.4, 0.15);
            }

            this.bot.crit(target);
         }

         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
      }

      this.pendingAttack = true;
      this.wTap.onAttack();
      this.strafeController.onAttack();
      this.afterAttackBlockhit();
   }

   private void orientAndSwing(EffectiveSettings es) {
      EquipmentSync.syncNow(this.bot);
      float[] rot = this.pickSwingRotation(es);
      this.bot.setYRot(rot[0]);
      this.bot.setXRot(rot[1]);
      this.bot.setYHeadRot(rot[0]);
      this.bot.setYBodyRot(rot[0]);
      if (this.swingIsMiss) {
         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
         this.bot.resetAttackStrengthTicker();
      } else {
         BotCommands.attackOnce(this.server, this.botName);
      }

      this.pendingAttack = true;
      this.wTap.onAttack();
      this.strafeController.onAttack();
      this.afterAttackBlockhit();
   }

   private void tryAttack(WeaponSelector.WeaponType weapon) {
      if (this.target != null) {
         ItemStack heldItem = this.bot.getMainHandItem();
         WeaponSelector.WeaponType heldType = WeaponSelector.getType(heldItem);
         boolean meleeCapable = heldType == WeaponSelector.WeaponType.SWORD || heldType == WeaponSelector.WeaponType.AXE || heldType == WeaponSelector.WeaponType.MACE || heldType == WeaponSelector.WeaponType.EMPTY || heldItem.is(Items.TRIDENT);
         if (meleeCapable) {
            if (this.isFacingTarget()) {
               if (this.bot.hasLineOfSight(this.target)) {
                  if (weapon != WeaponSelector.WeaponType.MACE || MaceSmashGates.botMayUseSmashFallBonus(this.bot)) {
                     EffectiveSettings esForAim = EffectiveSettings.of(this.botName);
                     float charge = this.bot.getAttackStrengthScale(0.0F);
                     this.swingReach.tick(charge, this.attackRange, esForAim.difficultyParams().reachFlips);
                     if ((double)this.bot.distanceTo(this.target) > this.swingReach.get(this.attackRange)) {
                        this.jumpedForCrit = false;
                     } else {
                        String name = this.botName;
                        boolean targetInWeb = this.targetIsInWeb();
                        Move move = this.decideMove(weapon, charge, esForAim);
                        switch (move.ordinal()) {
                           case 0:
                              this.doAxeFlick(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 1:
                              this.doAxeDisable(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 2:
                              this.doAutoCrit(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 3:
                              this.doMirrorPunish(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 4:
                              this.doAnswerSwing(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 5:
                              this.doCombo(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 6:
                              this.doCritPhase2(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 7:
                              this.doSweep(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 8:
                              this.doPinFleeing(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 9:
                              this.doCritJump(weapon, charge, name, esForAim, targetInWeb);
                              break;
                           case 10:
                              this.doFallback(weapon, charge, name, esForAim, targetInWeb);
                           case 11:
                        }

                     }
                  }
               }
            }
         }
      }
   }

   private int flickAxeSlot() {
      for(int i = 0; i < 9; ++i) {
         if (WeaponSelector.getType(this.bot.getInventory().getItem(i)) == WeaponSelector.WeaponType.AXE) {
            return i;
         }
      }

      return -1;
   }

   private Move decideMove(WeaponSelector.WeaponType weapon, float charge, EffectiveSettings esForAim) {
      if (weapon == WeaponSelector.WeaponType.SWORD && this.target.isBlocking() && this.axeController.seesShieldNow() && this.axeController.shouldDisableNow(charge, esForAim) && this.flickAxeSlot() >= 0) {
         return SwordPvpController.Move.AXE_FLICK;
      } else if (weapon == WeaponSelector.WeaponType.AXE && this.target.isBlocking() && this.axeController.shouldDisableNow(charge, esForAim)) {
         return SwordPvpController.Move.AXE_DISABLE;
      } else {
         if ((weapon == WeaponSelector.WeaponType.SWORD || weapon == WeaponSelector.WeaponType.AXE) && this.targetIsInWeb() && !this.botIsInWeb()) {
            this.inCombo = false;
            this.comboHitsLeft = 0;
            if (this.jumpedForCrit) {
               return SwordPvpController.Move.CRIT_PHASE2;
            }

            if (this.canAttemptCrit()) {
               return SwordPvpController.Move.CRIT_JUMP;
            }
         }

         if (weapon == WeaponSelector.WeaponType.SWORD && this.autoCritWindow > 0 && !this.inCombo && !this.jumpedForCrit && this.bot.onGround() && this.canAttemptCrit() && charge >= 0.95F) {
            return SwordPvpController.Move.AUTO_CRIT;
         } else if (weapon == WeaponSelector.WeaponType.SWORD && this.mirrorPunishWindow > 0 && !this.inCombo && !this.jumpedForCrit && !this.target.isBlocking() && this.bot.onGround() && charge >= 0.95F) {
            return SwordPvpController.Move.MIRROR_PUNISH;
         } else if (weapon == WeaponSelector.WeaponType.SWORD && this.answerSwingWindow > 0 && !this.inCombo && !this.jumpedForCrit && !this.target.isBlocking() && this.bot.onGround() && charge >= 0.95F) {
            return SwordPvpController.Move.ANSWER_SWING;
         } else {
            if (!this.jumpedForCrit && weapon == WeaponSelector.WeaponType.SWORD && this.fightState.beingCombod() && this.canAttemptCrit()) {
               int chainNow = this.fightState.incomingComboHits();
               if (chainNow != this.uppercutRolledChain) {
                  this.uppercutRolledChain = chainNow;
                  this.uppercutThisChain = RNG.nextDouble() < this.effectiveSettings.difficultyParams().accuracy;
               }

               if (this.uppercutThisChain) {
                  this.inCombo = false;
                  this.comboHitsLeft = 0;
                  return SwordPvpController.Move.CRIT_JUMP;
               }
            }

            if (!this.jumpedForCrit && this.targetFinishable()) {
               this.inCombo = false;
               this.comboHitsLeft = 0;
               if (this.canAttemptCrit()) {
                  return SwordPvpController.Move.CRIT_JUMP;
               }

               if (weapon == WeaponSelector.WeaponType.SWORD && this.bot.onGround() && charge >= 0.95F) {
                  return SwordPvpController.Move.PIN_FLEEING;
               }
            }

            if (this.inCombo && !this.jumpedForCrit) {
               return SwordPvpController.Move.COMBO;
            } else if (this.jumpedForCrit) {
               return SwordPvpController.Move.CRIT_PHASE2;
            } else {
               this.maybeStartCombo();
               if (weapon == WeaponSelector.WeaponType.SWORD && this.bot.onGround() && this.countNearbyEnemies() >= 2) {
                  return SwordPvpController.Move.SWEEP;
               } else if (weapon == WeaponSelector.WeaponType.SWORD && this.bot.onGround() && charge >= 0.95F && this.targetFinishable()) {
                  return SwordPvpController.Move.PIN_FLEEING;
               } else if (weapon == WeaponSelector.WeaponType.AXE && this.target.isBlocking()) {
                  return SwordPvpController.Move.HOLD;
               } else {
                  return this.canAttemptCrit() ? SwordPvpController.Move.CRIT_JUMP : SwordPvpController.Move.FALLBACK;
               }
            }
         }
      }
   }

   private boolean comboOpener(String name, EffectiveSettings esForAim) {
      if (!this.targetCornered() && !this.targetAtLedge()) {
         boolean veryLaggy = this.targetPingMs > 200;
         if (((double)this.bot.distanceTo(this.target) >= (double)2.0F || veryLaggy) && (!this.targetHighPing || !((double)this.bot.distanceTo(this.target) > this.attackRange - 0.3))) {
            BotCommands.setMovement(this.server, name, 1.0F, 0.0F);
            this.bot.setSprinting(true);
            this.orientAndSwing(esForAim);
            if (!veryLaggy) {
               this.sprintHitHold = 2;
               this.releaseAfterHit = 3;
               this.inCombo = true;
               this.comboHitsLeft = 2 + RNG.nextInt(3);
            }

            return true;
         } else {
            return false;
         }
      } else {
         BotCommands.setMovement(this.server, name, 1.0F, 0.0F);
         this.bot.setSprinting(true);
         this.orientAndSwing(esForAim);
         this.inCombo = true;
         this.comboHitsLeft = 2 + RNG.nextInt(3);
         return true;
      }
   }

   private boolean comboShieldLock() {
      return this.inCombo && this.fightState.ticksSinceOurHit() <= 20;
   }

   private boolean maybeStartCombo() {
      if (this.targetPingMs <= 200 && this.shouldStartCombo()) {
         this.inCombo = true;
         this.comboHitsLeft = 2 + RNG.nextInt(4);
         return true;
      } else {
         return false;
      }
   }

   private void doAxeFlick(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      int flickAxe = -1;

      for(int i = 0; i < 9; ++i) {
         if (WeaponSelector.getType(this.bot.getInventory().getItem(i)) == WeaponSelector.WeaponType.AXE) {
            flickAxe = i;
            break;
         }
      }

      if (flickAxe >= 0) {
         if (McCompat.invulnerableTime(this.target) <= 10) {
            int prevSlot = InventoryUtils.selected(this.bot.getInventory());
            InventoryUtils.select(this.bot.getInventory(), flickAxe);
            EquipmentSync.syncNow(this.bot);
            this.bot.setSprinting(true);
            this.bot.attack(this.target);
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            this.bot.resetAttackStrengthTicker();
            InventoryUtils.select(this.bot.getInventory(), prevSlot);
            EquipmentSync.syncNow(this.bot);
            this.axeController.onDisableSwung();
         }
      }
   }

   private void doAxeDisable(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      this.bot.setSprinting(true);
      this.orientAndSwing(esForAim);
      this.axeController.onDisableSwung();
   }

   private void doAutoCrit(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      this.autoCritWindow = 0;
      BotCommands.jumpOnce(this.server, name);
      this.jumpedForCrit = true;
      this.critJumpTick = this.tickCount;
   }

   private void doMirrorPunish(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      this.mirrorPunishWindow = 0;
      this.shieldController.reset();
      BotCommands.setMovement(this.server, name, 1.0F, 0.0F);
      this.bot.setSprinting(true);
      this.orientAndSwing(esForAim);
   }

   private void doAnswerSwing(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      this.answerSwingWindow = 0;
      this.hitSelectHold = 0;
      BotCommands.setMovement(this.server, name, 1.0F, 0.0F);
      this.bot.setSprinting(true);
      this.orientAndSwing(esForAim);
      this.sprintHitHold = 2;
      this.releaseAfterHit = 3;
      this.inCombo = true;
      this.comboHitsLeft = 2 + RNG.nextInt(3);
   }

   private void doCombo(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      if (charge >= this.comboFireAt()) {
         if (this.targetDescending() && this.swingHold < 6) {
            ++this.swingHold;
            return;
         }

         this.swingHold = 0;
         BotCommands.setMovement(this.server, name, 1.0F, 0.0F);
         this.bot.setSprinting(true);
         this.orientAndSwing(esForAim);
         this.sprintHitHold = 2;
         this.releaseAfterHit = 3;
         this.jumpedForCrit = false;
         --this.comboHitsLeft;
         if (this.comboHitsLeft <= 0) {
            this.inCombo = false;
         }
      }

   }

   private void doCritPhase2(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      EffectiveSettings critEs = EffectiveSettings.of(name);
      double critVelThreshold = critEs.difficultyParams().critThreshold;
      boolean falling = this.bot.getDeltaMovement().y < critVelThreshold && this.bot.fallDistance > (double)0.0F && !this.bot.onGround();
      if (this.tickCount - this.critJumpTick > 15) {
         this.jumpedForCrit = false;
      } else if (!falling || !(charge < 0.92F)) {
         if (!falling || McCompat.invulnerableTime(this.target) <= 2 && !this.target.isBlocking()) {
            if (falling) {
               this.critSwingHold = 2;
               this.critSwingNow(esForAim, this.target);
               if (!targetInWeb && esForAim.roll()) {
                  this.noKbHoldW = 5;
               }

               this.jumpedForCrit = false;
               this.critFollowUpWindow = 12;
               this.critChainWindow = 30;
            }

         }
      }
   }

   private void doSweep(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      if (charge >= 1.0F) {
         this.sprintOffForCrit();
         BotCommands.setMovement(this.server, name, 0.0F, 0.0F);
         this.critSwingHold = 2;
         this.orientAndSwing(esForAim);
         this.jumpedForCrit = false;
      }

   }

   private void doPinFleeing(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      this.sprintOffForCrit();
      BotCommands.setMovement(this.server, name, 1.0F, 0.0F);
      this.critSwingHold = 2;
      this.orientAndSwing(esForAim);
      this.jumpedForCrit = false;
   }

   private void doCritJump(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      boolean doubleCrit = this.critFollowUpWindow > 0 && !this.target.onGround() && (double)this.bot.distanceTo(this.target) <= 2.6;
      if (!this.bot.onGround()) {
         if (charge >= 0.95F && this.bot.fallDistance > (double)0.0F) {
            this.critSwingHold = 2;
            this.critSwingNow(esForAim, this.target);
            if (esForAim.roll()) {
               this.noKbHoldW = 5;
            }
         }

      } else if (doubleCrit && charge >= 0.95F) {
         BotCommands.jumpOnce(this.server, name);
         this.jumpedForCrit = true;
         this.critJumpTick = this.tickCount;
         this.critFollowUpWindow = 0;
      } else {
         if (!targetInWeb) {
            boolean critNow = (this.critChainWindow > 0 || this.targetLandWindow > 0 || this.healPunishWindow > 0 || this.armorPunishWindow > 0 || this.overextendWindow > 0 || this.axeController.punishActive()) && (double)this.bot.distanceTo(this.target) <= 3.4;
            boolean earlyJump = !critNow && this.earlyCritThisCycle && charge < 0.95F && (double)this.bot.distanceTo(this.target) < (double)2.0F && this.targetPingMs <= 200 && !this.targetCornered() && !this.targetAtLedge();
            if (charge < (!critNow && !earlyJump ? 0.95F : 0.55F)) {
               return;
            }

            if (!critNow && this.targetDescending() && this.swingHold < 6) {
               ++this.swingHold;
               return;
            }

            if (!critNow && this.shouldHoldSwing()) {
               ++this.hitSelectHold;
               return;
            }

            if (critNow || this.readyToFire(charge, earlyJump ? 0.55F : 0.95F)) {
               this.hitSelectHold = 0;
               if (McCompat.invulnerableTime(this.target) > 6) {
                  if (!critNow) {
                     this.reactionCountdown = 0;
                  }

                  return;
               }

               this.swingHold = 0;
               if (!critNow && !earlyJump && this.comboOpener(name, esForAim)) {
                  return;
               }

               this.targetLandWindow = 0;
               BotCommands.jumpOnce(this.server, name);
               this.jumpedForCrit = true;
               this.critJumpTick = this.tickCount;
            }
         } else if (!this.botIsInWeb() && charge >= 0.95F && (double)this.bot.distanceTo(this.target) <= this.attackRange) {
            BotCommands.stopMoving(this.server, name);
            this.sprintOffForCrit();
            if (this.bot.getDeltaMovement().horizontalDistanceSqr() < 0.0025) {
               BotCommands.jumpOnce(this.server, name);
               this.jumpedForCrit = true;
               this.critJumpTick = this.tickCount;
            }
         }

      }
   }

   private void doFallback(WeaponSelector.WeaponType weapon, float charge, String name, EffectiveSettings esForAim, boolean targetInWeb) {
      this.jumpedForCrit = false;
      if ((!targetInWeb || this.botIsInWeb()) && charge >= 0.95F) {
         if (this.targetDescending() && this.swingHold < 6) {
            ++this.swingHold;
            return;
         }

         if (this.readyToFire(charge, 0.95F)) {
            this.swingHold = 0;
            this.bot.setSprinting(true);
            this.orientAndSwing(esForAim);
         }
      }

   }

   private void craftWindChargesFromBreezeRods() {
      Inventory inv = this.bot.getInventory();

      for(int crafted = 0; crafted < 4; ++crafted) {
         int wc = 0;

         for(int i = 0; i < 36; ++i) {
            ItemStack s = inv.getItem(i);
            if (s.is(Items.WIND_CHARGE)) {
               wc += s.getCount();
            }
         }

         if (this.bot.getOffhandItem().is(Items.WIND_CHARGE)) {
            wc += this.bot.getOffhandItem().getCount();
         }

         if (wc >= 32) {
            return;
         }

         int rodSlot = -1;

         for(int i = 0; i < 36; ++i) {
            if (inv.getItem(i).is(Items.BREEZE_ROD)) {
               rodSlot = i;
               break;
            }
         }

         if (rodSlot < 0) {
            return;
         }

         boolean room = inv.getItem(rodSlot).getCount() == 1;
         if (!room) {
            for(int i = 0; i < 36; ++i) {
               ItemStack s = inv.getItem(i);
               if (s.isEmpty() || s.is(Items.WIND_CHARGE) && s.getCount() <= 60) {
                  room = true;
                  break;
               }
            }
         }

         if (!room) {
            return;
         }

         inv.getItem(rodSlot).shrink(1);
         ItemStack charges = new ItemStack(Items.WIND_CHARGE, 4);
         if (inv.getItem(rodSlot).isEmpty()) {
            inv.setItem(rodSlot, charges);
         } else {
            boolean placed = false;

            for(int i = 0; i < 36 && !placed; ++i) {
               ItemStack s = inv.getItem(i);
               if (s.is(Items.WIND_CHARGE) && s.getCount() <= 60) {
                  s.grow(4);
                  placed = true;
               }
            }

            for(int i = 0; i < 36 && !placed; ++i) {
               if (inv.getItem(i).isEmpty()) {
                  inv.setItem(i, charges);
                  placed = true;
               }
            }

            if (!placed) {
               McCompat.drop(this.bot, charges, false);
               return;
            }
         }
      }

   }

   private void craftPlanksFromLogs() {
      Inventory inv = this.bot.getInventory();
      Registry<Item> items = this.server.registryAccess().lookupOrThrow(Registries.ITEM);

      for(int crafted = 0; crafted < 4; ++crafted) {
         int logSlot = -1;

         for(int i = 0; i < 36; ++i) {
            if (inv.getItem(i).is(ItemTags.LOGS)) {
               logSlot = i;
               break;
            }
         }

         if (logSlot < 0) {
            return;
         }

         ItemStack log = inv.getItem(logSlot);
         Item planks = planksFor(items, log);
         if (planks == null) {
            return;
         }

         boolean room = log.getCount() == 1;
         if (!room) {
            for(int i = 0; i < 36; ++i) {
               ItemStack s = inv.getItem(i);
               if (s.isEmpty() || s.is(planks) && s.getCount() <= 60) {
                  room = true;
                  break;
               }
            }
         }

         if (!room) {
            return;
         }

         log.shrink(1);
         ItemStack out = new ItemStack(planks, 4);
         if (inv.getItem(logSlot).isEmpty()) {
            inv.setItem(logSlot, out);
         } else if (!inv.add(out) && !out.isEmpty()) {
            McCompat.drop(this.bot, out, false);
            return;
         }
      }

   }

   private static Item planksFor(Registry<Item> items, ItemStack log) {
      String path = items.getKey(log.getItem()).getPath();
      String base = path.startsWith("stripped_") ? path.substring("stripped_".length()) : path;
      int cut = base.lastIndexOf(95);
      if (cut <= 0) {
         return null;
      } else {
         String var10001 = base.substring(0, cut);
         Item planks = (Item)items.getValue(Identifier.withDefaultNamespace(var10001 + "_planks"));
         return planks != null && planks != Items.AIR ? planks : null;
      }
   }

   private void afterAttackBlockhit() {
      if (this.offhandManager.hasShieldInOffhand()) {
         byte var10000;
         switch (this.effectiveSettings.playStyle()) {
            case SAFE:
            case DEFENSIVE:
               var10000 = 40;
               break;
            case AGGRESSIVE:
               var10000 = 12;
               break;
            default:
               var10000 = 30;
         }

         int window = var10000;
         if (this.targetHighPing) {
            window += 8;
         }

         this.shieldController.requestBlockhit(window);
      }
   }

   private boolean targetDescending() {
      if (this.target != null && !this.target.onGround()) {
         return this.target.getDeltaMovement().y < -0.08;
      } else {
         return false;
      }
   }

   private boolean opponentAggressive() {
      if (!(this.target instanceof Player)) {
         return false;
      } else {
         Vec3 tv = this.target.getDeltaMovement();
         double hs = Math.sqrt(tv.x * tv.x + tv.z * tv.z);
         if (hs < 0.03) {
            return false;
         } else {
            Vec3 toBot = this.bot.position().subtract(this.target.position());
            double len = Math.sqrt(toBot.x * toBot.x + toBot.z * toBot.z);
            if (len < 0.001) {
               return false;
            } else {
               double dot = (tv.x * toBot.x + tv.z * toBot.z) / len;
               return dot > 0.05;
            }
         }
      }
   }

   private boolean shouldStartCombo() {
      if (this.target == null) {
         return false;
      } else if (!this.comboThisCycle) {
         return false;
      } else if (this.jumpedForCrit) {
         return false;
      } else if (this.critChainWindow > 0) {
         return false;
      } else {
         boolean chainLive = this.fightState.comboHits() >= 1 && this.fightState.ticksSinceOurHit() <= 20;
         if (!chainLive && this.canAttemptCrit()) {
            return false;
         } else if ((double)this.bot.distanceTo(this.target) > this.attackRange + (double)0.5F) {
            return false;
         } else if (this.bot.getHealth() <= 3.0F) {
            return false;
         } else if (this.target.isBlocking()) {
            return false;
         } else {
            Vec3 vel = this.bot.getDeltaMovement();
            return !(Math.sqrt(vel.x * vel.x + vel.z * vel.z) > 0.4);
         }
      }
   }

   private int countNearbyEnemies() {
      int n = 0;

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (p.isAlive() && !p.isSpectator() && !((double)this.bot.distanceTo(p) > this.attackRange) && !McCompat.tags(p).contains("vexbot")) {
            if (p != this.target) {
               String pName = p.getScoreboardName();
               if (this.effectiveSettings.ignoreCreative() && p.isCreative() || pName.equalsIgnoreCase(BotManager.getFollowTarget(this.botName)) || TeamManager.isAlliedWithBot(this.botName, pName)) {
                  continue;
               }
            }

            ++n;
         }
      }

      return n;
   }

   private boolean canAttemptCrit() {
      if (this.bot.isInWater()) {
         return false;
      } else if (this.bot.onClimbable()) {
         return false;
      } else if (this.botIsInWeb()) {
         return false;
      } else {
         Vec3 vel = this.bot.getDeltaMovement();
         double horizVel = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
         return horizVel <= 0.65;
      }
   }

   private boolean targetCornered() {
      if (this.target == null) {
         return false;
      } else {
         double dx = this.target.getX() - this.bot.getX();
         double dz = this.target.getZ() - this.bot.getZ();
         double len = Math.hypot(dx, dz);
         if (len < 0.01) {
            return false;
         } else {
            ServerLevel lvl = this.bot.level();
            BlockPos feet = BlockPos.containing(this.target.getX() + dx / len, this.target.getY(), this.target.getZ() + dz / len);
            return !lvl.getBlockState(feet).getCollisionShape(lvl, feet).isEmpty() && !lvl.getBlockState(feet.above()).getCollisionShape(lvl, feet.above()).isEmpty();
         }
      }
   }

   private boolean targetAtLedge() {
      if (this.target != null && this.target.onGround()) {
         double dx = this.target.getX() - this.bot.getX();
         double dz = this.target.getZ() - this.bot.getZ();
         double len = Math.hypot(dx, dz);
         if (len < 0.01) {
            return false;
         } else {
            ServerLevel lvl = this.bot.level();
            BlockPos spot = BlockPos.containing(this.target.getX() + dx / len * (double)1.5F, this.target.getY(), this.target.getZ() + dz / len * (double)1.5F);
            if (!lvl.getBlockState(spot).getCollisionShape(lvl, spot).isEmpty()) {
               return false;
            } else {
               for(int down = 1; down <= 4; ++down) {
                  BlockPos below = spot.below(down);
                  if (!lvl.getBlockState(below).getCollisionShape(lvl, below).isEmpty()) {
                     return false;
                  }
               }

               return true;
            }
         }
      } else {
         return false;
      }
   }

   private void tryJumpReset() {
      if (this.jumpResetCooldown > 0) {
         --this.jumpResetCooldown;
      } else if (this.target != null && this.bot.onGround()) {
         if (!this.bot.isUsingItem()) {
            if (!((double)this.bot.distanceTo(this.target) > (double)3.5F)) {
               LivingEntity var2 = this.target;
               if (var2 instanceof ServerPlayer) {
                  ServerPlayer tp = (ServerPlayer)var2;
                  if (!(this.bot.getAttackStrengthScale(0.0F) >= 0.7F)) {
                     if (!(tp.getAttackStrengthScale(0.0F) < 0.85F)) {
                        Vec3 look = tp.getLookAngle();
                        Vec3 toBot = this.bot.position().subtract(tp.position()).normalize();
                        double dot = look.x * toBot.x + look.z * toBot.z;
                        if (!(dot < 0.7)) {
                           if (!EffectiveSettings.of(this.botName).rollJumpReset()) {
                              this.jumpResetCooldown = 15;
                           } else {
                              BotCommands.jumpOnce(this.server, this.botName);
                              this.jumpResetCooldown = 15;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean isKnockedBack() {
      if (this.target == null) {
         return false;
      } else {
         Vec3 vel = this.bot.getDeltaMovement();
         double horizSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
         if (horizSpeed <= 0.15) {
            return false;
         } else {
            Vec3 toTarget = this.target.position().subtract(this.bot.position()).normalize();
            double dot = vel.x * toTarget.x + vel.z * toTarget.z;
            return dot < (double)0.0F;
         }
      }
   }

   private void chooseHitReaction(boolean cpvpMode, boolean specialExecuting) {
      this.hitReact = 0;
      if (this.target != null && this.target.isAlive() && this.bot.getLastHurtByMob() == this.target && !cpvpMode && !specialExecuting && !this.healingController.isHealing() && !this.bot.isUsingItem() && WeaponSelector.getType(this.bot.getMainHandItem()) == WeaponSelector.WeaponType.SWORD) {
         EffectiveSettings es = EffectiveSettings.of(this.botName);
         if (!this.jumpedForCrit && this.critSwingHold <= 0) {
            int delay = this.rollReactionDelay();
            if (this.ticksUntilStrong() <= 2 + delay && es.roll()) {
               this.hitReact = 1;
               this.hitReactTicks = 4 + delay;
               this.hitReactDelay = delay;
            } else if (!this.isHardIncomingHit() && this.ticksUntilCharge(0.92F) <= 8 && es.roll()) {
               this.hitReact = 2;
               this.hitReactTicks = 14;
               this.hitReactDelay = 0;
            }

         } else {
            if (this.ticksUntilCharge(0.92F) <= 8 && es.roll()) {
               this.hitReact = 2;
               this.hitReactTicks = 14;
               this.hitReactDelay = 0;
            }

         }
      }
   }

   private boolean runHitReaction() {
      if (this.hitReactTicks > 0 && this.target != null && this.target.isAlive() && WeaponSelector.getType(this.bot.getMainHandItem()) == WeaponSelector.WeaponType.SWORD) {
         EffectiveSettings es = EffectiveSettings.of(this.botName);
         if (this.hitReact == 1) {
            if (this.hitReactDelay > 0) {
               --this.hitReactDelay;
               return false;
            } else if (this.strongReady() && this.canSwingAt(this.target) && McCompat.invulnerableTime(this.target) <= 10) {
               ++this.knockbackTicks;
               this.inCombo = false;
               this.aimAtTarget();
               BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
               this.bot.setSprinting(true);
               BotCommands.setSprinting(this.server, this.botName, true);
               this.orientAndSwing(es);
               this.sprintHitHold = 2;
               this.reactionCountdown = -1;
               this.hitReact = 0;
               this.hitReactTicks = 0;
               return true;
            } else {
               return false;
            }
         } else {
            ++this.knockbackTicks;
            this.inCombo = false;
            this.aimAtTarget();
            BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
            boolean falling = !this.bot.onGround() && this.bot.fallDistance > (double)0.0F && this.bot.getDeltaMovement().y < (double)0.0F;
            if (!falling) {
               if (this.bot.onGround() && this.hitReactTicks < 12) {
                  this.hitReact = 0;
                  this.hitReactTicks = 0;
                  return false;
               } else {
                  this.bot.setSprinting(true);
                  BotCommands.setSprinting(this.server, this.botName, true);
                  return true;
               }
            } else {
               this.sprintOffForCrit();
               if (this.bot.getAttackStrengthScale(0.0F) >= 0.92F && this.canSwingAt(this.target) && McCompat.invulnerableTime(this.target) <= 10) {
                  this.critSwingHold = 2;
                  this.critSwingNow(es, this.target);
                  this.jumpedForCrit = false;
                  this.hitReact = 0;
                  this.hitReactTicks = 0;
               }

               return true;
            }
         }
      } else {
         this.hitReact = 0;
         return false;
      }
   }

   private boolean canSwingAt(LivingEntity t) {
      return this.isFacingTarget() && this.bot.hasLineOfSight(t) && (double)this.bot.distanceTo(t) <= this.swingReach.get(this.attackRange);
   }

   private boolean strongReady() {
      return this.bot.getAttackStrengthScale(0.5F) > 0.9F;
   }

   private int ticksUntilStrong() {
      float delay = this.bot.getCurrentItemAttackStrengthDelay();
      int ticker = Math.round(this.bot.getAttackStrengthScale(0.0F) * delay);
      int firstStrong = (int)Math.floor((double)(0.9F * delay - 0.5F)) + 1;
      return Math.max(0, firstStrong - ticker);
   }

   private int ticksUntilCharge(float charge) {
      float now = this.bot.getAttackStrengthScale(0.0F);
      return now >= charge ? 0 : (int)Math.ceil((double)((charge - now) * this.bot.getCurrentItemAttackStrengthDelay()));
   }

   private boolean isHardIncomingHit() {
      if (!this.isKnockedBack()) {
         return false;
      } else {
         Vec3 vel = this.bot.getDeltaMovement();
         double horizSpeed = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
         return horizSpeed > 0.38;
      }
   }

   private boolean incomingCritDive() {
      LivingEntity var2 = this.target;
      if (var2 instanceof Player p) {
         if (p.onGround()) {
            return false;
         } else if (p.getDeltaMovement().y > -0.05) {
            return false;
         } else if (p.getY() < this.bot.getY() - 0.1) {
            return false;
         } else {
            return p.getAttackStrengthScale(0.0F) >= 0.85F;
         }
      } else {
         return false;
      }
   }

   private boolean isIncomingFallAttack(LivingEntity target) {
      if (target == null) {
         return false;
      } else if (target.getY() - this.bot.getY() < (double)3.0F) {
         return false;
      } else {
         double dx = target.getX() - this.bot.getX();
         double dz = target.getZ() - this.bot.getZ();
         if (dx * dx + dz * dz > (double)12.25F) {
            return false;
         } else {
            return this.fallVelY(target) >= -0.3 ? false : this.carriesSmashWeapon(target);
         }
      }
   }

   private double fallVelY(LivingEntity e) {
      return e == this.target ? this.targetVelocity().y : e.getDeltaMovement().y;
   }

   private boolean carriesSmashWeapon(LivingEntity target) {
      if (target instanceof Player p) {
         return StunSlamDummy.carriesMaceOrSpear(p);
      } else {
         return StunSlamDummy.isMaceOrSpear(target.getMainHandItem()) || StunSlamDummy.isMaceOrSpear(target.getOffhandItem());
      }
   }

   private boolean shouldHoldFallShield(LivingEntity target) {
      if (target == null) {
         return false;
      } else {
         double dx = target.getX() - this.bot.getX();
         double dz = target.getZ() - this.bot.getZ();
         if (dx * dx + dz * dz > (double)20.25F) {
            return false;
         } else if (!this.carriesSmashWeapon(target)) {
            return false;
         } else {
            boolean atGround = target.onGround() || target.getY() - this.bot.getY() <= (double)0.5F;
            return !atGround;
         }
      }
   }

   private void faceEntity(LivingEntity e) {
      Vec3 eye = this.bot.getEyePosition();
      float[] a = BotMath.getAngles(eye.x, eye.y, eye.z, e.getX(), e.getY() + (double)e.getBbHeight() * (double)0.5F, e.getZ());
      this.bot.setYRot(a[0]);
      this.bot.setYHeadRot(a[0]);
      this.bot.setXRot(a[1]);
   }

   private void startMaceDodge(LivingEntity target) {
      double dx = this.bot.getX() - target.getX();
      double dz = this.bot.getZ() - target.getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len < 0.01) {
         dx = (double)1.0F;
         dz = (double)0.0F;
      } else {
         dx /= len;
         dz /= len;
      }

      this.dodgeYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.dodgeTicksLeft = 10;
   }

   private void tickMaceDodgeMovement() {
      if (this.target != null) {
         this.lookAtTarget();
      }

      double rad = Math.toRadians((double)this.bot.getYRot());
      double fx = -Math.sin(rad);
      double fz = Math.cos(rad);
      double rx = Math.cos(rad);
      double rz = Math.sin(rad);
      double aRad = Math.toRadians((double)this.dodgeYaw);
      double ax = -Math.sin(aRad);
      double az = Math.cos(aRad);
      float forward = (float)(ax * fx + az * fz);
      float strafe = (float)(ax * rx + az * rz);
      this.meleeMove(this.botName, forward, strafe);
      this.bot.setSprinting(false);
   }

   private void startFallAttackShield() {
      if (this.offhandManager.hasShieldInOffhand()) {
         this.stopMainHandShield();
         this.fallShieldUsesOffhand = true;
         if (!this.bot.isUsingItem()) {
            this.bot.startUsingItem(InteractionHand.OFF_HAND);
         }

      } else {
         this.fallShieldUsesOffhand = false;
         if (this.mainHandShieldSlot < 0) {
            this.startMainHandShield();
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.mainHandShieldSlot);
            if (!this.bot.isUsingItem()) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
            }
         }

      }
   }

   private void tickFallAttackShield() {
      if (this.fallShieldUsesOffhand) {
         if (!this.offhandManager.hasShieldInOffhand()) {
            this.fallShieldUsesOffhand = false;
            this.startMainHandShield();
         } else {
            if (!this.bot.isUsingItem() || this.bot.getUsedItemHand() != InteractionHand.OFF_HAND) {
               this.bot.startUsingItem(InteractionHand.OFF_HAND);
            }

         }
      } else {
         if (this.mainHandShieldSlot >= 0) {
            InventoryUtils.select(this.bot.getInventory(), this.mainHandShieldSlot);
            if (!this.bot.isUsingItem()) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
            }
         } else {
            this.startFallAttackShield();
         }

      }
   }

   private void stopFallAttackShield() {
      this.stopMainHandShield();
      if (this.fallShieldUsesOffhand && this.bot.isUsingItem() && this.bot.getUsedItemHand() == InteractionHand.OFF_HAND && this.bot.getUseItem().is(Items.SHIELD)) {
         this.bot.stopUsingItem();
      }

      this.fallShieldUsesOffhand = false;
   }

   private void startMainHandShield() {
      Inventory inv = this.bot.getInventory();
      int srcSlot = -1;

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.SHIELD)) {
            srcSlot = i;
            break;
         }
      }

      if (srcSlot >= 0) {
         int hotbarSlot;
         if (srcSlot < 9) {
            hotbarSlot = srcSlot;
            this.mainHandShieldSrc = -1;
         } else {
            hotbarSlot = InventoryUtils.moveToHotbarSafe(inv, srcSlot);
            this.mainHandShieldSrc = srcSlot;
         }

         this.mainHandShieldSlot = hotbarSlot;
         InventoryUtils.select(inv, hotbarSlot);
         this.bot.startUsingItem(InteractionHand.MAIN_HAND);
      }
   }

   private void stopMainHandShield() {
      if (this.mainHandShieldSlot >= 0) {
         if (this.bot.isUsingItem() && this.bot.getUsedItemHand() == InteractionHand.MAIN_HAND && this.bot.getUseItem().is(Items.SHIELD)) {
            this.bot.stopUsingItem();
         }

         if (this.mainHandShieldSrc >= 0 && this.mainHandShieldSrc != this.mainHandShieldSlot) {
            Inventory inv = this.bot.getInventory();
            ItemStack inHotbar = inv.getItem(this.mainHandShieldSlot).copy();
            ItemStack atSource = inv.getItem(this.mainHandShieldSrc).copy();
            inv.setItem(this.mainHandShieldSrc, inHotbar);
            inv.setItem(this.mainHandShieldSlot, atSource);
         }

         this.mainHandShieldSlot = -1;
         this.mainHandShieldSrc = -1;
      }
   }

   private void manageRangedPosition(double dist) {
      String name = this.botName;
      if (dist < (double)7.0F) {
         this.pathFollower.reset();
         BotCommands.moveBackward(this.server, name);
         this.bot.setSprinting(false);
      } else if (dist > (double)20.0F) {
         this.pathFollower.chase((Entity)this.target, this.target.position());
         this.bot.setSprinting(true);
         this.bunnyHopController.tick(true);
      } else {
         this.pathFollower.reset();
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
      }

   }

   private void idle() {
      if (!this.wanderController.tick()) {
         BotCommands.stopMoving(this.server, this.botName);
         this.bot.setSprinting(false);
         this.idleHumanizer.tick(this.tickCount);
      }

      if (this.weaponSelector.selectCrossbowIfAvailable()) {
         this.rangedController.tickPreload();
      }

   }

   private CpvpPick pickCpvp(LivingEntity t) {
      boolean chainHp = this.fightState.isOpening() || t.getHealth() >= t.getMaxHealth() * 0.8F;
      if (t.onGround() && t.getY() - this.bot.getY() >= (double)1.0F) {
         return SwordPvpController.CpvpPick.CRYSTAL;
      } else if (this.tickCount < this.crystalAfterChainUntil) {
         return SwordPvpController.CpvpPick.CRYSTAL;
      } else if (this.anchorAfterCrystal) {
         return chainHp ? SwordPvpController.CpvpPick.CHAIN : SwordPvpController.CpvpPick.ANCHOR;
      } else if (chainHp) {
         return SwordPvpController.CpvpPick.CHAIN;
      } else {
         int sinceAnchor = this.tickCount - this.oppAnchorTick;
         int sinceCrystal = this.tickCount - this.oppCrystalTick;
         if (sinceAnchor <= 60 && sinceAnchor <= sinceCrystal) {
            return SwordPvpController.CpvpPick.ANCHOR;
         } else if (sinceCrystal <= 60) {
            return SwordPvpController.CpvpPick.CRYSTAL;
         } else {
            return this.preferAnchorOverCrystal(t) ? SwordPvpController.CpvpPick.ANCHOR : SwordPvpController.CpvpPick.CRYSTAL;
         }
      }
   }

   private void watchOpponentTool(LivingEntity t) {
      ItemStack main = t.getMainHandItem();
      if (main.is(Items.RESPAWN_ANCHOR) || main.is(Items.GLOWSTONE)) {
         this.oppAnchorTick = this.tickCount;
      }

   }

   private void noteBlastFrom(LivingEntity t) {
      if (t != null) {
         DamageSource src = this.bot.getLastDamageSource();
         if (src != null) {
            if (src.getDirectEntity() instanceof EndCrystal && src.getEntity() == t) {
               this.oppCrystalTick = this.tickCount;
            } else if (src.is(DamageTypes.BAD_RESPAWN_POINT) && this.bot.tickCount - this.anchorPvpController.lastDetonateTick() > 2) {
               this.oppAnchorTick = this.tickCount;
            }

         }
      }
   }

   private void cpvpFootwork(LivingEntity target, double dist) {
      if (dist > (double)3.0F) {
         this.pathFollower.chase((Entity)target, target.position());
         this.bot.setSprinting(true);
      } else {
         this.pathFollower.reset();
         if (--this.cpvpStrafeTicks <= 0) {
            this.cpvpStrafeDir = RNG.nextBoolean() ? 1 : -1;
            this.cpvpStrafeTicks = 15 + RNG.nextInt(25);
         }

         float[] angles = BotMath.getAngles(this.bot.getEyePosition().x, this.bot.getEyePosition().y, this.bot.getEyePosition().z, target.getX(), target.getEyeY(), target.getZ());
         float yaw = BotMath.wrapDegrees(BotMath.smoothYawToward(this.bot.getYRot(), angles[0], 32.0F));
         this.bot.setYRot(yaw);
         this.bot.setYHeadRot(yaw);
         this.bot.setYBodyRot(yaw);
         this.bot.setSprinting(false);
         this.meleeMove(this.botName, dist < 1.8 ? -0.5F : 0.0F, (float)this.cpvpStrafeDir);
      }
   }

   private boolean preferAnchorOverCrystal(LivingEntity t) {
      if (t == null) {
         return false;
      } else if (this.bot.level().dimension() == Level.NETHER) {
         return false;
      } else {
         boolean cpvp = this.inCrystalPvpMode(t);
         if (this.fightState.isOpening()) {
            return true;
         } else if (cpvp && this.tickCount - this.lastAnchorActiveTick < 10) {
            return false;
         } else {
            double score = 0.7;
            if (t.onGround()) {
               score += 0.12;
            }

            if (t.getHealth() > 14.0F) {
               score += 0.08;
            }

            double speedSq = t.getDeltaMovement().horizontalDistanceSqr();
            if (speedSq < 0.02) {
               score += 0.07;
            }

            if (cpvp && t.getY() - this.bot.getY() >= (double)2.0F) {
               score -= 0.15;
            }

            return RNG.nextDouble() < score;
         }
      }
   }

   private boolean inCrystalPvpMode(LivingEntity t) {
      if (t instanceof Player && t.isAlive()) {
         if ((double)this.bot.distanceTo(t) > (double)40.0F) {
            return false;
         } else if (!this.hasItemInInventory(Items.TOTEM_OF_UNDYING)) {
            return false;
         } else {
            boolean crystalReady = this.hasItemInInventory(Items.END_CRYSTAL) && this.hasItemInInventory(Items.OBSIDIAN);
            boolean anchorReady = this.hasItemInInventory(Items.RESPAWN_ANCHOR) && this.hasItemInInventory(Items.GLOWSTONE) && this.bot.level().dimension() != Level.NETHER;
            return crystalReady || anchorReady;
         }
      } else {
         return false;
      }
   }

   private boolean hasItemInInventory(Item item) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i <= 40; ++i) {
         if (inv.getItem(i).is(item)) {
            return true;
         }
      }

      return false;
   }

   private Vec3 findLowGroundNearTarget(LivingEntity target) {
      if (target == null) {
         return null;
      } else {
         Level level = this.bot.level();
         double targetX = target.getX();
         double targetZ = target.getZ();
         int targetFeetY = (int)Math.floor(target.getY());
         Vec3 best = null;
         double bestHorizSq = Double.MAX_VALUE;

         for(int dx = -8; dx <= 8; ++dx) {
            for(int dz = -8; dz <= 8; ++dz) {
               int x = (int)Math.floor(targetX) + dx;
               int z = (int)Math.floor(targetZ) + dz;

               for(int dy = 2; dy <= 8; ++dy) {
                  BlockPos floor = new BlockPos(x, targetFeetY - dy, z);
                  if (level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP)) {
                     BlockPos stand = floor.above();
                     if (level.getBlockState(stand).isAir() && level.getBlockState(stand.above()).isAir()) {
                        Vec3 standVec = Vec3.atCenterOf(stand);
                        double hdx = standVec.x - targetX;
                        double hdz = standVec.z - targetZ;
                        double horizSq = hdx * hdx + hdz * hdz;
                        if (!(horizSq > (double)42.25F) && horizSq < bestHorizSq) {
                           bestHorizSq = horizSq;
                           best = standVec;
                        }
                        break;
                     }
                  }
               }
            }
         }

         return best;
      }
   }

   private boolean isFacingTarget() {
      if (this.target == null) {
         return false;
      } else {
         double dx = this.target.getX() - this.bot.getX();
         double dz = this.target.getZ() - this.bot.getZ();
         float angleToTarget = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float diff = Math.abs(BotMath.wrapDegrees(this.bot.getYHeadRot() - angleToTarget));
         return diff < 60.0F;
      }
   }

   private LivingEntity orderedTargetWhileFollowing(String followName) {
      ServerPlayer escorted = this.resolveFollowEntity(followName);
      String ordered = BotManager.getAttackTarget(this.botName);
      if (ordered != null && TeamFormationOrders.isTeamOrder(this.botName, ordered)) {
         ordered = null;
      }

      if (ordered != null) {
         ServerPlayer t = BotManager.resolvePlayerOrBotByName(this.server, ordered);
         if (t != null && t != this.bot && t != escorted && t.isAlive() && !t.isSpectator() && !TeamManager.isAlliedWithBot(this.botName, t.getScoreboardName())) {
            return t;
         }

         if (t == null || !t.isAlive() || t.isSpectator()) {
            BotManager.clearAttackTarget(this.botName);
         }
      }

      TeamManager.BotTeam team = TeamManager.getTeamForBot(this.botName);
      if (team == null) {
         return null;
      } else {
         EffectiveSettings es = EffectiveSettings.of(this.botName);
         ServerPlayer var10000;
         switch (team.getMode()) {
            case SPECIFIC -> var10000 = this.resolveSpecificTeamTarget(team, es, this.botName);
            case SPECIFIC_TEAMS -> var10000 = this.shareOrCloser(this.pinnedTarget(es, this.botName), this.nearestFromTargetTeams(team.getName(), team.getTargetTeamNames(), es));
            default -> var10000 = null;
         }

         ServerPlayer chosen = var10000;
         return chosen != null && chosen != escorted && chosen.level() == this.bot.level() && !((double)this.bot.distanceTo(chosen) > (double)64.0F) ? chosen : null;
      }
   }

   private boolean onOrderedFight() {
      LivingEntity var2 = this.target;
      if (var2 instanceof ServerPlayer t) {
         if (t.isAlive()) {
            String name = t.getScoreboardName();
            String ordered = BotManager.getAttackTarget(this.botName);
            if (ordered != null && ordered.equalsIgnoreCase(name) && !TeamFormationOrders.isTeamOrder(this.botName, ordered)) {
               return true;
            }

            TeamManager.BotTeam team = TeamManager.getTeamForBot(this.botName);
            if (team == null) {
               return false;
            }

            boolean var10000;
            switch (team.getMode()) {
               case SPECIFIC:
                  var10000 = TeamManager.targetNamesContains(team.getTargetNames(), name) || name.equalsIgnoreCase(String.valueOf(TeamManager.getAssignedTarget(this.botName)));
                  break;
               case SPECIFIC_TEAMS:
                  TeamManager.BotTeam theirs = TeamManager.getTeamForMember(name);
                  var10000 = theirs != null && !theirs.getName().equalsIgnoreCase(team.getName()) && team.getTargetTeamNames().contains(theirs.getName());
                  break;
               default:
                  var10000 = false;
            }

            return var10000;
         }
      }

      return false;
   }

   private LivingEntity resolveEscortThreat(String followName) {
      LivingEntity chosen = this.orderedTargetWhileFollowing(followName);
      if (chosen != null) {
         return chosen;
      } else {
         double leash = (double)32.0F;
         ServerPlayer escortedBoss = this.resolveFollowEntity(followName);
         double regroup = TeamFormationOrders.regroupDistance(this.botName, followName);
         if (regroup > (double)0.0F) {
            leash = regroup;
            if (escortedBoss != null && (double)this.bot.distanceTo(escortedBoss) > regroup) {
               this.revengeTargetName = null;
               return null;
            }
         }

         String teamOrder = BotManager.getAttackTarget(this.botName);
         if (teamOrder != null && TeamFormationOrders.isTeamOrder(this.botName, teamOrder)) {
            ServerPlayer t = BotManager.resolvePlayerOrBotByName(this.server, teamOrder);
            if (t != null && t != this.bot && t.isAlive() && !t.isSpectator() && !TeamManager.isAlliedWithBot(this.botName, t.getScoreboardName()) && (escortedBoss == null || (double)t.distanceTo(escortedBoss) <= leash)) {
               return t;
            }
         }

         LivingEntity lastHurt = this.bot.getLastHurtByMob();
         if (lastHurt instanceof ServerPlayer) {
            ServerPlayer sp = (ServerPlayer)lastHurt;
            if (sp.isAlive() && !sp.isSpectator() && sp != this.bot && !sp.getScoreboardName().equals(this.botName)) {
               this.revengeTargetName = sp.getScoreboardName();
            }
         }

         if (this.revengeTargetName == null) {
            return null;
         } else {
            ServerPlayer threat = BotManager.resolveOtherPlayerByName(this.server, this.bot, this.revengeTargetName);
            if (threat != null && !threat.isSpectator() && !TeamManager.isAlliedWithBot(this.botName, threat.getScoreboardName())) {
               if (!threat.isAlive()) {
                  this.revengeTargetName = null;
                  return null;
               } else {
                  String threatName = threat.getScoreboardName();
                  TeamManager.BotTeam followedTeam = this.resolveTeamByName(followName);
                  if (followedTeam != null && TeamManager.isMemberOfTeam(followedTeam.getName(), threatName)) {
                     this.revengeTargetName = null;
                     return null;
                  } else {
                     ServerPlayer escorted = this.resolveFollowEntity(followName);
                     if (escorted != null) {
                        if (threatName.equalsIgnoreCase(escorted.getScoreboardName())) {
                           this.revengeTargetName = null;
                           return null;
                        }

                        if ((double)threat.distanceTo(escorted) > leash) {
                           this.revengeTargetName = null;
                           return null;
                        }
                     }

                     return threat;
                  }
               }
            } else {
               this.revengeTargetName = null;
               return null;
            }
         }
      }
   }

   private ServerPlayer resolveFollowEntity(String name) {
      if (name == null) {
         return null;
      } else {
         String selfName = this.botName;
         ServerPlayer human = BotManager.resolveNonBotPlayerByName(this.server, name);
         if (human != null && human.isAlive()) {
            return human;
         } else {
            ServerPlayer otherBot = BotManager.resolveTrackedBotPlayer(this.server, name);
            if (otherBot != null && otherBot.isAlive() && !otherBot.getScoreboardName().equalsIgnoreCase(selfName)) {
               return otherBot;
            } else {
               TeamManager.BotTeam team = this.resolveTeamByName(name);
               return team != null ? this.nearestTeamMember(team, selfName) : null;
            }
         }
      }
   }

   private TeamManager.BotTeam resolveTeamByName(String name) {
      if (name == null) {
         return null;
      } else {
         TeamManager.BotTeam t = TeamManager.get(name);
         if (t != null) {
            return t;
         } else {
            for(String tn : TeamManager.teamNames()) {
               if (tn.equalsIgnoreCase(name)) {
                  return TeamManager.get(tn);
               }
            }

            return null;
         }
      }
   }

   private ServerPlayer nearestTeamMember(TeamManager.BotTeam team, String selfName) {
      ServerPlayer best = null;
      double bestSq = Double.MAX_VALUE;
      List<String> members = new ArrayList();
      members.addAll(team.getPlayerNames());
      members.addAll(team.getBotNames());

      for(String memberName : members) {
         if (!memberName.equalsIgnoreCase(selfName)) {
            ServerPlayer m = BotManager.resolvePlayerOrBotByName(this.server, memberName);
            if (m != null && m.isAlive()) {
               double d = this.bot.distanceToSqr(m);
               if (d < bestSq) {
                  bestSq = d;
                  best = m;
               }
            }
         }
      }

      return best;
   }

   private void tickFollow(String playerName) {
      ServerPlayer followEntity = this.resolveFollowEntity(playerName);
      if (followEntity != null && followEntity.isAlive()) {
         boolean fly = BotManager.isFollowElytra(this.botName);
         FollowFormation.Type formation = BotManager.getFollowFormation(this.botName);
         Vec3 goal;
         double stopDist;
         if (formation == FollowFormation.Type.NONE) {
            goal = followEntity.position();
            stopDist = (double)2.5F;
         } else {
            List<String> group = BotManager.followGroupAlive(this.server, playerName, fly);
            int idx = TeamFormationOrders.slotIndex(this.server, this.botName, playerName, group, formation, BotManager.getFollowRowWidth(this.botName), true);
            int n = Math.max(1, group.size());
            int rowWidth = BotManager.getFollowRowWidth(this.botName);
            if (idx < 0) {
               idx = 0;
            }

            FormationAnchor.Anchored anchor = FormationAnchor.of(followEntity, this.bot.level().getGameTime());
            this.formationYaw = FollowFormation.worldAligned(formation) ? 0.0F : anchor.yaw();
            TeamTactics orders = TeamFormationOrders.tacticsFor(this.botName);
            double spacing = orders != null ? orders.spacing : (double)2.0F;
            goal = FollowFormation.slotWorldSpacedCentred(formation, idx, n, rowWidth, anchor.pos(), this.formationYaw, true, spacing);
            stopDist = this.inFormationSlot ? 0.9 : 0.45;
         }

         if (fly) {
            this.releaseFormationStance();
            if (this.elytraFollowController.tickFly(goal, followEntity.getY())) {
               return;
            }
         } else if (this.elytraFollowController.isFlying()) {
            this.elytraFollowController.land();
         }

         double dx = goal.x - this.bot.getX();
         double dz = goal.z - this.bot.getZ();
         double dist = Math.sqrt(dx * dx + dz * dz);
         if (dist > stopDist) {
            this.inFormationSlot = false;
            LivingEntity prevTarget = this.target;
            this.target = followEntity;
            if (formation == FollowFormation.Type.NONE) {
               this.pathFollower.chase(goal, followEntity.position());
            } else {
               this.pathFollower.chase(goal);
            }

            this.target = prevTarget;
            TeamTactics pace = formation == FollowFormation.Type.NONE ? null : TeamFormationOrders.tacticsFor(this.botName);
            double speed = pace != null ? pace.movementSpeed : (double)1.0F;
            if (speed < 0.95) {
               this.setSpeedScale((float)speed);
               this.bot.setSprinting(false);
            } else {
               this.bot.setSprinting(dist > (double)3.0F || speed > (double)1.25F);
               if (speed >= (double)1.5F && dist > (double)4.0F && this.bot.onGround() && !BunnyHopController.runsInsteadOfHopping(this.bot)) {
                  BotCommands.jumpOnce(this.server, this.botName);
               }
            }

            this.applyFormationStance(pace, formation, false);
         } else {
            this.pathFollower.reset();
            BotCommands.stopMoving(this.server, this.botName);
            this.bot.setSprinting(false);
            this.inFormationSlot = true;
            this.applyFormationStance(formation == FollowFormation.Type.NONE ? null : TeamFormationOrders.tacticsFor(this.botName), formation, true);
            float yaw = formation == FollowFormation.Type.NONE ? (float)Math.toDegrees(Math.atan2(-(followEntity.getX() - this.bot.getX()), followEntity.getZ() - this.bot.getZ())) : this.formationYaw;
            this.bot.setYRot(yaw);
            this.bot.setYHeadRot(yaw);
            this.bot.setYBodyRot(yaw);
         }

         BotManager.tickLookAt(this.bot, this.server);
      } else {
         BotCommands.stopMoving(this.server, this.botName);
         this.bot.setSprinting(false);
      }
   }

   private void setSpeedScale(float scale) {
      boolean scaled = scale < 0.999F;
      if (scaled || this.speedScaled) {
         this.speedScaled = scaled;
         BotPlayerActionPack pack = Internals.get().actionPack(this.bot);
         if (pack != null) {
            pack.setSpeedScale(scale);
         }

      }
   }

   private void applyFormationStance(TeamTactics orders, FollowFormation.Type formation, boolean holdingSlot) {
      boolean want = orders != null && formation != FollowFormation.Type.NONE && orders.shieldBehaviour != TeamTactics.ShieldBehaviour.FREE && this.bot.getOffhandItem().is(Items.SHIELD) && (holdingSlot || this.enemyWithin((double)24.0F));
      if (!want) {
         this.releaseFormationStance();
      } else {
         if (!this.bot.isUsingItem()) {
            this.bot.startUsingItem(InteractionHand.OFF_HAND);
         }

         this.bot.setShiftKeyDown(orders.shieldBehaviour == TeamTactics.ShieldBehaviour.SHIELD_WALL);
         this.formationStance = true;
      }
   }

   private void releaseFormationStance() {
      if (this.formationStance) {
         this.formationStance = false;
         if (this.bot.isUsingItem() && this.bot.getUsedItemHand() == InteractionHand.OFF_HAND && this.bot.getUseItem().is(Items.SHIELD)) {
            this.bot.releaseUsingItem();
         }

         this.bot.setShiftKeyDown(false);
      }
   }

   private static int indexOfIgnoreCase(List<String> list, String name) {
      for(int i = 0; i < list.size(); ++i) {
         if (((String)list.get(i)).equalsIgnoreCase(name)) {
            return i;
         }
      }

      return -1;
   }

   public LivingEntity getTarget() {
      return this.target;
   }

   public ServerPlayer getBot() {
      return this.bot;
   }

   public String getRevengeTargetName() {
      return this.revengeTargetName;
   }

   public void notifyHurtBy(String attackerName) {
      this.revengeTargetName = attackerName;
   }

   private void applyReachAttribute() {
      AttributeInstance attr = this.bot.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
      if (attr != null) {
         if (Math.abs(attr.getBaseValue() - this.attackRange) > 1.0E-6) {
            attr.setBaseValue(this.attackRange);
         }

      }
   }

   private static enum Move {
      AXE_FLICK,
      AXE_DISABLE,
      AUTO_CRIT,
      MIRROR_PUNISH,
      ANSWER_SWING,
      COMBO,
      CRIT_PHASE2,
      SWEEP,
      PIN_FLEEING,
      CRIT_JUMP,
      FALLBACK,
      HOLD;

      // $FF: synthetic method
      private static Move[] $values() {
         return new Move[]{AXE_FLICK, AXE_DISABLE, AUTO_CRIT, MIRROR_PUNISH, ANSWER_SWING, COMBO, CRIT_PHASE2, SWEEP, PIN_FLEEING, CRIT_JUMP, FALLBACK, HOLD};
      }
   }

   private static enum CpvpPick {
      CHAIN,
      ANCHOR,
      CRYSTAL;

      // $FF: synthetic method
      private static CpvpPick[] $values() {
         return new CpvpPick[]{CHAIN, ANCHOR, CRYSTAL};
      }
   }
}
