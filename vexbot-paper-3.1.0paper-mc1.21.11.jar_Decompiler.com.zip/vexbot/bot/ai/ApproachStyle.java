package vexbot.bot.ai;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

final class ApproachStyle {
   private static final double ARC_BAND = (double)5.0F;
   private static final double WIDE_BAND = (double)10.0F;
   private static final double MAX_LATERAL = (double)3.0F;
   private static final int HOLD_MIN = 20;
   private static final int HOLD_MAX = 50;
   private static final double EASE_PER_TICK = 0.07;
   private static final int PAUSE_CHANCE_IN = 90;
   private static final int PAUSE_MIN = 8;
   private static final int PAUSE_MAX = 20;
   private static final int PAUSE_COOLDOWN = 60;
   private double lateral;
   private double wantLateral;
   private int holdTicks;
   private int pauseTicks;
   private int pauseCooldown;
   private int targetId = -1;

   private void retarget(LivingEntity target) {
      if (target.getId() != this.targetId) {
         this.targetId = target.getId();
         this.lateral = (double)0.0F;
         this.wantLateral = (double)0.0F;
         this.holdTicks = 0;
         this.pauseTicks = 0;
         this.pauseCooldown = 60;
      }
   }

   void tick(double dist, double strafeAngle, boolean targetMoving) {
      double skill = Math.min((double)1.0F, strafeAngle / (double)50.0F);
      if (this.pauseCooldown > 0) {
         --this.pauseCooldown;
      }

      if (this.pauseTicks > 0) {
         --this.pauseTicks;
         if (!targetMoving) {
            this.pauseTicks = 0;
         }
      } else if (this.pauseCooldown == 0 && dist > (double)5.0F && targetMoving && ThreadLocalRandom.current().nextInt(90) == 0) {
         this.pauseTicks = (int)((double)(8 + ThreadLocalRandom.current().nextInt(13)) * (0.4 + 0.6 * skill));
         this.pauseCooldown = 60;
      }

      if (--this.holdTicks <= 0) {
         this.holdTicks = ThreadLocalRandom.current().nextInt(20, 51);
         double width = (double)3.0F * skill;
         double mag = width * (0.4 + ThreadLocalRandom.current().nextDouble() * 0.6);
         this.wantLateral = this.lateral >= (double)0.0F ? -mag : mag;
      }

      this.lateral += Math.signum(this.wantLateral - this.lateral) * Math.min(0.07, Math.abs(this.wantLateral - this.lateral));
   }

   boolean paused() {
      return this.pauseTicks > 0;
   }

   Vec3 goal(LivingEntity target, Vec3 botPos, double dist) {
      this.retarget(target);
      Vec3 targetPos = target.position();
      double taper = Math.max((double)0.0F, Math.min((double)1.0F, (dist - (double)5.0F) / (double)5.0F));
      double offset = this.lateral * Math.max(0.45, taper);
      if (Math.abs(offset) < 0.05) {
         return targetPos;
      } else {
         double dx = targetPos.x - botPos.x;
         double dz = targetPos.z - botPos.z;
         double len = Math.sqrt(dx * dx + dz * dz);
         return len < 1.0E-4 ? targetPos : new Vec3(targetPos.x + -dz / len * offset, targetPos.y, targetPos.z + dx / len * offset);
      }
   }

   boolean shouldSprint(double dist, double strafeAngle) {
      if (this.paused()) {
         return false;
      } else {
         double commitAt = (double)11.0F - Math.min((double)1.0F, strafeAngle / (double)50.0F) * (double)6.0F;
         return dist <= commitAt;
      }
   }

   boolean shouldHop(double dist) {
      return !this.paused() && dist <= (double)10.0F;
   }
}
