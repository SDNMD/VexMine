package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.WebPlacer;

public final class HeadWebController {
   private static final double WALL_MAX_DIST = (double)2.5F;
   private static final int WALL_MIN_HEIGHT = 2;
   private static final double HIT_RANGE = (double)3.0F;
   private static final int SETTLE_TICKS = 2;
   private static final int HEAD_RISE = 1;
   private static final int WINDUP_TICKS = 2;
   private static final double PLACE_REACH = (double)4.5F;
   private static final int COOLDOWN_OK = 100;
   private static final int COOLDOWN_FAIL = 40;
   private static final int MAX_PHASE_TICKS = 20;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int windup;
   private LivingEntity victim;
   private BlockPos headSpot;
   private int prevSlot;

   public HeadWebController(ServerPlayer bot, MinecraftServer server) {
      this.phase = HeadWebController.Phase.NONE;
      this.phaseTick = 0;
      this.cooldown = 0;
      this.windup = 0;
      this.victim = null;
      this.headSpot = null;
      this.prevSlot = -1;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isExecuting() {
      return this.phase != HeadWebController.Phase.NONE;
   }

   public void reset() {
      if (this.phase != HeadWebController.Phase.NONE && this.prevSlot >= 0 && this.prevSlot < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.phase = HeadWebController.Phase.NONE;
      this.phaseTick = 0;
      this.windup = 0;
      this.victim = null;
      this.headSpot = null;
      this.prevSlot = -1;
      this.cooldown = Math.max(this.cooldown, 40);
   }

   public boolean tick(LivingEntity target) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.phase != HeadWebController.Phase.NONE) {
         return this.drive();
      } else if (target != null && target.isAlive()) {
         if (this.cooldown > 0) {
            return false;
         } else if (!this.bot.onGround()) {
            return false;
         } else if ((double)this.bot.distanceTo(target) > (double)3.0F) {
            return false;
         } else if (!this.bot.hasLineOfSight(target)) {
            return false;
         } else {
            EffectiveSettings eff = EffectiveSettings.of(this.botName);
            if (!eff.useCobwebs()) {
               return false;
            } else if (!WebPlacer.hasWeb(this.bot)) {
               return false;
            } else if (this.wallBehind(target) == null) {
               return false;
            } else if (this.bot.getAttackStrengthScale(0.0F) < 0.9F) {
               return false;
            } else {
               this.lookAtEntity(target);
               this.bot.setSprinting(true);
               BotCommands.setSprinting(this.server, this.botName, true);
               EquipmentSync.syncNow(this.bot);
               this.bot.attack(target);
               McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
               this.victim = target;
               this.phase = HeadWebController.Phase.WAIT;
               this.phaseTick = 0;
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private boolean drive() {
      ++this.phaseTick;
      if (this.victim != null && this.victim.isAlive()) {
         if (this.phaseTick > 20) {
            this.fail();
            return false;
         } else {
            switch (this.phase.ordinal()) {
               case 1:
                  BotCommands.stopMoving(this.server, this.botName);
                  this.bot.setSprinting(false);
                  if (this.phaseTick < 2) {
                     return true;
                  } else {
                     this.headSpot = this.predictHeadAgainstWall(this.victim);
                     if (this.headSpot == null) {
                        this.fail();
                        return false;
                     } else if (this.bot.position().distanceTo(Vec3.atCenterOf(this.headSpot)) > (double)4.5F) {
                        this.fail();
                        return false;
                     } else {
                        int slot = WebPlacer.equipWeb(this.bot);
                        if (slot < 0) {
                           this.fail();
                           return false;
                        }

                        this.prevSlot = InventoryUtils.selected(this.bot.getInventory());
                        InventoryUtils.select(this.bot.getInventory(), slot);
                        this.windup = 2;
                        this.phase = HeadWebController.Phase.PLACE;
                        this.phaseTick = 0;
                        return true;
                     }
                  }
               case 2:
                  BotCommands.stopMoving(this.server, this.botName);
                  int webSlot = WebPlacer.equipWeb(this.bot);
                  if (webSlot >= 0) {
                     InventoryUtils.select(this.bot.getInventory(), webSlot);
                  }

                  WebPlacer.lookAt(this.bot, this.headSpot);
                  if (this.windup > 0) {
                     --this.windup;
                     return true;
                  }

                  boolean placed = WebPlacer.placeAt(this.bot, this.headSpot);
                  if (this.prevSlot >= 0 && this.prevSlot < 9) {
                     InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
                  }

                  this.cooldown = placed ? 100 : 40;
                  this.phase = HeadWebController.Phase.NONE;
                  this.victim = null;
                  this.headSpot = null;
                  this.prevSlot = -1;
                  return placed;
               default:
                  this.fail();
                  return false;
            }
         }
      } else {
         this.fail();
         return false;
      }
   }

   private void fail() {
      if (this.prevSlot >= 0 && this.prevSlot < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.phase = HeadWebController.Phase.NONE;
      this.windup = 0;
      this.victim = null;
      this.headSpot = null;
      this.prevSlot = -1;
      this.cooldown = 40;
   }

   private BlockPos wallBehind(LivingEntity target) {
      Level level = this.bot.level();
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      double len = Math.hypot(dx, dz);
      if (len < 0.001) {
         return null;
      } else {
         dx /= len;
         dz /= len;

         for(double d = 0.6; d <= (double)2.5F; d += (double)0.5F) {
            BlockPos at = BlockPos.containing(target.getX() + dx * d, target.getEyeY(), target.getZ() + dz * d);
            if (this.isWall(level, at)) {
               boolean tall = true;

               for(int h = 0; h < 2; ++h) {
                  if (!this.isWall(level, at.above(h))) {
                     tall = false;
                     break;
                  }
               }

               if (tall) {
                  return at;
               }
            }
         }

         return null;
      }
   }

   private boolean isWall(Level level, BlockPos pos) {
      return level.getBlockState(pos).isFaceSturdy(level, pos, Direction.UP);
   }

   private BlockPos predictHeadAgainstWall(LivingEntity target) {
      Level level = this.bot.level();
      BlockPos wall = this.wallBehind(target);
      if (wall == null) {
         return null;
      } else {
         double dx = target.getX() - this.bot.getX();
         double dz = target.getZ() - this.bot.getZ();
         double len = Math.hypot(dx, dz);
         if (len < 0.001) {
            return null;
         } else {
            dx /= len;
            dz /= len;
            BlockPos against = BlockPos.containing((double)wall.getX() + (double)0.5F - dx, target.getEyeY(), (double)wall.getZ() + (double)0.5F - dz);
            BlockPos high = against.above(1);
            if (level.getBlockState(high).isAir()) {
               return high;
            } else {
               return level.getBlockState(against).isAir() ? against : null;
            }
         }
      }
   }

   private void lookAtEntity(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dy = target.getEyeY() - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getZ();
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.bot.setYRot(yaw);
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, horiz))));
      this.bot.yHeadRot = yaw;
   }

   private static enum Phase {
      NONE,
      WAIT,
      PLACE;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{NONE, WAIT, PLACE};
      }
   }
}
