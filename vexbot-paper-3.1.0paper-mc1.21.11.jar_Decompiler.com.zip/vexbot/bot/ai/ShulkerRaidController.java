package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.EffectiveSettings;
import vexbot.team.TeamManager;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;
import vexbot.util.VexLog;

public final class ShulkerRaidController {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-ShulkerRaid");
   private static final double NEAR_TARGET = (double)8.0F;
   private static final double MAX_TRAVEL = (double)24.0F;
   private static final double REACH = (double)4.0F;
   private static final float MIN_HEALTH = 12.0F;
   private static final int SCAN_EVERY = 20;
   private static final int APPROACH_TIMEOUT = 100;
   private static final int MINE_TIMEOUT = 200;
   private static final int COLLECT_TICKS = 40;
   private static final double DROP_FALL_REACH = (double)8.0F;
   private static final int COOLDOWN_TICKS = 200;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private final PathFollower path;
   private Phase phase;
   private int phaseTick;
   private int scanTick;
   private int cooldown;
   private BlockPos boxPos;
   private int slotBefore;

   public ShulkerRaidController(ServerPlayer bot, MinecraftServer server) {
      this.phase = ShulkerRaidController.Phase.IDLE;
      this.phaseTick = 0;
      this.scanTick = 0;
      this.cooldown = 0;
      this.boxPos = null;
      this.slotBefore = -1;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
      this.path = new PathFollower(bot, server);
   }

   public boolean isExecuting() {
      return this.phase != ShulkerRaidController.Phase.IDLE;
   }

   public boolean tick(LivingEntity target) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.phase != ShulkerRaidController.Phase.IDLE) {
         return this.tickRaid();
      } else if (this.cooldown > 0) {
         return false;
      } else if (target != null && target.isAlive()) {
         if (!EffectiveSettings.of(this.botName).shulkerSteal()) {
            return false;
         } else if (this.bot.getHealth() < 12.0F) {
            return false;
         } else if (this.findPickaxe() < 0) {
            return false;
         } else if (++this.scanTick < 20) {
            return false;
         } else {
            this.scanTick = 0;
            BlockPos found = this.findEnemyShulker(target);
            if (found == null) {
               return false;
            } else {
               this.boxPos = found;
               this.phase = ShulkerRaidController.Phase.APPROACH;
               this.phaseTick = 0;
               this.slotBefore = InventoryUtils.selected(this.bot.getInventory());
               VexLog.detail(LOGGER, "[ShulkerRaid] {} going for {}'s shulker at {}", this.botName, target.getName().getString(), this.boxPos);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   public void reset() {
      if (this.phase != ShulkerRaidController.Phase.IDLE) {
         BotCommands.stopMining(this.server, this.botName);
         this.restoreSlot();
         this.path.reset();
      }

      this.phase = ShulkerRaidController.Phase.IDLE;
      this.phaseTick = 0;
      this.boxPos = null;
   }

   private boolean tickRaid() {
      ++this.phaseTick;
      if (this.phase != ShulkerRaidController.Phase.COLLECT && !this.isShulkerAt(this.boxPos)) {
         VexLog.detail(LOGGER, "[ShulkerRaid] {} lost the box (owner recovered it)", this.botName);
         this.finish();
         return false;
      } else {
         switch (this.phase.ordinal()) {
            case 1:
               if (this.phaseTick > 100) {
                  this.finish();
                  return false;
               }

               double dist = Math.sqrt(this.bot.distanceToSqr(Vec3.atCenterOf(this.boxPos)));
               if (dist <= (double)4.0F) {
                  this.beginMining();
                  this.phase = ShulkerRaidController.Phase.MINE;
                  this.phaseTick = 0;
               } else {
                  this.path.chase(Vec3.atCenterOf(this.boxPos));
               }
               break;
            case 2:
               if (this.phaseTick > 200) {
                  this.finish();
                  return false;
               }

               this.lookAtBox();
               if (!this.isShulkerAt(this.boxPos)) {
                  BotCommands.stopMining(this.server, this.botName);
                  this.phase = ShulkerRaidController.Phase.COLLECT;
                  this.phaseTick = 0;
               }
               break;
            case 3:
               if (this.collectDrop()) {
                  this.finish();
                  return false;
               }

               if (this.phaseTick >= 40) {
                  this.finish();
                  return false;
               }
               break;
            default:
               this.finish();
               return false;
         }

         return true;
      }
   }

   private void beginMining() {
      Inventory inv = this.bot.getInventory();
      int pick = this.findPickaxe();
      if (pick >= 0) {
         pick = InventoryUtils.moveToHotbarSafe(inv, pick);
         InventoryUtils.select(inv, pick);
      }

      this.path.reset();
      BotCommands.stopMoving(this.server, this.botName);
      this.lookAtBox();
      BotCommands.mineContinuous(this.server, this.botName);
   }

   private boolean collectDrop() {
      if (this.boxPos != null) {
         ServerLevel var2 = this.bot.level();
         if (var2 instanceof ServerLevel) {
            ServerLevel sl = var2;
            AABB var8 = (new AABB(this.boxPos)).inflate((double)3.0F).expandTowards((double)0.0F, (double)-8.0F, (double)0.0F);
            boolean got = false;

            for(ItemEntity ie : sl.getEntitiesOfClass(ItemEntity.class, var8)) {
               ItemStack st = ie.getItem();
               if (isShulkerBox(st)) {
                  ItemStack overflow = this.addToInventory(st.copy());
                  if (overflow.isEmpty()) {
                     ie.discard();
                     got = true;
                     VexLog.brief(LOGGER, "[ShulkerRaid] {} stole the shulker", this.botName);
                  } else {
                     ie.setItem(overflow);
                  }
               }
            }

            return got;
         }
      }

      return false;
   }

   private void finish() {
      BotCommands.stopMining(this.server, this.botName);
      this.restoreSlot();
      this.path.reset();
      this.phase = ShulkerRaidController.Phase.IDLE;
      this.phaseTick = 0;
      this.boxPos = null;
      this.cooldown = 200;
   }

   private BlockPos findEnemyShulker(LivingEntity target) {
      ServerLevel var3 = this.bot.level();
      if (!(var3 instanceof ServerLevel)) {
         return null;
      } else {
         ServerLevel sl = var3;
         BlockPos var13 = target.blockPosition();
         byte r = 8;
         BlockPos best = null;
         double bestDist = Double.MAX_VALUE;

         for(BlockPos p : BlockPos.betweenClosed(var13.offset(-r, -3, -r), var13.offset(r, 3, r))) {
            if (sl.getBlockState(p).getBlock() instanceof ShulkerBoxBlock) {
               String owner = RestockController.placedBoxOwner(sl, p);
               if (owner == null || !owner.equals(this.botName) && !TeamManager.isAlliedWithBot(this.botName, owner)) {
                  double d = this.bot.distanceToSqr(Vec3.atCenterOf(p));
                  if (!(d > (double)576.0F) && d < bestDist) {
                     bestDist = d;
                     best = p.immutable();
                  }
               }
            }
         }

         return best;
      }
   }

   private boolean isShulkerAt(BlockPos pos) {
      return pos != null && this.bot.level().getBlockState(pos).getBlock() instanceof ShulkerBoxBlock;
   }

   private static boolean isShulkerBox(ItemStack st) {
      boolean var10000;
      if (!st.isEmpty()) {
         Item var2 = st.getItem();
         if (var2 instanceof BlockItem) {
            BlockItem bi = (BlockItem)var2;
            if (bi.getBlock() instanceof ShulkerBoxBlock) {
               var10000 = true;
               return var10000;
            }
         }
      }

      var10000 = false;
      return var10000;
   }

   private int findPickaxe() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(ItemTags.PICKAXES)) {
            return i;
         }
      }

      return -1;
   }

   private void lookAtBox() {
      if (this.boxPos != null) {
         Vec3 t = Vec3.atCenterOf(this.boxPos);
         Vec3 e = this.bot.getEyePosition();
         double dx = t.x - e.x;
         double dy = t.y - e.y;
         double dz = t.z - e.z;
         double horiz = Math.sqrt(dx * dx + dz * dz);
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
         this.bot.setYRot(yaw);
         this.bot.setXRot(pitch);
         this.bot.yHeadRot = yaw;
      }
   }

   private void restoreSlot() {
      if (this.slotBefore >= 0 && this.slotBefore < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.slotBefore);
      }

      this.slotBefore = -1;
   }

   private ItemStack addToInventory(ItemStack stack) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36 && !stack.isEmpty(); ++i) {
         ItemStack existing = inv.getItem(i);
         if (!existing.isEmpty() && ItemStack.isSameItemSameComponents(existing, stack)) {
            int space = existing.getMaxStackSize() - existing.getCount();
            if (space > 0) {
               int take = Math.min(space, stack.getCount());
               existing.grow(take);
               stack.shrink(take);
            }
         }
      }

      for(int i = 0; i < 36 && !stack.isEmpty(); ++i) {
         if (inv.getItem(i).isEmpty()) {
            inv.setItem(i, stack.copy());
            return ItemStack.EMPTY;
         }
      }

      return stack;
   }

   private static enum Phase {
      IDLE,
      APPROACH,
      MINE,
      COLLECT;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, APPROACH, MINE, COLLECT};
      }
   }
}
