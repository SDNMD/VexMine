package vexbot.bot.ai;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.util.EnchantmentUtils;
import vexbot.util.InventoryUtils;

public final class LoadoutManager {
   private final ServerPlayer bot;
   private final int[] firstBagSlot;
   private static final List<Predicate<ItemStack>> ENSURED = List.of((Predicate)(s) -> s.is(Items.MACE), (Predicate)(s) -> s.is(Items.BOW), (Predicate)(s) -> s.is(Items.CROSSBOW), (Predicate)(s) -> s.is(Items.WIND_CHARGE), (Predicate)(s) -> s.is(ItemTags.SWORDS), (Predicate)(s) -> s.is(ItemTags.AXES), (Predicate)(s) -> EnchantmentUtils.hasEnchantAtLeast(s, "lunge", 3), (Predicate)(s) -> s.is(Items.TRIDENT) && EnchantmentUtils.hasEnchantAtLeast(s, "riptide", 3));
   private static final int ALL_KINDS;

   public LoadoutManager(ServerPlayer bot) {
      this.firstBagSlot = new int[ENSURED.size()];
      this.bot = bot;
   }

   public void tick() {
      Inventory inv = this.bot.getInventory();
      int emptyMask = matches(ItemStack.EMPTY, ALL_KINDS);
      int inHotbar = 0;

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         inHotbar |= s.isEmpty() ? emptyMask : matches(s, ~inHotbar & ALL_KINDS);
      }

      int pending = ~inHotbar & ALL_KINDS;
      int inBag = 0;

      for(int i = 9; i < 36 && pending != 0; ++i) {
         ItemStack s = inv.getItem(i);
         int m = s.isEmpty() ? emptyMask & pending : matches(s, pending);
         if (m != 0) {
            for(int k = 0; k < ENSURED.size(); ++k) {
               if ((m & 1 << k) != 0) {
                  this.firstBagSlot[k] = i;
               }
            }

            inBag |= m;
            pending &= ~m;
         }
      }

      for(int k = 0; k < ENSURED.size(); ++k) {
         if ((inBag & 1 << k) != 0) {
            this.pull(inv, this.firstBagSlot[k]);
            this.ensureFrom(inv, k + 1);
            return;
         }
      }

   }

   private void ensureFrom(Inventory inv, int from) {
      if (from <= 0) {
         this.ensureExactItem(inv, Items.MACE);
      }

      if (from <= 1) {
         this.ensureExactItem(inv, Items.BOW);
      }

      if (from <= 2) {
         this.ensureExactItem(inv, Items.CROSSBOW);
      }

      if (from <= 3) {
         this.ensureExactItem(inv, Items.WIND_CHARGE);
      }

      if (from <= 4) {
         this.ensureTagged(inv, ItemTags.SWORDS);
      }

      if (from <= 5) {
         this.ensureTagged(inv, ItemTags.AXES);
      }

      if (from <= 6) {
         this.ensureLungeSpear(inv);
      }

      if (from <= 7) {
         this.ensureRiptideTrident(inv);
      }

   }

   private static int matches(ItemStack s, int mask) {
      int m = 0;

      for(int k = 0; k < ENSURED.size(); ++k) {
         if ((mask & 1 << k) != 0 && ((Predicate)ENSURED.get(k)).test(s)) {
            m |= 1 << k;
         }
      }

      return m;
   }

   private void pull(Inventory inv, int from) {
      boolean room = false;

      for(int i = 0; i < 9 && !room; ++i) {
         ItemStack s = inv.getItem(i);
         room = s.isEmpty() || !InventoryUtils.isProtected(s);
      }

      if (room || !isSoleEnsured(inv, 8)) {
         InventoryUtils.moveToHotbarSafe(inv, from);
      }
   }

   private static boolean isSoleEnsured(Inventory inv, int slot) {
      ItemStack held = inv.getItem(slot);
      if (held.isEmpty()) {
         return false;
      } else {
         for(Predicate<ItemStack> kind : ENSURED) {
            if (kind.test(held)) {
               boolean elsewhere = false;

               for(int i = 0; i < 9 && !elsewhere; ++i) {
                  if (i != slot && kind.test(inv.getItem(i))) {
                     elsewhere = true;
                  }
               }

               if (!elsewhere) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private void ensureExactItem(Inventory inv, Item item) {
      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(item)) {
            return;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(item)) {
            this.pull(inv, i);
            return;
         }
      }

   }

   private void ensureTagged(Inventory inv, TagKey<Item> tag) {
      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(tag)) {
            return;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(tag)) {
            this.pull(inv, i);
            return;
         }
      }

   }

   private void ensureLungeSpear(Inventory inv) {
      for(int i = 0; i < 9; ++i) {
         if (EnchantmentUtils.hasEnchantAtLeast(inv.getItem(i), "lunge", 3)) {
            return;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (EnchantmentUtils.hasEnchantAtLeast(inv.getItem(i), "lunge", 3)) {
            this.pull(inv, i);
            return;
         }
      }

   }

   private void ensureRiptideTrident(Inventory inv) {
      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.TRIDENT) && EnchantmentUtils.hasEnchantAtLeast(s, "riptide", 3)) {
            return;
         }
      }

      for(int i = 9; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.TRIDENT) && EnchantmentUtils.hasEnchantAtLeast(s, "riptide", 3)) {
            this.pull(inv, i);
            return;
         }
      }

   }

   static {
      ALL_KINDS = (1 << ENSURED.size()) - 1;
   }
}
