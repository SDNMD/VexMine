package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;

public final class CobwebTrapController {
   private static final int PREDICT_TICKS = 4;
   private static final double TRAP_RANGE = (double)4.5F;
   private static final int COOLDOWN_MIN = 600;
   private static final int COOLDOWN_MAX = 900;
   private static final float LOW_HP = 12.0F;
   private static final int COMBAT_START_DELAY = 300;
   private static final int WEB_BLOCKS_PEARL_TICKS = 20;
   private static final Random RNG = new Random();
   private static final int HIT_WAIT_TICKS = 2;
   private static final int HIT_PLACE_TIMEOUT = 26;
   private static final int HIT_WEB_CD_MIN = 140;
   private static final int HIT_WEB_CD_MAX = 220;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private HitWebPhase hitPhase;
   private int hitTicks;
   private LivingEntity hitTarget;
   private BlockPos hitLanding;
   private int hitWebSlot;
   private int hitPrevSlot;
   private int cooldown;
   private BlockPos placedPos;
   private long placedAtTick;
   private static final int PLACED_WEB_TRACK_TICKS = 80;
   private int combatDelay;
   private int webBlockPearl;
   private static final int PLACE_WINDUP_TICKS = 3;
   private static final int FAIL_RETRY_COOLDOWN = 60;
   private int placeWindup;
   private BlockPos pendingTrapPos;
   private int pendingSlot;
   private int prevSlot;

   private double hitWebRange() {
      return (new EffectiveSettings(this.bot.getScoreboardName())).attackRange();
   }

   public boolean isPlacing() {
      return this.placeWindup > 0 || this.hitPhase != CobwebTrapController.HitWebPhase.NONE;
   }

   public CobwebTrapController(ServerPlayer bot, MinecraftServer server) {
      this.hitPhase = CobwebTrapController.HitWebPhase.NONE;
      this.hitTicks = 0;
      this.hitTarget = null;
      this.hitLanding = null;
      this.hitWebSlot = -1;
      this.hitPrevSlot = -1;
      this.cooldown = 0;
      this.placedPos = null;
      this.placedAtTick = 0L;
      this.combatDelay = 300;
      this.webBlockPearl = 0;
      this.placeWindup = 0;
      this.pendingTrapPos = null;
      this.pendingSlot = -1;
      this.prevSlot = -1;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean tick(LivingEntity target, boolean wantCrit, boolean pearlSuppressesWeb) {
      if (this.hitPhase != CobwebTrapController.HitWebPhase.NONE) {
         return this.tickHitWeb();
      } else if (!EffectiveSettings.of(this.botName).useCobwebs()) {
         return false;
      } else {
         Level level = this.bot.level();
         if (this.cooldown > 0) {
            --this.cooldown;
         }

         if (this.webBlockPearl > 0) {
            --this.webBlockPearl;
         }

         if (this.placeWindup > 0) {
            if (this.pendingSlot >= 0 && this.pendingSlot < 9 && this.bot.getInventory().getItem(this.pendingSlot).is(Items.COBWEB) && this.pendingTrapPos != null && level.getBlockState(this.pendingTrapPos).isAir()) {
               InventoryUtils.select(this.bot.getInventory(), this.pendingSlot);
               this.lookAt(this.pendingTrapPos);
               --this.placeWindup;
               if (this.placeWindup == 0) {
                  this.placeCobwebNow(level);
               }

               return true;
            } else {
               this.abortPending();
               return false;
            }
         } else if (pearlSuppressesWeb) {
            return false;
         } else {
            this.expirePlacedWeb(level);
            if (target == null) {
               return false;
            } else if (EffectiveSettings.of(this.botName).hitWeb()) {
               if (this.cooldown == 0 && (double)this.bot.distanceTo(target) <= this.hitWebRange() && this.bot.hasLineOfSight(target)) {
                  int webSlot = this.findCobweb();
                  if (webSlot >= 0) {
                     return this.beginHitWeb(target, this.moveCobwebToHotbar(webSlot));
                  }
               }

               return false;
            } else if (this.combatDelay > 0) {
               --this.combatDelay;
               return false;
            } else if ((double)this.bot.distanceTo(target) > (double)4.5F) {
               return false;
            } else if (!this.bot.hasLineOfSight(target)) {
               return false;
            } else if (!this.shouldTrap(wantCrit)) {
               return false;
            } else if (this.cooldown <= 0 && this.placedPos == null) {
               int slot = this.findCobweb();
               if (slot < 0) {
                  return false;
               } else {
                  BlockPos trapPos = this.predictPosition(target);
                  if (trapPos == null) {
                     return false;
                  } else if (!level.getBlockState(trapPos).isAir()) {
                     return false;
                  } else if (this.bot.position().distanceTo(Vec3.atCenterOf(trapPos)) > (double)4.5F) {
                     return false;
                  } else {
                     slot = this.moveCobwebToHotbar(slot);
                     this.prevSlot = InventoryUtils.selected(this.bot.getInventory());
                     this.pendingSlot = slot;
                     this.pendingTrapPos = trapPos;
                     InventoryUtils.select(this.bot.getInventory(), slot);
                     this.lookAt(trapPos);
                     this.placeWindup = 3;
                     return true;
                  }
               }
            } else {
               return false;
            }
         }
      }
   }

   private void placeCobwebNow(Level level) {
      Inventory inv = this.bot.getInventory();
      boolean placed = false;
      if (this.pendingTrapPos != null && this.pendingSlot >= 0) {
         ItemStack cobwebStack = inv.getItem(this.pendingSlot);
         if (cobwebStack.is(Items.COBWEB) && level.getBlockState(this.pendingTrapPos).isAir()) {
            this.lookAt(this.pendingTrapPos);
            Vec3 hitVec = new Vec3((double)this.pendingTrapPos.getX() + (double)0.5F, (double)this.pendingTrapPos.getY(), (double)this.pendingTrapPos.getZ() + (double)0.5F);
            BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, this.pendingTrapPos.below(), false);
            this.bot.gameMode.useItemOn(this.bot, level, cobwebStack, InteractionHand.MAIN_HAND, hit);
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            placed = level.getBlockState(this.pendingTrapPos).is(Blocks.COBWEB);
         }
      }

      if (placed) {
         this.placedPos = this.pendingTrapPos;
         this.placedAtTick = level.getGameTime();
         this.cooldown = this.rollWebCooldown();
         this.webBlockPearl = 20;
      } else {
         this.cooldown = 60;
      }

      if (this.prevSlot >= 0) {
         InventoryUtils.select(inv, this.prevSlot);
      }

      this.pendingTrapPos = null;
      this.pendingSlot = -1;
      this.prevSlot = -1;
   }

   private float webCooldownScale() {
      float var10000;
      switch (EffectiveSettings.of(this.botName).playStyle()) {
         case AGGRESSIVE -> var10000 = 1.6F;
         case DEFENSIVE -> var10000 = 0.55F;
         case SAFE -> var10000 = 0.7F;
         case BALANCED -> var10000 = 0.85F;
         default -> var10000 = 1.0F;
      }

      return var10000;
   }

   private int rollWebCooldown() {
      int base = 600 + RNG.nextInt(301);
      return Math.max(40, Math.round((float)base * this.webCooldownScale()));
   }

   private void expirePlacedWeb(Level level) {
      if (this.placedPos != null) {
         if (!level.getBlockState(this.placedPos).is(Blocks.COBWEB) || level.getGameTime() - this.placedAtTick >= 80L) {
            this.placedPos = null;
         }

      }
   }

   private void abortPending() {
      this.cooldown = 60;
      if (this.prevSlot >= 0) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.placeWindup = 0;
      this.pendingTrapPos = null;
      this.pendingSlot = -1;
      this.prevSlot = -1;
   }

   private void lookAt(BlockPos pos) {
      if (pos != null) {
         double dx = (double)pos.getX() + (double)0.5F - this.bot.getEyePosition().x;
         double dy = (double)pos.getY() + (double)0.5F - this.bot.getEyePosition().y;
         double dz = (double)pos.getZ() + (double)0.5F - this.bot.getEyePosition().z;
         double horiz = Math.sqrt(dx * dx + dz * dz);
         this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
         this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, horiz))));
         this.bot.yHeadRot = this.bot.getYRot();
      }
   }

   public boolean tryEmergencyWeb(LivingEntity target) {
      if (target == null) {
         return false;
      } else if (!EffectiveSettings.of(this.botName).useCobwebs()) {
         return false;
      } else {
         Level level = this.bot.level();
         this.expirePlacedWeb(level);
         if (this.cooldown <= 0 && this.placedPos == null && this.hitPhase == CobwebTrapController.HitWebPhase.NONE) {
            if ((double)this.bot.distanceTo(target) > (double)4.5F) {
               return false;
            } else if (!this.bot.hasLineOfSight(target)) {
               return false;
            } else {
               int slot = this.findCobweb();
               if (slot < 0) {
                  return false;
               } else {
                  BlockPos trapPos = this.predictPosition(target);
                  if (trapPos != null && level.getBlockState(trapPos).isAir()) {
                     if (this.bot.position().distanceTo(Vec3.atCenterOf(trapPos)) > (double)4.5F) {
                        return false;
                     } else {
                        slot = this.moveCobwebToHotbar(slot);
                        int prev = InventoryUtils.selected(this.bot.getInventory());
                        this.hitWebSlot = slot;
                        boolean placed = this.placeCobwebAt(level, trapPos);
                        this.hitWebSlot = -1;
                        InventoryUtils.select(this.bot.getInventory(), prev);
                        if (placed) {
                           this.placedPos = trapPos;
                           this.placedAtTick = level.getGameTime();
                           this.webBlockPearl = 20;
                           this.cooldown = this.rollWebCooldown();
                        } else {
                           this.cooldown = 60;
                        }

                        return placed;
                     }
                  } else {
                     return false;
                  }
               }
            }
         } else {
            return false;
         }
      }
   }

   public boolean placedWebRecently() {
      return this.webBlockPearl > 0;
   }

   public void reset() {
      this.cooldown = 0;
      this.combatDelay = 300;
      this.placeWindup = 0;
      this.pendingTrapPos = null;
      this.pendingSlot = -1;
      this.prevSlot = -1;
      this.hitPhase = CobwebTrapController.HitWebPhase.NONE;
      this.hitTicks = 0;
      this.hitTarget = null;
      this.hitLanding = null;
      this.hitWebSlot = -1;
      this.hitPrevSlot = -1;
   }

   private boolean beginHitWeb(LivingEntity target, int webSlot) {
      this.hitTarget = target;
      this.hitWebSlot = webSlot;
      this.hitPrevSlot = InventoryUtils.selected(this.bot.getInventory());
      this.lookAtEntity(target);
      this.bot.setSprinting(true);
      BotCommands.setSprinting(this.server, this.botName, true);
      EquipmentSync.syncNow(this.bot);
      this.bot.attack(target);
      McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
      this.hitPhase = CobwebTrapController.HitWebPhase.WAIT;
      this.hitTicks = 0;
      return true;
   }

   private boolean tickHitWeb() {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.webBlockPearl > 0) {
         --this.webBlockPearl;
      }

      ++this.hitTicks;
      if (this.hitTarget != null && this.hitTarget.isAlive()) {
         switch (this.hitPhase.ordinal()) {
            case 1:
               BotCommands.stopMoving(this.server, this.botName);
               this.bot.setSprinting(false);
               if (this.hitTicks >= 2) {
                  BlockPos landing = this.predictLanding(this.hitTarget);
                  if (landing == null) {
                     this.endHitWeb(60);
                     return false;
                  }

                  this.hitLanding = landing;
                  this.hitPhase = CobwebTrapController.HitWebPhase.PLACE;
                  this.hitTicks = 0;
               }

               return true;
            case 2:
               return this.tickHitWebPlace();
            default:
               this.endHitWeb(60);
               return false;
         }
      } else {
         this.endHitWeb(60);
         return false;
      }
   }

   private boolean tickHitWebPlace() {
      Level level = this.bot.level();
      if (this.hitLanding != null && level.getBlockState(this.hitLanding).isAir()) {
         Inventory inv = this.bot.getInventory();
         if (this.hitWebSlot < 0 || this.hitWebSlot >= 9 || !inv.getItem(this.hitWebSlot).is(Items.COBWEB)) {
            int s = this.findCobweb();
            if (s < 0) {
               this.endHitWeb(60);
               return false;
            }

            this.hitWebSlot = this.moveCobwebToHotbar(s);
         }

         InventoryUtils.select(inv, this.hitWebSlot);
         this.lookAt(this.hitLanding);
         double reach = this.bot.position().distanceTo(Vec3.atCenterOf(this.hitLanding));
         if (reach > (double)4.5F) {
            this.moveTowardLanding();
            if (this.hitTicks >= 26) {
               this.endHitWeb(60);
               return false;
            } else {
               return true;
            }
         } else {
            BotCommands.stopMoving(this.server, this.botName);
            if (this.placeCobwebAt(level, this.hitLanding)) {
               this.webBlockPearl = 20;
               this.endHitWeb(140 + RNG.nextInt(81));
            } else {
               this.endHitWeb(60);
            }

            return true;
         }
      } else {
         this.endHitWeb(60);
         return false;
      }
   }

   private void moveTowardLanding() {
      double dx = (double)this.hitLanding.getX() + (double)0.5F - this.bot.getX();
      double dz = (double)this.hitLanding.getZ() + (double)0.5F - this.bot.getZ();
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      BotCommands.setSprinting(this.server, this.botName, true);
      BotCommands.moveForward(this.server, this.botName);
   }

   private BlockPos predictLanding(LivingEntity target) {
      Level level = this.bot.level();
      double px = target.getX();
      double py = target.getY();
      double pz = target.getZ();
      Vec3 v = target.getDeltaMovement();
      double vx = v.x;
      double vy = v.y;
      double vz = v.z;

      for(int t = 0; t < 40; ++t) {
         vy = (vy - 0.08) * 0.98;
         px += vx;
         py += vy;
         pz += vz;
         vx *= 0.91;
         vz *= 0.91;
         if (!(vy >= (double)0.0F)) {
            BlockPos foot = BlockPos.containing(px, py, pz);
            BlockPos below = foot.below();
            boolean groundBelow = !level.getBlockState(below).getCollisionShape(level, below).isEmpty();
            if (groundBelow && level.getBlockState(foot).isAir() && !this.overlapsBot(foot)) {
               return foot;
            }
         }
      }

      return null;
   }

   private boolean placeCobwebAt(Level level, BlockPos pos) {
      Inventory inv = this.bot.getInventory();
      if (this.hitWebSlot >= 0 && this.hitWebSlot < 9) {
         ItemStack web = inv.getItem(this.hitWebSlot);
         if (web.is(Items.COBWEB) && level.getBlockState(pos).isAir()) {
            this.lookAt(pos);
            Vec3 hitVec = new Vec3((double)pos.getX() + (double)0.5F, (double)pos.getY(), (double)pos.getZ() + (double)0.5F);
            BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, pos.below(), false);
            this.bot.gameMode.useItemOn(this.bot, level, web, InteractionHand.MAIN_HAND, hit);
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            return level.getBlockState(pos).is(Blocks.COBWEB);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void lookAtEntity(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dy = target.getY() + (double)target.getEyeHeight() - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getZ();
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, horiz))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private void endHitWeb(int cooldownTicks) {
      BotCommands.stopMoving(this.server, this.botName);
      BotCommands.setSprinting(this.server, this.botName, false);
      this.bot.setSprinting(false);
      if (this.hitPrevSlot >= 0 && this.hitPrevSlot < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.hitPrevSlot);
      }

      this.hitPhase = CobwebTrapController.HitWebPhase.NONE;
      this.hitTicks = 0;
      this.hitTarget = null;
      this.hitLanding = null;
      this.hitWebSlot = -1;
      this.hitPrevSlot = -1;
      this.cooldown = Math.max(this.cooldown, cooldownTicks);
   }

   private int moveCobwebToHotbar(int slot) {
      return InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), slot);
   }

   private boolean shouldTrap(boolean wantCrit) {
      return this.bot.getHealth() <= 12.0F || wantCrit;
   }

   private BlockPos predictPosition(LivingEntity target) {
      Vec3 vel = target.getKnownMovement();
      double fx = target.getX() + vel.x * (double)4.0F;
      double fz = target.getZ() + vel.z * (double)4.0F;
      Level level = this.bot.level();
      BlockPos start = BlockPos.containing(fx, target.getY(), fz);
      int maxY = this.bot.getBlockY() + 1;

      for(int dy = 0; dy <= 4; ++dy) {
         BlockPos candidate = start.below(dy);
         if (candidate.getY() <= maxY) {
            BlockPos below = candidate.below();
            boolean groundBelow = !level.getBlockState(below).getCollisionShape(level, below).isEmpty();
            if (groundBelow) {
               return this.overlapsBot(candidate) ? null : candidate;
            }
         }
      }

      return null;
   }

   private boolean overlapsBot(BlockPos pos) {
      return (new AABB(pos)).intersects(this.bot.getBoundingBox().inflate(0.3));
   }

   private int findCobweb() {
      for(int i = 0; i < 9; ++i) {
         if (this.bot.getInventory().getItem(i).is(Items.COBWEB)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(Items.COBWEB)) {
            return i;
         }
      }

      return -1;
   }

   private static enum HitWebPhase {
      NONE,
      WAIT,
      PLACE;

      // $FF: synthetic method
      private static HitWebPhase[] $values() {
         return new HitWebPhase[]{NONE, WAIT, PLACE};
      }
   }
}
