package vexbot.bot.ai;

import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ChargedProjectiles;
import vexbot.util.InventoryUtils;

public final class CrossbowHelper {
   public static final int POST_FIRE_COOLDOWN_TICKS = 35;

   private CrossbowHelper() {
   }

   public static ItemStack selectedStack(ServerPlayer bot) {
      return bot.getInventory().getItem(InventoryUtils.selected(bot.getInventory()));
   }

   public static boolean isCharged(ServerPlayer bot) {
      return CrossbowItem.isCharged(selectedStack(bot));
   }

   public static void clearCharge(ServerPlayer bot) {
      int slot = InventoryUtils.selected(bot.getInventory());
      ItemStack stack = bot.getInventory().getItem(slot);
      if (stack.is(Items.CROSSBOW) && CrossbowItem.isCharged(stack)) {
         ItemStack cleared = stack.copy();
         cleared.set(DataComponents.CHARGED_PROJECTILES, ChargedProjectiles.EMPTY);
         bot.getInventory().setItem(slot, cleared);
      }
   }

   public static boolean fireIfCharged(ServerPlayer bot) {
      ItemStack stack = selectedStack(bot);
      if (stack.is(Items.CROSSBOW) && CrossbowItem.isCharged(stack)) {
         bot.gameMode.useItem(bot, bot.level(), stack, InteractionHand.MAIN_HAND);
         clearCharge(bot);
         return true;
      } else {
         return false;
      }
   }
}
