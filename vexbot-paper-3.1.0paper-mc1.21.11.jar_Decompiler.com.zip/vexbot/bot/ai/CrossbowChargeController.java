package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.util.InventoryUtils;

public final class CrossbowChargeController {
   private static final int MAX_CHARGE_TICKS = 40;
   private final ServerPlayer bot;
   private int chargingSlot = -1;
   private int chargeTicks = 0;

   public CrossbowChargeController(ServerPlayer bot) {
      this.bot = bot;
   }

   public boolean isCharging() {
      return this.chargingSlot >= 0;
   }

   public boolean tick() {
      if (!this.hasArrows()) {
         this.stop();
         return false;
      } else {
         if (this.chargingSlot < 0) {
            int slot = this.findUnchargedHotbarCrossbow();
            if (slot < 0) {
               return false;
            }

            this.chargingSlot = slot;
            this.chargeTicks = 0;
         }

         ItemStack cb = this.bot.getInventory().getItem(this.chargingSlot);
         if (cb.is(Items.CROSSBOW) && !CrossbowItem.isCharged(cb) && ++this.chargeTicks <= 40) {
            if (this.bot.isUsingItem() && !this.bot.getUseItem().is(Items.CROSSBOW)) {
               if (this.bot.getUsedItemHand() != InteractionHand.OFF_HAND) {
                  this.stop();
                  return false;
               }

               this.bot.stopUsingItem();
            }

            InventoryUtils.select(this.bot.getInventory(), this.chargingSlot);
            if (!this.bot.isUsingItem()) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
            }

            return true;
         } else {
            this.stop();
            return false;
         }
      }
   }

   public void reset() {
      this.stop();
   }

   private void stop() {
      if (this.chargingSlot >= 0 && this.bot.isUsingItem() && this.bot.getUseItem().is(Items.CROSSBOW)) {
         this.bot.releaseUsingItem();
      }

      this.chargingSlot = -1;
      this.chargeTicks = 0;
   }

   private int findUnchargedHotbarCrossbow() {
      for(int i = 0; i < 9; ++i) {
         ItemStack s = this.bot.getInventory().getItem(i);
         if (s.is(Items.CROSSBOW) && !CrossbowItem.isCharged(s)) {
            return i;
         }
      }

      return -1;
   }

   private boolean hasArrows() {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(ItemTags.ARROWS)) {
            return true;
         }
      }

      return this.bot.getInventory().getItem(40).is(ItemTags.ARROWS);
   }
}
