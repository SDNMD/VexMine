package vexbot.bot.ai;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public final class FormationAnchor {
   private static final double MOVING_SPEED_SQR = 0.0025;
   private static final double RE_ANCHOR_DIST_SQR = (double)64.0F;
   private static final long STALE_AFTER_TICKS = 40L;
   private static final Map<UUID, Anchor> ANCHORS = new ConcurrentHashMap();

   private FormationAnchor() {
   }

   public static Anchored of(LivingEntity leader, long gameTime) {
      UUID key = leader.getUUID();
      Anchor prev = (Anchor)ANCHORS.get(key);
      boolean moving = leader.getKnownMovement().horizontalDistanceSqr() > 0.0025;
      boolean jumped = prev != null && prev.pos.distanceToSqr(leader.position()) > (double)64.0F;
      boolean stale = prev != null && gameTime - prev.lastSeen > 40L;
      if (prev != null && !moving && !jumped && !stale) {
         ANCHORS.put(key, new Anchor(prev.pos, prev.yaw, gameTime));
         return new Anchored(prev.pos, prev.yaw, false);
      } else {
         Anchor now = new Anchor(leader.position(), leader.yBodyRot, gameTime);
         ANCHORS.put(key, now);
         return new Anchored(now.pos, now.yaw, true);
      }
   }

   public static void forget(UUID leaderId) {
      if (leaderId != null) {
         ANCHORS.remove(leaderId);
      }

   }

   private static record Anchor(Vec3 pos, float yaw, long lastSeen) {
   }

   public static record Anchored(Vec3 pos, float yaw, boolean moving) {
   }
}
