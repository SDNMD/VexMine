package vexbot.bot.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.BotMath;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;

public final class CrystalPvpController {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-Crystal");
   private static final double CRYSTAL_RANGE = (double)4.5F;
   private static final double CRYSTAL_MIN_RANGE = (double)0.0F;
   private static final double PLACE_RANGE = (double)4.5F;
   private static final double ATTACK_REACH = (double)3.0F;
   private static final int COOLDOWN_TICKS = 0;
   private static final int MAX_SESSION_TICKS = 10;
   private static final double SELF_BLAST_SAFE = (double)2.0F;
   private static final double SELF_BLAST_TOTEM = (double)1.5F;
   private static final double HIGH_CRYSTAL_Y = (double)2.0F;
   private static final double CRYSTAL_BLAST_DIAMETER = (double)12.0F;
   private static final double SHIELD_BONUS = 0.35;
   private static final double PEARL_FLEE_DIST = (double)12.0F;
   private static final int REPOSITION_TIMEOUT = 20;
   private static final double REPOSITION_ARRIVE = 1.2;
   private static final int REPOSITION_SCAN = 6;
   private static final int REPOSITION_LOCKOUT = 40;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private boolean active = false;
   private int sessionTick = 0;
   private int cooldownLeft = 0;
   private BlockPos obsidianPos = null;
   private EndCrystal lastCrystal = null;
   private boolean kbLaunched = false;
   private int prevSlot = 0;
   private Vec3 kbLaunchPos = null;
   private int shieldWaitTicks = 0;
   private boolean repositioning = false;
   private Vec3 repositionGoal = null;
   private int repositionTicks = 0;
   private int lowerScanLockout = 0;
   private int lastPlaceTick = -1000;
   private boolean seededThisTick = false;

   public CrystalPvpController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.lowerScanLockout > 0) {
         --this.lowerScanLockout;
      }

      if (this.cooldownLeft > 0) {
         --this.cooldownLeft;
         return false;
      } else if (this.repositioning) {
         return this.tickRepositioning(target, dist);
      } else {
         return this.active ? this.tickActive(target, dist) : this.tickIdle(target, dist);
      }
   }

   public boolean isExecuting() {
      return this.active || this.repositioning;
   }

   public boolean isRepositioning() {
      return this.repositioning;
   }

   public boolean tickDetap(LivingEntity target) {
      if (target == null) {
         return false;
      } else {
         ServerLevel var3 = this.bot.level();
         if (var3 instanceof ServerLevel) {
            ServerLevel sl = var3;
            EndCrystal var11 = null;
            double bestDist = (double)3.0F;

            for(EndCrystal crystal : sl.getEntitiesOfClass(EndCrystal.class, this.bot.getBoundingBox().inflate((double)3.0F))) {
               if (crystal != this.lastCrystal) {
                  double d = (double)this.bot.distanceTo(crystal);
                  if (d <= bestDist) {
                     bestDist = d;
                     var11 = crystal;
                  }
               }
            }

            if (var11 == null) {
               return false;
            } else if (!this.bot.hasLineOfSight(var11)) {
               return false;
            } else {
               double aimY = var11.getY() - this.bot.getY() >= (double)2.0F ? var11.getY() + (double)0.5F : var11.getY() + (double)var11.getBbHeight() * (double)0.5F;
               this.aimAt(var11.getX(), aimY, var11.getZ());
               this.bot.attack(var11);
               McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
               return true;
            }
         } else {
            return false;
         }
      }
   }

   public void reset() {
      if (this.active) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.active = false;
      this.sessionTick = 0;
      this.lastCrystal = null;
      this.kbLaunched = false;
      this.repositioning = false;
      this.repositionGoal = null;
      this.repositionTicks = 0;
      this.lowerScanLockout = 0;
      this.kbLaunchPos = null;
      this.shieldWaitTicks = 0;
      this.obsidianPos = null;
   }

   private boolean tickRepositioning(LivingEntity target, double dist) {
      ++this.repositionTicks;
      if (target != null && target.isAlive() && this.repositionGoal != null && this.repositionTicks <= 20 && !(this.bot.position().distanceTo(this.repositionGoal) <= 1.2)) {
         double dx = this.repositionGoal.x - this.bot.getX();
         double dz = this.repositionGoal.z - this.bot.getZ();
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         this.bot.setYRot(BotMath.smoothBodyYaw(this.bot.getYRot(), yaw));
         this.bot.yHeadRot = yaw;
         BotCommands.moveForward(this.server, this.bot.getScoreboardName());
         this.bot.setSprinting(true);
         return true;
      } else {
         if (this.repositionTicks > 20) {
            this.lowerScanLockout = 40;
         }

         this.repositioning = false;
         this.repositionGoal = null;
         this.repositionTicks = 0;
         BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
         return false;
      }
   }

   private boolean tickIdle(LivingEntity target, double dist) {
      if (target != null && target.isAlive()) {
         if (!(dist < (double)0.0F) && !(dist > (double)4.5F)) {
            if (this.findInInventory(Items.END_CRYSTAL) < 0) {
               return false;
            } else if (this.findInInventory(Items.OBSIDIAN) < 0) {
               return false;
            } else if (!this.targetReady(target)) {
               return false;
            } else if (!this.botSafeToEngage()) {
               return false;
            } else if (CrystalSkill.skipSession(this.bot)) {
               this.cooldownLeft = CrystalSkill.hesitateTicks(this.bot);
               return false;
            } else {
               if (this.bot.getY() >= target.getY() - (double)0.5F) {
                  Vec3 lower = this.lowerScanLockout > 0 ? null : this.scanForLowerGround(target);
                  if (lower != null) {
                     this.repositioning = true;
                     this.repositionGoal = lower;
                     this.repositionTicks = 0;
                     return true;
                  }
               }

               this.prevSlot = this.bot.getInventory().getSelectedSlot();
               this.active = true;
               this.sessionTick = 0;
               this.kbLaunched = false;
               this.obsidianPos = null;
               this.lastCrystal = null;
               this.lastPlaceTick = -1000;
               this.shieldWaitTicks = 0;
               this.kbLaunchPos = target.position();
               this.equipTotemToOffhand();
               LOGGER.info("[Crystal] {} starting crystal PVP at dist={}", this.bot.getScoreboardName(), String.format("%.1f", dist));
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean tickActive(LivingEntity target, double dist) {
      ++this.sessionTick;
      if (!this.tickRetotem()) {
         this.finish();
         return false;
      } else if (this.sessionTick > 10) {
         this.finish();
         this.cooldownLeft = Math.max(CrystalSkill.sessionGap(this.bot), this.crystalCooldown());
         return false;
      } else if (target != null && target.isAlive() && !(dist > (double)10.5F)) {
         if (this.findInInventory(Items.END_CRYSTAL) >= 0 && this.findInInventory(Items.OBSIDIAN) >= 0) {
            if (this.kbLaunchPos != null) {
               double horizFled = Math.hypot(target.getX() - this.kbLaunchPos.x, target.getZ() - this.kbLaunchPos.z);
               if (horizFled > (double)12.0F) {
                  this.finish();
                  return false;
               }
            }

            if (this.obsidianPos != null) {
               Vec3 spot = Vec3.atCenterOf(this.obsidianPos.above());
               this.aimAt(spot.x, spot.y, spot.z);
            } else {
               this.aimAt(target.getX(), target.getY() + (double)0.5F, target.getZ());
            }

            if (!this.kbLaunched && this.bot.onGround() && dist <= (double)3.0F) {
               if (this.bot.hasLineOfSight(target)) {
                  this.kbLaunch(target);
               }

               this.kbLaunched = true;
               this.kbLaunchPos = target.position();
               return true;
            } else {
               if (this.obsidianPos == null || !this.isObsidianOrBedrock(this.obsidianPos)) {
                  this.seededThisTick = false;
                  this.obsidianPos = this.pickObsidianSpot(target);
                  if (this.obsidianPos == null) {
                     return true;
                  }

                  if (this.seededThisTick) {
                     return true;
                  }
               }

               if (!this.safeToPlace(this.obsidianPos.above())) {
                  BlockPos retry = this.pickObsidianSpot(target);
                  if (retry == null || !this.safeToPlace(retry.above())) {
                     this.obsidianPos = null;
                     return true;
                  }

                  this.obsidianPos = retry;
               }

               if (CrystalSkill.fumble(this.bot)) {
                  return true;
               } else {
                  if (this.sessionTick - this.lastPlaceTick >= this.crystalCooldown()) {
                     this.breakCrystalOn(this.obsidianPos);
                     EndCrystal crystal = this.placeCrystal(this.obsidianPos);
                     if (crystal == null) {
                        this.obsidianPos = null;
                     } else {
                        this.lastPlaceTick = this.sessionTick;
                        this.lastCrystal = crystal;
                        if (this.inCrystalReach(crystal) && this.bot.hasLineOfSight(crystal) && !CrystalSkill.noInstantHit(this.bot)) {
                           this.lookAt(crystal.position().add((double)0.0F, (double)0.5F, (double)0.0F));
                           this.bot.attack(crystal);
                           McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                           this.lastCrystal = null;
                        }
                     }
                  }

                  return true;
               }
            }
         } else {
            this.finish();
            return false;
         }
      } else {
         this.finish();
         return false;
      }
   }

   private boolean targetReady(LivingEntity target) {
      MobEffectInstance resistance = target.getEffect(MobEffects.RESISTANCE);
      if (resistance != null && resistance.getAmplifier() >= 3) {
         return false;
      } else {
         Vec3 v = target.getDeltaMovement();
         return !(v.y > (double)1.0F) || !(Math.hypot(v.x, v.z) > (double)0.5F);
      }
   }

   private boolean botSafeToEngage() {
      return this.countInInventory(Items.TOTEM_OF_UNDYING) > 0;
   }

   public boolean targetInHole(LivingEntity target) {
      Level level = this.bot.level();
      BlockPos feet = BlockPos.containing(target.getX(), target.getY(), target.getZ());
      int higher = 0;
      int[][] offs = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

      for(int[] o : offs) {
         BlockPos col = feet.offset(o[0], 0, o[1]);
         if (!level.getBlockState(col).isAir() || !level.getBlockState(col.above()).isAir()) {
            ++higher;
         }
      }

      return higher >= 4;
   }

   private boolean tickRetotem() {
      Inventory inv = this.bot.getInventory();
      ItemStack off = inv.getItem(40);
      if (off.is(Items.TOTEM_OF_UNDYING)) {
         return true;
      } else {
         int slot = this.findInInventory(Items.TOTEM_OF_UNDYING);
         if (slot < 0) {
            return off.is(Items.TOTEM_OF_UNDYING);
         } else {
            ItemStack totem = inv.getItem(slot).copy();
            ItemStack current = inv.getItem(40).copy();
            inv.setItem(slot, current);
            inv.setItem(40, totem);
            return true;
         }
      }
   }

   private boolean offhandHasTotem() {
      return this.bot.getInventory().getItem(40).is(Items.TOTEM_OF_UNDYING);
   }

   private BlockPos pickObsidianSpot(LivingEntity target) {
      Level level = this.bot.level();
      Vec3 targetPos = target.position();
      Vec3 targetMid = targetPos.add((double)0.0F, (double)target.getBbHeight() * (double)0.5F, (double)0.0F);
      Vec3 botMid = this.bot.getEyePosition();
      Vec3 facing = null;
      if (target.isBlocking()) {
         Vec3 look = target.getLookAngle();
         Vec3 flat = new Vec3(look.x, (double)0.0F, look.z);
         if (flat.lengthSqr() > 1.0E-4) {
            facing = flat.normalize();
         }
      }

      BlockPos best = null;
      boolean bestReady = false;
      double bestScore = (double)0.0F;
      double selfCare = CrystalSkill.selfCare(this.bot);
      List<BlockPos> worthIt = new ArrayList();
      List<Boolean> worthReady = new ArrayList();

      for(int dx = -3; dx <= 3; ++dx) {
         for(int dz = -3; dz <= 3; ++dz) {
            for(int dy = 0; dy >= -1; --dy) {
               BlockPos at = BlockPos.containing(targetPos.x + (double)dx, targetPos.y + (double)dy, targetPos.z + (double)dz);
               boolean ready = this.isObsidianOrBedrock(at);
               if (ready) {
                  if (this.bot.position().distanceTo(Vec3.atCenterOf(at)) > (double)4.5F || !level.getBlockState(at.above()).isAir() || !level.getEntities((Entity)null, (new AABB(at.above())).expandTowards((double)0.0F, (double)1.0F, (double)0.0F), (e) -> !e.isSpectator() && !(e instanceof EndCrystal)).isEmpty() || !PlacementRaycasts.canSeePlacement(this.bot, at)) {
                     continue;
                  }
               } else if (!this.canSeedObsidian(level, at, target)) {
                  continue;
               }

               if (this.safeToPlace(at.above()) && this.seatInReach(at)) {
                  Vec3 crystal = Vec3.atCenterOf(at.above());
                  double score = this.blastAt(crystal, targetMid) - selfCare * this.blastAt(crystal, botMid);
                  if (facing != null) {
                     Vec3 flat = new Vec3(crystal.x - targetPos.x, (double)0.0F, crystal.z - targetPos.z);
                     if (flat.lengthSqr() > (double)0.25F) {
                        double behind = -flat.normalize().dot(facing);
                        if (behind > (double)0.0F) {
                           score += behind * 0.35;
                        }
                     }
                  }

                  if (ready) {
                     score += 0.05;
                  }

                  if (score > (double)0.0F) {
                     worthIt.add(at);
                     worthReady.add(ready);
                  }

                  if (score > bestScore) {
                     bestScore = score;
                     best = at;
                     bestReady = ready;
                  }
               }
            }
         }
      }

      if (best != null && worthIt.size() > 1 && CrystalSkill.badSeat(this.bot)) {
         int i = ThreadLocalRandom.current().nextInt(worthIt.size());
         best = (BlockPos)worthIt.get(i);
         bestReady = (Boolean)worthReady.get(i);
      }

      if (best != null) {
         return bestReady ? best : this.seedObsidian(level, best);
      } else {
         Vec3 dir = targetPos.subtract(this.bot.position()).normalize();
         BlockPos placed = this.tryPlaceObsidianRow(level, this.bot.position(), dir, this.bot.position().y, target);
         if (placed != null) {
            return placed;
         } else {
            return this.tryPlaceObsidianRow(level, this.bot.position(), dir, targetPos.y, target);
         }
      }
   }

   private double blastAt(Vec3 blast, Vec3 victim) {
      double d = blast.distanceTo(victim);
      return d >= (double)12.0F ? (double)0.0F : (double)1.0F - d / (double)12.0F;
   }

   private boolean canSeedObsidian(Level level, BlockPos pos, LivingEntity target) {
      if (!level.getBlockState(pos).isAir()) {
         return false;
      } else if (!level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
         return false;
      } else if (!level.getBlockState(pos.above()).isAir()) {
         return false;
      } else if (!level.getBlockState(pos.above().above()).isAir()) {
         return false;
      } else if (!this.hasEntityAt(pos) && !this.hasEntityAt(pos.above())) {
         if (Vec3.atCenterOf(pos).distanceTo(target.position()) < (double)1.0F) {
            return false;
         } else if (this.bot.position().distanceTo(Vec3.atCenterOf(pos)) > (double)4.5F) {
            return false;
         } else {
            return PlacementRaycasts.canSeePlacement(this.bot, pos);
         }
      } else {
         return false;
      }
   }

   private BlockPos seedObsidian(Level level, BlockPos pos) {
      if (!PlacementRaycasts.canSeePlacement(this.bot, pos)) {
         return null;
      } else {
         int obsSlot = this.findInInventory(Items.OBSIDIAN);
         if (obsSlot < 0) {
            return null;
         } else {
            obsSlot = this.moveToHotbar(obsSlot);
            InventoryUtils.select(this.bot.getInventory(), obsSlot);
            ItemStack obsStack = this.bot.getInventory().getItem(obsSlot);
            if (!obsStack.is(Items.OBSIDIAN)) {
               return null;
            } else {
               Vec3 hitVec = new Vec3((double)pos.getX() + (double)0.5F, (double)pos.getY(), (double)pos.getZ() + (double)0.5F);
               this.lookAt(hitVec);
               BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, pos.below(), false);
               this.bot.gameMode.useItemOn(this.bot, level, obsStack, InteractionHand.MAIN_HAND, hit);
               McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
               if (!this.isObsidianOrBedrock(pos)) {
                  return null;
               } else {
                  this.seededThisTick = true;
                  return pos;
               }
            }
         }
      }
   }

   private boolean safeToPlace(BlockPos crystalSpot) {
      double floor = this.offhandHasTotem() ? (double)1.5F : (double)2.0F;
      Vec3 center = Vec3.atCenterOf(crystalSpot);
      return this.bot.getEyePosition().distanceTo(center) >= floor;
   }

   private int crystalCooldown() {
      return Math.max(0, (new EffectiveSettings(this.bot.getScoreboardName())).difficultyParams().crystalCooldownTicks);
   }

   private void breakCrystalOn(BlockPos obsPos) {
      ServerLevel sl = this.bot.level();
      if (sl instanceof ServerLevel) {
         List<EndCrystal> on = sl.getEntitiesOfClass(EndCrystal.class, (new AABB(obsPos.above())).inflate((double)0.5F));
         if (!on.isEmpty()) {
            EndCrystal c = (EndCrystal)on.get(0);
            if (this.inCrystalReach(c) && this.bot.hasLineOfSight(c)) {
               this.lookAt(c.position().add((double)0.0F, (double)0.5F, (double)0.0F));
               this.bot.attack(c);
               McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
               if (c == this.lastCrystal) {
                  this.lastCrystal = null;
               }

            }
         }
      }
   }

   private EndCrystal placeCrystal(BlockPos obsPos) {
      ServerLevel var3 = this.bot.level();
      if (var3 instanceof ServerLevel) {
         ServerLevel sl = var3;
         BlockPos var10 = obsPos.above();
         if (!sl.getBlockState(var10).isAir()) {
            return null;
         } else if (!sl.getBlockState(var10.above()).isAir()) {
            return null;
         } else {
            List<EndCrystal> existing = sl.getEntitiesOfClass(EndCrystal.class, (new AABB(var10)).inflate((double)0.5F));
            if (!existing.isEmpty()) {
               this.lastCrystal = (EndCrystal)existing.get(0);
               if (this.inCrystalReach(this.lastCrystal) && this.bot.hasLineOfSight(this.lastCrystal)) {
                  this.bot.attack(this.lastCrystal);
                  McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
               }

               return null;
            } else {
               int crystalSlot = this.findInInventory(Items.END_CRYSTAL);
               if (crystalSlot < 0) {
                  return null;
               } else {
                  crystalSlot = this.moveToHotbar(crystalSlot);
                  InventoryUtils.select(this.bot.getInventory(), crystalSlot);
                  ItemStack crystalStack = this.bot.getInventory().getItem(crystalSlot);
                  if (!crystalStack.is(Items.END_CRYSTAL)) {
                     return null;
                  } else {
                     Vec3 hitVec = new Vec3((double)obsPos.getX() + (double)0.5F, (double)obsPos.getY() + (double)1.0F, (double)obsPos.getZ() + (double)0.5F);
                     this.lookAt(hitVec);
                     BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, obsPos, false);
                     this.bot.gameMode.useItemOn(this.bot, sl, crystalStack, InteractionHand.MAIN_HAND, hit);
                     List<EndCrystal> spawned = sl.getEntitiesOfClass(EndCrystal.class, (new AABB(var10)).inflate((double)0.5F));
                     return spawned.isEmpty() ? null : (EndCrystal)spawned.get(0);
                  }
               }
            }
         }
      } else {
         return null;
      }
   }

   private BlockPos tryPlaceObsidianRow(Level level, Vec3 botPos, Vec3 dir, double y, LivingEntity target) {
      for(double d = (double)2.0F; d <= (double)4.0F; d += (double)0.5F) {
         Vec3 cand = botPos.add(dir.scale(d));
         BlockPos pos = BlockPos.containing(cand.x, y, cand.z);
         if (!this.hasEntityAt(pos) && !this.hasEntityAt(pos.above()) && !(Vec3.atCenterOf(pos).distanceTo(target.position()) < (double)1.0F) && level.getBlockState(pos).isAir() && level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP) && level.getBlockState(pos.above()).isAir() && level.getBlockState(pos.above().above()).isAir()) {
            BlockPos placed = this.seedObsidian(level, pos);
            if (placed != null) {
               return placed;
            }
         }
      }

      return null;
   }

   private boolean isObsidianOrBedrock(BlockPos pos) {
      BlockState state = this.bot.level().getBlockState(pos);
      return state.is(Blocks.OBSIDIAN) || state.is(Blocks.BEDROCK);
   }

   private Vec3 scanForLowerGround(LivingEntity target) {
      Level level = this.bot.level();
      Vec3 botPos = this.bot.position();
      double targetY = target.getY();
      double bestScore = Double.MAX_VALUE;
      Vec3 best = null;

      for(int dx = -6; dx <= 6; ++dx) {
         for(int dz = -6; dz <= 6; ++dz) {
            for(int dy = 1; dy <= 6; ++dy) {
               BlockPos floor = BlockPos.containing(botPos.x + (double)dx, botPos.y - (double)dy, botPos.z + (double)dz);
               BlockPos stand = floor.above();
               if (!level.getBlockState(stand).isAir() || !level.getBlockState(stand.above()).isAir()) {
                  break;
               }

               if (level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP)) {
                  if (!((double)stand.getY() >= targetY - (double)0.5F)) {
                     Vec3 standVec = Vec3.atCenterOf(stand);
                     if (!(standVec.distanceTo(target.position()) > (double)4.5F)) {
                        double score = (double)stand.getY() * (double)100.0F + botPos.distanceTo(standVec);
                        if (score < bestScore) {
                           bestScore = score;
                           best = standVec;
                        }
                     }
                  }
                  break;
               }
            }
         }
      }

      return best;
   }

   private void kbLaunch(LivingEntity target) {
      EquipmentSync.syncNow(this.bot);
      this.bot.setSprinting(true);
      this.bot.attack(target);
      McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
   }

   private boolean inCrystalReach(EndCrystal crystal) {
      return crystal.getBoundingBox().distanceToSqr(this.bot.getEyePosition()) <= (double)9.0F;
   }

   private boolean seatInReach(BlockPos obsidian) {
      AABB box = new AABB((double)obsidian.getX() - (double)0.5F, (double)obsidian.getY() + (double)1.0F, (double)obsidian.getZ() - (double)0.5F, (double)obsidian.getX() + (double)1.5F, (double)obsidian.getY() + (double)3.0F, (double)obsidian.getZ() + (double)1.5F);
      return box.distanceToSqr(this.bot.getEyePosition()) <= (double)9.0F;
   }

   private boolean hasEntityAt(BlockPos pos) {
      ServerLevel sl = this.bot.level();
      if (sl instanceof ServerLevel) {
         return !sl.getEntitiesOfClass(LivingEntity.class, (new AABB(pos)).inflate(0.1)).isEmpty();
      } else {
         return false;
      }
   }

   private void finish() {
      if (this.active) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.active = false;
      this.cooldownLeft = this.crystalCooldown();
      this.lastCrystal = null;
      this.obsidianPos = null;
      this.shieldWaitTicks = 0;
      this.kbLaunchPos = null;
   }

   private void aimAt(double x, double y, double z) {
      double dx = x - this.bot.getEyePosition().x;
      double dy = y - this.bot.getEyePosition().y;
      double dz = z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(BotMath.smoothBodyYaw(this.bot.getYRot(), yaw));
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private int findInInventory(Item item) {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private int countInInventory(Item item) {
      int total = 0;

      for(int i = 0; i < 41; ++i) {
         ItemStack s = this.bot.getInventory().getItem(i);
         if (s.is(item)) {
            total += s.getCount();
         }
      }

      return total;
   }

   private int moveToHotbar(int slot) {
      return InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), slot);
   }

   private void equipTotemToOffhand() {
      Inventory inv = this.bot.getInventory();
      if (!inv.getItem(40).is(Items.TOTEM_OF_UNDYING)) {
         int totemSlot = this.findInInventory(Items.TOTEM_OF_UNDYING);
         if (totemSlot >= 0) {
            ItemStack totem = inv.getItem(totemSlot).copy();
            ItemStack offhand = inv.getItem(40).copy();
            inv.setItem(totemSlot, offhand);
            inv.setItem(40, totem);
         }
      }
   }

   private void lookAt(Vec3 pos) {
      double dx = pos.x - this.bot.getEyePosition().x;
      double dy = pos.y - this.bot.getEyePosition().y;
      double dz = pos.z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(BotMath.smoothBodyYaw(this.bot.getYRot(), yaw));
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }
}
