package vexbot.bot.ai;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import vexbot.VexBot;
import vexbot.util.VexLog;

public final class InvisibleSuitUp {
   private static final EquipmentSlot[] ORDER;
   private static final Map<UUID, State> STATES;

   private InvisibleSuitUp() {
   }

   public static boolean holdsArmour(ServerPlayer bot) {
      State s = (State)STATES.get(bot.getUUID());
      if (s != null && s.step >= 0) {
         return true;
      } else if (!bot.hasEffect(MobEffects.INVISIBILITY)) {
         return false;
      } else {
         return s != null && s.released ? false : wearsNoArmour(bot);
      }
   }

   public static boolean callToArms(ServerPlayer bot) {
      return start(bot, false);
   }

   public static void tick(ServerPlayer bot) {
      UUID id = bot.getUUID();
      State s = (State)STATES.get(id);
      if (s != null && s.step < 0 && !bot.hasEffect(MobEffects.INVISIBILITY)) {
         STATES.remove(id);
      } else if (s != null && s.step >= 0) {
         if (s.timer-- <= 0) {
            while(s.step < ORDER.length) {
               EquipmentSlot slot = ORDER[s.step++];
               if (equipBest(bot, slot)) {
                  s.timer = s.fast ? 2 : 4 + ThreadLocalRandom.current().nextInt(4);
                  return;
               }
            }

            s.step = -1;
            s.released = true;
         }
      } else {
         if (bot.hurtTime > 0 && holdsArmour(bot)) {
            start(bot, true);
         }

      }
   }

   private static boolean start(ServerPlayer bot, boolean fast) {
      if (holdsArmour(bot) && hasArmourToWear(bot)) {
         State s = (State)STATES.computeIfAbsent(bot.getUUID(), (k) -> new State());
         if (s.step < 0) {
            s.step = 0;
            s.timer = fast ? 0 : 2 + ThreadLocalRandom.current().nextInt(6);
         }

         s.fast |= fast;
         return true;
      } else {
         return false;
      }
   }

   private static boolean wearsNoArmour(ServerPlayer bot) {
      for(EquipmentSlot slot : ORDER) {
         if (!bot.getItemBySlot(slot).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   private static boolean hasArmourToWear(ServerPlayer bot) {
      Inventory inv = bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (ArmorEvaluator.isArmor(inv.getItem(i))) {
            return true;
         }
      }

      return false;
   }

   private static boolean equipBest(ServerPlayer bot, EquipmentSlot slot) {
      Inventory inv = bot.getInventory();
      ItemStack worn = bot.getItemBySlot(slot);
      int best = -1;
      double bestScore = ArmorEvaluator.score(worn);

      for(int i = 0; i < 36; ++i) {
         ItemStack cand = inv.getItem(i);
         if (ArmorEvaluator.isArmor(cand) && ArmorEvaluator.getSlot(cand) == slot) {
            double sc = ArmorEvaluator.score(cand);
            if (sc > bestScore) {
               bestScore = sc;
               best = i;
            }
         }
      }

      if (best < 0) {
         return false;
      } else {
         ItemStack piece = inv.getItem(best).copy();
         inv.setItem(best, worn.isEmpty() ? ItemStack.EMPTY : worn.copy());
         bot.setItemSlot(slot, piece);
         VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' suits up: {}", bot.getScoreboardName(), piece.getHoverName().getString());
         return true;
      }
   }

   static {
      ORDER = new EquipmentSlot[]{EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.HEAD, EquipmentSlot.CHEST};
      STATES = new ConcurrentHashMap();
   }

   private static final class State {
      int step = -1;
      int timer;
      boolean fast;
      boolean released;
   }
}
