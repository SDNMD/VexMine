package vexbot.bot.ai;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Unit;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

public final class StunSlamDummy {
   private static final double DIVE_HEIGHT_MIN = (double)3.0F;
   private static final double DIVE_HORIZ_SQR = (double)12.25F;
   private static final double HOLD_HORIZ_SQR = (double)20.25F;
   private static final double LAND_HEIGHT = (double)0.5F;
   private static final double SCAN_RANGE_SQR = (double)100.0F;
   private static final Map<UUID, UUID> HOLDING = new ConcurrentHashMap();

   private StunSlamDummy() {
   }

   public static void tick(ServerPlayer bot) {
      Vec3 dm = bot.getDeltaMovement();
      if (dm.x != (double)0.0F || dm.z != (double)0.0F) {
         bot.setDeltaMovement((double)0.0F, Math.min((double)0.0F, dm.y), (double)0.0F);
      }

      bot.setSprinting(false);
      ItemStack off = bot.getOffhandItem();
      if (!off.is(Items.SHIELD)) {
         ItemStack shield = new ItemStack(Items.SHIELD);
         shield.set(DataComponents.UNBREAKABLE, Unit.INSTANCE);
         bot.getInventory().setItem(40, shield);
      }

      if (!bot.hasEffect(MobEffects.RESISTANCE)) {
         bot.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, -1, 4, false, false));
      }

      Player threat = resolveThreat(bot);
      if (threat != null) {
         lookAt(bot, threat);
      }

      if (!bot.getCooldowns().isOnCooldown(bot.getOffhandItem())) {
         if (!bot.isUsingItem() || bot.getUsedItemHand() != InteractionHand.OFF_HAND) {
            bot.startUsingItem(InteractionHand.OFF_HAND);
         }

      }
   }

   private static Player resolveThreat(ServerPlayer bot) {
      UUID held = (UUID)HOLDING.get(bot.getUUID());
      if (held != null) {
         Player pl = bot.level().getPlayerByUUID(held);
         Player p = pl instanceof Player ? pl : null;
         if (p != null && stillDescending(bot, p)) {
            return p;
         }

         HOLDING.remove(bot.getUUID());
      }

      Player fresh = findDiveThreat(bot);
      if (fresh != null) {
         HOLDING.put(bot.getUUID(), fresh.getUUID());
      }

      return fresh;
   }

   private static boolean stillDescending(ServerPlayer bot, Player p) {
      if (p.isAlive() && !p.isSpectator()) {
         double dx = p.getX() - bot.getX();
         double dz = p.getZ() - bot.getZ();
         if (dx * dx + dz * dz > (double)20.25F) {
            return false;
         } else if (!carriesMaceOrSpear(p)) {
            return false;
         } else {
            boolean atGround = p.onGround() || p.getY() - bot.getY() <= (double)0.5F;
            return !atGround;
         }
      } else {
         return false;
      }
   }

   private static Player findDiveThreat(ServerPlayer bot) {
      Player best = null;
      double bestSqr = (double)100.0F;

      for(Player p : bot.level().players()) {
         if (p != bot && p.isAlive() && !p.isSpectator()) {
            double sqr = p.distanceToSqr(bot);
            if (!(sqr > bestSqr) && !(p.getY() - bot.getY() < (double)3.0F)) {
               double dx = p.getX() - bot.getX();
               double dz = p.getZ() - bot.getZ();
               if (!(dx * dx + dz * dz > (double)12.25F) && !(p.getDeltaMovement().y >= -0.08) && carriesMaceOrSpear(p)) {
                  bestSqr = sqr;
                  best = p;
               }
            }
         }
      }

      return best;
   }

   public static boolean carriesMaceOrSpear(Player p) {
      for(int i = 0; i < 36; ++i) {
         if (isMaceOrSpear(p.getInventory().getItem(i))) {
            return true;
         }
      }

      return isMaceOrSpear(p.getOffhandItem()) || isMaceOrSpear(p.getMainHandItem());
   }

   public static boolean isMaceOrSpear(ItemStack s) {
      return s.is(Items.MACE) || s.has(DataComponents.PIERCING_WEAPON);
   }

   private static void lookAt(ServerPlayer bot, Player p) {
      double dx = p.getX() - bot.getEyePosition().x;
      double dy = p.getY() + (double)p.getBbHeight() * (double)0.5F - bot.getEyePosition().y;
      double dz = p.getZ() - bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      bot.setYRot(yaw);
      bot.setXRot(pitch);
      bot.yHeadRot = yaw;
      bot.yBodyRot = yaw;
   }
}
