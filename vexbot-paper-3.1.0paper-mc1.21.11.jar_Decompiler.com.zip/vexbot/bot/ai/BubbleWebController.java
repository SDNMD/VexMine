package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

public final class BubbleWebController {
   private static final int PLACE_WINDUP = 2;
   private static final float HEAL_TARGET_HP = 16.0F;
   private static final int HEAL_MAX_TICKS = 120;
   private static final int PEARL_MAX_TICKS = 40;
   private static final int COOLDOWN = 200;
   private static final int PLACE_FAIL_CAP = 20;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private Phase phase;
   private int phaseTick;
   private int placeFails;
   private int cooldown;
   private int prevSlot;

   public BubbleWebController(ServerPlayer bot, MinecraftServer server) {
      this.phase = BubbleWebController.Phase.IDLE;
      this.phaseTick = 0;
      this.placeFails = 0;
      this.cooldown = 0;
      this.prevSlot = -1;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isActive() {
      return this.phase != BubbleWebController.Phase.IDLE;
   }

   public boolean canStart() {
      return this.cooldown == 0 && this.phase == BubbleWebController.Phase.IDLE && this.bot.onGround() && this.countItem(Items.COBWEB) >= 2 && this.countItem(Items.ENDER_PEARL) >= 1;
   }

   public boolean tick(LivingEntity target, HealingController healingController, EnderPearlController enderPearlController) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.phase == BubbleWebController.Phase.IDLE) {
         if (!this.canStart()) {
            return false;
         }

         this.prevSlot = InventoryUtils.selected(this.bot.getInventory());
         this.phase = BubbleWebController.Phase.FEET;
         this.phaseTick = 0;
      }

      BotCommands.stopMoving(this.server, this.botName);
      switch (this.phase.ordinal()) {
         case 1:
            return this.tickPlace(this.bot.blockPosition(), BubbleWebController.Phase.HEAD);
         case 2:
            return this.tickPlace(this.bot.blockPosition().above(), BubbleWebController.Phase.HEAL);
         case 3:
            if (target != null && target.isAlive() && this.boxIntact()) {
               boolean healed = healingController.tick(true, target, false);
               boolean full = this.bot.getHealth() >= 16.0F;
               if (!full && (healed || this.phaseTick <= 8) && this.phaseTick < 120) {
                  ++this.phaseTick;
                  return true;
               } else {
                  healingController.abortHealing();
                  this.advance(BubbleWebController.Phase.PEARL);
                  return true;
               }
            } else {
               healingController.abortHealing();
               this.advance(BubbleWebController.Phase.PEARL);
               return true;
            }
         case 4:
            if (target != null && target.isAlive() && enderPearlController.tryThrow(target)) {
               this.finish();
               return false;
            } else {
               if (target != null && target.isAlive() && ++this.phaseTick < 40) {
                  return true;
               }

               this.finish();
               return false;
            }
         default:
            return false;
      }
   }

   private boolean tickPlace(BlockPos pos, Phase next) {
      Level level = this.bot.level();
      if (level.getBlockState(pos).is(Blocks.COBWEB)) {
         this.advance(next);
         return true;
      } else {
         int slot = this.equipCobweb();
         if (slot < 0) {
            this.finish();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), slot);
            this.lookAt(pos);
            if (this.phaseTick < 2) {
               ++this.phaseTick;
               return true;
            } else {
               this.placeWebAt(pos, slot);
               if (level.getBlockState(pos).is(Blocks.COBWEB)) {
                  this.advance(next);
               } else if (++this.placeFails >= 20) {
                  this.finish();
               }

               return this.phase != BubbleWebController.Phase.IDLE;
            }
         }
      }
   }

   private void placeWebAt(BlockPos pos, int slot) {
      Level level = this.bot.level();
      ItemStack web = this.bot.getInventory().getItem(slot);
      if (web.is(Items.COBWEB) && level.getBlockState(pos).isAir()) {
         BlockPos clicked = pos.below();
         Vec3 hitVec = new Vec3((double)pos.getX() + (double)0.5F, (double)pos.getY(), (double)pos.getZ() + (double)0.5F);
         BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, clicked, false);
         this.bot.gameMode.useItemOn(this.bot, level, web, InteractionHand.MAIN_HAND, hit);
         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
      }
   }

   private boolean boxIntact() {
      Level level = this.bot.level();
      BlockPos feet = this.bot.blockPosition();
      return level.getBlockState(feet).is(Blocks.COBWEB) && level.getBlockState(feet.above()).is(Blocks.COBWEB);
   }

   private int equipCobweb() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.COBWEB)) {
            return InventoryUtils.moveToHotbarSafe(inv, i);
         }
      }

      return -1;
   }

   private int countItem(Item item) {
      int n = 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(item)) {
            n += inv.getItem(i).getCount();
         }
      }

      return n;
   }

   private void lookAt(BlockPos pos) {
      double dx = (double)pos.getX() + (double)0.5F - this.bot.getEyePosition().x;
      double dy = (double)pos.getY() + (double)0.5F - this.bot.getEyePosition().y;
      double dz = (double)pos.getZ() + (double)0.5F - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, horiz))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private void advance(Phase next) {
      this.phase = next;
      this.phaseTick = 0;
      this.placeFails = 0;
   }

   private void finish() {
      if (this.prevSlot >= 0 && this.prevSlot < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.phase = BubbleWebController.Phase.IDLE;
      this.phaseTick = 0;
      this.placeFails = 0;
      this.prevSlot = -1;
      this.cooldown = 200;
   }

   public void reset() {
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      this.phase = BubbleWebController.Phase.IDLE;
      this.phaseTick = 0;
      this.placeFails = 0;
      this.prevSlot = -1;
   }

   private static enum Phase {
      IDLE,
      FEET,
      HEAD,
      HEAL,
      PEARL;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, FEET, HEAD, HEAL, PEARL};
      }
   }
}
