package vexbot.bot.ai;

import java.util.ArrayDeque;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

public final class TunnelController {
   private static final double MAX_DIST = (double)14.0F;
   private static final int BLOCKED_TRIGGER_TICKS = 30;
   private static final int PER_BLOCK_TIMEOUT = 100;
   private static final int STUCK_TICKS = 140;
   private static final int WALK_TICKS = 10;
   private static final int ABORT_COOLDOWN = 120;
   private static final double MELEE_REACH = (double)3.5F;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private boolean active = false;
   private Mode mode;
   private final ArrayDeque<BlockPos> cells;
   private boolean stepUp;
   private int cellTicks;
   private int walkTicks;
   private int blockedTicks;
   private double bestDist;
   private int noProgress;
   private int cooldown;
   private static final int STUCK_TICKS_FOR_PEARL = 16;
   private double bestTriggerDist;

   public TunnelController(ServerPlayer bot, MinecraftServer server) {
      this.mode = TunnelController.Mode.MINING;
      this.cells = new ArrayDeque();
      this.stepUp = false;
      this.cellTicks = 0;
      this.walkTicks = 0;
      this.blockedTicks = 0;
      this.bestDist = Double.POSITIVE_INFINITY;
      this.noProgress = 0;
      this.cooldown = 0;
      this.bestTriggerDist = Double.POSITIVE_INFINITY;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isActive() {
      return this.active;
   }

   public boolean stuck() {
      return !this.active && this.blockedTicks >= 16;
   }

   public void reset() {
      if (this.active) {
         BotCommands.stopMining(this.server, this.botName);
         BotCommands.stopMoving(this.server, this.botName);
      }

      this.active = false;
      this.cells.clear();
      this.cellTicks = 0;
      this.walkTicks = 0;
      this.blockedTicks = 0;
      this.bestDist = Double.POSITIVE_INFINITY;
      this.noProgress = 0;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (target != null && target.isAlive()) {
         if (!this.active) {
            boolean below = target.getY() - this.bot.getY() < (double)-1.5F && this.horizontal(target) <= (double)3.0F && dist > (double)3.5F;
            boolean walled = dist <= (double)14.0F && (below || !this.bot.hasLineOfSight(target));
            if (walled && dist > this.bestTriggerDist - (double)0.25F) {
               ++this.blockedTicks;
            } else {
               this.blockedTicks = 0;
               this.bestTriggerDist = dist;
            }

            if (!walled) {
               this.bestTriggerDist = Double.POSITIVE_INFINITY;
            }

            if (this.cooldown > 0 || this.blockedTicks < 30) {
               return false;
            }

            if (!this.bot.onGround()) {
               return false;
            }

            if (!this.planStep(target)) {
               this.blockedTicks = 0;
               return false;
            }

            this.active = true;
            this.mode = TunnelController.Mode.MINING;
            this.bestDist = dist;
            this.noProgress = 0;
         }

         if (!this.bot.hasLineOfSight(target) || !(dist <= (double)4.0F) || !(dist <= (double)3.5F) && !(target.getY() - this.bot.getY() >= (double)-1.5F)) {
            if (dist > (double)20.0F) {
               this.abort();
               return false;
            } else {
               if (dist < this.bestDist - 0.3) {
                  this.bestDist = dist;
                  this.noProgress = 0;
               } else if (++this.noProgress > 140) {
                  this.abort();
                  return false;
               }

               return this.mode == TunnelController.Mode.MINING ? this.tickMining(target) : this.tickWalking(target);
            }
         } else {
            this.reset();
            return false;
         }
      } else {
         this.reset();
         return false;
      }
   }

   private boolean tickMining(LivingEntity target) {
      Level level;
      for(level = this.bot.level(); !this.cells.isEmpty() && !this.needsMining(level, (BlockPos)this.cells.peekFirst()); this.cellTicks = 0) {
         this.cells.pollFirst();
      }

      if (this.cells.isEmpty()) {
         BotCommands.stopMining(this.server, this.botName);
         this.mode = TunnelController.Mode.WALKING;
         this.walkTicks = 0;
         return true;
      } else {
         BlockPos cell = (BlockPos)this.cells.peekFirst();
         BlockState state = level.getBlockState(cell);
         if (state.getDestroySpeed(level, cell) < 0.0F) {
            this.abort();
            return false;
         } else {
            int toolSlot = this.bestToolSlot(state);
            if (toolSlot < 0) {
               this.abort();
               return false;
            } else {
               BotCommands.stopMoving(this.server, this.botName);
               this.bot.setSprinting(false);
               Inventory inv = this.bot.getInventory();
               InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, toolSlot));
               this.faceBlock(cell);
               BotCommands.mineContinuous(this.server, this.botName);
               if (++this.cellTicks > 100) {
                  this.abort();
                  return false;
               } else {
                  return true;
               }
            }
         }
      }
   }

   private boolean tickWalking(LivingEntity target) {
      this.faceStepDirection(target);
      BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
      if (this.stepUp && this.bot.onGround()) {
         BotCommands.jumpOnce(this.server, this.botName);
      }

      if (++this.walkTicks >= 10) {
         BotCommands.stopMoving(this.server, this.botName);
         if (!this.planStep(target)) {
            if (this.bot.hasLineOfSight(target)) {
               this.reset();
               return false;
            }

            this.abort();
            return false;
         }

         this.mode = TunnelController.Mode.MINING;
      }

      return true;
   }

   private boolean planStep(LivingEntity target) {
      Level level = this.bot.level();
      BlockPos feet = this.bot.blockPosition();
      double tx = target.getX() - this.bot.getX();
      double tz = target.getZ() - this.bot.getZ();
      double dy = target.getY() - this.bot.getY();
      Direction dir = Math.abs(tx) >= Math.abs(tz) ? (tx > (double)0.0F ? Direction.EAST : Direction.WEST) : (tz > (double)0.0F ? Direction.SOUTH : Direction.NORTH);
      boolean up = dy > (double)1.5F;
      boolean down = dy < (double)-1.5F;
      this.stepUp = up;
      this.cells.clear();
      if (up) {
         this.addIfMinable(level, feet.above(2));
         this.addIfMinable(level, feet.relative(dir).above(1));
         this.addIfMinable(level, feet.relative(dir).above(2));
      } else if (down) {
         boolean straight = this.horizontal(target) < (double)1.5F;
         BlockPos drop = straight ? feet.below() : feet.relative(dir).below();
         if (lavaAt(level, drop) || lavaAt(level, drop.below())) {
            return false;
         }

         if (!straight) {
            this.addIfMinable(level, feet.relative(dir).above(1));
            this.addIfMinable(level, feet.relative(dir));
         }

         this.addIfMinable(level, drop);
      } else {
         this.addIfMinable(level, feet.relative(dir).above(1));
         this.addIfMinable(level, feet.relative(dir));
      }

      this.cellTicks = 0;
      if (this.cells.isEmpty()) {
         return false;
      } else {
         for(BlockPos c : this.cells) {
            BlockState s = level.getBlockState(c);
            if (s.getDestroySpeed(level, c) < 0.0F) {
               return false;
            }

            if (this.bestToolSlot(s) < 0) {
               return false;
            }
         }

         return true;
      }
   }

   private double horizontal(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      return Math.sqrt(dx * dx + dz * dz);
   }

   private static boolean lavaAt(Level level, BlockPos p) {
      return level.getFluidState(p).is(FluidTags.LAVA);
   }

   private void addIfMinable(Level level, BlockPos p) {
      if (this.needsMining(level, p)) {
         this.cells.addLast(p);
      }

   }

   private boolean needsMining(Level level, BlockPos p) {
      BlockState s = level.getBlockState(p);
      return !s.isAir() && !s.getCollisionShape(level, p).isEmpty();
   }

   private int bestToolSlot(BlockState state) {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      float bestSpeed = 1.0F;

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty()) {
            float sp = st.getDestroySpeed(state);
            if (sp > bestSpeed) {
               bestSpeed = sp;
               best = i;
            }
         }
      }

      return best;
   }

   private void abort() {
      this.reset();
      this.cooldown = 120;
   }

   private void faceBlock(BlockPos p) {
      Vec3 c = Vec3.atCenterOf(p);
      double dx = c.x - this.bot.getEyePosition().x;
      double dy = c.y - this.bot.getEyeY();
      double dz = c.z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, Math.max(horiz, 0.001)))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private void faceStepDirection(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      this.bot.setXRot(0.0F);
   }

   private static enum Mode {
      MINING,
      WALKING;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{MINING, WALKING};
      }
   }
}
