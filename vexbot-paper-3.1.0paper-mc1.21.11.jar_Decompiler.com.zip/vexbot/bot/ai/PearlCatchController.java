package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;
import vexbot.util.BotCommands;
import vexbot.util.ElytraFlight;
import vexbot.util.EnchantmentUtils;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.StunSlam;
import vexbot.util.SwapEngine;

public final class PearlCatchController {
   private static final int TICK_FIRE_PEARL = 1;
   private static final int TICK_FIRE_WC = 3;
   private static final int TICK_AIRBORNE = 5;
   private static final double DASH_HANDOFF_HORIZ = (double)6.0F;
   private float vPitch = -90.0F;
   private int vPearlTick = 1;
   private int vWcTick = 3;
   private int vAirborne = 5;
   private int vSettleMax = 30;
   private boolean vOffhandWc = false;
   private boolean vNoWc = false;
   private float vWallYaw = Float.NaN;
   private float vWcPitch = Float.NaN;
   private boolean vFaceTarget = false;
   private boolean vWaitForApex = false;
   private boolean apexSeen = false;
   private boolean preLaunchFired = false;
   private static final double APEX_Y_VELOCITY = 0.08;
   private static final float ANGLE_PEARL_PITCH = -55.0F;
   private static final float ANGLE_DRAG_DOWN = 20.0F;
   private static final int INSTANT_PARK_TICKS = 20;
   private static final int WALL_PROBE_DIST = 3;
   private static final int WALL_MIN_HEIGHT = 4;
   private boolean vPreLaunch = false;
   private static final int PRELAUNCH_TICK = 1;
   private static final int WC_COOLDOWN_TICKS = 11;
   private static final float PRELAUNCH_PITCH = 80.0F;
   private static final double TRIGGER_RANGE = (double)7.0F;
   private static final double MIN_FALL_DIST = (double)1.5F;
   private static final int MAX_AIRBORNE_TICKS = 100;
   private static final int MAX_LAUNCH_TICKS = 40;
   private static final int WC_RETRY_TICKS = 14;
   private static final int MAX_SMASH_TICKS = 40;
   private static final double GLIDE_ENTER_HORIZ = (double)4.5F;
   private static final double GLIDE_EXIT_HORIZ = (double)3.0F;
   private static final int GLIDE_MAX_TICKS = 200;
   private static final int COOLDOWN_TICKS = 60;
   private static final int SETTLE_MAX = 30;
   private LivingEntity catchTarget = null;
   private Phase phase;
   private int phaseTick;
   private int cooldownLeft;
   private boolean settled;
   private boolean wcFired;
   private boolean pearlFired;
   private int settleTicks;
   private int prevSlot;
   private int chestStashSlot;
   private int maceSlot;
   private int windChargeSlot;
   private int pearlSlot;
   private final StunSlam stunSlam;
   private final ServerPlayer bot;
   private final MinecraftServer server;

   private double attackRange() {
      return EffectiveSettings.of(this.bot.getScoreboardName()).attackRange();
   }

   private boolean throwsDone() {
      return this.pearlFired && (this.wcFired || this.vNoWc);
   }

   public PearlCatchController(ServerPlayer bot, MinecraftServer server) {
      this.phase = PearlCatchController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldownLeft = 0;
      this.settled = false;
      this.wcFired = false;
      this.pearlFired = false;
      this.settleTicks = 0;
      this.prevSlot = 0;
      this.chestStashSlot = -1;
      this.maceSlot = -1;
      this.windChargeSlot = -1;
      this.pearlSlot = -1;
      this.stunSlam = new StunSlam();
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldownLeft > 0) {
         --this.cooldownLeft;
      }

      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target, dist);
         case 1 -> var10000 = this.tickLaunching();
         case 2 -> var10000 = this.tickAirborne(target);
         case 3 -> var10000 = this.tickGliding(target);
         case 4 -> var10000 = this.tickSmashing(target);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public boolean isExecuting() {
      return this.phase != PearlCatchController.Phase.IDLE;
   }

   public void reset() {
      if (this.vOffhandWc) {
         OffhandManager.unpark(this.bot);
         this.vOffhandWc = false;
      }

      if (this.phase != PearlCatchController.Phase.IDLE) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.unequipElytra();
      this.phase = PearlCatchController.Phase.IDLE;
      this.phaseTick = 0;
      this.catchTarget = null;
   }

   private boolean tickIdle(LivingEntity target, double dist) {
      if (target != null && target.isAlive()) {
         if (this.cooldownLeft > 0) {
            return false;
         } else if (!this.bot.onGround()) {
            return false;
         } else if (dist > (double)7.0F) {
            return false;
         } else if (!EffectiveSettings.of(this.bot.getScoreboardName()).usePearlCatch()) {
            return false;
         } else if (this.bot.getCooldowns().isOnCooldown(new ItemStack(Items.WIND_CHARGE))) {
            return false;
         } else if (this.bot.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))) {
            return false;
         } else {
            this.maceSlot = this.findMaceSlot();
            this.windChargeSlot = this.findWindChargeSlot();
            this.pearlSlot = this.findPearlSlot();
            if (this.maceSlot >= 0 && this.windChargeSlot >= 0 && this.pearlSlot >= 0) {
               if (this.pearlSlot >= 9) {
                  this.pearlSlot = InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), this.pearlSlot);
                  this.windChargeSlot = this.findWindChargeSlot();
                  if (this.windChargeSlot < 0 || this.windChargeSlot == this.pearlSlot) {
                     return false;
                  }
               }

               this.prevSlot = this.bot.getInventory().getSelectedSlot();
               this.settled = false;
               this.settleTicks = 0;
               this.wcFired = false;
               this.pearlFired = false;
               this.preLaunchFired = false;
               this.catchTarget = target;
               this.resolveVariant(target);
               this.enterPhase(PearlCatchController.Phase.LAUNCHING);
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private boolean hasSpearDashKit() {
      Inventory inv = this.bot.getInventory();
      boolean spear = false;
      boolean wbMace = false;

      for(int i = 0; i < 9; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty()) {
            if (!spear && st.get(DataComponents.PIERCING_WEAPON) != null && EnchantmentUtils.getEnchantLevel(st, "lunge") >= 1) {
               spear = true;
            }

            if (!wbMace && st.is(Items.MACE) && EnchantmentUtils.getEnchantLevel(st, "wind_burst") >= 1) {
               wbMace = true;
            }
         }
      }

      return spear && wbMace;
   }

   private void resolveVariant(LivingEntity target) {
      TechniqueConfig cfg = EffectiveSettings.of(this.bot.getScoreboardName()).techniques();
      this.vPitch = -90.0F;
      this.vPearlTick = 1;
      this.vWcTick = 3;
      this.vAirborne = 5;
      this.vSettleMax = 30;
      this.vOffhandWc = false;
      this.vNoWc = false;
      this.vPreLaunch = false;
      this.vWallYaw = Float.NaN;
      this.vWcPitch = Float.NaN;
      this.vFaceTarget = false;
      this.vWaitForApex = false;
      this.apexSeen = false;
      TechniqueConfig.PearlCatchVariant setting = EffectiveSettings.of(this.bot.getScoreboardName()).pearlCatchType();
      TechniqueConfig.PearlCatchVariant type = setting;
      if (setting == TechniqueConfig.PearlCatchVariant.SMART) {
         double horiz = Math.hypot(target.getX() - this.bot.getX(), target.getZ() - this.bot.getZ());
         if (horiz <= (double)2.0F && target.onGround()) {
            type = TechniqueConfig.PearlCatchVariant.STANDARD;
         } else if (horiz >= (double)6.0F) {
            type = TechniqueConfig.PearlCatchVariant.ANGLE;
         } else {
            type = TechniqueConfig.PearlCatchVariant.HIGHER;
         }
      }

      float wallYaw = this.probeWallYaw();
      if (Float.isNaN(wallYaw) || setting != TechniqueConfig.PearlCatchVariant.STANDARD && setting != TechniqueConfig.PearlCatchVariant.SMART) {
         switch (type) {
            case HIGHER:
               this.vPreLaunch = true;
               this.vWaitForApex = true;
               this.vPearlTick = 5;
               this.vWcTick = Math.max(this.vPearlTick + 4, 12);
               this.vAirborne = this.vWcTick + 3;
               break;
            case INSTANT:
               this.vOffhandWc = OffhandManager.park(this.bot, this.windChargeSlot, 20);
               this.vPearlTick = 1;
               this.vWcTick = 2;
               this.vAirborne = 4;
               this.vSettleMax = 2;
               break;
            case ANGLE:
               this.vPitch = -55.0F;
               this.vWcPitch = -35.0F;
               this.vFaceTarget = true;
               this.vPearlTick = 1;
               this.vWcTick = 4;
               this.vAirborne = this.vWcTick + 3;
         }

      } else {
         this.vWallYaw = wallYaw;
         this.vPitch = -45.0F;
         this.vNoWc = true;
         this.vAirborne = 14;
      }
   }

   private void holdForSequence() {
      int want;
      if (this.vPreLaunch && !this.preLaunchFired) {
         want = this.windChargeSlot;
      } else if (!this.pearlFired) {
         want = this.pearlSlot;
      } else if (!this.wcFired && !this.vNoWc && !this.vOffhandWc) {
         want = this.windChargeSlot;
      } else {
         want = this.maceSlot;
      }

      if (want >= 0 && want <= 8) {
         Inventory inv = this.bot.getInventory();
         if (InventoryUtils.selected(inv) != want) {
            InventoryUtils.select(inv, want);
            EquipmentSync.syncNow(this.bot);
         }

      }
   }

   private float yawTo(Entity e) {
      return (float)Math.toDegrees(Math.atan2(-(e.getX() - this.bot.getX()), e.getZ() - this.bot.getZ()));
   }

   private float probeWallYaw() {
      ServerLevel level = this.bot.level();
      BlockPos feet = this.bot.blockPosition();
      float best = Float.NaN;
      int bestDist = Integer.MAX_VALUE;

      for(int i = 0; i < 8; ++i) {
         double ang = (double)i * (Math.PI / 4D);
         double dx = -Math.sin(ang);
         double dz = Math.cos(ang);

         for(int d = 1; d <= 3; ++d) {
            BlockPos at = feet.offset((int)Math.round(dx * (double)d), 1, (int)Math.round(dz * (double)d));
            if (this.isWallBlock(at)) {
               boolean tall = true;

               for(int h = 1; h < 4; ++h) {
                  if (!this.isWallBlock(at.above(h))) {
                     tall = false;
                     break;
                  }
               }

               if (tall && d < bestDist) {
                  bestDist = d;
                  best = (float)Math.toDegrees(ang);
               }
               break;
            }
         }
      }

      return best;
   }

   private boolean isWallBlock(BlockPos pos) {
      ServerLevel level = this.bot.level();
      return level.getBlockState(pos).isFaceSturdy(level, pos, Direction.UP);
   }

   private boolean tickLaunching() {
      String name = this.bot.getScoreboardName();
      if (this.phaseTick > 40) {
         VexBot.LOGGER.debug("[PearlCatch] {} launch timed out — back to fighting", name);
         this.abort();
         return false;
      } else {
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
         BotCommands.stopLookInterpolation(this.server, name);
         float pitchNow = this.vPitch;
         if (this.vPreLaunch && this.settled && this.phaseTick <= 1) {
            pitchNow = 80.0F;
         } else if (!Float.isNaN(this.vWcPitch) && this.settled && this.phaseTick >= this.vWcTick) {
            pitchNow = this.vWcPitch;
         }

         this.bot.setXRot(pitchNow);
         if (!Float.isNaN(this.vWallYaw)) {
            this.bot.setYRot(this.vWallYaw);
         }

         if (this.vFaceTarget && this.catchTarget != null) {
            this.bot.setYRot(this.yawTo(this.catchTarget));
         }

         this.bot.setYHeadRot(this.bot.getYRot());
         this.bot.setYBodyRot(this.bot.getYRot());
         this.holdForSequence();
         if (!this.settled) {
            this.bot.setDeltaMovement((double)0.0F, this.bot.getDeltaMovement().y, (double)0.0F);
            double hSpeed = Math.hypot(this.bot.getDeltaMovement().x, this.bot.getDeltaMovement().z);
            if (this.bot.onGround() && hSpeed < 0.03 || ++this.settleTicks >= this.vSettleMax) {
               this.settled = true;
               this.phaseTick = 0;
            }

            return true;
         } else {
            ++this.phaseTick;
            if (this.vPreLaunch && this.phaseTick == 1) {
               SwapEngine.sameTickJumpAndWc(this.server, this.bot, this.windChargeSlot);
               this.preLaunchFired = true;
               return true;
            } else {
               if (this.vWaitForApex && !this.apexSeen && this.phaseTick > 1) {
                  boolean rising = this.bot.getDeltaMovement().y > 0.08;
                  if (rising) {
                     return true;
                  }

                  this.apexSeen = true;
                  this.vPearlTick = this.phaseTick;
                  int cdClear = 12;
                  this.vWcTick = Math.max(this.phaseTick + 1, cdClear);
                  this.vAirborne = this.vWcTick + 3;
               }

               if (!this.throwsDone()) {
                  this.bot.setDeltaMovement((double)0.0F, this.bot.getDeltaMovement().y, (double)0.0F);
               }

               if (this.phaseTick == this.vPearlTick && !this.pearlFired) {
                  InventoryUtils.select(this.bot.getInventory(), this.pearlSlot);
                  ItemStack pearl = this.bot.getMainHandItem();
                  if (pearl.is(Items.ENDER_PEARL)) {
                     try {
                        this.bot.gameMode.useItem(this.bot, this.bot.level(), pearl, InteractionHand.MAIN_HAND);
                        this.pearlFired = true;
                     } catch (Exception var8) {
                     }
                  }
               }

               if (this.phaseTick >= this.vWcTick && !this.vNoWc && !this.wcFired) {
                  float wcPitch = Float.isNaN(this.vWcPitch) ? this.vPitch : this.vWcPitch;
                  if (this.vOffhandWc) {
                     ItemStack wc = this.bot.getOffhandItem();
                     if (wc.is(Items.WIND_CHARGE)) {
                        ServerLevel var6 = this.bot.level();
                        if (var6 instanceof ServerLevel) {
                           ServerLevel level = var6;

                           try {
                              this.bot.gameMode.useItem(this.bot, level, wc, InteractionHand.OFF_HAND);
                              this.wcFired = true;
                           } catch (Exception var7) {
                           }
                        }
                     }
                  } else if (SwapEngine.fireWindChargeSelf(this.bot, this.windChargeSlot, wcPitch)) {
                     this.wcFired = true;
                  }

                  if (!this.wcFired && this.phaseTick < this.vWcTick + 14) {
                     this.vAirborne = Math.max(this.vAirborne, this.phaseTick + 3);
                  } else if (!this.wcFired) {
                     VexBot.LOGGER.debug("[PearlCatch] {} charge never fired — riding the pearl alone", name);
                     this.vAirborne = this.phaseTick;
                  }
               }

               if (this.phaseTick >= this.vAirborne && this.throwsDone()) {
                  InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                  if (this.vOffhandWc) {
                     OffhandManager.unpark(this.bot);
                     this.vOffhandWc = false;
                  }

                  this.enterPhase(PearlCatchController.Phase.AIRBORNE);
               }

               return true;
            }
         }
      }
   }

   private boolean tickAirborne(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 100) {
            this.abort();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.faceTarget(target);
            this.driftToward(target);
            boolean falling = this.bot.getDeltaMovement().y < -0.05 && this.phaseTick > 10;
            if (falling) {
               double hd = this.horizDist(target);
               if (hd > (double)4.5F && EffectiveSettings.of(this.bot.getScoreboardName()).elytraGlide() && this.equipElytra()) {
                  ElytraFlight.beginGlide(this.bot);
                  this.enterPhase(PearlCatchController.Phase.GLIDING);
               } else {
                  if (hd > (double)6.0F && !this.bot.isFallFlying() && EffectiveSettings.of(this.bot.getScoreboardName()).techniques().spearMacing && this.hasSpearDashKit()) {
                     InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                     this.cooldownLeft = 60;
                     this.enterPhase(PearlCatchController.Phase.IDLE);
                     return false;
                  }

                  this.enterPhase(PearlCatchController.Phase.SMASHING);
               }
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickGliding(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 200) {
            this.unequipElytra();
            this.abort();
            return false;
         } else if (this.bot.onGround() && this.phaseTick > 5) {
            this.unequipElytra();
            this.abort();
            return false;
         } else {
            ElytraFlight.beginGlide(this.bot);
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.faceTarget(target);
            Vec3 v = this.bot.getDeltaMovement();
            double dx = target.getX() - this.bot.getX();
            double dz = target.getZ() - this.bot.getZ();
            double hd = Math.sqrt(dx * dx + dz * dz);
            if (hd > (double)0.5F) {
               double speed = Math.max(0.4, Math.hypot(v.x, v.z));
               double nx = dx / hd * speed;
               double nz = dz / hd * speed;
               this.bot.setDeltaMovement(v.x * 0.6 + nx * 0.4, v.y, v.z * 0.6 + nz * 0.4);
            }

            if (hd <= (double)3.0F && this.bot.getY() > target.getY() + (double)2.0F) {
               this.unequipElytra();
               this.enterPhase(PearlCatchController.Phase.SMASHING);
            }

            return true;
         }
      } else {
         this.unequipElytra();
         this.abort();
         return false;
      }
   }

   private boolean tickSmashing(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 40) {
            this.abort();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.faceTarget(target);
            this.driftToward(target);
            double dist = (double)this.bot.distanceTo(target);
            boolean inRange = dist <= this.attackRange();
            boolean hasFall = this.bot.fallDistance > (double)1.5F && MaceSmashGates.botMayUseSmashFallBonus(this.bot);
            boolean landed = this.bot.onGround() && this.phaseTick > 3;
            if (inRange && hasFall) {
               if (!this.bot.hasLineOfSight(target)) {
                  if (landed) {
                     this.abort();
                     return false;
                  } else {
                     return true;
                  }
               } else {
                  this.bot.setSprinting(true);
                  EffectiveSettings ssEffs = EffectiveSettings.of(this.bot.getScoreboardName());
                  TechniqueConfig ssCfg = ssEffs.techniques();
                  StunSlam.Result ssRes = this.stunSlam.tick(this.bot, target, this.findAxeSlot(), this.maceSlot, ssCfg.stunSlamVariant, ssCfg.stunSlam, ssEffs);
                  if (ssRes == StunSlam.Result.HOLD) {
                     return true;
                  } else {
                     if (ssRes != StunSlam.Result.SMASHED) {
                        InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                        EquipmentSync.syncNow(this.bot);
                        this.bot.attack(target);
                        McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                     }

                     InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
                     this.cooldownLeft = 60;
                     this.enterPhase(PearlCatchController.Phase.IDLE);
                     return false;
                  }
               }
            } else if (landed) {
               this.abort();
               return false;
            } else {
               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private void enterPhase(Phase p) {
      this.phase = p;
      this.phaseTick = 0;
   }

   private void abort() {
      this.unequipElytra();
      InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      this.cooldownLeft = 30;
      this.enterPhase(PearlCatchController.Phase.IDLE);
   }

   private int findMaceSlot() {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestS = (double)-1.0F;

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.MACE)) {
            double score = ItemEvaluator.scoreMace(s);
            if (score > bestS) {
               bestS = score;
               best = i;
            }
         }
      }

      return best;
   }

   private int findWindChargeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.WIND_CHARGE)) {
            return i;
         }
      }

      return -1;
   }

   private int findPearlSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.ENDER_PEARL)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(Items.ENDER_PEARL)) {
            return i;
         }
      }

      return -1;
   }

   private int findAxeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.AXES)) {
            return i;
         }
      }

      return -1;
   }

   private double horizDist(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      return Math.sqrt(dx * dx + dz * dz);
   }

   private boolean isUsableElytra(ItemStack s) {
      return s.is(Items.ELYTRA) && s.getDamageValue() < s.getMaxDamage() - 1;
   }

   private boolean equipElytra() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (this.isUsableElytra(chest)) {
         return true;
      } else {
         Inventory inv = this.bot.getInventory();

         for(int i = 0; i < 36; ++i) {
            ItemStack s = inv.getItem(i);
            if (this.isUsableElytra(s)) {
               ItemStack elytra = s.copy();
               inv.setItem(i, chest.copy());
               this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
               this.chestStashSlot = i;
               return true;
            }
         }

         return false;
      }
   }

   private void unequipElytra() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (chest.is(Items.ELYTRA)) {
         Inventory inv = this.bot.getInventory();
         if (this.chestStashSlot >= 0 && this.chestStashSlot < 36) {
            ItemStack stashed = inv.getItem(this.chestStashSlot).copy();
            inv.setItem(this.chestStashSlot, chest.copy());
            this.bot.setItemSlot(EquipmentSlot.CHEST, stashed);
         } else {
            for(int i = 0; i < 36; ++i) {
               if (inv.getItem(i).isEmpty()) {
                  inv.setItem(i, chest.copy());
                  this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                  break;
               }
            }
         }

         this.chestStashSlot = -1;
      }
   }

   private void faceTarget(LivingEntity target) {
      double dx = target.getX() - this.bot.getEyePosition().x;
      double dy = target.getY() - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void driftToward(LivingEntity target) {
      String name = this.bot.getScoreboardName();
      double dist = (double)this.bot.distanceTo(target);
      if (dist > (double)1.5F) {
         BotCommands.moveForward(this.server, name);
         this.bot.setSprinting(dist > (double)3.0F);
      } else {
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
      }

   }

   private static enum Phase {
      IDLE,
      LAUNCHING,
      AIRBORNE,
      GLIDING,
      SMASHING;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, LAUNCHING, AIRBORNE, GLIDING, SMASHING};
      }
   }
}
