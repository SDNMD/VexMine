package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import vexbot.EffectiveSettings;

public final class AxeController {
   private static final int SHIELD_PUNISH_TICKS = 30;
   private static final Random RNG = new Random();
   private final ServerPlayer bot;
   private final String botName;
   private int shieldReactionCountdown = -1;
   private int shieldPunishWindow = 0;

   public AxeController(ServerPlayer bot) {
      this.bot = bot;
      this.botName = bot.getScoreboardName();
   }

   public boolean tickSeesShield(LivingEntity target) {
      boolean targetBlocking = target != null && target.isBlocking();
      if (!targetBlocking) {
         this.shieldReactionCountdown = -1;
      } else if (this.shieldReactionCountdown < 0) {
         this.shieldReactionCountdown = this.rollShieldReactionDelay();
      } else if (this.shieldReactionCountdown > 0) {
         --this.shieldReactionCountdown;
      }

      return targetBlocking && this.shieldReactionCountdown == 0;
   }

   public void tickWindows() {
      if (this.shieldPunishWindow > 0) {
         --this.shieldPunishWindow;
      }

   }

   public boolean shouldDisableNow(float charge, EffectiveSettings es) {
      return charge >= (float)es.difficultyParams().shieldDisableCharge;
   }

   public boolean seesShieldNow() {
      return this.shieldReactionCountdown == 0;
   }

   public void onDisableSwung() {
      this.shieldPunishWindow = 30;
   }

   public boolean punishActive() {
      return this.shieldPunishWindow > 0;
   }

   public void reset() {
      this.shieldReactionCountdown = -1;
      this.shieldPunishWindow = 0;
   }

   private int rollShieldReactionDelay() {
      return EffectiveSettings.of(this.botName).difficultyParams().rollShieldReactionTicks(RNG);
   }
}
