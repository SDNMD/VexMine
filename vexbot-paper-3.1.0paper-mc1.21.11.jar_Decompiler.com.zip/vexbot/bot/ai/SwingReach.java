package vexbot.bot.ai;

import java.util.Random;

final class SwingReach {
   private static final double STEP = 0.1;
   private final Random rng = new Random();
   private double current = (double)-1.0F;
   private float lastCharge = 0.0F;

   void tick(float charge, double maxReach, int flips) {
      if (this.current < (double)0.0F || charge < this.lastCharge) {
         this.resample(maxReach, flips);
      }

      this.lastCharge = charge;
   }

   private void resample(double maxReach, int flips) {
      if (flips <= 0) {
         this.current = maxReach;
      } else {
         int hits = 0;

         for(int i = 0; i < flips; ++i) {
            if (this.rng.nextBoolean()) {
               ++hits;
            }
         }

         double min = Math.max((double)0.5F, maxReach - (double)flips * 0.1);
         this.current = Math.min(maxReach, min + (double)hits * 0.1);
      }
   }

   double get(double maxReach) {
      return this.current < (double)0.0F ? maxReach : Math.min(this.current, maxReach);
   }
}
