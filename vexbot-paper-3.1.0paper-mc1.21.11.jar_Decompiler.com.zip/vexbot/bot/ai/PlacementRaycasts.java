package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public final class PlacementRaycasts {
   private PlacementRaycasts() {
   }

   public static boolean canSeePlacement(ServerPlayer bot, BlockPos pos) {
      ServerLevel var3 = bot.level();
      if (var3 instanceof ServerLevel) {
         ServerLevel sl = var3;
         Vec3 var7 = bot.getEyePosition();
         Vec3 to = Vec3.atCenterOf(pos);
         BlockHitResult hit = sl.clip(new ClipContext(var7, to, Block.COLLIDER, Fluid.NONE, bot));
         if (hit.getType() != Type.BLOCK) {
            return true;
         } else {
            BlockPos blocked = hit.getBlockPos();
            return blocked.equals(pos) || blocked.equals(pos.below());
         }
      } else {
         return false;
      }
   }
}
