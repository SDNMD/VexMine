package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;

public final class MaceSmashGates {
   private MaceSmashGates() {
   }

   public static boolean botMayUseSmashFallBonus(ServerPlayer bot) {
      return !bot.hasEffect(MobEffects.SLOW_FALLING);
   }
}
