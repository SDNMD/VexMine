package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import vexbot.EffectiveSettings;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;
import vexbot.util.WebDetect;

public final class ChorusEscapeController {
   private static final int BOX_SIDES = 3;
   private static final int EAT_WINDUP = 16;
   private static final int COOLDOWN = 60;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private boolean eating = false;
   private int eatTicks = 0;
   private int cooldown = 0;

   public ChorusEscapeController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public void reset() {
      if (this.eating && this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      this.eating = false;
      this.eatTicks = 0;
   }

   public boolean tick() {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.eating) {
         BotCommands.stopMoving(this.server, this.botName);
         if (++this.eatTicks >= 16) {
            ItemStack held = this.bot.getMainHandItem();
            if (held.is(Items.CHORUS_FRUIT)) {
               try {
                  held.finishUsingItem(this.bot.level(), this.bot);
               } catch (Exception var3) {
                  held.shrink(1);
               }
            }

            if (this.bot.isUsingItem()) {
               this.bot.stopUsingItem();
            }

            this.eating = false;
            this.eatTicks = 0;
            this.cooldown = 60;
            return false;
         } else {
            if (!this.bot.isUsingItem()) {
               this.bot.gameMode.useItem(this.bot, this.bot.level(), this.bot.getMainHandItem(), InteractionHand.MAIN_HAND);
            }

            return true;
         }
      } else if (this.cooldown > 0) {
         return false;
      } else if (!EffectiveSettings.of(this.botName).chorusEscape()) {
         return false;
      } else if (!this.isTrapped()) {
         return false;
      } else {
         int slot = this.findChorusSlot();
         if (slot < 0) {
            return false;
         } else {
            Inventory inv = this.bot.getInventory();
            InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, slot));
            BotCommands.stopMoving(this.server, this.botName);
            if (this.bot.isUsingItem()) {
               this.bot.stopUsingItem();
            }

            this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getSelectedItem(), InteractionHand.MAIN_HAND);
            this.eating = true;
            this.eatTicks = 0;
            return true;
         }
      }
   }

   private boolean isTrapped() {
      Level level = this.bot.level();
      BlockPos feet = this.bot.blockPosition();
      if (!WebDetect.touchingWeb(this.bot)) {
         return false;
      } else {
         int blocked = 0;

         for(BlockPos n : new BlockPos[]{feet.north(), feet.south(), feet.east(), feet.west()}) {
            if (isSolid(level, n) || isSolid(level, n.above())) {
               ++blocked;
            }
         }

         return blocked >= 3;
      }
   }

   private static boolean isSolid(Level level, BlockPos p) {
      return !level.getBlockState(p).getCollisionShape(level, p).isEmpty();
   }

   private int findChorusSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.CHORUS_FRUIT)) {
            return i;
         }
      }

      return -1;
   }
}
