package vexbot.bot.ai;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResult.SwingSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.vehicle.minecart.MinecartTNT;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;
import vexbot.util.VexLog;

public final class CartController {
   private static final double CART_MIN_RANGE = (double)1.5F;
   private static final double CART_MAX_RANGE = (double)20.0F;
   private static final double CART_CHASE_RANGE = (double)30.0F;
   private static final double VANILLA_PLACE_REACH = (double)4.5F;
   private static final double CART_TARGET_MAX = (double)2.5F;
   private static final double CART_SELF_MIN = (double)3.0F;
   private static final int COOLDOWN_TICKS = 3;
   private static final int BOW_DRAW_TICKS = 7;
   private static final int BOW_DRAW_MIN = 4;
   private static final int BOW_DRAW_MAX = 12;
   private static final float MIN_HEALTH = 6.0F;
   private static final int MAX_EXECUTE_TICKS = 102;
   private static final int XBOW_LOAD_TICKS = 30;
   private static final int XBOW_POST_FIRE_WAIT = 8;
   private static final int XBOW_TICK_RAIL_EQUIP = 1;
   private static final int XBOW_TICK_RAIL = 2;
   private static final int XBOW_TICK_CART = 4;
   private static final int XBOW_TICK_FLINT_EQUIP = 8;
   private static final int XBOW_TICK_FIRE = 9;
   private static final int XBOW_TICK_SHOOT = 12;
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-Cart");
   private static final Random RNG = new Random();
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private Phase phase;
   private int phaseTick;
   private int cooldownLeft;
   private BotSettings.CartMode activeType;
   private BlockPos railPos;
   private BlockPos firePos;
   private int prevSlot;
   private int railSlot;
   private int cartSlot;
   private int flameBowSlot;
   private int crossbowSlot;
   private int sincePearl;
   private int sinceCartMiss;
   private CartDoctrine.Reason lastReason;
   private Vec3 lastTargetPos;
   private int lastTargetId;
   private boolean sawPrimedEnemyCart;
   private final ArrayDeque<UUID> ownCarts;
   private boolean offhandCart;
   private int cartMissScanTick;
   private boolean instaRetried;
   private boolean instaRecovery;
   private int lastFiredCrossbowSlot;
   private int flintSlot;
   private boolean isDrawing;
   private MinecartTNT spawnedCart;
   private boolean xbowFired;
   private int xbowPostFireWait;
   private boolean xbowFireRetried;
   private boolean xbowCharging;
   private int xbowChargeTicks;
   private BlockPos railPosLeft;
   private BlockPos railPosRight;
   private MinecartTNT spawnedCartLeft;
   private MinecartTNT spawnedCartRight;
   private String lastBail;
   private static final double INCOMING_CART_RANGE = (double)9.0F;
   private static final int DEFENCE_COOLDOWN = 10;
   private static final int DEFENCE_IDLE_RECHECK = 4;
   private int defenceCooldown;
   private static final int GRAB_DELAY_TICKS = 6;
   private int pendingGrabDelay;

   public CartController(ServerPlayer bot, MinecraftServer server) {
      this.phase = CartController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldownLeft = 0;
      this.activeType = null;
      this.railPos = null;
      this.firePos = null;
      this.prevSlot = 0;
      this.railSlot = -1;
      this.cartSlot = -1;
      this.flameBowSlot = -1;
      this.crossbowSlot = -1;
      this.sincePearl = 9999;
      this.sinceCartMiss = 9999;
      this.lastReason = CartDoctrine.Reason.NONE;
      this.lastTargetPos = null;
      this.lastTargetId = -1;
      this.sawPrimedEnemyCart = false;
      this.ownCarts = new ArrayDeque();
      this.offhandCart = false;
      this.cartMissScanTick = 0;
      this.instaRetried = false;
      this.instaRecovery = false;
      this.lastFiredCrossbowSlot = -1;
      this.flintSlot = -1;
      this.isDrawing = false;
      this.spawnedCart = null;
      this.xbowFired = false;
      this.xbowPostFireWait = 0;
      this.xbowFireRetried = false;
      this.xbowCharging = false;
      this.xbowChargeTicks = 0;
      this.railPosLeft = null;
      this.railPosRight = null;
      this.spawnedCartLeft = null;
      this.spawnedCartRight = null;
      this.lastBail = "";
      this.defenceCooldown = 0;
      this.pendingGrabDelay = 0;
      this.bot = bot;
      this.server = server;
   }

   public boolean isExecuting() {
      return this.phase == CartController.Phase.EXECUTING;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldownLeft > 0) {
         --this.cooldownLeft;
      }

      if (this.defenceCooldown > 0) {
         --this.defenceCooldown;
      }

      this.observeTarget(target, dist);
      this.ensureCartHotbar();
      this.defendAgainstIncomingCart();
      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target, dist);
         case 1 -> var10000 = this.tickExecuting(target);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private void observeTarget(LivingEntity target, double dist) {
      if (this.sincePearl < 9999) {
         ++this.sincePearl;
      }

      if (this.sinceCartMiss < 9999) {
         ++this.sinceCartMiss;
      }

      if (target == null) {
         this.lastTargetPos = null;
      } else {
         if (target.getId() != this.lastTargetId) {
            this.lastTargetId = target.getId();
            this.lastTargetPos = null;
            this.sincePearl = 9999;
            this.sinceCartMiss = 9999;
            this.sawPrimedEnemyCart = false;
         }

         if (this.lastTargetPos != null) {
            double jump = target.position().distanceTo(this.lastTargetPos);
            if (jump > (double)8.0F && dist > (double)1.5F) {
               this.sincePearl = 0;
            }
         }

         this.lastTargetPos = target.position();
         ServerLevel sl = this.bot.level();
         if (sl instanceof ServerLevel) {
            if (this.cartMissScanTick++ % 5 == 0) {
               boolean primedNear = !sl.getEntitiesOfClass(MinecartTNT.class, target.getBoundingBox().inflate((double)6.0F), (m) -> m.isPrimed() && !this.ownCarts.contains(m.getUUID())).isEmpty();
               if (primedNear) {
                  this.sawPrimedEnemyCart = true;
               } else if (this.sawPrimedEnemyCart) {
                  this.sawPrimedEnemyCart = false;
                  if (this.bot.hurtTime == 0) {
                     this.sinceCartMiss = 0;
                  }
               }

            }
         }
      }
   }

   public boolean wantsToChaseForCart(LivingEntity target, double dist) {
      if (this.phase != CartController.Phase.IDLE) {
         return false;
      } else if (this.cooldownLeft > 0) {
         return false;
      } else if (target != null && target.isAlive()) {
         if (this.bot.getHealth() < 6.0F) {
            return false;
         } else if (!(dist <= (double)6.5F) && !(dist > (double)30.0F)) {
            EffectiveSettings es = EffectiveSettings.of(this.bot.getScoreboardName());
            if (!es.useCarting()) {
               return false;
            } else {
               return this.findRailInInventory() >= 0 && this.findInInventory(Items.TNT_MINECART) >= 0 && (this.findFlameBowInHotbar() >= 0 || this.hasAnyCrossbow() && this.hasArrows());
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void reset() {
      if (this.phase != CartController.Phase.IDLE) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
         if (this.isDrawing) {
            this.bot.stopUsingItem();
            this.isDrawing = false;
         }

         if (this.xbowCharging && this.bot.isUsingItem()) {
            this.bot.stopUsingItem();
         }
      }

      this.phase = CartController.Phase.IDLE;
      this.phaseTick = 0;
      this.instaRetried = false;
      this.instaRecovery = false;
      this.offhandCart = false;
      this.lastTargetPos = null;
      this.spawnedCart = null;
      this.spawnedCartLeft = null;
      this.spawnedCartRight = null;
      this.clearXbowCartState();
   }

   private boolean aboutToLand() {
      if (this.bot.getDeltaMovement().y > 0.1) {
         return false;
      } else {
         return !this.bot.level().noCollision(this.bot.getBoundingBox().move((double)0.0F, -1.2, (double)0.0F));
      }
   }

   private boolean bail(String reason) {
      int sp = reason.indexOf(32);
      int kindLen = sp < 0 ? reason.length() : sp;
      if (kindLen != this.lastBail.length() || !reason.startsWith(this.lastBail)) {
         this.lastBail = reason.substring(0, kindLen);
         VexLog.detail(LOGGER, "[Cart] {} no cart: {}", this.bot.getScoreboardName(), reason);
      }

      return false;
   }

   private boolean repeatBail(String kind) {
      return this.lastBail.equals(kind);
   }

   private double cartSelfMin() {
      return !CartDoctrine.isGuideDoctrine(this.bot.getScoreboardName()) ? (double)3.0F : Math.max((double)3.0F, CartDoctrine.selfMinDistance(this.bot, this.lastReason));
   }

   private boolean tickIdle(LivingEntity target, double dist) {
      if (target != null && target.isAlive()) {
         if (this.cooldownLeft > 0) {
            return this.repeatBail("cooldown") ? false : this.bail("cooldown " + this.cooldownLeft);
         } else if (this.bot.getHealth() < 6.0F) {
            return this.repeatBail("hp") ? false : this.bail("hp " + this.bot.getHealth());
         } else if (!(dist < (double)1.5F) && !(dist > (double)20.0F)) {
            if (!this.bot.onGround() && !this.aboutToLand()) {
               return this.bail("airborne");
            } else {
               EffectiveSettings es = EffectiveSettings.of(this.bot.getScoreboardName());
               if (!es.useCarting()) {
                  return this.bail("carting off");
               } else {
                  CartDoctrine.Reason why = CartDoctrine.shouldCart(this.bot, target, dist, this.sincePearl, this.sinceCartMiss);
                  if (why == CartDoctrine.Reason.NONE) {
                     return this.bail("doctrine");
                  } else if (why != CartDoctrine.Reason.RELENTLESS && !CartDoctrine.selfDamageOk(this.bot, target, why)) {
                     return this.bail("selfdamage");
                  } else {
                     this.lastReason = why;
                     if (why != CartDoctrine.Reason.FINISH && this.skipThisCart()) {
                        this.cooldownLeft = this.cartCooldown();
                        return false;
                     } else {
                        this.railSlot = this.findRailInInventory();
                        this.cartSlot = this.findInInventory(Items.TNT_MINECART);
                        if (this.railSlot >= 0 && this.cartSlot >= 0) {
                           this.flameBowSlot = this.findFlameBowInHotbar();
                           int chained = this.findChargedCrossbowExcluding(this.lastFiredCrossbowSlot);
                           if (chained < 0) {
                              chained = this.findChargedCrossbowExcluding(-1);
                           }

                           this.crossbowSlot = chained >= 0 ? chained : this.findCrossbowForCart();
                           this.flintSlot = this.findInInventory(Items.FLINT_AND_STEEL);
                           BotSettings.CartMode mode = es.cartMode();
                           if (mode == BotSettings.CartMode.SMART) {
                              mode = this.pickSmartMode(target, dist);
                           }

                           if (!this.hasItemsForType(mode)) {
                              boolean var8;
                              if (this.repeatBail("no")) {
                                 var8 = false;
                              } else {
                                 String var10001 = String.valueOf(mode);
                                 var8 = this.bail("no items for " + var10001 + " bow=" + this.flameBowSlot + " xbow=" + this.crossbowSlot + " flint=" + this.flintSlot);
                              }

                              return var8;
                           } else {
                              this.railPos = this.findPlacementPos(target);
                              if (this.railPos == null) {
                                 return this.bail("no placement spot");
                              } else {
                                 if (mode == BotSettings.CartMode.XBOW_CART) {
                                    this.firePos = this.findFirePosAlongShotPath(Vec3.atCenterOf(this.railPos).add((double)0.0F, 0.15, (double)0.0F));
                                    if (this.firePos == null) {
                                       return this.bail("no fire spot");
                                    }
                                 }

                                 VexLog.detail(LOGGER, "[Cart] {} starting {} cart at dist={} railPos={} because={}", this.bot.getScoreboardName(), mode, String.format("%.1f", dist), this.railPos, this.lastReason);
                                 this.lastBail = "";
                                 this.activeType = mode;
                                 this.prevSlot = this.bot.getInventory().getSelectedSlot();
                                 this.phaseTick = 0;
                                 this.phase = CartController.Phase.EXECUTING;
                                 this.spawnedCart = null;
                                 this.isDrawing = false;
                                 this.offhandCart = false;
                                 this.clearXbowCartState();
                                 BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
                                 this.bot.setSprinting(false);
                                 return true;
                              }
                           }
                        } else {
                           return this.repeatBail("no") ? false : this.bail("no rail(" + this.railSlot + ") or cart(" + this.cartSlot + ")");
                        }
                     }
                  }
               }
            }
         } else {
            boolean var10000;
            if (this.repeatBail("range")) {
               var10000 = false;
            } else {
               Object[] var10002 = new Object[]{dist};
               var10000 = this.bail("range " + String.format("%.1f", var10002));
            }

            return var10000;
         }
      } else {
         return this.bail("no target");
      }
   }

   private void backAwayOnceArmed() {
      if (this.spawnedCart != null) {
         if (this.phaseTick > this.lastPlacementTick()) {
            BotCommands.moveBackward(this.server, this.bot.getScoreboardName());
         }
      }
   }

   private int lastPlacementTick() {
      byte var10000;
      switch (this.activeType) {
         case XBOW_CART -> var10000 = 9;
         default -> var10000 = 0;
      }

      return var10000;
   }

   private int cartCooldown() {
      return Math.max(1, EffectiveSettings.of(this.bot.getScoreboardName()).difficultyParams().cartCooldownTicks);
   }

   private boolean skipThisCart() {
      int skip = EffectiveSettings.of(this.bot.getScoreboardName()).difficultyParams().cartSkipChance;
      return skip > 0 && RNG.nextInt(100) < skip;
   }

   private void defendAgainstIncomingCart() {
      if (this.defenceCooldown <= 0) {
         ServerLevel var2 = this.bot.level();
         if (var2 instanceof ServerLevel) {
            ServerLevel sl = var2;
            MinecartTNT var12 = null;
            double closest = (double)9.0F;

            for(MinecartTNT cart : var2.getEntitiesOfClass(MinecartTNT.class, this.bot.getBoundingBox().inflate((double)9.0F))) {
               if (cart != this.spawnedCart && cart.isAlive()) {
                  double d = (double)cart.distanceTo(this.bot);
                  if (!(d > closest)) {
                     Vec3 toBot = this.bot.position().subtract(cart.position());
                     Vec3 vel = cart.getDeltaMovement();
                     if (!(vel.horizontalDistance() < 0.05) && !(vel.x * toBot.x + vel.z * toBot.z <= (double)0.0F)) {
                        closest = d;
                        var12 = cart;
                     }
                  }
               }
            }

            if (var12 == null) {
               this.defenceCooldown = 4;
            } else if (this.phase == CartController.Phase.EXECUTING) {
               this.defenceCooldown = 5;
            } else {
               Vec3 dir = var12.getDeltaMovement().normalize();
               int blockSlot = this.findSolidBlockInInventory();
               if (blockSlot >= 0) {
                  for(double ahead = (double)1.0F; ahead <= (double)2.0F; ++ahead) {
                     Vec3 p = var12.position().add(dir.scale(ahead));
                     BlockPos at = BlockPos.containing(p.x, p.y, p.z);
                     if (sl.getBlockState(at).isAir() && !(this.bot.position().distanceTo(Vec3.atCenterOf(at)) > (double)4.5F)) {
                        boolean placed = this.placeSolidBlock(blockSlot, at);
                        if (placed) {
                           this.defenceCooldown = 10;
                           return;
                        }
                     }
                  }
               }

               BotCommands.moveBackward(this.server, this.bot.getScoreboardName());
               this.defenceCooldown = 5;
            }
         }
      }
   }

   private int findSolidBlockInInventory() {
      for(int i = 0; i < 36; ++i) {
         ItemStack st = this.bot.getInventory().getItem(i);
         if (!st.isEmpty() && !isRailStack(st) && !st.is(Items.TNT_MINECART)) {
            Item var4 = st.getItem();
            if (var4 instanceof BlockItem) {
               BlockItem bi = (BlockItem)var4;
               if (bi.getBlock().defaultBlockState().isSolidRender()) {
                  return i;
               }
            }
         }
      }

      return -1;
   }

   private boolean placeSolidBlock(int slot, BlockPos at) {
      slot = this.moveToHotbar(slot);
      InventoryUtils.select(this.bot.getInventory(), slot);
      ItemStack st = this.bot.getInventory().getItem(slot);
      Vec3 hitVec = Vec3.atCenterOf(at);
      this.lookAt(hitVec);
      BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, at.below(), false);
      InteractionResult result = this.bot.gameMode.useItemOn(this.bot, this.bot.level(), st, InteractionHand.MAIN_HAND, hit);
      this.swingForPlacement(result);
      return result.consumesAction();
   }

   private boolean tickExecuting(LivingEntity target) {
      ++this.phaseTick;
      if (this.phaseTick <= 102 && target != null && target.isAlive()) {
         this.backAwayOnceArmed();
         boolean var10000;
         switch (this.activeType) {
            case XBOW_CART:
               var10000 = this.execXbowCart(target);
               break;
            case PRE_CART:
               var10000 = this.execPreCart(target);
               break;
            case PRE_RAIL:
               var10000 = this.execPreRail(target);
               break;
            case INSTA_CART:
               var10000 = this.execInstaCart(target);
               break;
            case SMART:
               this.abort();
               var10000 = false;
               break;
            default:
               throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         this.abort();
         return false;
      }
   }

   private boolean execPreCart(LivingEntity target) {
      int railPlace = 2;
      int cartEquip = 3;
      int cartPlace = 4;
      int switchTick = 5;
      int drawStart = 6;
      int release = drawStart + 7;
      int done = release + 5;
      if (this.phaseTick == 1) {
         this.equipRail();
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == railPlace) {
         this.aimAtBlock(this.railPos);
         this.placeRail();
      } else if (this.phaseTick == cartEquip) {
         this.equipCart();
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == cartPlace) {
         this.aimAtBlock(this.railPos);
         this.spawnCartEntity();
      } else if (this.phaseTick == switchTick) {
         InventoryUtils.select(this.bot.getInventory(), this.flameBowSlot);
         this.aimAtCartOrRail(target);
      } else if (this.phaseTick == drawStart) {
         this.aimAtCartOrRail(target);
         this.startBowDraw();
      } else if (this.phaseTick > drawStart && this.phaseTick < release) {
         this.aimAtCartOrRail(target);
      } else if (this.phaseTick == release) {
         this.aimAtCartOrRail(target);
         this.releaseBow();
      } else if (this.phaseTick == done) {
         this.safetyCheck(target);
         this.finish();
      }

      return true;
   }

   private boolean execPreRail(LivingEntity target) {
      int railPlace = 2;
      int switchTick = 3;
      int drawStart = 4;
      int release = drawStart + 7;
      int cartEquip = release + 1;
      int cartTick = release + 2;
      int done = release + 6;
      if (this.phaseTick == 1) {
         this.equipRail();
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == railPlace) {
         this.aimAtBlock(this.railPos);
         this.placeRail();
      } else if (this.phaseTick == switchTick) {
         InventoryUtils.select(this.bot.getInventory(), this.flameBowSlot);
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == drawStart) {
         this.aimAtBlock(this.railPos);
         this.startBowDraw();
      } else if (this.phaseTick > drawStart && this.phaseTick < release) {
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == release) {
         this.aimAtBlock(this.railPos);
         this.releaseBow();
      } else if (this.phaseTick == cartEquip) {
         this.equipCart();
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == cartTick) {
         this.spawnCartEntity();
      } else if (this.phaseTick == done) {
         this.safetyCheck(target);
         this.finish();
      }

      return true;
   }

   private int instaDrawTicks(LivingEntity target) {
      double d = this.bot.position().distanceTo(Vec3.atCenterOf(this.railPos));
      int ticks = (int)Math.round((double)4.0F + d * 1.1);
      return Math.max(4, Math.min(12, ticks));
   }

   private boolean execInstaCart(LivingEntity target) {
      int drawStart = 2;
      int release = drawStart + this.instaDrawTicks(target);
      int railEquip = release + 1;
      int railPlace = release + 2;
      int cartEquip = release + 3;
      int cartPlace = release + 4;
      int done = release + 8;
      if (this.phaseTick == 1) {
         InventoryUtils.select(this.bot.getInventory(), this.flameBowSlot);
         this.aimAtCartOrRail(target);
      } else if (this.phaseTick == drawStart) {
         this.aimAtCartOrRail(target);
         this.startBowDraw();
      } else if (this.phaseTick > drawStart && this.phaseTick < release) {
         this.aimAtCartOrRail(target);
      } else if (this.phaseTick == release) {
         this.aimAtCartOrRail(target);
         this.releaseBow();
      } else if (!this.instaRecovery && this.phaseTick == railEquip) {
         this.equipRail();
         this.aimAtBlock(this.railPos);
      } else if (!this.instaRecovery && this.phaseTick == railPlace) {
         this.aimAtBlock(this.railPos);
         this.placeRail();
      } else if (!this.instaRecovery && this.phaseTick == cartEquip) {
         this.equipCart();
         this.aimAtBlock(this.railPos);
      } else if (!this.instaRecovery && this.phaseTick == cartPlace) {
         this.aimAtBlock(this.railPos);
         this.spawnCartEntity();
      } else if (this.phaseTick == done) {
         if (!this.instaRetried && this.spawnedCart != null && this.spawnedCart.isAlive() && !this.spawnedCart.isPrimed() && this.flameBowSlot >= 0 && this.hasArrows()) {
            this.instaRetried = true;
            this.phaseTick = 0;
            this.instaRecovery = true;
            return true;
         }

         this.safetyCheck(target);
         this.finish();
      } else if (this.instaRecovery && this.phaseTick == 1) {
         InventoryUtils.select(this.bot.getInventory(), this.flameBowSlot);
         this.aimAtCartOrRail(target);
      }

      return true;
   }

   private boolean execXbowCart(LivingEntity target) {
      if (this.phaseTick == 1) {
         this.equipRail();
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == 2) {
         this.aimAtBlock(this.railPos);
         this.placeRail();
      } else if (this.phaseTick == 3) {
         if (!this.isRailAt(this.railPos)) {
            this.placeRail();
         }
      } else if (this.phaseTick == 4) {
         this.equipCart();
         this.aimAtBlock(this.railPos);
      } else if (this.phaseTick == 5) {
         this.aimAtBlock(this.railPos);
         this.spawnCartEntity();
      } else if (this.phaseTick == 6) {
         this.refreshSpawnedCart();
      } else if (this.phaseTick == 8) {
         this.equipFlint();
         this.firePos = this.findFirePosAlongShotPath(this.cartLowerAimPoint());
         this.aimAtBlock(this.firePos != null ? this.firePos : this.railPos);
      } else if (this.phaseTick == 9) {
         this.firePos = this.findFirePosAlongShotPath(this.cartLowerAimPoint());
         this.aimAtBlock(this.firePos != null ? this.firePos : this.railPos);
         this.placeFire();
      } else if (this.phaseTick == 10) {
         if (!this.isFireAt(this.firePos)) {
            this.firePos = this.findFirePosAlongShotPath(this.cartLowerAimPoint());
            this.placeFire();
         }
      } else if (this.phaseTick >= 12) {
         this.tickXbowCartCrossbow(target);
      }

      return true;
   }

   private void tickXbowCartCrossbow(LivingEntity target) {
      if (this.crossbowSlot < 0) {
         LOGGER.warn("[Cart] {} xbow cart: no crossbow slot", this.bot.getScoreboardName());
         this.abort();
      } else {
         this.crossbowSlot = this.moveToHotbar(this.crossbowSlot);
         InventoryUtils.select(this.bot.getInventory(), this.crossbowSlot);
         this.aimAtCartLowerHalf();
         if (this.xbowFired) {
            ++this.xbowPostFireWait;
            if (this.xbowPostFireWait >= 8) {
               this.safetyCheck(target);
               this.finish();
            }

         } else {
            ItemStack held = this.bot.getMainHandItem();
            if (!held.is(Items.CROSSBOW)) {
               LOGGER.warn("[Cart] {} xbow cart: expected crossbow in hand, got {}", this.bot.getScoreboardName(), held.getItem());
               this.abort();
            } else if (CrossbowItem.isCharged(held)) {
               if (this.isFireAt(this.firePos) && this.fireIsOnShotLine(this.firePos, this.cartLowerAimPoint())) {
                  this.aimAtCartLowerHalf();
                  this.fireCrossbow();
                  this.xbowFired = true;
                  this.lastFiredCrossbowSlot = this.crossbowSlot;
                  this.xbowPostFireWait = 0;
               } else {
                  if (!this.xbowFireRetried) {
                     this.xbowFireRetried = true;
                     this.firePos = this.findFirePosAlongShotPath(this.cartLowerAimPoint());
                     if (this.firePos != null) {
                        this.equipFlint();
                        this.aimAtBlock(this.firePos);
                        this.placeFire();
                        return;
                     }
                  }

                  LOGGER.warn("[Cart] {} xbow cart: no flame on the shot line — holding fire (a plain arrow would destroy the cart)", this.bot.getScoreboardName());
                  this.abort();
               }
            } else {
               if (this.xbowCharging && !this.bot.isUsingItem()) {
                  this.xbowCharging = false;
                  this.xbowChargeTicks = 0;
               }

               if (!this.xbowCharging) {
                  this.bot.startUsingItem(InteractionHand.MAIN_HAND);
                  this.xbowCharging = true;
                  this.xbowChargeTicks = 0;
               }

               ++this.xbowChargeTicks;
               if (this.xbowChargeTicks >= 30) {
                  this.bot.releaseUsingItem();
                  this.xbowCharging = false;
                  this.xbowChargeTicks = 0;
               }

            }
         }
      }
   }

   private void clearXbowCartState() {
      this.xbowFired = false;
      this.xbowPostFireWait = 0;
      this.xbowCharging = false;
      this.xbowChargeTicks = 0;
      this.xbowFireRetried = false;
   }

   private void equipRail() {
      if (this.railSlot >= 0) {
         this.railSlot = this.moveToHotbar(this.railSlot);
         InventoryUtils.select(this.bot.getInventory(), this.railSlot);
      }
   }

   private void equipCart() {
      if (this.cartSlot >= 0) {
         if (this.countHotbar(Items.TNT_MINECART) == 0 && this.countInInventoryOf(Items.TOTEM_OF_UNDYING) == 0) {
            this.offhandCart = true;
         } else {
            this.cartSlot = this.moveToHotbar(this.cartSlot);
            InventoryUtils.select(this.bot.getInventory(), this.cartSlot);
         }
      }
   }

   private void equipFlint() {
      if (this.flintSlot >= 0) {
         this.flintSlot = this.moveToHotbar(this.flintSlot);
         InventoryUtils.select(this.bot.getInventory(), this.flintSlot);
      }
   }

   void ensureCartHotbar() {
      if (this.phase == CartController.Phase.IDLE) {
         if (EffectiveSettings.of(this.bot.getScoreboardName()).useCarting()) {
            if (this.countHotbar(Items.TNT_MINECART) < 2) {
               this.hoistToHotbar(this.findInBag(Items.TNT_MINECART));
            }

            if (this.countHotbarRails() < 1) {
               this.hoistToHotbar(this.findRailInInventory());
            }

         }
      }
   }

   private int countHotbar(Item item) {
      int n = 0;

      for(int i = 0; i < 9; ++i) {
         if (this.bot.getInventory().getItem(i).is(item)) {
            ++n;
         }
      }

      return n;
   }

   private int countHotbarRails() {
      int n = 0;

      for(int i = 0; i < 9; ++i) {
         if (isRailStack(this.bot.getInventory().getItem(i))) {
            ++n;
         }
      }

      return n;
   }

   private void hoistToHotbar(int slot) {
      if (slot >= 9) {
         int dest = this.findHotbarDest(true);
         if (dest >= 0) {
            this.swapIntoHotbar(slot, dest);
         }

      }
   }

   private int moveToHotbar(int slot) {
      if (slot < 9) {
         return slot;
      } else {
         if (CartDoctrine.isGuideDoctrine(this.bot.getScoreboardName())) {
            this.pendingGrabDelay = 6;
         }

         return this.swapIntoHotbar(slot, this.findHotbarDest(false));
      }
   }

   private int swapIntoHotbar(int slot, int dest) {
      ItemStack item = this.bot.getInventory().getItem(slot).copy();
      ItemStack old = this.bot.getInventory().getItem(dest).copy();
      this.bot.getInventory().setItem(dest, item);
      this.bot.getInventory().setItem(slot, old);
      return dest;
   }

   private int findHotbarDest(boolean strict) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).isEmpty()) {
            return i;
         }
      }

      for(int i = 8; i >= 0; --i) {
         if (!this.isSequenceSlot(i)) {
            ItemStack s = inv.getItem(i);
            if (!InventoryUtils.isProtected(s) && !isRailStack(s) && !s.is(Items.TNT_MINECART) && !s.is(Items.FLINT_AND_STEEL)) {
               return i;
            }
         }
      }

      if (strict) {
         return -1;
      } else {
         for(int i = 8; i >= 0; --i) {
            if (!this.isSequenceSlot(i)) {
               return i;
            }
         }

         return 8;
      }
   }

   private boolean isSequenceSlot(int i) {
      return i == this.railSlot || i == this.cartSlot || i == this.flameBowSlot || i == this.crossbowSlot || i == this.flintSlot || i == this.prevSlot;
   }

   private void placeRail() {
      if (this.canPlaceRail(this.railPos)) {
         if (!(this.bot.position().distanceTo(Vec3.atCenterOf(this.railPos)) > (double)4.5F)) {
            this.railSlot = this.moveToHotbar(this.railSlot);
            InventoryUtils.select(this.bot.getInventory(), this.railSlot);
            ItemStack railStack = this.bot.getInventory().getItem(this.railSlot);
            if (isRailStack(railStack)) {
               Vec3 hitVec = new Vec3((double)this.railPos.getX() + (double)0.5F, (double)this.railPos.getY(), (double)this.railPos.getZ() + (double)0.5F);
               this.lookAt(hitVec);
               BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, this.railPos.below(), false);
               InteractionResult result = this.bot.gameMode.useItemOn(this.bot, this.bot.level(), railStack, InteractionHand.MAIN_HAND, hit);
               this.swingForPlacement(result);
            }
         }
      }
   }

   private boolean tryOffhandCart(ServerLevel sl, Vec3 hitVec, BlockHitResult hit) {
      if (this.bot.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
         return false;
      } else if (this.countInInventoryOf(Items.TOTEM_OF_UNDYING) > 0) {
         return false;
      } else {
         int source = this.findInInventory(Items.TNT_MINECART);
         if (source < 0) {
            return false;
         } else if (!OffhandManager.park(this.bot, source, 20)) {
            return false;
         } else {
            ItemStack off = this.bot.getOffhandItem();
            if (!off.is(Items.TNT_MINECART)) {
               OffhandManager.unpark(this.bot);
               return false;
            } else {
               this.lookAt(hitVec);
               InteractionResult r = this.bot.gameMode.useItemOn(this.bot, sl, off, InteractionHand.OFF_HAND, hit);
               this.swingForPlacement(r);
               OffhandManager.unpark(this.bot);
               List<MinecartTNT> near = sl.getEntitiesOfClass(MinecartTNT.class, (new AABB(this.railPos)).inflate((double)1.0F));
               if (!near.isEmpty()) {
                  this.spawnedCart = (MinecartTNT)near.get(0);
               }

               this.rememberOwnCart(this.spawnedCart);
               return this.spawnedCart != null;
            }
         }
      }
   }

   private int countInInventoryOf(Item item) {
      int n = 0;

      for(int i = 0; i < 41; ++i) {
         if (this.bot.getInventory().getItem(i).is(item)) {
            ++n;
         }
      }

      return n;
   }

   private void spawnCartEntity() {
      ServerLevel hitVec = this.bot.level();
      if (hitVec instanceof ServerLevel) {
         ServerLevel sl = hitVec;
         if (isRailBlock(hitVec.getBlockState(this.railPos))) {
            Vec3 hitVec0 = new Vec3((double)this.railPos.getX() + (double)0.5F, (double)this.railPos.getY() + (double)0.0625F, (double)this.railPos.getZ() + (double)0.5F);
            BlockHitResult hit0 = new BlockHitResult(hitVec0, Direction.UP, this.railPos, false);
            if (!this.offhandCart || !this.tryOffhandCart(sl, hitVec0, hit0)) {
               this.cartSlot = this.moveToHotbar(this.cartSlot);
               InventoryUtils.select(this.bot.getInventory(), this.cartSlot);
               ItemStack cartStack = this.bot.getInventory().getItem(this.cartSlot);
               if (cartStack.is(Items.TNT_MINECART)) {
                  this.lookAt(hitVec0);
                  InteractionResult result = this.bot.gameMode.useItemOn(this.bot, sl, cartStack, InteractionHand.MAIN_HAND, hit0);
                  this.swingForPlacement(result);
                  List<MinecartTNT> nearby = sl.getEntitiesOfClass(MinecartTNT.class, (new AABB(this.railPos)).inflate((double)1.0F));
                  if (!nearby.isEmpty()) {
                     this.spawnedCart = (MinecartTNT)nearby.get(0);
                  }

                  this.rememberOwnCart(this.spawnedCart);
               }
            }
         }
      }
   }

   private void rememberOwnCart(MinecartTNT cart) {
      if (cart != null && !this.ownCarts.contains(cart.getUUID())) {
         this.ownCarts.addLast(cart.getUUID());
         if (this.ownCarts.size() > 8) {
            this.ownCarts.removeFirst();
         }

      }
   }

   private void placeFire() {
      if (this.firePos != null && this.flintSlot >= 0) {
         if (this.canPlaceFire(this.firePos)) {
            if (!(this.bot.position().distanceTo(Vec3.atCenterOf(this.firePos)) > (double)4.5F)) {
               this.flintSlot = this.moveToHotbar(this.flintSlot);
               InventoryUtils.select(this.bot.getInventory(), this.flintSlot);
               ItemStack flintStack = this.bot.getInventory().getItem(this.flintSlot);
               if (flintStack.is(Items.FLINT_AND_STEEL)) {
                  Vec3 hitVec = new Vec3((double)this.firePos.getX() + (double)0.5F, (double)this.firePos.getY(), (double)this.firePos.getZ() + (double)0.5F);
                  this.lookAt(hitVec);
                  BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, this.firePos.below(), false);
                  InteractionResult result = this.bot.gameMode.useItemOn(this.bot, this.bot.level(), flintStack, InteractionHand.MAIN_HAND, hit);
                  this.swingForPlacement(result);
               }
            }
         }
      }
   }

   private void swingForPlacement(InteractionResult result) {
      if (result instanceof InteractionResult.Success success) {
         if (success.swingSource() != SwingSource.NONE) {
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
         }
      }

   }

   private void startBowDraw() {
      ItemStack held = this.bot.getMainHandItem();
      if (!held.is(Items.BOW)) {
         LOGGER.warn("[Cart] {} tried to draw but held item is {} (slot {})", new Object[]{this.bot.getScoreboardName(), held.getItem(), InventoryUtils.selected(this.bot.getInventory())});
      } else {
         this.bot.startUsingItem(InteractionHand.MAIN_HAND);
         this.isDrawing = true;
         VexLog.detail(LOGGER, "[Cart] {} started bow draw (slot {})", this.bot.getScoreboardName(), InventoryUtils.selected(this.bot.getInventory()));
      }
   }

   private void releaseBow() {
      if (this.isDrawing) {
         int useTicks = this.bot.getTicksUsingItem();
         VexLog.detail(LOGGER, "[Cart] {} releasing bow after {} use-ticks", this.bot.getScoreboardName(), useTicks);
         this.bot.releaseUsingItem();
         this.isDrawing = false;
      }

   }

   private void fireCrossbow() {
      CrossbowHelper.fireIfCharged(this.bot);
   }

   private void aimAt(double x, double y, double z) {
      double dx = x - this.bot.getEyePosition().x;
      double dy = y - this.bot.getEyePosition().y;
      double dz = z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void aimAtBlock(BlockPos pos) {
      this.aimAt((double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.5F, (double)pos.getZ() + (double)0.5F);
   }

   private void aimAtCartOrRail(LivingEntity target) {
      if (this.spawnedCart != null && this.spawnedCart.isAlive()) {
         this.aimAt(this.spawnedCart.getX(), this.spawnedCart.getY() + 0.35, this.spawnedCart.getZ());
      } else {
         this.aimAt((double)this.railPos.getX() + (double)0.5F, (double)this.railPos.getY() + 0.3, (double)this.railPos.getZ() + (double)0.5F);
      }

   }

   private void aimAtCartLowerHalf() {
      Vec3 p = this.cartLowerAimPoint();
      this.aimAt(p.x, p.y, p.z);
   }

   private Vec3 cartLowerAimPoint() {
      if (this.spawnedCart != null && this.spawnedCart.isAlive()) {
         double h = (double)this.spawnedCart.getBbHeight();
         return new Vec3(this.spawnedCart.getX(), this.spawnedCart.getY() + h * (double)0.25F, this.spawnedCart.getZ());
      } else {
         return Vec3.atCenterOf(this.railPos).add((double)0.0F, 0.15, (double)0.0F);
      }
   }

   private void refreshSpawnedCart() {
      if (this.railPos != null) {
         ServerLevel sl = this.bot.level();
         if (sl instanceof ServerLevel) {
            List<MinecartTNT> nearby = sl.getEntitiesOfClass(MinecartTNT.class, (new AABB(this.railPos)).inflate((double)1.5F));
            if (!nearby.isEmpty()) {
               this.spawnedCart = (MinecartTNT)nearby.get(0);
            }

            this.rememberOwnCart(this.spawnedCart);
            return;
         }
      }

   }

   private boolean isRailAt(BlockPos pos) {
      return pos != null && isRailBlock(this.bot.level().getBlockState(pos));
   }

   private static boolean isRailBlock(BlockState state) {
      return state.is(BlockTags.RAILS);
   }

   private static boolean isRailStack(ItemStack stack) {
      return stack.is(Items.RAIL) || stack.is(Items.POWERED_RAIL) || stack.is(Items.DETECTOR_RAIL) || stack.is(Items.ACTIVATOR_RAIL);
   }

   private boolean isFireAt(BlockPos pos) {
      if (pos == null) {
         return false;
      } else {
         BlockState state = this.bot.level().getBlockState(pos);
         return state.is(Blocks.FIRE) || state.is(Blocks.SOUL_FIRE);
      }
   }

   private void aimAtCartEntity(MinecartTNT cart, BlockPos fallback) {
      if (cart != null && cart.isAlive()) {
         this.aimAt(cart.getX(), cart.getY() + 0.35, cart.getZ());
      } else {
         this.aimAt((double)fallback.getX() + (double)0.5F, (double)fallback.getY() + 0.3, (double)fallback.getZ() + (double)0.5F);
      }

   }

   private void safetyCheck(LivingEntity target) {
      if (this.spawnedCart != null && this.spawnedCart.isAlive()) {
         if (this.spawnedCart.isPrimed()) {
            Vec3 vel = this.spawnedCart.getDeltaMovement();
            double spd = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
            if (spd < 0.3) {
               Vec3 dir = target.position().subtract(this.spawnedCart.position()).normalize();
               double push = Math.min(1.2, (double)this.spawnedCart.distanceTo(target) * (double)0.25F);
               this.spawnedCart.setDeltaMovement(dir.x * push, vel.y, dir.z * push);
            }

         }
      }
   }

   private void finish() {
      if (this.isDrawing) {
         this.bot.stopUsingItem();
         this.isDrawing = false;
      }

      if (this.xbowCharging && this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      this.clearXbowCartState();
      InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      this.phase = CartController.Phase.IDLE;
      this.cooldownLeft = this.cartCooldown() + this.pendingGrabDelay;
      this.pendingGrabDelay = 0;
      this.spawnedCart = null;
      this.instaRetried = false;
      this.instaRecovery = false;
      this.offhandCart = false;
   }

   private void abort() {
      if (this.isDrawing) {
         this.bot.stopUsingItem();
         this.isDrawing = false;
      }

      if (this.xbowCharging && this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      this.clearXbowCartState();
      InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      this.phase = CartController.Phase.IDLE;
      this.cooldownLeft = this.cartCooldown() / 2;
      this.spawnedCart = null;
      this.instaRetried = false;
      this.instaRecovery = false;
      this.offhandCart = false;
   }

   private int findInInventory(Item item) {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private int findInBag(Item item) {
      for(int i = 9; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private int findRailInInventory() {
      for(int i = 0; i < 36; ++i) {
         if (isRailStack(this.bot.getInventory().getItem(i))) {
            return i;
         }
      }

      return -1;
   }

   private int countInInventory(Item item) {
      int count = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack stack = this.bot.getInventory().getItem(i);
         if (stack.is(item)) {
            count += stack.getCount();
         }
      }

      return count;
   }

   private int countRailsInInventory() {
      int count = 0;

      for(int i = 0; i < 36; ++i) {
         ItemStack stack = this.bot.getInventory().getItem(i);
         if (isRailStack(stack)) {
            count += stack.getCount();
         }
      }

      return count;
   }

   private int findFlameBowInHotbar() {
      for(int i = 0; i < 9; ++i) {
         ItemStack s = this.bot.getInventory().getItem(i);
         if (s.is(Items.BOW) && this.hasEnchant(s, "flame")) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         ItemStack s = this.bot.getInventory().getItem(i);
         if (s.is(Items.BOW) && this.hasEnchant(s, "flame")) {
            return this.swapIntoHotbar(i, this.findHotbarDest(false));
         }
      }

      return -1;
   }

   private int findCrossbowForCart() {
      for(int i = 0; i < 9; ++i) {
         ItemStack s = this.bot.getInventory().getItem(i);
         if (s.is(Items.CROSSBOW)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         ItemStack s = this.bot.getInventory().getItem(i);
         if (s.is(Items.CROSSBOW)) {
            return this.swapIntoHotbar(i, this.findHotbarDest(false));
         }
      }

      return -1;
   }

   private boolean hasAnyCrossbow() {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(Items.CROSSBOW)) {
            return true;
         }
      }

      return false;
   }

   private boolean hasArrows() {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(ItemTags.ARROWS)) {
            return true;
         }
      }

      return this.bot.getInventory().getItem(40).is(ItemTags.ARROWS);
   }

   private boolean hasEnchant(ItemStack stack, String enchantPath) {
      ItemEnchantments enchants = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
      if (enchants == null) {
         return false;
      } else {
         for(Holder<Enchantment> h : enchants.keySet()) {
            String id = (String)h.unwrapKey().map(ResourceKey::identifier).map((loc) -> loc.getPath()).orElse("");
            if (id.equals(enchantPath)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean hasItemsForType(BotSettings.CartMode type) {
      boolean var10000;
      switch (type) {
         case XBOW_CART:
            var10000 = this.crossbowSlot >= 0 && this.flintSlot >= 0 && this.hasArrows();
            break;
         case PRE_CART:
         case PRE_RAIL:
         case INSTA_CART:
            var10000 = this.flameBowSlot >= 0 && this.hasArrows();
            break;
         case SMART:
            var10000 = false;
            break;
         default:
            throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private BlockPos findPlacementPos(LivingEntity target) {
      Vec3 botPos = this.bot.position();
      Vec3 targetPos = target.position();
      BlockPos centre = BlockPos.containing(targetPos.x, targetPos.y, targetPos.z);
      BlockPos best = null;
      double bestDist = Double.MAX_VALUE;

      for(int dx = -2; dx <= 2; ++dx) {
         for(int dz = -2; dz <= 2; ++dz) {
            for(int dy = -1; dy <= 1; ++dy) {
               BlockPos p = centre.offset(dx, dy, dz);
               if (this.canPlaceRail(p)) {
                  Vec3 c = Vec3.atCenterOf(p);
                  double toTarget = targetPos.distanceTo(c);
                  double toBot = botPos.distanceTo(c);
                  if (!(toTarget > (double)2.5F) && !(toBot < this.cartSelfMin()) && !(toBot > (double)4.5F) && this.canSee(this.bot.getEyePosition(), c) && this.canSee(c, targetPos.add((double)0.0F, (double)target.getBbHeight() * (double)0.5F, (double)0.0F)) && toTarget < bestDist) {
                     bestDist = toTarget;
                     best = p;
                  }
               }
            }
         }
      }

      return best;
   }

   private boolean canSee(Vec3 from, Vec3 to) {
      return this.bot.level().clip(new ClipContext(from, to, Block.COLLIDER, Fluid.NONE, this.bot)).getType() == Type.MISS;
   }

   private BlockPos findFirePosAlongShotPath(Vec3 cartLower) {
      if (this.railPos != null && cartLower != null) {
         Vec3 eye = this.bot.getEyePosition();
         Vec3 delta = cartLower.subtract(eye);
         double len = delta.length();
         if (len < (double)1.0F) {
            return null;
         } else {
            Vec3 dir = delta.scale((double)1.0F / len);
            BlockPos last = null;

            for(double dist = len - 0.6; dist >= 1.2; dist -= (double)0.25F) {
               Vec3 sample = eye.add(dir.scale(dist));
               BlockPos pos = BlockPos.containing(sample.x, sample.y, sample.z);
               if (!pos.equals(last)) {
                  last = pos;
                  if (!pos.equals(this.railPos) && !pos.equals(this.railPos.above()) && !(this.bot.position().distanceTo(Vec3.atCenterOf(pos)) > (double)4.25F) && this.canPlaceFire(pos)) {
                     return pos;
                  }
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private boolean fireIsOnShotLine(BlockPos pos, Vec3 cartLower) {
      if (pos != null && cartLower != null) {
         Vec3 eye = this.bot.getEyePosition();
         Vec3 delta = cartLower.subtract(eye);
         double len = delta.length();
         if (len < 0.001) {
            return false;
         } else {
            Vec3 dir = delta.scale((double)1.0F / len);

            for(double dist = (double)0.5F; dist <= len; dist += 0.2) {
               Vec3 sample = eye.add(dir.scale(dist));
               if (BlockPos.containing(sample.x, sample.y, sample.z).equals(pos)) {
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private BotSettings.CartMode pickSmartMode(LivingEntity target, double dist) {
      boolean expoReady = this.crossbowSlot >= 0 && this.flintSlot >= 0 && this.hasArrows() && this.hasChargedCrossbowInHotbar();
      boolean bowReady = this.flameBowSlot >= 0 && this.hasArrows();
      if (!expoReady) {
         return BotSettings.CartMode.INSTA_CART;
      } else if (!bowReady) {
         return BotSettings.CartMode.XBOW_CART;
      } else if (target.getHealth() <= 10.0F) {
         return BotSettings.CartMode.INSTA_CART;
      } else {
         return !(dist >= (double)9.0F) && !this.sprintingStraightIn(target) ? BotSettings.CartMode.XBOW_CART : BotSettings.CartMode.XBOW_CART;
      }
   }

   private int findChargedCrossbowExcluding(int exclude) {
      for(int i = 0; i < 9; ++i) {
         if (i != exclude) {
            ItemStack st = this.bot.getInventory().getItem(i);
            if (st.is(Items.CROSSBOW) && CrossbowItem.isCharged(st)) {
               return i;
            }
         }
      }

      return -1;
   }

   private boolean hasChargedCrossbowInHotbar() {
      for(int i = 0; i < 9; ++i) {
         ItemStack s = this.bot.getInventory().getItem(i);
         if (s.is(Items.CROSSBOW) && CrossbowItem.isCharged(s)) {
            return true;
         }
      }

      return false;
   }

   private boolean sprintingStraightIn(LivingEntity target) {
      if (!target.isSprinting()) {
         return false;
      } else {
         Vec3 v = target.getDeltaMovement();
         double dx = this.bot.getX() - target.getX();
         double dz = this.bot.getZ() - target.getZ();
         double h = Math.hypot(dx, dz);
         if (h < 0.001) {
            return false;
         } else {
            return v.x * dx / h + v.z * dz / h > 0.15;
         }
      }
   }

   private boolean canPlaceRail(BlockPos pos) {
      Level level = this.bot.level();
      if (!level.getBlockState(pos).isAir()) {
         return false;
      } else {
         BlockPos below = pos.below();
         return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
      }
   }

   private boolean canPlaceFire(BlockPos pos) {
      Level level = this.bot.level();
      if (!level.getBlockState(pos).isAir()) {
         return false;
      } else {
         BlockPos below = pos.below();
         return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
      }
   }

   private boolean execDoubleCart(LivingEntity target) {
      int leftCart = 2;
      int leftSwitch = 3;
      int leftDraw = 4;
      int leftRelease = leftDraw + 7;
      int rightRail = leftRelease + 2;
      int rightCart = rightRail + 1;
      int rightSwitch = rightCart + 1;
      int rightDraw = rightSwitch + 1;
      int rightRelease = rightDraw + 7;
      int done = rightRelease + 3;
      if (this.phaseTick == 1) {
         this.aimAtBlock(this.railPosLeft);
         this.placeRailAt(this.railPosLeft);
      } else if (this.phaseTick == leftCart) {
         this.spawnedCartLeft = this.spawnCartEntityAt(this.railPosLeft);
      } else if (this.phaseTick == leftSwitch) {
         InventoryUtils.select(this.bot.getInventory(), this.flameBowSlot);
         this.aimAtCartEntity(this.spawnedCartLeft, this.railPosLeft);
      } else if (this.phaseTick == leftDraw) {
         this.aimAtCartEntity(this.spawnedCartLeft, this.railPosLeft);
         this.startBowDraw();
      } else if (this.phaseTick > leftDraw && this.phaseTick < leftRelease) {
         this.aimAtCartEntity(this.spawnedCartLeft, this.railPosLeft);
      } else if (this.phaseTick == leftRelease) {
         this.aimAtCartEntity(this.spawnedCartLeft, this.railPosLeft);
         this.releaseBow();
      } else if (this.phaseTick == rightRail) {
         this.aimAtBlock(this.railPosRight);
         this.placeRailAt(this.railPosRight);
      } else if (this.phaseTick == rightCart) {
         this.spawnedCartRight = this.spawnCartEntityAt(this.railPosRight);
      } else if (this.phaseTick == rightSwitch) {
         InventoryUtils.select(this.bot.getInventory(), this.flameBowSlot);
         this.aimAtCartEntity(this.spawnedCartRight, this.railPosRight);
      } else if (this.phaseTick == rightDraw) {
         this.aimAtCartEntity(this.spawnedCartRight, this.railPosRight);
         this.startBowDraw();
      } else if (this.phaseTick > rightDraw && this.phaseTick < rightRelease) {
         this.aimAtCartEntity(this.spawnedCartRight, this.railPosRight);
      } else if (this.phaseTick == rightRelease) {
         this.aimAtCartEntity(this.spawnedCartRight, this.railPosRight);
         this.releaseBow();
      } else if (this.phaseTick == done) {
         this.spawnedCart = this.spawnedCartLeft;
         this.safetyCheck(target);
         this.spawnedCart = this.spawnedCartRight;
         this.safetyCheck(target);
         this.spawnedCart = null;
         this.finish();
      }

      return true;
   }

   private boolean findDoubleCartPositions(LivingEntity target) {
      Vec3 botPos = this.bot.position();
      Vec3 targetPos = target.position();
      Vec3 dir = (new Vec3(targetPos.x - botPos.x, (double)0.0F, targetPos.z - botPos.z)).normalize();
      double leftX = -dir.z;
      double leftZ = dir.x;
      double rightX = dir.z;
      double rightZ = -dir.x;
      Level level = this.bot.level();
      BlockPos leftCandidate = BlockPos.containing(targetPos.x + leftX, targetPos.y, targetPos.z + leftZ);
      if (!this.canPlaceRail(leftCandidate)) {
         leftCandidate = leftCandidate.below();
         if (!this.canPlaceRail(leftCandidate)) {
            return false;
         }
      }

      Vec3 leftCenter = Vec3.atCenterOf(leftCandidate);
      if (targetPos.distanceTo(leftCenter) >= botPos.distanceTo(leftCenter)) {
         return false;
      } else {
         BlockPos rightCandidate = BlockPos.containing(targetPos.x + rightX, targetPos.y, targetPos.z + rightZ);
         if (!this.canPlaceRail(rightCandidate)) {
            rightCandidate = rightCandidate.below();
            if (!this.canPlaceRail(rightCandidate)) {
               return false;
            }
         }

         Vec3 rightCenter = Vec3.atCenterOf(rightCandidate);
         if (targetPos.distanceTo(rightCenter) >= botPos.distanceTo(rightCenter)) {
            return false;
         } else {
            this.railPosLeft = leftCandidate;
            this.railPosRight = rightCandidate;
            return true;
         }
      }
   }

   private void placeRailAt(BlockPos pos) {
      if (this.canPlaceRail(pos)) {
         if (!(this.bot.position().distanceTo(Vec3.atCenterOf(pos)) > (double)4.5F)) {
            this.railSlot = this.findRailInInventory();
            if (this.railSlot >= 0) {
               this.railSlot = this.moveToHotbar(this.railSlot);
               InventoryUtils.select(this.bot.getInventory(), this.railSlot);
               ItemStack railStack = this.bot.getInventory().getItem(this.railSlot);
               if (isRailStack(railStack)) {
                  Vec3 hitVec = new Vec3((double)pos.getX() + (double)0.5F, (double)pos.getY(), (double)pos.getZ() + (double)0.5F);
                  this.lookAt(hitVec);
                  BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, pos.below(), false);
                  InteractionResult result = this.bot.gameMode.useItemOn(this.bot, this.bot.level(), railStack, InteractionHand.MAIN_HAND, hit);
                  this.swingForPlacement(result);
                  this.railSlot = this.findRailInInventory();
               }
            }
         }
      }
   }

   private MinecartTNT spawnCartEntityAt(BlockPos pos) {
      ServerLevel var3 = this.bot.level();
      if (var3 instanceof ServerLevel) {
         ServerLevel sl = var3;
         if (!isRailBlock(var3.getBlockState(pos))) {
            return null;
         } else {
            this.cartSlot = this.findInInventory(Items.TNT_MINECART);
            if (this.cartSlot < 0) {
               return null;
            } else {
               this.cartSlot = this.moveToHotbar(this.cartSlot);
               InventoryUtils.select(this.bot.getInventory(), this.cartSlot);
               ItemStack cartStack = this.bot.getInventory().getItem(this.cartSlot);
               if (!cartStack.is(Items.TNT_MINECART)) {
                  return null;
               } else {
                  Vec3 hitVec = new Vec3((double)pos.getX() + (double)0.5F, (double)pos.getY() + (double)0.0625F, (double)pos.getZ() + (double)0.5F);
                  this.lookAt(hitVec);
                  BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, pos, false);
                  InteractionResult result = this.bot.gameMode.useItemOn(this.bot, sl, cartStack, InteractionHand.MAIN_HAND, hit);
                  this.swingForPlacement(result);
                  this.cartSlot = this.findInInventory(Items.TNT_MINECART);
                  List<MinecartTNT> nearby = sl.getEntitiesOfClass(MinecartTNT.class, (new AABB(pos)).inflate((double)1.0F));
                  return nearby.isEmpty() ? null : (MinecartTNT)nearby.get(0);
               }
            }
         }
      } else {
         return null;
      }
   }

   private void lookAt(Vec3 pos) {
      double dx = pos.x - this.bot.getEyePosition().x;
      double dy = pos.y - this.bot.getEyePosition().y;
      double dz = pos.z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private static enum Phase {
      IDLE,
      EXECUTING;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, EXECUTING};
      }
   }
}
