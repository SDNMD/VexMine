package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

public final class JumpPlaceController {
   static final double START_DIST = (double)20.0F;
   static final double STOP_DIST = (double)7.0F;
   private static final int GROUND_SCAN = 6;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private boolean active = false;
   private boolean placedThisJump = false;

   public JumpPlaceController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public void reset() {
      this.active = false;
      this.placedThisJump = false;
   }

   public void tick(LivingEntity target, double dist) {
      if (dist > (double)20.0F) {
         this.active = true;
      } else if (dist <= (double)7.0F) {
         this.active = false;
      }

      if (this.active && !this.bot.isInWater() && !this.bot.isInLava() && !this.bot.isFallFlying() && !this.bot.isPassenger()) {
         int slot = this.findBlock();
         if (slot >= 0) {
            if (this.bot.onGround()) {
               this.placedThisJump = false;
               this.bot.setSprinting(true);
               BotCommands.jumpOnce(this.server, this.botName);
            } else if (!this.placedThisJump) {
               Vec3 v = this.bot.getDeltaMovement();
               if (!(v.y >= (double)0.0F)) {
                  ServerLevel level = this.bot.level();
                  double x = this.bot.getX();
                  double y = this.bot.getY();
                  double z = this.bot.getZ();
                  double vx = v.x;
                  double vy = v.y;
                  double vz = v.z;

                  for(int step = 0; step < 4; ++step) {
                     double nx = x + vx;
                     double ny = y + vy;
                     double nz = z + vz;
                     BlockPos ground = this.groundBelow(level, nx, y, nz);
                     if (ground == null) {
                        return;
                     }

                     BlockPos place = ground.above();
                     double top = (double)place.getY() + (double)1.0F;
                     if (ny < top) {
                        if (y < top) {
                           return;
                        }

                        if (level.getBlockState(place).canBeReplaced() && level.getFluidState(place).isEmpty()) {
                           this.placeOn(level, ground, slot);
                           return;
                        }

                        return;
                     }

                     x = nx;
                     y = ny;
                     z = nz;
                     vx *= 0.91;
                     vz *= 0.91;
                     vy = (vy - 0.08) * 0.98;
                  }

               }
            }
         }
      }
   }

   private BlockPos groundBelow(ServerLevel level, double x, double fromY, double z) {
      BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(Mth.floor(x), Mth.floor(fromY), Mth.floor(z));

      for(int i = 0; i <= 6; ++i) {
         p.move(0, -1, 0);
         if (!level.getBlockState(p).getCollisionShape(level, p).isEmpty()) {
            return p.immutable();
         }
      }

      return null;
   }

   private void placeOn(ServerLevel level, BlockPos ground, int slot) {
      Inventory inv = this.bot.getInventory();
      InteractionHand hand = slot == 40 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
      int prev = InventoryUtils.selected(inv);
      if (hand == InteractionHand.MAIN_HAND) {
         InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, slot));
      }

      ItemStack stack = hand == InteractionHand.OFF_HAND ? this.bot.getOffhandItem() : this.bot.getMainHandItem();
      Vec3 hit = Vec3.atCenterOf(ground).add((double)0.0F, (double)0.5F, (double)0.0F);
      double dx = hit.x - this.bot.getX();
      double dy = hit.y - this.bot.getEyeY();
      double dz = hit.z - this.bot.getZ();
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))));
      this.bot.gameMode.useItemOn(this.bot, level, stack, hand, new BlockHitResult(hit, Direction.UP, ground, false));
      McCompat.swing(this.bot, hand);
      this.placedThisJump = true;
      if (hand == InteractionHand.MAIN_HAND && prev >= 0 && prev < 9) {
         InventoryUtils.select(inv, prev);
      }

   }

   private int findBlock() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (usable(inv.getItem(i))) {
            return i;
         }
      }

      return usable(this.bot.getOffhandItem()) ? 40 : -1;
   }

   private static boolean usable(ItemStack st) {
      if (!ScaffoldController.isPillarBlock(st)) {
         return false;
      } else {
         return !st.is(Items.OBSIDIAN) && !st.is(Items.CRYING_OBSIDIAN) && !st.is(Items.RESPAWN_ANCHOR) && !st.is(Items.GLOWSTONE);
      }
   }
}
