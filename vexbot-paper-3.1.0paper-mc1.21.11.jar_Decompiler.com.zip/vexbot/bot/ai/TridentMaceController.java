package vexbot.bot.ai;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;
import vexbot.util.BotCommands;
import vexbot.util.EnchantmentUtils;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.StunSlam;
import vexbot.util.VexLog;

public final class TridentMaceController {
   public static final int REQUIRED_RIPTIDE_LEVEL = 3;
   private static final double TRIGGER_RANGE = (double)28.0F;
   private static final double MIN_FALL_DIST = (double)1.5F;
   private static final int COOLDOWN_TICKS = 140;
   private static final int MAX_CHARGE_TICKS = 24;
   private static final int MAX_RIPTIDE_UP_TICKS = 50;
   private static final int MAX_DIVE_TICKS = 45;
   private static final int MAX_SMASH_TICKS = 50;
   private static final int RIPTIDE_UP_COUNT = 2;
   private static final int RIPTIDE_COOLDOWN = 6;
   private static final float UP_PITCH = -89.0F;
   private static final int CHARGE_TICKS = 12;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int riptidesLeft;
   private int riptideCooldown;
   private int chargeTicks;
   private int tridentSlot;
   private int maceSlot;
   private int prevSlot;
   private final StunSlam stunSlam;
   private final ServerPlayer bot;
   private final MinecraftServer server;

   public TridentMaceController(ServerPlayer bot, MinecraftServer server) {
      this.phase = TridentMaceController.Phase.IDLE;
      this.tridentSlot = -1;
      this.maceSlot = -1;
      this.stunSlam = new StunSlam();
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.riptideCooldown > 0) {
         --this.riptideCooldown;
      }

      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target, dist);
         case 1 -> var10000 = this.tickCharging();
         case 2 -> var10000 = this.tickRiptideUp(target);
         case 3 -> var10000 = this.tickRiptideDive(target);
         case 4 -> var10000 = this.tickSmashing(target);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public boolean isExecuting() {
      return this.phase != TridentMaceController.Phase.IDLE;
   }

   public void reset() {
      if (this.phase != TridentMaceController.Phase.IDLE && this.bot.onGround()) {
         this.abort();
      }

   }

   public static boolean hasComboInHotbar(ServerPlayer bot) {
      return findRiptideTridentSlot(bot) >= 0 && findMaceSlot(bot) >= 0;
   }

   public static boolean canAttempt(ServerPlayer bot) {
      return !hasComboInHotbar(bot) ? false : mayRiptide(bot);
   }

   private boolean tickIdle(LivingEntity target, double dist) {
      if (target != null && target.isAlive()) {
         if (this.cooldown > 0) {
            return false;
         } else if (dist > (double)28.0F) {
            return false;
         } else if (!this.bot.onGround()) {
            return false;
         } else if (!mayRiptide(this.bot)) {
            return false;
         } else {
            this.tridentSlot = findRiptideTridentSlot(this.bot);
            this.maceSlot = findMaceSlot(this.bot);
            if (this.tridentSlot >= 0 && this.maceSlot >= 0) {
               if (!EffectiveSettings.of(this.bot.getScoreboardName()).roll()) {
                  return false;
               } else {
                  this.prevSlot = InventoryUtils.selected(this.bot.getInventory());
                  this.riptidesLeft = 2;
                  this.chargeTicks = 0;
                  this.enterPhase(TridentMaceController.Phase.CHARGING);
                  return true;
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private boolean tickCharging() {
      ++this.phaseTick;
      if (!this.comboItemsPresent()) {
         this.abort();
         return false;
      } else if (this.phaseTick > 24) {
         this.abort();
         return false;
      } else {
         BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
         this.bot.setSprinting(false);
         InventoryUtils.select(this.bot.getInventory(), this.tridentSlot);
         this.bot.setXRot(-89.0F);
         this.bot.yHeadRot = this.bot.getYRot();
         ItemStack trident = this.bot.getMainHandItem();
         if (!trident.is(Items.TRIDENT)) {
            this.abort();
            return false;
         } else {
            if (!this.bot.isUsingItem()) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
            }

            ++this.chargeTicks;
            if (this.chargeTicks >= 12) {
               this.enterPhase(TridentMaceController.Phase.RIPTIDE_UP);
            }

            return true;
         }
      }
   }

   private boolean tickRiptideUp(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (!this.comboItemsPresent()) {
            this.abort();
            return false;
         } else if (this.phaseTick > 50) {
            this.chargeTicks = 0;
            this.enterPhase(TridentMaceController.Phase.RIPTIDE_DIVE);
            return true;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.tridentSlot);
            this.bot.setXRot(-89.0F);
            this.bot.yHeadRot = this.bot.getYRot();
            if (this.riptidesLeft <= 0) {
               this.chargeTicks = 0;
               this.enterPhase(TridentMaceController.Phase.RIPTIDE_DIVE);
               return true;
            } else if (this.riptideCooldown > 0) {
               return true;
            } else {
               if (this.fireRiptide(-89.0F, this.bot.getYRot())) {
                  --this.riptidesLeft;
                  this.riptideCooldown = 6;
               }

               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickRiptideDive(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (!this.comboItemsPresent()) {
            this.abort();
            return false;
         } else if (this.phaseTick > 45) {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.enterPhase(TridentMaceController.Phase.SMASHING);
            return true;
         } else {
            this.faceTowardTarget(target);
            InventoryUtils.select(this.bot.getInventory(), this.tridentSlot);
            if (this.riptideCooldown <= 0 && mayRiptide(this.bot) && this.fireRiptide(this.bot.getXRot(), this.bot.getYRot())) {
               this.riptideCooldown = 6;
               InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
               this.enterPhase(TridentMaceController.Phase.SMASHING);
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickSmashing(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (!this.comboItemsPresent()) {
            this.abort();
            return false;
         } else if (this.phaseTick > 50) {
            this.abort();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.faceTowardTarget(target);
            this.driftToward(target);
            double dist = (double)this.bot.distanceTo(target);
            boolean inRange = dist <= EffectiveSettings.of(this.bot.getScoreboardName()).attackRange();
            boolean hasFall = this.bot.fallDistance > (double)1.5F && MaceSmashGates.botMayUseSmashFallBonus(this.bot);
            boolean landed = this.bot.onGround() && this.phaseTick > 3;
            if (inRange && hasFall) {
               if (!this.bot.hasLineOfSight(target)) {
                  if (landed) {
                     this.abort();
                     return false;
                  } else {
                     return true;
                  }
               } else {
                  this.bot.setSprinting(true);
                  EffectiveSettings ssEffs = EffectiveSettings.of(this.bot.getScoreboardName());
                  TechniqueConfig ssCfg = ssEffs.techniques();
                  StunSlam.Result ssRes = this.stunSlam.tick(this.bot, target, this.findAxeSlot(), this.maceSlot, ssCfg.stunSlamVariant, ssCfg.stunSlam, ssEffs);
                  if (ssRes == StunSlam.Result.HOLD) {
                     return true;
                  } else {
                     if (ssRes != StunSlam.Result.SMASHED) {
                        InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                        EquipmentSync.syncNow(this.bot);
                        this.bot.attack(target);
                        McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                     }

                     this.abort();
                     this.cooldown = 140;
                     return true;
                  }
               }
            } else if (landed) {
               this.abort();
               return false;
            } else {
               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean fireRiptide(float pitch, float yaw) {
      if (!mayRiptide(this.bot)) {
         return false;
      } else {
         this.bot.setYRot(yaw);
         this.bot.setXRot(pitch);
         this.bot.yHeadRot = yaw;
         InventoryUtils.select(this.bot.getInventory(), this.tridentSlot);
         ItemStack stack = this.bot.getMainHandItem();
         if (!stack.is(Items.TRIDENT)) {
            return false;
         } else {
            if (!this.bot.isUsingItem()) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
            }

            ++this.chargeTicks;
            if (this.chargeTicks < 12) {
               return false;
            } else {
               boolean launched = this.launchRiptide(stack, pitch, yaw);
               if (launched) {
                  this.chargeTicks = 0;
               }

               return launched;
            }
         }
      }
   }

   private boolean launchRiptide(ItemStack stack, float pitch, float yaw) {
      ServerLevel var5 = this.bot.level();
      if (var5 instanceof ServerLevel) {
         ServerLevel level = var5;
         float strength = EnchantmentHelper.getTridentSpinAttackStrength(stack, this.bot);
         if (strength <= 0.0F) {
            int level3 = EnchantmentUtils.getEnchantLevel(stack, "riptide");
            if (level3 <= 0) {
               return false;
            }

            strength = 1.5F + 0.75F * (float)(level3 - 1);
         }

         float k = -Mth.sin((double)(yaw * ((float)Math.PI / 180F))) * Mth.cos((double)(pitch * ((float)Math.PI / 180F)));
         float l = -Mth.sin((double)(pitch * ((float)Math.PI / 180F)));
         float m = Mth.cos((double)(yaw * ((float)Math.PI / 180F))) * Mth.cos((double)(pitch * ((float)Math.PI / 180F)));
         float n = Mth.sqrt(k * k + l * l + m * m);
         if (n < 1.0E-4F) {
            return false;
         } else {
            k *= strength / n;
            l *= strength / n;
            m *= strength / n;
            Vec3 before = this.bot.getDeltaMovement();
            this.bot.setDeltaMovement(before.add((double)k, (double)l, (double)m));
            this.bot.needsSync = true;
            McCompat.markVelocityDirty(this.bot);
            VexLog.detail(VexBot.LOGGER, "[TridentMace] {} LAUNCH strength={} pitch={} yaw={} delta {} -> {}", this.bot.getScoreboardName(), strength, pitch, yaw, before, this.bot.getDeltaMovement());
            this.bot.startAutoSpinAttack(20, 8.0F, stack);
            if (this.bot.onGround()) {
               this.bot.move(MoverType.SELF, new Vec3((double)0.0F, 1.1999999, (double)0.0F));
            }

            level.playSound((Entity)null, this.bot, (SoundEvent)SoundEvents.TRIDENT_RIPTIDE_3.value(), SoundSource.PLAYERS, 1.0F, 1.0F);
            this.bot.stopUsingItem();
            return true;
         }
      } else {
         return false;
      }
   }

   private static boolean mayRiptide(ServerPlayer bot) {
      EffectiveSettings es = EffectiveSettings.of(bot.getScoreboardName());
      if (es.riptideAnywhere()) {
         return true;
      } else {
         return bot.isInWater() || bot.isInWaterOrRain() || bot.level() != null && bot.level().isRainingAt(bot.blockPosition());
      }
   }

   private void faceTowardTarget(LivingEntity target) {
      double dx = target.getX() - this.bot.getEyePosition().x;
      double dy = target.getY() + (double)target.getBbHeight() * 0.35 - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void driftToward(LivingEntity target) {
      String name = this.bot.getScoreboardName();
      double dist = (double)this.bot.distanceTo(target);
      if (dist > (double)1.5F) {
         BotCommands.moveForward(this.server, name);
         this.bot.setSprinting(dist > (double)3.0F);
      } else {
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
      }

   }

   private boolean comboItemsPresent() {
      return findRiptideTridentSlot(this.bot) >= 0 && findMaceSlot(this.bot) >= 0;
   }

   private void enterPhase(Phase next) {
      VexLog.detail(VexBot.LOGGER, "[TridentMace] {} phase {} -> {} (chargeTicks={}, riptidesLeft={}, onGround={})", this.bot.getScoreboardName(), this.phase, next, this.chargeTicks, this.riptidesLeft, this.bot.onGround());
      this.phase = next;
      this.phaseTick = 0;
   }

   private void abort() {
      if (this.bot.isUsingItem()) {
         this.bot.releaseUsingItem();
      }

      InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      this.cooldown = 70;
      this.riptidesLeft = 0;
      this.riptideCooldown = 0;
      this.chargeTicks = 0;
      this.enterPhase(TridentMaceController.Phase.IDLE);
   }

   private int findAxeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.AXES)) {
            return i;
         }
      }

      return -1;
   }

   private static int findRiptideTridentSlot(ServerPlayer bot) {
      Inventory inv = bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.TRIDENT) && EnchantmentUtils.hasEnchantAtLeast(s, "riptide", 3)) {
            return i;
         }
      }

      return -1;
   }

   private static int findMaceSlot(ServerPlayer bot) {
      Inventory inv = bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.MACE)) {
            return i;
         }
      }

      return -1;
   }

   private static enum Phase {
      IDLE,
      CHARGING,
      RIPTIDE_UP,
      RIPTIDE_DIVE,
      SMASHING;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, CHARGING, RIPTIDE_UP, RIPTIDE_DIVE, SMASHING};
      }
   }
}
