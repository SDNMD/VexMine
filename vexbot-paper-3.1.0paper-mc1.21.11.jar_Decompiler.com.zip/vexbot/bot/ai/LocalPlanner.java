package vexbot.bot.ai;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import vexbot.fakeplayer.bot.pathing.BlockProbe;
import vexbot.fakeplayer.bot.pathing.MoveResult;
import vexbot.fakeplayer.bot.pathing.Moves;
import vexbot.fakeplayer.bot.pathing.PathFinder;
import vexbot.fakeplayer.bot.pathing.PathSettings;

public final class LocalPlanner {
   private static final int WINDOW_LEN = 8;
   private static final int BEAM_WIDTH = 3;
   private static final double REPLAN_GOAL_MOVE = (double)2.0F;
   private static final double REPLAN_DISPLACE = (double)3.0F;
   private static final int NO_PROGRESS_REPLAN = 12;
   private static final double REACH_HORIZ = 0.6;
   private static final double REACH_VERT = (double)1.25F;
   private static final double W_PROGRESS = (double)3.0F;
   private static final double W_MOVE = (double)1.0F;
   private static final double W_TURN = 0.8;
   private static final double W_VERT = 0.6;
   private static final double W_OPEN = (double)0.25F;
   private static final double W_DIFFICULTY = 1.2;
   private final ServerPlayer bot;
   private final PathSettings settings = new PathSettings();
   private final MoveResult scratch = new MoveResult();
   private final Moves[] moves = Moves.values();
   private final ArrayDeque<BlockPos> window = new ArrayDeque();
   private Vec3 lastGoal = null;
   private BlockPos planAnchor = null;
   private int noProgressTicks = 0;
   private double lastFrontDist = Double.MAX_VALUE;
   private static final int ASTAR_BUDGET = 1500;
   private static final int ASTAR_MIN_INTERVAL = 8;
   private static final double ASTAR_MAX_DIST = (double)40.0F;
   private static final double ASTAR_GOAL_MOVE = (double)3.0F;
   private static final double REACH_H_PATH = 0.9;
   private final PathSettings aStarSettings = new PathSettings();
   private List<BlockPos> path = new ArrayList();
   private int pathIndex = 0;
   private Vec3 pathGoal = null;
   private int aStarCooldown = 0;
   private int directCooldown = 0;
   private boolean directOk = false;
   private static final int[] SIDE_X = new int[]{0, 0, 1, -1};
   private static final int[] SIDE_Z = new int[]{-1, 1, 0, 0};

   public LocalPlanner(ServerPlayer bot) {
      this.bot = bot;
      this.settings.removeAvoidedBlock(Blocks.COBWEB);
   }

   public Vec3 tick(Vec3 goal, boolean combat) {
      Level level = this.bot.level();
      BlockPos botCell = this.bot.blockPosition();
      if (this.aStarCooldown > 0) {
         --this.aStarCooldown;
      }

      if (this.directCooldown > 0) {
         --this.directCooldown;
      }

      double distToGoal = this.bot.position().distanceTo(goal);
      if (this.directCooldown == 0) {
         this.directOk = this.directLaneClear(level, botCell, goal, distToGoal);
         this.directCooldown = 3;
      }

      if (this.directOk) {
         this.path.clear();
         return goal;
      } else {
         if (!this.path.isEmpty()) {
            this.advancePath();
            boolean stale = this.pathIndex >= this.path.size() || this.pathGoal != null && goal.distanceToSqr(this.pathGoal) > (double)9.0F || this.offPath() || this.noProgressTicks > 12;
            if (!stale) {
               BlockPos wp = (BlockPos)this.path.get(this.pathIndex);
               this.trackProgress(wp);
               return new Vec3((double)wp.getX() + (double)0.5F, (double)wp.getY(), (double)wp.getZ() + (double)0.5F);
            }

            this.path.clear();
         }

         if (this.aStarCooldown == 0 && distToGoal > (double)4.5F && distToGoal <= (double)40.0F) {
            this.aStarCooldown = 8 + (this.bot.getId() & 3);
            List<BlockPos> found = PathFinder.findPath(level, botCell, goal, this.aStarSettings, this.bot, 1500);
            if (found != null && !found.isEmpty()) {
               this.path = found;
               this.pathIndex = 0;
               this.pathGoal = goal;
               this.noProgressTicks = 0;
               this.lastFrontDist = Double.MAX_VALUE;
               this.advancePath();
               if (this.pathIndex < this.path.size()) {
                  BlockPos wp = (BlockPos)this.path.get(this.pathIndex);
                  this.trackProgress(wp);
                  return new Vec3((double)wp.getX() + (double)0.5F, (double)wp.getY(), (double)wp.getZ() + (double)0.5F);
               }

               this.path.clear();
            }
         }

         boolean replan = this.window.isEmpty() || this.lastGoal == null || goal.distanceToSqr(this.lastGoal) > (double)4.0F || this.planAnchor != null && this.bot.position().distanceToSqr(Vec3.atCenterOf(this.planAnchor)) > (double)9.0F || this.noProgressTicks > 12;

         try (BlockProbe probe = BlockProbe.open(level, this.settings)) {
            if (replan) {
               this.rebuild(probe, botCell, goal);
            } else {
               this.slide(probe, botCell, goal);
            }
         }

         this.lastGoal = goal;
         if (this.window.isEmpty()) {
            return null;
         } else {
            BlockPos front = (BlockPos)this.window.peekFirst();
            double frontDist = this.bot.position().distanceTo(Vec3.atCenterOf(front));
            if (frontDist < this.lastFrontDist - 0.02) {
               this.lastFrontDist = frontDist;
               this.noProgressTicks = 0;
            } else {
               ++this.noProgressTicks;
            }

            return new Vec3((double)front.getX() + (double)0.5F, (double)front.getY(), (double)front.getZ() + (double)0.5F);
         }
      }
   }

   private void advancePath() {
      while(true) {
         if (this.pathIndex < this.path.size()) {
            BlockPos wp = (BlockPos)this.path.get(this.pathIndex);
            double h = PathFinder.closestHDistToBlock(wp, this.bot.position());
            double v = Math.abs(this.bot.getY() - (double)wp.getY());
            if (h <= 0.9 && v <= (double)1.25F) {
               ++this.pathIndex;
               this.lastFrontDist = Double.MAX_VALUE;
               this.noProgressTicks = 0;
               continue;
            }
         }

         return;
      }
   }

   private boolean offPath() {
      if (this.pathIndex >= this.path.size()) {
         return true;
      } else {
         BlockPos wp = (BlockPos)this.path.get(this.pathIndex);
         double h = PathFinder.closestHDistToBlock(wp, this.bot.position());
         double v = Math.abs(this.bot.getY() - (double)wp.getY());
         return h > (double)8.0F || v > (double)4.0F;
      }
   }

   private void trackProgress(BlockPos wp) {
      double d = this.bot.position().distanceTo(Vec3.atCenterOf(wp));
      if (d < this.lastFrontDist - 0.02) {
         this.lastFrontDist = d;
         this.noProgressTicks = 0;
      } else {
         ++this.noProgressTicks;
      }

   }

   private boolean directLaneClear(Level level, BlockPos botCell, Vec3 goal, double dist) {
      if (!(dist > (double)24.0F) && !(Math.abs(goal.y - this.bot.getY()) > (double)2.5F)) {
         double dx = goal.x - this.bot.getX();
         double dz = goal.z - this.bot.getZ();
         double horiz = Math.sqrt(dx * dx + dz * dz);
         if (horiz < (double)1.5F) {
            return true;
         } else {
            double stepX = dx / horiz;
            double stepZ = dz / horiz;
            int y = botCell.getY();
            int steps = (int)Math.min(horiz, (double)24.0F);
            BlockPos goalCell = BlockPos.containing(goal);

            try (BlockProbe probe = BlockProbe.open(level, this.settings)) {
               for(int i = 1; i <= steps; ++i) {
                  int x = Mth.floor(this.bot.getX() + stepX * (double)i);
                  int z = Mth.floor(this.bot.getZ() + stepZ * (double)i);
                  if (!probe.isWalkable(x, y, z)) {
                     if (probe.isWalkable(x, y + 1, z)) {
                        ++y;
                     } else {
                        if (!probe.isWalkable(x, y - 1, z)) {
                           return false;
                        }

                        --y;
                     }
                  }

                  if (webAt(probe, x, y, z) && !nearGoal(x, y, z, goalCell)) {
                     return false;
                  }
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private static boolean webAt(BlockProbe probe, int x, int y, int z) {
      return probe.state(x, y, z).is(Blocks.COBWEB) || probe.state(x, y + 1, z).is(Blocks.COBWEB);
   }

   private static boolean nearGoal(int x, int y, int z, BlockPos goalCell) {
      return Math.abs(x - goalCell.getX()) <= 1 && Math.abs(z - goalCell.getZ()) <= 1 && Math.abs(y - goalCell.getY()) <= 2;
   }

   private void rebuild(BlockProbe probe, BlockPos anchor, Vec3 goal) {
      this.window.clear();
      this.planAnchor = anchor;
      this.noProgressTicks = 0;
      this.lastFrontDist = Double.MAX_VALUE;
      this.window.addAll(this.beam(probe, anchor, goal, 8));
      this.prunePassed();
   }

   private void slide(BlockProbe probe, BlockPos botCell, Vec3 goal) {
      boolean popped;
      for(popped = false; !this.window.isEmpty() && this.reached((BlockPos)this.window.peekFirst()); popped = true) {
         this.window.pollFirst();
      }

      if (popped) {
         this.lastFrontDist = Double.MAX_VALUE;
         this.noProgressTicks = 0;
      }

      while(this.window.size() < 8) {
         BlockPos from = this.window.isEmpty() ? botCell : (BlockPos)this.window.peekLast();
         List<BlockPos> next = this.beam(probe, from, goal, 1);
         if (next.isEmpty()) {
            break;
         }

         BlockPos b = (BlockPos)next.get(0);
         if (b.equals(botCell) || this.window.contains(b)) {
            break;
         }

         this.window.addLast(b);
      }

      if (this.planAnchor == null) {
         this.planAnchor = botCell;
      }

   }

   private void prunePassed() {
      while(!this.window.isEmpty() && this.reached((BlockPos)this.window.peekFirst())) {
         this.window.pollFirst();
      }

   }

   private boolean reached(BlockPos cell) {
      double h = PathFinder.closestHDistToBlock(cell, this.bot.position());
      double v = Math.abs(this.bot.getY() - (double)cell.getY());
      return h <= 0.6 && v <= (double)1.25F;
   }

   private List<BlockPos> beam(BlockProbe probe, BlockPos start, Vec3 goal, int count) {
      int maxJump = this.maxJump();
      int maxFall = this.maxFall();
      List<Cand> beam = new ArrayList();
      beam.add(new Cand(new ArrayList(), this.botHeading(), (double)0.0F));
      List<BlockPos> best = new ArrayList();

      for(int depth = 0; depth < count; ++depth) {
         List<Cand> next = new ArrayList();

         for(Cand p : beam) {
            BlockPos frontier = p.cells.isEmpty() ? start : (BlockPos)p.cells.get(p.cells.size() - 1);
            int fx = frontier.getX();
            int fy = frontier.getY();
            int fz = frontier.getZ();

            for(Moves m : this.moves) {
               this.scratch.reset();
               m.apply(probe, fx, fy, fz, maxJump, maxFall, this.scratch);
               if (!(this.scratch.cost >= Double.POSITIVE_INFINITY)) {
                  BlockPos cand = new BlockPos(this.scratch.x, this.scratch.y, this.scratch.z);
                  if (!cand.equals(frontier) && !p.cells.contains(cand) && !this.window.contains(cand)) {
                     double[] stepDir = dir(frontier, cand);
                     double sc = p.score + this.score(probe, frontier, cand, this.scratch.cost, p.headDir, stepDir, goal);
                     List<BlockPos> cells = new ArrayList(p.cells);
                     cells.add(cand);
                     next.add(new Cand(cells, stepDir, sc));
                  }
               }
            }
         }

         if (next.isEmpty()) {
            break;
         }

         next.sort(Comparator.comparingDouble((c) -> c.score).reversed());
         beam = new ArrayList(next.subList(0, Math.min(3, next.size())));
         best = ((Cand)beam.get(0)).cells;
      }

      return best;
   }

   private double score(BlockProbe probe, BlockPos from, BlockPos to, double moveCost, double[] prevDir, double[] stepDir, Vec3 goal) {
      double pFrom = PathFinder.closestHDistToBlock(from, goal) + Math.abs((double)from.getY() - goal.y) * (double)0.5F;
      double pTo = PathFinder.closestHDistToBlock(to, goal) + Math.abs((double)to.getY() - goal.y) * (double)0.5F;
      double progress = pFrom - pTo;
      double turn = (double)1.0F - (prevDir[0] * stepDir[0] + prevDir[1] * stepDir[1]);
      double vert = (double)Math.abs(to.getY() - from.getY());
      double open = this.wallProximity(probe, to);
      double diff = (double)(this.blockDifficulty(probe, to) - 1);
      return (double)3.0F * progress - (double)1.0F * moveCost - 0.8 * turn - 0.6 * vert - (double)0.25F * open - 1.2 * diff;
   }

   private int blockDifficulty(BlockProbe probe, BlockPos cell) {
      int x = cell.getX();
      int y = cell.getY();
      int z = cell.getZ();
      int d = bodyDifficulty(probe.state(x, y, z));
      d = Math.max(d, bodyDifficulty(probe.state(x, y + 1, z)));
      d = Math.max(d, floorDifficulty(probe.state(x, y - 1, z)));
      return d;
   }

   private static int bodyDifficulty(BlockState s) {
      if (s.is(Blocks.COBWEB)) {
         return 10;
      } else if (s.is(Blocks.POWDER_SNOW)) {
         return 9;
      } else if (s.is(Blocks.SWEET_BERRY_BUSH)) {
         return 8;
      } else if (s.is(Blocks.WATER)) {
         return 6;
      } else if (!s.is(Blocks.BAMBOO) && !s.is(Blocks.BAMBOO_SAPLING) && !s.is(Blocks.SUGAR_CANE)) {
         if (s.is(Blocks.SCAFFOLDING)) {
            return 3;
         } else {
            return s.is(Blocks.SNOW) ? 2 : 1;
         }
      } else {
         return 4;
      }
   }

   private static int floorDifficulty(BlockState s) {
      if (s.is(Blocks.HONEY_BLOCK)) {
         return 7;
      } else if (s.is(Blocks.SOUL_SAND)) {
         return 6;
      } else if (s.is(Blocks.SLIME_BLOCK)) {
         return 5;
      } else if (!s.is(Blocks.MUD) && !s.is(Blocks.MUDDY_MANGROVE_ROOTS)) {
         if (!s.is(Blocks.ICE) && !s.is(Blocks.PACKED_ICE) && !s.is(Blocks.BLUE_ICE) && !s.is(Blocks.FROSTED_ICE)) {
            return s.is(Blocks.SOUL_SOIL) ? 2 : 1;
         } else {
            return 4;
         }
      } else {
         return 5;
      }
   }

   private double wallProximity(BlockProbe probe, BlockPos cell) {
      int solid = 0;
      int x = cell.getX();
      int y = cell.getY();
      int z = cell.getZ();

      for(int s = 0; s < 4; ++s) {
         int nx = x + SIDE_X[s];
         int nz = z + SIDE_Z[s];
         if (probe.isSolid(nx, y, nz) || probe.isSolid(nx, y + 1, nz)) {
            ++solid;
         }
      }

      return (double)solid;
   }

   private static double[] dir(BlockPos from, BlockPos to) {
      double dx = (double)(to.getX() - from.getX());
      double dz = (double)(to.getZ() - from.getZ());
      double len = Math.sqrt(dx * dx + dz * dz);
      return len < 1.0E-6 ? new double[]{(double)0.0F, (double)0.0F} : new double[]{dx / len, dz / len};
   }

   private double[] botHeading() {
      Vec3 v = this.bot.getDeltaMovement();
      double len = Math.sqrt(v.x * v.x + v.z * v.z);
      if (len > 0.05) {
         return new double[]{v.x / len, v.z / len};
      } else {
         double yaw = Math.toRadians((double)this.bot.getYRot());
         return new double[]{-Math.sin(yaw), Math.cos(yaw)};
      }
   }

   private int maxJump() {
      int lvl = this.bot.hasEffect(MobEffects.JUMP_BOOST) ? this.bot.getEffect(MobEffects.JUMP_BOOST).getAmplifier() + 1 : 0;
      double velocity = 0.42 + (double)lvl * 0.1;
      return (int)(velocity * velocity / 0.16);
   }

   private int maxFall() {
      return this.bot.gameMode.getGameModeForPlayer() == GameType.CREATIVE ? 256 : (int)this.bot.getAttributeValue(Attributes.SAFE_FALL_DISTANCE);
   }

   public boolean hasWindow() {
      return !this.path.isEmpty() || !this.window.isEmpty();
   }

   public void invalidate() {
      this.window.clear();
      this.path.clear();
      this.pathIndex = 0;
      this.pathGoal = null;
      this.lastGoal = null;
      this.planAnchor = null;
      this.aStarCooldown = 0;
      this.directCooldown = 0;
      this.directOk = false;
   }

   public void reset() {
      this.invalidate();
      this.noProgressTicks = 0;
      this.lastFrontDist = Double.MAX_VALUE;
   }

   private static final class Cand {
      final List<BlockPos> cells;
      final double[] headDir;
      final double score;

      Cand(List<BlockPos> cells, double[] headDir, double score) {
         this.cells = cells;
         this.headDir = headDir;
         this.score = score;
      }
   }
}
