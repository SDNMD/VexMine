package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.DifficultyParams;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.BotMath;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;

public final class AnchorPvpController {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-Anchor");
   private static final double ANCHOR_RANGE = (double)4.5F;
   private static final double ANCHOR_MIN_RANGE = (double)1.5F;
   private static final double PLACE_RANGE = (double)4.5F;
   private static final double ATTACK_REACH = (double)3.0F;
   private static final int COOLDOWN_TICKS = 5;
   private static final int MAX_SESSION_TICKS = 200;
   private static final int CHAIN_MIN = 5;
   private static final int CHAIN_MAX = 8;
   private static final double CHAIN_REACH = (double)4.5F;
   private static final int CHAIN_MAX_DEPTH = 8;
   private static final double CHAIN_BLAST_REACH = (double)10.0F;
   private static final int CHAIN_WALK_LIMIT = 30;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private static final int MAX_SPAM_ROUNDS = 8;
   private static final Random RNG = new Random();
   private boolean active = false;
   private int sessionTick = 0;
   private int cooldownLeft = 0;
   private int lastRoundTick = -1000;
   private boolean kbLaunched = false;
   private int prevSlot = 0;
   private Mode mode;
   private int roundsLeft;
   private int chainX;
   private int chainZ;
   private int chainTopY;
   private int chainWalkTicks;
   private boolean chainEnded;
   private int lastDetonate;
   private BlockPos roundCell;
   private boolean roundCharged;

   public AnchorPvpController(ServerPlayer bot, MinecraftServer server) {
      this.mode = AnchorPvpController.Mode.SINGLE;
      this.roundsLeft = 0;
      this.chainWalkTicks = 0;
      this.chainEnded = false;
      this.lastDetonate = -10000;
      this.roundCell = null;
      this.roundCharged = false;
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist, boolean chain) {
      if (this.cooldownLeft > 0) {
         --this.cooldownLeft;
         return false;
      } else {
         return this.active ? this.tickActive(target, dist) : this.tickIdle(target, dist, chain);
      }
   }

   public boolean isExecuting() {
      return this.active;
   }

   public boolean isCoolingDown() {
      return !this.active && this.cooldownLeft > 0;
   }

   public boolean takeChainEnded() {
      boolean e = this.chainEnded;
      this.chainEnded = false;
      return e;
   }

   public int lastDetonateTick() {
      return this.lastDetonate;
   }

   public void reset() {
      if (this.active) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.active = false;
      this.sessionTick = 0;
      this.kbLaunched = false;
      this.lastRoundTick = -1000;
      this.mode = AnchorPvpController.Mode.SINGLE;
      this.roundsLeft = 0;
      this.chainWalkTicks = 0;
      this.chainEnded = false;
      this.roundCell = null;
      this.roundCharged = false;
   }

   private boolean tickIdle(LivingEntity target, double dist, boolean chain) {
      if (target != null && target.isAlive()) {
         if (!this.bot.hasLineOfSight(target)) {
            return false;
         } else if (!(dist < (double)1.5F) && !(dist > (double)4.5F)) {
            if (this.bot.level().dimension() == Level.NETHER) {
               return false;
            } else {
               ServerLevel var6 = this.bot.level();
               if (var6 instanceof ServerLevel) {
                  ServerLevel sl = var6;
                  if (this.findInInventory(Items.RESPAWN_ANCHOR) < 0) {
                     return false;
                  } else if (this.findInInventory(Items.GLOWSTONE) < 0) {
                     return false;
                  } else if (CrystalSkill.skipSession(this.bot)) {
                     this.cooldownLeft = CrystalSkill.hesitateTicks(this.bot);
                     return false;
                  } else {
                     int rounds = Math.min(Math.min(this.countInInventory(Items.RESPAWN_ANCHOR), this.countInInventory(Items.GLOWSTONE)), CrystalSkill.maxRounds(this.bot));
                     BlockPos spot = chain ? this.chainStart(sl, target) : null;
                     if (spot != null) {
                        this.mode = AnchorPvpController.Mode.CHAIN;
                        this.roundsLeft = Math.min(5 + RNG.nextInt(4), rounds);
                        this.chainX = spot.getX();
                        this.chainZ = spot.getZ();
                        this.chainTopY = target.blockPosition().getY();
                        this.chainWalkTicks = 0;
                     } else if (rounds >= 2) {
                        this.mode = AnchorPvpController.Mode.SPAM;
                        this.roundsLeft = Math.min(3 + RNG.nextInt(6), rounds);
                     } else {
                        this.mode = AnchorPvpController.Mode.SINGLE;
                        this.roundsLeft = 1;
                     }

                     this.prevSlot = this.bot.getInventory().getSelectedSlot();
                     this.active = true;
                     this.sessionTick = 0;
                     this.kbLaunched = false;
                     this.lastRoundTick = -1000;
                     LOGGER.info("[Anchor] {} starting {} mode ({} rounds) at dist={}", new Object[]{this.bot.getScoreboardName(), this.mode, this.roundsLeft, String.format("%.1f", dist)});
                     return true;
                  }
               } else {
                  return false;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean tickActive(LivingEntity target, double dist) {
      ++this.sessionTick;
      double abortDist = this.mode == AnchorPvpController.Mode.SINGLE ? (double)6.5F : (double)12.0F;
      if (target != null && target.isAlive() && (this.mode == AnchorPvpController.Mode.CHAIN || this.bot.hasLineOfSight(target)) && !(dist > abortDist) && this.sessionTick <= 200) {
         ServerLevel var7 = this.bot.level();
         if (!(var7 instanceof ServerLevel)) {
            this.finish();
            return false;
         } else if (this.mode == AnchorPvpController.Mode.CHAIN) {
            return this.tickChain(var7, target);
         } else {
            this.aimAt(target.getX(), target.getY() + (double)0.5F, target.getZ());
            BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
            if (!this.kbLaunched) {
               if (this.bot.onGround() && dist <= (double)3.0F && this.bot.hasLineOfSight(target)) {
                  this.kbLaunch(target);
               }

               this.kbLaunched = true;
               return true;
            } else {
               BlockPos cell = this.roundCell;
               if (cell == null) {
                  if (this.sessionTick - this.lastRoundTick < this.roundGap()) {
                     return true;
                  }

                  if (this.findInInventory(Items.RESPAWN_ANCHOR) < 0 || this.findInInventory(Items.GLOWSTONE) < 0) {
                     this.finish();
                     return false;
                  }

                  cell = this.mode == AnchorPvpController.Mode.SPAM ? this.findSpamPlacePosition(target) : this.findPlacePosition(target);
                  if (cell == null) {
                     cell = this.chainStart(var7, target);
                  }

                  if (cell == null) {
                     this.finish();
                     return false;
                  }
               }

               Step st = this.stepRound(var7, cell);
               if (st == AnchorPvpController.Step.FAIL) {
                  this.finish();
                  return false;
               } else {
                  if (st == AnchorPvpController.Step.DONE && --this.roundsLeft <= 0) {
                     this.finish();
                  }

                  return true;
               }
            }
         }
      } else {
         this.finish();
         return false;
      }
   }

   private boolean tickChain(ServerLevel sl, LivingEntity target) {
      Vec3 spot = new Vec3((double)this.chainX + (double)0.5F, (double)this.chainTopY + (double)0.5F, (double)this.chainZ + (double)0.5F);
      if (target.position().distanceTo(spot) > (double)10.0F) {
         this.finish();
         return false;
      } else if (this.roundCell != null) {
         BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
         Step st = this.stepRound(sl, this.roundCell);
         if (st == AnchorPvpController.Step.FAIL) {
            this.finish();
            return false;
         } else {
            if (st == AnchorPvpController.Step.DONE && --this.roundsLeft <= 0) {
               this.finish();
            }

            return true;
         }
      } else if (this.sessionTick - this.lastRoundTick < this.roundGap()) {
         BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
         return true;
      } else if (this.findInInventory(Items.RESPAWN_ANCHOR) >= 0 && this.findInInventory(Items.GLOWSTONE) >= 0) {
         BlockPos cell = this.chainCell(sl);
         if (cell == null) {
            this.finish();
            return false;
         } else if (!(this.bot.getEyePosition().distanceTo(Vec3.atCenterOf(cell)) > (double)4.5F) && PlacementRaycasts.canSeePlacement(this.bot, cell)) {
            this.chainWalkTicks = 0;
            BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
            if (this.stepRound(sl, cell) == AnchorPvpController.Step.FAIL) {
               this.finish();
               return false;
            } else {
               return true;
            }
         } else if (++this.chainWalkTicks > 30) {
            this.finish();
            return false;
         } else {
            this.walkToward(Vec3.atCenterOf(cell));
            return true;
         }
      } else {
         this.finish();
         return false;
      }
   }

   private BlockPos chainStart(ServerLevel sl, LivingEntity target) {
      BlockPos feet = target.blockPosition();
      this.chainTopY = feet.getY();
      BlockPos best = null;
      double bestScore = Double.MAX_VALUE;

      for(int dx = -1; dx <= 1; ++dx) {
         for(int dz = -1; dz <= 1; ++dz) {
            if (dx != 0 || dz != 0) {
               BlockPos c = this.columnFloor(sl, feet.getX() + dx, feet.getZ() + dz);
               if (c != null && this.free(sl, c) && !(this.bot.getEyePosition().distanceTo(Vec3.atCenterOf(c)) > (double)4.5F) && PlacementRaycasts.canSeePlacement(this.bot, c)) {
                  double score = (dx != 0 && dz != 0 ? (double)10.0F : (double)0.0F) + this.bot.position().distanceTo(Vec3.atCenterOf(c));
                  if (score < bestScore) {
                     bestScore = score;
                     best = c;
                  }
               }
            }
         }
      }

      return best;
   }

   private BlockPos chainCell(ServerLevel sl) {
      BlockPos c = this.columnFloor(sl, this.chainX, this.chainZ);
      if (c != null && this.free(sl, c)) {
         return c;
      } else if (c == null && !sl.getBlockState(new BlockPos(this.chainX, this.chainTopY, this.chainZ)).canBeReplaced()) {
         return null;
      } else {
         for(Direction d : Plane.HORIZONTAL) {
            BlockPos s = this.columnFloor(sl, this.chainX + d.getStepX(), this.chainZ + d.getStepZ());
            if (s != null && this.free(sl, s)) {
               return s;
            }
         }

         return null;
      }
   }

   private BlockPos columnFloor(ServerLevel sl, int x, int z) {
      for(int y = this.chainTopY; y >= this.chainTopY - 8; --y) {
         BlockPos c = new BlockPos(x, y, z);
         BlockState st = sl.getBlockState(c);
         if (st.is(Blocks.RESPAWN_ANCHOR)) {
            return c;
         }

         if (!st.canBeReplaced()) {
            return null;
         }

         BlockPos below = c.below();
         if (sl.getBlockState(below).isFaceSturdy(sl, below, Direction.UP)) {
            return c;
         }
      }

      return null;
   }

   private boolean free(ServerLevel sl, BlockPos c) {
      return sl.getEntitiesOfClass(LivingEntity.class, new AABB(c)).isEmpty();
   }

   private void walkToward(Vec3 p) {
      double dx = p.x - this.bot.getX();
      double dz = p.z - this.bot.getZ();
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.bot.setYRot(BotMath.smoothBodyYaw(this.bot.getYRot(), yaw));
      this.bot.yHeadRot = yaw;
      BotCommands.moveForward(this.server, this.bot.getScoreboardName());
      this.bot.setSprinting(true);
   }

   private Step stepRound(ServerLevel sl, BlockPos cell) {
      if (CrystalSkill.fumble(this.bot)) {
         return AnchorPvpController.Step.BUSY;
      } else if (this.roundCell != null) {
         if (!sl.getBlockState(this.roundCell).is(Blocks.RESPAWN_ANCHOR)) {
            this.roundCell = null;
            return AnchorPvpController.Step.FAIL;
         } else if (!this.roundCharged) {
            if (CrystalSkill.anchorDud(this.bot)) {
               this.roundCharged = true;
               return AnchorPvpController.Step.BUSY;
            } else if (!this.use(sl, Items.GLOWSTONE, this.roundCell, Direction.UP, Vec3.atCenterOf(this.roundCell))) {
               this.roundCell = null;
               return AnchorPvpController.Step.FAIL;
            } else {
               this.roundCharged = true;
               return AnchorPvpController.Step.BUSY;
            }
         } else {
            int totem = this.findInInventory(Items.TOTEM_OF_UNDYING);
            this.select(totem >= 0 ? totem : this.nonGlowstoneSlot());
            Vec3 hit = Vec3.atCenterOf(this.roundCell);
            this.lookAt(hit);
            this.bot.gameMode.useItemOn(this.bot, sl, this.bot.getMainHandItem(), InteractionHand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, this.roundCell, false));
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            this.roundCell = null;
            this.lastRoundTick = this.sessionTick;
            this.lastDetonate = this.bot.tickCount;
            return AnchorPvpController.Step.DONE;
         }
      } else if (sl.getBlockState(cell).is(Blocks.RESPAWN_ANCHOR) || this.use(sl, Items.RESPAWN_ANCHOR, cell.below(), Direction.UP, new Vec3((double)cell.getX() + (double)0.5F, (double)cell.getY(), (double)cell.getZ() + (double)0.5F)) && sl.getBlockState(cell).is(Blocks.RESPAWN_ANCHOR)) {
         this.roundCell = cell;
         this.roundCharged = false;
         return AnchorPvpController.Step.BUSY;
      } else {
         return AnchorPvpController.Step.FAIL;
      }
   }

   private int roundGap() {
      return Math.max(1, this.getPlaceInterval(EffectiveSettings.of(this.bot.getScoreboardName()).difficultyParams()));
   }

   private boolean use(ServerLevel sl, Item item, BlockPos on, Direction face, Vec3 hit) {
      int slot = this.findInInventory(item);
      if (slot < 0) {
         return false;
      } else {
         this.select(slot);
         ItemStack stack = this.bot.getInventory().getItem(this.bot.getInventory().getSelectedSlot());
         if (!stack.is(item)) {
            return false;
         } else {
            this.lookAt(hit);
            this.bot.gameMode.useItemOn(this.bot, sl, stack, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, on, false));
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            return true;
         }
      }
   }

   private void select(int slot) {
      if (slot >= 9) {
         slot = this.ensureHotbar(slot);
      }

      InventoryUtils.select(this.bot.getInventory(), slot);
   }

   private int nonGlowstoneSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (!inv.getItem(i).is(Items.GLOWSTONE)) {
            return i;
         }
      }

      return 0;
   }

   private int anchorCooldown() {
      return Math.max(1, (new EffectiveSettings(this.bot.getScoreboardName())).difficultyParams().anchorCooldownTicks);
   }

   private BlockPos findPlaceBehindTarget(LivingEntity target) {
      Level level = this.bot.level();
      Vec3 targetPos = target.position();
      Vec3 look = target.getLookAngle();
      Vec3 facing = new Vec3(look.x, (double)0.0F, look.z);
      if (facing.lengthSqr() < 1.0E-4) {
         return null;
      } else {
         facing = facing.normalize();
         BlockPos best = null;
         double bestScore = 0.3;

         for(int dx = -3; dx <= 3; ++dx) {
            for(int dz = -3; dz <= 3; ++dz) {
               for(int dy = 0; dy >= -1; --dy) {
                  BlockPos at = BlockPos.containing(targetPos.x + (double)dx, targetPos.y + (double)dy, targetPos.z + (double)dz);
                  if (this.canPlaceAt(level, at) && !(this.bot.position().distanceTo(Vec3.atCenterOf(at)) > (double)4.5F)) {
                     Vec3 flat = new Vec3((double)at.getX() + (double)0.5F - targetPos.x, (double)0.0F, (double)at.getZ() + (double)0.5F - targetPos.z);
                     if (!(flat.lengthSqr() < (double)0.25F)) {
                        double score = -flat.normalize().dot(facing);
                        if (!(score <= bestScore)) {
                           bestScore = score;
                           best = at;
                        }
                     }
                  }
               }
            }
         }

         return best;
      }
   }

   private BlockPos findPlacePosition(LivingEntity target) {
      Level level = this.bot.level();
      Vec3 targetPos = target.position();
      if (target.isBlocking()) {
         BlockPos behind = this.findPlaceBehindTarget(target);
         if (behind != null) {
            return behind;
         }
      }

      Vec3 dir = targetPos.subtract(this.bot.position()).normalize();

      for(double d = (double)2.0F; d <= (double)4.0F; d += (double)0.5F) {
         Vec3 cand = this.bot.position().add(dir.scale(d));
         BlockPos base = BlockPos.containing(cand.x, targetPos.y, cand.z);
         if (this.canPlaceAt(level, base)) {
            double distToBot = this.bot.position().distanceTo(Vec3.atCenterOf(base));
            if (distToBot <= (double)4.5F) {
               return base;
            }
         }

         base = BlockPos.containing(cand.x, targetPos.y - (double)1.0F, cand.z);
         if (this.canPlaceAt(level, base)) {
            double distToBot = this.bot.position().distanceTo(Vec3.atCenterOf(base));
            if (distToBot <= (double)4.5F) {
               return base;
            }
         }
      }

      for(int dx = -1; dx <= 1; ++dx) {
         for(int dz = -1; dz <= 1; ++dz) {
            BlockPos check = BlockPos.containing(targetPos.x + (double)dx, targetPos.y, targetPos.z + (double)dz);
            if (this.canPlaceAt(level, check)) {
               double distToBot = this.bot.position().distanceTo(Vec3.atCenterOf(check));
               if (distToBot <= (double)4.5F) {
                  return check;
               }
            }
         }
      }

      return null;
   }

   private BlockPos findSpamPlacePosition(LivingEntity target) {
      Level level = this.bot.level();
      Vec3 tp = target.position();
      BlockPos above = BlockPos.containing(tp.x, tp.y + (double)2.0F, tp.z);
      if (this.canPlaceAt(level, above) && this.bot.position().distanceTo(Vec3.atCenterOf(above)) <= (double)4.5F) {
         return above;
      } else {
         Vec3 toBot = this.bot.position().subtract(tp).normalize();

         for(double d = (double)1.0F; d <= (double)3.0F; d += (double)0.5F) {
            Vec3 cand = tp.add(toBot.scale(d));
            BlockPos bp = BlockPos.containing(cand.x, tp.y, cand.z);
            if (this.canPlaceAt(level, bp) && this.bot.position().distanceTo(Vec3.atCenterOf(bp)) <= (double)4.5F) {
               return bp;
            }

            bp = BlockPos.containing(cand.x, tp.y - (double)1.0F, cand.z);
            if (this.canPlaceAt(level, bp) && this.bot.position().distanceTo(Vec3.atCenterOf(bp)) <= (double)4.5F) {
               return bp;
            }
         }

         return this.findPlacePosition(target);
      }
   }

   private int countInInventory(Item item) {
      int count = 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(item)) {
            count += s.getCount();
         }
      }

      return count;
   }

   private boolean canPlaceAt(Level level, BlockPos pos) {
      if (!PlacementRaycasts.canSeePlacement(this.bot, pos)) {
         return false;
      } else if (!level.getBlockState(pos).isAir()) {
         return false;
      } else if (!level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) {
         return false;
      } else {
         ServerLevel sl = this.bot.level();
         return sl instanceof ServerLevel ? sl.getEntitiesOfClass(LivingEntity.class, (new AABB(pos)).inflate(0.1)).isEmpty() : true;
      }
   }

   private void kbLaunch(LivingEntity target) {
      EquipmentSync.syncNow(this.bot);
      this.bot.setSprinting(true);
      this.bot.attack(target);
      McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
   }

   private int getPlaceInterval(DifficultyParams params) {
      return params.anchorIntervalTicks;
   }

   private void finish() {
      if (this.active) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      if (this.active && this.mode == AnchorPvpController.Mode.CHAIN) {
         this.chainEnded = true;
      }

      this.active = false;
      this.cooldownLeft = this.anchorCooldown();
      this.lastRoundTick = -1000;
      this.roundsLeft = 0;
      this.mode = AnchorPvpController.Mode.SINGLE;
      this.chainWalkTicks = 0;
      this.roundCell = null;
      this.roundCharged = false;
   }

   private void aimAt(double x, double y, double z) {
      double dx = x - this.bot.getEyePosition().x;
      double dy = y - this.bot.getEyePosition().y;
      double dz = z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(BotMath.smoothBodyYaw(this.bot.getYRot(), yaw));
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private int ensureHotbar(int slot) {
      return InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), slot);
   }

   private int findInInventory(Item item) {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private void lookAt(Vec3 pos) {
      double dx = pos.x - this.bot.getEyePosition().x;
      double dy = pos.y - this.bot.getEyePosition().y;
      double dz = pos.z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(BotMath.smoothBodyYaw(this.bot.getYRot(), yaw));
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private static enum Mode {
      SINGLE,
      SPAM,
      CHAIN;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{SINGLE, SPAM, CHAIN};
      }
   }

   private static enum Step {
      BUSY,
      DONE,
      FAIL;

      // $FF: synthetic method
      private static Step[] $values() {
         return new Step[]{BUSY, DONE, FAIL};
      }
   }
}
