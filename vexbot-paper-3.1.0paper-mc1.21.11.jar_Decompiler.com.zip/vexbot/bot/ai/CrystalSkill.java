package vexbot.bot.ai;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.level.ServerPlayer;
import vexbot.EffectiveSettings;

final class CrystalSkill {
   private static final double[] SKIP_SESSION = new double[]{0.55, 0.35, 0.08, 0.03, (double)0.0F};
   private static final int[] HESITATE_TICKS = new int[]{40, 28, 12, 8, 0};
   private static final double[] BAD_SEAT = new double[]{0.65, 0.4, 0.1, 0.04, (double)0.0F};
   private static final double[] SELF_CARE = new double[]{0.45, 0.8, (double)1.25F, 1.35, 1.4};
   private static final double[] NO_INSTANT_HIT = new double[]{0.55, 0.35, 0.08, 0.03, (double)0.0F};
   private static final double[] FUMBLE = new double[]{0.35, 0.22, 0.05, 0.02, (double)0.0F};
   private static final int[] SESSION_GAP = new int[]{40, 26, 12, 10, 8};
   private static final double[] ANCHOR_DUD = new double[]{(double)0.25F, 0.12, 0.03, 0.01, (double)0.0F};
   private static final int[] MAX_ROUNDS = new int[]{2, 3, 6, 8, 8};

   private CrystalSkill() {
   }

   static int level(ServerPlayer bot) {
      int lvl = EffectiveSettings.of(bot.getScoreboardName()).difficultyParams().crystalPvpLevel;
      return Math.max(1, Math.min(5, lvl));
   }

   private static boolean roll(double chance) {
      return chance > (double)0.0F && ThreadLocalRandom.current().nextDouble() < chance;
   }

   static boolean skipSession(ServerPlayer bot) {
      return roll(SKIP_SESSION[level(bot) - 1]);
   }

   static int hesitateTicks(ServerPlayer bot) {
      return HESITATE_TICKS[level(bot) - 1];
   }

   static boolean badSeat(ServerPlayer bot) {
      return roll(BAD_SEAT[level(bot) - 1]);
   }

   static double selfCare(ServerPlayer bot) {
      return SELF_CARE[level(bot) - 1];
   }

   static boolean noInstantHit(ServerPlayer bot) {
      return roll(NO_INSTANT_HIT[level(bot) - 1]);
   }

   static boolean fumble(ServerPlayer bot) {
      return roll(FUMBLE[level(bot) - 1]);
   }

   static int sessionGap(ServerPlayer bot) {
      return SESSION_GAP[level(bot) - 1];
   }

   static boolean anchorDud(ServerPlayer bot) {
      return roll(ANCHOR_DUD[level(bot) - 1]);
   }

   static int maxRounds(ServerPlayer bot) {
      return MAX_ROUNDS[level(bot) - 1];
   }
}
