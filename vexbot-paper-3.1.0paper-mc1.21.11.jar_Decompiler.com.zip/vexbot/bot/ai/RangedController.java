package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class RangedController {
   private static final int FULL_DRAW_TICKS = 20;
   private static final int CROSSBOW_LOAD_TICKS = 30;
   private static final float SHOOT_FACING_TOL = 15.0F;
   public static final double MAX_RANGE = (double)35.0F;
   private final ServerPlayer bot;
   private int drawTicks = 0;
   private boolean isDrawing = false;
   private int loadTicks = 0;
   private int crossbowCooldown = 0;

   public RangedController(ServerPlayer bot) {
      this.bot = bot;
   }

   public boolean tick(LivingEntity target, WeaponSelector.WeaponType type) {
      double dist = (double)this.bot.distanceTo(target);
      if (dist > (double)35.0F) {
         this.stopUsing();
         return false;
      } else {
         this.aimAtTarget(target);
         boolean var10000;
         switch (type) {
            case BOW -> var10000 = this.tickBow(target);
            case CROSSBOW -> var10000 = this.tickCrossbow(target);
            default -> var10000 = false;
         }

         return var10000;
      }
   }

   public void reset() {
      this.stopUsing();
   }

   public void tickPreload() {
      ItemStack held = this.bot.getMainHandItem();
      if (held.is(Items.CROSSBOW)) {
         if (CrossbowItem.isCharged(held)) {
            if (this.isDrawing && this.bot.isUsingItem() && this.bot.getUseItem().is(Items.CROSSBOW)) {
               this.bot.stopUsingItem();
            }

            this.isDrawing = false;
            this.loadTicks = 0;
         } else {
            if (this.isDrawing && !this.bot.isUsingItem()) {
               this.isDrawing = false;
               this.loadTicks = 0;
            }

            if (!this.isDrawing) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
               this.isDrawing = true;
               this.loadTicks = 0;
            }

            ++this.loadTicks;
            if (this.loadTicks >= 30) {
               this.bot.releaseUsingItem();
               this.isDrawing = false;
               this.loadTicks = 0;
            }

         }
      }
   }

   private boolean tickBow(LivingEntity target) {
      if (this.isDrawing && (!this.bot.isUsingItem() || !this.bot.getUseItem().is(Items.BOW))) {
         this.isDrawing = false;
         this.drawTicks = 0;
      }

      if (!this.isDrawing) {
         this.bot.startUsingItem(InteractionHand.MAIN_HAND);
         this.isDrawing = true;
         this.drawTicks = 0;
      }

      ++this.drawTicks;
      if (this.drawTicks >= 20 && this.isFacingTarget(target, 15.0F)) {
         this.bot.releaseUsingItem();
         this.isDrawing = false;
         this.drawTicks = 0;
      }

      return true;
   }

   private boolean tickCrossbow(LivingEntity target) {
      if (this.crossbowCooldown > 0) {
         --this.crossbowCooldown;
         return true;
      } else {
         ItemStack held = CrossbowHelper.selectedStack(this.bot);
         if (!CrossbowItem.isCharged(held)) {
            if (this.isDrawing && !this.bot.isUsingItem()) {
               this.isDrawing = false;
               this.loadTicks = 0;
            }

            if (!this.isDrawing) {
               this.bot.startUsingItem(InteractionHand.MAIN_HAND);
               this.isDrawing = true;
               this.loadTicks = 0;
            }

            ++this.loadTicks;
            if (this.loadTicks >= 30) {
               this.bot.releaseUsingItem();
               this.isDrawing = false;
               this.loadTicks = 0;
            }

            return true;
         } else {
            this.isDrawing = false;
            this.loadTicks = 0;
            if (this.isFacingTarget(target, 15.0F)) {
               if (CrossbowHelper.fireIfCharged(this.bot)) {
                  this.crossbowCooldown = 35;
               } else {
                  CrossbowHelper.clearCharge(this.bot);
               }
            }

            return true;
         }
      }
   }

   private void aimAtTarget(LivingEntity target) {
      double eyeX = this.bot.getEyePosition().x;
      double eyeY = this.bot.getEyePosition().y;
      double eyeZ = this.bot.getEyePosition().z;
      double dx = target.getX() - eyeX;
      double dz = target.getZ() - eyeZ;
      double horizDist = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      double flightTime = horizDist / (double)3.0F;
      double gravComp = 0.025 * flightTime * flightTime;
      double adjustedDy = target.getEyeY() - eyeY + gravComp;
      float pitch = (float)(-Math.toDegrees(Math.atan2(adjustedDy, horizDist)));
      pitch = Mth.clamp(pitch, -90.0F, 90.0F);
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private boolean isFacingTarget(LivingEntity target, float toleranceDeg) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      float requiredYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      return Math.abs(Mth.wrapDegrees(this.bot.getYRot() - requiredYaw)) < toleranceDeg;
   }

   private void stopUsing() {
      if (this.isDrawing || this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      this.isDrawing = false;
      this.drawTicks = 0;
      this.loadTicks = 0;
      this.crossbowCooldown = 0;
   }
}
