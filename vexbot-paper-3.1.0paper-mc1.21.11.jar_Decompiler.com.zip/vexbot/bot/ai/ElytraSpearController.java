package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.KineticWeapon;
import net.minecraft.world.phys.Vec3;
import vexbot.VexBot;
import vexbot.util.BotCommands;
import vexbot.util.ElytraFlight;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.VexLog;

public final class ElytraSpearController {
   private static final double TRIGGER_RANGE = (double)24.0F;
   private static final double AIR_TRIGGER_RANGE = (double)60.0F;
   private static final int MIN_ROCKETS = 2;
   private static final int APPROACH_ROCKET_INTERVAL = 60;
   private static final int RETREAT_ROCKET_INTERVAL = 12;
   private static final int EQUIP_SETTLE_TICKS = 3;
   private static final int FLY_MAX_TICKS = 1200;
   private static final int MAX_PHASE_TICKS = 60;
   private static final int COOLDOWN_TICKS = 60;
   private static final int CHARGE_LEAD_TICKS = 30;
   private static final double CLOSE_RANGE = (double)6.0F;
   private static final double MIN_CLOSING_SPEED = 0.05;
   private static final double RUN_UP_DIST = (double)18.0F;
   private static final double RUN_UP_ALT = (double)8.0F;
   private static final int MIN_MODE_TICKS = 8;
   private static final int RETREAT_MAX_TICKS = 70;
   private static final double PASS_REACH = (double)3.5F;
   private static final float CLIMB_PITCH = -38.0F;
   private static final float MAX_DIVE_PITCH = 35.0F;
   private static final double ALT_FLOOR = (double)5.0F;
   private static final float MAX_YAW_STEP = 13.0F;
   private static final float MAX_PITCH_STEP = 9.0F;
   private static final int GLIDE_DOWN_MAX_TICKS = 400;
   private static final float GLIDE_DOWN_PITCH = 20.0F;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int lastRocketTick;
   private boolean chargeBoostDone;
   private FlyMode flyMode;
   private int modeTick;
   private double minApproach;
   private boolean headingFrozen;
   private float frozenYaw;
   private float frozenPitch;
   private int spearSlot;
   private int chestSaveSlot;
   private int elytraFromSlot;
   private int prevSelected;
   private boolean hadOriginalChestplate;
   private final ElytraObstacleGuard.CrashDetector crashGuard;
   private final ServerPlayer bot;
   private final MinecraftServer server;

   public ElytraSpearController(ServerPlayer bot, MinecraftServer server) {
      this.phase = ElytraSpearController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldown = 0;
      this.lastRocketTick = -100;
      this.chargeBoostDone = false;
      this.flyMode = ElytraSpearController.FlyMode.RETREAT;
      this.modeTick = 0;
      this.minApproach = Double.MAX_VALUE;
      this.headingFrozen = false;
      this.frozenYaw = 0.0F;
      this.frozenPitch = 0.0F;
      this.spearSlot = -1;
      this.chestSaveSlot = -1;
      this.elytraFromSlot = -1;
      this.prevSelected = 0;
      this.hadOriginalChestplate = false;
      this.crashGuard = new ElytraObstacleGuard.CrashDetector();
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target, dist);
         case 1 -> var10000 = this.tickEquipping();
         case 2 -> var10000 = this.tickLaunching();
         case 3 -> var10000 = this.tickFlying(target);
         case 4 -> var10000 = this.tickGlideDown();
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void reset() {
      if (this.phase != ElytraSpearController.Phase.IDLE) {
         this.abort();
      }

   }

   public boolean isExecuting() {
      return this.phase != ElytraSpearController.Phase.IDLE;
   }

   public boolean hasGearForCombo() {
      return this.findSpearAnywhere() >= 0 && this.findElytraInInventory() >= 0 && this.countItem(Items.FIREWORK_ROCKET) >= 2;
   }

   private boolean tickIdle(LivingEntity target, double dist) {
      this.ensureChestplateOnGround();
      if (target != null && target.isAlive()) {
         if (this.cooldown > 0) {
            return false;
         } else if (!this.bot.onGround()) {
            return false;
         } else {
            boolean targetAir = this.isTargetAirborne(target);
            if (targetAir) {
               if (dist > (double)60.0F) {
                  return false;
               }
            } else if (dist > (double)24.0F) {
               return false;
            }

            if (this.countItem(Items.FIREWORK_ROCKET) < 2) {
               return false;
            } else if (this.findSpearAnywhere() < 0) {
               return false;
            } else {
               ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
               if (chest.is(Items.ELYTRA)) {
                  return false;
               } else {
                  this.elytraFromSlot = this.findElytraInInventory();
                  if (this.elytraFromSlot < 0) {
                     return false;
                  } else {
                     this.hadOriginalChestplate = !chest.isEmpty();
                     this.prevSelected = InventoryUtils.selected(this.bot.getInventory());
                     this.enterPhase(ElytraSpearController.Phase.EQUIPPING);
                     return true;
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   private boolean tickEquipping() {
      ++this.phaseTick;
      if (this.phaseTick > 60) {
         this.abort();
         return false;
      } else if (this.elytraFromSlot == -1) {
         this.enterPhase(ElytraSpearController.Phase.LAUNCHING);
         return true;
      } else {
         if (this.phaseTick == 1) {
            ItemStack currentChest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
            ItemStack elytra = this.bot.getInventory().getItem(this.elytraFromSlot).copy();
            this.bot.getInventory().setItem(this.elytraFromSlot, ItemStack.EMPTY);
            this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            if (!currentChest.isEmpty()) {
               this.chestSaveSlot = this.findFreeHotbarSlot();
               if (this.chestSaveSlot < 0) {
                  this.chestSaveSlot = this.elytraFromSlot;
               }

               this.bot.getInventory().setItem(this.chestSaveSlot, currentChest.copy());
            } else {
               this.chestSaveSlot = -1;
            }
         }

         if (this.phaseTick < 3) {
            return true;
         } else {
            ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
            if (!chest.is(Items.ELYTRA)) {
               this.abort();
               return false;
            } else {
               this.enterPhase(ElytraSpearController.Phase.LAUNCHING);
               return true;
            }
         }
      }
   }

   private boolean tickLaunching() {
      ++this.phaseTick;
      if (this.phaseTick > 30) {
         this.abort();
         return false;
      } else {
         String name = this.bot.getScoreboardName();
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
         if (this.bot.onGround()) {
            BotCommands.jumpOnce(this.server, name);
            return true;
         } else if (!this.bot.isFallFlying()) {
            BotCommands.jumpOnce(this.server, name);
            return true;
         } else {
            this.spearSlot = this.ensureSpearInHotbar();
            if (this.spearSlot < 0) {
               this.abort();
               return false;
            } else {
               this.flyMode = ElytraSpearController.FlyMode.RETREAT;
               this.modeTick = 0;
               this.minApproach = Double.MAX_VALUE;
               this.headingFrozen = false;
               this.chargeBoostDone = false;
               this.lastRocketTick = -100;
               this.enterPhase(ElytraSpearController.Phase.FLYING);
               return true;
            }
         }
      }
   }

   private boolean tickFlying(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 1200) {
            this.abort();
            return false;
         } else {
            this.spearSlot = this.ensureSpearInHotbar();
            if (this.spearSlot < 0) {
               this.abort();
               return false;
            } else {
               InventoryUtils.select(this.bot.getInventory(), this.spearSlot);
               EquipmentSync.syncNow(this.bot);
               BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
               this.bot.setSprinting(false);
               if (this.phaseTick == 1) {
                  float yaw = this.yawAwayFrom(target);
                  this.bot.setYRot(yaw);
                  this.bot.yHeadRot = yaw;
                  this.bot.setXRot(-38.0F);
               }

               int rockets = this.countItem(Items.FIREWORK_ROCKET);
               double dist = (double)this.bot.distanceTo(target);
               double speed = this.bot.getDeltaMovement().length();
               double clearance = this.groundClearance();
               this.engageFallFlying();
               if (this.bot.onGround()) {
                  BotCommands.jumpOnce(this.server, this.bot.getScoreboardName());
               }

               boolean gliding = this.bot.isFallFlying() && !this.bot.onGround();
               ++this.modeTick;
               boolean climbing = clearance < (double)5.0F;
               float desiredYaw;
               float desiredPitch;
               if (this.flyMode == ElytraSpearController.FlyMode.RETREAT) {
                  if (this.bot.isUsingItem()) {
                     this.bot.stopUsingItem();
                  }

                  this.chargeBoostDone = false;
                  this.headingFrozen = false;
                  desiredYaw = this.yawAwayFrom(target);
                  desiredPitch = -38.0F;
                  if (gliding && rockets > 0 && this.phaseTick - this.lastRocketTick >= 12) {
                     this.fireRocket();
                     this.lastRocketTick = this.phaseTick;
                  }

                  double horiz = this.horizontalDist(target);
                  boolean ready = this.modeTick >= 8 && (horiz >= (double)18.0F && clearance >= (double)8.0F || this.modeTick > 70);
                  if (ready && !climbing) {
                     this.flyMode = ElytraSpearController.FlyMode.APPROACH;
                     this.modeTick = 0;
                     this.minApproach = Double.MAX_VALUE;
                     this.headingFrozen = false;
                  }
               } else {
                  this.minApproach = Math.min(this.minApproach, dist);
                  Vec3 rel = this.bot.getDeltaMovement().subtract(target.getDeltaMovement());
                  Vec3 toT = target.position().subtract(this.bot.position());
                  double len = toT.length();
                  double closing = len > 1.0E-4 ? rel.dot(toT.scale((double)1.0F / len)) : (double)0.0F;
                  double etaTicks = closing > 0.05 ? dist / closing : Double.MAX_VALUE;
                  boolean chargeNow = etaTicks <= (double)30.0F || dist <= (double)6.0F;
                  if (!this.headingFrozen && dist <= (double)6.0F) {
                     this.headingFrozen = true;
                     this.frozenYaw = this.yawToward(target);
                     this.frozenPitch = clampPitch(this.pitchToward(target), 35.0F);
                  }

                  if (this.headingFrozen) {
                     desiredYaw = this.frozenYaw;
                     desiredPitch = this.frozenPitch;
                  } else {
                     desiredYaw = this.yawToward(target);
                     desiredPitch = clampPitch(this.pitchToward(target), 35.0F);
                  }

                  if (chargeNow) {
                     if (!this.chargeBoostDone) {
                        if (this.bot.isUsingItem()) {
                           this.bot.stopUsingItem();
                        }

                        if (gliding && rockets > 0) {
                           this.fireRocket();
                           this.lastRocketTick = this.phaseTick;
                        }

                        this.chargeBoostDone = true;
                     } else {
                        if (!this.bot.isUsingItem()) {
                           this.bot.startUsingItem(InteractionHand.MAIN_HAND);
                        }

                        this.doSpearChargeDamage();
                     }
                  } else {
                     if (this.bot.isUsingItem()) {
                        this.bot.stopUsingItem();
                     }

                     this.chargeBoostDone = false;
                     if (gliding && rockets > 0 && this.phaseTick - this.lastRocketTick >= 60) {
                        this.fireRocket();
                        this.lastRocketTick = this.phaseTick;
                     }
                  }

                  boolean passed = this.modeTick >= 8 && (dist <= (double)3.5F || this.minApproach < (double)7.0F && dist > this.minApproach + (double)3.0F);
                  if (passed) {
                     if (this.bot.isUsingItem()) {
                        this.bot.stopUsingItem();
                     }

                     this.flyMode = ElytraSpearController.FlyMode.RETREAT;
                     this.modeTick = 0;
                     this.headingFrozen = false;
                  }
               }

               if (climbing) {
                  desiredPitch = -38.0F;
               }

               float[] safe = ElytraObstacleGuard.avoid(this.bot, desiredYaw, desiredPitch);
               desiredYaw = safe[0];
               desiredPitch = safe[1];
               this.steer(desiredYaw, desiredPitch);
               if (this.crashGuard.crashed(this.bot)) {
                  VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' flew into something — breaking off the elytra run", this.bot.getScoreboardName());
                  this.abort();
                  return false;
               } else if (rockets == 0 && speed < 0.6) {
                  this.abort();
                  return false;
               } else {
                  return true;
               }
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private void steer(float desiredYaw, float desiredPitch) {
      float curYaw = this.bot.getYRot();
      float yawDiff = Mth.degreesDifference(curYaw, desiredYaw);
      float yawStep = Mth.clamp(yawDiff, -13.0F, 13.0F);
      float newYaw = Mth.wrapDegrees(curYaw + yawStep);
      float curPitch = this.bot.getXRot();
      float pitchDiff = desiredPitch - curPitch;
      float pitchStep = Mth.clamp(pitchDiff, -9.0F, 9.0F);
      float newPitch = Mth.clamp(curPitch + pitchStep, -90.0F, 90.0F);
      this.bot.setYRot(newYaw);
      this.bot.setXRot(newPitch);
      this.bot.yHeadRot = newYaw;
   }

   private float yawToward(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      return dx * dx + dz * dz < 1.0E-4 ? this.bot.getYRot() : (float)Math.toDegrees(Math.atan2(-dx, dz));
   }

   private float yawAwayFrom(LivingEntity target) {
      double dx = this.bot.getX() - target.getX();
      double dz = this.bot.getZ() - target.getZ();
      return dx * dx + dz * dz < 1.0E-4 ? this.bot.getYRot() : (float)Math.toDegrees(Math.atan2(-dx, dz));
   }

   private float pitchToward(LivingEntity target) {
      double dx = target.getX() - this.bot.getEyePosition().x;
      double dy = target.getEyeY() - this.bot.getEyePosition().y;
      double dz = target.getZ() - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      return (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
   }

   private static float clampPitch(float pitch, float maxDown) {
      return Mth.clamp(pitch, -90.0F, maxDown);
   }

   private double groundClearance() {
      ServerLevel level = this.bot.level();
      BlockPos base = this.bot.blockPosition();

      for(int i = 0; i < 24; ++i) {
         BlockPos p = base.below(i);
         if (!level.getBlockState(p).isAir()) {
            return this.bot.getY() - (double)(p.getY() + 1);
         }
      }

      return (double)24.0F;
   }

   private void doSpearChargeDamage() {
      ItemStack spear = this.bot.getInventory().getItem(this.spearSlot);
      if (spear.is(ItemTags.SPEARS)) {
         KineticWeapon kw = (KineticWeapon)spear.get(DataComponents.KINETIC_WEAPON);
         if (kw != null) {
            int useDur = spear.getUseDuration(this.bot);
            int i = useDur - (kw.delayTicks() + 1);
            if (i < 0) {
               i = 0;
            }

            kw.damageEntities(spear, i, this.bot, EquipmentSlot.MAINHAND);
         }
      }
   }

   private void abort() {
      this.crashGuard.reset();
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      if (!this.bot.onGround()) {
         this.enterPhase(ElytraSpearController.Phase.GLIDE_DOWN);
      } else {
         this.restoreChest();
         InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
         this.cooldown = 60;
         this.enterPhase(ElytraSpearController.Phase.IDLE);
      }
   }

   private boolean tickGlideDown() {
      ++this.phaseTick;
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      if (this.phaseTick > 400) {
         this.forceGroundReset();
         return false;
      } else if (this.bot.onGround()) {
         this.forceGroundReset();
         return false;
      } else {
         ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         if (!chest.is(Items.ELYTRA)) {
            int elytraSlot = this.findElytraInInventory();
            if (elytraSlot >= 0) {
               ItemStack worn = chest.copy();
               ItemStack elytra = this.bot.getInventory().getItem(elytraSlot).copy();
               this.bot.getInventory().setItem(elytraSlot, worn);
               this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            }
         }

         this.engageFallFlying();
         this.bot.setXRot(20.0F);
         this.bot.yHeadRot = this.bot.getYRot();
         BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
         this.bot.setSprinting(false);
         return true;
      }
   }

   private void forceGroundReset() {
      if (this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      if (this.bot.isFallFlying()) {
         this.bot.stopFallFlying();
      }

      if (this.bot.onGround()) {
         this.ensureChestplateOnGround();
      } else {
         this.restoreChest();
      }

      InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
      this.cooldown = 60;
      this.enterPhase(ElytraSpearController.Phase.IDLE);
   }

   private void enterPhase(Phase p) {
      this.phase = p;
      this.phaseTick = 0;
   }

   private void engageFallFlying() {
      if (!this.bot.isFallFlying()) {
         ElytraFlight.beginGlide(this.bot);
      }

   }

   private double horizontalDist(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      return Math.sqrt(dx * dx + dz * dz);
   }

   private void fireRocket() {
      Inventory inv = this.bot.getInventory();
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
            slot = i;
            break;
         }
      }

      if (slot < 0) {
         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
               slot = i;
               break;
            }
         }

         if (slot < 0) {
            return;
         }

         slot = InventoryUtils.moveToHotbarSafe(inv, slot);
      }

      int prev = InventoryUtils.selected(inv);
      InventoryUtils.select(inv, slot);
      this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(slot), InteractionHand.MAIN_HAND);
      InventoryUtils.select(inv, prev);
   }

   private void restoreChest() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (chest.is(Items.ELYTRA)) {
         ItemStack elytra = chest.copy();
         if (this.hadOriginalChestplate && this.chestSaveSlot >= 0) {
            ItemStack toWear = this.bot.getInventory().getItem(this.chestSaveSlot).copy();
            if (ArmorEvaluator.getSlot(toWear) == EquipmentSlot.CHEST && !toWear.is(Items.ELYTRA)) {
               this.bot.setItemSlot(EquipmentSlot.CHEST, toWear);
               this.bot.getInventory().setItem(this.chestSaveSlot, elytra);
               return;
            }
         }

         int plateSlot = this.findBestChestplateInInventory();
         if (plateSlot >= 0) {
            this.bot.setItemSlot(EquipmentSlot.CHEST, this.bot.getInventory().getItem(plateSlot).copy());
            this.bot.getInventory().setItem(plateSlot, elytra);
         } else {
            int elytraStore = this.findElytraStoreSlot();
            if (elytraStore < 0) {
               return;
            }

            this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
            this.bot.getInventory().setItem(elytraStore, elytra);
         }

      }
   }

   private void ensureChestplateOnGround() {
      if (this.bot.onGround()) {
         ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         if (chest.is(Items.ELYTRA)) {
            if (this.bot.isFallFlying()) {
               this.bot.stopFallFlying();
            }

            int plateSlot = this.findBestChestplateInInventory();
            ItemStack elytra = chest.copy();
            if (plateSlot >= 0) {
               this.bot.setItemSlot(EquipmentSlot.CHEST, this.bot.getInventory().getItem(plateSlot).copy());
               this.bot.getInventory().setItem(plateSlot, elytra);
            } else {
               int store = this.findElytraStoreSlot();
               if (store >= 0) {
                  this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                  this.bot.getInventory().setItem(store, elytra);
               }
            }
         }
      }
   }

   private int ensureSpearInHotbar() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.SPEARS)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(ItemTags.SPEARS)) {
            return InventoryUtils.moveToHotbarSafe(inv, i);
         }
      }

      return -1;
   }

   private int findSpearAnywhere() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(ItemTags.SPEARS)) {
            return i;
         }
      }

      return -1;
   }

   private int findBestChestplateInInventory() {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestScore = (double)-1.0F;

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (ArmorEvaluator.getSlot(s) == EquipmentSlot.CHEST) {
            double score = ArmorEvaluator.score(s);
            if (score > bestScore) {
               bestScore = score;
               best = i;
            }
         }
      }

      return best;
   }

   private int findElytraInInventory() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (ElytraFlight.isUsable(s)) {
            return i;
         }
      }

      return -1;
   }

   private int findFreeHotbarSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).isEmpty()) {
            return i;
         }
      }

      return -1;
   }

   private int findElytraStoreSlot() {
      int slot = this.findFreeHotbarSlot();
      if (slot >= 0) {
         return slot;
      } else {
         Inventory inv = this.bot.getInventory();

         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).isEmpty()) {
               return i;
            }
         }

         return -1;
      }
   }

   private boolean isTargetAirborne(LivingEntity target) {
      if (target != null && !target.onGround()) {
         if (target.isFallFlying()) {
            return true;
         } else if (target.isAutoSpinAttack()) {
            return true;
         } else {
            return target.getY() - this.bot.getY() > (double)4.0F;
         }
      } else {
         return false;
      }
   }

   private int countItem(Item item) {
      int total = 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(item)) {
            total += s.getCount();
         }
      }

      return total;
   }

   private static enum Phase {
      IDLE,
      EQUIPPING,
      LAUNCHING,
      FLYING,
      GLIDE_DOWN;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, EQUIPPING, LAUNCHING, FLYING, GLIDE_DOWN};
      }
   }

   private static enum FlyMode {
      RETREAT,
      APPROACH;

      // $FF: synthetic method
      private static FlyMode[] $values() {
         return new FlyMode[]{RETREAT, APPROACH};
      }
   }
}
