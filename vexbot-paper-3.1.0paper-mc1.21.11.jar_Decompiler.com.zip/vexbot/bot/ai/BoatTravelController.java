package vexbot.bot.ai;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.item.BoatItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

public final class BoatTravelController {
   private static final double MIN_DIST = (double)6.0F;
   private static final double MAX_DIST = (double)32.0F;
   private static final double MAX_DY = (double)2.5F;
   private static final int WATER_SAMPLES = 5;
   private static final double ARRIVE_DIST = (double)3.5F;
   private static final double LEAD_ARRIVE = (double)2.0F;
   private static final double BOAT_SPEED = 0.35;
   private static final int MAX_LEAD_TICKS = 40;
   private static final double LEAD_EXTRA = (double)1.5F;
   private static final int DRIVE_STUCK_TICKS = 80;
   private static final int MOUNT_TIMEOUT = 20;
   private static final int PICKUP_TIMEOUT = 20;
   private static final double FIGHT_FIRST = (double)4.5F;
   private static final int ABORT_COOLDOWN = 200;
   private static final int DONE_COOLDOWN = 60;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private Phase phase = null;
   private AbstractBoat boat = null;
   private int phaseTicks = 0;
   private int cooldown = 0;
   private double bestDist = Double.POSITIVE_INFINITY;
   private int noProgress = 0;
   private Vec3 breakPos = null;
   private Vec3 lastTargetPos = null;
   private Vec3 targetVel;

   public BoatTravelController(ServerPlayer bot, MinecraftServer server) {
      this.targetVel = Vec3.ZERO;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isActive() {
      return this.phase != null;
   }

   public void reset() {
      if (this.phase != null) {
         BotCommands.stopMoving(this.server, this.botName);
         Entity var2 = this.bot.getVehicle();
         if (var2 instanceof AbstractBoat) {
            AbstractBoat b = (AbstractBoat)var2;
            this.bot.stopRiding();
            this.scuttle(b);
         } else if (this.boat != null && this.boat.isAlive()) {
            this.scuttle(this.boat);
         }
      }

      this.phase = null;
      this.boat = null;
      this.phaseTicks = 0;
      this.bestDist = Double.POSITIVE_INFINITY;
      this.noProgress = 0;
      this.breakPos = null;
      this.lastTargetPos = null;
      this.targetVel = Vec3.ZERO;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (target != null && target.isAlive()) {
         this.trackTarget(target);
         if (this.phase == null) {
            if (this.cooldown > 0 || dist < (double)6.0F || dist > (double)32.0F) {
               return false;
            }

            if (Math.abs(target.getY() - this.bot.getY()) > (double)2.5F) {
               return false;
            }

            if (!this.bot.onGround() && !this.bot.isInWater()) {
               return false;
            }

            if (this.findBoatItemSlot() < 0) {
               return false;
            }

            if (!this.openWaterToward(target)) {
               return false;
            }

            this.phase = BoatTravelController.Phase.PLACE;
            this.phaseTicks = 0;
         }

         ++this.phaseTicks;
         switch (this.phase.ordinal()) {
            case 0 -> this.tickPlace(target);
            case 1 -> this.tickMount();
            case 2 -> this.tickDrive(target);
            case 3 -> this.tickBreak();
            case 4 -> this.tickPickup(target);
         }

         return this.phase != null;
      } else {
         this.reset();
         return false;
      }
   }

   private void tickPlace(LivingEntity target) {
      BotCommands.stopMoving(this.server, this.botName);
      int slot = this.findBoatItemSlot();
      if (slot < 0) {
         this.abort();
      } else {
         this.faceToward(target.position(), 30.0F);
         InteractionHand hand = InteractionHand.MAIN_HAND;
         if (slot == 40) {
            hand = InteractionHand.OFF_HAND;
         } else {
            Inventory inv = this.bot.getInventory();
            InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, slot));
         }

         ItemStack stack = hand == InteractionHand.OFF_HAND ? this.bot.getOffhandItem() : this.bot.getMainHandItem();
         if (stack.getItem() instanceof BoatItem) {
            McCompat.swing(this.bot, hand);
            this.bot.gameMode.useItem(this.bot, this.bot.level(), stack, hand);
         }

         this.phase = BoatTravelController.Phase.MOUNT;
         this.phaseTicks = 0;
      }
   }

   private void tickMount() {
      AbstractBoat b = this.nearestEmptyBoat((double)4.0F, this.phaseTicks + 5);
      if (b != null && this.bot.startRiding(b, true, true)) {
         this.boat = b;
         this.phase = BoatTravelController.Phase.DRIVE;
         this.phaseTicks = 0;
         this.bestDist = Double.POSITIVE_INFINITY;
         this.noProgress = 0;
      } else {
         if (this.phaseTicks > 20) {
            this.abort();
         }

      }
   }

   private void tickDrive(LivingEntity target) {
      Entity var3 = this.bot.getVehicle();
      if (var3 instanceof AbstractBoat b) {
         this.boat = b;
         double dist = (double)this.bot.distanceTo(target);
         if (dist < this.bestDist - (double)0.25F) {
            this.bestDist = dist;
            this.noProgress = 0;
         } else if (++this.noProgress > 80) {
            this.disembark();
            return;
         }

         Vec3 lead = this.leadPoint(target, dist);
         double toLead = Math.hypot(lead.x - b.getX(), lead.z - b.getZ());
         if (!(dist <= (double)3.5F) && (!(toLead <= (double)2.0F) || !(dist <= (double)8.0F)) && !this.shoreAhead(b, lead)) {
            double dx = lead.x - b.getX();
            double dz = lead.z - b.getZ();
            float desiredYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
            float diff = Mth.wrapDegrees(desiredYaw - b.getYRot());
            float strafe = diff < -5.0F ? 1.0F : (diff > 5.0F ? -1.0F : 0.0F);
            BotCommands.setMovement(this.server, this.botName, 1.0F, strafe);
            this.faceToward(target.position(), 10.0F);
         } else {
            this.disembark();
         }
      } else {
         this.phase = this.boat != null && this.boat.isAlive() ? BoatTravelController.Phase.BREAK : null;
         if (this.phase == null) {
            this.cooldown = 200;
         }

         this.phaseTicks = 0;
      }
   }

   private void tickBreak() {
      BotCommands.stopMoving(this.server, this.botName);
      if (this.boat != null && this.boat.isAlive()) {
         this.faceToward(this.boat.position(), 25.0F);
         this.breakPos = this.boat.position();
         float dmg = 15.0F;
         int tool = this.findBoatBreakTool();
         if (tool >= 0) {
            Inventory inv = this.bot.getInventory();
            InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, tool));
            dmg = WeaponSelector.getType(inv.getItem(InventoryUtils.selected(inv))) == WeaponSelector.WeaponType.AXE ? 45.0F : 25.0F;
         }

         if (this.phaseTicks % 4 == 1) {
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            this.boat.hurtServer(this.bot.level(), this.bot.level().damageSources().playerAttack(this.bot), dmg);
         }

         if (this.phaseTicks > 40) {
            this.boat = null;
            this.finish();
         }

      } else {
         this.phase = BoatTravelController.Phase.PICKUP;
         this.phaseTicks = 0;
      }
   }

   private int findBoatBreakTool() {
      Inventory inv = this.bot.getInventory();
      int sword = -1;

      for(int i = 0; i < 36; ++i) {
         WeaponSelector.WeaponType t = WeaponSelector.getType(inv.getItem(i));
         if (t == WeaponSelector.WeaponType.AXE) {
            return i;
         }

         if (t == WeaponSelector.WeaponType.SWORD && sword < 0) {
            sword = i;
         }
      }

      return sword;
   }

   private void tickPickup(LivingEntity target) {
      ItemEntity drop = this.ourBoatDrop();
      if (drop != null && this.phaseTicks <= 20 && !((double)this.bot.distanceTo(target) <= (double)4.5F)) {
         Vec3 dpos = drop.position();
         if (this.bot.position().distanceTo(dpos) > 1.1) {
            this.faceToward(dpos, 20.0F);
            BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
         } else {
            BotCommands.stopMoving(this.server, this.botName);
         }

      } else {
         this.finish();
      }
   }

   private void disembark() {
      Entity var3 = this.bot.getVehicle();
      AbstractBoat var10000;
      if (var3 instanceof AbstractBoat vb) {
         var10000 = vb;
      } else {
         var10000 = this.boat;
      }

      AbstractBoat b = var10000;
      BotCommands.stopMoving(this.server, this.botName);
      this.bot.stopRiding();
      this.boat = b;
      this.phase = BoatTravelController.Phase.BREAK;
      this.phaseTicks = 0;
   }

   private void finish() {
      this.phase = null;
      this.boat = null;
      this.breakPos = null;
      this.cooldown = 60;
      BotCommands.stopMoving(this.server, this.botName);
   }

   private void abort() {
      this.phase = null;
      this.boat = null;
      this.cooldown = 200;
      BotCommands.stopMoving(this.server, this.botName);
   }

   private void scuttle(AbstractBoat b) {
      try {
         b.hurtServer(this.bot.level(), this.bot.level().damageSources().playerAttack(this.bot), 100.0F);
      } catch (Throwable var3) {
      }

      this.boat = null;
   }

   private boolean openWaterToward(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dz = target.getZ() - this.bot.getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len < 0.001) {
         return false;
      } else {
         dx /= len;
         dz /= len;
         int water = 0;

         for(int i = 2; i <= 8; ++i) {
            BlockPos p = BlockPos.containing(this.bot.getX() + dx * (double)i, this.bot.getY(), this.bot.getZ() + dz * (double)i);
            if (this.isWaterAt(p) || this.isWaterAt(p.below()) || this.isWaterAt(p.below(2))) {
               ++water;
            }
         }

         return water >= 5;
      }
   }

   private boolean shoreAhead(AbstractBoat b, Vec3 toward) {
      double dx = toward.x - b.getX();
      double dz = toward.z - b.getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len < 0.001) {
         return false;
      } else {
         dx /= len;
         dz /= len;
         BlockPos ahead = BlockPos.containing(b.getX() + dx * (double)2.0F, b.getY(), b.getZ() + dz * (double)2.0F);
         boolean landAhead = !this.isWaterAt(ahead) && !this.isWaterAt(ahead.below()) && !this.bot.level().getBlockState(ahead.below()).getCollisionShape(this.bot.level(), ahead.below()).isEmpty();
         return landAhead || b.horizontalCollision;
      }
   }

   private boolean isWaterAt(BlockPos p) {
      return this.bot.level().getFluidState(p).is(FluidTags.WATER);
   }

   private int findBoatItemSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).getItem() instanceof BoatItem) {
            return i;
         }
      }

      if (this.bot.getOffhandItem().getItem() instanceof BoatItem) {
         return 40;
      } else {
         return -1;
      }
   }

   private AbstractBoat nearestEmptyBoat(double r, int maxAge) {
      List<AbstractBoat> boats = this.bot.level().getEntitiesOfClass(AbstractBoat.class, this.bot.getBoundingBox().inflate(r), (bx) -> bx.isAlive() && bx.getPassengers().isEmpty() && bx.tickCount <= maxAge);
      AbstractBoat best = null;
      double bestD = Double.MAX_VALUE;

      for(AbstractBoat b : boats) {
         double d = this.bot.distanceToSqr(b);
         if (d < bestD) {
            bestD = d;
            best = b;
         }
      }

      return best;
   }

   private ItemEntity ourBoatDrop() {
      if (this.breakPos == null) {
         return null;
      } else {
         List<ItemEntity> items = this.bot.level().getEntitiesOfClass(ItemEntity.class, (new AABB(this.breakPos, this.breakPos)).inflate((double)2.0F), (itx) -> itx.isAlive() && itx.tickCount < 60 && itx.getItem().getItem() instanceof BoatItem);
         ItemEntity best = null;
         double bestD = Double.MAX_VALUE;

         for(ItemEntity it : items) {
            double d = it.position().distanceToSqr(this.breakPos);
            if (d < bestD) {
               bestD = d;
               best = it;
            }
         }

         return best;
      }
   }

   private void trackTarget(LivingEntity target) {
      Vec3 now = target.position();
      if (this.lastTargetPos != null) {
         Vec3 step = now.subtract(this.lastTargetPos);
         if (step.horizontalDistanceSqr() > (double)4.0F) {
            step = Vec3.ZERO;
         }

         this.targetVel = this.targetVel.scale(0.7).add(step.scale(0.3));
      }

      this.lastTargetPos = now;
   }

   private Vec3 leadPoint(LivingEntity target, double dist) {
      Vec3 pos = target.position();
      double vx = this.targetVel.x;
      double vz = this.targetVel.z;
      double speed = Math.sqrt(vx * vx + vz * vz);
      if (speed < 0.03) {
         return pos;
      } else {
         double t = Math.min((double)40.0F, dist / 0.35);
         return new Vec3(pos.x + vx * t + vx / speed * (double)1.5F, pos.y, pos.z + vz * t + vz / speed * (double)1.5F);
      }
   }

   private void faceToward(Vec3 pos, float pitch) {
      double dx = pos.x - this.bot.getX();
      double dz = pos.z - this.bot.getZ();
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      this.bot.setXRot(pitch);
   }

   private static enum Phase {
      PLACE,
      MOUNT,
      DRIVE,
      BREAK,
      PICKUP;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{PLACE, MOUNT, DRIVE, BREAK, PICKUP};
      }
   }
}
