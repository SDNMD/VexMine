package vexbot.bot.ai;

import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class ShieldController {
   private static final int PREDICT_LEAD_TICKS = 5;
   private static final int PREDICT_HOLD_TICKS = 10;
   private static final float MIN_BLOCK_CHARGE = 0.5F;
   private static final int MAX_BLOCK_TICKS = 40;
   private static final int REBLOCK_COOLDOWN = 2;
   private static final double SHIELD_RANGE = (double)4.5F;
   private static final double RUSH_RANGE = 3.8;
   private static final double APPROACH_DOT = 0.8;
   private static final double APPROACH_MIN_SPEED = 0.12;
   private static final double APPROACH_RAISE_RANGE = (double)6.0F;
   private static final int APPROACH_SUSTAIN = 2;
   private static final Identifier SPEED_ID = Identifier.withDefaultNamespace("vexbot_shield_slow");
   private static final double SPEED_REDUCTION = -0.7;
   private final ServerPlayer bot;
   private boolean isBlocking = false;
   private int blockTicks = 0;
   private int cooldown = 0;
   private float prevTargCharge = 0.0F;
   private int predictHoldTicks = 0;
   private int blockhitTicksLeft = 0;
   private int blockhitRequested = 0;
   private boolean blockhitPunishPending = false;
   private static final int BLOCKHIT_MIN_HOLD = 14;
   private int approachTicks = 0;
   private int baitTicksLeft = 0;
   private boolean sacrifice = false;
   private static final int SACRIFICE_MAX_TICKS = 100;

   public ShieldController(ServerPlayer bot) {
      this.bot = bot;
   }

   public void tick(LivingEntity target, boolean shieldInOffhand) {
      if (shieldInOffhand && target != null) {
         if (this.bot.getCooldowns().isOnCooldown(this.bot.getOffhandItem())) {
            if (this.isBlocking) {
               this.stopBlocking();
            }

            this.clearTransientWindows();
         } else if (this.cooldown > 0) {
            --this.cooldown;
            if (this.isBlocking) {
               this.stopBlocking();
            }

         } else {
            double dist = (double)this.bot.distanceTo(target);
            float botCharge = this.bot.getAttackStrengthScale(0.0F);
            float var10000;
            if (target instanceof Player) {
               Player p = (Player)target;
               var10000 = p.getAttackStrengthScale(0.0F);
            } else {
               var10000 = 1.0F;
            }

            float targCharge = var10000;
            boolean wantBlock = this.shouldBlock(dist, botCharge, targCharge, target);
            if (this.baitTicksLeft > 0) {
               --this.baitTicksLeft;
               wantBlock = true;
            }

            if (this.sacrifice) {
               wantBlock = true;
            }

            if (wantBlock) {
               if (!this.isBlocking) {
                  this.startBlocking();
               } else if (!this.bot.isUsingItem()) {
                  this.bot.startUsingItem(InteractionHand.OFF_HAND);
                  this.applySpeedPenalty();
               }
            } else if (this.isBlocking) {
               this.stopBlocking();
            }

            if (this.isBlocking) {
               ++this.blockTicks;
               if (this.blockTicks >= (this.sacrifice ? 100 : 40)) {
                  this.stopBlocking();
                  this.cooldown = 2;
               }
            }

         }
      } else {
         if (this.isBlocking) {
            this.stopBlocking();
         }

         this.clearTransientWindows();
      }
   }

   public void reset() {
      if (this.isBlocking) {
         this.stopBlocking();
      }

      this.cooldown = 0;
      this.blockhitTicksLeft = 0;
      this.blockhitPunishPending = false;
      this.predictHoldTicks = 0;
      this.approachTicks = 0;
      this.baitTicksLeft = 0;
      this.sacrifice = false;
   }

   private void clearTransientWindows() {
      this.blockhitTicksLeft = 0;
      this.blockhitPunishPending = false;
      this.baitTicksLeft = 0;
      this.predictHoldTicks = 0;
      this.approachTicks = 0;
   }

   public boolean isBlocking() {
      return this.isBlocking;
   }

   public float getPrevTargetCharge() {
      return this.prevTargCharge;
   }

   public void requestBlockhit(int ticks) {
      this.blockhitTicksLeft = ticks;
      this.blockhitRequested = ticks;
   }

   public void requestBait(int ticks) {
      if (this.cooldown == 0) {
         this.baitTicksLeft = ticks;
      }

   }

   public void setSacrifice(boolean on) {
      this.sacrifice = on;
   }

   private boolean shouldBlock(double dist, float botCharge, float targCharge, LivingEntity target) {
      float chargeVel = targCharge - this.prevTargCharge;
      this.prevTargCharge = targCharge;
      Vec3 tv = target.getKnownMovement();
      double hs = Math.sqrt(tv.x * tv.x + tv.z * tv.z);
      double tx = this.bot.getX() - target.getX();
      double tz = this.bot.getZ() - target.getZ();
      double td = Math.sqrt(tx * tx + tz * tz);
      boolean towardUs = hs >= 0.12 && td > 0.001 && (tv.x * tx + tv.z * tz) / (hs * td) >= 0.8;
      this.approachTicks = towardUs ? this.approachTicks + 1 : 0;
      if (this.blockhitTicksLeft > 0) {
         if (chargeVel <= -0.4F && dist <= (double)3.5F) {
            this.blockhitPunishPending = true;
         }

         if (this.blockhitPunishPending && botCharge >= 0.95F) {
            this.blockhitTicksLeft = 0;
            this.blockhitPunishPending = false;
            return false;
         } else {
            int held = this.blockhitRequested - this.blockhitTicksLeft;
            if (held >= 14 && botCharge >= 0.95F) {
               this.blockhitTicksLeft = 0;
               this.blockhitPunishPending = false;
               return false;
            } else {
               --this.blockhitTicksLeft;
               return true;
            }
         }
      } else {
         this.blockhitPunishPending = false;
         if (botCharge >= 0.95F) {
            return false;
         } else if (dist <= (double)6.0F && this.approachTicks >= 2) {
            this.predictHoldTicks = 10;
            return true;
         } else if (dist > (double)4.5F) {
            return false;
         } else if (this.predictHoldTicks > 0) {
            --this.predictHoldTicks;
            return true;
         } else if (target.isBlocking()) {
            return true;
         } else {
            if (targCharge >= 0.5F && chargeVel > 0.001F) {
               float remaining = (1.0F - targCharge) / chargeVel;
               if (remaining <= 5.0F) {
                  this.predictHoldTicks = 10;
                  return true;
               }
            }

            if (dist <= 3.8 && target instanceof Player) {
               Player p = (Player)target;
               if (p.isSprinting()) {
                  return true;
               }
            }

            return targCharge >= 0.85F;
         }
      }
   }

   private void startBlocking() {
      if (!this.bot.isUsingItem()) {
         this.isBlocking = true;
         this.blockTicks = 0;
         this.bot.startUsingItem(InteractionHand.OFF_HAND);
         this.applySpeedPenalty();
      }
   }

   private void stopBlocking() {
      this.isBlocking = false;
      this.blockTicks = 0;
      if (this.bot.isUsingItem() && this.bot.getUsedItemHand() == InteractionHand.OFF_HAND) {
         this.bot.stopUsingItem();
      }

      this.removeSpeedPenalty();
   }

   private void applySpeedPenalty() {
      AttributeInstance attr = this.bot.getAttribute(Attributes.MOVEMENT_SPEED);
      if (attr != null) {
         attr.removeModifier(SPEED_ID);
         attr.addOrUpdateTransientModifier(new AttributeModifier(SPEED_ID, -0.7, Operation.ADD_MULTIPLIED_TOTAL));
      }
   }

   private void removeSpeedPenalty() {
      AttributeInstance attr = this.bot.getAttribute(Attributes.MOVEMENT_SPEED);
      if (attr != null) {
         attr.removeModifier(SPEED_ID);
      }

   }
}
