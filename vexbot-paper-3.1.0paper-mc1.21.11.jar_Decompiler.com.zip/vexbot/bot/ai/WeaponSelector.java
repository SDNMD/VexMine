package vexbot.bot.ai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.EffectiveSettings;
import vexbot.util.InventoryUtils;

public final class WeaponSelector {
   public static final double RANGE_SWITCH = (double)7.0F;
   private final ServerPlayer bot;

   public WeaponSelector(ServerPlayer bot) {
      this.bot = bot;
   }

   public WeaponType selectWeapon(LivingEntity target, double dist, boolean effectivelyBlocking) {
      Inventory inv = this.bot.getInventory();
      if (dist > (double)7.0F && (new EffectiveSettings(this.bot.getScoreboardName())).useBows()) {
         boolean arrows = this.hasArrows();
         if (arrows) {
            int bowSlot = this.bestInHotbar(WeaponSelector.WeaponType.BOW);
            if (bowSlot >= 0) {
               InventoryUtils.select(inv, bowSlot);
               return WeaponSelector.WeaponType.BOW;
            }
         }

         int xbowSlot = this.bestInHotbar(WeaponSelector.WeaponType.CROSSBOW);
         if (xbowSlot >= 0 && (arrows || CrossbowItem.isCharged(inv.getItem(xbowSlot)))) {
            InventoryUtils.select(inv, xbowSlot);
            return WeaponSelector.WeaponType.CROSSBOW;
         }
      }

      if (effectivelyBlocking) {
         int axeSlotB = this.bestInHotbar(WeaponSelector.WeaponType.AXE);
         int swordSlotB = this.bestInHotbar(WeaponSelector.WeaponType.SWORD);
         if (axeSlotB >= 0 && swordSlotB < 0) {
            InventoryUtils.select(inv, axeSlotB);
            return WeaponSelector.WeaponType.AXE;
         }
      }

      int swordSlot = this.bestInHotbar(WeaponSelector.WeaponType.SWORD);
      int axeSlot = this.bestInHotbar(WeaponSelector.WeaponType.AXE);
      if (swordSlot >= 0) {
         InventoryUtils.select(inv, swordSlot);
         return WeaponSelector.WeaponType.SWORD;
      } else if (axeSlot >= 0) {
         InventoryUtils.select(inv, axeSlot);
         return WeaponSelector.WeaponType.AXE;
      } else {
         int pulled = this.pullBestMeleeFromInventory();
         if (pulled >= 0) {
            InventoryUtils.select(inv, pulled);
            return getType(inv.getItem(pulled));
         } else {
            int maceSlot = this.bestInHotbar(WeaponSelector.WeaponType.MACE);
            if (maceSlot >= 0) {
               InventoryUtils.select(inv, maceSlot);
               return WeaponSelector.WeaponType.MACE;
            } else {
               for(int slot = 0; slot < 9; ++slot) {
                  if (inv.getItem(slot).isEmpty()) {
                     InventoryUtils.select(inv, slot);
                     return WeaponSelector.WeaponType.EMPTY;
                  }
               }

               return WeaponSelector.WeaponType.OTHER;
            }
         }
      }
   }

   public boolean selectCrossbowIfAvailable() {
      int slot = this.bestInHotbar(WeaponSelector.WeaponType.CROSSBOW);
      if (slot >= 0) {
         InventoryUtils.select(this.bot.getInventory(), slot);
         return true;
      } else {
         return false;
      }
   }

   public WeaponType currentType() {
      return getType(this.bot.getMainHandItem());
   }

   public static WeaponType getType(ItemStack stack) {
      if (stack.isEmpty()) {
         return WeaponSelector.WeaponType.EMPTY;
      } else if (stack.is(Items.BOW)) {
         return WeaponSelector.WeaponType.BOW;
      } else if (stack.is(Items.CROSSBOW)) {
         return WeaponSelector.WeaponType.CROSSBOW;
      } else if (stack.is(Items.MACE)) {
         return WeaponSelector.WeaponType.MACE;
      } else if (stack.is(ItemTags.SWORDS)) {
         return WeaponSelector.WeaponType.SWORD;
      } else {
         return stack.is(ItemTags.AXES) ? WeaponSelector.WeaponType.AXE : WeaponSelector.WeaponType.OTHER;
      }
   }

   private boolean hasArrows() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(ItemTags.ARROWS)) {
            return true;
         }
      }

      return inv.getItem(40).is(ItemTags.ARROWS);
   }

   private int pullBestMeleeFromInventory() {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestScore = (double)0.0F;

      for(int i = 9; i < 36; ++i) {
         ItemStack stack = inv.getItem(i);
         WeaponType type = getType(stack);
         if (type == WeaponSelector.WeaponType.SWORD || type == WeaponSelector.WeaponType.AXE) {
            double score = ItemEvaluator.scoreWeapon(stack);
            if (score > bestScore) {
               bestScore = score;
               best = i;
            }
         }
      }

      if (best < 0) {
         return -1;
      } else {
         return InventoryUtils.moveToHotbarSafe(inv, best);
      }
   }

   private int bestInHotbar(WeaponType wanted) {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestScore = (double)-1.0F;

      for(int i = 0; i < 9; ++i) {
         ItemStack stack = inv.getItem(i);
         if (getType(stack) == wanted) {
            double score;
            if (wanted == WeaponSelector.WeaponType.CROSSBOW) {
               score = CrossbowItem.isCharged(stack) ? (double)2.0F : (double)1.0F;
            } else if (wanted == WeaponSelector.WeaponType.BOW) {
               score = (double)1.0F;
            } else if (wanted == WeaponSelector.WeaponType.MACE) {
               score = ItemEvaluator.scoreMace(stack);
            } else {
               score = ItemEvaluator.scoreWeapon(stack);
            }

            if (score > bestScore) {
               bestScore = score;
               best = i;
            }
         }
      }

      return best;
   }

   public static enum WeaponType {
      SWORD,
      AXE,
      BOW,
      CROSSBOW,
      MACE,
      OTHER,
      EMPTY;

      // $FF: synthetic method
      private static WeaponType[] $values() {
         return new WeaponType[]{SWORD, AXE, BOW, CROSSBOW, MACE, OTHER, EMPTY};
      }
   }
}
