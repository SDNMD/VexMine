package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.InventoryUtils;

public final class WebDrainController {
   private static final int WATER_SCAN_R = 2;
   private static final double REACH = (double)4.5F;
   private static final int DRAIN_COOLDOWN = 8;
   private static final int SKIP_COOLDOWN = 16;
   private final ServerPlayer bot;
   private int cooldown = 0;
   private int reactTicks = -1;

   public WebDrainController(ServerPlayer bot) {
      this.bot = bot;
   }

   public boolean tick(LivingEntity target) {
      if (this.cooldown > 0) {
         --this.cooldown;
         this.reactTicks = -1;
         return false;
      } else if (target != null && target.isAlive()) {
         ServerLevel var3 = this.bot.level();
         if (var3 instanceof ServerLevel) {
            ServerLevel level = var3;
            EffectiveSettings es = EffectiveSettings.of(this.bot.getScoreboardName());
            if (!es.useWebDrain()) {
               this.reactTicks = -1;
               return false;
            } else if (!this.targetInCobweb(level, target)) {
               this.reactTicks = -1;
               return false;
            } else {
               int bucketSlot = this.findEmptyBucket();
               if (bucketSlot < 0) {
                  this.reactTicks = -1;
                  return false;
               } else {
                  BlockPos water = this.findDrainableWater(level, target);
                  if (water == null) {
                     this.reactTicks = -1;
                     return false;
                  } else {
                     if (this.reactTicks < 0) {
                        this.reactTicks = es.difficultyParams().webDrainDelayTicks();
                     }

                     if (this.reactTicks > 0) {
                        --this.reactTicks;
                        return false;
                     } else {
                        this.reactTicks = -1;
                        if (!es.rollWebDrain()) {
                           this.cooldown = 16;
                           return false;
                        } else {
                           this.drain(level, water, bucketSlot);
                           this.cooldown = 8;
                           return true;
                        }
                     }
                  }
               }
            }
         } else {
            this.reactTicks = -1;
            return false;
         }
      } else {
         this.reactTicks = -1;
         return false;
      }
   }

   public boolean isExecuting() {
      return this.cooldown > 0;
   }

   public void reset() {
      this.cooldown = 0;
      this.reactTicks = -1;
   }

   private boolean targetInCobweb(Level level, LivingEntity target) {
      BlockPos feet = target.blockPosition();
      return level.getBlockState(feet).is(Blocks.COBWEB) || level.getBlockState(feet.above()).is(Blocks.COBWEB);
   }

   private int findEmptyBucket() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.BUCKET)) {
            return i;
         }
      }

      return -1;
   }

   private BlockPos findDrainableWater(Level level, LivingEntity target) {
      BlockPos base = target.blockPosition();
      Vec3 eye = this.bot.getEyePosition();
      BlockPos best = null;
      double bestD = (double)20.25F;

      for(int dx = -2; dx <= 2; ++dx) {
         for(int dy = -1; dy <= 2; ++dy) {
            for(int dz = -2; dz <= 2; ++dz) {
               BlockPos p = base.offset(dx, dy, dz);
               FluidState fluid = level.getFluidState(p);
               if (fluid.isSource() && fluid.is(FluidTags.WATER)) {
                  double d = eye.distanceToSqr((double)p.getX() + (double)0.5F, (double)p.getY() + (double)0.5F, (double)p.getZ() + (double)0.5F);
                  if (d <= bestD) {
                     bestD = d;
                     best = p;
                  }
               }
            }
         }
      }

      return best;
   }

   private void drain(Level level, BlockPos water, int bucketSlot) {
      Inventory inv = this.bot.getInventory();
      int prevSel = InventoryUtils.selected(inv);
      int useSlot = bucketSlot;
      boolean swapped = false;
      int storedAt = -1;
      if (bucketSlot > 8) {
         storedAt = bucketSlot;
         useSlot = prevSel;
         ItemStack bucket = inv.getItem(bucketSlot).copy();
         ItemStack held = inv.getItem(prevSel).copy();
         inv.setItem(prevSel, bucket);
         inv.setItem(bucketSlot, held);
         swapped = true;
      }

      InventoryUtils.select(inv, useSlot);
      this.aimAt(water);
      this.bot.gameMode.useItem(this.bot, level, inv.getItem(useSlot), InteractionHand.MAIN_HAND);
      McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
      if (swapped) {
         ItemStack nowWater = inv.getItem(useSlot).copy();
         ItemStack original = inv.getItem(storedAt).copy();
         inv.setItem(useSlot, original);
         inv.setItem(storedAt, nowWater);
      }

      InventoryUtils.select(inv, prevSel);
   }

   private void aimAt(BlockPos water) {
      Vec3 eye = this.bot.getEyePosition();
      double dx = (double)water.getX() + (double)0.5F - eye.x;
      double dy = (double)water.getY() + (double)0.5F - eye.y;
      double dz = (double)water.getZ() + (double)0.5F - eye.z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, horiz))));
      this.bot.yHeadRot = this.bot.getYRot();
   }
}
