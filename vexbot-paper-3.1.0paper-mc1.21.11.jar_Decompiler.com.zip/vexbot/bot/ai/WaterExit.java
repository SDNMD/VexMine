package vexbot.bot.ai;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.Plane;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import vexbot.BotSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

final class WaterExit {
   private static final int SEARCH_RADIUS = 12;
   private static final double MAX_DETOUR = (double)8.0F;
   static final double CLIMBABLE_LIP = 0.6;
   private static final int STUCK_TRIGGER = 10;
   private static final int EXIT_TIMEOUT = 300;
   private static final int DIG_TIMEOUT = 200;
   private static final float HAND_HARDNESS = 1.0F;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private Vec3 exit;
   private int exitTicks;
   private BlockPos dig;
   private BlockPos digColumn;
   private int digTicks;
   private int stuck;
   private int cooldown;
   private Vec3 steerTo;
   private boolean busy;

   WaterExit(ServerPlayer bot, MinecraftServer server, String botName) {
      this.bot = bot;
      this.server = server;
      this.botName = botName;
   }

   Vec3 steerTo() {
      return this.steerTo;
   }

   boolean busy() {
      return this.busy;
   }

   boolean active() {
      return this.exit != null || this.dig != null;
   }

   void reset() {
      if (this.dig != null) {
         BotCommands.stopMining(this.server, this.botName);
      }

      this.exit = null;
      this.dig = null;
      this.digColumn = null;
      this.stuck = 0;
      this.steerTo = null;
      this.busy = false;
   }

   void pause() {
      if (this.dig != null) {
         BotCommands.stopMining(this.server, this.botName);
      }

   }

   void tick(Level level, Vec3 pos, Vec3 goal, double surface) {
      this.steerTo = null;
      this.busy = false;
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      int sy = Mth.floor(surface - 0.01);
      if (this.dig != null) {
         this.tickDig(level, sy);
      } else {
         if (this.exit != null) {
            BlockPos land = BlockPos.containing(this.exit.x, this.exit.y - (double)0.5F, this.exit.z);
            if (++this.exitTicks <= 300 && !Double.isNaN(landTop(level, land, surface))) {
               this.steerTo = this.exit;
               return;
            }

            this.exit = null;
            this.cooldown = 60;
         }

         float yaw = this.bot.getYRot();
         if (!highBankAhead(level, pos, yaw, surface)) {
            this.stuck = 0;
         } else {
            if (this.bot.horizontalCollision) {
               ++this.stuck;
            } else if (this.stuck > 0) {
               --this.stuck;
            }

            if (this.stuck >= 10 && this.cooldown <= 0) {
               this.stuck = 0;
               Vec3 low = this.findLowExit(level, pos, goal, surface, sy, false);
               if (low != null) {
                  this.setExit(low);
               } else {
                  BlockPos step = this.placeStep(level, pos, yaw, sy);
                  if (step != null) {
                     this.setExit(new Vec3((double)step.getX() + (double)0.5F, (double)step.getY() + (double)1.0F, (double)step.getZ() + (double)0.5F));
                  } else {
                     if (BotSettings.gotoMining) {
                        BlockPos column = ahead(pos, yaw, sy);
                        BlockPos lip = column.above();
                        if (solid(level, lip) && this.canDig(level, lip)) {
                           this.digColumn = column;
                           this.dig = lip;
                           this.digTicks = 0;
                           this.tickDig(level, sy);
                           return;
                        }
                     }

                     Vec3 far = this.findLowExit(level, pos, goal, surface, sy, true);
                     if (far != null) {
                        this.setExit(far);
                     } else {
                        this.cooldown = 100;
                     }
                  }
               }
            }
         }
      }
   }

   private void setExit(Vec3 top) {
      this.exit = top;
      this.exitTicks = 0;
      this.steerTo = top;
   }

   static double landTop(Level level, BlockPos column, double surface) {
      int sy = Mth.floor(surface - 0.01);

      for(int y = sy; y <= sy + 1; ++y) {
         BlockPos b = new BlockPos(column.getX(), y, column.getZ());
         if (!level.getFluidState(b).is(FluidTags.WATER)) {
            VoxelShape shape = level.getBlockState(b).getCollisionShape(level, b);
            if (!shape.isEmpty() && free(level, b.above()) && free(level, b.above(2))) {
               return (double)y + shape.max(Axis.Y);
            }
         }
      }

      return Double.NaN;
   }

   static boolean highBankAhead(Level level, Vec3 pos, float yaw, double surface) {
      double rad = Math.toRadians((double)yaw);
      double fx = -Math.sin(rad);
      double fz = Math.cos(rad);
      int sy = Mth.floor(surface - 0.01);

      for(double step = 0.7; step <= 1.31; step += 0.6) {
         int x = Mth.floor(pos.x + fx * step);
         int z = Mth.floor(pos.z + fz * step);
         BlockPos lip = new BlockPos(x, sy + 1, z);
         if (solid(level, lip)) {
            double top = landTop(level, new BlockPos(x, sy, z), surface);
            return Double.isNaN(top) || top - surface > 0.6;
         }
      }

      return false;
   }

   private Vec3 findLowExit(Level level, Vec3 pos, Vec3 goal, double surface, int sy, boolean anyDetour) {
      BlockPos start = new BlockPos(Mth.floor(pos.x), sy, Mth.floor(pos.z));
      Map<BlockPos, Integer> dist = new HashMap();
      ArrayDeque<BlockPos> queue = new ArrayDeque();
      dist.put(start, 0);
      queue.add(start);
      BlockPos best = null;
      double bestTop = (double)0.0F;
      double bestScore = Double.MAX_VALUE;

      while(!queue.isEmpty()) {
         BlockPos p = (BlockPos)queue.poll();
         int d = (Integer)dist.get(p);

         for(Direction dir : Plane.HORIZONTAL) {
            BlockPos n = p.relative(dir);
            if (Math.abs(n.getX() - start.getX()) <= 12 && Math.abs(n.getZ() - start.getZ()) <= 12 && !dist.containsKey(n)) {
               if (level.getFluidState(n).is(FluidTags.WATER) && free(level, n.above())) {
                  dist.put(n, d + 1);
                  queue.add(n);
               } else {
                  double top = landTop(level, n, surface);
                  if (!Double.isNaN(top) && !(top - surface > 0.6)) {
                     double gx = goal.x - ((double)n.getX() + (double)0.5F);
                     double gz = goal.z - ((double)n.getZ() + (double)0.5F);
                     double score = (double)(d + 1) + Math.sqrt(gx * gx + gz * gz);
                     if (score < bestScore) {
                        bestScore = score;
                        best = n;
                        bestTop = top;
                     }
                  }
               }
            }
         }
      }

      double sx = goal.x - pos.x;
      double sz = goal.z - pos.z;
      if (best != null && (anyDetour || !(bestScore > Math.sqrt(sx * sx + sz * sz) + (double)8.0F))) {
         return new Vec3((double)best.getX() + (double)0.5F, bestTop, (double)best.getZ() + (double)0.5F);
      } else {
         return null;
      }
   }

   private BlockPos placeStep(Level level, Vec3 pos, float yaw, int sy) {
      int slot = this.blockSlot();
      if (slot < 0) {
         return null;
      } else {
         Direction toBank = Direction.fromYRot((double)yaw);
         BlockPos here = new BlockPos(Mth.floor(pos.x), sy, Mth.floor(pos.z));
         AABB body = this.bot.getBoundingBox();

         for(Direction side : new Direction[]{toBank.getClockWise(), toBank.getCounterClockWise()}) {
            BlockPos cell = here.relative(side);
            if (level.getBlockState(cell).canBeReplaced() && !(new AABB(cell)).intersects(body) && free(level, cell.above()) && free(level, cell.above(2))) {
               BlockPos click;
               Direction face;
               if (solid(level, cell.relative(toBank))) {
                  click = cell.relative(toBank);
                  face = toBank.getOpposite();
               } else {
                  if (!solid(level, cell.below())) {
                     continue;
                  }

                  click = cell.below();
                  face = Direction.UP;
               }

               InteractionHand hand = slot == 40 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
               if (hand == InteractionHand.MAIN_HAND) {
                  Inventory inv = this.bot.getInventory();
                  InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, slot));
               }

               ItemStack stack = hand == InteractionHand.OFF_HAND ? this.bot.getOffhandItem() : this.bot.getMainHandItem();
               Vec3 hitVec = Vec3.atCenterOf(click).add((double)face.getStepX() * (double)0.5F, (double)face.getStepY() * (double)0.5F, (double)face.getStepZ() * (double)0.5F);
               this.faceBlock(click);
               this.bot.gameMode.useItemOn(this.bot, level, stack, hand, new BlockHitResult(hitVec, face, click, false));
               McCompat.swing(this.bot, hand);
               if (solid(level, cell)) {
                  return cell;
               }
            }
         }

         return null;
      }
   }

   private int blockSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (ScaffoldController.isPillarBlock(inv.getItem(i))) {
            return i;
         }
      }

      return ScaffoldController.isPillarBlock(this.bot.getOffhandItem()) ? 40 : -1;
   }

   private void tickDig(Level level, int sy) {
      this.busy = true;
      if (!solid(level, this.dig)) {
         BotCommands.stopMining(this.server, this.botName);
         BlockPos over = this.dig.above();
         if (this.dig.getY() != this.digColumn.getY() + 1 || !solid(level, over) || !this.canDig(level, over)) {
            this.dig = null;
            this.busy = false;
            this.setExit(new Vec3((double)this.digColumn.getX() + (double)0.5F, (double)this.digColumn.getY() + (double)1.0F, (double)this.digColumn.getZ() + (double)0.5F));
            return;
         }

         this.dig = over;
         this.digTicks = 0;
      }

      if (++this.digTicks <= 200 && this.canDig(level, this.dig)) {
         BotCommands.stopMoving(this.server, this.botName);
         this.bot.setSprinting(false);
         this.bot.setJumping(this.bot.isUnderWater());
         Vec3 v = this.bot.getDeltaMovement();
         this.bot.setDeltaMovement((double)0.0F, v.y, (double)0.0F);
         int tool = this.toolSlot(level.getBlockState(this.dig));
         if (tool >= 0) {
            Inventory inv = this.bot.getInventory();
            InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, tool));
         }

         this.faceBlock(this.dig);
         BotCommands.mineContinuous(this.server, this.botName);
      } else {
         BotCommands.stopMining(this.server, this.botName);
         this.dig = null;
         this.busy = false;
         this.cooldown = 200;
      }
   }

   private boolean canDig(Level level, BlockPos p) {
      BlockState st = level.getBlockState(p);
      float hardness = st.getDestroySpeed(level, p);
      if (!(hardness < 0.0F) && !st.hasBlockEntity()) {
         return this.toolSlot(st) >= 0 || hardness <= 1.0F;
      } else {
         return false;
      }
   }

   private int toolSlot(BlockState state) {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      float bestSpeed = 1.0F;

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (!s.isEmpty()) {
            float sp = s.getDestroySpeed(state);
            if (sp > bestSpeed) {
               bestSpeed = sp;
               best = i;
            }
         }
      }

      return best;
   }

   private static BlockPos ahead(Vec3 pos, float yaw, int sy) {
      double rad = Math.toRadians((double)yaw);
      return new BlockPos(Mth.floor(pos.x - Math.sin(rad) * 0.9), sy, Mth.floor(pos.z + Math.cos(rad) * 0.9));
   }

   private void faceBlock(BlockPos p) {
      Vec3 c = Vec3.atCenterOf(p);
      double dx = c.x - this.bot.getX();
      double dy = c.y - this.bot.getEyeY();
      double dz = c.z - this.bot.getZ();
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, Math.max(horiz, 0.001)))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private static boolean solid(Level level, BlockPos p) {
      return !level.getBlockState(p).getCollisionShape(level, p).isEmpty();
   }

   private static boolean free(Level level, BlockPos p) {
      return level.getBlockState(p).getCollisionShape(level, p).isEmpty();
   }
}
