package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import vexbot.util.WaterRules;

public final class FireEscapeController {
   private static final int PICKUP_DELAY = 10;
   private final ServerPlayer bot;
   private boolean active = false;
   private int pickupTimer = 0;
   private BlockPos waterPos = null;
   private int bucketSlot = -1;

   public FireEscapeController(ServerPlayer bot) {
      this.bot = bot;
   }

   public boolean isActive() {
      return this.active;
   }

   public boolean tick() {
      if (this.active) {
         if (--this.pickupTimer <= 0) {
            this.collectWater();
         }

         return true;
      } else if (!this.needsEscape()) {
         return false;
      } else {
         int slot = this.findWaterBucket();
         if (slot < 0) {
            return false;
         } else {
            Level level = this.bot.level();
            BlockPos feet = this.bot.blockPosition();
            if (WaterRules.evaporates(level, feet)) {
               return false;
            } else {
               BlockState state = level.getBlockState(feet);
               if (!state.isAir() && !state.is(Blocks.LAVA)) {
                  return false;
               } else {
                  level.setBlock(feet, Blocks.WATER.defaultBlockState(), 3);
                  this.bot.getInventory().setItem(slot, new ItemStack(Items.BUCKET));
                  this.active = true;
                  this.waterPos = feet;
                  this.bucketSlot = slot;
                  this.pickupTimer = 10;
                  return true;
               }
            }
         }
      }
   }

   private boolean needsEscape() {
      if (!this.bot.isOnFire() && !this.bot.isInLava()) {
         return false;
      } else {
         return !this.bot.hasEffect(MobEffects.FIRE_RESISTANCE);
      }
   }

   private void collectWater() {
      Level level = this.bot.level();
      boolean removed = false;
      if (this.waterPos != null && level.getBlockState(this.waterPos).is(Blocks.WATER)) {
         level.setBlock(this.waterPos, Blocks.AIR.defaultBlockState(), 3);
         removed = true;
      }

      Inventory inv = this.bot.getInventory();
      if (removed) {
         int slot = this.bucketSlot >= 0 && isSingleBucket(inv.getItem(this.bucketSlot)) ? this.bucketSlot : -1;

         for(int i = 0; slot < 0 && i < 36; ++i) {
            if (isSingleBucket(inv.getItem(i))) {
               slot = i;
            }
         }

         if (slot >= 0) {
            inv.setItem(slot, new ItemStack(Items.WATER_BUCKET));
         }
      }

      this.active = false;
      this.waterPos = null;
      this.bucketSlot = -1;
   }

   private static boolean isSingleBucket(ItemStack stack) {
      return stack.is(Items.BUCKET) && stack.getCount() == 1;
   }

   private int findWaterBucket() {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(Items.WATER_BUCKET)) {
            return i;
         }
      }

      return -1;
   }
}
