package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;
import vexbot.util.WebPlacer;

public final class PredictionWebController {
   private static final int LEAD_TICKS_MIN = 5;
   private static final int LEAD_TICKS_MAX = 11;
   private static final double MIN_SPEED = 0.12;
   private static final double MIN_CLOSING = 0.04;
   private static final double MIN_RANGE = (double)3.0F;
   private static final double MAX_RANGE = (double)14.0F;
   private static final double PLACE_REACH = (double)4.5F;
   private static final int WINDUP_TICKS = 2;
   private static final int COOLDOWN_OK = 90;
   private static final int COOLDOWN_FAIL = 30;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private int cooldown = 0;
   private int windup = 0;
   private BlockPos pendingPos = null;
   private int prevSlot = -1;

   public PredictionWebController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isExecuting() {
      return this.windup > 0;
   }

   public void reset() {
      if (this.windup > 0 && this.prevSlot >= 0 && this.prevSlot < 9) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.cooldown = Math.max(this.cooldown, 30);
      this.windup = 0;
      this.pendingPos = null;
      this.prevSlot = -1;
   }

   public boolean tick(LivingEntity target) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.windup > 0) {
         return this.tickWindup();
      } else if (target != null && target.isAlive()) {
         if (this.cooldown > 0) {
            return false;
         } else if (!this.bot.onGround()) {
            return false;
         } else {
            EffectiveSettings eff = EffectiveSettings.of(this.botName);
            if (!eff.useCobwebs()) {
               return false;
            } else {
               double dist = (double)this.bot.distanceTo(target);
               if (!(dist < (double)3.0F) && !(dist > (double)14.0F)) {
                  if (!this.bot.hasLineOfSight(target)) {
                     return false;
                  } else if (!WebPlacer.hasWeb(this.bot)) {
                     return false;
                  } else {
                     BlockPos spot = this.predictLane(target);
                     if (spot == null) {
                        return false;
                     } else if (this.bot.position().distanceTo(Vec3.atCenterOf(spot)) > (double)4.5F) {
                        return false;
                     } else {
                        int slot = WebPlacer.equipWeb(this.bot);
                        if (slot < 0) {
                           return false;
                        } else {
                           this.prevSlot = InventoryUtils.selected(this.bot.getInventory());
                           InventoryUtils.select(this.bot.getInventory(), slot);
                           this.pendingPos = spot;
                           this.windup = 2;
                           return true;
                        }
                     }
                  }
               } else {
                  return false;
               }
            }
         }
      } else {
         return false;
      }
   }

   private boolean tickWindup() {
      --this.windup;
      BotCommands.stopMoving(this.server, this.botName);
      this.bot.setSprinting(false);
      int webSlot = WebPlacer.equipWeb(this.bot);
      if (webSlot >= 0) {
         InventoryUtils.select(this.bot.getInventory(), webSlot);
      }

      if (this.pendingPos != null) {
         WebPlacer.lookAt(this.bot, this.pendingPos);
      }

      if (this.windup > 0) {
         return true;
      } else {
         boolean placed = this.pendingPos != null && WebPlacer.placeAt(this.bot, this.pendingPos);
         if (this.prevSlot >= 0 && this.prevSlot < 9) {
            InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
         }

         this.cooldown = placed ? 90 : 30;
         this.pendingPos = null;
         this.prevSlot = -1;
         return placed;
      }
   }

   private BlockPos predictLane(LivingEntity target) {
      Vec3 vel = target.getKnownMovement();
      double speed = Math.hypot(vel.x, vel.z);
      if (speed < 0.12) {
         return null;
      } else {
         Vec3 toBot = new Vec3(this.bot.getX() - target.getX(), (double)0.0F, this.bot.getZ() - target.getZ());
         double closing = (toBot.x * vel.x + toBot.z * vel.z) / Math.max(0.001, toBot.length());
         if (closing < 0.04) {
            return null;
         } else {
            Level level = this.bot.level();

            for(int lead = 11; lead >= 5; --lead) {
               double px = target.getX() + vel.x * (double)lead;
               double pz = target.getZ() + vel.z * (double)lead;
               BlockPos feet = BlockPos.containing(px, target.getY() + 0.1, pz);
               if (level.getBlockState(feet).isAir() && !level.getBlockState(feet.below()).isAir() && !feet.equals(target.blockPosition()) && !(new AABB(feet)).intersects(this.bot.getBoundingBox().inflate(0.3)) && !(this.bot.position().distanceTo(Vec3.atCenterOf(feet)) > (double)4.5F)) {
                  return feet;
               }
            }

            return null;
         }
      }
   }
}
