package vexbot.bot.ai;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.util.BotMath;

final class IdleHumanizer {
   private static final double ATTEND_RANGE = (double)16.0F;
   private static final float MAX_YAW_STEP = 14.0F;
   private static final float MAX_PITCH_STEP = 9.0F;
   private static final float EASE = 0.35F;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private float goalYaw;
   private float goalPitch;
   private boolean hasGoal = false;
   private int holdTicks = 0;
   private boolean glancing = false;
   private UUID attending = null;

   IdleHumanizer(ServerPlayer bot, MinecraftServer server, String botName) {
      this.bot = bot;
      this.server = server;
      this.botName = botName;
   }

   void tick(int tickCount) {
      if (this.bot.hurtTime <= 0) {
         this.pickGaze(this.nearestPerson());
         this.easeHead();
      }
   }

   private ServerPlayer nearestPerson() {
      ServerPlayer best = null;
      double bestScore = Double.MAX_VALUE;

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (p != this.bot) {
            double d = (double)this.bot.distanceTo(p);
            if (!(d > (double)16.0F) && p.isAlive() && !p.isSpectator() && p.level() == this.bot.level() && !p.getScoreboardName().equals(this.botName)) {
               double score = p instanceof BotPlayer ? d + (double)4.0F : d;
               if (score < bestScore) {
                  bestScore = score;
                  best = p;
               }
            }
         }
      }

      return best;
   }

   private void pickGaze(ServerPlayer near) {
      ThreadLocalRandom r = ThreadLocalRandom.current();
      if (this.holdTicks > 0) {
         --this.holdTicks;
      }

      if (near != null) {
         if (!near.getUUID().equals(this.attending)) {
            this.attending = near.getUUID();
            this.glancing = false;
            this.holdTicks = 60 + r.nextInt(120);
         }

         if (this.holdTicks <= 0) {
            if (this.glancing) {
               this.glancing = false;
               this.holdTicks = 60 + r.nextInt(140);
            } else {
               this.glancing = true;
               this.holdTicks = 15 + r.nextInt(30);
               this.goalYaw = this.bot.getYHeadRot() + (float)(r.nextBoolean() ? 1 : -1) * (float)r.nextDouble((double)25.0F, (double)80.0F);
               this.goalPitch = (float)r.nextDouble((double)-5.0F, (double)25.0F);
               this.hasGoal = true;
            }
         }

         if (!this.glancing) {
            this.setGoalAt(new Vec3(near.getX(), near.getEyeY(), near.getZ()));
         }

      } else {
         this.attending = null;
         this.glancing = false;
         if (this.holdTicks <= 0 || !this.hasGoal) {
            this.goalYaw = this.bot.getYHeadRot() + (float)r.nextDouble((double)-70.0F, (double)70.0F);
            this.goalPitch = (float)r.nextDouble((double)-8.0F, (double)22.0F);
            this.hasGoal = true;
            this.holdTicks = 40 + r.nextInt(100);
         }

      }
   }

   private void setGoalAt(Vec3 p) {
      Vec3 eye = this.bot.getEyePosition();
      float[] a = BotMath.getAngles(eye.x, eye.y, eye.z, p.x, p.y, p.z);
      this.goalYaw = a[0];
      this.goalPitch = a[1];
      this.hasGoal = true;
   }

   private void easeHead() {
      if (this.hasGoal) {
         ThreadLocalRandom r = ThreadLocalRandom.current();
         float yaw = this.bot.getYHeadRot();
         float pitch = this.bot.getXRot();
         float dy = BotMath.wrapDegrees(this.goalYaw - yaw);
         float dp = this.goalPitch - pitch;
         float stepY = Math.abs(dy) < 0.4F ? 0.0F : Math.min(14.0F, Math.max(0.4F, Math.abs(dy) * 0.35F));
         float stepP = Math.abs(dp) < 0.3F ? 0.0F : Math.min(9.0F, Math.max(0.3F, Math.abs(dp) * 0.35F));
         yaw += Math.signum(dy) * stepY;
         pitch += Math.signum(dp) * stepP;
         if (r.nextInt(7) == 0) {
            yaw += (float)r.nextDouble((double)-0.25F, (double)0.25F);
            pitch += (float)r.nextDouble(-0.15, 0.15);
         }

         yaw = BotMath.wrapDegrees(yaw);
         pitch = Math.max(-90.0F, Math.min(90.0F, pitch));
         this.bot.setYRot(yaw);
         this.bot.setYHeadRot(yaw);
         float off = BotMath.wrapDegrees(yaw - this.bot.yBodyRot);
         if (off > 50.0F) {
            this.bot.setYBodyRot(yaw - 50.0F);
         }

         if (off < -50.0F) {
            this.bot.setYBodyRot(yaw + 50.0F);
         }

         this.bot.setXRot(pitch);
      }
   }
}
