package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;
import vexbot.util.BotCommands;
import vexbot.util.ElytraFlight;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.StunSlam;

public final class WindBurstElytraController {
   private static final double LAUNCH_VEL_THRESHOLD = 0.35;
   private static final double DIVE_TARGET_HEIGHT = (double)10.0F;
   private static final int CLIMB_TICK_CAP = 40;
   private static final double DIVE_STANDOFF = (double)3.0F;
   private static final double DIVE_LEAD_TICKS = (double)4.0F;
   private static final double UNEQUIP_HEIGHT = (double)3.0F;
   private static final double SMASH_RANGE = (double)8.0F;
   private static final double MIN_FALL_DIST = (double)1.5F;
   private static final int COOLDOWN_TICKS = 10;
   private static final int MAX_PHASE_TICKS = 200;
   private static final int ARM_WINDOW_TICKS = 60;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int armTicksLeft;
   private int maceSlot;
   private int chestSaveSlot;
   private int elytraFromSlot;
   private int prevSelected;
   private boolean diveRocketFired;
   private int diveSide;
   private double sideX;
   private double sideZ;
   private double lastTgtX;
   private double lastTgtZ;
   private final DiveLead diveLead;
   private final DiveCover cover;
   private double diveOffX;
   private double diveOffZ;
   private static final Random RNG = new Random();
   private final StunSlam stunSlam;
   private final ServerPlayer bot;
   private final MinecraftServer server;

   private double smashHitRange() {
      return (new EffectiveSettings(this.bot.getScoreboardName())).attackRange();
   }

   public WindBurstElytraController(ServerPlayer bot, MinecraftServer server) {
      this.phase = WindBurstElytraController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldown = 0;
      this.armTicksLeft = 0;
      this.maceSlot = -1;
      this.chestSaveSlot = -1;
      this.elytraFromSlot = -1;
      this.prevSelected = 0;
      this.diveRocketFired = false;
      this.diveSide = 1;
      this.sideX = (double)0.0F;
      this.sideZ = (double)0.0F;
      this.lastTgtX = Double.NaN;
      this.lastTgtZ = Double.NaN;
      this.diveLead = new DiveLead();
      this.cover = new DiveCover();
      this.stunSlam = new StunSlam();
      this.bot = bot;
      this.server = server;
   }

   public boolean isExecuting() {
      return this.phase != WindBurstElytraController.Phase.IDLE;
   }

   public void reset() {
      if (this.phase != WindBurstElytraController.Phase.IDLE) {
         this.abort();
      }

   }

   public void armAfterSmash() {
      if (this.phase == WindBurstElytraController.Phase.IDLE && this.cooldown == 0) {
         this.armTicksLeft = 60;
      }

   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.armTicksLeft > 0) {
         --this.armTicksLeft;
      }

      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target);
         case 1 -> var10000 = this.tickEquipping();
         case 2 -> var10000 = this.tickGliding(target);
         case 3 -> var10000 = this.tickApexUnequip(target);
         case 4 -> var10000 = this.tickApexReequip(target);
         case 5 -> var10000 = this.tickDiving(target);
         case 6 -> var10000 = this.tickUnequipping();
         case 7 -> var10000 = this.tickSmashing(target);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private boolean tickIdle(LivingEntity target) {
      if (!EffectiveSettings.of(this.bot.getScoreboardName()).techniques().diveBomb) {
         return false;
      } else if (target != null && target.isAlive()) {
         if (this.cooldown > 0) {
            return false;
         } else if (this.armTicksLeft <= 0) {
            return false;
         } else if (this.bot.onGround()) {
            return false;
         } else {
            boolean rising = this.bot.getDeltaMovement().y >= 0.35;
            boolean highEnough = this.bot.getY() - target.getY() >= (double)10.0F;
            if (!rising && !highEnough) {
               return false;
            } else if (this.lostCover(target)) {
               return false;
            } else if (!ElytraSkill.continueChain(this.bot)) {
               this.armTicksLeft = 0;
               return false;
            } else {
               this.maceSlot = this.findMaceInHotbar();
               if (this.maceSlot < 0) {
                  return false;
               } else {
                  ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
                  if (ElytraFlight.isUsable(chest)) {
                     this.elytraFromSlot = -1;
                     this.chestSaveSlot = -1;
                  } else {
                     this.elytraFromSlot = this.findElytraInInventory();
                     if (this.elytraFromSlot < 0) {
                        return false;
                     }
                  }

                  this.prevSelected = InventoryUtils.selected(this.bot.getInventory());
                  this.armTicksLeft = 0;
                  this.enterPhase(WindBurstElytraController.Phase.EQUIPPING);
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private boolean tickEquipping() {
      ++this.phaseTick;
      if (this.phaseTick > 30) {
         this.abort();
         return false;
      } else if (this.elytraFromSlot == -1) {
         this.engageFallFlying();
         this.enterPhase(WindBurstElytraController.Phase.GLIDING);
         return true;
      } else {
         if (this.phaseTick == 1) {
            ItemStack currentChest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
            ItemStack elytra = this.bot.getInventory().getItem(this.elytraFromSlot).copy();
            this.bot.getInventory().setItem(this.elytraFromSlot, ItemStack.EMPTY);
            this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            if (!currentChest.isEmpty()) {
               this.chestSaveSlot = this.findFreeHotbarSlot();
               if (this.chestSaveSlot < 0) {
                  this.chestSaveSlot = this.elytraFromSlot;
               }

               this.bot.getInventory().setItem(this.chestSaveSlot, currentChest.copy());
            } else {
               this.chestSaveSlot = -1;
            }
         }

         ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         if (chest.is(Items.ELYTRA)) {
            this.engageFallFlying();
            this.enterPhase(WindBurstElytraController.Phase.GLIDING);
         }

         return true;
      }
   }

   private boolean tickGliding(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 200) {
            this.abort();
            return false;
         } else if (this.bot.onGround() && this.phaseTick > 5) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            this.engageFallFlying();
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            if (this.phaseTick == 1) {
               this.bot.setXRot(-90.0F);
            }

            double heightAboveTarget = this.bot.getY() - target.getY();
            boolean atApex = this.phaseTick >= 4 && this.bot.getDeltaMovement().y <= (double)0.0F;
            if (!(heightAboveTarget >= (double)10.0F) && !atApex && this.phaseTick <= 40) {
               Vec3 eye = this.bot.getEyePosition();
               double yr = Math.toRadians((double)this.bot.getYRot());
               this.smoothAimAtPoint(eye.x - Math.sin(yr), eye.y + (double)50.0F, eye.z + Math.cos(yr), (double)12.0F);
               return true;
            } else {
               this.enterPhase(WindBurstElytraController.Phase.APEX_UNEQUIP);
               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickApexUnequip(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 30) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            if (this.phaseTick == 1) {
               if (this.chestSaveSlot < 0) {
                  this.chestSaveSlot = this.findFreeSlot();
                  if (this.chestSaveSlot < 0) {
                     this.aimAt(target, true);
                     this.enterPhase(WindBurstElytraController.Phase.DIVING);
                     return true;
                  }
               }

               this.swapChestEquipment();
            }

            this.aimAt(target, true);
            if (this.phaseTick > 3 && !this.bot.isFallFlying()) {
               this.enterPhase(WindBurstElytraController.Phase.APEX_REEQUIP);
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickApexReequip(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 10) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            if (this.phaseTick == 1) {
               this.swapChestEquipment();
            }

            this.aimAt(target, true);
            if (this.phaseTick >= 2) {
               this.enterPhase(WindBurstElytraController.Phase.DIVING);
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickDiving(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 200) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            if (this.phaseTick == 1) {
               this.diveRocketFired = false;
               this.lastTgtX = Double.NaN;
               this.lastTgtZ = Double.NaN;
               double[] off = ElytraSkill.diveOffset(this.bot);
               this.diveOffX = off[0];
               this.diveOffZ = off[1];
            }

            double steer = ElytraSkill.steer(this.bot);
            this.engageFallFlying();
            BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
            this.bot.setSprinting(false);
            boolean targetStationary = !this.diveLead.moving(target);
            double aimOffX = (double)0.0F;
            double aimOffZ = (double)0.0F;
            if (target.isBlocking() && this.backstabAllowed() && (double)this.bot.distanceTo(target) > (double)4.0F) {
               Vec3 look = target.getLookAngle().normalize();
               aimOffX = -look.x * (double)2.0F;
               aimOffZ = -look.z * (double)2.0F;
            }

            aimOffX += this.diveOffX;
            aimOffZ += this.diveOffZ;
            double hx = target.getX() + aimOffX - this.bot.getX();
            double hz = target.getZ() + aimOffZ - this.bot.getZ();
            double hd = Math.sqrt(hx * hx + hz * hz);
            if (targetStationary) {
               if (hd <= 1.2) {
                  this.bot.setXRot(90.0F);
                  this.bot.yHeadRot = this.bot.getYRot();
                  Vec3 dm = this.bot.getDeltaMovement();
                  this.bot.setDeltaMovement(hx * (double)0.25F * steer, dm.y, hz * (double)0.25F * steer);
               } else {
                  this.smoothAimAtPoint(target.getX(), target.getY(), target.getZ(), (double)22.0F);
                  if (this.bot.getXRot() < 60.0F) {
                     this.bot.setXRot(60.0F);
                  }

                  Vec3 dm = this.bot.getDeltaMovement();
                  double step = Math.min(0.35, hd * 0.4) * steer;
                  this.bot.setDeltaMovement(hx / hd * step, dm.y, hz / hd * step);
               }

               this.lastTgtX = target.getX();
               this.lastTgtZ = target.getZ();
            } else {
               this.lastTgtX = target.getX();
               this.lastTgtZ = target.getZ();
               int eta = Math.max(4, DiveLead.ticksToDrop(Math.max((double)0.0F, this.bot.getY() - target.getY() - (double)1.0F), this.bot.getDeltaMovement().y));
               Vec3 aimPt = this.diveLead.lead(target, eta);
               double aimY = target.getY() + (double)target.getBbHeight() * (double)0.5F;
               this.smoothAimAtPoint(aimPt.x + aimOffX, aimY, aimPt.z + aimOffZ, (double)22.0F);
            }

            if (!this.diveRocketFired && this.bot.isFallFlying() && (this.bot.getXRot() >= 45.0F || this.phaseTick >= 8) && (new EffectiveSettings(this.bot.getScoreboardName())).techniques().rocketMace) {
               this.fireRocket();
               this.diveRocketFired = true;
            }

            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            double heightAboveTarget = this.bot.getY() - target.getY();
            double dist = (double)this.bot.distanceTo(target);
            if (heightAboveTarget <= (double)3.0F || dist <= (double)8.0F) {
               this.enterPhase(WindBurstElytraController.Phase.UNEQUIPPING);
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickUnequipping() {
      ++this.phaseTick;
      if (this.phaseTick == 1) {
         ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         if (chest.is(Items.ELYTRA)) {
            Inventory inv = this.bot.getInventory();
            ItemStack saved = this.chestSaveSlot >= 0 ? inv.getItem(this.chestSaveSlot) : ItemStack.EMPTY;
            if (this.chestSaveSlot < 0 || !saved.isEmpty() && !isChestplate(saved)) {
               int store = this.findFreeSlot();
               if (store >= 0) {
                  this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                  inv.setItem(store, chest.copy());
               }
            } else {
               this.bot.setItemSlot(EquipmentSlot.CHEST, saved.copy());
               inv.setItem(this.chestSaveSlot, chest.copy());
            }

            this.bot.stopFallFlying();
         }

         InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
      }

      if (this.phaseTick > 10 && this.bot.isFallFlying()) {
         this.abort();
         return false;
      } else {
         if (!this.bot.isFallFlying()) {
            this.enterPhase(WindBurstElytraController.Phase.SMASHING);
         }

         return true;
      }
   }

   private boolean tickSmashing(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 60) {
            this.abort();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.smoothAimAtPoint(target.getX(), target.getEyeY(), target.getZ(), (double)18.0F);
            double dist = (double)this.bot.distanceTo(target);
            boolean inRange = dist <= this.smashHitRange();
            boolean hasFall = this.bot.fallDistance > (double)1.5F && MaceSmashGates.botMayUseSmashFallBonus(this.bot);
            boolean landed = this.bot.onGround() && this.phaseTick > 3;
            BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
            this.bot.setSprinting(false);
            if (!this.bot.onGround()) {
               Vec3 aimPt = this.diveLead.lead(target, DiveLead.ticksToDrop(this.bot.getY() - target.getEyeY(), this.bot.getDeltaMovement().y)).add(this.diveOffX, (double)0.0F, this.diveOffZ);
               double hx = aimPt.x - this.bot.getX();
               double hz = aimPt.z - this.bot.getZ();
               double hd = Math.sqrt(hx * hx + hz * hz);
               if (hd > 0.05) {
                  double step = Math.min(0.42, hd * (double)0.5F) * ElytraSkill.steer(this.bot);
                  Vec3 dm = this.bot.getDeltaMovement();
                  this.bot.setDeltaMovement(hx / hd * step, dm.y, hz / hd * step);
               }
            }

            if (inRange && hasFall) {
               if (!this.bot.hasLineOfSight(target)) {
                  if (landed) {
                     this.abort();
                     return false;
                  } else {
                     return true;
                  }
               } else {
                  this.bot.setSprinting(true);
                  EffectiveSettings ssEffs = EffectiveSettings.of(this.bot.getScoreboardName());
                  TechniqueConfig ssCfg = ssEffs.techniques();
                  boolean mayAirSlam = ssCfg.elytraStunSlam && ssEffs.difficultyParams().elytraMaceLevel >= 4;
                  StunSlam.Result ssRes = this.stunSlam.tick(this.bot, target, this.findAxeSlot(), this.maceSlot, ssCfg.stunSlamVariant, mayAirSlam, ssEffs);
                  if (ssRes == StunSlam.Result.HOLD) {
                     return true;
                  } else {
                     if (ssRes != StunSlam.Result.SMASHED) {
                        InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                        EquipmentSync.syncNow(this.bot);
                        if (!ElytraSkill.whiff(this.bot)) {
                           this.bot.attack(target);
                        }

                        McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                     }

                     this.cooldown = 0;
                     this.diveSide *= -1;
                     if (this.equipElytraNow()) {
                        this.engageFallFlying();
                        this.enterPhase(WindBurstElytraController.Phase.GLIDING);
                     } else {
                        InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
                        this.armTicksLeft = 60;
                        this.enterPhase(WindBurstElytraController.Phase.IDLE);
                     }

                     return false;
                  }
               }
            } else if (landed) {
               this.abort();
               return false;
            } else {
               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private void enterPhase(Phase p) {
      this.phase = p;
      this.phaseTick = 0;
   }

   private boolean equipElytraNow() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (ElytraFlight.isUsable(chest)) {
         return true;
      } else {
         int slot = this.findElytraInInventory();
         if (slot < 0) {
            return false;
         } else {
            ItemStack elytra = this.bot.getInventory().getItem(slot).copy();
            this.bot.getInventory().setItem(slot, ItemStack.EMPTY);
            if (!chest.isEmpty()) {
               this.chestSaveSlot = this.findFreeHotbarSlot();
               if (this.chestSaveSlot < 0) {
                  this.chestSaveSlot = slot;
               }

               this.bot.getInventory().setItem(this.chestSaveSlot, chest.copy());
            } else {
               this.chestSaveSlot = -1;
            }

            this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            return true;
         }
      }
   }

   private boolean lostCover(LivingEntity target) {
      return target.onGround() && !this.cover.reachable(target, this.bot.tickCount);
   }

   private void abort() {
      if (this.bot.onGround()) {
         this.restoreChest();
      } else {
         ElytraFlight.beginGlide(this.bot);
      }

      InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
      this.cooldown = 5;
      this.enterPhase(WindBurstElytraController.Phase.IDLE);
   }

   private void restoreChest() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (chest.is(Items.ELYTRA) && this.chestSaveSlot >= 0) {
         ItemStack saved = this.bot.getInventory().getItem(this.chestSaveSlot);
         if (!saved.isEmpty() && !isChestplate(saved)) {
            return;
         }

         ItemStack chestplate = saved.copy();
         this.bot.setItemSlot(EquipmentSlot.CHEST, chestplate);
         this.bot.getInventory().setItem(this.chestSaveSlot, chest.copy());
      }

   }

   private void swapChestEquipment() {
      if (this.chestSaveSlot >= 0) {
         ItemStack chestSlotItem = this.bot.getItemBySlot(EquipmentSlot.CHEST).copy();
         ItemStack savedItem = this.bot.getInventory().getItem(this.chestSaveSlot).copy();
         this.bot.setItemSlot(EquipmentSlot.CHEST, savedItem);
         this.bot.getInventory().setItem(this.chestSaveSlot, chestSlotItem);
      }
   }

   private void engageFallFlying() {
      if (!this.bot.isFallFlying()) {
         ElytraFlight.beginGlide(this.bot);
      }

   }

   private boolean backstabAllowed() {
      TechniqueConfig t = (new EffectiveSettings(this.bot.getScoreboardName())).techniques();
      return t.elytraBackstab && !t.stunSlamEnabled();
   }

   private void fireRocket() {
      Inventory inv = this.bot.getInventory();
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
            slot = i;
            break;
         }
      }

      if (slot < 0) {
         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
               slot = i;
               break;
            }
         }

         if (slot < 0) {
            return;
         }

         slot = InventoryUtils.moveToHotbarSafe(inv, slot);
      }

      int prev = InventoryUtils.selected(inv);
      InventoryUtils.select(inv, slot);
      this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(slot), InteractionHand.MAIN_HAND);
      InventoryUtils.select(inv, prev);
   }

   private void aimAt(LivingEntity target, boolean steep) {
      double dx = target.getX() - this.bot.getEyePosition().x;
      double dy = target.getEyeY() - this.bot.getEyePosition().y;
      double dz = target.getZ() - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      if (steep) {
         pitch = Math.max(pitch, 60.0F);
      }

      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void aimAtPoint(double x, double y, double z) {
      double dx = x - this.bot.getEyePosition().x;
      double dy = y - this.bot.getEyePosition().y;
      double dz = z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void smoothAimAtPoint(double x, double y, double z, double maxStepDeg) {
      double dx = x - this.bot.getEyePosition().x;
      double dy = y - this.bot.getEyePosition().y;
      double dz = z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float wantYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float wantPitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      float newYaw = approachAngle(this.bot.getYRot(), wantYaw, (float)maxStepDeg);
      float newPitch = approachAngle(this.bot.getXRot(), wantPitch, (float)maxStepDeg);
      this.bot.setYRot(newYaw);
      this.bot.setXRot(newPitch);
      this.bot.yHeadRot = newYaw;
   }

   private static float approachAngle(float cur, float want, float maxStep) {
      float delta = (want - cur) % 360.0F;
      if (delta > 180.0F) {
         delta -= 360.0F;
      }

      if (delta < -180.0F) {
         delta += 360.0F;
      }

      if (delta > maxStep) {
         delta = maxStep;
      }

      if (delta < -maxStep) {
         delta = -maxStep;
      }

      return cur + delta;
   }

   private int findAxeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.AXES)) {
            return i;
         }
      }

      return -1;
   }

   private int findMaceInHotbar() {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestScore = (double)-1.0F;

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.MACE)) {
            double score = ItemEvaluator.scoreMace(s);
            if (score > bestScore) {
               bestScore = score;
               best = i;
            }
         }
      }

      return best;
   }

   private int findElytraInInventory() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (ElytraFlight.isUsable(s)) {
            return i;
         }
      }

      return -1;
   }

   private int findFreeHotbarSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).isEmpty()) {
            return i;
         }
      }

      return -1;
   }

   private int findFreeSlot() {
      int slot = this.findFreeHotbarSlot();
      if (slot >= 0) {
         return slot;
      } else {
         Inventory inv = this.bot.getInventory();

         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).isEmpty()) {
               return i;
            }
         }

         return -1;
      }
   }

   private static boolean isChestplate(ItemStack s) {
      return !s.is(Items.ELYTRA) && ArmorEvaluator.getSlot(s) == EquipmentSlot.CHEST;
   }

   private static enum Phase {
      IDLE,
      EQUIPPING,
      GLIDING,
      APEX_UNEQUIP,
      APEX_REEQUIP,
      DIVING,
      UNEQUIPPING,
      SMASHING;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, EQUIPPING, GLIDING, APEX_UNEQUIP, APEX_REEQUIP, DIVING, UNEQUIPPING, SMASHING};
      }
   }
}
