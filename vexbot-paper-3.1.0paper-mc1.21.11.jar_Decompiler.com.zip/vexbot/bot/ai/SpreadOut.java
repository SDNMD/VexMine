package vexbot.bot.ai;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.team.TeamManager;

public final class SpreadOut {
   public static final int MIN_TEAM = 100;
   private static final double ENGAGE_RANGE = (double)5.0F;
   private static final long ENGAGED_TICKS = 100L;
   private static final Map<String, Long> ENGAGED = new ConcurrentHashMap();
   private static final Map<String, Roster> ROSTERS = new ConcurrentHashMap();
   private static final double STANDOFF = (double)10.0F;
   private static final double ASPECT = (double)3.0F;
   private static final int MIN_WIDTH = 12;
   private static final double SPACING = (double)4.0F;

   private SpreadOut() {
   }

   public static void clearEngaged(String teamName) {
      if (teamName != null) {
         ENGAGED.remove(teamName);
      }

   }

   public static Vec3 standoffFor(ServerPlayer bot, String botName, LivingEntity target) {
      if (bot != null && target != null) {
         TeamManager.BotTeam team = TeamManager.getTeamForBot(botName);
         if (team == null) {
            return null;
         } else if (!EffectiveSettings.of(botName).spreadOut()) {
            return null;
         } else {
            String teamName = team.getName();
            long now = bot.level().getGameTime();
            if (bot.hurtTime <= 0 && !((double)bot.distanceTo(target) <= (double)5.0F)) {
               Long last = (Long)ENGAGED.get(teamName);
               if (last != null && now - last >= 0L && now - last < 100L) {
                  return null;
               } else {
                  Set<String> names = team.getBotNames();
                  int sourceSize = names.size();
                  if (sourceSize <= 100) {
                     return null;
                  } else {
                     Roster roster = (Roster)ROSTERS.get(teamName);
                     if (roster == null || roster.gameTime() != now || roster.sourceSize() != sourceSize) {
                        List<String> sorted = new ArrayList(names);
                        sorted.sort(String.CASE_INSENSITIVE_ORDER);
                        Map<String, Integer> ranks = new HashMap(sorted.size() * 2);

                        for(int i = 0; i < sorted.size(); ++i) {
                           ranks.putIfAbsent(((String)sorted.get(i)).toLowerCase(Locale.ROOT), i);
                        }

                        roster = new Roster(now, sourceSize, sorted.size(), ranks);
                        ROSTERS.put(teamName, roster);
                     }

                     if (roster.size() <= 100) {
                        return null;
                     } else {
                        Integer found = (Integer)roster.rankByName().get(botName.toLowerCase(Locale.ROOT));
                        if (found == null) {
                           return null;
                        } else {
                           int rank = found;
                           int holders = roster.size();
                           FormationAnchor.Anchored anchor = FormationAnchor.of(target, bot.level().getGameTime());
                           float yaw = anchor.yaw();
                           double rad = Math.toRadians((double)yaw);
                           double fx = -Math.sin(rad);
                           double fz = Math.cos(rad);
                           Vec3 a = anchor.pos();
                           Vec3 base = new Vec3(a.x - fx * (double)10.0F, a.y, a.z - fz * (double)10.0F);
                           return FollowFormation.slotWorldSpaced(FollowFormation.Type.GRID, rank, holders, widthFor(holders), base, yaw, (double)4.0F);
                        }
                     }
                  }
               }
            } else {
               ENGAGED.put(teamName, now);
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private static int widthFor(int holders) {
      return Math.max(12, (int)Math.ceil(Math.sqrt((double)holders * (double)3.0F)));
   }

   private static record Roster(long gameTime, int sourceSize, int size, Map<String, Integer> rankByName) {
   }
}
