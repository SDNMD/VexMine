package vexbot.bot.ai;

import java.util.Locale;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

public final class OrbitalStrikeController {
   private static final int CONFIRM_DELAY = 4;
   private static final int CONFIRM_TRIES = 2;
   private static final int SURVIVE_TICKS = 60;
   private static final int COOLDOWN = 200;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int runTicks;
   private Vec3 strikePos;
   private Kind confirmKind;
   private LivingEntity confirmTarget;
   private int confirmTries;

   public OrbitalStrikeController(ServerPlayer bot, MinecraftServer server) {
      this.phase = OrbitalStrikeController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldown = 0;
      this.runTicks = 0;
      this.strikePos = null;
      this.confirmKind = null;
      this.confirmTarget = null;
      this.confirmTries = 0;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   public boolean isActive() {
      return this.phase != OrbitalStrikeController.Phase.SURVIVE || this.phaseTick > 0;
   }

   public void reset() {
      if (this.phase == OrbitalStrikeController.Phase.SURVIVE && this.bot.isUsingItem()) {
         this.bot.stopUsingItem();
      }

      if (this.phase == OrbitalStrikeController.Phase.RUN) {
         BotCommands.stopMoving(this.server, this.botName);
      }

      this.strikePos = null;
      this.confirmKind = null;
      this.confirmTarget = null;
      this.phase = OrbitalStrikeController.Phase.IDLE;
      this.phaseTick = 0;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      if (this.phase == OrbitalStrikeController.Phase.SURVIVE) {
         return this.tickSurvive();
      } else if (this.phase == OrbitalStrikeController.Phase.RUN) {
         return this.tickRun();
      } else if (this.phase == OrbitalStrikeController.Phase.CONFIRM) {
         return this.tickConfirm();
      } else if (target != null && target.isAlive() && this.cooldown <= 0) {
         int slot = this.findOrbitalRodSlot();
         if (slot < 0) {
            return false;
         } else {
            Kind kind = kindOf(this.bot.getInventory().getItem(slot));
            boolean aim = kind.aimed();
            if (kind.overworldOnly && this.bot.level().dimension() != Level.OVERWORLD) {
               return false;
            } else if (!(dist < kind.minDist) && !(dist > kind.maxDist)) {
               if (aim && !this.bot.hasLineOfSight(target)) {
                  return false;
               } else {
                  Inventory inv = this.bot.getInventory();
                  InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, slot));
                  BotCommands.stopMoving(this.server, this.botName);
                  this.aimAt(kind, target);
                  ItemStack rod = this.bot.getMainHandItem();
                  if (rod.is(Items.FISHING_ROD)) {
                     McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                     this.bot.gameMode.useItem(this.bot, this.bot.level(), rod, InteractionHand.MAIN_HAND);
                  }

                  this.cooldown = 200;
                  if (orbitalPlusMode(this.bot.getMainHandItem()) != null) {
                     this.phase = OrbitalStrikeController.Phase.CONFIRM;
                     this.phaseTick = 0;
                     this.confirmKind = kind;
                     this.confirmTarget = target;
                     this.confirmTries = 0;
                     return true;
                  } else {
                     return this.afterFire(kind, target);
                  }
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private boolean afterFire(Kind kind, LivingEntity target) {
      boolean aim = kind.aimed();
      if (kind.runTicks > 0) {
         this.phase = OrbitalStrikeController.Phase.RUN;
         this.runTicks = kind.runTicks;
         this.strikePos = target.position();
         return true;
      } else if (aim) {
         return true;
      } else {
         this.phase = OrbitalStrikeController.Phase.SURVIVE;
         this.phaseTick = 0;
         return true;
      }
   }

   private boolean tickConfirm() {
      ++this.phaseTick;
      BotCommands.stopMoving(this.server, this.botName);
      LivingEntity target = this.confirmTarget;
      Kind kind = this.confirmKind;
      ItemStack rod = this.bot.getMainHandItem();
      if (target != null && kind != null && target.isAlive() && rod.is(Items.FISHING_ROD)) {
         this.aimAt(kind, target);
         if (orbitalPlusMode(rod) == null) {
            this.phase = OrbitalStrikeController.Phase.IDLE;
            this.confirmKind = null;
            this.confirmTarget = null;
            return this.afterFire(kind, target);
         } else if (this.phaseTick % 4 != 0) {
            return true;
         } else if (this.confirmTries++ >= 2) {
            this.phase = OrbitalStrikeController.Phase.IDLE;
            this.confirmKind = null;
            this.confirmTarget = null;
            return false;
         } else {
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            this.bot.gameMode.useItem(this.bot, this.bot.level(), rod, InteractionHand.MAIN_HAND);
            return true;
         }
      } else {
         this.phase = OrbitalStrikeController.Phase.IDLE;
         this.confirmKind = null;
         this.confirmTarget = null;
         return false;
      }
   }

   private boolean tickSurvive() {
      ++this.phaseTick;
      BotCommands.stopMoving(this.server, this.botName);
      this.bot.setSprinting(false);
      int shieldSlot = this.findShieldSlot();
      if (shieldSlot >= 0) {
         Inventory inv = this.bot.getInventory();
         InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, shieldSlot));
         this.bot.setXRot(90.0F);
         this.bot.yHeadRot = this.bot.getYRot();
         if (!this.bot.isUsingItem()) {
            this.bot.startUsingItem(InteractionHand.MAIN_HAND);
         }
      }

      if (this.phaseTick >= 60) {
         if (this.bot.isUsingItem()) {
            this.bot.stopUsingItem();
         }

         this.phase = OrbitalStrikeController.Phase.IDLE;
         this.phaseTick = 0;
         return false;
      } else {
         return true;
      }
   }

   private boolean tickRun() {
      if (--this.runTicks > 0 && this.strikePos != null) {
         double dx = this.bot.getX() - this.strikePos.x;
         double dz = this.bot.getZ() - this.strikePos.z;
         float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         this.bot.setYRot(yaw);
         this.bot.yHeadRot = yaw;
         this.bot.setXRot(0.0F);
         this.bot.setSprinting(true);
         BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
         return true;
      } else {
         BotCommands.stopMoving(this.server, this.botName);
         this.phase = OrbitalStrikeController.Phase.IDLE;
         this.strikePos = null;
         return false;
      }
   }

   private int findOrbitalRodSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (isOrbitalRod(inv.getItem(i))) {
            return i;
         }
      }

      return -1;
   }

   private static boolean isOrbitalRod(ItemStack st) {
      if (!st.isEmpty() && st.is(Items.FISHING_ROD)) {
         CustomData cd = (CustomData)st.get(DataComponents.CUSTOM_DATA);
         if (cd == null) {
            return false;
         } else {
            CompoundTag t = cd.copyTag();
            if (cannonRodName(st, t) != null) {
               return true;
            } else if (orbitalPlusMode(t) != null) {
               return true;
            } else {
               for(String k : t.keySet()) {
                  String lk = k.toLowerCase(Locale.ROOT);
                  if (lk.startsWith("stab") || lk.startsWith("nuke") || lk.startsWith("c_nuke")) {
                     return true;
                  }
               }

               return false;
            }
         }
      } else {
         return false;
      }
   }

   private static String cannonRodName(ItemStack st, CompoundTag t) {
      if (!t.contains("Orbital_Cannon") && !t.contains("wolf_cannon")) {
         return null;
      } else {
         Component name = (Component)st.get(DataComponents.CUSTOM_NAME);
         if (name == null) {
            return null;
         } else {
            String var10000;
            switch (name.getString()) {
               case "Nuke Shot":
               case "Stab Shot":
               case "Law-Nuke Shot":
               case "Wither Nuke Shot":
               case "Arrow Shot":
               case "Wolf Rod":
                  var10000 = name.getString();
                  break;
               default:
                  var10000 = null;
            }

            return var10000;
         }
      }
   }

   private static String orbitalPlusMode(ItemStack st) {
      if (!st.isEmpty() && st.is(Items.FISHING_ROD)) {
         CustomData cd = (CustomData)st.get(DataComponents.CUSTOM_DATA);
         return cd == null ? null : orbitalPlusMode(cd.copyTag());
      } else {
         return null;
      }
   }

   private static String orbitalPlusMode(CompoundTag t) {
      String var10000;
      switch (t.getStringOr("OrbitalMode", "")) {
         case "stab":
         case "nuke":
         case "railgun":
         case "wolf":
            var10000 = mode;
            break;
         default:
            var10000 = null;
      }

      return var10000;
   }

   private static Kind kindOf(ItemStack st) {
      CustomData cd = (CustomData)st.get(DataComponents.CUSTOM_DATA);
      CompoundTag t = cd == null ? new CompoundTag() : cd.copyTag();
      String plus = orbitalPlusMode(t);
      if (plus != null) {
         Kind var7;
         switch (plus) {
            case "nuke" -> var7 = OrbitalStrikeController.Kind.OPLUS_NUKE;
            case "stab" -> var7 = OrbitalStrikeController.Kind.OPLUS_STAB;
            case "railgun" -> var7 = OrbitalStrikeController.Kind.OPLUS_RAILGUN;
            default -> var7 = OrbitalStrikeController.Kind.OPLUS_WOLF;
         }

         return var7;
      } else {
         String cannon = cannonRodName(st, t);
         if (cannon != null) {
            Kind var10000;
            switch (cannon) {
               case "Stab Shot" -> var10000 = OrbitalStrikeController.Kind.STAB;
               case "Wither Nuke Shot" -> var10000 = OrbitalStrikeController.Kind.WITHER_NUKE;
               case "Arrow Shot" -> var10000 = OrbitalStrikeController.Kind.ARROW;
               case "Wolf Rod" -> var10000 = OrbitalStrikeController.Kind.WOLF;
               default -> var10000 = OrbitalStrikeController.Kind.NUKE;
            }

            return var10000;
         } else {
            return isAimRod(st) ? OrbitalStrikeController.Kind.STEPAN_AIM : OrbitalStrikeController.Kind.STEPAN_SELF;
         }
      }
   }

   private static boolean isAimRod(ItemStack st) {
      CustomData cd = (CustomData)st.get(DataComponents.CUSTOM_DATA);
      if (cd == null) {
         return false;
      } else {
         for(String k : cd.copyTag().keySet()) {
            if (k.toLowerCase(Locale.ROOT).contains("aim")) {
               return true;
            }
         }

         return false;
      }
   }

   private int findShieldSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.SHIELD)) {
            return i;
         }
      }

      return -1;
   }

   private void aimAt(Kind kind, LivingEntity target) {
      if (kind.atEntity()) {
         this.faceEntity(target);
      } else if (kind.aimed()) {
         this.faceGroundAt(target);
      } else {
         this.faceCastForward();
      }

   }

   private void faceEntity(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dy = target.getEyeY() - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getZ();
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, Math.max(horiz, 0.001)))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private void faceGroundAt(LivingEntity target) {
      double dx = target.getX() - this.bot.getX();
      double dy = target.getY() - 0.1 - this.bot.getEyeY();
      double dz = target.getZ() - this.bot.getZ();
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, Math.max(horiz, 0.001)))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private void faceCastForward() {
      this.bot.setXRot(0.0F);
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private static enum Kind {
      STEPAN_AIM((double)0.0F, (double)40.0F, 0, false),
      STEPAN_SELF((double)0.0F, (double)10.0F, 0, false),
      NUKE((double)32.0F, (double)64.0F, 110, true),
      WITHER_NUKE((double)32.0F, (double)64.0F, 80, false),
      STAB((double)12.0F, (double)64.0F, 40, true),
      ARROW((double)6.0F, (double)48.0F, 0, true),
      WOLF((double)6.0F, (double)48.0F, 0, true),
      OPLUS_NUKE((double)48.0F, (double)96.0F, 100, false),
      OPLUS_STAB((double)12.0F, (double)96.0F, 40, false),
      OPLUS_RAILGUN((double)8.0F, (double)64.0F, 0, false),
      OPLUS_WOLF((double)0.0F, (double)24.0F, 0, false);

      final double minDist;
      final double maxDist;
      final int runTicks;
      final boolean overworldOnly;

      private Kind(double minDist, double maxDist, int runTicks, boolean overworldOnly) {
         this.minDist = minDist;
         this.maxDist = maxDist;
         this.runTicks = runTicks;
         this.overworldOnly = overworldOnly;
      }

      boolean aimed() {
         return this != STEPAN_SELF;
      }

      boolean atEntity() {
         return this == STEPAN_AIM || this == OPLUS_RAILGUN;
      }

      // $FF: synthetic method
      private static Kind[] $values() {
         return new Kind[]{STEPAN_AIM, STEPAN_SELF, NUKE, WITHER_NUKE, STAB, ARROW, WOLF, OPLUS_NUKE, OPLUS_STAB, OPLUS_RAILGUN, OPLUS_WOLF};
      }
   }

   private static enum Phase {
      IDLE,
      CASTING,
      CONFIRM,
      SURVIVE,
      RUN;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, CASTING, CONFIRM, SURVIVE, RUN};
      }
   }
}
