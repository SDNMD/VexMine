package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;
import vexbot.util.BotCommands;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.StunSlam;
import vexbot.util.SwapEngine;

public final class MaceController {
   private Phase phase;
   private int phaseTick;
   private int cooldownLeft;
   private double launchY;
   private double targetHeight;
   private int prevSlot;
   private int maceSlot;
   private int windChargeSlot;
   private static final int MAX_AIRBORNE_TICKS = 80;
   private static final int MAX_SMASH_TICKS = 40;
   private static final int COOLDOWN_TICKS = 40;
   private static final double MIN_FALL_DIST = (double)1.5F;
   private static final double TRIGGER_RANGE = (double)7.0F;
   private static final Random RNG = new Random();
   private final StunSlam stunSlam;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private boolean crouchBoostActive;
   private final DiveLead lead;

   private double attackRange() {
      return (new EffectiveSettings(this.bot.getScoreboardName())).attackRange();
   }

   public MaceController(ServerPlayer bot, MinecraftServer server) {
      this.phase = MaceController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldownLeft = 0;
      this.launchY = (double)0.0F;
      this.targetHeight = (double)0.0F;
      this.prevSlot = 0;
      this.maceSlot = -1;
      this.windChargeSlot = -1;
      this.stunSlam = new StunSlam();
      this.crouchBoostActive = false;
      this.lead = new DiveLead();
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldownLeft > 0) {
         --this.cooldownLeft;
      }

      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target, dist);
         case 1 -> var10000 = this.tickLaunching();
         case 2 -> var10000 = this.tickAirborne(target);
         case 3 -> var10000 = this.tickSmashing(target);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public boolean isExecuting() {
      return this.phase != MaceController.Phase.IDLE;
   }

   public boolean hasGearForCombo() {
      return this.findMaceSlot() >= 0 && this.findWindChargeSlot() >= 0;
   }

   public void reset() {
      if (this.phase != MaceController.Phase.IDLE) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      }

      this.phase = MaceController.Phase.IDLE;
      this.phaseTick = 0;
   }

   private boolean tickIdle(LivingEntity target, double dist) {
      if (!EffectiveSettings.of(this.bot.getScoreboardName()).techniques().windchargeMace) {
         return false;
      } else if (target != null && target.isAlive()) {
         if (this.cooldownLeft > 0) {
            return false;
         } else if (!this.bot.onGround()) {
            return false;
         } else if (dist > (double)7.0F) {
            return false;
         } else if ((new EffectiveSettings(this.bot.getScoreboardName())).techniques().wcFullCooldownDiscipline && this.bot.getCooldowns().isOnCooldown(new ItemStack(Items.WIND_CHARGE))) {
            return false;
         } else {
            this.maceSlot = this.findMaceSlot();
            this.windChargeSlot = this.findWindChargeSlot();
            if (this.maceSlot >= 0 && this.windChargeSlot >= 0) {
               if (!EffectiveSettings.of(this.bot.getScoreboardName()).roll()) {
                  this.cooldownLeft = 20;
                  return false;
               } else {
                  this.prevSlot = this.bot.getInventory().getSelectedSlot();
                  this.targetHeight = this.rollTargetHeight();
                  this.enterPhase(MaceController.Phase.LAUNCHING);
                  return true;
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private boolean tickLaunching() {
      ++this.phaseTick;
      String name = this.bot.getScoreboardName();
      InventoryUtils.select(this.bot.getInventory(), this.windChargeSlot);
      this.bot.setXRot(80.0F);
      BotCommands.stopMoving(this.server, name);
      this.bot.setSprinting(false);
      if (this.phaseTick >= 2) {
         this.launchY = this.bot.getY();
         boolean crouch = (new EffectiveSettings(this.bot.getScoreboardName())).techniques().wcCrouchBoost;
         if (crouch) {
            this.bot.setShiftKeyDown(true);
         }

         BotCommands.jumpOnce(this.server, this.bot.getScoreboardName());
         this.fireWindCharge();
         if (crouch) {
            this.crouchBoostActive = true;
         }

         this.enterPhase(MaceController.Phase.AIRBORNE);
      }

      return true;
   }

   private boolean tickAirborne(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 80) {
            this.abort();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            double heightGained = this.bot.getY() - this.launchY;
            double yVel = this.bot.getDeltaMovement().y;
            this.faceTarget(target);
            this.driftToward(target);
            boolean reachedGoal = yVel < -0.05 && heightGained >= this.targetHeight;
            boolean alreadyFalling = yVel < -0.05 && this.phaseTick > 20;
            if (reachedGoal || alreadyFalling) {
               this.enterPhase(MaceController.Phase.SMASHING);
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickSmashing(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 40) {
            this.abort();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.faceTarget(target);
            this.driftToward(target);
            double dist = (double)this.bot.distanceTo(target);
            boolean inRange = dist <= this.attackRange();
            boolean hasFall = this.bot.fallDistance > (double)1.5F && MaceSmashGates.botMayUseSmashFallBonus(this.bot);
            boolean landed = this.bot.onGround() && this.phaseTick > 3;
            if (inRange && hasFall) {
               if (!this.bot.hasLineOfSight(target)) {
                  if (landed) {
                     this.abort();
                     return false;
                  } else {
                     return true;
                  }
               } else {
                  this.bot.setSprinting(true);
                  EffectiveSettings ssEffs = EffectiveSettings.of(this.bot.getScoreboardName());
                  TechniqueConfig ssCfg = ssEffs.techniques();
                  StunSlam.Result ssRes = this.stunSlam.tick(this.bot, target, this.findAxeSlot(), this.maceSlot, ssCfg.stunSlamVariant, ssCfg.stunSlam, ssEffs);
                  if (ssRes == StunSlam.Result.HOLD) {
                     return true;
                  } else {
                     if (ssRes != StunSlam.Result.SMASHED) {
                        InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                        EquipmentSync.syncNow(this.bot);
                        this.bot.attack(target);
                        McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                     }

                     InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
                     this.cooldownLeft = 40;
                     this.enterPhase(MaceController.Phase.IDLE);
                     return false;
                  }
               }
            } else if (landed) {
               this.abort();
               return false;
            } else {
               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private void enterPhase(Phase p) {
      this.phase = p;
      this.phaseTick = 0;
   }

   private void abort() {
      InventoryUtils.select(this.bot.getInventory(), this.prevSlot);
      this.cooldownLeft = 20;
      this.enterPhase(MaceController.Phase.IDLE);
   }

   private void fireWindCharge() {
      SwapEngine.fireWindCharge(this.bot, this.windChargeSlot, 80.0F);
   }

   private int findMaceSlot() {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestS = (double)-1.0F;

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.MACE)) {
            double score = ItemEvaluator.scoreMace(s);
            if (score > bestS) {
               bestS = score;
               best = i;
            }
         }
      }

      return best;
   }

   private int findAxeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.AXES)) {
            return i;
         }
      }

      return -1;
   }

   private int findWindChargeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.WIND_CHARGE)) {
            return i;
         }
      }

      return -1;
   }

   private double rollTargetHeight() {
      return (double)4.0F + RNG.nextDouble();
   }

   private void faceTarget(LivingEntity target) {
      if (this.crouchBoostActive) {
         this.bot.setShiftKeyDown(false);
         this.crouchBoostActive = false;
      }

      TechniqueConfig.HitPreference hitPref = (new EffectiveSettings(this.bot.getScoreboardName())).techniques().wcHitPreference;
      double aimY = target.getY();
      if (hitPref == TechniqueConfig.HitPreference.HORIZONTAL && this.bot.getAttackStrengthScale(0.0F) > 0.9F) {
         aimY = target.getEyeY() - 0.4;
      }

      Vec3 aimPt = this.lead.lead(target, DiveLead.ticksToDrop(Math.max((double)0.0F, this.bot.getY() - target.getEyeY()), Math.min((double)0.0F, this.bot.getDeltaMovement().y)));
      double dx = aimPt.x - this.bot.getEyePosition().x;
      double dy = aimY - this.bot.getEyeY();
      double dz = aimPt.z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void driftToward(LivingEntity target) {
      String name = this.bot.getScoreboardName();
      Vec3 aimPt = this.lead.lead(target, DiveLead.ticksToDrop(Math.max((double)0.0F, this.bot.getY() - target.getEyeY()), Math.min((double)0.0F, this.bot.getDeltaMovement().y)));
      double dist = Math.sqrt(Math.pow(aimPt.x - this.bot.getX(), (double)2.0F) + Math.pow(aimPt.z - this.bot.getZ(), (double)2.0F) + Math.pow(target.getY() - this.bot.getY(), (double)2.0F));
      if (dist > (double)1.5F) {
         BotCommands.moveForward(this.server, name);
         this.bot.setSprinting(dist > (double)3.0F);
      } else {
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
      }

   }

   private static enum Phase {
      IDLE,
      LAUNCHING,
      AIRBORNE,
      SMASHING;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, LAUNCHING, AIRBORNE, SMASHING};
      }
   }
}
