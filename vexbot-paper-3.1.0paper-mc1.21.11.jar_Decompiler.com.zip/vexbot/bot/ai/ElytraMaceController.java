package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.Fireworks;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.compat.McCompat;
import vexbot.settings.TechniqueConfig;
import vexbot.util.BotCommands;
import vexbot.util.ElytraFlight;
import vexbot.util.EnchantmentUtils;
import vexbot.util.EquipmentSync;
import vexbot.util.InventoryUtils;
import vexbot.util.StunSlam;
import vexbot.util.VexLog;

public final class ElytraMaceController {
   private static final double TARGET_HEIGHT = (double)10.0F;
   private static final double UNEQUIP_HEIGHT = (double)3.0F;
   private static final double HEAD_LOCK_HEIGHT = (double)12.0F;
   private static final double MIN_FALL_DIST = (double)1.5F;
   private static final double SMASH_RANGE = (double)8.0F;
   private static final int COOLDOWN_TICKS = 12;
   private static final int RECHAIN_COOLDOWN_TICKS = 10;
   private static final double[] LVL_COOLDOWN_MULT = new double[]{(double)3.5F, (double)2.5F, 1.8, 1.3, (double)1.0F};
   private static final double[] LVL_RECHAIN_CHANCE = new double[]{(double)0.0F, (double)0.0F, (double)0.25F, 0.6, (double)1.0F};
   private static final double[] LVL_AIM_ERROR = new double[]{2.6, 1.8, 1.1, (double)0.5F, (double)0.0F};
   private static final double[] LVL_OVERSHOOT_HEIGHT = new double[]{(double)7.0F, (double)4.5F, (double)2.5F, (double)1.0F, (double)0.0F};
   private static final double[] LVL_LATE_UNEQUIP = new double[]{2.6, 1.8, (double)1.0F, 0.4, (double)0.0F};
   private static final double[] LVL_MISS_ROCKET = new double[]{0.45, 0.3, 0.15, 0.05, (double)0.0F};
   private int climbRocketDelay = 0;
   private static final int LVL_MIN_AIR_STUNSLAM = 4;
   private static final int MAX_PHASE_TICKS = 200;
   private static final double TRIGGER_RANGE = (double)40.0F;
   private static final int EQUIP_SETTLE_TICKS = 3;
   private static final float CLIMB_PITCH = -90.0F;
   private static final float CLIMB_PITCH_SPREAD = 12.0F;
   private double apexJitter = (double)0.0F;
   private float climbJitter = 0.0F;
   private static final int MIN_ROCKETS = 2;
   private static final int MAX_ROCKETS = 1;
   private static final double AIR_TRIGGER_RANGE = (double)50.0F;
   private static final double AIR_APEX_OFFSET = (double)2.0F;
   private static final int MIN_AIR_ROCKETS = 3;
   private static final int AIR_CLIMB_ROCKETS = 8;
   private static final int AIR_ROCKET_INTERVAL = 8;
   private static final int GLIDE_DOWN_MAX_TICKS = 400;
   private static final float GLIDE_DOWN_PITCH = 20.0F;
   private Phase phase;
   private int phaseTick;
   private int cooldown;
   private int rocketsUsed;
   private boolean aerialChase;
   private int lastRocketTick;
   private int maceSlot;
   private int chestSaveSlot;
   private int elytraFromSlot;
   private int prevSelected;
   private boolean hadOriginalChestplate;
   private static final Random RNG = new Random();
   private final StunSlam stunSlam;
   private final DiveLead lead;
   private final DiveCover cover;
   private double diveOffX;
   private double diveOffZ;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private Runnable onSmashLanded;
   private TechniqueConfig.RocketMaceVariant rocketVariant;
   private final ElytraObstacleGuard.CrashDetector crashGuard;

   private double smashHitRange() {
      return (new EffectiveSettings(this.bot.getScoreboardName())).attackRange();
   }

   private int elytraMaceLevel() {
      int lvl = EffectiveSettings.of(this.bot.getScoreboardName()).difficultyParams().elytraMaceLevel;
      return Math.max(1, Math.min(5, lvl));
   }

   public ElytraMaceController(ServerPlayer bot, MinecraftServer server) {
      this.phase = ElytraMaceController.Phase.IDLE;
      this.phaseTick = 0;
      this.cooldown = 0;
      this.rocketsUsed = 0;
      this.aerialChase = false;
      this.lastRocketTick = -100;
      this.maceSlot = -1;
      this.chestSaveSlot = -1;
      this.elytraFromSlot = -1;
      this.prevSelected = 0;
      this.hadOriginalChestplate = false;
      this.stunSlam = new StunSlam();
      this.lead = new DiveLead();
      this.cover = new DiveCover();
      this.rocketVariant = TechniqueConfig.RocketMaceVariant.V1_CLIMB_DROP;
      this.crashGuard = new ElytraObstacleGuard.CrashDetector();
      this.bot = bot;
      this.server = server;
   }

   public void setOnSmashLanded(Runnable cb) {
      this.onSmashLanded = cb;
   }

   public boolean hasFireworksForCombo() {
      if (!(new EffectiveSettings(this.bot.getScoreboardName())).techniques().rocketMace) {
         return false;
      } else {
         return this.countItem(Items.FIREWORK_ROCKET) >= 2;
      }
   }

   private void resolveRocketVariant() {
      Class<TechniqueConfig.RocketMaceVariant> V = TechniqueConfig.RocketMaceVariant.class;
      TechniqueConfig.RocketMaceVariant want = (new EffectiveSettings(this.bot.getScoreboardName())).techniques().rocketMaceVariant;
      this.rocketVariant = want;
      if (want != TechniqueConfig.RocketMaceVariant.V1_CLIMB_DROP && !this.hasDurationIiiRocket()) {
         this.rocketVariant = TechniqueConfig.RocketMaceVariant.V1_CLIMB_DROP;
      }

      if (this.rocketVariant == TechniqueConfig.RocketMaceVariant.V4_WINDBURST_LOOP && !this.hasWindBurstMace()) {
         this.rocketVariant = TechniqueConfig.RocketMaceVariant.V1_CLIMB_DROP;
      }

   }

   private boolean hasDurationIiiRocket() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (st.is(Items.FIREWORK_ROCKET)) {
            Fireworks fw = (Fireworks)st.get(DataComponents.FIREWORKS);
            if (fw != null && fw.flightDuration() >= 3) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean hasWindBurstMace() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         ItemStack st = inv.getItem(i);
         if (st.is(Items.MACE) && EnchantmentUtils.getEnchantLevel(st, "wind_burst") >= 1) {
            return true;
         }
      }

      return false;
   }

   private boolean skipsApexDance() {
      return this.rocketVariant == TechniqueConfig.RocketMaceVariant.V2_BOOST_TURN_HIT || this.rocketVariant == TechniqueConfig.RocketMaceVariant.V4_WINDBURST_LOOP;
   }

   public boolean hasGearForCombo() {
      TechniqueConfig tech = EffectiveSettings.of(this.bot.getScoreboardName()).techniques();
      if (tech.diveBomb && tech.rocketMace) {
         if (this.findMaceInHotbar() < 0) {
            return false;
         } else if (this.countItem(Items.FIREWORK_ROCKET) < 2) {
            return false;
         } else {
            return this.findElytraInInventory() >= 0 ? true : ElytraFlight.isUsable(this.bot.getItemBySlot(EquipmentSlot.CHEST));
         }
      } else {
         return false;
      }
   }

   private boolean canRechainImmediately(LivingEntity target, double dist) {
      if (target != null && target.isAlive()) {
         if (dist > (double)40.0F) {
            return false;
         } else if (this.findMaceInHotbar() < 0) {
            return false;
         } else if (this.countItem(Items.FIREWORK_ROCKET) < 2) {
            return false;
         } else {
            return this.findElytraInInventory() >= 0;
         }
      } else {
         return false;
      }
   }

   public boolean tick(LivingEntity target, double dist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      boolean var10000;
      switch (this.phase.ordinal()) {
         case 0 -> var10000 = this.tickIdle(target, dist);
         case 1 -> var10000 = this.tickEquipping();
         case 2 -> var10000 = this.tickLaunching();
         case 3 -> var10000 = this.tickClimbing(target);
         case 4 -> var10000 = this.tickApexUnequip(target);
         case 5 -> var10000 = this.tickApexReequip(target);
         case 6 -> var10000 = this.tickDiving(target);
         case 7 -> var10000 = this.tickUnequipping(target);
         case 8 -> var10000 = this.tickSmashing(target);
         case 9 -> var10000 = this.tickAerialPursue(target);
         case 10 -> var10000 = this.tickGlideDown();
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void reset() {
      if (this.phase != ElytraMaceController.Phase.IDLE) {
         if (this.phase != ElytraMaceController.Phase.GLIDE_DOWN) {
            this.abort();
         }

         if (this.phase == ElytraMaceController.Phase.GLIDE_DOWN) {
            this.tickGlideDown();
         }

      }
   }

   public boolean isExecuting() {
      return this.phase != ElytraMaceController.Phase.IDLE;
   }

   private boolean tickIdle(LivingEntity target, double dist) {
      if (!EffectiveSettings.of(this.bot.getScoreboardName()).techniques().diveBomb) {
         return false;
      } else {
         this.ensureChestplateOnGround();
         if (!EffectiveSettings.of(this.bot.getScoreboardName()).techniques().rocketMace) {
            return false;
         } else if (target != null && target.isAlive()) {
            if (this.cooldown > 0) {
               return false;
            } else if (!this.bot.onGround()) {
               return false;
            } else {
               boolean targetAir = this.isTargetAirborne(target);
               if (targetAir) {
                  if (dist > (double)50.0F) {
                     return false;
                  }
               } else if (dist > (double)40.0F) {
                  return false;
               }

               this.maceSlot = this.findMaceInHotbar();
               if (this.maceSlot < 0) {
                  return false;
               } else {
                  int needRockets = targetAir ? 3 : 2;
                  if (this.countItem(Items.FIREWORK_ROCKET) < needRockets) {
                     return false;
                  } else {
                     ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
                     if (chest.is(Items.ELYTRA)) {
                        return false;
                     } else {
                        this.elytraFromSlot = this.findElytraInInventory();
                        if (this.elytraFromSlot < 0) {
                           return false;
                        } else {
                           this.hadOriginalChestplate = !chest.isEmpty();
                           if (!targetAir && !this.cover.reachable(target, this.bot.tickCount)) {
                              return false;
                           } else if (!DiveCover.openAbove(this.bot, (double)6.0F)) {
                              return false;
                           } else if (ElytraSkill.skipLaunch(this.bot)) {
                              this.cooldown = ElytraSkill.hesitateTicks(this.bot);
                              return false;
                           } else {
                              this.aerialChase = targetAir;
                              this.prevSelected = InventoryUtils.selected(this.bot.getInventory());
                              this.enterPhase(ElytraMaceController.Phase.EQUIPPING);
                              return true;
                           }
                        }
                     }
                  }
               }
            }
         } else {
            return false;
         }
      }
   }

   private boolean tickEquipping() {
      ++this.phaseTick;
      if (this.phaseTick > 200) {
         this.abort();
         return false;
      } else if (this.elytraFromSlot == -1) {
         this.enterPhase(ElytraMaceController.Phase.LAUNCHING);
         return true;
      } else {
         if (this.phaseTick == 1) {
            ItemStack currentChest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
            ItemStack elytra = this.bot.getInventory().getItem(this.elytraFromSlot).copy();
            this.bot.getInventory().setItem(this.elytraFromSlot, ItemStack.EMPTY);
            this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            if (!currentChest.isEmpty()) {
               this.chestSaveSlot = this.findFreeHotbarSlot();
               if (this.chestSaveSlot < 0) {
                  this.chestSaveSlot = this.elytraFromSlot;
               }

               this.bot.getInventory().setItem(this.chestSaveSlot, currentChest.copy());
            } else {
               this.chestSaveSlot = -1;
            }
         }

         if (this.phaseTick < 3) {
            return true;
         } else {
            ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
            if (!chest.is(Items.ELYTRA)) {
               this.abort();
               return false;
            } else {
               this.enterPhase(ElytraMaceController.Phase.LAUNCHING);
               return true;
            }
         }
      }
   }

   private boolean tickLaunching() {
      ++this.phaseTick;
      if (this.phaseTick > 30) {
         this.abort();
         return false;
      } else {
         String name = this.bot.getScoreboardName();
         BotCommands.stopMoving(this.server, name);
         this.bot.setSprinting(false);
         if (this.bot.onGround()) {
            BotCommands.jumpOnce(this.server, name);
            return true;
         } else if (!this.bot.isFallFlying()) {
            BotCommands.jumpOnce(this.server, name);
            return true;
         } else {
            this.resolveRocketVariant();
            this.enterPhase(ElytraMaceController.Phase.CLIMBING);
            return true;
         }
      }
   }

   private boolean tickClimbing(LivingEntity target) {
      ++this.phaseTick;
      if (this.phaseTick == 1) {
         this.rocketsUsed = 0;
         this.lastRocketTick = -100;
         this.apexJitter = (double)-2.0F + RNG.nextDouble() * (double)5.0F;
         this.climbJitter = (float)(RNG.nextDouble() * (double)12.0F);
         this.climbRocketDelay = RNG.nextDouble() < LVL_MISS_ROCKET[this.elytraMaceLevel() - 1] ? 8 + RNG.nextInt(13) : 0;
      }

      if (target != null && target.isAlive()) {
         if (this.phaseTick > 200) {
            this.abort();
            return false;
         } else if (!this.bot.isFallFlying() && this.phaseTick > 10) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            double overshoot = LVL_OVERSHOOT_HEIGHT[this.elytraMaceLevel() - 1];
            double apexY = (this.aerialChase ? target.getY() + (double)2.0F + overshoot * (double)0.5F : target.getY() + (double)10.0F + overshoot) + this.apexJitter;
            if (this.bot.getY() >= apexY) {
               if (!this.aerialChase && this.skipsApexDance()) {
                  this.aimAt(target, true);
                  this.enterPhase(ElytraMaceController.Phase.DIVING);
                  return true;
               } else {
                  this.enterPhase(this.aerialChase ? ElytraMaceController.Phase.AERIAL_PURSUE : ElytraMaceController.Phase.APEX_UNEQUIP);
                  return true;
               }
            } else if (!this.aerialChase && this.rocketsUsed >= 1 && this.phaseTick >= 8 + this.climbRocketDelay && this.bot.getDeltaMovement().y <= (double)0.0F) {
               if (this.skipsApexDance()) {
                  this.aimAt(target, true);
                  this.enterPhase(ElytraMaceController.Phase.DIVING);
                  return true;
               } else {
                  this.enterPhase(ElytraMaceController.Phase.APEX_UNEQUIP);
                  return true;
               }
            } else {
               double dx = target.getX() - this.bot.getX();
               double dz = target.getZ() - this.bot.getZ();
               float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
               this.bot.setYRot(yaw);
               this.bot.setXRot(-90.0F + this.climbJitter);
               this.bot.yHeadRot = yaw;
               if (this.aerialChase) {
                  if (this.bot.isFallFlying() && this.rocketsUsed < 8 && this.phaseTick - this.lastRocketTick >= 8 && this.countItem(Items.FIREWORK_ROCKET) > 0) {
                     if (RNG.nextDouble() >= LVL_MISS_ROCKET[this.elytraMaceLevel() - 1]) {
                        this.fireRocket();
                        ++this.rocketsUsed;
                     }

                     this.lastRocketTick = this.phaseTick;
                  }

                  if (this.countItem(Items.FIREWORK_ROCKET) == 0 && this.bot.getY() < target.getY() - (double)2.0F) {
                     this.abort();
                     return false;
                  }
               } else if (this.rocketsUsed < 1 && this.phaseTick == 1 + this.climbRocketDelay) {
                  this.fireRocket();
                  ++this.rocketsUsed;
               }

               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickApexUnequip(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 30) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            if (this.phaseTick == 1) {
               if (this.chestSaveSlot < 0) {
                  this.chestSaveSlot = this.findFreeHotbarSlot();
                  if (this.chestSaveSlot < 0) {
                     this.chestSaveSlot = 8;
                  }
               }

               this.swapChestEquipment();
            }

            this.aimAt(target, true);
            if (this.phaseTick > 3 && !this.bot.isFallFlying()) {
               this.enterPhase(ElytraMaceController.Phase.APEX_REEQUIP);
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickApexReequip(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 10) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            if (this.phaseTick == 1) {
               this.swapChestEquipment();
            }

            this.aimAt(target, true);
            if (this.phaseTick >= 2) {
               this.enterPhase(ElytraMaceController.Phase.DIVING);
            }

            return true;
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickDiving(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 200) {
            this.abort();
            return false;
         } else if (this.lostCover(target)) {
            this.abort();
            return false;
         } else {
            if (this.phaseTick == 1) {
               double[] off = ElytraSkill.diveOffset(this.bot);
               this.diveOffX = off[0];
               this.diveOffZ = off[1];
            }

            if (this.crashGuard.crashed(this.bot)) {
               VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' flew into something — breaking off the elytra dive", this.bot.getScoreboardName());
               this.abort();
               return false;
            } else {
               ElytraFlight.beginGlide(this.bot);
               double heightAboveTarget = this.bot.getY() - target.getY();
               BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
               this.bot.setSprinting(false);
               int eta = DiveLead.ticksToDrop(Math.max((double)0.0F, heightAboveTarget - (double)1.0F), this.bot.getDeltaMovement().y);
               Vec3 aimPt = this.lead.lead(target, eta).add(this.diveOffX, (double)0.0F, this.diveOffZ);
               double steer = ElytraSkill.steer(this.bot);
               double hx = aimPt.x - this.bot.getX();
               double hz = aimPt.z - this.bot.getZ();
               double hd = Math.sqrt(hx * hx + hz * hz);
               boolean targetStationary = !this.lead.moving(target);
               if (targetStationary) {
                  Vec3 dm = this.bot.getDeltaMovement();
                  if (hd <= 1.2) {
                     this.aimStraightDown();
                     this.bot.setDeltaMovement(hx * (double)0.25F * steer, dm.y, hz * (double)0.25F * steer);
                  } else {
                     this.aimAt(target, true);
                     double step = Math.min(0.35, hd * 0.4) * steer;
                     this.bot.setDeltaMovement(hx / hd * step, dm.y, hz / hd * step);
                  }
               } else {
                  this.aimAtHead(target, aimPt);
                  if (hd > 0.05) {
                     double step = Math.min((double)0.5F, hd * (double)0.5F) * steer;
                     Vec3 dm = this.bot.getDeltaMovement();
                     this.bot.setDeltaMovement(hx / hd * step, dm.y, hz / hd * step);
                  }
               }

               InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
               double late = LVL_LATE_UNEQUIP[this.elytraMaceLevel() - 1];
               if (heightAboveTarget <= (double)3.0F - late || (double)this.bot.distanceTo(target) <= (double)9.0F - late) {
                  this.enterPhase(ElytraMaceController.Phase.UNEQUIPPING);
               }

               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickAerialPursue(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 200) {
            this.abort();
            return false;
         } else if (this.crashGuard.crashed(this.bot)) {
            VexLog.brief(VexBot.LOGGER, "[VexBot] '{}' flew into something — breaking off the elytra chase", this.bot.getScoreboardName());
            this.abort();
            return false;
         } else {
            if (!this.bot.isFallFlying()) {
               ElytraFlight.beginGlide(this.bot);
            }

            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            double dx = target.getX() - this.bot.getX();
            double dz = target.getZ() - this.bot.getZ();
            double horiz = Math.sqrt(dx * dx + dz * dz);
            double dist3d = (double)this.bot.distanceTo(target);
            if (horiz <= (double)8.0F && dist3d <= (double)9.0F) {
               this.enterPhase(ElytraMaceController.Phase.UNEQUIPPING);
               return true;
            } else if (target.onGround()) {
               this.aerialChase = false;
               this.enterPhase(ElytraMaceController.Phase.DIVING);
               return true;
            } else {
               double tx = target.getX();
               double ty = target.getY() + (double)2.0F;
               double tz = target.getZ();
               this.aimAtHead(target);
               BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
               this.bot.setSprinting(false);
               double vx = tx - this.bot.getX();
               double vy = ty - this.bot.getY();
               double vz = tz - this.bot.getZ();
               double d = Math.sqrt(vx * vx + vy * vy + vz * vz);
               if (d > 0.05) {
                  double step = Math.min((double)1.0F, d * (double)0.5F);
                  this.bot.setDeltaMovement(vx / d * step, vy / d * step, vz / d * step);
               }

               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private boolean tickUnequipping(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         this.aimAtHead(target);
      }

      if (this.phaseTick == 1) {
         ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         if (chest.is(Items.ELYTRA)) {
            int wearFrom = -1;
            if (this.hadOriginalChestplate) {
               wearFrom = this.chestSaveSlot >= 0 && isChestplate(this.bot.getInventory().getItem(this.chestSaveSlot)) ? this.chestSaveSlot : this.findBestChestplateInInventory();
            }

            if (wearFrom >= 0) {
               this.bot.setItemSlot(EquipmentSlot.CHEST, this.bot.getInventory().getItem(wearFrom).copy());
               this.bot.getInventory().setItem(wearFrom, chest.copy());
            } else {
               int elytraStore = this.findElytraStoreSlot();
               if (elytraStore >= 0) {
                  this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                  this.bot.getInventory().setItem(elytraStore, chest.copy());
               }
            }

            this.bot.stopFallFlying();
         }

         InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
      }

      if (this.phaseTick > 10 && this.bot.isFallFlying()) {
         this.abort();
         return false;
      } else {
         if (!this.bot.isFallFlying()) {
            this.enterPhase(ElytraMaceController.Phase.SMASHING);
         }

         return true;
      }
   }

   private boolean tickSmashing(LivingEntity target) {
      ++this.phaseTick;
      if (target != null && target.isAlive()) {
         if (this.phaseTick > 60) {
            this.abort();
            return false;
         } else {
            InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
            this.aimAtHead(target);
            double dist = (double)this.bot.distanceTo(target);
            boolean inRange = dist <= this.smashHitRange();
            boolean hasFall = this.bot.fallDistance > (double)1.5F && MaceSmashGates.botMayUseSmashFallBonus(this.bot);
            boolean landed = this.bot.onGround() && this.phaseTick > 3;
            BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
            this.bot.setSprinting(false);
            if (!inRange && !this.bot.onGround()) {
               Vec3 aimPt = this.lead.lead(target, DiveLead.ticksToDrop(this.bot.getY() - target.getEyeY(), this.bot.getDeltaMovement().y)).add(this.diveOffX, (double)0.0F, this.diveOffZ);
               double hx = aimPt.x - this.bot.getX();
               double hz = aimPt.z - this.bot.getZ();
               double hd = Math.sqrt(hx * hx + hz * hz);
               if (ElytraSkill.level(this.bot) < 5 && this.bot.getY() - target.getY() > (double)4.0F) {
                  int fallTicks = DiveLead.ticksToDrop(this.bot.getY() - target.getEyeY(), this.bot.getDeltaMovement().y);
                  double canClose = (double)fallTicks * 0.42 * ElytraSkill.steer(this.bot) + this.smashHitRange();
                  if (hd > canClose) {
                     this.abort();
                     return false;
                  }
               }

               if (hd > 0.05) {
                  double step = Math.min(0.42, hd * (double)0.5F) * ElytraSkill.steer(this.bot);
                  Vec3 dm = this.bot.getDeltaMovement();
                  this.bot.setDeltaMovement(hx / hd * step, dm.y, hz / hd * step);
               }
            }

            if (inRange && hasFall) {
               if (!this.bot.hasLineOfSight(target)) {
                  if (landed) {
                     this.abort();
                     return false;
                  } else {
                     return true;
                  }
               } else {
                  this.bot.setSprinting(true);
                  EffectiveSettings ssEffs = EffectiveSettings.of(this.bot.getScoreboardName());
                  TechniqueConfig ssCfg = ssEffs.techniques();
                  boolean mayAirSlam = ssCfg.elytraStunSlam && this.elytraMaceLevel() >= 4;
                  StunSlam.Result ssRes = this.stunSlam.tick(this.bot, target, this.findAxeSlot(), this.maceSlot, ssCfg.stunSlamVariant, mayAirSlam, ssEffs);
                  if (ssRes == StunSlam.Result.HOLD) {
                     return true;
                  } else {
                     if (ssRes != StunSlam.Result.SMASHED) {
                        InventoryUtils.select(this.bot.getInventory(), this.maceSlot);
                        EquipmentSync.syncNow(this.bot);
                        if (!ElytraSkill.whiff(this.bot)) {
                           this.bot.attack(target);
                        }

                        McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                     }

                     if (this.onSmashLanded != null) {
                        this.onSmashLanded.run();
                     }

                     InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
                     int lvl = this.elytraMaceLevel();
                     double m = LVL_COOLDOWN_MULT[lvl - 1];
                     boolean rechain = this.canRechainImmediately(target, dist) && RNG.nextDouble() < LVL_RECHAIN_CHANCE[lvl - 1];
                     this.cooldown = (int)Math.round((double)(rechain ? 10 : 12) * m);
                     this.aerialChase = false;
                     if (this.bot.onGround()) {
                        this.ensureChestplateOnGround();
                     }

                     this.enterPhase(ElytraMaceController.Phase.IDLE);
                     return false;
                  }
               }
            } else if (landed) {
               this.abort();
               return false;
            } else {
               return true;
            }
         }
      } else {
         this.abort();
         return false;
      }
   }

   private void enterPhase(Phase p) {
      this.phase = p;
      this.phaseTick = 0;
   }

   private void abort() {
      this.crashGuard.reset();
      if (!this.bot.onGround()) {
         this.enterPhase(ElytraMaceController.Phase.GLIDE_DOWN);
      } else {
         this.restoreChest();
         InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
         this.cooldown = (int)Math.round((double)6.0F * LVL_COOLDOWN_MULT[this.elytraMaceLevel() - 1]);
         this.aerialChase = false;
         this.enterPhase(ElytraMaceController.Phase.IDLE);
      }
   }

   private boolean maybeTickElytraOff(double heightAboveGround) {
      if (!(new EffectiveSettings(this.bot.getScoreboardName())).techniques().elytraPreserve) {
         return false;
      } else if (heightAboveGround < (double)8.0F) {
         return false;
      } else if (this.bot.getDeltaMovement().y < (double)-0.5F) {
         return false;
      } else {
         int cycle = this.phaseTick % 19;
         if (cycle >= 15) {
            if (this.bot.isFallFlying()) {
               this.bot.stopFallFlying();
            }

            return true;
         } else {
            if (cycle == 0 && !this.bot.isFallFlying()) {
               this.engageFallFlying();
            }

            return false;
         }
      }
   }

   private boolean tickGlideDown() {
      boolean glideHeldOff = this.maybeTickElytraOff(this.bot.getY() - (double)this.bot.level().getHeightmapPos(Types.MOTION_BLOCKING, this.bot.blockPosition()).getY());
      ++this.phaseTick;
      if (this.phaseTick > 400) {
         this.forceGroundReset();
         return false;
      } else if (!this.bot.onGround() && !this.bot.isInWater() && !this.bot.isInLava()) {
         ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         if (!chest.is(Items.ELYTRA)) {
            int elytraSlot = this.findElytraInInventory();
            if (elytraSlot >= 0) {
               ItemStack worn = chest.copy();
               ItemStack elytra = this.bot.getInventory().getItem(elytraSlot).copy();
               this.bot.getInventory().setItem(elytraSlot, worn);
               this.bot.setItemSlot(EquipmentSlot.CHEST, elytra);
            }
         }

         if (!glideHeldOff) {
            this.engageFallFlying();
         }

         float yaw = this.bot.getYRot();
         this.bot.setXRot(20.0F);
         this.bot.yHeadRot = yaw;
         BotCommands.stopMoving(this.server, this.bot.getScoreboardName());
         this.bot.setSprinting(false);
         return true;
      } else {
         this.forceGroundReset();
         return false;
      }
   }

   private void forceGroundReset() {
      if (this.bot.isFallFlying()) {
         this.bot.stopFallFlying();
      }

      this.aerialChase = false;
      if (this.bot.onGround()) {
         this.ensureChestplateOnGround();
      } else {
         this.restoreChest();
      }

      InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
      this.cooldown = (int)Math.round((double)6.0F * LVL_COOLDOWN_MULT[this.elytraMaceLevel() - 1]);
      this.enterPhase(ElytraMaceController.Phase.IDLE);
   }

   private void engageFallFlying() {
      if (!this.bot.isFallFlying()) {
         ElytraFlight.beginGlide(this.bot);
      }

   }

   private void restoreChest() {
      ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
      if (chest.is(Items.ELYTRA)) {
         ItemStack elytra = chest.copy();
         if (this.hadOriginalChestplate && this.chestSaveSlot >= 0 && isChestplate(this.bot.getInventory().getItem(this.chestSaveSlot))) {
            ItemStack toWear = this.bot.getInventory().getItem(this.chestSaveSlot).copy();
            this.bot.setItemSlot(EquipmentSlot.CHEST, toWear);
            this.bot.getInventory().setItem(this.chestSaveSlot, elytra);
         } else {
            int plateSlot = this.findBestChestplateInInventory();
            if (plateSlot >= 0) {
               this.bot.setItemSlot(EquipmentSlot.CHEST, this.bot.getInventory().getItem(plateSlot).copy());
               this.bot.getInventory().setItem(plateSlot, elytra);
            } else {
               int elytraStore = this.findElytraStoreSlot();
               if (elytraStore < 0) {
                  return;
               }

               this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
               this.bot.getInventory().setItem(elytraStore, elytra);
            }

         }
      }
   }

   private void ensureChestplateOnGround() {
      if (this.bot.onGround()) {
         ItemStack chest = this.bot.getItemBySlot(EquipmentSlot.CHEST);
         if (chest.is(Items.ELYTRA)) {
            if (this.bot.isFallFlying()) {
               this.bot.stopFallFlying();
            }

            int plateSlot = this.findBestChestplateInInventory();
            ItemStack elytra = chest.copy();
            if (plateSlot >= 0) {
               this.bot.setItemSlot(EquipmentSlot.CHEST, this.bot.getInventory().getItem(plateSlot).copy());
               this.bot.getInventory().setItem(plateSlot, elytra);
            } else {
               int store = this.findElytraStoreSlot();
               if (store >= 0) {
                  this.bot.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
                  this.bot.getInventory().setItem(store, elytra);
               }
            }
         }
      }
   }

   private void swapChestEquipment() {
      if (this.chestSaveSlot >= 0) {
         ItemStack chestSlotItem = this.bot.getItemBySlot(EquipmentSlot.CHEST).copy();
         ItemStack savedItem = this.bot.getInventory().getItem(this.chestSaveSlot).copy();
         this.bot.setItemSlot(EquipmentSlot.CHEST, savedItem);
         this.bot.getInventory().setItem(this.chestSaveSlot, chestSlotItem);
      }
   }

   private void fireRocket() {
      Inventory inv = this.bot.getInventory();
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
            slot = i;
            break;
         }
      }

      if (slot < 0) {
         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
               slot = i;
               break;
            }
         }

         if (slot < 0) {
            return;
         }

         slot = InventoryUtils.moveToHotbarSafe(inv, slot);
      }

      int prev = InventoryUtils.selected(inv);
      InventoryUtils.select(inv, slot);
      this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(slot), InteractionHand.MAIN_HAND);
      InventoryUtils.select(inv, prev);
   }

   private void aimAt(LivingEntity target, boolean steep) {
      double dx = target.getX() - this.bot.getEyePosition().x;
      double dy = target.getEyeY() - this.bot.getEyePosition().y;
      double dz = target.getZ() - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      if (steep) {
         pitch = Math.max(pitch, 60.0F);
      }

      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void aimAtHead(LivingEntity target) {
      this.aimAtHead(target, target.position());
   }

   private void aimAtHead(LivingEntity target, Vec3 feet) {
      double err = LVL_AIM_ERROR[this.elytraMaceLevel() - 1];
      double ex = (double)0.0F;
      double ez = (double)0.0F;
      if (err > (double)0.0F) {
         long slot = this.bot.level().getGameTime() / 10L;
         Random r = new Random((long)this.bot.getId() * 31L + slot);
         ex = (r.nextDouble() - (double)0.5F) * (double)2.0F * err;
         ez = (r.nextDouble() - (double)0.5F) * (double)2.0F * err;
      }

      double dx = feet.x + ex - this.bot.getEyePosition().x;
      double dy = feet.y + (double)target.getEyeHeight() - this.bot.getEyePosition().y;
      double dz = feet.z + ez - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horiz)));
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private void aimStraightDown() {
      this.bot.setXRot(90.0F);
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private int findAxeSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(ItemTags.AXES)) {
            return i;
         }
      }

      return -1;
   }

   private int findMaceInHotbar() {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestScore = (double)-1.0F;

      for(int i = 0; i < 9; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(Items.MACE)) {
            double score = ItemEvaluator.scoreMace(s);
            if (score > bestScore) {
               bestScore = score;
               best = i;
            }
         }
      }

      return best;
   }

   private int findBestChestplateInInventory() {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      double bestScore = (double)-1.0F;

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (isChestplate(s)) {
            double score = ArmorEvaluator.score(s);
            if (score > bestScore) {
               bestScore = score;
               best = i;
            }
         }
      }

      return best;
   }

   private static boolean isChestplate(ItemStack s) {
      return !s.is(Items.ELYTRA) && ArmorEvaluator.getSlot(s) == EquipmentSlot.CHEST;
   }

   private int findElytraInInventory() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (ElytraFlight.isUsable(inv.getItem(i))) {
            return i;
         }
      }

      return -1;
   }

   private int findFreeHotbarSlot() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).isEmpty()) {
            return i;
         }
      }

      return -1;
   }

   private int findElytraStoreSlot() {
      int slot = this.findFreeHotbarSlot();
      if (slot >= 0) {
         return slot;
      } else {
         Inventory inv = this.bot.getInventory();

         for(int i = 9; i < 36; ++i) {
            if (inv.getItem(i).isEmpty()) {
               return i;
            }
         }

         return -1;
      }
   }

   private boolean lostCover(LivingEntity target) {
      return !this.aerialChase && target.onGround() && !this.cover.reachable(target, this.bot.tickCount);
   }

   private boolean isTargetAirborne(LivingEntity target) {
      if (target != null && !target.onGround()) {
         if (target.isFallFlying()) {
            return true;
         } else if (target.isAutoSpinAttack()) {
            return true;
         } else {
            return target.getY() - this.bot.getY() > (double)4.0F;
         }
      } else {
         return false;
      }
   }

   private int countItem(Item item) {
      int total = 0;
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         ItemStack s = inv.getItem(i);
         if (s.is(item)) {
            total += s.getCount();
         }
      }

      return total;
   }

   private static enum Phase {
      IDLE,
      EQUIPPING,
      LAUNCHING,
      CLIMBING,
      APEX_UNEQUIP,
      APEX_REEQUIP,
      DIVING,
      UNEQUIPPING,
      SMASHING,
      AERIAL_PURSUE,
      GLIDE_DOWN;

      // $FF: synthetic method
      private static Phase[] $values() {
         return new Phase[]{IDLE, EQUIPPING, LAUNCHING, CLIMBING, APEX_UNEQUIP, APEX_REEQUIP, DIVING, UNEQUIPPING, SMASHING, AERIAL_PURSUE, GLIDE_DOWN};
      }
   }
}
