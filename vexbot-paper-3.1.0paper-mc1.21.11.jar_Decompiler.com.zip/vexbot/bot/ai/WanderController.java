package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.util.BotCommands;
import vexbot.util.BotMath;
import vexbot.util.LedgeGuard;

public final class WanderController {
   private static final int WANDER_RADIUS = 10;
   private static final double ARRIVE_DIST = (double)1.5F;
   private static final int SAFE_DROP = 4;
   private static final double RECENTRE_DIST = (double)36.0F;
   private static final Random RNG = new Random();
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private Vec3 spawnPos;
   private Level spawnLevel;
   private Vec3 wanderTarget = null;
   private int pauseTicksLeft = 0;
   private float idleYawTarget = 0.0F;
   private float lookPitch = 0.0F;
   private float lookPitchTarget = 0.0F;
   private int driftReroll = 0;
   private int jumpCd = 0;

   public WanderController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
      this.spawnPos = bot.position();
      this.spawnLevel = bot.level();
   }

   public boolean tick() {
      if (!EffectiveSettings.of(this.botName).wanderWhenIdle()) {
         this.wanderTarget = null;
         this.pauseTicksLeft = 0;
         return false;
      } else {
         if (this.jumpCd > 0) {
            --this.jumpCd;
         }

         if (this.bot.level() != this.spawnLevel || this.bot.position().distanceToSqr(this.spawnPos) > (double)1296.0F) {
            this.spawnPos = this.bot.position();
            this.spawnLevel = this.bot.level();
            this.wanderTarget = null;
         }

         if (this.pauseTicksLeft > 0) {
            --this.pauseTicksLeft;
            BotCommands.stopMoving(this.server, this.botName);
            this.bot.setSprinting(false);
            this.idleLookDrift();
            return true;
         } else if (this.wanderTarget != null) {
            double dx = this.wanderTarget.x - this.bot.getX();
            double dz = this.wanderTarget.z - this.bot.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist < (double)1.5F) {
               BotCommands.stopMoving(this.server, this.botName);
               this.bot.setSprinting(false);
               this.wanderTarget = null;
               this.pauseTicksLeft = 40 + RNG.nextInt(61);
               return true;
            } else if (LedgeGuard.wouldFallDangerously(this.bot, dx, dz, 4)) {
               BotCommands.stopMoving(this.server, this.botName);
               this.bot.setSprinting(false);
               this.wanderTarget = null;
               this.pauseTicksLeft = 20 + RNG.nextInt(20);
               return true;
            } else {
               double nlen = dist > 1.0E-6 ? dist : (double)1.0F;
               double fx = dx / nlen;
               double fz = dz / nlen;
               BlockPos feetAhead = BlockPos.containing(this.bot.getX() + fx * 0.6, this.bot.getY(), this.bot.getZ() + fz * 0.6);
               boolean blockFeet = this.solidAt(feetAhead);
               boolean blockHead = this.solidAt(feetAhead.above());
               ServerLevel lvl = this.bot.level();
               boolean lavaAhead = lvl.getFluidState(feetAhead).is(FluidTags.LAVA) || lvl.getFluidState(feetAhead.below()).is(FluidTags.LAVA);
               if ((!blockFeet || !blockHead) && !lavaAhead) {
                  if (blockFeet && !this.solidAt(feetAhead.above(2)) && this.bot.onGround() && this.jumpCd <= 0) {
                     BotCommands.jumpOnce(this.server, this.botName);
                     this.jumpCd = 10;
                  }

                  float bearing = (float)Math.toDegrees(Math.atan2(-dx, dz));
                  float yaw = BotMath.smoothYawToward(this.bot.getYRot(), bearing, 9.0F);
                  this.advancePitchDrift((double)6.0F);
                  this.bot.setYRot(yaw);
                  this.bot.yHeadRot = yaw;
                  this.bot.setXRot(this.lookPitch);
                  float fwd = (float)Math.max(0.4, Math.min((double)1.0F, dist / (double)3.0F));
                  BotCommands.setMovement(this.server, this.botName, fwd, 0.0F);
                  this.bot.setSprinting(false);
                  return true;
               } else {
                  BotCommands.stopMoving(this.server, this.botName);
                  this.bot.setSprinting(false);
                  this.wanderTarget = null;
                  this.pauseTicksLeft = 10 + RNG.nextInt(20);
                  return true;
               }
            }
         } else {
            this.wanderTarget = this.pickWanderTarget();
            if (this.wanderTarget == null) {
               this.pauseTicksLeft = 20;
            }

            return true;
         }
      }
   }

   public void reset() {
      this.wanderTarget = null;
      this.pauseTicksLeft = 0;
      this.driftReroll = 0;
      this.jumpCd = 0;
      this.lookPitch = 0.0F;
      this.lookPitchTarget = 0.0F;
   }

   private void idleLookDrift() {
      if (this.driftReroll <= 0) {
         this.driftReroll = 30 + RNG.nextInt(40);
         this.idleYawTarget = this.bot.getYRot() + (float)((RNG.nextDouble() * (double)2.0F - (double)1.0F) * (double)35.0F);
         this.lookPitchTarget = (float)((RNG.nextDouble() * (double)2.0F - (double)1.0F) * (double)8.0F);
      }

      --this.driftReroll;
      float yaw = BotMath.smoothYawToward(this.bot.getYRot(), this.idleYawTarget, 3.0F);
      this.lookPitch += (this.lookPitchTarget - this.lookPitch) * 0.05F;
      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      this.bot.setXRot(this.lookPitch);
   }

   private void advancePitchDrift(double band) {
      if (this.driftReroll <= 0) {
         this.driftReroll = 30 + RNG.nextInt(40);
         this.lookPitchTarget = (float)((RNG.nextDouble() * (double)2.0F - (double)1.0F) * band);
      }

      --this.driftReroll;
      this.lookPitch += (this.lookPitchTarget - this.lookPitch) * 0.05F;
   }

   private boolean solidAt(BlockPos pos) {
      ServerLevel level = this.bot.level();
      return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
   }

   private Vec3 pickWanderTarget() {
      ServerLevel level = this.bot.level();

      for(int attempt = 0; attempt < 20; ++attempt) {
         double dx = (RNG.nextDouble() * (double)2.0F - (double)1.0F) * (double)10.0F;
         double dz = (RNG.nextDouble() * (double)2.0F - (double)1.0F) * (double)10.0F;
         int bx = (int)Math.floor(this.spawnPos.x + dx);
         int bz = (int)Math.floor(this.spawnPos.z + dz);
         int startY = (int)this.spawnPos.y;

         for(int y = startY + 4; y >= startY - 8; --y) {
            BlockPos feet = new BlockPos(bx, y, bz);
            BlockPos head = feet.above();
            if (!level.getBlockState(feet).isAir() && level.getBlockState(head).isAir() && level.getBlockState(head.above()).isAir() && !level.getFluidState(feet).is(FluidTags.LAVA) && !level.getFluidState(head).is(FluidTags.LAVA)) {
               double ox = (RNG.nextDouble() - (double)0.5F) * 0.7;
               double oz = (RNG.nextDouble() - (double)0.5F) * 0.7;
               return new Vec3((double)bx + (double)0.5F + ox, (double)y + (double)1.0F, (double)bz + (double)0.5F + oz);
            }
         }
      }

      return null;
   }
}
