package vexbot.bot.ai;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.DifficultyParams;
import vexbot.EffectiveSettings;

public final class OffhandManager {
   private static final int OFFHAND_SLOT = 40;
   private final ServerPlayer bot;
   private static final Map<UUID, long[]> PARKS = new ConcurrentHashMap();
   private boolean hadTotemLastTick = false;
   private int totemRegrabDelay = 0;
   private long lastTotemTick = Long.MIN_VALUE;

   public OffhandManager(ServerPlayer bot) {
      this.bot = bot;
   }

   public static boolean park(ServerPlayer bot, int sourceSlot, int ticks) {
      if (bot.getHealth() <= 10.0F) {
         return false;
      } else if (sourceSlot >= 0 && sourceSlot <= 35) {
         if (PARKS.containsKey(bot.getUUID())) {
            return false;
         } else {
            Inventory inv = bot.getInventory();
            if (inv.getItem(sourceSlot).isEmpty()) {
               return false;
            } else {
               swap(inv, sourceSlot, 40);
               PARKS.put(bot.getUUID(), new long[]{(long)sourceSlot, bot.level().getGameTime() + (long)ticks});
               return true;
            }
         }
      } else {
         return false;
      }
   }

   public static void unpark(ServerPlayer bot) {
      long[] park = (long[])PARKS.remove(bot.getUUID());
      if (park != null) {
         swap(bot.getInventory(), (int)park[0], 40);
      }
   }

   public static boolean isParked(ServerPlayer bot) {
      return PARKS.containsKey(bot.getUUID());
   }

   private boolean parkActive() {
      long[] park = (long[])PARKS.get(this.bot.getUUID());
      if (park == null) {
         return false;
      } else if (this.bot.level().getGameTime() > park[1]) {
         unpark(this.bot);
         return false;
      } else {
         return true;
      }
   }

   public boolean tickTotem() {
      if (this.parkActive()) {
         return true;
      } else {
         long now = this.bot.level().getGameTime();
         if (now == this.lastTotemTick) {
            return this.hasTotemInOffhand();
         } else {
            this.lastTotemTick = now;
            Inventory inv = this.bot.getInventory();
            ItemStack offhand = inv.getItem(40);
            boolean hasTotem = offhand.is(Items.TOTEM_OF_UNDYING);
            if (this.hadTotemLastTick && !hasTotem) {
               this.totemRegrabDelay = this.reactionTicks();
            }

            this.hadTotemLastTick = hasTotem;
            if (hasTotem) {
               return true;
            } else if (this.totemRegrabDelay > 0) {
               --this.totemRegrabDelay;
               return false;
            } else {
               int totemIdx = this.findInMainInventory(Items.TOTEM_OF_UNDYING);
               if (totemIdx != -1) {
                  swap(inv, totemIdx, 40);
                  this.hadTotemLastTick = true;
                  return true;
               } else {
                  return false;
               }
            }
         }
      }
   }

   private int reactionTicks() {
      DifficultyParams p = EffectiveSettings.of(this.bot.getScoreboardName()).difficultyParams();
      int lo = Math.max(0, p.reactionMinTicks);
      int hi = Math.max(lo, p.reactionMaxTicks);
      return lo == hi ? lo : lo + this.bot.getRandom().nextInt(hi - lo + 1);
   }

   public void tick() {
      if (!this.parkActive()) {
         this.tick(false);
      }
   }

   public void tick(boolean preferShield) {
      if (!this.parkActive()) {
         Inventory inv = this.bot.getInventory();
         ItemStack offhand = inv.getItem(40);
         if (!preferShield || !this.ensureShieldOffhand()) {
            if (!this.tickTotem()) {
               if (!preferShield) {
                  offhand = inv.getItem(40);
                  int bestShieldIdx = this.findBestShieldInMainInventory();
                  if (bestShieldIdx != -1 && (!offhand.is(Items.SHIELD) || ItemEvaluator.scoreShield(inv.getItem(bestShieldIdx)) > ItemEvaluator.scoreShield(offhand))) {
                     swap(inv, bestShieldIdx, 40);
                  }

               }
            }
         }
      }
   }

   public boolean ensureShieldOffhand() {
      Inventory inv = this.bot.getInventory();
      ItemStack offhand = inv.getItem(40);
      int bestShieldIdx = this.findBestShieldInMainInventory();
      if (offhand.is(Items.SHIELD)) {
         if (bestShieldIdx != -1 && ItemEvaluator.scoreShield(inv.getItem(bestShieldIdx)) > ItemEvaluator.scoreShield(offhand)) {
            swap(inv, bestShieldIdx, 40);
         }

         this.hadTotemLastTick = false;
         return true;
      } else if (bestShieldIdx != -1) {
         swap(inv, bestShieldIdx, 40);
         this.hadTotemLastTick = false;
         return true;
      } else {
         return false;
      }
   }

   public boolean hasShieldAvailable() {
      if (this.bot.getInventory().getItem(40).is(Items.SHIELD)) {
         return true;
      } else {
         return this.findBestShieldInMainInventory() != -1;
      }
   }

   public boolean hasShieldInOffhand() {
      return this.bot.getInventory().getItem(40).is(Items.SHIELD);
   }

   public boolean hasTotemInOffhand() {
      return this.bot.getInventory().getItem(40).is(Items.TOTEM_OF_UNDYING);
   }

   private int findInMainInventory(Item item) {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private int findBestShieldInMainInventory() {
      Inventory inv = this.bot.getInventory();
      int bestIdx = -1;
      double bestScore = (double)-1.0F;

      for(int i = 0; i < 36; ++i) {
         ItemStack stack = inv.getItem(i);
         if (ItemEvaluator.isShield(stack)) {
            double s = ItemEvaluator.scoreShield(stack);
            if (s > bestScore) {
               bestScore = s;
               bestIdx = i;
            }
         }
      }

      return bestIdx;
   }

   private static void swap(Inventory inv, int slotA, int slotB) {
      ItemStack a = inv.getItem(slotA).copy();
      ItemStack b = inv.getItem(slotB).copy();
      inv.setItem(slotA, b);
      inv.setItem(slotB, a);
   }
}
