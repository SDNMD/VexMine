package vexbot.bot.ai;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.equipment.Equippable;

public final class ArmorEvaluator {
   private ArmorEvaluator() {
   }

   public static double score(ItemStack stack) {
      if (stack.isEmpty()) {
         return (double)0.0F;
      } else {
         EquipmentSlot slot = getSlot(stack);
         if (slot == null) {
            return (double)0.0F;
         } else {
            ItemAttributeModifiers mods = (ItemAttributeModifiers)stack.get(DataComponents.ATTRIBUTE_MODIFIERS);
            double defense = (double)0.0F;
            double toughness = (double)0.0F;
            if (mods != null) {
               defense = mods.compute(Attributes.ARMOR, (double)0.0F, slot);
               toughness = mods.compute(Attributes.ARMOR_TOUGHNESS, (double)0.0F, slot);
            }

            double score = defense + toughness * (double)2.0F;
            ItemEnchantments enchantments = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
            if (enchantments != null && !enchantments.isEmpty()) {
               for(Holder<Enchantment> holder : enchantments.keySet()) {
                  score += enchantmentValue(holder, enchantments.getLevel(holder));
               }
            }

            return score;
         }
      }
   }

   public static EquipmentSlot getSlot(ItemStack stack) {
      if (stack.isEmpty()) {
         return null;
      } else {
         Equippable eq = (Equippable)stack.get(DataComponents.EQUIPPABLE);
         if (eq == null) {
            return null;
         } else {
            EquipmentSlot slot = eq.slot();
            if (!isArmorSlot(slot)) {
               return null;
            } else {
               ItemAttributeModifiers mods = (ItemAttributeModifiers)stack.get(DataComponents.ATTRIBUTE_MODIFIERS);
               if (mods == null) {
                  return null;
               } else {
                  double protection = mods.compute(Attributes.ARMOR, (double)0.0F, slot) + mods.compute(Attributes.ARMOR_TOUGHNESS, (double)0.0F, slot);
                  return protection > (double)0.0F ? slot : null;
               }
            }
         }
      }
   }

   public static boolean isArmor(ItemStack stack) {
      return getSlot(stack) != null;
   }

   private static boolean isArmorSlot(EquipmentSlot slot) {
      return slot == EquipmentSlot.HEAD || slot == EquipmentSlot.CHEST || slot == EquipmentSlot.LEGS || slot == EquipmentSlot.FEET;
   }

   private static double enchantmentValue(Holder<Enchantment> holder, int level) {
      double var10000;
      switch ((String)holder.unwrapKey().map(ResourceKey::identifier).map((loc) -> loc.getPath()).orElse("")) {
         case "protection" -> var10000 = (double)3.0F * (double)level;
         case "fire_protection" -> var10000 = (double)1.5F * (double)level;
         case "blast_protection" -> var10000 = (double)1.5F * (double)level;
         case "projectile_protection" -> var10000 = (double)1.5F * (double)level;
         case "mending" -> var10000 = (double)5.0F;
         case "thorns" -> var10000 = (double)2.0F * (double)level;
         case "unbreaking" -> var10000 = (double)0.5F * (double)level;
         case "feather_falling" -> var10000 = (double)1.0F * (double)level;
         case "depth_strider" -> var10000 = (double)1.0F * (double)level;
         case "soul_speed" -> var10000 = (double)0.5F * (double)level;
         default -> var10000 = 0.3 * (double)level;
      }

      return var10000;
   }
}
