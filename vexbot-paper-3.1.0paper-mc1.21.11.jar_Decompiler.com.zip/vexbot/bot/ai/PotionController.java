package vexbot.bot.ai;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.InventoryUtils;

public final class PotionController {
   private static final List<Holder<MobEffect>> BUFF_EFFECTS;
   private static final float INSTANT_HEAL_HP = 6.0F;
   private static final float TURTLE_MASTER_HP = 4.0F;
   private static final int QUEUE_GAP_TICKS = 5;
   private static final int REBUFF_RESCAN_TICKS = 60;
   private static final int DRINK_TICKS = 32;
   private static final int HONEY_DRINK_TICKS = 40;
   private static final int SPLASH_WINDUP_TICKS = 3;
   private static final float THROW_PITCH_SELF = 90.0F;
   private static final double MAX_SPLASH_FALL = (double)1.5F;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final Deque<Holder<MobEffect>> potionQueue = new ArrayDeque();
   private int queueGapTicks = 0;
   private boolean isDrinking = false;
   private int drinkTicksLeft = 0;
   private int splashWindup = 0;
   private int splashSlot = -1;
   private Holder<MobEffect> splashEffect = null;
   private boolean splashChaining = false;
   private boolean hadTarget = false;
   private int rescanTicks = 0;
   private boolean prevStrength = false;
   private boolean prevSpeed = false;
   private boolean prevFireRes = false;
   private boolean prevRegen = false;
   private boolean prevInvis = false;

   public PotionController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
   }

   public boolean tick(LivingEntity target, double dist, boolean allowDrinking) {
      if (!EffectiveSettings.of(this.bot.getScoreboardName()).usePotions()) {
         this.hadTarget = false;
         if (this.isSplashing()) {
            this.endSplashSession();
         }

         return false;
      } else {
         if (this.splashWindup > 0 && this.splashChaining) {
            float hpNow = this.bot.getHealth();
            if (hpNow < 4.0F && !this.hasEffect(MobEffects.RESISTANCE) && this.canUsePotionNow(MobEffects.RESISTANCE, allowDrinking) || hpNow <= 6.0F && this.canUsePotionNow(MobEffects.INSTANT_HEALTH, allowDrinking)) {
               Holder<MobEffect> pending = this.splashEffect;
               this.endSplashSession();
               if (pending != null && !this.potionQueue.contains(pending)) {
                  this.potionQueue.addFirst(pending);
               }
            }
         }

         if (this.splashWindup > 0) {
            Inventory inv = this.bot.getInventory();
            this.splashSlot = this.reacquireSplashSlot(inv);
            if (this.splashSlot < 0) {
               this.endSplashSession();
               return false;
            } else {
               InventoryUtils.select(inv, this.splashSlot);
               this.bot.setShiftKeyDown(true);
               this.bot.setXRot(90.0F);
               --this.splashWindup;
               if (this.splashWindup == 0) {
                  this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(this.splashSlot), InteractionHand.MAIN_HAND);
                  McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
                  this.splashSlot = -1;
                  this.splashEffect = null;
                  if (!this.splashChaining || !this.beginNextSplashFromQueue()) {
                     this.endSplashSession();
                     this.queueGapTicks = 5;
                  }
               }

               return true;
            }
         } else {
            if (this.isDrinking) {
               --this.drinkTicksLeft;
               if (this.drinkTicksLeft > 0 && this.bot.isUsingItem()) {
                  return true;
               }

               this.isDrinking = false;
               this.queueGapTicks = 5;
            }

            if (allowDrinking && this.bot.hasEffect(MobEffects.POISON)) {
               int honeySlot = this.findItem(Items.HONEY_BOTTLE, this.bot.getInventory());
               if (honeySlot >= 0) {
                  this.drinkItem(honeySlot, this.bot.getInventory(), 40);
                  return true;
               }
            }

            float hp = this.bot.getHealth();
            if (hp < 4.0F && !this.hasEffect(MobEffects.RESISTANCE) && this.tryUsePotionNow(MobEffects.RESISTANCE, allowDrinking)) {
               this.queueGapTicks = 5;
               return this.isDrinking || this.splashWindup > 0;
            } else if (hp <= 6.0F && this.tryUsePotionNow(MobEffects.INSTANT_HEALTH, allowDrinking)) {
               this.queueGapTicks = 5;
               return this.isDrinking || this.splashWindup > 0;
            } else {
               boolean hasTarget = target != null;
               if (!hasTarget) {
                  this.checkEffectExpiry();
                  this.potionQueue.clear();
                  this.hadTarget = false;
                  return false;
               } else {
                  if (hasTarget && !this.hadTarget) {
                     this.enqueueAvailableBuffs();
                     this.rescanTicks = 60;
                  }

                  this.hadTarget = hasTarget;
                  if (hasTarget && --this.rescanTicks <= 0) {
                     this.enqueueAvailableBuffs();
                     this.rescanTicks = 60;
                  }

                  this.checkEffectExpiry();
                  if (this.queueGapTicks > 0) {
                     --this.queueGapTicks;
                     return false;
                  } else {
                     this.potionQueue.removeIf((e) -> !this.needsBuff(e));
                     if (this.canSplashAtFeet() && this.beginNextSplashFromQueue()) {
                        this.bot.setShiftKeyDown(true);
                        this.bot.setXRot(90.0F);
                        this.splashWindup = 3;
                        this.splashChaining = true;
                        return true;
                     } else {
                        if (allowDrinking) {
                           Iterator<Holder<MobEffect>> it = this.potionQueue.iterator();

                           while(it.hasNext()) {
                              Holder<MobEffect> effect = (Holder)it.next();
                              int slot = this.findPotion(Items.POTION, effect, this.bot.getInventory());
                              if (slot >= 0) {
                                 it.remove();
                                 this.drinkPotion(slot, this.bot.getInventory());
                                 return true;
                              }

                              if (this.findPotion(Items.SPLASH_POTION, effect, this.bot.getInventory()) < 0) {
                                 it.remove();
                              }
                           }
                        }

                        return false;
                     }
                  }
               }
            }
         }
      }
   }

   private void enqueueAvailableBuffs() {
      for(Holder<MobEffect> effect : BUFF_EFFECTS) {
         if (this.needsBuff(effect) && !this.potionQueue.contains(effect) && this.hasPotionInInventory(effect)) {
            this.potionQueue.add(effect);
         }
      }

   }

   private void checkEffectExpiry() {
      boolean curStrength = this.hasEffect(MobEffects.STRENGTH);
      boolean curSpeed = this.hasEffect(MobEffects.SPEED);
      boolean curFireRes = this.hasEffect(MobEffects.FIRE_RESISTANCE);
      boolean curRegen = this.hasEffect(MobEffects.REGENERATION);
      boolean curInvis = this.hasEffect(MobEffects.INVISIBILITY);
      this.maybeRequeue(MobEffects.STRENGTH, this.prevStrength, curStrength);
      this.maybeRequeue(MobEffects.SPEED, this.prevSpeed, curSpeed);
      this.maybeRequeue(MobEffects.FIRE_RESISTANCE, this.prevFireRes, curFireRes);
      this.maybeRequeue(MobEffects.REGENERATION, this.prevRegen, curRegen);
      this.maybeRequeue(MobEffects.INVISIBILITY, this.prevInvis, curInvis);
      this.prevStrength = curStrength;
      this.prevSpeed = curSpeed;
      this.prevFireRes = curFireRes;
      this.prevRegen = curRegen;
      this.prevInvis = curInvis;
   }

   private void maybeRequeue(Holder<MobEffect> effect, boolean hadIt, boolean hasIt) {
      if (hadIt && !hasIt && !this.potionQueue.contains(effect) && this.hasPotionInInventory(effect)) {
         this.potionQueue.add(effect);
      }

   }

   private boolean tryUsePotionNow(Holder<MobEffect> wantedEffect, boolean allowDrinking) {
      Inventory inv = this.bot.getInventory();
      int slot = this.canSplashAtFeet() ? this.findPotion(Items.SPLASH_POTION, wantedEffect, inv) : -1;
      if (slot >= 0) {
         this.throwSplashPotion(slot, inv, wantedEffect);
         return true;
      } else {
         if (allowDrinking) {
            slot = this.findPotion(Items.POTION, wantedEffect, inv);
            if (slot >= 0) {
               this.drinkPotion(slot, inv);
               return true;
            }
         }

         return false;
      }
   }

   private boolean canUsePotionNow(Holder<MobEffect> effect, boolean allowDrinking) {
      Inventory inv = this.bot.getInventory();
      return this.canSplashAtFeet() && this.findPotion(Items.SPLASH_POTION, effect, inv) >= 0 || allowDrinking && this.findPotion(Items.POTION, effect, inv) >= 0;
   }

   private boolean hasPotionInInventory(Holder<MobEffect> effect) {
      Inventory inv = this.bot.getInventory();
      return this.findPotion(Items.SPLASH_POTION, effect, inv) >= 0 || this.findPotion(Items.POTION, effect, inv) >= 0;
   }

   private int findPotion(Item potionItem, Holder<MobEffect> wantedEffect, Inventory inv) {
      int best = -1;
      int bestAmp = -1;

      for(int pass = 0; pass < 2; ++pass) {
         int from = pass == 0 ? 0 : 9;
         int to = pass == 0 ? 9 : 36;

         for(int i = from; i < to; ++i) {
            ItemStack stack = inv.getItem(i);
            if (stack.is(potionItem) && grants(stack, wantedEffect)) {
               int amp = amplifierOf(stack, wantedEffect);
               if (amp > bestAmp) {
                  best = i;
                  bestAmp = amp;
               }
            }
         }
      }

      return best;
   }

   private boolean canSplashAtFeet() {
      if (this.bot.onGround()) {
         return true;
      } else if (this.bot.isFallFlying()) {
         return false;
      } else {
         BlockPos p = this.bot.blockPosition();

         for(int d = 1; d <= (int)Math.ceil((double)1.5F); ++d) {
            if (!this.bot.level().getBlockState(p.below(d)).isAir()) {
               return true;
            }
         }

         return false;
      }
   }

   private static boolean grants(ItemStack stack, Holder<MobEffect> effect) {
      if (effect == null) {
         return false;
      } else {
         PotionContents contents = (PotionContents)stack.get(DataComponents.POTION_CONTENTS);
         if (contents == null) {
            return false;
         } else {
            for(MobEffectInstance inst : contents.getAllEffects()) {
               if (inst.getEffect().equals(effect)) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   private int reacquireSplashSlot(Inventory inv) {
      if (this.splashSlot >= 0 && this.splashSlot < 9 && inv.getItem(this.splashSlot).is(Items.SPLASH_POTION) && grants(inv.getItem(this.splashSlot), this.splashEffect)) {
         return this.splashSlot;
      } else if (this.splashEffect == null) {
         return -1;
      } else {
         int slot = this.findPotion(Items.SPLASH_POTION, this.splashEffect, inv);
         return slot < 0 ? -1 : this.ensureHotbar(slot, inv);
      }
   }

   private void endSplashSession() {
      this.bot.setShiftKeyDown(false);
      this.splashWindup = 0;
      this.splashSlot = -1;
      this.splashEffect = null;
      this.splashChaining = false;
   }

   public boolean isSplashing() {
      return this.splashWindup > 0 || this.splashChaining;
   }

   private void throwSplashPotion(int slot, Inventory inv, Holder<MobEffect> effect) {
      slot = this.ensureHotbar(slot, inv);
      InventoryUtils.select(inv, slot);
      this.bot.setShiftKeyDown(true);
      this.bot.setXRot(90.0F);
      this.splashSlot = slot;
      this.splashEffect = effect;
      this.splashWindup = 3;
      this.splashChaining = false;
      this.isDrinking = false;
   }

   private boolean beginNextSplashFromQueue() {
      Inventory inv = this.bot.getInventory();
      Iterator<Holder<MobEffect>> it = this.potionQueue.iterator();

      while(it.hasNext()) {
         Holder<MobEffect> effect = (Holder)it.next();
         if (!this.needsBuff(effect)) {
            it.remove();
         } else {
            int slot = this.findPotion(Items.SPLASH_POTION, effect, inv);
            if (slot >= 0) {
               it.remove();
               slot = this.ensureHotbar(slot, inv);
               InventoryUtils.select(inv, slot);
               this.splashSlot = slot;
               this.splashEffect = effect;
               this.splashWindup = this.potChainTicks();
               return true;
            }
         }
      }

      return false;
   }

   private int potChainTicks() {
      return EffectiveSettings.of(this.bot.getScoreboardName()).difficultyParams().potIntervalTicks();
   }

   private void drinkPotion(int slot, Inventory inv) {
      this.drinkItem(slot, inv, 32);
   }

   private void drinkItem(int slot, Inventory inv, int ticks) {
      slot = this.ensureHotbar(slot, inv);
      InventoryUtils.select(inv, slot);
      this.bot.startUsingItem(InteractionHand.MAIN_HAND);
      this.isDrinking = true;
      this.drinkTicksLeft = ticks;
   }

   private int findItem(Item item, Inventory inv) {
      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(item)) {
            return i;
         }
      }

      return -1;
   }

   private int ensureHotbar(int slot, Inventory inv) {
      return InventoryUtils.moveToHotbarSafe(inv, slot);
   }

   private boolean hasEffect(Holder<MobEffect> effect) {
      return this.bot.hasEffect(effect);
   }

   private boolean needsBuff(Holder<MobEffect> effect) {
      MobEffectInstance cur = this.bot.getEffect(effect);
      if (cur == null) {
         return true;
      } else {
         return this.bestCarriedAmplifier(effect) > cur.getAmplifier();
      }
   }

   private int bestCarriedAmplifier(Holder<MobEffect> effect) {
      Inventory inv = this.bot.getInventory();
      int best = -1;

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (st.is(Items.SPLASH_POTION) || st.is(Items.POTION)) {
            best = Math.max(best, amplifierOf(st, effect));
         }
      }

      return best;
   }

   private static int amplifierOf(ItemStack stack, Holder<MobEffect> effect) {
      PotionContents contents = (PotionContents)stack.get(DataComponents.POTION_CONTENTS);
      if (contents == null) {
         return -1;
      } else {
         int best = -1;

         for(MobEffectInstance inst : contents.getAllEffects()) {
            if (inst.getEffect().equals(effect)) {
               best = Math.max(best, inst.getAmplifier());
            }
         }

         return best;
      }
   }

   static {
      BUFF_EFFECTS = List.of(MobEffects.STRENGTH, MobEffects.SPEED, MobEffects.FIRE_RESISTANCE, MobEffects.REGENERATION, MobEffects.INVISIBILITY);
   }
}
