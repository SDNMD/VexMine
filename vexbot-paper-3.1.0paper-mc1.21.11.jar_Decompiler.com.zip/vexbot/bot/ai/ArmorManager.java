package vexbot.bot.ai;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.util.EnchantmentUtils;
import vexbot.util.VexLog;

public final class ArmorManager {
   private static final double SCAN_RANGE = (double)16.0F;
   private static final int DROP_SCAN_INTERVAL = 10;
   private int dropScanTick = 10;
   private static final double MIN_GAIN = (double)0.5F;
   private final ServerPlayer bot;
   private final PathFollower path;
   private ItemEntity targetItem = null;
   private static final int MAX_CHASE_TICKS = 200;
   private static final int MAX_IGNORED = 32;
   private int chaseTicks = 0;
   private final Set<UUID> ignoredDrops = new HashSet();

   public ArmorManager(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.path = new PathFollower(bot, server);
   }

   public void equipFromInventory() {
      if (EffectiveSettings.of(this.bot.getScoreboardName()).equipArmor()) {
         Inventory inv = this.bot.getInventory();
         if (InvisibleSuitUp.holdsArmour(this.bot)) {
            this.equipBestWeapon();
         } else {
            if (this.bot.isInWater()) {
               this.equipTurtleShell(inv);
            }

            for(int i = 0; i < 36; ++i) {
               ItemStack stack = inv.getItem(i);
               if (ArmorEvaluator.isArmor(stack)) {
                  EquipmentSlot slot = ArmorEvaluator.getSlot(stack);
                  if (slot != null) {
                     ItemStack current = this.bot.getItemBySlot(slot);
                     if ((slot != EquipmentSlot.HEAD || !this.bot.isInWater() || !current.is(Items.TURTLE_HELMET)) && ArmorEvaluator.score(stack) > ArmorEvaluator.score(current)) {
                        ItemStack old = current.copy();
                        this.bot.setItemSlot(slot, stack.copy());
                        inv.setItem(i, old);
                        VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' equipped {} (score {}) over {} (score {})", this.bot.getScoreboardName(), stack.getHoverName().getString(), String.format("%.1f", ArmorEvaluator.score(stack)), current.isEmpty() ? "nothing" : current.getHoverName().getString(), String.format("%.1f", ArmorEvaluator.score(current)));
                     }
                  }
               }
            }

            this.equipBestWeapon();
         }
      }
   }

   private void equipTurtleShell(Inventory inv) {
      ItemStack currentHelmet = this.bot.getItemBySlot(EquipmentSlot.HEAD);
      if (!currentHelmet.is(Items.TURTLE_HELMET)) {
         for(int i = 0; i < 36; ++i) {
            ItemStack stack = inv.getItem(i);
            if (stack.is(Items.TURTLE_HELMET)) {
               this.bot.setItemSlot(EquipmentSlot.HEAD, stack.copy());
               inv.setItem(i, currentHelmet.copy());
               VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' equipped Turtle Shell for water breathing.", this.bot.getScoreboardName());
               return;
            }
         }

      }
   }

   private void equipBestWeapon() {
      Inventory inv = this.bot.getInventory();
      int bestSlot = -1;
      double bestScore = (double)0.0F;

      for(int i = 0; i < 36; ++i) {
         double s = ItemEvaluator.scoreWeapon(inv.getItem(i));
         if (s > bestScore) {
            bestScore = s;
            bestSlot = i;
         }
      }

      if (bestSlot >= 0) {
         if (bestSlot >= 9) {
            int destSlot = -1;
            double destScore = Double.MAX_VALUE;

            for(int i = 0; i < 9; ++i) {
               ItemStack stack = inv.getItem(i);
               if (!isComboCritical(stack)) {
                  double s = ItemEvaluator.scoreWeapon(stack);
                  if (s < destScore) {
                     destScore = s;
                     destSlot = i;
                  }
               }
            }

            if (destSlot >= 0) {
               if (!(bestScore <= destScore)) {
                  ItemStack candidate = inv.getItem(bestSlot).copy();
                  ItemStack displaced = inv.getItem(destSlot).copy();
                  inv.setItem(destSlot, candidate);
                  inv.setItem(bestSlot, displaced);
                  VexLog.detail(VexBot.LOGGER, "[VexBot] '{}' pulled best weapon {} to the hotbar (score {})", this.bot.getScoreboardName(), candidate.getHoverName().getString(), String.format("%.1f", bestScore));
               }
            }
         }
      }
   }

   private static boolean isComboCritical(ItemStack stack) {
      if (stack.isEmpty()) {
         return false;
      } else {
         return !stack.is(Items.MACE) && !stack.is(Items.BOW) && !stack.is(Items.CROSSBOW) && !stack.is(Items.ELYTRA) && !stack.is(Items.TRIDENT) ? EnchantmentUtils.hasEnchantAtLeast(stack, "lunge", 3) : true;
      }
   }

   public boolean tickNavigation() {
      if (!EffectiveSettings.of(this.bot.getScoreboardName()).pickupLoot()) {
         this.targetItem = null;
         this.path.reset();
         return false;
      } else {
         if (this.targetItem != null && (this.targetItem.isRemoved() || !this.targetItem.isAlive())) {
            this.targetItem = null;
         }

         if (++this.dropScanTick >= 10) {
            this.dropScanTick = 0;
            ItemEntity best = this.findBestDrop();
            if (best != this.targetItem) {
               this.chaseTicks = 0;
            }

            this.targetItem = best;
         }

         if (this.targetItem == null) {
            this.chaseTicks = 0;
            this.path.reset();
            return false;
         } else if (++this.chaseTicks > 200) {
            if (this.ignoredDrops.size() >= 32) {
               this.ignoredDrops.clear();
            }

            this.ignoredDrops.add(this.targetItem.getUUID());
            this.targetItem = null;
            this.chaseTicks = 0;
            this.path.reset();
            return false;
         } else {
            this.path.chase((Entity)this.targetItem);
            return true;
         }
      }
   }

   public void resetNavigation() {
      this.targetItem = null;
      this.chaseTicks = 0;
      this.path.reset();
   }

   private ItemEntity findBestDrop() {
      if (this.bot.getInventory().getFreeSlot() < 0) {
         return null;
      } else {
         AABB box = this.bot.getBoundingBox().inflate((double)16.0F);
         ItemEntity best = null;
         double bestGain = (double)0.5F;

         for(ItemEntity ie : this.bot.level().getEntitiesOfClass(ItemEntity.class, box)) {
            if (!ie.isRemoved() && !this.ignoredDrops.contains(ie.getUUID())) {
               ItemStack stack = ie.getItem();
               if (ArmorEvaluator.isArmor(stack)) {
                  EquipmentSlot slot = ArmorEvaluator.getSlot(stack);
                  if (slot != null) {
                     double gain = ArmorEvaluator.score(stack) - ArmorEvaluator.score(this.bot.getItemBySlot(slot));
                     if (gain > bestGain) {
                        bestGain = gain;
                        best = ie;
                     }
                  }
               }
            }
         }

         return best;
      }
   }
}
