package vexbot.bot.ai;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import vexbot.bot.BotManager;

public final class ChaseSpread {
   static final double FULL_AT = (double)17.0F;
   static final double NONE_AT = (double)7.0F;
   static final double SPACING = 2.2;
   static final int PER_RANK = 12;
   static final double RANK_GAP = (double)2.5F;
   private static final double MAX_FAN_DEG = (double)90.0F;
   private static final Map<UUID, Plan> PLANS = new HashMap();

   private ChaseSpread() {
   }

   public static Vec3 offsetFor(ServerPlayer bot, LivingEntity target, double dist) {
      if (target != null && !(dist <= (double)7.0F)) {
         long tick = bot.level().getGameTime();
         Plan plan = (Plan)PLANS.get(target.getUUID());
         if (plan == null || plan.tick() != tick) {
            if (PLANS.size() > 256) {
               PLANS.clear();
            }

            plan = build(target, tick);
            PLANS.put(target.getUUID(), plan);
         }

         double[] slot = (double[])plan.slots().get(bot.getUUID());
         if (slot == null) {
            return null;
         } else {
            double scale = Math.min((double)1.0F, (dist - (double)7.0F) / (double)10.0F);
            double px = -plan.fz();
            double pz = plan.fx();
            double ox = (px * slot[0] - plan.fx() * slot[1]) * scale;
            double oz = (pz * slot[0] - plan.fz() * slot[1]) * scale;
            return new Vec3(ox, (double)0.0F, oz);
         }
      } else {
         return null;
      }
   }

   private static Plan build(LivingEntity target, long tick) {
      List<ServerPlayer> chasers = new ArrayList();

      for(SwordPvpController ai : BotManager.activeControllers()) {
         ServerPlayer b = ai.getBot();
         if (ai.getTarget() == target && b != null && b.isAlive() && b.level() == target.level() && !((double)b.distanceTo(target) <= (double)7.0F)) {
            chasers.add(b);
         }
      }

      Map<UUID, double[]> slots = new HashMap();
      if (chasers.size() < 2) {
         return new Plan(tick, (double)0.0F, (double)1.0F, slots);
      } else {
         double minB = Double.MAX_VALUE;
         double maxB = -Double.MAX_VALUE;
         double sumSin = (double)0.0F;
         double sumCos = (double)0.0F;

         for(ServerPlayer b : chasers) {
            double a = Math.atan2(b.getZ() - target.getZ(), b.getX() - target.getX());
            sumSin += Math.sin(a);
            sumCos += Math.cos(a);
         }

         double mean = Math.atan2(sumSin, sumCos);

         for(ServerPlayer b : chasers) {
            double a = Math.atan2(b.getZ() - target.getZ(), b.getX() - target.getX());
            double d = Math.toDegrees(Math.atan2(Math.sin(a - mean), Math.cos(a - mean)));
            minB = Math.min(minB, d);
            maxB = Math.max(maxB, d);
         }

         if (maxB - minB > (double)90.0F) {
            return new Plan(tick, (double)0.0F, (double)1.0F, slots);
         } else {
            double cx = (double)0.0F;
            double cz = (double)0.0F;

            for(ServerPlayer b : chasers) {
               cx += b.getX();
               cz += b.getZ();
            }

            cx /= (double)chasers.size();
            cz /= (double)chasers.size();
            double fx = target.getX() - cx;
            double fz = target.getZ() - cz;
            double len = Math.sqrt(fx * fx + fz * fz);
            if (len < 0.001) {
               return new Plan(tick, (double)0.0F, (double)1.0F, slots);
            } else {
               fx /= len;
               fz /= len;
               double pxs = -fz;
               double pzs = fx;
               double ccx = cx;
               double ccz = cz;
               chasers.sort(Comparator.comparingDouble((bx) -> bx.distanceToSqr(target)));

               for(int r = 0; r * 12 < chasers.size(); ++r) {
                  List<ServerPlayer> rank = new ArrayList(chasers.subList(r * 12, Math.min(chasers.size(), (r + 1) * 12)));
                  rank.sort(Comparator.comparingDouble((bx) -> (bx.getX() - ccx) * pxs + (bx.getZ() - ccz) * pzs));
                  double half = (double)(rank.size() - 1) / (double)2.0F;

                  for(int k = 0; k < rank.size(); ++k) {
                     slots.put(((ServerPlayer)rank.get(k)).getUUID(), new double[]{((double)k - half) * 2.2, (double)r * (double)2.5F});
                  }
               }

               return new Plan(tick, fx, fz, slots);
            }
         }
      }
   }

   private static record Plan(long tick, double fx, double fz, Map<UUID, double[]> slots) {
   }
}
