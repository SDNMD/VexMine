package vexbot.bot.ai;

import java.util.Random;

public final class StrafeController {
   private static final Random RNG = new Random();
   private static final float TICK_JITTER = 6.0F;
   private static final int FLIP_MIN = 8;
   private static final int FLIP_MAX = 18;
   private static final float BURST_ANGLE = 85.0F;
   private static final int BURST_MIN = 3;
   private static final int BURST_MAX = 6;
   private int direction = 1;
   private int remaining;
   private boolean inBurst = false;
   private int burstTicks = 0;

   public StrafeController() {
      this.remaining = 8 + RNG.nextInt(11);
   }

   public float getYawOffset(int tickCount, float baseAngle) {
      if (--this.remaining <= 0) {
         this.direction = -this.direction;
         this.remaining = 8 + RNG.nextInt(11);
      }

      if (this.inBurst) {
         --this.burstTicks;
         if (this.burstTicks <= 0) {
            this.inBurst = false;
         }

         float jitter = (RNG.nextFloat() - 0.5F) * 6.0F;
         return (float)this.direction * 85.0F + jitter;
      } else {
         float jitter = (RNG.nextFloat() - 0.5F) * 6.0F * 2.0F;
         return (float)this.direction * baseAngle + jitter;
      }
   }

   public float attackTickStrafe() {
      return (float)this.direction * (0.3F + RNG.nextFloat() * 0.25F);
   }

   public void onAttack() {
      this.direction = -this.direction;
      this.remaining = 8 + RNG.nextInt(11);
   }

   public void triggerBurst() {
      if (!this.inBurst) {
         this.inBurst = true;
         this.burstTicks = 3 + RNG.nextInt(4);
         if (RNG.nextBoolean()) {
            this.direction = -this.direction;
         }

      }
   }

   public boolean isBursting() {
      return this.inBurst;
   }
}
