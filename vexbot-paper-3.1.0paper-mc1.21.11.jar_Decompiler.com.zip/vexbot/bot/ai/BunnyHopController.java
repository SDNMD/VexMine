package vexbot.bot.ai;

import java.util.Random;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import vexbot.EffectiveSettings;
import vexbot.util.BotCommands;

public final class BunnyHopController {
   private static final Random RNG = new Random();
   private static final int MAX_HOP_DELAY = 4;
   private static final double SKIP_CHANCE = 0.18;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private boolean wasAirborne = false;
   private int groundTicks = 0;
   private int nextHopDelay = 0;
   private boolean skipThisHop = false;

   public BunnyHopController(ServerPlayer bot, MinecraftServer server) {
      this.bot = bot;
      this.server = server;
   }

   private void startHopCycle() {
      this.groundTicks = 0;
      this.nextHopDelay = RNG.nextInt(5);
      this.skipThisHop = RNG.nextDouble() < 0.18;
   }

   public static boolean runsInsteadOfHopping(ServerPlayer bot) {
      if (!EffectiveSettings.of(bot.getScoreboardName()).speedNoJump()) {
         return false;
      } else {
         MobEffectInstance speed = bot.getEffect(MobEffects.SPEED);
         return speed != null && speed.getAmplifier() >= 1;
      }
   }

   public void tick(boolean smartAllowed) {
      if (!this.bot.isUsingItem() || this.bot.getMainHandItem().has(DataComponents.KINETIC_WEAPON)) {
         boolean var10000;
         switch (EffectiveSettings.of(this.bot.getScoreboardName()).bunnyHopMode()) {
            case OFF -> var10000 = false;
            case ON -> var10000 = true;
            case SMART -> var10000 = smartAllowed;
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         boolean shouldHop = var10000;
         if (runsInsteadOfHopping(this.bot)) {
            shouldHop = false;
         }

         if (!this.bot.onGround()) {
            this.wasAirborne = true;
         } else {
            if (this.wasAirborne) {
               this.wasAirborne = false;
               this.startHopCycle();
            }

            ++this.groundTicks;
            if (this.groundTicks >= this.nextHopDelay) {
               if (shouldHop && this.bot.isSprinting() && !this.skipThisHop) {
                  BotCommands.jumpOnce(this.server, this.bot.getScoreboardName());
               } else {
                  this.startHopCycle();
               }

            }
         }
      }
   }
}
