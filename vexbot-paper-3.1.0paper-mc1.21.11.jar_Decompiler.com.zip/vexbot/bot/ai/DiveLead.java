package vexbot.bot.ai;

import java.util.UUID;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

final class DiveLead {
   static final double MOVING_SPEED = 0.06;
   private static final int MAX_LEAD_TICKS = 20;
   private static final double LEAD_TRUST = 0.85;
   private UUID id;
   private Vec3 last;
   private long lastTick;
   private Vec3 vel;

   DiveLead() {
      this.vel = Vec3.ZERO;
   }

   Vec3 track(LivingEntity t) {
      long now = t.level().getGameTime();
      Vec3 pos = t.position();
      if (t.getUUID().equals(this.id) && this.last != null) {
         if (now != this.lastTick) {
            long gap = Math.max(1L, now - this.lastTick);
            Vec3 step = pos.subtract(this.last).scale((double)1.0F / (double)gap);
            if (step.lengthSqr() > (double)36.0F) {
               step = Vec3.ZERO;
            }

            this.vel = this.vel.scale(0.45).add(step.scale(0.55));
            this.last = pos;
            this.lastTick = now;
         }

         return this.vel;
      } else {
         this.id = t.getUUID();
         this.last = pos;
         this.lastTick = now;
         this.vel = Vec3.ZERO;
         return this.vel;
      }
   }

   boolean moving(LivingEntity t) {
      Vec3 v = this.track(t);
      return !t.onGround() || Math.sqrt(v.x * v.x + v.z * v.z) > 0.06;
   }

   Vec3 lead(LivingEntity t, int ticks) {
      Vec3 v = this.track(t);
      double k = (double)Math.min(Math.max(ticks, 0), 20) * 0.85;
      return new Vec3(t.getX() + v.x * k, t.getY(), t.getZ() + v.z * k);
   }

   static int ticksToDrop(double height, double vy) {
      if (height <= (double)0.0F) {
         return 0;
      } else {
         double y = (double)0.0F;
         double v = vy;

         for(int t = 1; t <= 60; ++t) {
            v = (v - 0.08) * 0.98;
            y += v;
            if (-y >= height) {
               return t;
            }
         }

         return 60;
      }
   }

   void reset() {
      this.id = null;
      this.last = null;
      this.vel = Vec3.ZERO;
   }
}
