package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import vexbot.EffectiveSettings;
import vexbot.compat.McCompat;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;
import vexbot.util.WaterRules;
import vexbot.util.WebDetect;
import vexbot.util.WebPlacer;

public final class CobwebEscapeController {
   private static final int PICKUP_DELAY = 10;
   private static final int SCOOP_TIMEOUT = 100;
   private static final int PEARL_RADIUS = 5;
   private static final int PEARL_RETRY = 40;
   private static final float PEARL_PITCH = -24.0F;
   private final ServerPlayer bot;
   private boolean escaping = false;
   private int pickupTimer = 0;
   private int scoopTicks = 0;
   private BlockPos waterPos = null;
   private BlockPos cobwebPos = null;
   private int bucketSlot = -1;
   private int prevSelected = -1;
   private int pearlRetry = 0;
   private int reactTicks = -1;
   private boolean mining = false;
   private BlockPos miningPos = null;
   private int miningTicks = 0;
   private float mineProgress = 0.0F;

   public CobwebEscapeController(ServerPlayer bot) {
      this.bot = bot;
   }

   public boolean tick() {
      if (this.pearlRetry > 0) {
         --this.pearlRetry;
      }

      if (!this.escaping && !(new EffectiveSettings(this.bot.getScoreboardName())).webEscape()) {
         if (this.mining) {
            this.endSwordMine();
         }

         return false;
      } else if (this.mining) {
         Level level = this.bot.level();
         if (!this.isTrappedInCobweb(level)) {
            this.endSwordMine();
            return false;
         } else {
            return this.tickSwordMine(level);
         }
      } else if (!this.escaping) {
         Level level = this.bot.level();
         BlockPos web = WebDetect.firstWeb(this.bot);
         if (web == null) {
            this.reactTicks = -1;
            return false;
         } else {
            if (this.reactTicks < 0) {
               this.reactTicks = (new EffectiveSettings(this.bot.getScoreboardName())).difficultyParams().webEscapeDelayTicks();
            }

            if (this.reactTicks > 0) {
               --this.reactTicks;
               return false;
            } else {
               this.reactTicks = -1;
               if (WebPlacer.hasShears(this.bot)) {
                  return this.tickSwordMine(level);
               } else {
                  BlockPos waterPlace = WaterRules.evaporates(level, web) ? null : this.findWaterPlacementPos(level, web);
                  if (waterPlace != null && this.findWaterBucket() >= 0) {
                     this.startWaterEscape(level, web, waterPlace);
                     return true;
                  } else if (this.pearlRetry <= 0 && this.tryPearlEscape(level)) {
                     this.pearlRetry = 40;
                     return true;
                  } else {
                     return this.findPearl() < 0 ? this.tickSwordMine(level) : true;
                  }
               }
            }
         }
      } else {
         Level level = this.bot.level();
         boolean cobwebGone = this.cobwebPos == null || !level.getBlockState(this.cobwebPos).is(Blocks.COBWEB);
         if (!cobwebGone && --this.pickupTimer > 0) {
            return true;
         } else {
            BlockPos waterAt = this.findWaterSourceNearby(level);
            if (waterAt == null) {
               this.endWaterEscape();
               return false;
            } else if (++this.scoopTicks > 100) {
               this.endWaterEscape();
               return false;
            } else if (this.bot.getOffhandItem().is(Items.BUCKET)) {
               this.aimAtBlock(waterAt);
               this.bot.gameMode.useItem(this.bot, level, this.bot.getOffhandItem(), InteractionHand.OFF_HAND);
               return true;
            } else {
               int emptyBucket = this.findEmptyBucket();
               if (emptyBucket < 0) {
                  this.endWaterEscape();
                  return false;
               } else {
                  Inventory inv = this.bot.getInventory();
                  emptyBucket = InventoryUtils.moveToHotbarSafe(inv, emptyBucket);
                  InventoryUtils.select(inv, emptyBucket);
                  this.aimAtBlock(waterAt);
                  this.bot.gameMode.useItem(this.bot, level, inv.getItem(emptyBucket), InteractionHand.MAIN_HAND);
                  return true;
               }
            }
         }
      }
   }

   private boolean tickSwordMine(Level level) {
      String name = this.bot.getScoreboardName();
      BlockPos web = this.pickCobwebToMine(level);
      if (web == null) {
         this.endSwordMine();
         return false;
      } else {
         if (!this.mining || !web.equals(this.miningPos)) {
            this.miningPos = web;
            this.miningTicks = 0;
            this.mineProgress = 0.0F;
            this.equipSword();
            if (!this.mining) {
               this.mining = true;
               BotCommands.mineContinuous(this.server(), name);
            }
         }

         ++this.miningTicks;
         this.aimAtBlock(this.miningPos);
         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
         BlockState webState = level.getBlockState(this.miningPos);
         if (webState.is(Blocks.COBWEB)) {
            this.mineProgress += webState.getDestroyProgress(this.bot, level, this.miningPos);
            if (this.mineProgress >= 1.0F) {
               this.bot.gameMode.destroyBlock(this.miningPos);
            }
         }

         return true;
      }
   }

   private void endSwordMine() {
      if (this.mining) {
         BotCommands.stopMining(this.server(), this.bot.getScoreboardName());
      }

      this.mining = false;
      this.miningPos = null;
      this.miningTicks = 0;
      this.mineProgress = 0.0F;
   }

   private BlockPos pickCobwebToMine(Level level) {
      Player threat = level.getNearestPlayer(this.bot, (double)16.0F);
      if (threat != null) {
         double dx = this.bot.getX() - threat.getX();
         double dz = this.bot.getZ() - threat.getZ();
         double len = Math.hypot(dx, dz);
         if (len > 0.001) {
            dx /= len;
            dz /= len;
            BlockPos feet = this.bot.blockPosition();
            BlockPos[] outward = new BlockPos[]{BlockPos.containing(this.bot.getX() + dx, this.bot.getY() + 0.1, this.bot.getZ() + dz), BlockPos.containing(this.bot.getX() + dx, this.bot.getEyeY(), this.bot.getZ() + dz)};

            for(BlockPos p : outward) {
               if (!p.equals(feet) && level.getBlockState(p).is(Blocks.COBWEB)) {
                  return p;
               }
            }
         }
      }

      return WebDetect.firstWeb(this.bot);
   }

   private void equipSword() {
      WebPlacer.equipWebCutter(this.bot);
   }

   private MinecraftServer server() {
      return this.bot.level().getServer();
   }

   private boolean isTrappedInCobweb(Level level) {
      return WebDetect.touchingWeb(this.bot);
   }

   private BlockPos findWaterPlacementPos(Level level, BlockPos web) {
      BlockPos above = web.above();
      if (level.getBlockState(above).is(Blocks.COBWEB)) {
         return level.getBlockState(above.above()).isAir() ? above.above() : null;
      } else {
         return level.getBlockState(above).isAir() ? above : null;
      }
   }

   private void startWaterEscape(Level level, BlockPos web, BlockPos waterPlace) {
      this.bucketSlot = this.findWaterBucket();
      if (this.bucketSlot >= 0) {
         this.waterPos = waterPlace;
         this.cobwebPos = web;
         Inventory inv = this.bot.getInventory();
         this.prevSelected = InventoryUtils.selected(inv);
         this.bucketSlot = InventoryUtils.moveToHotbarSafe(inv, this.bucketSlot);
         InventoryUtils.select(inv, this.bucketSlot);
         this.aimAtBlock(waterPlace);
         level.setBlockAndUpdate(waterPlace, Blocks.WATER.defaultBlockState());
         inv.setItem(this.bucketSlot, new ItemStack(Items.BUCKET));
         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
         level.playSound((Entity)null, waterPlace, SoundEvents.BUCKET_EMPTY, SoundSource.PLAYERS, 1.0F, 1.0F);
         this.escaping = true;
         this.pickupTimer = 10;
      }
   }

   private BlockPos findWaterSourceNearby(Level level) {
      BlockPos feet = this.bot.blockPosition();
      BlockPos[] candidates = this.waterPos == null ? new BlockPos[]{feet, feet.above()} : new BlockPos[]{this.waterPos, this.waterPos.below(), this.waterPos.below(2), feet, feet.above()};

      for(BlockPos p : candidates) {
         FluidState fluid = level.getFluidState(p);
         if (fluid.isSource() && fluid.is(FluidTags.WATER)) {
            return p;
         }
      }

      return null;
   }

   private int findEmptyBucket() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 36; ++i) {
         if (inv.getItem(i).is(Items.BUCKET)) {
            return i;
         }
      }

      return -1;
   }

   private void endWaterEscape() {
      if (this.prevSelected >= 0) {
         InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
         this.prevSelected = -1;
      }

      this.escaping = false;
      this.waterPos = null;
      this.cobwebPos = null;
      this.bucketSlot = -1;
      this.scoopTicks = 0;
   }

   private boolean tryPearlEscape(Level level) {
      if (this.bot.getCooldowns().isOnCooldown(new ItemStack(Items.ENDER_PEARL))) {
         return false;
      } else {
         int pearlSlot = this.findPearl();
         if (pearlSlot < 0) {
            return false;
         } else {
            Vec3 target = this.findPearlTarget(level);
            if (target == null) {
               return false;
            } else {
               pearlSlot = InventoryUtils.moveToHotbarSafe(this.bot.getInventory(), pearlSlot);
               this.prevSelected = InventoryUtils.selected(this.bot.getInventory());
               InventoryUtils.select(this.bot.getInventory(), pearlSlot);
               this.aimAtPoint(target);
               ItemStack pearl = this.bot.getInventory().getItem(pearlSlot);
               if (!pearl.is(Items.ENDER_PEARL)) {
                  InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
                  this.prevSelected = -1;
                  return false;
               } else {
                  try {
                     this.bot.gameMode.useItem(this.bot, level, pearl, InteractionHand.MAIN_HAND);
                  } catch (Exception var6) {
                     InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
                     this.prevSelected = -1;
                     return false;
                  }

                  InventoryUtils.select(this.bot.getInventory(), this.prevSelected);
                  this.prevSelected = -1;
                  return true;
               }
            }
         }
      }
   }

   private Vec3 findPearlTarget(Level level) {
      BlockPos origin = this.bot.blockPosition();
      float awayYaw = this.awayFromWallYaw(level);
      Vec3 best = null;
      double bestScore = Double.NEGATIVE_INFINITY;

      for(int dx = -5; dx <= 5; ++dx) {
         for(int dz = -5; dz <= 5; ++dz) {
            double horizSq = (double)dx * (double)dx + (double)dz * (double)dz;
            if (!(horizSq < (double)1.0F) && !(horizSq > (double)25.0F)) {
               for(int dy = 2; dy >= -2; --dy) {
                  BlockPos stand = origin.offset(dx, dy, dz);
                  if (this.isStandableLanding(level, stand)) {
                     double dist = Math.sqrt(horizSq);
                     double distScore = (double)1.0F - Math.abs(dist - (double)4.0F) / (double)5.0F;
                     double dirX = (double)dx / dist;
                     double dirZ = (double)dz / dist;
                     double awayRad = Math.toRadians((double)awayYaw);
                     double awayX = -Math.sin(awayRad);
                     double awayZ = Math.cos(awayRad);
                     double alignScore = dirX * awayX + dirZ * awayZ;
                     double score = distScore + alignScore * (double)1.5F;
                     if (score > bestScore) {
                        bestScore = score;
                        best = Vec3.atCenterOf(stand);
                     }
                  }
               }
            }
         }
      }

      if (best != null) {
         return best;
      } else {
         return this.fallbackPearlTarget();
      }
   }

   private float awayFromWallYaw(Level level) {
      BlockPos feet = this.bot.blockPosition();
      float bestWallYaw = this.bot.getYRot();
      int bestSolid = -1;

      for(Direction dir : Plane.HORIZONTAL) {
         int solid = 0;

         for(int d = 0; d <= 2; ++d) {
            BlockPos check = feet.relative(dir, d);
            if (isSolidAt(level, check) || isSolidAt(level, check.above())) {
               ++solid;
            }
         }

         if (solid > bestSolid) {
            bestSolid = solid;
            bestWallYaw = dir.toYRot();
         }
      }

      if (bestSolid <= 0) {
         return this.bot.getYRot();
      } else {
         return bestWallYaw + 180.0F;
      }
   }

   private Vec3 fallbackPearlTarget() {
      float awayYaw = this.awayFromWallYaw(this.bot.level());
      double rad = Math.toRadians((double)awayYaw);
      return new Vec3(this.bot.getX() - Math.sin(rad) * (double)4.0F, this.bot.getY(), this.bot.getZ() + Math.cos(rad) * (double)4.0F);
   }

   private boolean isStandableLanding(Level level, BlockPos stand) {
      BlockPos below = stand.below();
      if (level.getBlockState(below).getCollisionShape(level, below).isEmpty()) {
         return false;
      } else if (level.getBlockState(below).is(Blocks.COBWEB)) {
         return false;
      } else if (level.getBlockState(stand).is(Blocks.COBWEB)) {
         return false;
      } else if (!level.getBlockState(stand).getCollisionShape(level, stand).isEmpty()) {
         return false;
      } else if (!level.getBlockState(stand.above()).getCollisionShape(level, stand.above()).isEmpty()) {
         return false;
      } else {
         return !level.getBlockState(stand.above()).is(Blocks.COBWEB);
      }
   }

   private void aimAtBlock(BlockPos pos) {
      this.aimAtPoint(Vec3.atCenterOf(pos));
   }

   private void aimAtPoint(Vec3 point) {
      double dx = point.x - this.bot.getEyePosition().x;
      double dy = point.y - this.bot.getEyeY();
      double dz = point.z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = horiz > 0.05 ? (float)(-Math.toDegrees(Math.atan2(dy, horiz))) : -24.0F;
      this.bot.setYRot(yaw);
      this.bot.setXRot(pitch);
      this.bot.yHeadRot = yaw;
   }

   private static boolean isSolidAt(Level level, BlockPos pos) {
      return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
   }

   private int findWaterBucket() {
      for(int i = 0; i < 36; ++i) {
         if (this.bot.getInventory().getItem(i).is(Items.WATER_BUCKET)) {
            return i;
         }
      }

      return -1;
   }

   private int findPearl() {
      Inventory inv = this.bot.getInventory();

      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.ENDER_PEARL)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(Items.ENDER_PEARL)) {
            return i;
         }
      }

      return -1;
   }
}
