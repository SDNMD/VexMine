package vexbot.bot.ai;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.compat.McCompat;
import vexbot.util.InventoryUtils;

public final class WaterBucketClutchController {
   private static final float MIN_FALL_DIST = 4.0F;
   private static final int DEPLOY_HEIGHT = 2;
   private static final int MAX_DEPLOY_HEIGHT = 3;
   private static final int SCAN_DEPTH = 30;
   private static final int COLLECT_TIMEOUT = 60;
   private final ServerPlayer bot;
   private boolean rolledThisFall = false;
   private boolean willClutch = false;
   private int bucketSlot = -1;
   private int prevSelected = -1;
   private boolean collectingClutch = false;
   private BlockPos clutchWaterPos = null;
   private int clutchBucketSlot = -1;
   private int clutchTimer = 0;

   public WaterBucketClutchController(ServerPlayer bot) {
      this.bot = bot;
   }

   public boolean tick() {
      Inventory inv = this.bot.getInventory();
      if (this.bot.onGround()) {
         if (this.collectingClutch) {
            this.collectClutchWater(inv);
         } else if (this.willClutch) {
            this.restoreSlot(inv);
         }

         this.rolledThisFall = false;
         this.willClutch = false;
         this.bucketSlot = -1;
         return false;
      } else if (this.collectingClutch) {
         if (++this.clutchTimer >= 60) {
            this.collectClutchWater(inv);
         }

         return true;
      } else if (this.bot.isFallFlying()) {
         return false;
      } else if (this.bot.getDeltaMovement().y >= (double)0.0F) {
         return false;
      } else if (this.bot.fallDistance < (double)4.0F) {
         return false;
      } else {
         if (!this.rolledThisFall) {
            this.rolledThisFall = true;
            EffectiveSettings es = EffectiveSettings.of(this.bot.getScoreboardName());
            if (es.waterBucketClutch() && es.rollClutch()) {
               int slot = this.findWaterBucket(inv);
               if (slot >= 0) {
                  this.prevSelected = InventoryUtils.selected(inv);
                  this.bucketSlot = slot;
                  this.willClutch = true;
                  InventoryUtils.select(inv, slot);
               }
            }
         }

         if (!this.willClutch) {
            return false;
         } else {
            InventoryUtils.select(inv, this.bucketSlot);
            int deployAt = Math.max(2, Math.min(3, (int)Math.ceil(-this.bot.getDeltaMovement().y) + 1));
            if (this.blocksToGround() > deployAt) {
               return true;
            } else {
               this.deployWater(inv);
               return true;
            }
         }
      }
   }

   private void deployWater(Inventory inv) {
      if (!inv.getItem(this.bucketSlot).is(Items.WATER_BUCKET)) {
         this.willClutch = false;
         this.restoreSlot(inv);
      } else {
         this.bot.setXRot(90.0F);
         this.bot.yHeadRot = this.bot.getYRot();
         this.bot.gameMode.useItem(this.bot, this.bot.level(), inv.getItem(this.bucketSlot), InteractionHand.MAIN_HAND);
         McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
         this.clutchWaterPos = BlockPos.containing(this.bot.position());
         this.clutchBucketSlot = this.bucketSlot;
         this.collectingClutch = true;
         this.clutchTimer = 0;
         this.willClutch = false;
         VexBot.LOGGER.info("[VexBot] '{}' water bucket clutch! (difficulty: {})", this.bot.getScoreboardName(), EffectiveSettings.of(this.bot.getScoreboardName()).difficulty());
      }
   }

   private void collectClutchWater(Inventory inv) {
      Level level = this.bot.level();
      if (this.clutchWaterPos != null && this.clutchBucketSlot >= 0) {
         BlockPos waterAt = null;

         for(BlockPos candidate : new BlockPos[]{this.clutchWaterPos, this.clutchWaterPos.below()}) {
            if (level.getBlockState(candidate).is(Blocks.WATER)) {
               waterAt = candidate;
               break;
            }
         }

         int emptySlot = -1;

         for(int i = 0; i < 9; ++i) {
            if (inv.getItem(i).is(Items.BUCKET)) {
               emptySlot = i;
               break;
            }
         }

         if (waterAt != null && emptySlot >= 0) {
            int prevSel = InventoryUtils.selected(inv);
            InventoryUtils.select(inv, emptySlot);
            double dx = (double)waterAt.getX() + (double)0.5F - this.bot.getEyePosition().x;
            double dy = (double)waterAt.getY() + (double)0.5F - this.bot.getEyePosition().y;
            double dz = (double)waterAt.getZ() + (double)0.5F - this.bot.getEyePosition().z;
            double horiz = Math.sqrt(dx * dx + dz * dz);
            this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
            this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, horiz))));
            this.bot.yHeadRot = this.bot.getYRot();
            this.bot.gameMode.useItem(this.bot, level, inv.getItem(emptySlot), InteractionHand.MAIN_HAND);
            McCompat.swing(this.bot, InteractionHand.MAIN_HAND);
            InventoryUtils.select(inv, prevSel);
         }
      }

      this.restoreSlot(inv);
      this.collectingClutch = false;
      this.clutchWaterPos = null;
      this.clutchBucketSlot = -1;
      this.clutchTimer = 0;
   }

   public void suppressThisFall() {
      this.rolledThisFall = true;
      this.willClutch = false;
   }

   private void restoreSlot(Inventory inv) {
      if (this.prevSelected >= 0) {
         InventoryUtils.select(inv, this.prevSelected);
         this.prevSelected = -1;
      }

   }

   private int findWaterBucket(Inventory inv) {
      for(int i = 0; i < 9; ++i) {
         if (inv.getItem(i).is(Items.WATER_BUCKET)) {
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         if (inv.getItem(i).is(Items.WATER_BUCKET)) {
            return InventoryUtils.moveToHotbarSafe(inv, i);
         }
      }

      return -1;
   }

   private int blocksToGround() {
      BlockPos feet = BlockPos.containing(this.bot.position());
      Level level = this.bot.level();

      for(int i = 1; i <= 30; ++i) {
         BlockPos below = feet.below(i);
         if (!level.getBlockState(below).getCollisionShape(level, below).isEmpty()) {
            return i;
         }
      }

      return 30;
   }
}
