package vexbot.march;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import vexbot.bot.BotManager;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;
import vexbot.util.BotCommands;

public final class TeamSurround {
   public static final double DEFAULT_RADIUS = (double)8.0F;
   public static final double MIN_RADIUS = (double)4.0F;
   public static final double MAX_RADIUS = (double)32.0F;
   public static final double DEFAULT_ENGAGE = (double)4.0F;
   private static final double SLOT_ARRIVE = 1.2;
   private static final int HIT_TICKS = 20;
   private static final double ARC_STEP = Math.toRadians((double)40.0F);
   private static final Map<String, Surround> BY_TEAM = new ConcurrentHashMap();

   private TeamSurround() {
   }

   private static String key(String s) {
      return s.toLowerCase(Locale.ROOT);
   }

   public static Surround start(String teamName, String target, double radius, double engageDist) {
      Surround s = new Surround(teamName, target, radius, engageDist);
      BY_TEAM.put(key(teamName), s);
      return s;
   }

   public static Surround stop(String teamName) {
      return (Surround)BY_TEAM.remove(key(teamName));
   }

   public static Surround get(String teamName) {
      return (Surround)BY_TEAM.get(key(teamName));
   }

   private static Surround forBot(String botName) {
      if (BY_TEAM.isEmpty()) {
         return null;
      } else {
         TeamManager.BotTeam t = TeamManager.getTeamForBot(botName);
         return t == null ? null : (Surround)BY_TEAM.get(key(t.getName()));
      }
   }

   public static boolean tick(ServerPlayer bot, MinecraftServer server, Consumer<Vec3> chase) {
      if (BY_TEAM.isEmpty()) {
         return false;
      } else {
         String name = bot.getName().getString();
         Surround s = forBot(name);
         if (s == null) {
            return false;
         } else {
            ServerPlayer target = server.getPlayerList().getPlayerByName(s.target);
            if (target != null && target.isAlive() && !target.isSpectator()) {
               if (target.level() != bot.level()) {
                  return false;
               } else {
                  List<ServerPlayer> ring = liveRing(server, s, target);
                  if (ring.isEmpty()) {
                     return false;
                  } else {
                     if (!s.placed || !s.ring.contains(name)) {
                        place(s, ring, target);
                     }

                     int now = server.getTickCount();
                     if (s.checkedTick != now) {
                        s.checkedTick = now;

                        for(ServerPlayer m : ring) {
                           boolean close = s.settled.contains(m.getName().getString().toLowerCase(Locale.ROOT)) && (double)m.distanceTo(target) <= s.engageDist;
                           boolean hit = m.getLastHurtByMob() == target && m.tickCount - m.getLastHurtByMobTimestamp() <= 20;
                           if (close || hit) {
                              engage(server, s, ring, target, close ? "came too close" : "attacked");
                              return false;
                           }
                        }
                     }

                     LivingEntity hurtBy = bot.getLastHurtByMob();
                     if (hurtBy != null && hurtBy != target && hurtBy.isAlive() && bot.tickCount - bot.getLastHurtByMobTimestamp() <= 20) {
                        return false;
                     } else {
                        int i = 0;
                        int n = 0;
                        int mine = -1;

                        for(String member : s.ring) {
                           if (!ring.stream().noneMatch((p) -> p.getName().getString().equalsIgnoreCase(member))) {
                              if (member.equalsIgnoreCase(name)) {
                                 mine = i;
                              }

                              ++i;
                              ++n;
                           }
                        }

                        if (mine >= 0 && n != 0) {
                           double a = s.baseAngle + (Math.PI * 2D) * (double)mine / (double)n;
                           Vec3 spot = onRing(target, a, s.radius);
                           double dx = spot.x - bot.getX();
                           double dz = spot.z - bot.getZ();
                           double away = Math.sqrt(dx * dx + dz * dz);
                           if (away > 1.2) {
                              double cur = Math.atan2(bot.getZ() - target.getZ(), bot.getX() - target.getX());
                              double diff = Math.atan2(Math.sin(a - cur), Math.cos(a - cur));
                              Vec3 go = Math.abs(diff) > ARC_STEP ? onRing(target, cur + Math.copySign(ARC_STEP, diff), s.radius) : spot;
                              bot.setSprinting(away > (double)4.0F);
                              chase.accept(go);
                           } else {
                              s.settled.add(name.toLowerCase(Locale.ROOT));
                              BotCommands.stopMoving(server, name);
                              bot.setSprinting(false);
                              face(bot, target);
                           }

                           return true;
                        } else {
                           return false;
                        }
                     }
                  }
               }
            } else {
               BY_TEAM.remove(key(s.teamName));
               announce(server, "[VexBot] Team §e" + s.teamName + "§r stopped surrounding §e" + s.target + "§r — they're gone.");
               return false;
            }
         }
      }
   }

   private static Vec3 onRing(ServerPlayer target, double angle, double radius) {
      return new Vec3(target.getX() + Math.cos(angle) * radius, target.getY(), target.getZ() + Math.sin(angle) * radius);
   }

   private static List<ServerPlayer> liveRing(MinecraftServer server, Surround s, ServerPlayer target) {
      TeamManager.BotTeam team = TeamManager.get(s.teamName);
      List<ServerPlayer> out = new ArrayList();
      if (team == null) {
         return out;
      } else {
         for(String b : team.getBotNames()) {
            ServerPlayer p = server.getPlayerList().getPlayerByName(b);
            if (p != null && p.isAlive() && p.level() == target.level()) {
               out.add(p);
            }
         }

         return out;
      }
   }

   private static void place(Surround s, List<ServerPlayer> ring, ServerPlayer target) {
      List<ServerPlayer> sorted = new ArrayList(ring);
      sorted.sort(Comparator.comparingDouble((px) -> bearing(px, target)));
      s.ring.clear();

      for(ServerPlayer p : sorted) {
         s.ring.add(p.getName().getString());
      }

      s.baseAngle = sorted.isEmpty() ? (double)0.0F : bearing((ServerPlayer)sorted.get(0), target);
      s.placed = true;
   }

   private static double bearing(ServerPlayer p, ServerPlayer target) {
      return Math.atan2(p.getZ() - target.getZ(), p.getX() - target.getX());
   }

   private static void engage(MinecraftServer server, Surround s, List<ServerPlayer> ring, ServerPlayer target, String why) {
      BY_TEAM.remove(key(s.teamName));
      String t = target.getName().getString();

      for(ServerPlayer m : ring) {
         String b = m.getName().getString();
         if (!TeamManager.isAlliedWithBot(b, t)) {
            BotManager.setAttackTarget(b, t);
         }
      }

      announce(server, "[VexBot] §e" + t + "§r " + why + " — team §e" + s.teamName + "§r closes in.");
   }

   private static void face(ServerPlayer bot, ServerPlayer target) {
      double dx = target.getX() - bot.getX();
      double dz = target.getZ() - bot.getZ();
      double dy = target.getEyeY() - bot.getEyeY();
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
      bot.setYRot(yaw);
      bot.setXRot(pitch);
      bot.yHeadRot = yaw;
   }

   private static void announce(MinecraftServer server, String text) {
      server.getPlayerList().broadcastSystemMessage(VexText.literal(text), false);
   }

   public static final class Surround {
      public final String teamName;
      public final String target;
      public final double radius;
      public final double engageDist;
      final List<String> ring = new ArrayList();
      double baseAngle;
      boolean placed;
      final Set<String> settled = new HashSet();
      int checkedTick = -1;

      Surround(String teamName, String target, double radius, double engageDist) {
         this.teamName = teamName;
         this.target = target;
         this.radius = radius;
         this.engageDist = engageDist;
      }
   }
}
