package vexbot.march;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import vexbot.util.BotCommands;
import vexbot.util.InventoryUtils;

final class MarchTunneler {
   private static final double DIAGONAL_RATIO = 0.4;
   private static final int BLOCKED_TRIGGER_TICKS = 20;
   private static final double PROGRESS_EPS = 0.35;
   private static final int PER_BLOCK_TIMEOUT = 200;
   private static final int WALK_TICKS = 10;
   private static final int STUCK_TICKS = 400;
   private static final int REPLAN_COOLDOWN = 40;
   private static final int ABORT_COOLDOWN = 100;
   private final ServerPlayer bot;
   private final MinecraftServer server;
   private final String botName;
   private boolean active = false;
   private Mode mode;
   private final ArrayDeque<BlockPos> cells;
   private final Set<BlockPos> required;
   private boolean stepUp;
   private int cellTicks;
   private int walkTicks;
   private int blockedTicks;
   private int cooldown;
   private int noProgress;
   private double lastDist;
   private double bestApproach;
   private double bestDist;
   private static final float HAND_MINABLE_HARDNESS = 1.0F;

   MarchTunneler(ServerPlayer bot, MinecraftServer server) {
      this.mode = MarchTunneler.Mode.MINING;
      this.cells = new ArrayDeque();
      this.required = new HashSet();
      this.stepUp = false;
      this.cellTicks = 0;
      this.walkTicks = 0;
      this.blockedTicks = 0;
      this.cooldown = 0;
      this.noProgress = 0;
      this.lastDist = Double.POSITIVE_INFINITY;
      this.bestApproach = Double.POSITIVE_INFINITY;
      this.bestDist = Double.POSITIVE_INFINITY;
      this.bot = bot;
      this.server = server;
      this.botName = bot.getScoreboardName();
   }

   boolean isActive() {
      return this.active;
   }

   boolean isFor(ServerPlayer p) {
      return this.bot == p;
   }

   void reset() {
      if (this.active) {
         BotCommands.stopMining(this.server, this.botName);
         BotCommands.stopMoving(this.server, this.botName);
      }

      this.active = false;
      this.cells.clear();
      this.required.clear();
      this.cellTicks = this.walkTicks = this.blockedTicks = this.noProgress = 0;
      this.lastDist = this.bestDist = this.bestApproach = Double.POSITIVE_INFINITY;
   }

   boolean tick(Vec3 dest, double destDist) {
      if (this.cooldown > 0) {
         --this.cooldown;
      }

      double digDist = this.bot.position().distanceTo(dest);
      if (!this.active) {
         if (destDist < this.bestApproach - 0.35) {
            this.bestApproach = destDist;
            this.blockedTicks = 0;
         } else if (this.bot.onGround()) {
            ++this.blockedTicks;
         }

         this.lastDist = destDist;
         if (this.cooldown > 0 || this.blockedTicks < 20) {
            return false;
         }

         if (!this.planStep(dest)) {
            this.blockedTicks = 0;
            return false;
         }

         this.active = true;
         this.mode = MarchTunneler.Mode.MINING;
         this.bestDist = digDist;
         this.noProgress = 0;
      }

      if (digDist < this.bestDist - (double)0.5F) {
         this.bestDist = digDist;
         this.noProgress = 0;
      } else if (++this.noProgress > 400) {
         this.abort();
         return false;
      }

      return this.mode == MarchTunneler.Mode.MINING ? this.tickMining(dest) : this.tickWalking(dest);
   }

   private boolean tickMining(Vec3 dest) {
      Level level;
      for(level = this.bot.level(); !this.cells.isEmpty() && !this.needsMining(level, (BlockPos)this.cells.peekFirst()); this.cellTicks = 0) {
         this.cells.pollFirst();
      }

      if (this.cells.isEmpty()) {
         BotCommands.stopMining(this.server, this.botName);
         this.mode = MarchTunneler.Mode.WALKING;
         this.walkTicks = 0;
         return true;
      } else {
         BlockPos cell = (BlockPos)this.cells.peekFirst();
         BlockState state = level.getBlockState(cell);
         if (state.getDestroySpeed(level, cell) < 0.0F) {
            this.abort();
            return false;
         } else if (!this.canBreak(level, cell)) {
            this.abort();
            return false;
         } else {
            BotCommands.stopMoving(this.server, this.botName);
            this.bot.setSprinting(false);
            Inventory inv = this.bot.getInventory();
            int toolSlot = this.bestToolSlot(state);
            if (toolSlot >= 0) {
               InventoryUtils.select(inv, InventoryUtils.moveToHotbarSafe(inv, toolSlot));
            }

            this.faceBlock(cell);
            BotCommands.mineContinuous(this.server, this.botName);
            if (++this.cellTicks > 200) {
               this.abort();
               return false;
            } else {
               return true;
            }
         }
      }
   }

   private boolean tickWalking(Vec3 dest) {
      this.faceGoal(dest);
      BotCommands.setMovement(this.server, this.botName, 1.0F, 0.0F);
      if (this.stepUp && this.bot.onGround()) {
         BotCommands.jumpOnce(this.server, this.botName);
      }

      if (++this.walkTicks >= 10) {
         BotCommands.stopMoving(this.server, this.botName);
         if (!this.planStep(dest)) {
            this.reset();
            this.cooldown = 40;
            return false;
         }

         this.mode = MarchTunneler.Mode.MINING;
      }

      return true;
   }

   private boolean planStep(Vec3 dest) {
      Level level = this.bot.level();
      BlockPos feet = this.bot.blockPosition();
      double dx = dest.x - this.bot.getX();
      double dz = dest.z - this.bot.getZ();
      double dy = dest.y - this.bot.getY();
      this.stepUp = dy > (double)1.5F;
      boolean stepDown = dy < -0.9;
      Direction major = Math.abs(dx) >= Math.abs(dz) ? (dx > (double)0.0F ? Direction.EAST : Direction.WEST) : (dz > (double)0.0F ? Direction.SOUTH : Direction.NORTH);
      Direction minor = Math.abs(dx) >= Math.abs(dz) ? (dz > (double)0.0F ? Direction.SOUTH : Direction.NORTH) : (dx > (double)0.0F ? Direction.EAST : Direction.WEST);
      double major0 = Math.max(Math.abs(dx), Math.abs(dz));
      double minor0 = Math.min(Math.abs(dx), Math.abs(dz));
      boolean diagonal = major0 > 0.001 && minor0 / major0 >= 0.4;
      BlockPos ahead = diagonal ? feet.relative(major).relative(minor) : feet.relative(major);
      Direction wide = diagonal ? major.getOpposite() : minor;
      this.cells.clear();
      this.required.clear();
      if (this.stepUp) {
         this.addRequired(level, feet.above(2));
         this.addRequired(level, ahead.above(1));
         this.addRequired(level, ahead.above(2));
         this.addOptional(level, ahead.relative(wide).above(1));
         this.addOptional(level, ahead.relative(wide).above(2));
      } else if (stepDown) {
         this.addRequired(level, ahead.above(1));
         this.addRequired(level, ahead);
         this.addRequired(level, ahead.below());
         this.addOptional(level, ahead.relative(wide));
         this.addOptional(level, ahead.relative(wide).above(1));
         this.addOptional(level, ahead.relative(wide).below());
      } else {
         this.addRequired(level, ahead.above(1));
         this.addRequired(level, ahead);
         this.addOptional(level, ahead.relative(wide));
         this.addOptional(level, ahead.relative(wide).above(1));
      }

      boolean sinkStraight = stepDown && (major0 < (double)3.0F || Math.abs(dy) > major0);
      if (sinkStraight) {
         this.cells.clear();
         this.required.clear();
         this.addRequired(level, feet.below());
         this.addOptional(level, feet.below().relative(major));
      }

      if (diagonal && !sinkStraight) {
         this.addRequired(level, feet.relative(major));
         this.addRequired(level, feet.relative(major).above(1));
         this.addRequired(level, feet.relative(minor));
         this.addRequired(level, feet.relative(minor).above(1));
      }

      this.cellTicks = 0;
      if (this.cells.isEmpty()) {
         return false;
      } else {
         this.cells.removeIf((cx) -> !this.required.contains(cx) && !this.canMine(level, cx));

         for(BlockPos c : this.required) {
            if (!this.canMine(level, c)) {
               return false;
            }
         }

         return !this.cells.isEmpty();
      }
   }

   private boolean canMine(Level level, BlockPos p) {
      return this.canBreak(level, p);
   }

   private void addRequired(Level level, BlockPos p) {
      if (this.needsMining(level, p)) {
         this.cells.addLast(p);
         this.required.add(p);
      }
   }

   private void addOptional(Level level, BlockPos p) {
      if (this.needsMining(level, p)) {
         this.cells.addLast(p);
      }

   }

   private boolean needsMining(Level level, BlockPos p) {
      BlockState s = level.getBlockState(p);
      return !s.isAir() && !s.getCollisionShape(level, p).isEmpty();
   }

   private boolean canBreak(Level level, BlockPos p) {
      BlockState st = level.getBlockState(p);
      float hardness = st.getDestroySpeed(level, p);
      if (hardness < 0.0F) {
         return false;
      } else if (this.bestToolSlot(st) >= 0) {
         return true;
      } else {
         return hardness <= 1.0F;
      }
   }

   private int bestToolSlot(BlockState state) {
      Inventory inv = this.bot.getInventory();
      int best = -1;
      float bestSpeed = 1.0F;

      for(int i = 0; i < 36; ++i) {
         ItemStack st = inv.getItem(i);
         if (!st.isEmpty()) {
            float sp = st.getDestroySpeed(state);
            if (sp > bestSpeed) {
               bestSpeed = sp;
               best = i;
            }
         }
      }

      return best;
   }

   private void abort() {
      this.reset();
      this.cooldown = 100;
   }

   private void faceBlock(BlockPos p) {
      Vec3 c = Vec3.atCenterOf(p);
      double dx = c.x - this.bot.getEyePosition().x;
      double dy = c.y - this.bot.getEyeY();
      double dz = c.z - this.bot.getEyePosition().z;
      double horiz = Math.sqrt(dx * dx + dz * dz);
      this.bot.setYRot((float)Math.toDegrees(Math.atan2(-dx, dz)));
      this.bot.setXRot((float)(-Math.toDegrees(Math.atan2(dy, Math.max(horiz, 0.001)))));
      this.bot.yHeadRot = this.bot.getYRot();
   }

   private void faceGoal(Vec3 dest) {
      double dx = dest.x - this.bot.getX();
      double dz = dest.z - this.bot.getZ();
      float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
      this.bot.setYRot(yaw);
      this.bot.yHeadRot = yaw;
      this.bot.setXRot(0.0F);
   }

   private static enum Mode {
      MINING,
      WALKING;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{MINING, WALKING};
      }
   }
}
