package vexbot.march;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;
import vexbot.bot.BotManager;
import vexbot.bot.ai.FollowFormation;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;
import vexbot.util.BotCommands;

public final class TeamMarch {
   private static final double FORWARD_PULL = (double)6.0F;
   private static final double SOLO_ARRIVE = 1.6;
   private static final double FORM_COLLAPSE_DIST = (double)10.0F;
   private static final double ARRIVE_TEAM = (double)4.0F;
   private static final double VERTICAL_ARRIVE = (double)2.0F;
   private static final double WALK_IN_DIST = (double)6.0F;
   private static final double PACK_SPREAD = (double)32.0F;
   private static final Map<String, March> MARCHES = new HashMap();
   private static final Map<String, March> SOLO = new HashMap();
   private static final Map<String, MarchTunneler> DIGGERS = new HashMap();
   private static final double SLOT_TOLERANCE = 1.6;
   private static final double FORMED_FRACTION = 0.8;

   private TeamMarch() {
   }

   private static String key(String s) {
      return s.toLowerCase(Locale.ROOT);
   }

   public static March start(TeamManager.BotTeam team, Destination dest, String dimension, FollowFormation.Type formation, int rowWidth, Arrival arrival) {
      List<String> order = new ArrayList(team.getBotNames());
      order.sort(String.CASE_INSENSITIVE_ORDER);
      March m = new March(team.getName(), dest, dimension, formation, rowWidth, order, arrival == null ? TeamMarch.Arrival.hold() : arrival);
      MARCHES.put(key(team.getName()), m);
      return m;
   }

   public static March startSolo(String botName, Destination dest, String dimension, Arrival arrival) {
      March m = new March(botName, dest, dimension, FollowFormation.Type.NONE, 0, List.of(botName), arrival == null ? TeamMarch.Arrival.hold() : arrival);
      SOLO.put(key(botName), m);
      return m;
   }

   public static March stopSolo(String botName) {
      March m = (March)SOLO.remove(key(botName));
      MarchTunneler d = (MarchTunneler)DIGGERS.remove(key(botName));
      if (d != null) {
         d.reset();
      }

      return m;
   }

   public static March getSolo(String botName) {
      return (March)SOLO.get(key(botName));
   }

   public static March stop(String teamName) {
      March m = (March)MARCHES.remove(key(teamName));
      if (m != null) {
         for(String bot : m.order) {
            MarchTunneler d = (MarchTunneler)DIGGERS.remove(key(bot));
            if (d != null) {
               d.reset();
            }
         }
      }

      return m;
   }

   public static March get(String teamName) {
      pruneDeadTeams();
      return (March)MARCHES.get(key(teamName));
   }

   public static boolean any() {
      return !MARCHES.isEmpty();
   }

   public static List<March> all() {
      pruneDeadTeams();
      return new ArrayList(MARCHES.values());
   }

   public static boolean tick(ServerPlayer bot, MinecraftServer server, Consumer<Vec3> chase) {
      if (MARCHES.isEmpty() && SOLO.isEmpty()) {
         if (!DIGGERS.isEmpty()) {
            releaseDigger(bot.getName().getString());
         }

         return false;
      } else {
         String botName = bot.getName().getString();
         March m = marchFor(botName);
         if (m != null && !m.arrived) {
            if (!bot.level().dimension().identifier().toString().equals(m.dimension)) {
               releaseDigger(botName);
               return false;
            } else {
               TeamView v = teamView(server, m);
               if (v == null) {
                  releaseDigger(botName);
                  return false;
               } else {
                  Vec3 dest = v.dest();
                  List<ServerPlayer> marchers = v.marchers();
                  Vec3 centre = v.centre();
                  double teamToDest = v.teamToDest();
                  ServerPlayer destPlayer = v.destPlayer();
                  boolean canReach = destPlayer == null || bot.hasLineOfSight(destPlayer);
                  boolean teamCanReach = v.teamCanReach();
                  Vec3 heading = v.heading();
                  float yaw = v.yaw();
                  boolean centred = v.centred();
                  float shapeYaw = v.shapeYaw();
                  boolean atDest = v.atDest();
                  if (atDest && teamCanReach) {
                     m.arrived = true;

                     for(ServerPlayer p : marchers) {
                        String n = p.getName().getString();
                        BotCommands.stopMoving(server, n);
                        MarchTunneler d = (MarchTunneler)DIGGERS.remove(key(n));
                        if (d != null) {
                           d.reset();
                        }
                     }

                     fireArrival(server, m);
                     if (m.order.size() == 1) {
                        SOLO.remove(key((String)m.order.get(0)));
                     }

                     return true;
                  } else {
                     double lead = Math.min(deepestSlot(m) + (double)6.0F, teamToDest);
                     Vec3 anchor = centre.add(heading.scale(lead));
                     int slot = slotOf(m, botName);
                     if (slot < 0) {
                        releaseDigger(botName);
                        return false;
                     } else {
                        Vec3 goal = m.formation == FollowFormation.Type.NONE ? dest : FollowFormation.slotWorld(m.formation, slot, m.order.size(), m.rowWidth, centred ? dest : anchor, centred ? shapeYaw : yaw);
                        if (!centred && teamToDest < (double)10.0F) {
                           double keep = teamToDest / (double)10.0F;
                           goal = new Vec3(dest.x + (goal.x - dest.x) * keep, goal.y, dest.z + (goal.z - dest.z) * keep);
                        }

                        goal = new Vec3(goal.x, dest.y, goal.z);
                        double myDist = horiz(bot.position(), dest);
                        boolean above = !m.destination.isPlayer() && bot.getY() - dest.y > (double)2.0F;
                        if (!BotSettings.gotoMining) {
                           releaseDigger(bot.getScoreboardName());
                        } else if ((myDist > arriveRadius(m) || !canReach || above) && digger(bot, server).tick(dest, myDist)) {
                           return true;
                        }

                        chase.accept(goal);
                        bot.setSprinting(teamToDest > (double)6.0F);
                        return true;
                     }
                  }
               }
            }
         } else {
            releaseDigger(botName);
            return false;
         }
      }
   }

   private static TeamView teamView(MinecraftServer server, March m) {
      int now = server.getTickCount();
      if (m.viewTick == now) {
         return m.view;
      } else {
         m.viewTick = now;
         m.view = null;
         Vec3 dest = destinationPos(server, m);
         if (dest == null) {
            return null;
         } else {
            List<ServerPlayer> marchers = liveMarchers(server, m);
            if (marchers.isEmpty()) {
               return null;
            } else {
               Vec3 centre = packCentre(marchers, dest);
               double teamToDest = horiz(centre, dest);
               ServerPlayer destPlayer = m.destination.isPlayer() ? findPlayer(server, m.destination.playerName()) : null;
               boolean teamCanReach = destPlayer == null;
               if (destPlayer != null) {
                  for(ServerPlayer p : marchers) {
                     if (p.hasLineOfSight(destPlayer)) {
                        teamCanReach = true;
                        break;
                     }
                  }
               }

               Vec3 toDest = dest.subtract(centre);
               double flat = Math.sqrt(toDest.x * toDest.x + toDest.z * toDest.z);
               Vec3 heading = flat < 0.001 ? new Vec3((double)0.0F, (double)0.0F, (double)1.0F) : new Vec3(toDest.x / flat, (double)0.0F, toDest.z / flat);
               float yaw = (float)Math.toDegrees(Math.atan2(-heading.x, heading.z));
               boolean centred = FollowFormation.isCentred(m.formation);
               float shapeYaw = FollowFormation.worldAligned(m.formation) ? 0.0F : yaw;
               boolean atDest = centred ? formedUp(marchers, m, dest, shapeYaw) : teamToDest <= arriveRadius(m);
               if (!m.destination.isPlayer() && centre.y - dest.y > (double)2.0F) {
                  atDest = false;
               }

               m.view = new TeamView(dest, marchers, centre, teamToDest, destPlayer, teamCanReach, heading, yaw, centred, shapeYaw, atDest);
               return m.view;
            }
         }
      }
   }

   private static void releaseDigger(String botName) {
      if (!DIGGERS.isEmpty()) {
         MarchTunneler d = (MarchTunneler)DIGGERS.remove(key(botName));
         if (d != null) {
            d.reset();
         }

      }
   }

   private static March marchFor(String botName) {
      March solo = (March)SOLO.get(key(botName));
      if (solo != null) {
         return solo;
      } else {
         TeamManager.BotTeam team = TeamManager.getTeamForBot(botName);
         return team == null ? null : (March)MARCHES.get(key(team.getName()));
      }
   }

   public static boolean hasOrder(String botName) {
      if (MARCHES.isEmpty() && SOLO.isEmpty()) {
         return false;
      } else {
         March m = marchFor(botName);
         return m != null && !m.arrived;
      }
   }

   public static Vec3 destinationPos(MinecraftServer server, March m) {
      if (!m.destination.isPlayer()) {
         return m.destination.pos();
      } else {
         ServerPlayer p = findPlayer(server, m.destination.playerName());
         if (p == null) {
            return null;
         } else {
            return !p.level().dimension().identifier().toString().equals(m.dimension) ? null : p.position();
         }
      }
   }

   private static List<ServerPlayer> liveMarchers(MinecraftServer server, March m) {
      List<ServerPlayer> out = new ArrayList(m.order.size());

      for(String n : m.order) {
         ServerPlayer p = findPlayer(server, n);
         if (p != null && p.isAlive() && marchFor(n) == m && p.level().dimension().identifier().toString().equals(m.dimension)) {
            out.add(p);
         }
      }

      return out;
   }

   private static int slotOf(March m, String botName) {
      if (m.slotIndex == null) {
         Map<String, Integer> idx = new HashMap();
         boolean ascii = true;

         for(int i = 0; i < m.order.size(); ++i) {
            String n = (String)m.order.get(i);
            if (!isAscii(n)) {
               ascii = false;
               break;
            }

            idx.putIfAbsent(n.toLowerCase(Locale.ROOT), i);
         }

         m.slotIndex = idx;
         m.slotIndexAscii = ascii;
      }

      if (m.slotIndexAscii && isAscii(botName)) {
         Integer i = (Integer)m.slotIndex.get(botName.toLowerCase(Locale.ROOT));
         return i != null ? i : -1;
      } else {
         for(int i = 0; i < m.order.size(); ++i) {
            if (((String)m.order.get(i)).equalsIgnoreCase(botName)) {
               return i;
            }
         }

         return -1;
      }
   }

   private static boolean isAscii(String s) {
      for(int i = 0; i < s.length(); ++i) {
         if (s.charAt(i) >= 128) {
            return false;
         }
      }

      return true;
   }

   private static ServerPlayer findPlayer(MinecraftServer server, String name) {
      ServerPlayer exact = server.getPlayerList().getPlayerByName(name);
      if (exact != null) {
         return exact;
      } else {
         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.getName().getString().equalsIgnoreCase(name)) {
               return p;
            }
         }

         return null;
      }
   }

   private static void fireArrival(MinecraftServer server, March m) {
      if (m.arrival != null && m.arrival.kind() != TeamMarch.Arrival.Kind.HOLD) {
         if (m.arrival.kind() == TeamMarch.Arrival.Kind.ATTACK) {
            String target = m.arrival.target();

            for(String bot : m.order) {
               if (marchFor(bot) == m && !TeamManager.isAlliedWithBot(bot, target)) {
                  BotManager.setAttackTarget(bot, target);
               }
            }

            server.getPlayerList().broadcastSystemMessage(VexText.literal("[VexBot] Team §e" + m.teamName + "§r arrived — attacking §e" + target + "§r."), false);
         }

      }
   }

   private static boolean formedUp(List<ServerPlayer> marchers, March m, Vec3 dest, float yaw) {
      if (marchers.isEmpty()) {
         return false;
      } else {
         int inPlace = 0;

         for(ServerPlayer p : marchers) {
            int slot = slotOf(m, p.getName().getString());
            if (slot >= 0) {
               Vec3 want = FollowFormation.slotWorld(m.formation, slot, m.order.size(), m.rowWidth, dest, yaw);
               if (horiz(p.position(), want) <= 1.6) {
                  ++inPlace;
               }
            }
         }

         return inPlace >= Math.max(1, (int)Math.ceil((double)marchers.size() * 0.8));
      }
   }

   private static double deepestSlot(March m) {
      if (!Double.isNaN(m.deepest)) {
         return m.deepest;
      } else {
         double deepest = (double)0.0F;
         int n = Math.max(1, m.order.size());

         for(int i = 0; i < n; ++i) {
            double back = FollowFormation.localOffset(m.formation, i, n, m.rowWidth)[0];
            if (back > deepest) {
               deepest = back;
            }
         }

         m.deepest = deepest;
         return deepest;
      }
   }

   private static MarchTunneler digger(ServerPlayer bot, MinecraftServer server) {
      String k = key(bot.getName().getString());
      MarchTunneler d = (MarchTunneler)DIGGERS.get(k);
      if (d == null || !d.isFor(bot)) {
         d = new MarchTunneler(bot, server);
         DIGGERS.put(k, d);
      }

      return d;
   }

   private static double arriveRadius(March m) {
      return Math.max(1.6, Math.min((double)4.0F, (double)1.0F + 0.6 * (double)m.order.size()));
   }

   private static double horiz(Vec3 a, Vec3 b) {
      double dx = a.x - b.x;
      double dz = a.z - b.z;
      return Math.sqrt(dx * dx + dz * dz);
   }

   private static Vec3 packCentre(List<ServerPlayer> marchers, Vec3 dest) {
      ServerPlayer front = null;
      double best = Double.POSITIVE_INFINITY;

      for(ServerPlayer p : marchers) {
         double d = horiz(p.position(), dest);
         if (d < best) {
            best = d;
            front = p;
         }
      }

      if (front == null) {
         return dest;
      } else {
         double x = (double)0.0F;
         double y = (double)0.0F;
         double z = (double)0.0F;
         int n = 0;

         for(ServerPlayer p : marchers) {
            if (!(horiz(p.position(), front.position()) > (double)32.0F)) {
               x += p.getX();
               y += p.getY();
               z += p.getZ();
               ++n;
            }
         }

         return new Vec3(x / (double)n, y / (double)n, z / (double)n);
      }
   }

   public static void pruneDeadTeams() {
      for(String k : new ArrayList(MARCHES.keySet())) {
         if (!teamExists(k)) {
            stop(k);
         }
      }

   }

   private static boolean teamExists(String name) {
      if (TeamManager.get(name) != null) {
         return true;
      } else {
         for(String tn : TeamManager.teamNames()) {
            if (tn.equalsIgnoreCase(name)) {
               return true;
            }
         }

         return false;
      }
   }

   public static record Destination(Vec3 pos, String playerName) {
      public static Destination at(Vec3 pos) {
         return new Destination(pos, (String)null);
      }

      public static Destination following(String name) {
         return new Destination((Vec3)null, name);
      }

      public boolean isPlayer() {
         return this.playerName != null;
      }
   }

   public static record Arrival(Kind kind, String target) {
      public static Arrival hold() {
         return new Arrival(TeamMarch.Arrival.Kind.HOLD, (String)null);
      }

      public static Arrival attack(String target) {
         return new Arrival(TeamMarch.Arrival.Kind.ATTACK, target);
      }

      public static enum Kind {
         HOLD,
         ATTACK;

         // $FF: synthetic method
         private static Kind[] $values() {
            return new Kind[]{HOLD, ATTACK};
         }
      }
   }

   public static final class March {
      public final String teamName;
      public final Destination destination;
      public final String dimension;
      public final FollowFormation.Type formation;
      public final int rowWidth;
      public final List<String> order;
      public final Arrival arrival;
      public boolean arrived = false;
      private double deepest = Double.NaN;
      private Map<String, Integer> slotIndex;
      private boolean slotIndexAscii;
      private int viewTick = Integer.MIN_VALUE;
      private TeamView view;

      March(String teamName, Destination destination, String dimension, FollowFormation.Type formation, int rowWidth, List<String> order, Arrival arrival) {
         this.arrival = arrival;
         this.teamName = teamName;
         this.destination = destination;
         this.dimension = dimension;
         this.formation = formation;
         this.rowWidth = rowWidth;
         this.order = order;
      }
   }

   private static record TeamView(Vec3 dest, List<ServerPlayer> marchers, Vec3 centre, double teamToDest, ServerPlayer destPlayer, boolean teamCanReach, Vec3 heading, float yaw, boolean centred, float shapeYaw, boolean atDest) {
   }
}
