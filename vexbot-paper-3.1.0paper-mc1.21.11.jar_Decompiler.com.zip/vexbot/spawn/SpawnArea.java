package vexbot.spawn;

import java.util.Locale;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import vexbot.BotSettings;

public final class SpawnArea {
   private static final Random RNG = new Random();
   private static final int PLACEMENT_TRIES = 24;

   private SpawnArea() {
   }

   public static boolean isSet() {
      return BotSettings.spawnAreaDim != null && !BotSettings.spawnAreaDim.isBlank();
   }

   public static void clear() {
      BotSettings.spawnAreaDim = null;
   }

   public static void set(String dimensionId, Vec3 a, Vec3 b) {
      BotSettings.spawnAreaDim = dimensionId;
      BotSettings.spawnAreaX1 = Math.min(a.x, b.x);
      BotSettings.spawnAreaY1 = Math.min(a.y, b.y);
      BotSettings.spawnAreaZ1 = Math.min(a.z, b.z);
      BotSettings.spawnAreaX2 = Math.max(a.x, b.x);
      BotSettings.spawnAreaY2 = Math.max(a.y, b.y);
      BotSettings.spawnAreaZ2 = Math.max(a.z, b.z);
   }

   public static String dimensionId() {
      return BotSettings.spawnAreaDim;
   }

   public static String describe() {
      return !isSet() ? "not set" : String.format(Locale.ROOT, "%.0f %.0f %.0f to %.0f %.0f %.0f in %s", BotSettings.spawnAreaX1, BotSettings.spawnAreaY1, BotSettings.spawnAreaZ1, BotSettings.spawnAreaX2, BotSettings.spawnAreaY2, BotSettings.spawnAreaZ2, BotSettings.spawnAreaDim);
   }

   public static ServerLevel level(MinecraftServer server) {
      if (!isSet()) {
         return null;
      } else {
         Identifier id = Identifier.tryParse(BotSettings.spawnAreaDim);
         return id == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
      }
   }

   public static Vec3 randomSpot(MinecraftServer server) {
      ServerLevel level = level(server);
      if (level == null) {
         return null;
      } else {
         int yTop = (int)Math.floor(BotSettings.spawnAreaY2);
         int yBottom = (int)Math.floor(BotSettings.spawnAreaY1);

         for(int attempt = 0; attempt < 24; ++attempt) {
            double x = lerp(BotSettings.spawnAreaX1, BotSettings.spawnAreaX2, RNG.nextDouble());
            double z = lerp(BotSettings.spawnAreaZ1, BotSettings.spawnAreaZ2, RNG.nextDouble());
            BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

            for(int y = yTop; y >= yBottom; --y) {
               p.set((int)Math.floor(x), y, (int)Math.floor(z));
               if (standable(level, p)) {
                  return new Vec3(Math.floor(x) + (double)0.5F, (double)y, Math.floor(z) + (double)0.5F);
               }
            }
         }

         return new Vec3((BotSettings.spawnAreaX1 + BotSettings.spawnAreaX2) / (double)2.0F, BotSettings.spawnAreaY2, (BotSettings.spawnAreaZ1 + BotSettings.spawnAreaZ2) / (double)2.0F);
      }
   }

   private static boolean standable(Level level, BlockPos.MutableBlockPos p) {
      int x = p.getX();
      int y = p.getY();
      int z = p.getZ();
      if (!level.getBlockState(p.set(x, y, z)).isAir()) {
         return false;
      } else if (!level.getBlockState(p.set(x, y + 1, z)).isAir()) {
         return false;
      } else {
         BlockState below = level.getBlockState(p.set(x, y - 1, z));
         p.set(x, y, z);
         return !below.isAir() && !below.liquid();
      }
   }

   private static double lerp(double a, double b, double t) {
      return a + (b - a) * t;
   }
}
