package vexbot.name;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import net.minecraft.server.MinecraftServer;
import vexbot.bot.BotManager;

public final class NamePoolShare {
   public static final String PREFIX = "VBN1:";
   private static final int MAX_NAMES = 20000;
   private static final int MAX_BYTES = 1048576;

   private NamePoolShare() {
   }

   public static String encode(String pool, List<String> names) {
      JsonObject o = new JsonObject();
      o.addProperty("name", pool);
      JsonArray arr = new JsonArray();

      for(String n : names) {
         arr.add(n);
      }

      o.add("names", arr);
      byte[] raw = o.toString().getBytes(StandardCharsets.UTF_8);
      ByteArrayOutputStream out = new ByteArrayOutputStream(raw.length / 2 + 16);
      Deflater d = new Deflater(9);

      Object var8;
      try {
         DeflaterOutputStream def = new DeflaterOutputStream(out, d);

         try {
            def.write(raw);
         } catch (Throwable var16) {
            try {
               def.close();
            } catch (Throwable var15) {
               var16.addSuppressed(var15);
            }

            throw var16;
         }

         def.close();
         return "VBN1:" + Base64.getUrlEncoder().withoutPadding().encodeToString(out.toByteArray());
      } catch (Exception var17) {
         var8 = null;
      } finally {
         d.end();
      }

      return (String)var8;
   }

   public static Shared decode(String rawId) {
      String id = rawId == null ? "" : rawId.strip();
      if (!id.regionMatches(true, 0, "VBN1:", 0, "VBN1:".length())) {
         throw new IllegalArgumentException("Not a VexBot name pool ID (they start with VBN1:).");
      } else {
         byte[] json;
         try {
            byte[] packed = Base64.getUrlDecoder().decode(id.substring("VBN1:".length()).replaceAll("\\s+", ""));
            InflaterInputStream in = new InflaterInputStream(new ByteArrayInputStream(packed));

            try {
               json = in.readNBytes(1048577);
            } catch (Throwable var9) {
               try {
                  in.close();
               } catch (Throwable var8) {
                  var9.addSuppressed(var8);
               }

               throw var9;
            }

            in.close();
         } catch (Exception var10) {
            throw new IllegalArgumentException("Could not read the name pool ID — it may be cut off or corrupted.");
         }

         if (json.length > 1048576) {
            throw new IllegalArgumentException("That name pool ID is too big.");
         } else {
            List<String> names = new ArrayList();

            String name;
            try {
               JsonObject o = JsonParser.parseString(new String(json, StandardCharsets.UTF_8)).getAsJsonObject();
               name = o.has("name") ? o.get("name").getAsString() : "imported";

               for(JsonElement el : o.getAsJsonArray("names")) {
                  names.add(el.getAsString().strip());
               }
            } catch (Exception var11) {
               throw new IllegalArgumentException("Could not read the name pool ID — it may be corrupted.");
            }

            names.removeIf(String::isEmpty);
            if (names.isEmpty()) {
               throw new IllegalArgumentException("That name pool ID has no names in it.");
            } else if (names.size() > 20000) {
               throw new IllegalArgumentException("That name pool has more than 20000 names.");
            } else {
               for(String n : names) {
                  String bad = BotManager.invalidBotNameReason(n);
                  if (bad != null) {
                     throw new IllegalArgumentException("The pool has an invalid name — " + bad + " Nothing was imported.");
                  }
               }

               return new Shared(cleanPoolName(name), List.copyOf(names));
            }
         }
      }
   }

   static String cleanPoolName(String s) {
      String c = s.replaceAll("[^A-Za-z0-9_-]", "_");
      if (c.length() > 32) {
         c = c.substring(0, 32);
      }

      return !c.isEmpty() && !c.chars().allMatch((ch) -> ch == 95) ? c : "imported";
   }

   public static String save(MinecraftServer server, Shared s) throws IOException {
      Path dir = NamePoolStorage.dir(server);
      String base = s.name();
      String name = base;
      int i = 2;

      while(true) {
         Path f = dir.resolve(name + ".json");
         if (!Files.exists(f, new LinkOption[0])) {
            StringBuilder sb = new StringBuilder("{\n  \"names\": [\n");

            for(int i = 0; i < s.names().size(); ++i) {
               sb.append("    ").append(new JsonPrimitive((String)s.names().get(i)));
               if (i < s.names().size() - 1) {
                  sb.append(',');
               }

               sb.append('\n');
            }

            sb.append("  ]\n}\n");
            Files.writeString(dir.resolve(name + ".json"), sb.toString());
            return name;
         }

         NamePoolStorage.LoadResult existing = NamePoolStorage.load(server, name);
         if (existing.ok() && existing.names().equals(s.names())) {
            return name;
         }

         if (i > 999) {
            throw new IOException("too many pools named " + base);
         }

         name = base + "_" + i;
         ++i;
      }
   }

   public static record Shared(String name, List<String> names) {
   }
}
