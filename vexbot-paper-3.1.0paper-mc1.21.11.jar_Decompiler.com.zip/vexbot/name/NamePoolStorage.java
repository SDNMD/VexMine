package vexbot.name;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;
import net.minecraft.server.MinecraftServer;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.command.BotNamePool;

public final class NamePoolStorage {
   public static final String DIR = "vexbot_namepools";
   public static final String STANDARD = "vexbot-standard-names";
   private static final Map<String, Cached> CACHE = new ConcurrentHashMap();

   private NamePoolStorage() {
   }

   private static String key(String s) {
      return s.toLowerCase(Locale.ROOT);
   }

   public static Path dir(MinecraftServer server) {
      Path dir = server.getServerDirectory().resolve("vexbot_namepools");

      try {
         Files.createDirectories(dir);
      } catch (Exception var3) {
      }

      return dir;
   }

   public static void ensureFolder(MinecraftServer server) {
      Path file = dir(server).resolve("vexbot-standard-names.json");
      if (!Files.exists(file, new LinkOption[0])) {
         try {
            StringBuilder sb = new StringBuilder("{\n  \"names\": [\n");
            String[] names = BotNamePool.NAMES;

            for(int i = 0; i < names.length; ++i) {
               sb.append("    \"").append(names[i]).append('"');
               if (i < names.length - 1) {
                  sb.append(',');
               }

               sb.append('\n');
            }

            sb.append("  ]\n}\n");
            Files.writeString(file, sb.toString());
            VexBot.LOGGER.info("[VexBot] wrote the standard name pool to {}/{}.json ({} names)", new Object[]{"vexbot_namepools", "vexbot-standard-names", names.length});
         } catch (Exception e) {
            VexBot.LOGGER.warn("[VexBot] could not write the standard name pool: {}", e.getMessage());
         }

      }
   }

   public static List<String> list(MinecraftServer server) {
      try {
         Stream<Path> s = Files.list(dir(server));

         List var2;
         try {
            var2 = s.map((p) -> p.getFileName().toString()).filter((n) -> n.toLowerCase(Locale.ROOT).endsWith(".json")).map((n) -> n.substring(0, n.length() - 5)).sorted().toList();
         } catch (Throwable var5) {
            if (s != null) {
               try {
                  s.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (s != null) {
            s.close();
         }

         return var2;
      } catch (Exception var6) {
         return List.of();
      }
   }

   public static LoadResult load(MinecraftServer server, String poolName) {
      if (poolName != null && !poolName.isBlank()) {
         Path file = dir(server).resolve(poolName + ".json");
         if (!Files.isRegularFile(file, new LinkOption[0])) {
            return new LoadResult(List.of(), "No pool '" + poolName + ".json' in vexbot_namepools/.");
         } else {
            try {
               long size = Files.size(file);
               long mod = Files.getLastModifiedTime(file).toMillis();
               Cached hit = (Cached)CACHE.get(key(poolName));
               if (hit != null && hit.size() == size && hit.modified() == mod) {
                  return new LoadResult(hit.names(), (String)null);
               } else {
                  List<String> raw = parse(Files.readString(file));
                  if (raw.isEmpty()) {
                     return new LoadResult(List.of(), "Pool '" + poolName + "' has no names in it.");
                  } else {
                     List<String> names = new ArrayList(raw.size());

                     for(String n : raw) {
                        String bad = BotManager.invalidBotNameReason(n);
                        if (bad != null) {
                           return new LoadResult(List.of(), "Pool '" + poolName + "' has an invalid name — " + bad + " The pool was NOT loaded.");
                        }

                        names.add(n.strip());
                     }

                     CACHE.put(key(poolName), new Cached(size, mod, List.copyOf(names)));
                     return new LoadResult(List.copyOf(names), (String)null);
                  }
               }
            } catch (Exception e) {
               return new LoadResult(List.of(), "Pool '" + poolName + "' could not be read: " + e.getMessage());
            }
         }
      } else {
         return new LoadResult(List.of(), "No name pool given.");
      }
   }

   private static List<String> parse(String text) {
      List<String> out = new ArrayList();
      String trimmed = text.strip();
      if (trimmed.isEmpty()) {
         return out;
      } else {
         try {
            JsonElement root = JsonParser.parseString(trimmed);
            if (root.isJsonArray()) {
               for(JsonElement el : root.getAsJsonArray()) {
                  addAll(out, el.getAsString());
               }

               return out;
            }

            if (root.isJsonObject()) {
               JsonObject o = root.getAsJsonObject();
               JsonElement names = o.has("names") ? o.get("names") : null;
               if (names == null) {
                  return out;
               }

               if (names.isJsonArray()) {
                  for(JsonElement el : names.getAsJsonArray()) {
                     addAll(out, el.getAsString());
                  }
               } else {
                  addAll(out, names.getAsString());
               }

               return out;
            }

            if (root.isJsonPrimitive()) {
               addAll(out, root.getAsString());
               return out;
            }
         } catch (Exception var8) {
         }

         addAll(out, trimmed);
         return out;
      }
   }

   private static void addAll(List<String> out, String commaSeparated) {
      if (commaSeparated != null) {
         for(String part : commaSeparated.split("[,\\n\\r]")) {
            String n = part.strip();
            if (!n.isEmpty()) {
               out.add(n);
            }
         }

      }
   }

   private static record Cached(long size, long modified, List<String> names) {
   }

   public static record LoadResult(List<String> names, String error) {
      public boolean ok() {
         return this.error == null;
      }
   }
}
