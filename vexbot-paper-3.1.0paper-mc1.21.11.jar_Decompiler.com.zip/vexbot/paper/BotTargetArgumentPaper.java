package vexbot.paper;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.papermc.paper.command.brigadier.argument.CustomArgumentType;
import java.util.concurrent.CompletableFuture;
import vexbot.command.BotTargetArgument;

public final class BotTargetArgumentPaper implements CustomArgumentType.Converted<BotTargetArgument.Target, String> {
   private final BotTargetArgument inner = BotTargetArgument.raw();

   static void install() {
      BotTargetArgument.FACTORY = BotTargetArgumentPaper::new;
   }

   public BotTargetArgument.Target parse(StringReader reader) throws CommandSyntaxException {
      return this.inner.parse(reader);
   }

   public <S> BotTargetArgument.Target parse(StringReader reader, S source) throws CommandSyntaxException {
      return this.inner.parse(reader);
   }

   public BotTargetArgument.Target convert(String nativeType) throws CommandSyntaxException {
      return this.inner.parse(new StringReader(nativeType));
   }

   public ArgumentType<String> getNativeType() {
      return StringArgumentType.string();
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
      return this.inner.listSuggestions(context, builder);
   }
}
