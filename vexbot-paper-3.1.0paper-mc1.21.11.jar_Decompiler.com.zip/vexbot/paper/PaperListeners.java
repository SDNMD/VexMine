package vexbot.paper;

import com.destroystokyo.paper.event.entity.PlayerNaturallySpawnCreaturesEvent;
import io.papermc.paper.event.player.PlayerShieldDisableEvent;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.throwableitemprojectile.AbstractThrownPotion;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.vehicle.VehicleUpdateEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.projectiles.ProjectileSource;
import vexbot.BotSettings;
import vexbot.EffectiveSettings;
import vexbot.VexBot;
import vexbot.api.VexBotEvents;
import vexbot.bot.BotManager;
import vexbot.bot.loadout.RandomGearGenerator;
import vexbot.combat.CombatRecorder;
import vexbot.compat.McCompat;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.fakeplayer.bot.BotPlayerActionPack;
import vexbot.kit.KitManager;
import vexbot.kit.KitPotion;
import vexbot.platform.Internals;
import vexbot.stats.Stats;
import vexbot.util.BotIdentity;
import vexbot.util.ExplosionRules;

public final class PaperListeners implements Listener {
   private static final MethodHandle CONTROL_BOAT = findControlBoat();

   private PaperListeners() {
   }

   private static MethodHandle findControlBoat() {
      try {
         return MethodHandles.privateLookupIn(AbstractBoat.class, MethodHandles.lookup()).findVirtual(AbstractBoat.class, "controlBoat", MethodType.methodType(Void.TYPE));
      } catch (ReflectiveOperationException var1) {
         return null;
      }
   }

   static void register(JavaPlugin plugin) {
      Bukkit.getPluginManager().registerEvents(new PaperListeners(), plugin);
      Bukkit.getPluginManager().registerEvents(new PaperStatsListeners(), plugin);
   }

   private static ServerPlayer serverPlayer(Entity e) {
      ServerPlayer var10000;
      if (e instanceof Player p) {
         var10000 = ((CraftPlayer)p).getHandle();
      } else {
         var10000 = null;
      }

      return var10000;
   }

   private static boolean isBot(ServerPlayer sp) {
      return sp instanceof BotPlayer || McCompat.tags(sp).contains("vexbot");
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onDamage(EntityDamageByEntityEvent e) {
      ServerPlayer victim = serverPlayer(e.getEntity());
      if (victim != null) {
         ServerPlayer attacker = serverPlayer(e.getDamageSource().getCausingEntity());
         if (attacker != null && attacker.isAlive() && !attacker.isSpectator() && attacker != victim) {
            String victimName = victim.getName().getString();
            String attackerName = attacker.getName().getString();
            CombatRecorder.logHit(attacker, victim, (float)e.getDamage());
            if (isBot(victim)) {
               BotManager.notifyBotHurtBy(victimName, attackerName);
            }

            BotManager.notifyPlayerHurtBy(victimName, attackerName);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onNaturalSpawn(PlayerNaturallySpawnCreaturesEvent e) {
      if (!BotSettings.botSpawnMobs) {
         if (BotIdentity.isBot(((CraftPlayer)e.getPlayer()).getHandle())) {
            e.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onCrystalHit(EntityDamageByEntityEvent e) {
      Entity damager = e.getEntity();
      if (damager instanceof EnderCrystal crystal) {
         damager = e.getDamager();
         if (damager instanceof Projectile proj) {
            ProjectileSource var6 = proj.getShooter();
            if (var6 instanceof Entity shooter) {
               damager = shooter;
            }
         }

         if (damager instanceof Player p) {
            Location c = crystal.getLocation();
            ExplosionRules.note(((CraftPlayer)p).getHandle(), new Vec3(c.getX(), c.getY(), c.getZ()));
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onEntityExplode(EntityExplodeEvent e) {
      net.minecraft.world.entity.Entity direct = ((CraftEntity)e.getEntity()).getHandle();
      net.minecraft.world.entity.Entity indirect = null;
      Entity var5 = e.getEntity();
      if (var5 instanceof TNTPrimed tnt) {
         if (tnt.getSource() != null) {
            indirect = ((CraftEntity)tnt.getSource()).getHandle();
         }
      }

      ServerLevel level = ((CraftWorld)e.getLocation().getWorld()).getHandle();
      Location c = e.getLocation();
      if (!ExplosionRules.blocksAllowed(level, new Vec3(c.getX(), c.getY(), c.getZ()), direct, indirect, (DamageSource)null)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onBlockExplode(BlockExplodeEvent e) {
      Block b = e.getBlock();
      ServerLevel level = ((CraftWorld)b.getWorld()).getHandle();
      if (!ExplosionRules.blocksAllowed(level, new Vec3((double)b.getX() + (double)0.5F, (double)b.getY() + (double)0.5F, (double)b.getZ() + (double)0.5F), (net.minecraft.world.entity.Entity)null, (net.minecraft.world.entity.Entity)null, (DamageSource)null)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onDeath(PlayerDeathEvent e) {
      ServerPlayer victim = ((CraftPlayer)e.getEntity()).getHandle();
      ServerPlayer killer = serverPlayer(e.getDamageSource().getCausingEntity());
      if (killer == victim) {
         killer = null;
      }

      VexBotEvents.fireDeath(victim, killer);
      if (Stats.enabled()) {
         if (victim instanceof BotPlayer) {
            Stats.inc("bot_deaths");
         }

         if (killer instanceof BotPlayer) {
            Stats.kill(victim instanceof BotPlayer, true);
         }
      }

   }

   @EventHandler
   public void onVehicleUpdate(VehicleUpdateEvent e) {
      if (CONTROL_BOAT != null) {
         net.minecraft.world.entity.Entity var3 = ((CraftEntity)e.getVehicle()).getHandle();
         if (var3 instanceof AbstractBoat) {
            AbstractBoat boat = (AbstractBoat)var3;
            LivingEntity var4 = boat.getControllingPassenger();
            if (var4 instanceof BotPlayer) {
               BotPlayer bot = (BotPlayer)var4;
               BotPlayerActionPack ap = Internals.get().actionPack(bot);
               if (ap != null) {
                  float forward = ap.getForward();
                  float strafing = ap.getStrafing();
                  boat.setInput(strafing > 0.0F, strafing < 0.0F, forward > 0.0F, forward < 0.0F);

                  try {
                     CONTROL_BOAT.invoke(boat);
                  } catch (Throwable var8) {
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onKick(PlayerKickEvent e) {
      ServerPlayer var3 = ((CraftPlayer)e.getPlayer()).getHandle();
      if (var3 instanceof BotPlayer bot) {
         if (bot.botJoining) {
            VexBot.LOGGER.info("[VexBot] Ignored a join-time kick for bot '{}' — a plugin tried to kick it; keeping the bot.", bot.getGameProfile().name());
            e.setCancelled(true);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onTeleport(PlayerTeleportEvent e) {
      ServerPlayer var3 = ((CraftPlayer)e.getPlayer()).getHandle();
      if (var3 instanceof BotPlayer bot) {
         if (bot.getPathFollower() != null) {
            bot.getPathFollower().requestRecalc();
         }
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onPickup(EntityPickupItemEvent e) {
      org.bukkit.entity.LivingEntity var3 = e.getEntity();
      if (var3 instanceof Player p) {
         ServerPlayer sp = ((CraftPlayer)p).getHandle();
         if (isBot(sp)) {
            if (!EffectiveSettings.of(sp.getName().getString()).pickupLoot()) {
               e.setCancelled(true);
            }

         }
      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onShieldDisable(PlayerShieldDisableEvent e) {
      ServerPlayer sp = ((CraftPlayer)e.getPlayer()).getHandle();
      boolean fast = isBot(sp) ? EffectiveSettings.of(sp.getName().getString()).fastShieldCooldown() : BotSettings.fastShieldCooldown;
      if (fast) {
         e.setCooldown(e.getCooldown() / 2);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPotionSplash(PotionSplashEvent e) {
      if (BotSettings.kitPotionDoSplash) {
         net.minecraft.world.entity.Entity var3 = ((CraftEntity)e.getPotion()).getHandle();
         if (var3 instanceof AbstractThrownPotion) {
            AbstractThrownPotion potion = (AbstractThrownPotion)var3;
            String kitName = KitPotion.getKitName(potion.getItem());
            if (kitName != null) {
               MinecraftServer server = MinecraftServer.getServer();

               for(org.bukkit.entity.LivingEntity hit : e.getAffectedEntities()) {
                  ServerPlayer p = serverPlayer(hit);
                  if (p != null && p.isAlive() && !p.isSpectator() && KitManager.give(server, p, kitName)) {
                     p.sendSystemMessage(Component.literal("§aKit §e" + kitName + " §asplashed onto you!"));
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onBlockPlace(BlockPlaceEvent e) {
      if (e.canBuild()) {
         ItemStack stack = CraftItemStack.asNMSCopy(e.getItemInHand());
         if (!stack.isEmpty()) {
            CustomData data = (CustomData)stack.get(DataComponents.CUSTOM_DATA);
            if (data != null && data.copyTag().getBooleanOr("VexBotLootChest", false)) {
               Block placed = e.getBlockPlaced();
               ServerLevel level = ((CraftWorld)placed.getWorld()).getHandle();
               BlockPos pos = new BlockPos(placed.getX(), placed.getY(), placed.getZ());
               BlockEntity var8 = level.getBlockEntity(pos);
               if (var8 instanceof Container) {
                  Container container = (Container)var8;
                  RandomGearGenerator.populateFfaChest(container, level.registryAccess(), BotSettings.randomChestLootConfig, new Random());
                  ServerPlayer sp = ((CraftPlayer)e.getPlayer()).getHandle();
                  if (!sp.isCreative()) {
                     InteractionHand hand = e.getHand() == EquipmentSlot.OFF_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
                     MinecraftServer server = MinecraftServer.getServer();
                     server.schedule(new TickTask(server.getTickCount() + 1, () -> {
                        if (!sp.isRemoved()) {
                           ItemStack chest = RandomGearGenerator.makeLootChestItem();
                           if (sp.getItemInHand(hand).isEmpty()) {
                              sp.setItemInHand(hand, chest);
                           } else {
                              sp.getInventory().add(chest);
                           }

                           sp.containerMenu.broadcastChanges();
                        }
                     }));
                  }
               }
            }
         }
      }
   }
}
