package vexbot.paper;

import com.destroystokyo.paper.event.server.ServerTickEndEvent;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.LiteralCommandNode;
import io.papermc.paper.command.brigadier.Commands;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import vexbot.command.VexBotCommand;
import vexbot.platform.Platform;

public final class PaperPlatform implements Platform, Listener {
   private final JavaPlugin plugin;
   private final List<Consumer<MinecraftServer>> ticks = new ArrayList();
   private final List<Consumer<MinecraftServer>> starting = new ArrayList();
   private final List<Consumer<MinecraftServer>> started = new ArrayList();
   private final List<Consumer<MinecraftServer>> stopping = new ArrayList();
   private final List<Platform.AttackEntityHandler> attacks = new ArrayList();
   private final List<Platform.UseItemHandler> uses = new ArrayList();
   private final List<Platform.UseBlockHandler> blockUses = new ArrayList();
   private final List<Platform.InputInterceptor> inputs = new ArrayList();

   PaperPlatform(JavaPlugin plugin) {
      this.plugin = plugin;
      Bukkit.getPluginManager().registerEvents(this, plugin);
   }

   public String loaderName() {
      return "Paper";
   }

   public String modVersion() {
      return this.plugin.getPluginMeta().getVersion();
   }

   public boolean isClient() {
      return false;
   }

   public boolean isModLoaded(String modId) {
      String var10000;
      switch (modId) {
         case "luckperms" -> var10000 = "LuckPerms";
         default -> var10000 = modId;
      }

      String name = var10000;
      return Bukkit.getPluginManager().isPluginEnabled(name);
   }

   public Path configDir() {
      return this.plugin.getDataFolder().toPath();
   }

   public Path extensionsDir() {
      return this.plugin.getDataFolder().toPath().getParent();
   }

   public void onEndServerTick(Consumer<MinecraftServer> h) {
      this.ticks.add(h);
   }

   public void onServerStarting(Consumer<MinecraftServer> h) {
      this.starting.add(h);
   }

   public void onServerStarted(Consumer<MinecraftServer> h) {
      this.started.add(h);
   }

   public void onServerStopping(Consumer<MinecraftServer> h) {
      this.stopping.add(h);
   }

   public void onPlayerAttackEntity(Platform.AttackEntityHandler h) {
      this.attacks.add(h);
   }

   public void onPlayerUseItem(Platform.UseItemHandler h) {
      this.uses.add(h);
   }

   public void onPlayerUseBlock(Platform.UseBlockHandler h) {
      this.blockUses.add(h);
   }

   public void addInputInterceptor(Platform.InputInterceptor h) {
      this.inputs.add(h);
   }

   void fireStarting(MinecraftServer server) {
      this.starting.forEach((h) -> h.accept(server));
   }

   void fireStopping(MinecraftServer server) {
      this.stopping.forEach((h) -> h.accept(server));
   }

   public void registerCommands(Consumer<CommandDispatcher<CommandSourceStack>> registrar) {
      this.plugin.getLifecycleManager().registerEventHandler(LifecycleEvents.COMMANDS, (event) -> {
         LiteralCommandNode node = VexBotCommand.tree().build();
         ((Commands)event.registrar()).register(node, "VexBot", List.of());
      });
   }

   @EventHandler
   public void onTickEnd(ServerTickEndEvent e) {
      MinecraftServer server = MinecraftServer.getServer();

      for(Consumer<MinecraftServer> h : this.ticks) {
         h.accept(server);
      }

   }

   @EventHandler
   public void onLoad(ServerLoadEvent e) {
      MinecraftServer server = MinecraftServer.getServer();

      for(Consumer<MinecraftServer> h : this.started) {
         h.accept(server);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onAttack(PrePlayerAttackEntityEvent e) {
      ServerPlayer attacker = ((CraftPlayer)e.getPlayer()).getHandle();
      Entity target = ((CraftEntity)e.getAttacked()).getHandle();

      for(Platform.AttackEntityHandler h : this.attacks) {
         h.onAttack(attacker, target);
      }

   }

   @EventHandler
   public void onUse(PlayerInteractEvent e) {
      if (e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null) {
         Block b = e.getClickedBlock();
         ServerPlayer clicker = ((CraftPlayer)e.getPlayer()).getHandle();
         BlockPos pos = new BlockPos(b.getX(), b.getY(), b.getZ());

         for(Platform.UseBlockHandler h : this.blockUses) {
            h.onUseBlock(clicker, pos);
         }
      }

      if (e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
         if (e.getHand() != null) {
            if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null || !e.getClickedBlock().getType().isInteractable() || e.getPlayer().isSneaking()) {
               ServerPlayer sp = ((CraftPlayer)e.getPlayer()).getHandle();
               InteractionHand hand = e.getHand() == EquipmentSlot.OFF_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
               ItemStack stack = sp.getItemInHand(hand);

               for(Platform.UseItemHandler h : this.uses) {
                  if (h.onUseItem(sp, hand, stack)) {
                     e.setUseItemInHand(Result.DENY);
                     return;
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onPanelAttack(PrePlayerAttackEntityEvent e) {
      if (!this.inputs.isEmpty()) {
         ServerPlayer p = ((CraftPlayer)e.getPlayer()).getHandle();
         Entity target = ((CraftEntity)e.getAttacked()).getHandle();

         for(Platform.InputInterceptor h : this.inputs) {
            if (h.onEntityClick(p, target, true)) {
               e.setCancelled(true);
               return;
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onPanelUseEntity(PlayerInteractEntityEvent e) {
      this.panelUseEntity(e);
   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onPanelUseEntityAt(PlayerInteractAtEntityEvent e) {
      this.panelUseEntity(e);
   }

   private void panelUseEntity(PlayerInteractEntityEvent e) {
      if (!this.inputs.isEmpty()) {
         ServerPlayer p = ((CraftPlayer)e.getPlayer()).getHandle();
         Entity target = ((CraftEntity)e.getRightClicked()).getHandle();

         for(Platform.InputInterceptor h : this.inputs) {
            if (h.onEntityClick(p, target, false)) {
               e.setCancelled(true);
               return;
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.LOW
   )
   public void onPanelBlock(PlayerInteractEvent e) {
      if (!this.inputs.isEmpty() && e.getClickedBlock() != null) {
         boolean attack = e.getAction() == Action.LEFT_CLICK_BLOCK;
         if (attack || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ServerPlayer p = ((CraftPlayer)e.getPlayer()).getHandle();
            Block b = e.getClickedBlock();
            BlockPos pos = new BlockPos(b.getX(), b.getY(), b.getZ());

            for(Platform.InputInterceptor h : this.inputs) {
               if (h.onBlockClick(p, pos, attack)) {
                  e.setCancelled(true);
                  return;
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPanelSwing(PlayerAnimationEvent e) {
      if (!this.inputs.isEmpty() && e.getAnimationType() == PlayerAnimationType.ARM_SWING) {
         ServerPlayer p = ((CraftPlayer)e.getPlayer()).getHandle();

         for(Platform.InputInterceptor h : this.inputs) {
            h.onSwing(p);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.LOW,
      ignoreCancelled = true
   )
   public void onPanelScroll(PlayerItemHeldEvent e) {
      if (!this.inputs.isEmpty()) {
         ServerPlayer p = ((CraftPlayer)e.getPlayer()).getHandle();
         boolean cancel = false;

         for(Platform.InputInterceptor h : this.inputs) {
            cancel |= h.onHotbarChange(p, e.getPreviousSlot(), e.getNewSlot());
         }

         if (cancel) {
            e.setCancelled(true);
         }

      }
   }
}
