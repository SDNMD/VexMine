package vexbot.paper;

import java.util.Locale;
import java.util.UUID;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot.Type;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.equipment.Equippable;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageModifier;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.server.ServerCommandEvent;
import vexbot.command.LegacyCommands;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.stats.Stats;

public final class PaperStatsListeners implements Listener {
   private static UUID lastBotHitVictim = null;
   private static int lastBotHitTick = -1;

   private static BotPlayer bot(Entity e) {
      BotPlayer var10000;
      if (e instanceof Player p) {
         ServerPlayer var3 = ((CraftPlayer)p).getHandle();
         if (var3 instanceof BotPlayer b) {
            var10000 = b;
            return var10000;
         }
      }

      var10000 = null;
      return var10000;
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void legacyPlayerCommand(PlayerCommandPreprocessEvent e) {
      String r = LegacyCommands.rewrite(e.getMessage());
      if (r != null) {
         e.setMessage(r);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void legacyServerCommand(ServerCommandEvent e) {
      String r = LegacyCommands.rewrite(e.getCommand());
      if (r != null) {
         e.setCommand(r);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onPlayerCommand(PlayerCommandPreprocessEvent e) {
      if (bot(e.getPlayer()) == null) {
         tallyCommand(e.getMessage());
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onServerCommand(ServerCommandEvent e) {
      if (e.getSender() instanceof ConsoleCommandSender) {
         tallyCommand(e.getCommand());
      }
   }

   private static void tallyCommand(String raw) {
      if (Stats.enabled() && raw != null) {
         String cmd = raw.startsWith("/") ? raw.substring(1) : raw;
         String[] parts = cmd.trim().split("\\s+");
         if (parts.length != 0) {
            String root = parts[0].toLowerCase(Locale.ROOT);
            if (root.equals("vexbot") || root.equals("vexbot:vexbot")) {
               Stats.command(parts.length > 1 ? parts[1].toLowerCase(Locale.ROOT) : "bare");
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onEntityDeath(EntityDeathEvent e) {
      if (Stats.enabled() && !(e.getEntity() instanceof Player)) {
         if (bot(e.getDamageSource().getCausingEntity()) != null) {
            Stats.kill(false, false);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onDamage(EntityDamageByEntityEvent e) {
      if (Stats.enabled()) {
         if (bot(e.getDamageSource().getCausingEntity()) != null) {
            net.minecraft.world.entity.Entity var3 = ((CraftEntity)e.getEntity()).getHandle();
            if (var3 instanceof LivingEntity) {
               LivingEntity victim = (LivingEntity)var3;
               if (!(victim instanceof BotPlayer)) {
                  if (victim instanceof ServerPlayer) {
                     lastBotHitVictim = victim.getUUID();
                     lastBotHitTick = Bukkit.getCurrentTick();
                  }

                  double absorbed = e.isApplicable(DamageModifier.ABSORPTION) ? -e.getDamage(DamageModifier.ABSORPTION) : (double)0.0F;
                  double lost = Math.min(e.getFinalDamage() + Math.max((double)0.0F, absorbed), (double)(victim.getHealth() + victim.getAbsorptionAmount()));
                  if (lost > (double)0.0F) {
                     Stats.add("damage_dealt", Math.round(lost));
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onBlockPlace(BlockPlaceEvent e) {
      if (Stats.enabled() && bot(e.getPlayer()) != null) {
         Stats.inc("blocks_placed");
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onBlockBreak(BlockBreakEvent e) {
      if (Stats.enabled() && bot(e.getPlayer()) != null) {
         Stats.inc("blocks_mined");
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onItemBreak(PlayerItemBreakEvent e) {
      if (Stats.enabled()) {
         ItemStack stack = CraftItemStack.asNMSCopy(e.getBrokenItem());
         Equippable eq = (Equippable)stack.get(DataComponents.EQUIPPABLE);
         if (eq != null && eq.slot().getType() == Type.HUMANOID_ARMOR && !stack.is(Items.ELYTRA)) {
            ServerPlayer owner = ((CraftPlayer)e.getPlayer()).getHandle();
            if (owner instanceof BotPlayer) {
               Stats.inc("armor_used");
            } else if (owner.getLastHurtByMob() instanceof BotPlayer || owner.getUUID().equals(lastBotHitVictim) && lastBotHitTick == Bukkit.getCurrentTick()) {
               Stats.inc("armor_broken");
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onResurrect(EntityResurrectEvent e) {
      if (Stats.enabled()) {
         if (bot(e.getEntity()) != null) {
            Stats.inc("totems_popped");
         } else {
            EntityDamageEvent last = e.getEntity().getLastDamageCause();
            if (last != null && bot(last.getDamageSource().getCausingEntity()) != null) {
               Stats.inc("totems_forced");
            }

         }
      }
   }
}
