package vexbot.paper;

import net.minecraft.server.MinecraftServer;
import org.bukkit.plugin.java.JavaPlugin;
import vexbot.VexBot;
import vexbot.VexBotCore;
import vexbot.platform.Internals;
import vexbot.platform.Platform;

public final class VexBotPaper extends JavaPlugin {
   private PaperPlatform platform;

   public void onEnable() {
      this.platform = new PaperPlatform(this);
      Platform.install(this.platform);
      Internals.install(new PaperInternals());
      BotTargetArgumentPaper.install();
      VexBot.SERVER = MinecraftServer.getServer();
      VexBotCore.init();
      PaperListeners.register(this);
      this.platform.fireStarting(VexBot.SERVER);
      this.getLogger().info("[VexBot] enabled on Paper");
   }

   public void onDisable() {
      if (this.platform != null && VexBot.SERVER != null) {
         this.platform.fireStopping(VexBot.SERVER);
      }

   }
}
