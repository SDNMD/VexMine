package vexbot.paper;

import com.mojang.authlib.GameProfile;
import io.netty.channel.Channel;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.VarHandle;
import net.minecraft.network.Connection;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.BlocksAttacks;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import vexbot.compat.CompatServerPlayer;
import vexbot.fakeplayer.bot.BotPlayerActionPack;
import vexbot.platform.Internals;

public final class PaperInternals implements Internals {
   private final MethodHandle checkTotem;
   private final VarHandle lastDamageSource;
   private final VarHandle lastDamageStamp;
   private static volatile VarHandle latency;

   PaperInternals() {
      try {
         MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(LivingEntity.class, MethodHandles.lookup());
         this.checkTotem = lookup.findVirtual(LivingEntity.class, "checkTotemDeathProtection", MethodType.methodType(Boolean.TYPE, DamageSource.class));
         this.lastDamageSource = lookup.findVarHandle(LivingEntity.class, "lastDamageSource", DamageSource.class);
         this.lastDamageStamp = lookup.findVarHandle(LivingEntity.class, "lastDamageStamp", Long.TYPE);
      } catch (ReflectiveOperationException e) {
         throw new IllegalStateException("[VexBot] Paper renamed a LivingEntity member VexBot relies on", e);
      }
   }

   public void setConnectionChannel(Connection connection, Channel channel) {
      connection.channel = channel;
   }

   public void setGameProfile(Player player, GameProfile profile) {
      player.gameProfile = profile;
   }

   public ChunkMap.TrackedEntity trackedEntity(ChunkMap chunkMap, int entityId) {
      return (ChunkMap.TrackedEntity)chunkMap.entityMap.get(entityId);
   }

   public void detectEquipmentUpdates(LivingEntity entity) {
      entity.detectEquipmentUpdates();
   }

   public boolean checkTotemDeathProtection(LivingEntity entity, DamageSource source) {
      try {
         return this.checkTotem.invoke(entity, source);
      } catch (Throwable t) {
         throw new RuntimeException(t);
      }
   }

   public void playSecondaryHurtSound(LivingEntity entity, DamageSource source) {
      entity.playSecondaryHurtSound(source);
   }

   public void setLastDamage(LivingEntity entity, DamageSource source, long gameTime) {
      this.lastDamageSource.set(entity, source);
      this.lastDamageStamp.set(entity, gameTime);
   }

   public void disableBlocking(BlocksAttacks blocksAttacks, ServerLevel level, LivingEntity blocker, float seconds, ItemStack stack, LivingEntity attacker) {
      blocksAttacks.disable(level, blocker, seconds, stack, attacker);
   }

   public void setAffectsSpawning(ServerPlayer player, boolean affects) {
      CraftPlayer bukkit = player.getBukkitEntity();
      if (bukkit.getAffectsSpawning() != affects) {
         bukkit.setAffectsSpawning(affects);
      }

   }

   public void setLatency(ServerPlayer player, int ms) {
      try {
         if (latency == null) {
            latency = MethodHandles.privateLookupIn(ServerCommonPacketListenerImpl.class, MethodHandles.lookup()).findVarHandle(ServerCommonPacketListenerImpl.class, "latency", Integer.TYPE);
         }

         latency.set(player.connection, ms);
      } catch (ReflectiveOperationException e) {
         throw new IllegalStateException("[VexBot] Paper renamed ServerCommonPacketListenerImpl.latency", e);
      }
   }

   public BotPlayerActionPack actionPack(ServerPlayer player) {
      BotPlayerActionPack var10000;
      if (player instanceof CompatServerPlayer bot) {
         var10000 = bot.botActionPack();
      } else {
         var10000 = null;
      }

      return var10000;
   }
}
