package vexbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.bot.ai.FollowFormation;
import vexbot.bot.ai.RestockPlan;
import vexbot.team.TeamManager;
import vexbot.team.TeamTactics;
import vexbot.team.TeamTargetBalancer;

public final class SettingsPersistence {
   private static boolean migratingEnderRegear = false;
   private static boolean loadFailed = false;
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-Settings");
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static int batchDepth = 0;
   private static boolean batchSaveDue = false;

   private SettingsPersistence() {
   }

   private static Path settingsFile(MinecraftServer server) {
      return server.getServerDirectory().resolve("vexbot_settings.json");
   }

   public static void beginBatch() {
      ++batchDepth;
   }

   public static void endBatch(MinecraftServer server) {
      if (batchDepth > 0 && --batchDepth <= 0 && batchSaveDue) {
         batchSaveDue = false;
         save(server);
      }
   }

   public static void save(MinecraftServer server) {
      if (batchDepth > 0) {
         batchSaveDue = true;
      } else if (loadFailed) {
         LOGGER.warn("[VexBot] Settings not saved: {} failed to load this session (a copy was kept as .corrupt-*). Fix or remove it and restart.", settingsFile(server));
      } else {
         JsonObject root = new JsonObject();
         root.add("global", saveGlobal());
         root.add("teams", saveTeams());
         Path file = settingsFile(server);
         Path tmp = file.resolveSibling(String.valueOf(file.getFileName()) + ".tmp");

         try {
            Files.writeString(tmp, GSON.toJson(root));

            try {
               Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException var5) {
               Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
         } catch (IOException e) {
            LOGGER.error("[VexBot] Failed to save settings", e);
         }

      }
   }

   private static JsonObject saveGlobal() {
      JsonObject g = new JsonObject();
      g.addProperty("equipArmor", BotSettings.equipArmor);
      g.addProperty("usePotions", BotSettings.usePotions);
      g.addProperty("revengeMode", BotSettings.revengeMode);
      g.addProperty("retreat", BotSettings.retreat);
      g.addProperty("useCobwebs", BotSettings.useCobwebs);
      g.addProperty("bunnyHopMode", BotSettings.bunnyHopMode.name());
      g.addProperty("autoTarget", BotSettings.autoTarget);
      g.addProperty("targetPlayers", BotSettings.targetPlayers);
      g.addProperty("targetBots", BotSettings.targetBots);
      g.addProperty("targetMobs", BotSettings.targetMobs);
      g.addProperty("difficulty", BotSettings.difficulty.name());
      JsonObject gDiffParams = new JsonObject();
      BotSettings.difficultyParams.writeTo(gDiffParams);
      g.add("difficultyParams", gDiffParams);
      JsonObject gTech = new JsonObject();
      BotSettings.techniques.writeTo(gTech);
      g.add("techniques", gTech);
      JsonObject gRgc = new JsonObject();
      BotSettings.randomGearConfig.writeTo(gRgc);
      g.add("randomGearConfig", gRgc);
      JsonObject gRcl = new JsonObject();
      BotSettings.randomChestLootConfig.writeTo(gRcl);
      g.add("randomChestLootConfig", gRcl);
      g.addProperty("useCarting", BotSettings.useCarting);
      g.addProperty("bridgeMode", BotSettings.bridgeMode.name());
      g.addProperty("attackRange", BotSettings.attackRange);
      g.addProperty("statsOn", BotSettings.statsEnabled);
      JsonObject psChances = new JsonObject();
      BotSettings.playStyleChances.forEach((k, v) -> psChances.addProperty(k.name(), v));
      g.add("playStyleChances", psChances);
      g.addProperty("cartMode", BotSettings.cartMode.name());
      g.addProperty("wanderWhenIdle", BotSettings.wanderWhenIdle);
      g.addProperty("ignoreCreative", BotSettings.ignoreCreative);
      g.addProperty("useEnderPearl", BotSettings.useEnderPearl);
      g.addProperty("botDontLeave", BotSettings.botDontLeave);
      g.addProperty("botAdvancements", BotSettings.botAdvancements);
      g.addProperty("botSpawnMobs", BotSettings.botSpawnMobs);
      g.addProperty("pearlChasing", BotSettings.pearlChasing);
      g.addProperty("botLeaveOnDeath", BotSettings.botLeaveOnDeath);
      g.addProperty("useScaffolding", BotSettings.useScaffolding);
      g.addProperty("chorusEscape", BotSettings.chorusEscape);
      g.addProperty("fireEscape", BotSettings.fireEscape);
      g.addProperty("shulkerSteal", BotSettings.shulkerSteal);
      g.addProperty("gameLogs", BotSettings.gameLogs.name());
      g.addProperty("namePool", BotSettings.namePool);
      g.addProperty("nullPortalJamatopChance", BotSettings.nullPortalJamatopChance);
      g.addProperty("nullPortalCommanderChance", BotSettings.nullPortalCommanderChance);
      g.addProperty("nullPortalSpecialChance", BotSettings.nullPortalSpecialChance);
      g.addProperty("nullPortalCommanderKit", BotSettings.nullPortalCommanderKit);
      g.addProperty("nullPortalSpecialKit", BotSettings.nullPortalSpecialKit);
      g.addProperty("nullPortalLeader", BotSettings.nullPortalLeader);
      g.addProperty("nullPortalSpokeKit", BotSettings.nullPortalSpokeKit);
      g.addProperty("nullPortalKitsV", 2);
      g.addProperty("spreadout", BotSettings.spreadOut);
      g.addProperty("showtags", BotSettings.showTags);
      g.addProperty("shulkerregear", BotSettings.shulkerRegear);
      g.addProperty("enderchestregear", BotSettings.enderChestRegear);
      g.addProperty("enderChestRegearDefaultedOn", true);
      g.addProperty("webEscape", BotSettings.webEscape);
      g.addProperty("waterBucketClutch", BotSettings.waterBucketClutch);
      g.addProperty("hitWeb", BotSettings.hitWeb);
      g.addProperty("pickupLoot", BotSettings.pickupLoot);
      g.addProperty("buildUpMinHeight", BotSettings.buildUpMinHeight);
      g.addProperty("botPing", BotSettings.botPing);
      g.addProperty("doBlockExplosion", BotSettings.doBlockExplosion);
      g.addProperty("speedNoJump", BotSettings.speedNoJump);
      g.addProperty("maceTotem", BotSettings.maceTotem);
      g.addProperty("chaseSpread", BotSettings.chaseSpread);
      g.addProperty("placeBlocksMoving", BotSettings.placeBlocksMoving);
      g.addProperty("lootPackRadius", BotSettings.lootPackRadius);
      g.addProperty("healingMode", BotSettings.healingMode.name());
      g.addProperty("offhandPreference", BotSettings.offhandPreference.name());
      g.addProperty("offhandTotemHearts", BotSettings.offhandTotemHearts);
      g.addProperty("strafeInCombo", BotSettings.strafeInCombo);
      JsonObject plan = new JsonObject();
      Map var10000 = RestockPlan.view((String)null);
      Objects.requireNonNull(plan);
      var10000.forEach(plan::addProperty);
      g.add("restockPlan", plan);
      g.addProperty("cartDoctrine", BotSettings.cartDoctrine.name());
      if (BotSettings.spawnAreaDim != null) {
         g.addProperty("spawnAreaDim", BotSettings.spawnAreaDim);
         g.addProperty("spawnAreaX1", BotSettings.spawnAreaX1);
         g.addProperty("spawnAreaY1", BotSettings.spawnAreaY1);
         g.addProperty("spawnAreaZ1", BotSettings.spawnAreaZ1);
         g.addProperty("spawnAreaX2", BotSettings.spawnAreaX2);
         g.addProperty("spawnAreaY2", BotSettings.spawnAreaY2);
         g.addProperty("spawnAreaZ2", BotSettings.spawnAreaZ2);
      }

      g.addProperty("useBows", BotSettings.useBows);
      g.addProperty("useOrbitalStrike", BotSettings.useOrbitalStrike);
      JsonObject styles = new JsonObject();

      for(Map.Entry<String, BotSettings.PlayStyle> e : BotSettings.playStyles.entrySet()) {
         styles.addProperty((String)e.getKey(), ((BotSettings.PlayStyle)e.getValue()).name());
      }

      g.add("playStyles", styles);
      JsonObject botDiff = new JsonObject();
      BotSettings.botDifficulties.forEach((name, params) -> {
         JsonObject one = new JsonObject();
         params.writeTo(one);
         botDiff.add(name, one);
      });
      g.add("botDifficulties", botDiff);
      g.addProperty("retreatHealthHearts", BotSettings.retreatHealthHearts);
      g.addProperty("kitPotionDoSplash", BotSettings.kitPotionDoSplash);
      g.addProperty("gotoMining", BotSettings.gotoMining);
      g.addProperty("advancedSpawn", BotSettings.advancedSpawn);
      g.addProperty("silentCommands", BotSettings.silentCommands);
      g.addProperty("ffaRandomDifficulties", BotSettings.ffaRandomDifficulties);
      g.addProperty("nullPortalJoinTeam", BotSettings.nullPortalJoinTeam);
      g.addProperty("nameTagColour", BotSettings.nameTagColour);
      g.addProperty("nullPortalTeam", BotSettings.nullPortalTeam);
      g.addProperty("nullPortalBreakAfterSpawn", BotSettings.nullPortalBreakAfterSpawn);
      g.addProperty("nullPortalSkin", BotSettings.nullPortalSkin);
      g.addProperty("riptideAnywhere", BotSettings.riptideAnywhere);
      g.addProperty("useElytraMace", BotSettings.useElytraMace);
      g.addProperty("useElytraSpear", BotSettings.useElytraSpear);
      g.addProperty("fastShieldCooldown", BotSettings.fastShieldCooldown);
      g.addProperty("useSpearDash", BotSettings.useSpearDash);
      g.addProperty("useStunSlam", BotSettings.useStunSlam);
      g.addProperty("useWebDrain", BotSettings.useWebDrain);
      g.addProperty("webDrainChance", BotSettings.webDrainChance);
      g.addProperty("jumpResetChance", BotSettings.jumpResetChance);
      g.addProperty("counterStunChance", BotSettings.counterStunChance);
      g.addProperty("shieldOnMaceDive", BotSettings.shieldOnMaceDive);
      g.addProperty("usePearlCatch", BotSettings.usePearlCatch);
      g.addProperty("elytraGlide", BotSettings.elytraGlide);
      return g;
   }

   private static JsonObject saveTeams() {
      JsonObject teams = new JsonObject();

      for(TeamManager.BotTeam t : TeamManager.allTeams()) {
         JsonObject tj = new JsonObject();
         tj.add("bots", GSON.toJsonTree(t.getBotNames()));
         tj.add("players", GSON.toJsonTree(t.getPlayerNames()));
         tj.addProperty("mode", t.getMode().name());
         tj.add("targets", GSON.toJsonTree(t.getTargetNames()));
         tj.add("targetTeams", GSON.toJsonTree(t.getTargetTeamNames()));
         tj.add("allies", GSON.toJsonTree(t.getAllies()));
         tj.addProperty("revengeMode", t.revengeMode);
         tj.addProperty("nameTagColour", t.nameTagColour);
         tj.addProperty("teamSkin", t.teamSkin);
         tj.addProperty("namePool", t.namePool);
         tj.addProperty("equipArmor", t.equipArmor);
         tj.addProperty("usePotions", t.usePotions);
         tj.addProperty("retreat", t.retreat);
         tj.addProperty("useCobwebs", t.useCobwebs);
         tj.addProperty("bunnyHopMode", t.bunnyHopMode.name());
         tj.addProperty("autoTarget", t.autoTarget);
         tj.addProperty("targetPlayers", t.targetPlayers);
         tj.addProperty("targetBots", t.targetBots);
         tj.addProperty("targetMobs", t.targetMobs);
         tj.addProperty("difficulty", t.difficulty.name());
         JsonObject tDiffParams = new JsonObject();
         t.difficultyParams.writeTo(tDiffParams);
         tj.add("difficultyParams", tDiffParams);
         JsonObject tTech = new JsonObject();
         t.techniques.writeTo(tTech);
         tj.add("techniques", tTech);
         JsonObject tRgc = new JsonObject();
         t.randomGearConfig.writeTo(tRgc);
         tj.add("randomGearConfig", tRgc);
         tj.addProperty("useCarting", t.useCarting);
         tj.addProperty("bridgeMode", t.bridgeMode.name());
         tj.addProperty("attackRange", t.attackRange);
         tj.addProperty("cartMode", t.cartMode.name());
         tj.addProperty("ignoreCreative", t.ignoreCreative);
         tj.addProperty("useEnderPearl", t.useEnderPearl);
         tj.addProperty("pearlChasing", t.pearlChasing);
         tj.addProperty("botLeaveOnDeath", t.botLeaveOnDeath);
         tj.addProperty("useScaffolding", t.useScaffolding);
         tj.addProperty("chorusEscape", t.chorusEscape);
         tj.addProperty("fireEscape", t.fireEscape);
         tj.addProperty("shulkerSteal", t.shulkerSteal);
         tj.addProperty("spreadOut", t.spreadOut);
         tj.addProperty("shulkerRegear", t.shulkerRegear);
         tj.addProperty("enderChestRegear", t.enderChestRegear);
         tj.addProperty("webEscape", t.webEscape);
         tj.addProperty("waterBucketClutch", t.waterBucketClutch);
         tj.addProperty("hitWeb", t.hitWeb);
         tj.addProperty("pickupLoot", t.pickupLoot);
         tj.addProperty("buildUpMinHeight", t.buildUpMinHeight);
         tj.addProperty("botPing", t.botPing);
         tj.addProperty("doBlockExplosion", t.doBlockExplosion);
         tj.addProperty("speedNoJump", t.speedNoJump);
         tj.addProperty("maceTotem", t.maceTotem);
         tj.addProperty("chaseSpread", t.chaseSpread);
         tj.addProperty("placeBlocksMoving", t.placeBlocksMoving);
         tj.addProperty("lootPackRadius", t.lootPackRadius);
         tj.addProperty("healingMode", t.healingMode.name());
         tj.addProperty("offhandPreference", t.offhandPreference.name());
         tj.addProperty("offhandTotemHearts", t.offhandTotemHearts);
         tj.addProperty("strafeInCombo", t.strafeInCombo);
         JsonObject tplan = new JsonObject();
         Map var10000 = RestockPlan.view(t.getName());
         Objects.requireNonNull(tplan);
         var10000.forEach(tplan::addProperty);
         tj.add("restockPlan", tplan);
         tj.addProperty("cartDoctrine", t.cartDoctrine.name());
         JsonObject tac = new JsonObject();
         tac.addProperty("formation", t.tactics.formation.name());
         tac.addProperty("formationSize", t.tactics.formationSize);
         tac.addProperty("spacing", t.tactics.spacing);
         tac.addProperty("spacingMigrated", true);
         tac.addProperty("movementSpeed", t.tactics.movementSpeed);
         tac.addProperty("boss", t.tactics.boss);
         tac.addProperty("protectBoss", t.tactics.protectBoss);
         tac.addProperty("focusBossTarget", t.tactics.focusBossTarget);
         tac.addProperty("followBoss", t.tactics.followBoss);
         tac.addProperty("maintainFormation", t.tactics.maintainFormation);
         tac.addProperty("retreatWhenLow", t.tactics.retreatWhenLow);
         tac.addProperty("shieldBehaviour", t.tactics.shieldBehaviour.name());
         tac.addProperty("rangedPositioning", t.tactics.rangedPositioning.name());
         tac.addProperty("targetPriority", t.tactics.targetPriority.name());
         tac.addProperty("regroupDistance", t.tactics.regroupDistance);
         tac.addProperty("maxDistanceFromBoss", t.tactics.maxDistanceFromBoss);
         tac.addProperty("hornPlayer", t.tactics.hornPlayer);
         tac.addProperty("hornType", t.tactics.hornType);
         tac.addProperty("hornFormation", t.tactics.hornFormation.name());
         tj.add("tactics", tac);
         tj.addProperty("useBows", t.useBows);
         tj.addProperty("useOrbitalStrike", t.useOrbitalStrike);
         tj.addProperty("retreatHealthHearts", t.retreatHealthHearts);
         tj.addProperty("wanderWhenIdle", t.wanderWhenIdle);
         tj.addProperty("riptideAnywhere", t.riptideAnywhere);
         tj.addProperty("useElytraMace", t.useElytraMace);
         tj.addProperty("useElytraSpear", t.useElytraSpear);
         tj.addProperty("fastShieldCooldown", t.fastShieldCooldown);
         tj.addProperty("useSpearDash", t.useSpearDash);
         tj.addProperty("useStunSlam", t.useStunSlam);
         tj.addProperty("useWebDrain", t.useWebDrain);
         tj.addProperty("webDrainChance", t.webDrainChance);
         tj.addProperty("jumpResetChance", t.jumpResetChance);
         tj.addProperty("counterStunChance", t.counterStunChance);
         tj.addProperty("shieldOnMaceDive", t.shieldOnMaceDive);
         tj.addProperty("usePearlCatch", t.usePearlCatch);
         tj.addProperty("elytraGlide", t.elytraGlide);
         teams.add(t.getName(), tj);
      }

      return teams;
   }

   public static void load(MinecraftServer server) {
      loadFailed = false;
      Path file = settingsFile(server);
      if (Files.exists(file, new LinkOption[0])) {
         try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.has("global")) {
               loadGlobal(root.getAsJsonObject("global"));
            }

            if (root.has("teams")) {
               loadTeams(root.getAsJsonObject("teams"));
            }

            TeamManager.setRebalanceServer(server);
            TeamTargetBalancer.rebalanceAll(server);
            LOGGER.info("[VexBot] Settings loaded from {}", file);
         } catch (RuntimeException | IOException e) {
            LOGGER.error("[VexBot] Failed to load settings from {}", file, e);
            loadFailed = true;

            try {
               String var10001 = String.valueOf(file.getFileName());
               Path backup = file.resolveSibling(var10001 + ".corrupt-" + System.currentTimeMillis());
               Files.copy(file, backup, StandardCopyOption.REPLACE_EXISTING);
               LOGGER.error("[VexBot] Copied the unreadable settings file to {}", backup);
            } catch (IOException copyErr) {
               LOGGER.error("[VexBot] Could not back up {}", file, copyErr);
            }
         }

      }
   }

   private static void loadGlobal(JsonObject g) {
      BotSettings.equipArmor = bool(g, "equipArmor", BotSettings.equipArmor);
      BotSettings.usePotions = bool(g, "usePotions", BotSettings.usePotions);
      BotSettings.revengeMode = bool(g, "revengeMode", BotSettings.revengeMode);
      BotSettings.retreat = bool(g, "retreat", BotSettings.retreat);
      BotSettings.useCobwebs = bool(g, "useCobwebs", BotSettings.useCobwebs);
      BotSettings.bunnyHopMode = (BotSettings.BunnyHopMode)enumVal(g, "bunnyHopMode", BotSettings.BunnyHopMode.class, BotSettings.bunnyHopMode);
      BotSettings.autoTarget = bool(g, "autoTarget", BotSettings.autoTarget);
      BotSettings.targetPlayers = bool(g, "targetPlayers", BotSettings.targetPlayers);
      BotSettings.targetBots = bool(g, "targetBots", BotSettings.targetBots);
      BotSettings.targetMobs = bool(g, "targetMobs", BotSettings.targetMobs);
      BotSettings.difficulty = (BotSettings.Difficulty)enumVal(g, "difficulty", BotSettings.Difficulty.class, BotSettings.difficulty);
      BotSettings.difficultyParams = DifficultyParams.forPreset(BotSettings.difficulty);
      if (g.has("difficultyParams") && g.get("difficultyParams").isJsonObject()) {
         BotSettings.difficultyParams.readFrom(g.getAsJsonObject("difficultyParams"));
      }

      BotSettings.techniques.spearDash = bool(g, "useSpearDash", BotSettings.techniques.spearDash);
      BotSettings.techniques.stunSlam = bool(g, "useStunSlam", BotSettings.techniques.stunSlam);
      BotSettings.techniques.pearlCatch = bool(g, "usePearlCatch", BotSettings.techniques.pearlCatch);
      BotSettings.techniques.pearlCatchGlide = bool(g, "elytraGlide", BotSettings.techniques.pearlCatchGlide);
      if (g.has("techniques") && g.get("techniques").isJsonObject()) {
         BotSettings.techniques.readFrom(g.getAsJsonObject("techniques"));
      }

      if (g.has("randomGearConfig") && g.get("randomGearConfig").isJsonObject()) {
         BotSettings.randomGearConfig.readFrom(g.getAsJsonObject("randomGearConfig"));
      }

      if (g.has("randomChestLootConfig") && g.get("randomChestLootConfig").isJsonObject()) {
         BotSettings.randomChestLootConfig.readFrom(g.getAsJsonObject("randomChestLootConfig"));
      }

      if (g.has("stunSlamChance")) {
         BotSettings.difficultyParams.stunSlamChance = percent(g, "stunSlamChance", BotSettings.difficultyParams.stunSlamChance);
      }

      BotSettings.useCarting = bool(g, "useCarting", BotSettings.useCarting);
      BotSettings.bridgeMode = (BotSettings.BridgeMode)enumVal(g, "bridgeMode", BotSettings.BridgeMode.class, BotSettings.bridgeMode);
      if (g.has("attackRange")) {
         BotSettings.attackRange = g.get("attackRange").getAsDouble();
      }

      BotSettings.statsEnabled = bool(g, "statsOn", BotSettings.statsEnabled);
      if (g.has("playStyleChances") && g.get("playStyleChances").isJsonObject()) {
         JsonObject psc = g.getAsJsonObject("playStyleChances");

         for(BotSettings.PlayStyle st : BotSettings.PlayStyle.values()) {
            if (psc.has(st.name())) {
               BotSettings.playStyleChances.put(st, Math.max(0, psc.get(st.name()).getAsInt()));
            }
         }
      }

      BotSettings.cartMode = (BotSettings.CartMode)enumVal(g, "cartMode", BotSettings.CartMode.class, BotSettings.cartMode);
      BotSettings.wanderWhenIdle = bool(g, "wanderWhenIdle", BotSettings.wanderWhenIdle);
      BotSettings.ignoreCreative = bool(g, "ignoreCreative", BotSettings.ignoreCreative);
      BotSettings.useEnderPearl = bool(g, "useEnderPearl", BotSettings.useEnderPearl);
      BotSettings.botDontLeave = bool(g, "botDontLeave", BotSettings.botDontLeave);
      BotSettings.botAdvancements = bool(g, "botAdvancements", BotSettings.botAdvancements);
      BotSettings.botSpawnMobs = bool(g, "botSpawnMobs", BotSettings.botSpawnMobs);
      BotSettings.pearlChasing = bool(g, "pearlChasing", BotSettings.pearlChasing);
      BotSettings.botLeaveOnDeath = bool(g, "botLeaveOnDeath", BotSettings.botLeaveOnDeath);
      BotSettings.useScaffolding = bool(g, "useScaffolding", BotSettings.useScaffolding);
      BotSettings.chorusEscape = bool(g, "chorusEscape", BotSettings.chorusEscape);
      BotSettings.fireEscape = bool(g, "fireEscape", BotSettings.fireEscape);
      BotSettings.shulkerSteal = bool(g, "shulkerSteal", BotSettings.shulkerSteal);
      BotSettings.gameLogs = (BotSettings.GameLogs)enumVal(g, "gameLogs", BotSettings.GameLogs.class, BotSettings.gameLogs);
      if (g.has("namePool")) {
         BotSettings.namePool = g.get("namePool").getAsString();
      }

      BotSettings.nullPortalJamatopChance = dbl(g, "nullPortalJamatopChance", BotSettings.nullPortalJamatopChance);
      BotSettings.nullPortalCommanderChance = dbl(g, "nullPortalCommanderChance", BotSettings.nullPortalCommanderChance);
      BotSettings.nullPortalSpecialChance = dbl(g, "nullPortalSpecialChance", BotSettings.nullPortalSpecialChance);
      if (g.has("nullPortalCommanderKit")) {
         BotSettings.nullPortalCommanderKit = g.get("nullPortalCommanderKit").getAsString();
      }

      if (g.has("nullPortalSpecialKit")) {
         BotSettings.nullPortalSpecialKit = g.get("nullPortalSpecialKit").getAsString();
      }

      if (!g.has("nullPortalKitsV")) {
         BotSettings.nullPortalCommanderKit = "";
         BotSettings.nullPortalSpecialKit = "";
      }

      if (g.has("nullPortalLeader")) {
         String l = g.get("nullPortalLeader").getAsString();
         BotSettings.nullPortalLeader = "spoke".equalsIgnoreCase(l) ? "spoke" : "jamatop";
      }

      if (g.has("nullPortalSpokeKit")) {
         BotSettings.nullPortalSpokeKit = g.get("nullPortalSpokeKit").getAsString();
      }

      BotSettings.spreadOut = bool(g, "spreadout", BotSettings.spreadOut);
      BotSettings.showTags = bool(g, "showtags", BotSettings.showTags);
      BotSettings.shulkerRegear = bool(g, "shulkerregear", BotSettings.shulkerRegear);
      BotSettings.enderChestRegear = bool(g, "enderchestregear", BotSettings.enderChestRegear);
      migratingEnderRegear = !g.has("enderChestRegearDefaultedOn");
      if (migratingEnderRegear) {
         BotSettings.enderChestRegear = true;
         VexBot.LOGGER.info("[VexBot] enderchestregear is now on by default — turning it on for this world (and its teams). Turn it off with /vexbot settings enderchestregear false.");
      }

      BotSettings.webEscape = bool(g, "webEscape", BotSettings.webEscape);
      BotSettings.waterBucketClutch = bool(g, "waterBucketClutch", BotSettings.waterBucketClutch);
      BotSettings.hitWeb = bool(g, "hitWeb", BotSettings.hitWeb);
      BotSettings.pickupLoot = bool(g, "pickupLoot", BotSettings.pickupLoot);
      BotSettings.buildUpMinHeight = dbl(g, "buildUpMinHeight", BotSettings.buildUpMinHeight);
      BotSettings.botPing = (int)Math.max((double)0.0F, Math.min((double)5000.0F, dbl(g, "botPing", (double)BotSettings.botPing)));
      BotSettings.doBlockExplosion = bool(g, "doBlockExplosion", BotSettings.doBlockExplosion);
      BotSettings.speedNoJump = bool(g, "speedNoJump", BotSettings.speedNoJump);
      BotSettings.maceTotem = bool(g, "maceTotem", BotSettings.maceTotem);
      BotSettings.chaseSpread = bool(g, "chaseSpread", BotSettings.chaseSpread);
      BotSettings.placeBlocksMoving = bool(g, "placeBlocksMoving", BotSettings.placeBlocksMoving);
      BotSettings.lootPackRadius = dbl(g, "lootPackRadius", BotSettings.lootPackRadius);
      BotSettings.healingMode = (BotSettings.HealingMode)enumOr(g, "healingMode", BotSettings.HealingMode.class, BotSettings.healingMode);
      BotSettings.offhandPreference = (BotSettings.OffhandPreference)enumOr(g, "offhandPreference", BotSettings.OffhandPreference.class, BotSettings.offhandPreference);
      BotSettings.offhandTotemHearts = dbl(g, "offhandTotemHearts", BotSettings.offhandTotemHearts);
      BotSettings.strafeInCombo = bool(g, "strafeInCombo", BotSettings.strafeInCombo);
      loadRestockPlan(g, (String)null);
      BotSettings.cartDoctrine = (BotSettings.CartDoctrine)enumOr(g, "cartDoctrine", BotSettings.CartDoctrine.class, BotSettings.cartDoctrine);
      BotSettings.spawnAreaDim = g.has("spawnAreaDim") ? g.get("spawnAreaDim").getAsString() : null;
      if (BotSettings.spawnAreaDim != null) {
         BotSettings.spawnAreaX1 = dbl(g, "spawnAreaX1", (double)0.0F);
         BotSettings.spawnAreaY1 = dbl(g, "spawnAreaY1", (double)0.0F);
         BotSettings.spawnAreaZ1 = dbl(g, "spawnAreaZ1", (double)0.0F);
         BotSettings.spawnAreaX2 = dbl(g, "spawnAreaX2", (double)0.0F);
         BotSettings.spawnAreaY2 = dbl(g, "spawnAreaY2", (double)0.0F);
         BotSettings.spawnAreaZ2 = dbl(g, "spawnAreaZ2", (double)0.0F);
      }

      BotSettings.useBows = bool(g, "useBows", BotSettings.useBows);
      BotSettings.useOrbitalStrike = bool(g, "useOrbitalStrike", BotSettings.useOrbitalStrike);
      BotSettings.botDifficulties.clear();
      if (g.has("botDifficulties") && g.get("botDifficulties").isJsonObject()) {
         for(Map.Entry<String, JsonElement> e : g.getAsJsonObject("botDifficulties").entrySet()) {
            if (((JsonElement)e.getValue()).isJsonObject()) {
               DifficultyParams p = BotSettings.difficultyParams.copy();
               p.readFrom(((JsonElement)e.getValue()).getAsJsonObject());
               BotSettings.botDifficulties.put((String)e.getKey(), p);
            }
         }
      }

      BotSettings.playStyles.clear();
      if (g.has("playStyles") && g.get("playStyles").isJsonObject()) {
         for(Map.Entry<String, JsonElement> e : g.getAsJsonObject("playStyles").entrySet()) {
            try {
               BotSettings.playStyles.put((String)e.getKey(), BotSettings.PlayStyle.valueOf(((JsonElement)e.getValue()).getAsString()));
            } catch (RuntimeException var6) {
            }
         }
      }

      BotSettings.reindexPlayStyles();
      BotSettings.retreatHealthHearts = dbl(g, "retreatHealthHearts", BotSettings.retreatHealthHearts);
      BotSettings.kitPotionDoSplash = bool(g, "kitPotionDoSplash", BotSettings.kitPotionDoSplash);
      BotSettings.gotoMining = bool(g, "gotoMining", BotSettings.gotoMining);
      BotSettings.advancedSpawn = bool(g, "advancedSpawn", BotSettings.advancedSpawn);
      BotSettings.silentCommands = bool(g, "silentCommands", BotSettings.silentCommands);
      BotSettings.ffaRandomDifficulties = bool(g, "ffaRandomDifficulties", BotSettings.ffaRandomDifficulties);
      BotSettings.nullPortalJoinTeam = bool(g, "nullPortalJoinTeam", BotSettings.nullPortalJoinTeam);
      BotSettings.nullPortalBreakAfterSpawn = bool(g, "nullPortalBreakAfterSpawn", BotSettings.nullPortalBreakAfterSpawn);
      BotSettings.nullPortalSkin = bool(g, "nullPortalSkin", BotSettings.nullPortalSkin);
      if (g.has("nameTagColour") && !g.get("nameTagColour").getAsString().isBlank()) {
         BotSettings.nameTagColour = g.get("nameTagColour").getAsString();
      }

      if (g.has("nullPortalTeam") && !g.get("nullPortalTeam").getAsString().isBlank()) {
         BotSettings.nullPortalTeam = g.get("nullPortalTeam").getAsString();
      }

      BotSettings.riptideAnywhere = bool(g, "riptideAnywhere", BotSettings.riptideAnywhere);
      BotSettings.useElytraMace = bool(g, "useElytraMace", BotSettings.useElytraMace);
      BotSettings.useElytraSpear = bool(g, "useElytraSpear", BotSettings.useElytraSpear);
      BotSettings.fastShieldCooldown = bool(g, "fastShieldCooldown", BotSettings.fastShieldCooldown);
      BotSettings.useSpearDash = bool(g, "useSpearDash", BotSettings.useSpearDash);
      BotSettings.useStunSlam = bool(g, "useStunSlam", BotSettings.useStunSlam);
      BotSettings.useWebDrain = bool(g, "useWebDrain", BotSettings.useWebDrain);
      BotSettings.webDrainChance = percent(g, "webDrainChance", BotSettings.webDrainChance);
      BotSettings.jumpResetChance = percent(g, "jumpResetChance", BotSettings.jumpResetChance);
      BotSettings.counterStunChance = percent(g, "counterStunChance", BotSettings.counterStunChance);
      BotSettings.shieldOnMaceDive = bool(g, "shieldOnMaceDive", BotSettings.shieldOnMaceDive);
      BotSettings.usePearlCatch = bool(g, "usePearlCatch", BotSettings.usePearlCatch);
      BotSettings.elytraGlide = bool(g, "elytraGlide", BotSettings.elytraGlide);
   }

   private static void loadTeams(JsonObject teamsObj) {
      TeamManager.loadingFromDisk = true;

      try {
         loadTeamsInner(teamsObj);
      } finally {
         TeamManager.loadingFromDisk = false;
      }

   }

   private static void loadTeamsInner(JsonObject teamsObj) {
      for(Map.Entry<String, JsonElement> entry : teamsObj.entrySet()) {
         String name = (String)entry.getKey();
         JsonObject tj = ((JsonElement)entry.getValue()).getAsJsonObject();
         List<String> bots = new ArrayList();
         if (tj.has("bots")) {
            for(JsonElement e : tj.getAsJsonArray("bots")) {
               bots.add(e.getAsString());
            }
         }

         TeamManager.setTeamBots(name, bots);
         if (tj.has("players")) {
            List<String> players = new ArrayList();

            for(JsonElement e : tj.getAsJsonArray("players")) {
               players.add(e.getAsString());
            }

            TeamManager.setTeamPlayers(name, players);
         }

         TeamManager.TargetMode mode = (TeamManager.TargetMode)enumVal(tj, "mode", TeamManager.TargetMode.class, TeamManager.TargetMode.NONE);
         TeamManager.setMode(name, mode);
         if (tj.has("targets")) {
            List<String> targets = new ArrayList();

            for(JsonElement e : tj.getAsJsonArray("targets")) {
               targets.add(e.getAsString());
            }

            if (mode == TeamManager.TargetMode.SPECIFIC && !targets.isEmpty()) {
               TeamManager.setTargets(name, targets);
            }
         }

         if (tj.has("targetTeams")) {
            List<String> targetTeams = new ArrayList();

            for(JsonElement e : tj.getAsJsonArray("targetTeams")) {
               targetTeams.add(e.getAsString());
            }

            if (mode == TeamManager.TargetMode.SPECIFIC_TEAMS && !targetTeams.isEmpty()) {
               TeamManager.setTargetTeams(name, targetTeams);
            }
         }

         if (tj.has("allies")) {
            List<String> allies = new ArrayList();

            for(JsonElement e : tj.getAsJsonArray("allies")) {
               allies.add(e.getAsString());
            }

            TeamManager.loadAllies(name, allies);
         }

         TeamManager.BotTeam team = TeamManager.get(name);
         if (team != null) {
            team.revengeMode = bool(tj, "revengeMode", team.revengeMode);
            if (tj.has("nameTagColour") && !tj.get("nameTagColour").getAsString().isBlank()) {
               team.nameTagColour = tj.get("nameTagColour").getAsString();
            }

            if (tj.has("teamSkin") && !tj.get("teamSkin").getAsString().isBlank()) {
               team.teamSkin = tj.get("teamSkin").getAsString();
            }

            if (tj.has("namePool") && !tj.get("namePool").getAsString().isBlank()) {
               team.namePool = tj.get("namePool").getAsString();
            }

            team.equipArmor = bool(tj, "equipArmor", team.equipArmor);
            team.usePotions = bool(tj, "usePotions", team.usePotions);
            team.retreat = bool(tj, "retreat", team.retreat);
            team.useCobwebs = bool(tj, "useCobwebs", team.useCobwebs);
            team.bunnyHopMode = (BotSettings.BunnyHopMode)enumVal(tj, "bunnyHopMode", BotSettings.BunnyHopMode.class, team.bunnyHopMode);
            team.autoTarget = bool(tj, "autoTarget", team.autoTarget);
            team.targetPlayers = bool(tj, "targetPlayers", team.targetPlayers);
            team.targetBots = bool(tj, "targetBots", team.targetBots);
            team.targetMobs = bool(tj, "targetMobs", team.targetMobs);
            team.difficulty = (BotSettings.Difficulty)enumVal(tj, "difficulty", BotSettings.Difficulty.class, team.difficulty);
            team.difficultyParams = DifficultyParams.forPreset(team.difficulty);
            team.techniques.spearDash = bool(tj, "useSpearDash", team.techniques.spearDash);
            team.techniques.stunSlam = bool(tj, "useStunSlam", team.techniques.stunSlam);
            team.techniques.pearlCatch = bool(tj, "usePearlCatch", team.techniques.pearlCatch);
            team.techniques.pearlCatchGlide = bool(tj, "elytraGlide", team.techniques.pearlCatchGlide);
            if (tj.has("techniques") && tj.get("techniques").isJsonObject()) {
               team.techniques.readFrom(tj.getAsJsonObject("techniques"));
            }

            if (tj.has("difficultyParams") && tj.get("difficultyParams").isJsonObject()) {
               team.difficultyParams.readFrom(tj.getAsJsonObject("difficultyParams"));
            }

            if (tj.has("randomGearConfig") && tj.get("randomGearConfig").isJsonObject()) {
               team.randomGearConfig.readFrom(tj.getAsJsonObject("randomGearConfig"));
            }

            if (tj.has("stunSlamChance")) {
               team.difficultyParams.stunSlamChance = percent(tj, "stunSlamChance", team.difficultyParams.stunSlamChance);
            }

            team.useCarting = bool(tj, "useCarting", team.useCarting);
            team.bridgeMode = (BotSettings.BridgeMode)enumVal(tj, "bridgeMode", BotSettings.BridgeMode.class, team.bridgeMode);
            if (tj.has("attackRange")) {
               team.attackRange = tj.get("attackRange").getAsDouble();
            }

            team.cartMode = (BotSettings.CartMode)enumVal(tj, "cartMode", BotSettings.CartMode.class, team.cartMode);
            team.ignoreCreative = bool(tj, "ignoreCreative", team.ignoreCreative);
            team.useEnderPearl = bool(tj, "useEnderPearl", team.useEnderPearl);
            team.pearlChasing = bool(tj, "pearlChasing", team.pearlChasing);
            team.botLeaveOnDeath = bool(tj, "botLeaveOnDeath", team.botLeaveOnDeath);
            team.useScaffolding = bool(tj, "useScaffolding", team.useScaffolding);
            team.chorusEscape = bool(tj, "chorusEscape", team.chorusEscape);
            team.fireEscape = bool(tj, "fireEscape", team.fireEscape);
            team.shulkerSteal = bool(tj, "shulkerSteal", team.shulkerSteal);
            team.spreadOut = bool(tj, "spreadOut", team.spreadOut);
            team.shulkerRegear = bool(tj, "shulkerRegear", team.shulkerRegear);
            team.enderChestRegear = bool(tj, "enderChestRegear", team.enderChestRegear);
            if (migratingEnderRegear) {
               team.enderChestRegear = true;
            }

            team.webEscape = bool(tj, "webEscape", team.webEscape);
            team.waterBucketClutch = bool(tj, "waterBucketClutch", team.waterBucketClutch);
            team.hitWeb = bool(tj, "hitWeb", team.hitWeb);
            team.pickupLoot = bool(tj, "pickupLoot", team.pickupLoot);
            team.buildUpMinHeight = dbl(tj, "buildUpMinHeight", team.buildUpMinHeight);
            team.botPing = (int)Math.max((double)0.0F, Math.min((double)5000.0F, dbl(tj, "botPing", (double)team.botPing)));
            team.doBlockExplosion = bool(tj, "doBlockExplosion", team.doBlockExplosion);
            team.speedNoJump = bool(tj, "speedNoJump", team.speedNoJump);
            team.maceTotem = bool(tj, "maceTotem", team.maceTotem);
            team.chaseSpread = bool(tj, "chaseSpread", team.chaseSpread);
            team.placeBlocksMoving = bool(tj, "placeBlocksMoving", team.placeBlocksMoving);
            team.lootPackRadius = dbl(tj, "lootPackRadius", team.lootPackRadius);
            team.healingMode = (BotSettings.HealingMode)enumOr(tj, "healingMode", BotSettings.HealingMode.class, team.healingMode);
            team.offhandPreference = (BotSettings.OffhandPreference)enumOr(tj, "offhandPreference", BotSettings.OffhandPreference.class, team.offhandPreference);
            team.offhandTotemHearts = dbl(tj, "offhandTotemHearts", team.offhandTotemHearts);
            team.strafeInCombo = bool(tj, "strafeInCombo", team.strafeInCombo);
            loadRestockPlan(tj, team.getName());
            team.cartDoctrine = (BotSettings.CartDoctrine)enumOr(tj, "cartDoctrine", BotSettings.CartDoctrine.class, team.cartDoctrine);
            if (tj.has("tactics") && tj.get("tactics").isJsonObject()) {
               JsonObject tac = tj.getAsJsonObject("tactics");
               TeamTactics tc = team.tactics;
               tc.formation = (FollowFormation.Type)enumOr(tac, "formation", FollowFormation.Type.class, tc.formation);
               tc.formationSize = (int)dbl(tac, "formationSize", (double)tc.formationSize);
               tc.spacing = dbl(tac, "spacing", tc.spacing);
               if (tc.spacing == (double)1.5F && !tac.has("spacingMigrated")) {
                  tc.spacing = (double)2.0F;
               }

               tc.movementSpeed = dbl(tac, "movementSpeed", tc.movementSpeed);
               tc.boss = tac.has("boss") ? tac.get("boss").getAsString() : tc.boss;
               tc.protectBoss = bool(tac, "protectBoss", tc.protectBoss);
               tc.focusBossTarget = bool(tac, "focusBossTarget", tc.focusBossTarget);
               tc.followBoss = bool(tac, "followBoss", tc.followBoss);
               tc.maintainFormation = bool(tac, "maintainFormation", tc.maintainFormation);
               tc.retreatWhenLow = bool(tac, "retreatWhenLow", tc.retreatWhenLow);
               tc.shieldBehaviour = (TeamTactics.ShieldBehaviour)enumOr(tac, "shieldBehaviour", TeamTactics.ShieldBehaviour.class, tc.shieldBehaviour);
               tc.rangedPositioning = (TeamTactics.RangedPositioning)enumOr(tac, "rangedPositioning", TeamTactics.RangedPositioning.class, tc.rangedPositioning);
               tc.targetPriority = (TeamTactics.TargetPriority)enumOr(tac, "targetPriority", TeamTactics.TargetPriority.class, tc.targetPriority);
               tc.regroupDistance = dbl(tac, "regroupDistance", tc.regroupDistance);
               tc.maxDistanceFromBoss = dbl(tac, "maxDistanceFromBoss", tc.maxDistanceFromBoss);
               tc.hornPlayer = tac.has("hornPlayer") ? tac.get("hornPlayer").getAsString() : tc.hornPlayer;
               tc.hornType = tac.has("hornType") ? tac.get("hornType").getAsString() : tc.hornType;
               tc.hornFormation = (FollowFormation.Type)enumOr(tac, "hornFormation", FollowFormation.Type.class, tc.hornFormation);
            }

            team.useBows = bool(tj, "useBows", team.useBows);
            team.useOrbitalStrike = bool(tj, "useOrbitalStrike", team.useOrbitalStrike);
            team.retreatHealthHearts = dbl(tj, "retreatHealthHearts", team.retreatHealthHearts);
            team.wanderWhenIdle = bool(tj, "wanderWhenIdle", team.wanderWhenIdle);
            team.riptideAnywhere = bool(tj, "riptideAnywhere", team.riptideAnywhere);
            team.useElytraMace = bool(tj, "useElytraMace", team.useElytraMace);
            team.useElytraSpear = bool(tj, "useElytraSpear", team.useElytraSpear);
            team.fastShieldCooldown = bool(tj, "fastShieldCooldown", team.fastShieldCooldown);
            team.useSpearDash = bool(tj, "useSpearDash", team.useSpearDash);
            team.useStunSlam = bool(tj, "useStunSlam", team.useStunSlam);
            team.useWebDrain = bool(tj, "useWebDrain", team.useWebDrain);
            team.webDrainChance = percent(tj, "webDrainChance", team.webDrainChance);
            team.jumpResetChance = percent(tj, "jumpResetChance", team.jumpResetChance);
            team.counterStunChance = percent(tj, "counterStunChance", team.counterStunChance);
            team.shieldOnMaceDive = bool(tj, "shieldOnMaceDive", team.shieldOnMaceDive);
            team.usePearlCatch = bool(tj, "usePearlCatch", team.usePearlCatch);
            team.elytraGlide = bool(tj, "elytraGlide", team.elytraGlide);
         }
      }

   }

   private static boolean bool(JsonObject obj, String key, boolean fallback) {
      return obj.has(key) ? obj.get(key).getAsBoolean() : fallback;
   }

   private static int percent(JsonObject obj, String key, int fallback) {
      if (!obj.has(key)) {
         return fallback;
      } else {
         int v = obj.get(key).getAsInt();
         return Math.clamp((long)v, 0, 100);
      }
   }

   private static void loadRestockPlan(JsonObject obj, String teamName) {
      if (obj != null && obj.has("restockPlan") && obj.get("restockPlan").isJsonObject()) {
         Map<String, Integer> m = new LinkedHashMap();

         for(Map.Entry<String, JsonElement> e : obj.getAsJsonObject("restockPlan").entrySet()) {
            try {
               m.put((String)e.getKey(), ((JsonElement)e.getValue()).getAsInt());
            } catch (Exception var6) {
            }
         }

         RestockPlan.load(teamName, m);
      }
   }

   private static <E extends Enum<E>> E enumOr(JsonObject obj, String key, Class<E> type, E fallback) {
      if (obj != null && obj.has(key)) {
         try {
            return (E)Enum.valueOf(type, obj.get(key).getAsString().toUpperCase(Locale.ROOT));
         } catch (Exception var5) {
            return fallback;
         }
      } else {
         return fallback;
      }
   }

   private static double dbl(JsonObject obj, String key, double fallback) {
      try {
         return obj.has(key) ? obj.get(key).getAsDouble() : fallback;
      } catch (RuntimeException var5) {
         return fallback;
      }
   }

   private static <E extends Enum<E>> E enumVal(JsonObject obj, String key, Class<E> cls, E fallback) {
      if (!obj.has(key)) {
         return fallback;
      } else {
         try {
            return (E)Enum.valueOf(cls, obj.get(key).getAsString());
         } catch (IllegalArgumentException var5) {
            return fallback;
         }
      }
   }
}
