package vexbot.combat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import vexbot.compat.McCompat;

public final class CombatRecorder {
   private static final double FOCUS_RANGE = (double)48.0F;
   private static final int MAX_ROWS = 400000;
   private static final String HEADER = "tick,kind,name,isBot,x,y,z,yaw,pitch,health,blocking,sprinting,onGround,attackCharge,target,damage,crit,targetBlocking";
   private static volatile boolean recording = false;
   private static boolean capped = false;
   private static String focusName = null;
   private static int tick = 0;
   private static long startMillis = 0L;
   private static final List<String> rows = new ArrayList();
   private static final Map<String, Boolean> prevShieldHeld = new HashMap();

   private CombatRecorder() {
   }

   public static synchronized boolean isRecording() {
      return recording;
   }

   public static synchronized void start(String focus, long nowMillis) {
      recording = true;
      capped = false;
      focusName = focus;
      tick = 0;
      startMillis = nowMillis;
      rows.clear();
      prevShieldHeld.clear();
      rows.add("tick,kind,name,isBot,x,y,z,yaw,pitch,health,blocking,sprinting,onGround,attackCharge,target,damage,crit,targetBlocking");
   }

   public static synchronized String stop(MinecraftServer server) {
      if (!recording) {
         return null;
      } else {
         recording = false;
         capped = false;
         if (rows.size() <= 1) {
            rows.clear();
            return null;
         } else {
            try {
               Path dir = server.getServerDirectory().resolve("vexbot-recordings");
               Files.createDirectories(dir);
               Path file = dir.resolve("combat-" + startMillis + ".csv");
               Files.write(file, rows);
               rows.clear();
               return file.toString();
            } catch (IOException e) {
               rows.clear();
               return "ERROR: " + e.getMessage();
            }
         }
      }
   }

   public static synchronized void onServerTick(MinecraftServer server) {
      if (recording && !capped) {
         ++tick;
         ServerPlayer focus = focusName != null ? server.getPlayerList().getPlayerByName(focusName) : null;
         Vec3 center = focus != null ? focus.position() : null;

         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isAlive()) {
               boolean isFocus = p.getName().getString().equals(focusName);
               if (center == null || isFocus || !(p.position().distanceToSqr(center) > (double)2304.0F)) {
                  recordState(p);
               }
            }
         }

         if (rows.size() >= 400000) {
            capped = true;
         }

      }
   }

   public static synchronized void logHit(ServerPlayer attacker, ServerPlayer victim, float damage) {
      if (recording && !capped) {
         boolean crit = !attacker.onGround() && attacker.getDeltaMovement().y < (double)0.0F && attacker.fallDistance > (double)0.0F && !attacker.isInWater();
         rows.add(row("HIT", attacker, victim.getName().getString(), damage, crit, victim.isBlocking()));
      }
   }

   private static void recordState(ServerPlayer p) {
      String name = p.getName().getString();
      boolean shieldHeld = p.isUsingItem() && p.getUseItem().is(Items.SHIELD);
      Boolean prev = (Boolean)prevShieldHeld.get(name);
      if (prev == null || prev != shieldHeld) {
         prevShieldHeld.put(name, shieldHeld);
         if (prev != null) {
            rows.add(row(shieldHeld ? "SHIELD_UP" : "SHIELD_DOWN", p, "", 0.0F, false, false));
         }
      }

      rows.add(row("STATE", p, "", 0.0F, false, false));
   }

   private static String row(String kind, ServerPlayer p, String target, float damage, boolean crit, boolean targetBlocking) {
      boolean isBot = McCompat.tags(p).contains("vexbot");
      boolean isEvent = !kind.equals("STATE");
      boolean isHit = kind.equals("HIT");
      return String.join(",", Integer.toString(tick), kind, csv(p.getName().getString()), Boolean.toString(isBot), f(p.getX()), f(p.getY()), f(p.getZ()), f((double)p.getYRot()), f((double)p.getXRot()), f((double)p.getHealth()), Boolean.toString(p.isBlocking()), Boolean.toString(p.isSprinting()), Boolean.toString(p.onGround()), f((double)p.getAttackStrengthScale(0.0F)), csv(target), isHit ? f((double)damage) : "", isHit ? Boolean.toString(crit) : "", isEvent && isHit ? Boolean.toString(targetBlocking) : "");
   }

   private static String f(double v) {
      return String.format(Locale.ROOT, "%.3f", v);
   }

   private static String csv(String s) {
      return s == null ? "" : s.replace(",", "_");
   }
}
