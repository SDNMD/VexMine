package vexbot.gui;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class AdvancedTeamSettingsMenu {
   private AdvancedTeamSettingsMenu() {
   }

   public static void open(ServerPlayer viewer, MinecraftServer server, String teamName) {
      TeamSettingsMenu.openBattleOrders(viewer, teamName);
   }
}
