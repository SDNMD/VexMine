package vexbot.gui;

import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.util.EquipmentSync;

public class InventoryViewMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int GUI_LABEL = 36;
   private static final int GUI_HELMET = 37;
   private static final int GUI_CHEST = 38;
   private static final int GUI_LEGS = 39;
   private static final int GUI_BOOTS = 40;
   private static final int GUI_SEP = 41;
   private static final int GUI_OFFHAND = 42;
   private final SimpleContainer decor = new SimpleContainer(54);
   private final MinecraftServer server;
   private final UUID targetId;

   private static boolean isDecor(int guiSlot) {
      return guiSlot == 36 || guiSlot == 41 || guiSlot == 43 || guiSlot == 44 || guiSlot >= 45 && guiSlot < 54;
   }

   private static int invIndex(int guiSlot) {
      if (guiSlot >= 0 && guiSlot < 27) {
         return 9 + guiSlot;
      } else if (guiSlot >= 27 && guiSlot < 36) {
         return guiSlot - 27;
      } else {
         byte var10000;
         switch (guiSlot) {
            case 37:
               var10000 = 39;
               break;
            case 38:
               var10000 = 38;
               break;
            case 39:
               var10000 = 37;
               break;
            case 40:
               var10000 = 36;
               break;
            case 41:
            default:
               var10000 = -1;
               break;
            case 42:
               var10000 = 40;
         }

         return var10000;
      }
   }

   public InventoryViewMenu(int containerId, Inventory viewerInventory, MinecraftServer server, ServerPlayer target) {
      super(MenuType.GENERIC_9x6, containerId, viewerInventory);
      BukkitCompat.setMenuPlayer(this, viewerInventory);
      this.server = server;
      this.targetId = target.getUUID();
      this.buildStaticDecor(target);
      Inventory targetInv = target.getInventory();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            int gui = col + row * 9;
            int x = 8 + col * 18;
            int y = 18 + row * 18;
            int idx = invIndex(gui);
            this.addSlot((Slot)(idx < 0 ? new KitListMenu.LockedSlot(this.decor, gui, x, y) : new Slot(targetInv, idx, x, y)));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(viewerInventory, col + row * 9 + 9, 8 + col * 18, 103 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(viewerInventory, col, 8 + col * 18, 161));
      }

   }

   private void buildStaticDecor(ServerPlayer target) {
      ItemStack fill = KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), " ");
      String tag = McCompat.tags(target).contains("vexbot") ? " §7(VexBot)" : "";
      this.decor.setItem(36, KitListMenu.makeItem(Items.PLAYER_HEAD, "§f" + target.getName().getString() + tag, "§7Live inventory — §aeditable", "§7Drop items in or take them out;", "§7the bot has them straight away."));
      this.decor.setItem(41, fill.copy());
      this.decor.setItem(43, fill.copy());
      this.decor.setItem(44, fill.copy());

      for(int i = 45; i < 54; ++i) {
         this.decor.setItem(i, fill.copy());
      }

   }

   private ServerPlayer target() {
      return this.server.getPlayerList().getPlayer(this.targetId);
   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (slotId < 0 || slotId >= 54 || !isDecor(slotId)) {
         this.vanillaClick(slotId, button, player);
         this.syncEquipment();
      }
   }

   private void syncEquipment() {
      ServerPlayer t = this.target();
      if (t != null) {
         EquipmentSync.syncNow(t);
      }

   }

   public ItemStack quickMoveStack(Player player, int index) {
      Slot slot = (Slot)this.slots.get(index);
      if (slot != null && slot.hasItem()) {
         if (index >= 0 && index < 54 && isDecor(index)) {
            return ItemStack.EMPTY;
         } else {
            ItemStack stack = slot.getItem();
            ItemStack copy = stack.copy();
            int botEnd = 54;
            if (index < botEnd) {
               if (!this.moveItemStackTo(stack, botEnd, this.slots.size(), true)) {
                  return ItemStack.EMPTY;
               }
            } else if (!this.moveItemStackTo(stack, 0, 36, false)) {
               return ItemStack.EMPTY;
            }

            if (stack.isEmpty()) {
               slot.set(ItemStack.EMPTY);
            } else {
               slot.setChanged();
            }

            this.syncEquipment();
            return copy;
         }
      } else {
         return ItemStack.EMPTY;
      }
   }

   public boolean stillValid(Player player) {
      ServerPlayer target = this.target();
      return target != null && target.isAlive();
   }
}
