package vexbot.gui;

import java.util.Arrays;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import vexbot.SettingsPersistence;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;

public final class TeamDeleteConfirmMenu extends VexMenu {
   private static final int SIZE = 27;
   private static final int SLOT_CONFIRM = 11;
   private static final int SLOT_CANCEL = 15;
   private final SimpleContainer container = new SimpleContainer(27);
   private final String teamName;

   public TeamDeleteConfirmMenu(int containerId, Inventory playerInventory, String teamName) {
      super(MenuType.GENERIC_9x3, containerId, playerInventory);
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.teamName = teamName;
      ItemStack filler = makeItem(McCompat.pane(DyeColor.GRAY), " ");

      for(int i = 0; i < 27; ++i) {
         this.container.setItem(i, filler.copy());
      }

      this.container.setItem(11, makeItem(McCompat.pane(DyeColor.LIME), "§a✔ Confirm Delete", "§7This will permanently delete", "§7team §e" + teamName + "§7.", "§cThis cannot be undone!"));
      this.container.setItem(13, makeItem(Items.BARRIER, "§c⚠ Delete Team: §e" + teamName, "§7Are you sure you want to", "§7delete this team?"));
      this.container.setItem(15, makeItem(McCompat.pane(DyeColor.RED), "§c✖ Cancel", "§7Keep the team."));

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
      }

   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (slotId == 11) {
         TeamManager.delete(this.teamName);
         if (player instanceof ServerPlayer) {
            ServerPlayer sp = (ServerPlayer)player;
            ServerLevel sl = sp.level();
            if (sl instanceof ServerLevel) {
               MinecraftServer srv = sl.getServer();
               if (srv != null) {
                  SettingsPersistence.save(srv);
               }

               sp.sendSystemMessage(VexText.literal("[VexBot] §aDeleted team §e" + this.teamName + "§a. (Its bots are still in the world.)"));
            }
         }

         player.closeContainer();
      } else if (slotId == 15) {
         player.closeContainer();
      } else {
         this.vanillaClick(slotId, button, player);
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int i) {
      return ItemStack.EMPTY;
   }

   private static ItemStack makeItem(Item item, String name, String... lore) {
      ItemStack stack = new ItemStack(item);
      stack.set(DataComponents.CUSTOM_NAME, VexText.literal(name).setStyle(Style.EMPTY.withItalic(false)));
      if (lore.length > 0) {
         List<Component> lines = Arrays.stream(lore).map((l) -> VexText.literal(l).setStyle(Style.EMPTY.withItalic(false))).toList();
         stack.set(DataComponents.LORE, new ItemLore(lines));
      }

      return stack;
   }

   private static final class LockedSlot extends Slot {
      LockedSlot(SimpleContainer c, int i, int x, int y) {
         super(c, i, x, y);
      }

      public boolean mayPickup(Player p) {
         return false;
      }

      public boolean mayPlace(ItemStack s) {
         return false;
      }
   }
}
