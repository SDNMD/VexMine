package vexbot.gui;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.kit.KitCli;
import vexbot.kit.KitManager;
import vexbot.kit.KitPotion;
import vexbot.kit.KitShareCodec;
import vexbot.team.TeamManager;

public class KitListMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int GRID_SLOTS = 45;
   private static final int SLOT_PREV = 45;
   private static final int SLOT_INFO = 49;
   private static final int SLOT_NEXT = 53;
   private final SimpleContainer container;
   private final MinecraftServer server;
   private final Mode mode;
   private final List<String> kits;
   private final String teamName;
   private int page;

   public KitListMenu(int containerId, Inventory playerInventory, MinecraftServer server, Mode mode) {
      this(containerId, playerInventory, server, mode, 0, (String)null);
   }

   public KitListMenu(int containerId, Inventory playerInventory, MinecraftServer server, Mode mode, int startPage) {
      this(containerId, playerInventory, server, mode, startPage, (String)null);
   }

   public KitListMenu(int containerId, Inventory playerInventory, MinecraftServer server, String teamName) {
      this(containerId, playerInventory, server, KitListMenu.Mode.GIVE_TEAM, 0, teamName);
   }

   public KitListMenu(int containerId, Inventory playerInventory, MinecraftServer server, Mode mode, int startPage, String teamName) {
      super(MenuType.GENERIC_9x6, containerId, playerInventory);
      this.container = new SimpleContainer(54);
      this.page = 0;
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.server = server;
      this.mode = mode;
      this.kits = KitManager.list(server);
      this.page = startPage;
      this.teamName = teamName;
      this.refresh();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 103 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 161));
      }

   }

   private void refresh() {
      ItemStack filler = makeItem(McCompat.pane(DyeColor.GRAY), " ");

      for(int i = 45; i < 54; ++i) {
         this.container.setItem(i, filler.copy());
      }

      int totalPages = Math.max(1, (int)Math.ceil((double)this.kits.size() / (double)45.0F));
      this.container.setItem(49, makeItem(Items.PAPER, "§fPage §e" + (this.page + 1) + " §f/ §e" + totalPages, "§7" + this.kits.size() + " kit(s) saved"));
      this.container.setItem(45, this.page > 0 ? makeItem(Items.ARROW, "§f« Previous page") : filler.copy());
      this.container.setItem(53, this.page + 1 < totalPages ? makeItem(Items.ARROW, "§fNext page »") : filler.copy());
      int start = this.page * 45;

      for(int i = 0; i < 45; ++i) {
         int idx = start + i;
         if (idx < this.kits.size()) {
            String name = (String)this.kits.get(idx);
            int count = KitManager.countItems(this.server, name);
            ItemStack iconStack = KitManager.loadIcon(this.server, name);
            if (this.mode == KitListMenu.Mode.DELETE) {
               this.container.setItem(i, applyLabel(iconStack, "§e§l" + name, "§7" + count + " item(s)", "§c§lClick to delete"));
            } else if (this.mode == KitListMenu.Mode.GIVE_TEAM) {
               TeamManager.BotTeam team = TeamManager.get(this.teamName);
               int botCount = team != null ? team.getBotNames().size() : 0;
               int humCount = team != null ? team.getPlayerNames().size() : 0;
               this.container.setItem(i, applyLabel(iconStack, "§e§l" + name, "§7" + count + " item(s)", "§a§lClick to give to team §e§l" + this.teamName, "§7" + botCount + " bot(s), §f" + humCount + " §7player(s) on roster"));
            } else if (this.mode == KitListMenu.Mode.GIVE_ALL) {
               int online = this.countOnlineRecipients();
               this.container.setItem(i, applyLabel(iconStack, "§e§l" + name, "§7" + count + " item(s)", "§a§lClick to give to everyone online", "§7" + online + " §7player(s) + bot(s) in world"));
            } else if (this.mode == KitListMenu.Mode.ICON) {
               String iconHint = iconStack.isEmpty() ? "§7No icon set" : "§7Icon: §f" + iconStack.getHoverName().getString();
               this.container.setItem(i, applyLabel(iconStack, "§e§l" + name, "§7" + count + " item(s)", iconHint, "§e§lClick to set icon"));
            } else if (this.mode == KitListMenu.Mode.GET_ID) {
               this.container.setItem(i, applyLabel(iconStack, "§e§l" + name, "§7" + count + " item(s)", "§b§lClick to get kit ID", "§7Posts a shareable kit ID to chat"));
            } else {
               this.container.setItem(i, applyLabel(iconStack, "§e§l" + name, "§7" + count + " item(s)", "§a§lClick to give", "§7Shift-click for §5Kit Potion"));
            }
         } else {
            this.container.setItem(i, ItemStack.EMPTY);
         }
      }

   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (player instanceof ServerPlayer sp) {
         if (slotId < 0 || slotId >= 54 || this.isPlainClick()) {
            if (slotId == 45 && this.page > 0) {
               --this.page;
               this.refresh();
               this.sendAllDataToRemote();
            } else {
               if (slotId == 53) {
                  int totalPages = (int)Math.ceil((double)this.kits.size() / (double)45.0F);
                  if (this.page + 1 < totalPages) {
                     ++this.page;
                     this.refresh();
                     this.sendAllDataToRemote();
                     return;
                  }
               }

               if (slotId >= 0 && slotId < 45) {
                  int idx = this.page * 45 + slotId;
                  if (idx >= this.kits.size()) {
                     return;
                  }

                  String kitName = (String)this.kits.get(idx);
                  if ((this.mode == KitListMenu.Mode.GIVE || this.mode == KitListMenu.Mode.GIVE_ALL) && quickMove) {
                     ItemStack potion = KitPotion.create(kitName);
                     if (!sp.getInventory().add(potion)) {
                        McCompat.drop(sp, potion, false);
                     }

                     return;
                  }

                  if (this.mode == KitListMenu.Mode.DELETE) {
                     sp.openMenu(new SimpleMenuProvider((idxx, inv, p) -> new KitDeleteConfirmMenu(idxx, inv, this.server, kitName), VexText.literal("§cDelete Kit: §e" + kitName)));
                  } else if (this.mode == KitListMenu.Mode.GIVE_TEAM) {
                     this.giveKitToTeam(sp, kitName);
                  } else if (this.mode == KitListMenu.Mode.GIVE_ALL) {
                     this.giveKitToEveryone(sp, kitName);
                  } else if (this.mode == KitListMenu.Mode.ICON) {
                     sp.openMenu(new SimpleMenuProvider((idxx, inv, p) -> new KitIconPickMenu(idxx, inv, this.server, kitName, this.page), VexText.literal("§6Set Icon: §e" + kitName)));
                  } else if (this.mode == KitListMenu.Mode.GET_ID) {
                     sp.closeContainer();
                     String id = KitShareCodec.encode(this.server, kitName);
                     if (id == null) {
                        sp.sendSystemMessage(VexText.literal(sp, "[VexBot] Could not encode kit '§e" + kitName + "§r'."));
                        return;
                     }

                     KitCli.sendKitIdMessage(sp.createCommandSourceStack(), kitName, id);
                  } else {
                     int currentPage = this.page;
                     sp.openMenu(new SimpleMenuProvider((idxx, inv, p) -> new PlayerSelectMenu(idxx, inv, this.server, kitName, currentPage), VexText.literal("§aGive Kit: §e" + kitName)));
                  }
               }

               this.vanillaClick(slotId, button, player);
            }
         }
      }
   }

   private void giveKitToTeam(ServerPlayer requester, String kitName) {
      KitCli.giveToTeam(requester.createCommandSourceStack(), this.server, this.teamName, kitName);
   }

   private void giveKitToEveryone(ServerPlayer requester, String kitName) {
      KitCli.giveToAll(requester.createCommandSourceStack(), this.server, kitName);
   }

   private int countOnlineRecipients() {
      int n = 0;
      Set<UUID> seen = new HashSet();

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (p.isAlive() && !p.isSpectator() && seen.add(p.getUUID())) {
            ++n;
         }
      }

      return n;
   }

   public int getPage() {
      return this.page;
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int index) {
      return ItemStack.EMPTY;
   }

   static ItemStack applyLabel(ItemStack icon, String name, String... lore) {
      ItemStack stack = icon.isEmpty() ? new ItemStack(Items.CHEST) : icon.copyWithCount(1);
      stack.set(DataComponents.CUSTOM_NAME, VexText.literal(name).setStyle(Style.EMPTY.withItalic(false)));
      if (lore.length > 0) {
         List<Component> lines = Arrays.stream(lore).map((l) -> VexText.literal(l).setStyle(Style.EMPTY.withItalic(false))).toList();
         stack.set(DataComponents.LORE, new ItemLore(lines));
      }

      return stack;
   }

   static ItemStack makeItem(Item item, String name, String... lore) {
      ItemStack stack = new ItemStack(item);
      stack.set(DataComponents.CUSTOM_NAME, VexText.literal(name).setStyle(Style.EMPTY.withItalic(false)));
      if (lore.length > 0) {
         List<Component> lines = Arrays.stream(lore).map((l) -> VexText.literal(l).setStyle(Style.EMPTY.withItalic(false))).toList();
         stack.set(DataComponents.LORE, new ItemLore(lines));
      }

      return stack;
   }

   public static enum Mode {
      DELETE,
      GIVE,
      GIVE_TEAM,
      GIVE_ALL,
      ICON,
      GET_ID;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{DELETE, GIVE, GIVE_TEAM, GIVE_ALL, ICON, GET_ID};
      }
   }

   static final class LockedSlot extends Slot {
      LockedSlot(SimpleContainer c, int idx, int x, int y) {
         super(c, idx, x, y);
      }

      public boolean mayPickup(Player p) {
         return false;
      }

      public boolean mayPlace(ItemStack s) {
         return false;
      }
   }
}
