package vexbot.gui;

import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import vexbot.compat.VexMenuBase;
import vexbot.i18n.VexText;

public class EnderChestViewMenu extends VexMenuBase {
   private static final int ROWS = 3;
   private final UUID targetId;
   private final String targetName;
   private final MinecraftServer server;
   private final Container ender;

   public EnderChestViewMenu(int containerId, Inventory viewerInventory, ServerPlayer target) {
      super(MenuType.GENERIC_9x3, containerId, viewerInventory);
      BukkitCompat.setMenuPlayer(this, viewerInventory);
      this.targetId = target.getUUID();
      this.targetName = target.getGameProfile().name();
      this.server = target.level().getServer();
      this.ender = target.getEnderChestInventory();

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(this.ender, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(viewerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(viewerInventory, col, 8 + col * 18, 142));
      }

   }

   public String targetName() {
      return this.targetName;
   }

   public boolean stillValid(Player player) {
      if (this.server == null) {
         return false;
      } else {
         ServerPlayer t = this.server.getPlayerList().getPlayer(this.targetId);
         return t != null && !t.isRemoved() && t.getEnderChestInventory() == this.ender;
      }
   }

   public ItemStack quickMoveStack(Player player, int index) {
      Slot slot = (Slot)this.slots.get(index);
      if (slot != null && slot.hasItem()) {
         ItemStack stack = slot.getItem();
         ItemStack copy = stack.copy();
         int chestEnd = 27;
         if (index < chestEnd) {
            if (!this.moveItemStackTo(stack, chestEnd, this.slots.size(), true)) {
               return ItemStack.EMPTY;
            }
         } else if (!this.moveItemStackTo(stack, 0, chestEnd, false)) {
            return ItemStack.EMPTY;
         }

         if (stack.isEmpty()) {
            slot.set(ItemStack.EMPTY);
         } else {
            slot.setChanged();
         }

         return copy;
      } else {
         return ItemStack.EMPTY;
      }
   }

   public static Component title(String name) {
      return VexText.literal("Ender chest: " + name);
   }
}
