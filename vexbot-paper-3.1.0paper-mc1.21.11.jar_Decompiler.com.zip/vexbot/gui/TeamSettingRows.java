package vexbot.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Consumer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import vexbot.BotSettings;
import vexbot.DifficultyKnobs;
import vexbot.DifficultyParams;
import vexbot.bot.ai.FollowFormation;
import vexbot.i18n.VexText;
import vexbot.settings.GameplaySettingsScope;
import vexbot.settings.SettingsCli;
import vexbot.team.TeamCommand;
import vexbot.team.TeamFormationOrders;
import vexbot.team.TeamHornSummon;
import vexbot.team.TeamManager;
import vexbot.team.TeamTactics;

final class TeamSettingRows {
   static final Set<String> SERVER_WIDE = Set.of("stats", "gamelogs", "botdontleave", "botadvancements", "botspawnmobs", "kitpotiondosplash", "gotomining", "advancedspawn", "silent", "tags");
   private static final Set<String> HIDDEN = Set.of("stunslamchance");
   private static final Map<String, Category> CATEGORY_OF;

   private TeamSettingRows() {
   }

   static String norm(String s) {
      return s.toLowerCase(Locale.ROOT).replace('-', ' ').replace('_', ' ').replace("§", " ");
   }

   private static Category techniqueCategory(String key) {
      String group = SettingsCli.techniqueCategory(key);
      if (group == null) {
         return TeamSettingRows.Category.OTHER;
      } else {
         Category var10000;
         switch (group) {
            case "movement":
            case "pearl":
               var10000 = TeamSettingRows.Category.MOVEMENT;
               break;
            case "anti-shield":
            case "finishers":
               var10000 = TeamSettingRows.Category.COMBAT;
               break;
            default:
               var10000 = TeamSettingRows.Category.WEAPONS;
         }

         return var10000;
      }
   }

   static List<Row> build(MinecraftServer server, TeamManager.BotTeam team) {
      List<Row> out = new ArrayList(160);
      orders(out, team);
      horn(out, server, team);
      gameplay(out, team);
      targetingLinks(out, server, team);
      difficulty(out, team);
      teamRows(out, server, team);
      return out;
   }

   private static void orders(List<Row> out, TeamManager.BotTeam team) {
      TeamTactics tc = team.tactics;
      TeamTactics def = new TeamTactics();
      Category c = TeamSettingRows.Category.ORDERS;
      Item var10005 = Items.ARMOR_STAND;
      String var10006 = pretty(tc.formation.name());
      boolean var10007 = tc.formation != def.formation;
      String var10008 = String.join(", ", FollowFormation.names());
      out.add(choice("order:formation", c, "Formation", "The shape the team holds while it escorts its boss or answers a horn. None means no formation: the team fights freely.", var10005, var10006, var10007, "§8Options: " + var10008, (m, right, shift) -> {
         tc.formation = (FollowFormation.Type)cycle(tc.formation, right);
         return null;
      }, "shape line wall circle square column rows triangle grid hexagon none free"));
      out.add(number("order:formationsize", c, "Row Width", "How many bots stand side by side in each row of the formation.", Items.PAPER, String.valueOf(tc.formationSize), tc.formationSize != def.formationSize, "§8Left +1 · Right −1 · Shift ±5", (m, right, shift) -> {
         tc.formationSize = clampInt(tc.formationSize, right, shift ? 5 : 1, 1, 50);
         return null;
      }, "formation size width per row"));
      out.add(number("order:spacing", c, "Spacing", "Blocks between neighbouring bots in the formation. 2 is the classic gap.", Items.STRING, fmt1(tc.spacing), tc.spacing != def.spacing, "§8Left +0.5 · Right −0.5 · Shift ±1", (m, right, shift) -> {
         tc.spacing = clamp(tc.spacing, right, shift ? (double)1.0F : (double)0.5F, (double)0.5F, (double)6.0F);
         return null;
      }, "gap distance apart"));
      var10005 = Items.SUGAR;
      var10006 = fmt1(tc.movementSpeed);
      out.add(number("order:speed", c, "Movement Speed", "How fast the formation marches. Below 1 the team walks slower and never sprints; above 1 it sprints the whole way; from 1.5 it sprint-jumps.", var10005, var10006 + "x", tc.movementSpeed != def.movementSpeed, "§8Left +0.1 · Right −0.1 · Shift ±0.5", (m, right, shift) -> {
         tc.movementSpeed = clamp(tc.movementSpeed, right, shift ? (double)0.5F : 0.1, (double)0.5F, (double)2.0F);
         return null;
      }, "march pace sprint walk slow fast"));
      out.add(new Row("order:boss", c, "Boss", "The bot or player the team is built around. Follow Boss, Protect Boss, Focus Boss Target and the boss target priorities all need one.", Items.GOLDEN_HELMET, TeamSettingRows.Kind.LINK, tc.hasBoss(), tc.hasBoss() ? tc.boss : "none", tc.hasBoss(), "§8Left: pick the boss · Right: clear it", (m, right, shift) -> {
         if (right) {
            tc.boss = "";
            return "§7Boss cleared.";
         } else {
            m.showPicker("Pick the boss", () -> bossOptions(m.server(), team));
            return null;
         }
      }, "leader king captain general"));
      out.add(toggle("order:followboss", c, "Follow Boss", "Everyone else escorts the boss in the team's formation, fights whoever hits them or the boss, then returns to their slot. Needs a boss and a formation.", Items.LEAD, tc.followBoss, tc.followBoss != def.followBoss, (v) -> tc.followBoss = v, "escort bodyguard travel with"));
      out.add(toggle("order:protectboss", c, "Protect Boss", "Whoever hits the boss becomes the whole team's target.", Items.SHIELD, tc.protectBoss, tc.protectBoss != def.protectBoss, (v) -> tc.protectBoss = v, "defend guard attacker"));
      out.add(toggle("order:focusbosstarget", c, "Focus Boss Target", "Everyone joins whatever fight the boss is in.", Items.SPYGLASS, tc.focusBossTarget, tc.focusBossTarget != def.focusBossTarget, (v) -> tc.focusBossTarget = v, "focus fire assist"));
      out.add(toggle("order:maintainformation", c, "Maintain Formation", "Bots fight from their slot and return to it, instead of breaking off to chase.", Items.IRON_BARS, tc.maintainFormation, tc.maintainFormation != def.maintainFormation, (v) -> tc.maintainFormation = v, "hold line keep slot"));
      out.add(toggle("order:retreatwhenlow", c, "Retreat When Low", "Every bot on the team pulls back to heal when it gets low, whatever its playstyle or Retreat setting says.", Items.GOLDEN_CARROT, tc.retreatWhenLow, tc.retreatWhenLow != def.retreatWhenLow, (v) -> tc.retreatWhenLow = v, "heal fall back low health"));
      out.add(choice("order:shield", c, "Shield Behaviour", "Free: shields as normal. Shields Up: raised while holding the formation or with an enemy near. Shield Wall: raised and crouched, a slow advancing wall.", Items.SHIELD, pretty(tc.shieldBehaviour.name()), tc.shieldBehaviour != def.shieldBehaviour, "§8Left: next · Right: previous", (m, right, shift) -> {
         tc.shieldBehaviour = (TeamTactics.ShieldBehaviour)cycle(tc.shieldBehaviour, right);
         return null;
      }, "shields up wall block"));
      out.add(choice("order:ranged", c, "Ranged Positioning", "Where bots with a bow or crossbow and no melee weapon stand: anywhere, in the back rows, or in the middle of a square, circle or hexagon.", Items.BOW, pretty(tc.rangedPositioning.name()), tc.rangedPositioning != def.rangedPositioning, "§8Left: next · Right: previous", (m, right, shift) -> {
         tc.rangedPositioning = (TeamTactics.RangedPositioning)cycle(tc.rangedPositioning, right);
         return null;
      }, "archers bows crossbows back inside"));
      out.add(choice("order:priority", c, "Target Priority", "Independent: each bot picks its own fight. Boss Target: everyone fights whoever the boss is fighting. Weakest: everyone converges on the lowest-health enemy near the boss. Boss Attacker: everyone turns on whoever last hit the boss.", Items.IRON_SWORD, pretty(tc.targetPriority.name()), tc.targetPriority != def.targetPriority, "§8Left: next · Right: previous", (m, right, shift) -> {
         tc.targetPriority = (TeamTactics.TargetPriority)cycle(tc.targetPriority, right);
         return null;
      }, "focus weakest attacker independent"));
      int var7 = (int)tc.regroupDistance;
      out.add(number("order:regroup", c, "Regroup Distance", "With Maintain Formation on, a bot chasing a fight gives up once it is this many blocks from the boss and goes back to its slot.", Items.COMPASS, var7 + " blocks", tc.regroupDistance != def.regroupDistance, "§8Left +1 · Right −1 · Shift ±5", (m, right, shift) -> {
         tc.regroupDistance = clamp(tc.regroupDistance, right, shift ? (double)5.0F : (double)1.0F, (double)4.0F, (double)64.0F);
         return null;
      }, "chase leash return"));
      var7 = (int)tc.maxDistanceFromBoss;
      out.add(number("order:maxdistance", c, "Max Distance From Boss", "With Follow Boss on, a bot further than this from the boss stops whatever it is doing and walks back.", Items.LEAD, var7 + " blocks", tc.maxDistanceFromBoss != def.maxDistanceFromBoss, "§8Left +1 · Right −1 · Shift ±5", (m, right, shift) -> {
         tc.maxDistanceFromBoss = clamp(tc.maxDistanceFromBoss, right, shift ? (double)5.0F : (double)1.0F, (double)4.0F, (double)128.0F);
         return null;
      }, "leash range far"));
      out.add(gesture(c, TeamTactics.GroupAction.JUMP, "Everyone: Jump", Items.SLIME_BALL, "The whole team jumps once."));
      out.add(gesture(c, TeamTactics.GroupAction.SWING, "Everyone: Swing", Items.WOODEN_SWORD, "The whole team swings its arm once. Nobody gets hit."));
      out.add(gesture(c, TeamTactics.GroupAction.CROUCH, "Everyone: Crouch / Stand", Items.LEATHER_LEGGINGS, "Every bot on the team toggles crouching."));
      out.add(gesture(c, TeamTactics.GroupAction.WAVE, "Everyone: Wave", Items.FEATHER, "The whole team swings and jumps together."));
   }

   private static Row gesture(Category c, TeamTactics.GroupAction a, String name, Item icon, String desc) {
      return new Row("order:gesture:" + a.name().toLowerCase(Locale.ROOT), c, name, desc, icon, TeamSettingRows.Kind.ACTION, false, (String)null, false, "§8Click to do it now", (m, right, shift) -> {
         int n = TeamFormationOrders.groupAction(m.server(), m.teamName(), a);
         return n == 0 ? "§7No bots of this team are in the world." : null;
      }, "gesture parade emote group action");
   }

   private static List<Row> bossOptions(MinecraftServer server, TeamManager.BotTeam team) {
      TeamTactics tc = team.tactics;
      List<Row> out = new ArrayList();
      out.add(pick("pick:boss:none", "No boss", "The team has no boss.", Items.BARRIER, !tc.hasBoss(), (m, right, shift) -> {
         tc.boss = "";
         m.back();
         return "§7Boss cleared.";
      }));
      Set<String> seen = new TreeSet(String.CASE_INSENSITIVE_ORDER);

      for(String bot : new TreeSet(team.getBotNames())) {
         if (seen.add(bot)) {
            out.add(bossOption(tc, bot, "§8Bot on this team"));
         }
      }

      for(String human : new TreeSet(team.getPlayerNames())) {
         if (seen.add(human)) {
            out.add(bossOption(tc, human, "§8Player on this team"));
         }
      }

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         String n = p.getName().getString();
         if (PlayerMenuHelper.isRealPlayer(p) && seen.add(n)) {
            out.add(bossOption(tc, n, "§8Online player, not on this team"));
         }
      }

      return out;
   }

   private static Row bossOption(TeamTactics tc, String name, String what) {
      boolean current = name.equalsIgnoreCase(tc.boss);
      return pick("pick:boss:" + name, name, what, Items.PLAYER_HEAD, current, (m, right, shift) -> {
         tc.boss = name;
         m.back();
         return "§7Boss is now §e" + name + "§7.";
      });
   }

   private static void horn(List<Row> out, MinecraftServer server, TeamManager.BotTeam team) {
      TeamTactics tc = team.tactics;
      Category c = TeamSettingRows.Category.HORN;
      List<String> types = new ArrayList();
      types.add("off");
      types.add("any");
      types.addAll(TeamHornSummon.VARIANTS);
      String curType = tc.hornArmed() ? TeamHornSummon.normalise(tc.hornType) : "off";
      out.add(choice("horn:type", c, "Horn", "Which goat horn calls the team. Any means every horn. Off means the team ignores horns. Blow it once to summon the team, again to dismiss it.", Items.GOAT_HORN, curType, tc.hornArmed(), "§8Options: " + String.join(", ", types), (m, right, shift) -> {
         int i = Math.max(0, types.indexOf(curType));
         String next = (String)types.get((i + (right ? types.size() - 1 : 1)) % types.size());
         tc.hornType = next.equals("off") ? "" : next;
         TeamHornSummon.forget(team.getName());
         return null;
      }, "goat horn summon call"));
      boolean anyone = tc.hornPlayer == null || tc.hornPlayer.isBlank();
      out.add(new Row("horn:player", c, "Horn Player", "Who can call the team with the horn. Anyone means any player blowing that horn. The team forms up on this player, else on the boss, else on whoever blew it.", Items.PLAYER_HEAD, TeamSettingRows.Kind.LINK, !anyone, anyone ? "anyone" : tc.hornPlayer, !anyone, "§8Left: pick a player · Right: anyone", (m, right, shift) -> {
         if (right) {
            tc.hornPlayer = "";
            TeamHornSummon.forget(team.getName());
            return "§7Anyone can blow the horn now.";
         } else {
            m.showPicker("Who blows the horn", () -> hornPlayerOptions(m.server(), team));
            return null;
         }
      }, "summoner owner who"));
      out.add(choice("horn:formation", c, "Horn Formation", "The shape the team forms when it answers the horn.", Items.ARMOR_STAND, pretty(tc.hornFormation.name()), tc.hornFormation != FollowFormation.Type.LINE, "§8Left: next · Right: previous", (m, right, shift) -> {
         FollowFormation.Type f = tc.hornFormation;

         do {
            f = (FollowFormation.Type)cycle(f, right);
         } while(f == FollowFormation.Type.NONE);

         tc.hornFormation = f;
         return null;
      }, "shape horn line wall circle"));
      out.add(new Row("horn:summon", c, "Summon Team To Me", "Calls the team to you right now and forms it up, exactly as blowing the horn would.", Items.BELL, TeamSettingRows.Kind.ACTION, false, (String)null, false, "§8Click to summon", (m, right, shift) -> {
         TeamCommand.blowHornNow(m.viewer().createCommandSourceStack(), team.getName());
         return null;
      }, "call rally form up now"));
      out.add(new Row("horn:dismiss", c, "Dismiss Team", "Every bot on the team stops following and goes back to fighting on its own.", Items.BARRIER, TeamSettingRows.Kind.ACTION, false, (String)null, false, "§8Click to dismiss", (m, right, shift) -> "§7" + TeamHornSummon.dismiss(team) + " bot(s) stood down.", "stand down release unfollow"));
   }

   private static List<Row> hornPlayerOptions(MinecraftServer server, TeamManager.BotTeam team) {
      TeamTactics tc = team.tactics;
      List<Row> out = new ArrayList();
      boolean anyone = tc.hornPlayer == null || tc.hornPlayer.isBlank();
      out.add(pick("pick:horn:anyone", "Anyone", "Any player blowing the horn.", Items.GOAT_HORN, anyone, (m, right, shift) -> {
         tc.hornPlayer = "";
         TeamHornSummon.forget(team.getName());
         m.back();
         return null;
      }));
      Set<String> names = new TreeSet(String.CASE_INSENSITIVE_ORDER);

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (PlayerMenuHelper.isRealPlayer(p)) {
            names.add(p.getName().getString());
         }
      }

      if (!anyone) {
         names.add(tc.hornPlayer);
      }

      for(String n : names) {
         boolean current = n.equalsIgnoreCase(tc.hornPlayer);
         out.add(pick("pick:horn:" + n, n, "§8Player", Items.PLAYER_HEAD, current, (m, right, shift) -> {
            tc.hornPlayer = n;
            TeamHornSummon.forget(team.getName());
            m.back();
            return "§7Only §e" + n + "§7 can call this team now.";
         }));
      }

      return out;
   }

   private static void gameplay(List<Row> out, TeamManager.BotTeam team) {
      GameplaySettingsScope scope = GameplaySettingsScope.forTeam(team.getName());
      GameplaySettingsScope global = GameplaySettingsScope.global();

      for(SettingsCli.Entry e : SettingsCli.entries(scope)) {
         String key = e.key();
         if (!SERVER_WIDE.contains(key) && !HIDDEN.contains(key)) {
            Category cat = (Category)CATEGORY_OF.getOrDefault(key, techniqueCategory(key));
            Kind var10000;
            switch (e.kind()) {
               case "BOOL" -> var10000 = TeamSettingRows.Kind.TOGGLE;
               case "ENUM" -> var10000 = TeamSettingRows.Kind.CHOICE;
               default -> var10000 = TeamSettingRows.Kind.NUMBER;
            }

            Kind kind = var10000;
            String var17;
            switch (e.kind()) {
               case "BOOL":
                  var17 = "§8Click to switch on/off";
                  break;
               case "ENUM":
                  var17 = "§8Left: next · Right: previous";
                  break;
               case "PERCENT":
                  var17 = "§8Left +5 · Right −5 · Shift ±25";
                  break;
               case "NUMBER":
                  double[] st = SettingsCli.numberSteps(key);
                  var17 = "§8Left +" + fmtStep(st[0]) + " · Right −" + fmtStep(st[0]) + " · Shift ±" + fmtStep(st[1]);
                  break;
               default:
                  var17 = "§8Set with /vexbot team " + team.getName() + " settings " + key + " <value>";
            }

            controls = var17;
            desc = e.description() == null ? "" : e.description();
            if (kind == TeamSettingRows.Kind.CHOICE && !e.values().isEmpty()) {
               desc = desc + " Options: " + String.join(", ", e.values()) + ".";
            }

            changed = !Objects.equals(e.value(), SettingsCli.currentValue(global, key));
            out.add(new Row("set:" + key, cat, VexBotSettingsMenu.displayName(key), desc, VexBotSettingsMenu.iconFor(key), kind, "on".equalsIgnoreCase(e.value()), e.value(), changed, controls, (m, right, shift) -> SettingsCli.click(scope, key, !right, shift), key));
         }
      }

   }

   private static void targetingLinks(List<Row> out, MinecraftServer server, TeamManager.BotTeam team) {
      Category c = TeamSettingRows.Category.TARGETING;
      String name = team.getName();
      out.add(new Row("link:targets", c, "Team Targets", "Target mode, hunted players and enemy teams: who this team goes after on its own.", Items.CROSSBOW, TeamSettingRows.Kind.LINK, false, pretty(team.getMode().name()), team.getMode() != TeamManager.TargetMode.NONE, "§8Click to open", (m, right, shift) -> {
         m.openOther(new SimpleMenuProvider((id, inv, p) -> new TeamTargetsMenu(id, inv, m.server(), name), VexText.literal("Team targets: " + name)));
         return null;
      }, "hunt enemy teams mode targets players"));
      List<String> allies = new ArrayList(team.getAllies());
      allies.sort(String.CASE_INSENSITIVE_ORDER);
      out.add(new Row("link:allies", c, "Allied Teams", "Teams this team never fights. An alliance works both ways.", Items.EMERALD, TeamSettingRows.Kind.LINK, !allies.isEmpty(), allies.isEmpty() ? "none" : String.join(", ", allies), !allies.isEmpty(), "§8Click to choose allies", (m, right, shift) -> {
         m.showPicker("Allied teams", () -> allyOptions(name));
         return null;
      }, "alliance friends allies peace"));
   }

   private static List<Row> allyOptions(String teamName) {
      List<Row> out = new ArrayList();
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         return out;
      } else {
         List<String> others = new ArrayList(TeamManager.teamNames());
         others.sort(String.CASE_INSENSITIVE_ORDER);

         for(String other : others) {
            if (!other.equalsIgnoreCase(teamName)) {
               boolean allied = false;

               for(String a : team.getAllies()) {
                  if (a.equalsIgnoreCase(other)) {
                     allied = true;
                     break;
                  }
               }

               out.add(pick("pick:ally:" + other, other, allied ? "§aAllied §8· click to end it" : "§7Not allied §8· click to ally", Items.EMERALD, allied, (m, right, shift) -> {
                  if (allied) {
                     TeamManager.removeAlliance(teamName, other);
                  } else {
                     TeamManager.addAlliance(teamName, other);
                  }

                  return allied ? "§7No longer allied with §e" + other + "§7." : "§aAllied with §e" + other + "§a.";
               }));
            }
         }

         if (out.isEmpty()) {
            out.add(new Row("pick:ally:none", TeamSettingRows.Category.TARGETING, "No other teams", "Create another team first.", Items.BARRIER, TeamSettingRows.Kind.ACTION, false, (String)null, false, "", (m, r, s) -> null, ""));
         }

         return out;
      }
   }

   private static void difficulty(List<Row> out, TeamManager.BotTeam team) {
      Category c = TeamSettingRows.Category.DIFFICULTY;
      GameplaySettingsScope scope = GameplaySettingsScope.forTeam(team.getName());
      BotSettings.Difficulty cur = scope.difficulty();
      out.add(choice("diff:preset", c, "Difficulty Preset", "Sets every knob below at once to a preset. Tuning a knob afterwards keeps the rest.", Items.EXPERIENCE_BOTTLE, pretty(cur.name()), cur != BotSettings.difficulty, "§8Left: harder · Right: easier", (m, right, shift) -> {
         BotSettings.Difficulty next = (BotSettings.Difficulty)cycle(cur, right);
         scope.setDifficulty(next);
         return "§7Every difficulty knob set to §e" + pretty(next.name()) + "§7.";
      }, "preset easy medium hard expert perfect"));
      DifficultyParams p = team.difficultyParams;
      DifficultyParams g = BotSettings.difficultyParams;

      for(DifficultyKnobs.Knob k : DifficultyKnobs.ALL) {
         boolean changed = Math.abs(k.get().applyAsDouble(p) - k.get().applyAsDouble(g)) > 1.0E-6;
         out.add(number("knob:" + k.id(), c, k.label(), k.description(), Items.REPEATER, k.shown(p), changed, "§8Left: up · Right: down · Shift: bigger step", (m, right, shift) -> {
            DifficultyKnobs.step(team.difficultyParams, k, !right, shift);
            return null;
         }, "difficulty knob " + k.id()));
      }

   }

   private static void teamRows(List<Row> out, MinecraftServer server, TeamManager.BotTeam team) {
      Category c = TeamSettingRows.Category.TEAM;
      String name = team.getName();
      int bots = team.getBotNames().size();
      int humans = team.getPlayerNames().size();
      out.add(new Row("team:members", c, "Members", "Add or remove the bots and players on this team.", Items.PLAYER_HEAD, TeamSettingRows.Kind.LINK, false, bots + " bot(s), " + humans + " player(s)", false, "§8Click to open", (m, right, shift) -> {
         m.openOther(new SimpleMenuProvider((id, inv, p) -> new TeamBuilderMenu(id, inv, m.server(), name, true), VexText.literal("Team members: " + name)));
         return null;
      }, "roster add remove bots players"));
      out.add(new Row("team:builder", c, "Team Builder", "The full team builder: members, presets and kits in one screen.", Items.CRAFTING_TABLE, TeamSettingRows.Kind.LINK, false, (String)null, false, "§8Click to open", (m, right, shift) -> {
         m.openOther(new SimpleMenuProvider((id, inv, p) -> new TeamBuilderMenu(id, inv, m.server(), name, false), VexText.literal("Build Team: " + name)));
         return null;
      }, "build kits presets"));
      BotSettings.PlayStyle shared = null;
      boolean mixed = false;

      for(String b : team.getBotNames()) {
         BotSettings.PlayStyle s = BotSettings.playStyleFor(b);
         if (shared == null) {
            shared = s;
         } else if (shared != s) {
            mixed = true;
         }
      }

      BotSettings.PlayStyle from = shared == null ? BotSettings.PlayStyle.DEFAULT : shared;
      out.add(choice("team:playstyle", c, "Playstyle", "How every bot on the team plays its fights: default, safe, aggressive, adaptive, defensive or balanced. Sets each member's own playstyle.", Items.TOTEM_OF_UNDYING, bots == 0 ? "no bots" : (mixed ? "mixed" : pretty(from.name())), !mixed && from != BotSettings.PlayStyle.DEFAULT, "§8Left: next · Right: previous", (m, right, shift) -> {
         if (team.getBotNames().isEmpty()) {
            return "§7This team has no bots yet.";
         } else {
            BotSettings.PlayStyle next = (BotSettings.PlayStyle)cycle(from, right);

            for(String b : team.getBotNames()) {
               BotSettings.setPlayStyle(b, next);
            }

            return "§7Every bot on §e" + name + "§7 now plays §e" + pretty(next.name()) + "§7.";
         }
      }, "safe aggressive adaptive defensive balanced style"));
      out.add(new Row("team:delete", c, "Delete Team", "Deletes this team and its settings. Its bots stay in the world.", Items.LAVA_BUCKET, TeamSettingRows.Kind.LINK, false, (String)null, false, "§8Click, then confirm", (m, right, shift) -> {
         m.openOther(new SimpleMenuProvider((id, inv, p) -> new TeamDeleteConfirmMenu(id, inv, name), VexText.literal("Delete Team: " + name)));
         return null;
      }, "remove disband"));
   }

   private static Row toggle(String id, Category c, String name, String desc, Item icon, boolean on, boolean changed, Consumer<Boolean> set, String keywords) {
      return new Row(id, c, name, desc, icon, TeamSettingRows.Kind.TOGGLE, on, on ? "on" : "off", changed, "§8Click to switch on/off", (m, right, shift) -> {
         set.accept(!on);
         return null;
      }, keywords);
   }

   private static Row choice(String id, Category c, String name, String desc, Item icon, String value, boolean changed, String controls, Action a, String keywords) {
      return new Row(id, c, name, desc, icon, TeamSettingRows.Kind.CHOICE, false, value, changed, controls, a, keywords);
   }

   private static Row number(String id, Category c, String name, String desc, Item icon, String value, boolean changed, String controls, Action a, String keywords) {
      return new Row(id, c, name, desc, icon, TeamSettingRows.Kind.NUMBER, false, value, changed, controls, a, keywords);
   }

   private static Row pick(String id, String name, String desc, Item icon, boolean current, Action a) {
      return new Row(id, TeamSettingRows.Category.OTHER, (current ? "§a✔ " : "") + name, desc, icon, TeamSettingRows.Kind.ACTION, current, (String)null, false, current ? "§aSelected" : "§8Click to choose", a, "");
   }

   static <E extends Enum<E>> E cycle(E value, boolean back) {
      E[] all = (E[])(value.getDeclaringClass().getEnumConstants());
      return (E)all[(value.ordinal() + (back ? all.length - 1 : 1)) % all.length];
   }

   private static double clamp(double v, boolean down, double step, double min, double max) {
      double next = (double)Math.round((down ? v - step : v + step) * (double)100.0F) / (double)100.0F;
      return Math.max(min, Math.min(max, next));
   }

   private static int clampInt(int v, boolean down, int step, int min, int max) {
      return Math.max(min, Math.min(max, down ? v - step : v + step));
   }

   static String pretty(String enumName) {
      StringBuilder sb = new StringBuilder();

      for(String w : enumName.toLowerCase(Locale.ROOT).split("_")) {
         if (!w.isEmpty()) {
            if (sb.length() > 0) {
               sb.append(' ');
            }

            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
         }
      }

      return sb.toString();
   }

   private static String fmt1(double v) {
      return String.format(Locale.ROOT, "%.1f", v);
   }

   private static String fmtStep(double v) {
      return v == Math.rint(v) ? String.valueOf((long)v) : String.valueOf(v);
   }

   static {
      CATEGORY_OF = Map.ofEntries(Map.entry("spread-out", TeamSettingRows.Category.ORDERS), Map.entry("attackrange", TeamSettingRows.Category.COMBAT), Map.entry("equiparmor", TeamSettingRows.Category.COMBAT), Map.entry("strafeincombo", TeamSettingRows.Category.COMBAT), Map.entry("jumpresetchance", TeamSettingRows.Category.COMBAT), Map.entry("counterstunchance", TeamSettingRows.Category.COMBAT), Map.entry("fastshield", TeamSettingRows.Category.COMBAT), Map.entry("backstab", TeamSettingRows.Category.COMBAT), Map.entry("offhand", TeamSettingRows.Category.COMBAT), Map.entry("offhandtotemhearts", TeamSettingRows.Category.COMBAT), Map.entry("shieldmacedive", TeamSettingRows.Category.COMBAT), Map.entry("stunslam", TeamSettingRows.Category.COMBAT), Map.entry("retreat", TeamSettingRows.Category.HEALING), Map.entry("retreattohealthreshold", TeamSettingRows.Category.HEALING), Map.entry("usepotions", TeamSettingRows.Category.HEALING), Map.entry("healing", TeamSettingRows.Category.HEALING), Map.entry("chorusescape", TeamSettingRows.Category.HEALING), Map.entry("fireescape", TeamSettingRows.Category.HEALING), Map.entry("webescape", TeamSettingRows.Category.HEALING), Map.entry("waterbucketclutch", TeamSettingRows.Category.HEALING), Map.entry("botleaveondeath", TeamSettingRows.Category.HEALING), Map.entry("bunnyhop", TeamSettingRows.Category.MOVEMENT), Map.entry("wander", TeamSettingRows.Category.MOVEMENT), Map.entry("enderpearl", TeamSettingRows.Category.MOVEMENT), Map.entry("pearlchasing", TeamSettingRows.Category.MOVEMENT), Map.entry("pearlcatch", TeamSettingRows.Category.MOVEMENT), Map.entry("pearlcatchtype", TeamSettingRows.Category.MOVEMENT), Map.entry("elytraglide", TeamSettingRows.Category.MOVEMENT), Map.entry("bridgemode", TeamSettingRows.Category.MOVEMENT), Map.entry("buildup", TeamSettingRows.Category.MOVEMENT), Map.entry("buildupminheight", TeamSettingRows.Category.MOVEMENT), Map.entry("riptideanywhere", TeamSettingRows.Category.MOVEMENT), Map.entry("carting", TeamSettingRows.Category.WEAPONS), Map.entry("cartmode", TeamSettingRows.Category.WEAPONS), Map.entry("cartdoctrine", TeamSettingRows.Category.WEAPONS), Map.entry("usebows", TeamSettingRows.Category.WEAPONS), Map.entry("speardash", TeamSettingRows.Category.WEAPONS), Map.entry("elytramace", TeamSettingRows.Category.WEAPONS), Map.entry("elytraspear", TeamSettingRows.Category.WEAPONS), Map.entry("orbitalstrike", TeamSettingRows.Category.WEAPONS), Map.entry("usecobwebs", TeamSettingRows.Category.TRAPS), Map.entry("hitweb", TeamSettingRows.Category.TRAPS), Map.entry("webdrain", TeamSettingRows.Category.TRAPS), Map.entry("webdrainchance", TeamSettingRows.Category.TRAPS), Map.entry("targetplayers", TeamSettingRows.Category.TARGETING), Map.entry("autotarget", TeamSettingRows.Category.TARGETING), Map.entry("targetbots", TeamSettingRows.Category.TARGETING), Map.entry("targetmobs", TeamSettingRows.Category.TARGETING), Map.entry("ignorecreative", TeamSettingRows.Category.TARGETING), Map.entry("revengemode", TeamSettingRows.Category.TARGETING), Map.entry("enderchestregear", TeamSettingRows.Category.RESTOCK), Map.entry("shulkersteal", TeamSettingRows.Category.RESTOCK), Map.entry("shulker-regear", TeamSettingRows.Category.RESTOCK), Map.entry("lootpackradius", TeamSettingRows.Category.RESTOCK), Map.entry("pickuploot", TeamSettingRows.Category.RESTOCK), Map.entry("nametagcolour", TeamSettingRows.Category.TEAM), Map.entry("botping", TeamSettingRows.Category.TEAM), Map.entry("doblockexplosion", TeamSettingRows.Category.TEAM), Map.entry("speednojump", TeamSettingRows.Category.MOVEMENT), Map.entry("macetotem", TeamSettingRows.Category.COMBAT), Map.entry("chasespread", TeamSettingRows.Category.MOVEMENT), Map.entry("placeblocksmoving", TeamSettingRows.Category.MOVEMENT));
   }

   static enum Category {
      ORDERS("Battle Orders", Items.GOLDEN_HELMET, "Formation, boss, escort duty and how the team fights together."),
      HORN("Horn Summon", Items.GOAT_HORN, "Blow a goat horn and the team runs to you and forms up."),
      COMBAT("Combat", Items.DIAMOND_SWORD, "Reach, strafing, shields, armour and melee habits."),
      HEALING("Healing & Escape", Items.GOLDEN_APPLE, "When to retreat, how to heal and how to get out of trouble."),
      MOVEMENT("Movement & Building", Items.LEATHER_BOOTS, "Pearls, bunny hops, bridging, building up and wandering."),
      WEAPONS("Weapons & Modes", Items.MACE, "Carts, bows, spears, maces, elytra and other kit."),
      TRAPS("Traps & Webs", Items.COBWEB, "Cobwebs, hit-webs and draining the water you escape with."),
      TARGETING("Targeting", Items.TARGET, "Who the team fights, hunts, ignores and is allied with."),
      RESTOCK("Restock & Loot", Items.SHULKER_BOX, "Ender chest regear, shulkers and picking up loot."),
      DIFFICULTY("Difficulty", Items.EXPERIENCE_BOTTLE, "Every difficulty knob, tuned for this team alone."),
      TEAM("Team & Members", Items.PLAYER_HEAD, "Members, playstyle, name colour, and deleting the team."),
      OTHER("Other", Items.PAPER, "Settings that have no category yet.");

      final String title;
      final Item icon;
      final String blurb;

      private Category(String title, Item icon, String blurb) {
         this.title = title;
         this.icon = icon;
         this.blurb = blurb;
      }

      // $FF: synthetic method
      private static Category[] $values() {
         return new Category[]{ORDERS, HORN, COMBAT, HEALING, MOVEMENT, WEAPONS, TRAPS, TARGETING, RESTOCK, DIFFICULTY, TEAM, OTHER};
      }
   }

   static enum Kind {
      TOGGLE,
      CHOICE,
      NUMBER,
      ACTION,
      LINK;

      // $FF: synthetic method
      private static Kind[] $values() {
         return new Kind[]{TOGGLE, CHOICE, NUMBER, ACTION, LINK};
      }
   }

   static record Row(String id, Category category, String name, String description, Item icon, Kind kind, boolean on, String value, boolean changed, String controls, Action action, String keywords) {
      boolean matches(String[] words) {
         String hay = TeamSettingRows.norm(this.name + " " + this.id + " " + this.description + " " + this.category.title + " " + this.keywords);

         for(String w : words) {
            if (!w.isEmpty() && !hay.contains(w)) {
               return false;
            }
         }

         return true;
      }

      boolean nameMatches(String[] words) {
         String hay = TeamSettingRows.norm(this.name + " " + this.id);

         for(String w : words) {
            if (!w.isEmpty() && !hay.contains(w)) {
               return false;
            }
         }

         return true;
      }
   }

   @FunctionalInterface
   interface Action {
      String run(TeamSettingsMenu var1, boolean var2, boolean var3);
   }
}
