package vexbot.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import vexbot.BotSettings;
import vexbot.DifficultyParams;
import vexbot.VexBot;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.settings.GameplaySettingsScope;
import vexbot.settings.SettingsCli;
import vexbot.team.TeamManager;

public class VexBotSettingsMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int SIZE = 54;
   private static final int PER_PAGE = 45;
   private static final int SLOT_PREV = 45;
   private static final int SLOT_DIFF_INFO = 47;
   private static final int SLOT_INFO = 49;
   private static final int SLOT_TECH_INFO = 51;
   private static final int SLOT_NEXT = 53;
   private final SimpleContainer container;
   private final String teamScope;
   private final GameplaySettingsScope scope;
   private int page;
   private static final Set<String> HIDDEN = Set.of("spread-out");
   private static final Map<String, String> SPACED = Map.ofEntries(Map.entry("riptideanywhere", "riptide anywhere"), Map.entry("equiparmor", "equip armour"), Map.entry("revengemode", "revenge mode"), Map.entry("bunnyhop", "bunny hop"), Map.entry("retreattohealthreshold", "retreat heal threshold"), Map.entry("targetplayers", "target players"), Map.entry("autotarget", "auto target"), Map.entry("targetbots", "target bots"), Map.entry("targetmobs", "target mobs"), Map.entry("usepotions", "use potions"), Map.entry("attackrange", "attack range"), Map.entry("bridgemode", "bridge mode"), Map.entry("cartmode", "cart mode"), Map.entry("ignorecreative", "ignore creative"), Map.entry("enderpearl", "ender pearl escape"), Map.entry("pearlchasing", "pearl chasing"), Map.entry("botleaveondeath", "bot leave on death"), Map.entry("botdontleave", "keep bots on restart"), Map.entry("botadvancements", "bots earn advancements"), Map.entry("botspawnmobs", "mobs spawn near bots"), Map.entry("kitpotiondosplash", "kit potion splash"), Map.entry("gotomining", "goto mines through blocks"), Map.entry("advancedspawn", "advanced spawn"), Map.entry("orbitalstrike", "orbital strike"), Map.entry("buildup", "build up (scaffold)"), Map.entry("nametagcolour", "nametag colour"), Map.entry("pearlcatchtype", "pearl catch type"), Map.entry("chorusescape", "chorus escape"), Map.entry("fireescape", "fire escape"), Map.entry("shulkersteal", "shulker steal"), Map.entry("shulker-regear", "shulker regear"), Map.entry("spread-out", "spread out"), Map.entry("webescape", "web escape"), Map.entry("waterbucketclutch", "water bucket clutch"), Map.entry("usebows", "use bows"), Map.entry("hitweb", "hit web"), Map.entry("pickuploot", "pickup loot"), Map.entry("lootpackradius", "loot pack radius"), Map.entry("buildupminheight", "buildup min height"), Map.entry("healing", "healing mode"), Map.entry("strafeincombo", "strafe in combo"), Map.entry("cartdoctrine", "cart doctrine"), Map.entry("fastshield", "fast shield cooldown"), Map.entry("speardash", "spear dash"), Map.entry("stunslam", "stun slam"), Map.entry("stunslamchance", "stun slam chance"), Map.entry("webdrain", "web drain"), Map.entry("webdrainchance", "web drain chance"), Map.entry("jumpresetchance", "jump reset chance"), Map.entry("counterstunchance", "counter stun chance"), Map.entry("shieldmacedive", "shield on mace dive"), Map.entry("pearlcatch", "pearl catch"), Map.entry("elytraglide", "elytra glide"), Map.entry("usecobwebs", "use cobwebs"), Map.entry("elytramace", "elytra mace"), Map.entry("elytraspear", "elytra spear"));
   private static final Map<String, Item> ICONS;

   public VexBotSettingsMenu(int containerId, Inventory playerInventory) {
      this(containerId, playerInventory, (String)null);
   }

   public VexBotSettingsMenu(int containerId, Inventory playerInventory, String teamName) {
      super(MenuType.GENERIC_9x6, containerId, playerInventory);
      this.container = new SimpleContainer(54);
      this.page = 0;
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.teamScope = teamName;
      this.scope = teamName != null ? GameplaySettingsScope.forTeam(teamName) : GameplaySettingsScope.global();
      this.render();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 198));
      }

   }

   private TeamManager.BotTeam scopedTeam() {
      return this.teamScope != null ? TeamManager.get(this.teamScope) : null;
   }

   private List<SettingsCli.Entry> entries() {
      List<SettingsCli.Entry> all = SettingsCli.entries(this.scope);
      if (HIDDEN.isEmpty()) {
         return all;
      } else {
         List<SettingsCli.Entry> shown = new ArrayList(all.size());

         for(SettingsCli.Entry e : all) {
            if (!HIDDEN.contains(e.key())) {
               shown.add(e);
            }
         }

         return shown;
      }
   }

   private int pageCount() {
      return Math.max(1, (this.entries().size() + 45 - 1) / 45);
   }

   private void render() {
      List<SettingsCli.Entry> all = this.entries();
      int pages = Math.max(1, (all.size() + 45 - 1) / 45);
      if (this.page >= pages) {
         this.page = pages - 1;
      }

      if (this.page < 0) {
         this.page = 0;
      }

      ItemStack filler = makeItem(McCompat.pane(DyeColor.GRAY), " ");

      for(int i = 0; i < 54; ++i) {
         this.container.setItem(i, filler.copy());
      }

      int base = this.page * 45;

      for(int i = 0; i < 45; ++i) {
         int idx = base + i;
         if (idx >= all.size()) {
            break;
         }

         this.container.setItem(i, this.render((SettingsCli.Entry)all.get(idx)));
      }

      boolean overridden = this.isTargetingOverridden();
      SimpleContainer var10000 = this.container;
      Item var10002 = Items.BOOK;
      String var10003 = this.teamScope == null ? "§6VexBot Settings" : "§6Team Settings: §e" + this.teamScope;
      String[] var10004 = new String[6];
      int var10007 = this.page + 1;
      var10004[0] = "§7Page §f" + var10007 + "§7 of §f" + pages + "§7 — §f" + all.size() + "§7 settings";
      var10004[1] = "§8Left-click: toggle / next value";
      var10004[2] = "§8Right-click: previous value";
      var10004[3] = "§8Shift: bigger step on numbers";
      var10004[4] = this.teamScope == null ? "§8Scope: global (bots with no team)" : "§8Scope: bots in §e" + this.teamScope;
      var10004[5] = overridden ? "§8Target toggles are overridden by this team's attack mode." : null;
      var10000.setItem(49, makeItem(var10002, var10003, var10004));
      this.container.setItem(47, makeItem(Items.PAPER, "§fDifficulty §8(command-driven)", "§7Per-knob, not a preset picker.", "§e/vexbot difficulty list §7— show all knobs", "§e/vexbot difficulty <knob> <value>", "§8[Accuracy currently " + this.accuracyPercent() + "%]"));
      this.container.setItem(51, makeItem(Items.MACE, "§fTechniques", "§7Every spear, mace and elytra technique", "§7is a setting in this list now.", "§e/vexbot settings <technique> <on|off>"));
      if (this.page > 0) {
         this.container.setItem(45, makeItem(Items.ARROW, "§ePrevious page", "§7Page " + this.page + " of " + pages));
      }

      if (this.page < pages - 1) {
         var10000 = this.container;
         var10002 = Items.ARROW;
         var10004 = new String[1];
         var10007 = this.page + 2;
         var10004[0] = "§7Page " + var10007 + " of " + pages;
         var10000.setItem(53, makeItem(var10002, "§eNext page", var10004));
      }

   }

   private ItemStack render(SettingsCli.Entry e) {
      String kind = e.kind();
      String value = e.value();
      boolean on = "on".equalsIgnoreCase(value);
      Item icon = (Item)ICONS.get(e.key());
      if (icon == null) {
         Item var10000;
         switch (kind) {
            case "BOOL" -> var10000 = on ? McCompat.pane(DyeColor.LIME) : McCompat.pane(DyeColor.RED);
            case "ENUM" -> var10000 = McCompat.pane(DyeColor.YELLOW);
            case "PERCENT" -> var10000 = McCompat.pane(DyeColor.CYAN);
            default -> var10000 = Items.PAPER;
         }

         icon = var10000;
      }

      String var11;
      switch (kind) {
         case "BOOL" -> var11 = on ? "§a" : "§c";
         case "ENUM" -> var11 = "§e";
         default -> var11 = "§b";
      }

      String colour = var11;
      switch (kind) {
         case "BOOL" -> var11 = "§8Click to toggle.";
         case "ENUM" -> var11 = "§8Left/right-click to cycle: " + String.join(", ", e.values());
         case "PERCENT" -> var11 = "§8Left +5, right −5, shift ±25.";
         case "NUMBER" -> var11 = "§8Left/right-click to step, shift for bigger.";
         default -> var11 = "§8Set with /vexbot settings " + e.key() + " <value>.";
      }

      String hint = var11;
      return makeItem(icon, colour + prettyName(e.key()), wrap(e.description()), "§8[Currently: " + colour + value + "§8]", hint);
   }

   public static String displayName(String key) {
      return prettyName(key);
   }

   public static Item iconFor(String key) {
      return (Item)ICONS.get(key);
   }

   private static String prettyName(String key) {
      String spaced = (String)SPACED.getOrDefault(key, key);
      StringBuilder out = new StringBuilder(spaced.length() + 4);
      boolean start = true;

      for(char c : spaced.toCharArray()) {
         if (c == ' ') {
            out.append(' ');
            start = true;
         } else {
            out.append(start ? Character.toUpperCase(c) : c);
            start = false;
         }
      }

      return out.toString();
   }

   private static String wrap(String description) {
      return description.length() <= 46 ? "§7" + description : "§7" + description.substring(0, 45) + "…";
   }

   private boolean isTargetingOverridden() {
      if (this.teamScope == null) {
         return false;
      } else {
         TeamManager.BotTeam t = this.scopedTeam();
         return t != null && t.getMode() != TeamManager.TargetMode.NONE;
      }
   }

   private int accuracyPercent() {
      TeamManager.BotTeam t = this.scopedTeam();
      DifficultyParams dp = t != null ? t.difficultyParams : BotSettings.difficultyParams;
      return (int)Math.round(dp.accuracy * (double)100.0F);
   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (this.teamScope != null && this.scopedTeam() == null) {
         tell(player, "§c[VexBot] Team '§e" + this.teamScope + "§c' no longer exists. Close this menu.");
      } else if (slotId < 0 || slotId >= 54 || this.isPlainClick()) {
         if (slotId != 45 && slotId != 53) {
            if (slotId >= 0 && slotId < 45) {
               List<SettingsCli.Entry> all = this.entries();
               int idx = this.page * 45 + slotId;
               if (idx < all.size()) {
                  boolean forward = button != 1;
                  String err = SettingsCli.click(this.scope, ((SettingsCli.Entry)all.get(idx)).key(), forward, quickMove);
                  if (err != null) {
                     tell(player, "§c[VexBot] " + err);
                  }

                  this.render();
                  this.sendAllDataToRemote();
                  this.persistSettings();
               }
            } else if (slotId < 45 || slotId >= 54) {
               this.vanillaClick(slotId, button, player);
            }
         } else {
            int pages = this.pageCount();
            this.page = slotId == 53 ? Math.min(pages - 1, this.page + 1) : Math.max(0, this.page - 1);
            this.render();
            this.sendAllDataToRemote();
         }
      }
   }

   private static void tell(Player player, String message) {
      if (player instanceof ServerPlayer sp) {
         sp.sendSystemMessage(VexText.literal(sp, message));
      }

   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int i) {
      return ItemStack.EMPTY;
   }

   private void persistSettings() {
      if (VexBot.SERVER != null) {
         this.scope.persist(VexBot.SERVER);
      }

   }

   private static ItemStack makeItem(Item item, String name, String... loreLines) {
      ItemStack stack = new ItemStack(item);
      stack.set(DataComponents.CUSTOM_NAME, VexText.literal(name).setStyle(Style.EMPTY.withItalic(false)));
      List<Component> lines = Arrays.stream(loreLines).filter(Objects::nonNull).map((l) -> VexText.literal(l).setStyle(Style.EMPTY.withItalic(false))).toList();
      if (!lines.isEmpty()) {
         stack.set(DataComponents.LORE, new ItemLore(lines));
      }

      return stack;
   }

   static {
      ICONS = Map.ofEntries(Map.entry("tags", Items.NAME_TAG), Map.entry("riptideanywhere", Items.TRIDENT), Map.entry("equiparmor", Items.DIAMOND_CHESTPLATE), Map.entry("revengemode", Items.IRON_SWORD), Map.entry("bunnyhop", Items.RABBIT_FOOT), Map.entry("retreat", Items.COOKED_BEEF), Map.entry("usepotions", Items.SPLASH_POTION), Map.entry("carting", Items.TNT_MINECART), Map.entry("cartmode", Items.RAIL), Map.entry("attackrange", Items.STICK), Map.entry("bridgemode", Items.SCAFFOLDING), Map.entry("enderpearl", Items.ENDER_PEARL), Map.entry("pearlchasing", Items.ENDER_EYE), Map.entry("pearlcatch", Items.ENDER_PEARL), Map.entry("pearlcatchtype", Items.ENDER_PEARL), Map.entry("usecobwebs", Items.COBWEB), Map.entry("hitweb", Items.COBWEB), Map.entry("pickuploot", Items.HOPPER), Map.entry("lootpackradius", Items.SHULKER_BOX), Map.entry("buildupminheight", Items.SCAFFOLDING), Map.entry("healing", Items.GOLDEN_APPLE), Map.entry("strafeincombo", Items.FEATHER), Map.entry("cartdoctrine", Items.TNT_MINECART), Map.entry("webescape", Items.SHEARS), Map.entry("webdrain", Items.BUCKET), Map.entry("waterbucketclutch", Items.WATER_BUCKET), Map.entry("fireescape", Items.WATER_BUCKET), Map.entry("chorusescape", Items.CHORUS_FRUIT), Map.entry("shulkersteal", Items.SHULKER_BOX), Map.entry("shulker-regear", Items.SHULKER_BOX), Map.entry("usebows", Items.BOW), Map.entry("fastshield", Items.SHIELD), Map.entry("shieldmacedive", Items.SHIELD), Map.entry("stunslam", Items.MACE), Map.entry("elytramace", Items.ELYTRA), Map.entry("elytraspear", Items.ELYTRA), Map.entry("elytraglide", Items.FIREWORK_ROCKET), Map.entry("speardash", Items.WIND_CHARGE), Map.entry("orbitalstrike", Items.END_ROD), Map.entry("buildup", Items.SCAFFOLDING), Map.entry("nametagcolour", Items.NAME_TAG), Map.entry("kitpotiondosplash", Items.SPLASH_POTION), Map.entry("gotomining", Items.IRON_PICKAXE), Map.entry("advancedspawn", Items.CHEST), Map.entry("stats", Items.WRITABLE_BOOK), Map.entry("silent", Items.BARRIER), Map.entry("botleaveondeath", Items.SKELETON_SKULL), Map.entry("botdontleave", Items.ENDER_CHEST), Map.entry("botadvancements", Items.KNOWLEDGE_BOOK), Map.entry("botspawnmobs", Items.ZOMBIE_HEAD), Map.entry("wander", Items.COMPASS), Map.entry("ignorecreative", Items.FEATHER));
   }

   private static final class LockedSlot extends Slot {
      LockedSlot(SimpleContainer c, int i, int x, int y) {
         super(c, i, x, y);
      }

      public boolean mayPickup(Player p) {
         return false;
      }

      public boolean mayPlace(ItemStack s) {
         return false;
      }
   }
}
