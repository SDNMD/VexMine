package vexbot.gui;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;

final class BukkitCompat {
   private BukkitCompat() {
   }

   static void setMenuPlayer(AbstractContainerMenu menu, Inventory playerInventory) {
      try {
         Method getBukkitEntity = playerInventory.player.getClass().getMethod("getBukkitEntity");
         Object craftPlayer = getBukkitEntity.invoke(playerInventory.player);
         Field playerField = AbstractContainerMenu.class.getDeclaredField("player");
         playerField.setAccessible(true);
         playerField.set(menu, craftPlayer);
      } catch (Exception var5) {
      }

   }
}
