package vexbot.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.kit.KitManager;

public final class KitIconPickMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int SLOT_BACK = 45;
   private static final int SLOT_CLEAR = 53;
   private static final int GUI_LABEL = 36;
   private static final int GUI_HELMET = 37;
   private static final int GUI_CHEST = 38;
   private static final int GUI_LEGS = 39;
   private static final int GUI_BOOTS = 40;
   private static final int GUI_SEP = 41;
   private static final int GUI_OFFHAND = 42;
   private static final int[] KIT_SLOT_FOR_GUI = new int[54];
   private final SimpleContainer container = new SimpleContainer(54);
   private final MinecraftServer server;
   private final String kitName;
   private final int returnPage;
   private final ItemStack[] kitContents;

   public KitIconPickMenu(int containerId, Inventory playerInventory, MinecraftServer server, String kitName, int returnPage) {
      super(MenuType.GENERIC_9x6, containerId, playerInventory);
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.server = server;
      this.kitName = kitName;
      this.returnPage = returnPage;
      this.kitContents = KitManager.load(server, kitName);
      this.buildContents();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new KitListMenu.LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 103 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 161));
      }

   }

   private void buildContents() {
      ItemStack fill = KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), " ");
      if (this.kitContents == null) {
         for(int i = 0; i < 54; ++i) {
            this.container.setItem(i, fill.copy());
         }

         this.container.setItem(45, makeBack());
      } else {
         for(int i = 0; i < 27; ++i) {
            ItemStack s = this.kitContents[9 + i];
            this.container.setItem(i, s.isEmpty() ? fill.copy() : withClickHint(s.copy()));
         }

         for(int i = 0; i < 9; ++i) {
            ItemStack s = this.kitContents[i];
            this.container.setItem(27 + i, s.isEmpty() ? fill.copy() : withClickHint(s.copy()));
         }

         this.container.setItem(36, KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§7Armor & Offhand"));
         this.container.setItem(37, this.armorSlot(this.kitContents[39], "§8(no helmet)"));
         this.container.setItem(38, this.armorSlot(this.kitContents[38], "§8(no chestplate)"));
         this.container.setItem(39, this.armorSlot(this.kitContents[37], "§8(no leggings)"));
         this.container.setItem(40, this.armorSlot(this.kitContents[36], "§8(no boots)"));
         this.container.setItem(41, fill.copy());
         this.container.setItem(42, this.armorSlot(this.kitContents[40], "§8(no offhand)"));
         this.container.setItem(43, fill.copy());
         this.container.setItem(44, fill.copy());

         for(int i = 45; i < 54; ++i) {
            this.container.setItem(i, fill.copy());
         }

         this.container.setItem(45, makeBack());
         this.container.setItem(53, KitListMenu.makeItem(Items.BARRIER, "§cClear Icon", "§7Remove the custom icon", "§7and revert to §7chest."));
         ItemStack existing = KitManager.loadIcon(this.server, this.kitName);
         if (!existing.isEmpty()) {
            this.container.setItem(53, KitListMenu.makeItem(Items.BARRIER, "§cClear Icon", "§7Current: §f" + existing.getHoverName().getString(), "§7Click to remove."));
         }

      }
   }

   private ItemStack armorSlot(ItemStack s, String emptyLabel) {
      return s.isEmpty() ? KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), emptyLabel) : withClickHint(s.copy());
   }

   private static ItemStack withClickHint(ItemStack stack) {
      ItemLore existing = (ItemLore)stack.get(DataComponents.LORE);
      List<Component> lines = new ArrayList();
      if (existing != null) {
         lines.addAll(existing.lines());
      }

      lines.add(VexText.literal("§e§lClick to set as icon").setStyle(Style.EMPTY.withItalic(false)));
      stack.set(DataComponents.LORE, new ItemLore(lines));
      return stack;
   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (player instanceof ServerPlayer sp) {
         if (slotId == 45) {
            this.openIconList(sp);
         } else if (slotId == 53) {
            KitManager.deleteIcon(this.server, this.kitName);
            sp.sendSystemMessage(VexText.literal(sp, "§a[VexBot] Cleared icon for kit §e" + this.kitName + "§a."));
            this.openIconList(sp);
         } else {
            if (this.kitContents != null && slotId >= 0 && slotId < 54) {
               int kitSlot = KIT_SLOT_FOR_GUI[slotId];
               if (kitSlot >= 0 && !this.kitContents[kitSlot].isEmpty()) {
                  ItemStack icon = this.kitContents[kitSlot].copyWithCount(1);
                  KitManager.saveIcon(this.server, this.kitName, icon);
                  String var10002 = this.kitName;
                  sp.sendSystemMessage(VexText.literal(sp, "§a[VexBot] Set icon for kit §e" + var10002 + "§a to §f" + icon.getHoverName().getString() + "§a."));
                  this.openIconList(sp);
               }
            }

            this.vanillaClick(slotId, button, player);
         }
      }
   }

   private void openIconList(ServerPlayer sp) {
      sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, this.server, KitListMenu.Mode.ICON, this.returnPage, (String)null), VexText.literal("§6Kit Icons")));
   }

   private static ItemStack makeBack() {
      return KitListMenu.makeItem(Items.ARROW, "§f« Back to Kits", "§7Return to the kit list.");
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int i) {
      return ItemStack.EMPTY;
   }

   static {
      Arrays.fill(KIT_SLOT_FOR_GUI, -1);

      for(int i = 0; i < 27; ++i) {
         KIT_SLOT_FOR_GUI[i] = 9 + i;
      }

      for(int i = 0; i < 9; KIT_SLOT_FOR_GUI[27 + i] = i++) {
      }

      KIT_SLOT_FOR_GUI[37] = 39;
      KIT_SLOT_FOR_GUI[38] = 38;
      KIT_SLOT_FOR_GUI[39] = 37;
      KIT_SLOT_FOR_GUI[40] = 36;
      KIT_SLOT_FOR_GUI[42] = 40;
   }
}
