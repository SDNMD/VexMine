package vexbot.gui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.ResolvableProfile;
import vexbot.SettingsPersistence;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;

public final class TeamTargetsMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int SIZE = 54;
   private static final int SLOT_STOP = 9;
   private static final int SLOT_ALL = 10;
   private static final int SLOT_SPEC = 11;
   private static final int SLOT_EDIT = 12;
   private static final int SLOT_REVENGE = 13;
   private static final int SLOT_SPEC_TEAMS = 14;
   private static final int SLOT_DELETE = 17;
   private static final int SLOT_PAGE_PREV = 15;
   private static final int SLOT_PAGE_NEXT = 16;
   private static final int SLOT_STATUS = 35;
   private static final int ENTITY_GRID_START = 36;
   private static final int ENTITY_GRID_SIZE = 18;
   private final SimpleContainer container = new SimpleContainer(54);
   private final MinecraftServer server;
   private final String teamName;
   private List<TargetCandidate> entityList;
   private List<String> teamList;
   private int entityPage = 0;
   private int teamPage = 0;

   public TeamTargetsMenu(int containerId, Inventory playerInventory, MinecraftServer server, String teamName) {
      super(MenuType.GENERIC_9x6, containerId, playerInventory);
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.server = server;
      String canon = TeamManager.canonicalName(teamName);
      this.teamName = canon != null ? canon : teamName;
      this.entityList = this.computeEntityList();
      this.teamList = this.computeTeamList();
      this.buildContainer();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 138 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 196));
      }

   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (slotId < 0 || slotId >= 54 || this.isPlainClick()) {
         TeamManager.BotTeam team = TeamManager.get(this.teamName);
         if (team != null) {
            if (slotId == 9) {
               TeamManager.setTargets(this.teamName, Collections.emptyList());
               TeamManager.setTargetTeams(this.teamName, Collections.emptyList());
               TeamManager.setMode(this.teamName, TeamManager.TargetMode.NONE);
               this.rebuildAndSync();
            } else if (slotId == 10) {
               TeamManager.setMode(this.teamName, TeamManager.TargetMode.ALL_PLAYERS);
               this.rebuildAndSync();
            } else if (slotId == 11) {
               if (team.getMode() != TeamManager.TargetMode.SPECIFIC) {
                  TeamManager.setMode(this.teamName, TeamManager.TargetMode.SPECIFIC);
               }

               this.rebuildAndSync();
            } else if (slotId == 14) {
               if (team.getMode() != TeamManager.TargetMode.SPECIFIC_TEAMS) {
                  TeamManager.setMode(this.teamName, TeamManager.TargetMode.SPECIFIC_TEAMS);
               }

               this.rebuildAndSync();
            } else if (slotId == 12) {
               if (player instanceof ServerPlayer) {
                  ServerPlayer sp = (ServerPlayer)player;
                  sp.sendSystemMessage(VexText.literal(sp, "§7Edit who is on this team: §e/vexbot team " + this.teamName + " members"));
               }

            } else if (slotId == 17) {
               if (player instanceof ServerPlayer) {
                  ServerPlayer sp = (ServerPlayer)player;
                  sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamDeleteConfirmMenu(id, inv, this.teamName), VexText.literal("Delete Team: " + this.teamName)));
               }

            } else if (slotId == 13) {
               TeamManager.setTeamRevengeMode(this.teamName, !team.isRevengeMode());
               this.rebuildAndSync();
            } else if (slotId == 15) {
               if (team.getMode() == TeamManager.TargetMode.SPECIFIC_TEAMS && this.teamPage > 0) {
                  --this.teamPage;
                  this.rebuildVisuals();
               } else if (team.getMode() != TeamManager.TargetMode.SPECIFIC_TEAMS && this.entityPage > 0) {
                  --this.entityPage;
                  this.rebuildVisuals();
               }

            } else if (slotId != 16) {
               if (!this.handleEntityGridClick(slotId, team, player)) {
                  this.vanillaClick(slotId, button, player);
               }
            } else {
               if (team.getMode() == TeamManager.TargetMode.SPECIFIC_TEAMS && this.teamPage < this.maxTeamPage()) {
                  ++this.teamPage;
                  this.rebuildVisuals();
               } else if (team.getMode() != TeamManager.TargetMode.SPECIFIC_TEAMS && this.entityPage < this.maxEntityPage()) {
                  ++this.entityPage;
                  this.rebuildVisuals();
               }

            }
         }
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int i) {
      return ItemStack.EMPTY;
   }

   public void broadcastChanges() {
      super.broadcastChanges();
      List<TargetCandidate> freshE = this.computeEntityList();
      List<String> freshT = this.computeTeamList();
      if (!freshE.equals(this.entityList) || !freshT.equals(this.teamList)) {
         this.entityList = freshE;
         this.teamList = freshT;
         if (this.entityPage > this.maxEntityPage()) {
            this.entityPage = this.maxEntityPage();
         }

         if (this.teamPage > this.maxTeamPage()) {
            this.teamPage = this.maxTeamPage();
         }

         this.buildContainer();
         this.sendAllDataToRemote();
      }
   }

   private List<TargetCandidate> computeEntityList() {
      List<TargetCandidate> humans = new ArrayList();
      List<TargetCandidate> bots = new ArrayList();

      for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
         if (!p.isSpectator()) {
            String name = p.getName().getString();
            boolean teammate = TeamManager.isMemberOfTeam(this.teamName, name);
            if (!PlayerMenuHelper.isRealPlayer(p)) {
               if (!teammate) {
                  bots.add(new TargetCandidate(name, true, false));
               }
            } else {
               humans.add(new TargetCandidate(name, false, teammate));
            }
         }
      }

      humans.sort(Comparator.comparing((c) -> c.name));
      bots.sort(Comparator.comparing((c) -> c.name));
      List<TargetCandidate> result = new ArrayList(humans.size() + bots.size());
      result.addAll(humans);
      result.addAll(bots);
      return result;
   }

   private List<String> computeTeamList() {
      return (List)TeamManager.teamNames().stream().filter((name) -> !name.equals(this.teamName)).sorted().collect(Collectors.toList());
   }

   private int maxEntityPage() {
      return this.entityList.isEmpty() ? 0 : (this.entityList.size() - 1) / 18;
   }

   private int maxTeamPage() {
      return this.teamList.isEmpty() ? 0 : (this.teamList.size() - 1) / 18;
   }

   private void buildContainer() {
      TeamManager.BotTeam team = TeamManager.get(this.teamName);
      TeamManager.TargetMode mode = team != null ? team.getMode() : TeamManager.TargetMode.NONE;
      Set<String> targets = team != null ? team.getTargetNames() : Collections.emptySet();
      Set<String> targetTeams = team != null ? team.getTargetTeamNames() : Collections.emptySet();
      if (mode == TeamManager.TargetMode.SPECIFIC_TEAMS) {
         if (this.teamPage > this.maxTeamPage()) {
            this.teamPage = this.maxTeamPage();
         }
      } else if (this.entityPage > this.maxEntityPage()) {
         this.entityPage = this.maxEntityPage();
      }

      ItemStack filler = TeamBuilderMenu.makeItem(McCompat.pane(DyeColor.GRAY), " ");

      for(int i = 0; i < 54; ++i) {
         this.container.setItem(i, filler.copy());
      }

      int nb = team == null ? 0 : team.getBotNames().size();
      int np = team == null ? 0 : team.getPlayerNames().size();
      long humanCandidates = this.entityList.stream().filter((c) -> !c.bot() && !c.teammate()).count();
      long botCandidates = this.entityList.stream().filter((c) -> c.bot()).count();
      long teammatesShown = this.entityList.stream().filter((c) -> c.teammate()).count();
      List<String> bannerLore = new ArrayList();
      bannerLore.add("§7Roster: §a" + nb + " §7bot(s), §b" + np + " §7player(s)");
      bannerLore.add("§7Attackable: §a" + botCandidates + " §7bot(s), §b" + humanCandidates + " §7player(s)");
      if (teammatesShown > 0L) {
         bannerLore.add("§8Teammates shown (§e" + teammatesShown + "§8) — remove via §e/vexbot team <team> members");
      }

      String var10001 = this.teamName;
      bannerLore.add("§8Roster: §e/vexbot team " + var10001 + " members");
      var10001 = this.teamName;
      bannerLore.add("§8Gameplay: §e/vexbot team " + var10001 + " settings");
      String var10003 = this.teamName;
      this.container.setItem(4, TeamBuilderMenu.makeItem(Items.NAME_TAG, "§eTeam: " + var10003, (String[])bannerLore.toArray(new String[0])));
      boolean stopActive = mode == TeamManager.TargetMode.NONE;
      this.container.setItem(9, TeamBuilderMenu.makeItem(stopActive ? McCompat.pane(DyeColor.RED) : McCompat.pane(DyeColor.GRAY), stopActive ? "§c✖ Stop Attacking §c[Active]" : "§7✖ Stop Attacking", "§7No scripted targets. Enable §eAuto Target", "§7in team settings to hunt while stopped."));
      boolean allActive = mode == TeamManager.TargetMode.ALL_PLAYERS;
      this.container.setItem(10, TeamBuilderMenu.makeItem(allActive ? McCompat.pane(DyeColor.LIME) : McCompat.pane(DyeColor.GRAY), allActive ? "§a⚔ Attack All §a[Active]" : "§7⚔ Attack All", "§7Bots will attack the nearest", "§7non-team entity."));
      boolean specActive = mode == TeamManager.TargetMode.SPECIFIC;
      this.container.setItem(11, TeamBuilderMenu.makeItem(specActive ? McCompat.pane(DyeColor.CYAN) : McCompat.pane(DyeColor.GRAY), specActive ? "§b\ud83d\udc65 Attack Specific §b[Active]" : "§7\ud83d\udc65 Attack Specific", specActive ? "§7" + targets.size() + " target(s) chosen." : "§7Pick targets below.", "§8Click to enable, then pick targets."));
      boolean specTeamsActive = mode == TeamManager.TargetMode.SPECIFIC_TEAMS;
      this.container.setItem(14, TeamBuilderMenu.makeItem(specTeamsActive ? McCompat.pane(DyeColor.BLUE) : McCompat.pane(DyeColor.GRAY), specTeamsActive ? "§9\ud83d\udee1 Attack Teams §9[Active]" : "§7\ud83d\udee1 Attack Teams", specTeamsActive ? "§7" + targetTeams.size() + " team(s) chosen." : "§7Pick teams below.", "§8Click to enable, then pick teams."));
      this.container.setItem(12, TeamBuilderMenu.makeItem(Items.WRITABLE_BOOK, "§e✏ Team roster", "§7Run §e/vexbot team " + this.teamName + " members", "§7to add or remove bots.", "§8(Humans: §e/vexbot team join " + this.teamName + "§8)"));
      boolean revenge = team != null && team.isRevengeMode();
      this.container.setItem(13, TeamBuilderMenu.makeItem(revenge ? McCompat.pane(DyeColor.LIME) : McCompat.pane(DyeColor.RED), revenge ? "§aRevenge Mode §a[ON]" : "§cRevenge Mode §c[OFF]", "§7Bots retaliate when hit by a player.", "§8(Overrides team targeting.)", "§8[Currently: " + (revenge ? "§aON" : "§cOFF") + "§8]"));
      this.container.setItem(17, TeamBuilderMenu.makeItem(Items.TNT, "§c\ud83d\uddd1 Delete Team", "§7Permanently delete team §e" + this.teamName + "§7.", "§8Opens a confirmation menu."));
      this.refreshPaginationSlots(filler, mode);

      for(int s = 18; s <= 34; ++s) {
         this.container.setItem(s, filler.copy());
      }

      String var10000;
      switch (mode) {
         case NONE -> var10000 = "§cNo attack directive. §7(Enable §eAuto Target §7in team settings to hunt.)";
         case ALL_PLAYERS -> var10000 = "§aAttacking all non-team entities.";
         case SPECIFIC -> var10000 = targets.isEmpty() ? "§eSpecific mode — pick targets above." : "§aTargeting §e" + targets.size() + " §aentit(ies).";
         case SPECIFIC_TEAMS -> var10000 = targetTeams.isEmpty() ? "§eTeam mode — pick teams above." : "§aTargeting §e" + targetTeams.size() + " §ateam(s).";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      String statusText = var10000;
      List<String> statusLore = new ArrayList();
      if (teammatesShown > 0L) {
         statusLore.add("§8Teammates (gray heads) cannot be attack targets.");
         statusLore.add("§8Remove from roster: §e/vexbot team " + this.teamName + " members");
      }

      if (humanCandidates == 0L && botCandidates == 0L) {
         statusLore.add("§8No attackable players online — invite friends or pick Attack Teams.");
      }

      ItemStack statusItem = TeamBuilderMenu.makeItem(Items.PAPER, statusText, (String[])statusLore.toArray(new String[0]));
      this.container.setItem(35, statusItem);
      if (mode == TeamManager.TargetMode.SPECIFIC_TEAMS) {
         int offset = this.teamPage * 18;

         for(int i = 0; i < 18; ++i) {
            int slot = 36 + i;
            int idx = offset + i;
            if (idx < this.teamList.size()) {
               this.container.setItem(slot, this.makeTeamTargetHead((String)this.teamList.get(idx), targetTeams));
            } else {
               this.container.setItem(slot, filler.copy());
            }
         }
      } else {
         int offset = this.entityPage * 18;

         for(int i = 0; i < 18; ++i) {
            int slot = 36 + i;
            int idx = offset + i;
            if (idx < this.entityList.size()) {
               this.container.setItem(slot, this.makeEntityHead((TargetCandidate)this.entityList.get(idx), targets, mode, team));
            } else {
               this.container.setItem(slot, filler.copy());
            }
         }
      }

   }

   private void refreshPaginationSlots(ItemStack filler, TeamManager.TargetMode mode) {
      boolean teamPaging = mode == TeamManager.TargetMode.SPECIFIC_TEAMS && this.teamList.size() > 18;
      boolean entityPaging = mode != TeamManager.TargetMode.SPECIFIC_TEAMS && this.entityList.size() > 18;
      if (!teamPaging && !entityPaging) {
         this.container.setItem(15, filler.copy());
         this.container.setItem(16, filler.copy());
      } else {
         int page = teamPaging ? this.teamPage : this.entityPage;
         int maxPage = teamPaging ? this.maxTeamPage() : this.maxEntityPage();
         String kind = teamPaging ? "teams" : "targets";
         int pages = maxPage + 1;
         String pageLine = "§7" + kind + " page §f" + (page + 1) + "§7/§f" + pages;
         if (page > 0) {
            this.container.setItem(15, TeamBuilderMenu.makeItem(Items.SPECTRAL_ARROW, "§e◀ Previous", pageLine, "§8Click for previous 18 " + kind));
         } else {
            this.container.setItem(15, TeamBuilderMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§8◀ First page", pageLine));
         }

         if (page < maxPage) {
            this.container.setItem(16, TeamBuilderMenu.makeItem(Items.SPECTRAL_ARROW, "§eNext ▶", pageLine, "§8Click for next 18 " + kind));
         } else {
            this.container.setItem(16, TeamBuilderMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§8Last page ▶", pageLine));
         }

      }
   }

   private void rebuildVisuals() {
      this.buildContainer();
      this.sendAllDataToRemote();
   }

   private void rebuildAndSync() {
      this.rebuildVisuals();
      if (VexBot.SERVER != null) {
         SettingsPersistence.save(VexBot.SERVER);
      }

   }

   private boolean handleEntityGridClick(int slotId, TeamManager.BotTeam team, Player player) {
      if (slotId >= 0 && slotId < this.slots.size()) {
         Slot clicked = (Slot)this.slots.get(slotId);
         if (clicked.container != this.container) {
            return false;
         } else {
            int containerSlot = clicked.getContainerSlot();
            int gridIdx = containerSlot - 36;
            if (gridIdx >= 0 && gridIdx < 18) {
               TeamManager.TargetMode mode = team.getMode();
               if (mode != TeamManager.TargetMode.SPECIFIC && mode != TeamManager.TargetMode.NONE && mode != TeamManager.TargetMode.ALL_PLAYERS) {
                  if (mode == TeamManager.TargetMode.SPECIFIC_TEAMS) {
                     int idx = this.teamPage * 18 + gridIdx;
                     if (idx >= this.teamList.size()) {
                        return true;
                     } else {
                        String targetTeam = (String)this.teamList.get(idx);
                        Set<String> currentTeams = new LinkedHashSet(team.getTargetTeamNames());
                        if (currentTeams.contains(targetTeam)) {
                           currentTeams.remove(targetTeam);
                        } else {
                           currentTeams.add(targetTeam);
                        }

                        TeamManager.setTargetTeams(this.teamName, currentTeams);
                        this.rebuildAndSync();
                        return true;
                     }
                  } else {
                     return false;
                  }
               } else {
                  int idx = this.entityPage * 18 + gridIdx;
                  if (idx >= this.entityList.size()) {
                     return true;
                  } else {
                     TargetCandidate candidate = (TargetCandidate)this.entityList.get(idx);
                     if (candidate.teammate()) {
                        if (player instanceof ServerPlayer) {
                           ServerPlayer sp = (ServerPlayer)player;
                           String var10002 = candidate.name();
                           sp.sendSystemMessage(VexText.literal(sp, "§c[VexBot] §e" + var10002 + " §cis on your team roster — cannot attack. Remove them with §e/vexbot team " + this.teamName + " members"));
                        }

                        return true;
                     } else {
                        String targetName = candidate.name();
                        Set<String> current = new LinkedHashSet(team.getTargetNames());
                        boolean nowTargeted = TeamManager.toggleTargetName(current, targetName);
                        TeamManager.setTargets(this.teamName, current);
                        this.rebuildAndSync();
                        if (player instanceof ServerPlayer) {
                           ServerPlayer sp = (ServerPlayer)player;
                           int n = current.size();
                           sp.sendSystemMessage(VexText.literal(sp, nowTargeted ? "§a[VexBot] Now targeting §e" + targetName + (n >= 2 ? " §7(§f" + n + " §7targets — bots split evenly by gear power)" : "") : "§7[VexBot] Removed §e" + targetName + " §7from targets"));
                        }

                        return true;
                     }
                  }
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private ItemStack makeEntityHead(TargetCandidate candidate, Set<String> targets, TeamManager.TargetMode mode, TeamManager.BotTeam team) {
      String name = candidate.name();
      boolean isTargeted = TeamManager.targetNamesContains(targets, name);
      String assigned = team != null && isTargeted && team.getBotNames().size() >= 2 ? countBotsAssignedTo(team, name) + " bots" : null;
      ItemStack head = new ItemStack(Items.PLAYER_HEAD);
      ServerPlayer p = BotManager.resolveTrackedBotPlayer(this.server, name);
      if (p == null) {
         p = BotManager.resolveNonBotPlayerByName(this.server, name);
      }

      if (p != null) {
         head.set(DataComponents.PROFILE, ResolvableProfile.createResolved(p.getGameProfile()));
      }

      String prefix = candidate.teammate() ? "§8" : (isTargeted ? "§a" : "§7");
      String suffix = candidate.teammate() ? " §8(roster)" : (isTargeted ? " §a✔" : "");
      head.set(DataComponents.CUSTOM_NAME, VexText.literal(prefix + name + suffix).setStyle(Style.EMPTY.withItalic(false)));
      List<Component> lore = new ArrayList();
      if (candidate.teammate()) {
         lore.add(VexText.literal("§8On your team — not attackable").setStyle(Style.EMPTY.withItalic(false)));
         lore.add(VexText.literal("§8/vexbot team " + this.teamName + " members").setStyle(Style.EMPTY.withItalic(false)));
      } else if (mode != TeamManager.TargetMode.SPECIFIC && mode != TeamManager.TargetMode.NONE) {
         if (mode == TeamManager.TargetMode.SPECIFIC_TEAMS) {
            lore.add(VexText.literal("§8(Team mode active)").setStyle(Style.EMPTY.withItalic(false)));
         } else {
            lore.add(VexText.literal("§8(All mode active)").setStyle(Style.EMPTY.withItalic(false)));
         }
      } else {
         lore.add(VexText.literal(isTargeted ? "§a✔ Targeted" + (assigned != null ? " §7(" + assigned + ")" : "") : "§8Click to target").setStyle(Style.EMPTY.withItalic(false)));
      }

      head.set(DataComponents.LORE, new ItemLore(lore));
      return head;
   }

   private static String countBotsAssignedTo(TeamManager.BotTeam team, String targetPlayer) {
      int n = 0;

      for(Map.Entry<String, String> e : team.getBotTargetAssignments().entrySet()) {
         if (e.getValue() != null && ((String)e.getValue()).equalsIgnoreCase(targetPlayer)) {
            ++n;
         }
      }

      return Integer.toString(n);
   }

   private ItemStack makeTeamTargetHead(String targetTeam, Set<String> targetedTeams) {
      boolean selected = targetedTeams.contains(targetTeam);
      ItemStack head = new ItemStack(Items.PLAYER_HEAD);
      ServerPlayer rep = this.findRepresentativeOnlineForTeam(targetTeam);
      if (rep != null) {
         head.set(DataComponents.PROFILE, ResolvableProfile.createResolved(rep.getGameProfile()));
      }

      head.set(DataComponents.CUSTOM_NAME, VexText.literal(selected ? "§9" + targetTeam + " §9✔" : "§7" + targetTeam).setStyle(Style.EMPTY.withItalic(false)));
      head.set(DataComponents.LORE, new ItemLore(List.of(VexText.literal(selected ? "§9✔ Team targeted" : "§8Click to target this team").setStyle(Style.EMPTY.withItalic(false)), VexText.literal(rep != null ? "§8Skin: online member" : "§8Skin: no one online").setStyle(Style.EMPTY.withItalic(false)))));
      return head;
   }

   private ServerPlayer findRepresentativeOnlineForTeam(String targetTeamName) {
      TeamManager.BotTeam target = TeamManager.get(targetTeamName);
      if (target == null) {
         return null;
      } else {
         for(ServerPlayer p : this.server.getPlayerList().getPlayers()) {
            if (!p.isSpectator()) {
               TeamManager.BotTeam onTeam = TeamManager.getTeamForMember(p.getName().getString());
               if (onTeam != null && onTeam.getName().equals(targetTeamName)) {
                  return p;
               }
            }
         }

         for(String botName : target.getBotNames()) {
            ServerPlayer b = BotManager.resolveTrackedBotPlayer(this.server, botName);
            if (b != null && b.isAlive() && !b.isSpectator()) {
               return b;
            }
         }

         for(String pname : target.getPlayerNames()) {
            ServerPlayer h = BotManager.resolveNonBotPlayerByName(this.server, pname);
            if (h != null && h.isAlive() && !h.isSpectator()) {
               return h;
            }
         }

         return null;
      }
   }

   private static record TargetCandidate(String name, boolean bot, boolean teammate) {
   }

   private static final class LockedSlot extends Slot {
      LockedSlot(SimpleContainer c, int i, int x, int y) {
         super(c, i, x, y);
      }

      public boolean mayPickup(Player p) {
         return false;
      }

      public boolean mayPlace(ItemStack s) {
         return false;
      }
   }
}
