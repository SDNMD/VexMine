package vexbot.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import vexbot.command.VexBotCommand;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;

public final class TeamDeleteAllMenu extends VexMenu {
   private static final int SIZE = 27;
   private static final int SLOT_CONFIRM = 11;
   private static final int SLOT_INFO = 13;
   private static final int SLOT_CANCEL = 15;
   private final SimpleContainer container = new SimpleContainer(27);
   private final MinecraftServer server;
   private final boolean finalStep;

   public static void open(ServerPlayer viewer, MinecraftServer server, boolean finalStep) {
      viewer.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamDeleteAllMenu(id, inv, server, finalStep), VexText.literal(finalStep ? "Just to confirm..." : "Delete ALL teams?")));
   }

   private TeamDeleteAllMenu(int id, Inventory inv, MinecraftServer server, boolean finalStep) {
      super(MenuType.GENERIC_9x3, id, inv);
      BukkitCompat.setMenuPlayer(this, inv);
      this.server = server;
      this.finalStep = finalStep;
      List<String> names = new ArrayList(TeamManager.teamNames());
      names.sort(String.CASE_INSENSITIVE_ORDER);
      int bots = 0;

      for(String n : names) {
         TeamManager.BotTeam t = TeamManager.get(n);
         if (t != null) {
            bots += t.getBotNames().size();
         }
      }

      ItemStack filler = item(McCompat.pane(finalStep ? DyeColor.RED : DyeColor.GRAY), " ");

      for(int i = 0; i < 27; ++i) {
         this.container.setItem(i, filler.copy());
      }

      List<String> info = new ArrayList();
      int var10001 = names.size();
      info.add("§7Teams: §f" + var10001 + "§7 · bots left teamless: §f" + bots);

      for(int i = 0; i < Math.min(names.size(), 12); ++i) {
         Object var19 = names.get(i);
         info.add("§8• §e" + (String)var19);
      }

      if (names.size() > 12) {
         var10001 = names.size();
         info.add("§8…and " + (var10001 - 12) + " more");
      }

      info.add("§cSettings, orders, targets, alliances and horns go too.");
      info.add("§cThis cannot be undone.");
      this.container.setItem(13, item(Items.TNT, finalStep ? "§4§lJust to confirm — delete every team?" : "§c§lDelete ALL teams?", (String[])info.toArray((x$0) -> new String[x$0])));
      this.container.setItem(11, item(McCompat.pane(DyeColor.LIME), finalStep ? "§a§l✔ Yes, delete them all" : "§a✔ I'm sure", finalStep ? "§7Deletes every team now." : "§7One more confirmation follows."));
      this.container.setItem(15, item(McCompat.pane(DyeColor.RED), "§c✖ Cancel", "§7Keep every team."));

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new KitListMenu.LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(inv, col, 8 + col * 18, 142));
      }

   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (slotId < 0 || slotId >= 27 || this.isPlainClick()) {
         if (player instanceof ServerPlayer) {
            ServerPlayer sp = (ServerPlayer)player;
            if (slotId == 15) {
               sp.closeContainer();
               sp.sendSystemMessage(VexText.literal(sp, "[VexBot] §7Cancelled — no teams were deleted."));
            } else if (slotId == 11) {
               if (!this.finalStep) {
                  open(sp, this.server, true);
               } else {
                  sp.closeContainer();
                  int n = VexBotCommand.deleteAllTeams(this.server);
                  sp.sendSystemMessage(VexText.literal(sp, n == 0 ? "[VexBot] §7There were no teams to delete." : "[VexBot] §aDeleted all §e" + n + "§a team(s). (Bots themselves are not removed.)"));
               }
            } else {
               if (slotId >= 27 || slotId < 0) {
                  this.vanillaClick(slotId, button, player);
               }

            }
         }
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int i) {
      return ItemStack.EMPTY;
   }

   private static ItemStack item(Item icon, String name, String... lore) {
      ItemStack s = new ItemStack(icon);
      s.set(DataComponents.CUSTOM_NAME, VexText.literal(name).setStyle(Style.EMPTY.withItalic(false)));
      if (lore.length > 0) {
         List<Component> lines = new ArrayList();

         for(String l : lore) {
            lines.add(VexText.literal(l).setStyle(Style.EMPTY.withItalic(false)));
         }

         s.set(DataComponents.LORE, new ItemLore(lines));
      }

      return s;
   }
}
