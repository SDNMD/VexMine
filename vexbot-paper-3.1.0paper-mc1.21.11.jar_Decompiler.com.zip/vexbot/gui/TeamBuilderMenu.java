package vexbot.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.ResolvableProfile;
import vexbot.SettingsPersistence;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;

public final class TeamBuilderMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int SIZE = 54;
   private static final int SLOT_SELECT_ALL = 45;
   private static final int SLOT_DESELECT_ALL = 46;
   private static final int SLOT_COUNT = 49;
   private static final int SLOT_TARGETS = 50;
   private static final int SLOT_SAVE = 52;
   private static final int SLOT_SETTINGS = 53;
   private static final int SLOT_BOT_PREV = 47;
   private static final int SLOT_BOT_NEXT = 48;
   private static final int SLOT_HUMAN_ROW = 37;
   private static final int HUMAN_PER_PAGE = 7;
   private static final int BOT_GRID_MEMBERS = 36;
   private static final int SLOT_HUMAN_PREV = 36;
   private static final int SLOT_HUMAN_NEXT = 44;
   private int botPage;
   private int humanPage;
   private final SimpleContainer container;
   private final MinecraftServer server;
   private final String teamName;
   private final boolean membersOnly;
   private final Set<String> selected;
   private final Set<String> selectedHumans;
   private List<String> botList;
   private List<PlayerMenuHelper.HumanEntry> humanList;
   private int refreshTick;

   public TeamBuilderMenu(int containerId, Inventory playerInventory, MinecraftServer server, String teamName) {
      this(containerId, playerInventory, server, teamName, false);
   }

   public TeamBuilderMenu(int containerId, Inventory playerInventory, MinecraftServer server, String teamName, boolean membersOnly) {
      super(MenuType.GENERIC_9x6, containerId, playerInventory);
      this.botPage = 0;
      this.humanPage = 0;
      this.container = new SimpleContainer(54);
      this.selected = new LinkedHashSet();
      this.selectedHumans = new LinkedHashSet();
      this.humanList = new ArrayList();
      this.refreshTick = 0;
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.server = server;
      String canon = TeamManager.canonicalName(teamName);
      this.teamName = canon != null ? canon : teamName;
      this.membersOnly = membersOnly;
      TeamManager.BotTeam existing = TeamManager.get(this.teamName);
      if (existing != null) {
         this.selected.addAll(existing.getBotNames());

         for(String pname : existing.getPlayerNames()) {
            this.addHumanSelected(pname);
         }
      }

      this.botList = this.currentBotList();
      this.humanList = PlayerMenuHelper.onlineHumans(server, this.teamName);
      ItemStack filler = makeItem(McCompat.pane(DyeColor.GRAY), " ");

      for(int i = 0; i < 54; ++i) {
         this.container.setItem(i, filler.copy());
      }

      this.rebuildGrid();
      this.refreshCountSlot();
      this.refreshSelectAllSlots();
      this.container.setItem(52, makeItem(McCompat.pane(DyeColor.LIME), membersOnly ? "§a✔ Save roster" : "§a✔ Save Team", membersOnly ? "§7Save bots + human players for §e" + teamName + "§7." : "§7Save and assign selected bots", membersOnly ? "" : "§7to team §e" + teamName + "§7."));
      if (membersOnly) {
         this.container.setItem(50, makeItem(Items.PAPER, "§7Attack targets", "§8/vexbot team " + teamName + " targets"));
         this.container.setItem(53, makeItem(Items.PAPER, "§7Gameplay settings", "§8/vexbot team " + teamName + " settings"));
      } else {
         this.container.setItem(50, makeItem(Items.IRON_SWORD, "§cAttack Targets →", "§7Who this team fights (modes, grid).", "§8§e/vexbot team " + teamName + " targets"));
         this.container.setItem(53, makeItem(Items.COMPASS, "§eGameplay Settings →", "§7Same options as §e/vexbot settings", "§7but only for bots in §e" + teamName + "§7."));
      }

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 138 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 196));
      }

   }

   public void broadcastChanges() {
      super.broadcastChanges();
      if (++this.refreshTick >= 2) {
         this.refreshTick = 0;
         List<String> freshBots = this.currentBotList();
         boolean botsChanged = !freshBots.equals(this.botList);
         this.botList = freshBots;
         List<PlayerMenuHelper.HumanEntry> freshHumans = PlayerMenuHelper.onlineHumans(this.server, this.teamName);
         boolean humansChanged = !freshHumans.equals(this.humanList);
         this.humanList = freshHumans;
         if (botsChanged || humansChanged) {
            if (this.botPage > this.maxBotPage()) {
               this.botPage = this.maxBotPage();
            }

            this.rebuildGrid();
            this.refreshSelectAllSlots();
            this.sendAllDataToRemote();
         }

         this.pruneSelectedFromStaleRoster();
         this.refreshCountSlot();
      }
   }

   private void pruneSelectedFromStaleRoster() {
      TeamManager.BotTeam roster = TeamManager.get(this.teamName);
      if (roster != null) {
         this.selected.removeIf((n) -> !roster.getBotNames().contains(n) && !this.botList.contains(n));
      }
   }

   private int botPageSize() {
      return 36;
   }

   private int maxBotPage() {
      int ps = this.botPageSize();
      return !this.botList.isEmpty() && ps > 0 ? (this.botList.size() - 1) / ps : 0;
   }

   private List<String> currentBotList() {
      return (List)this.server.getPlayerList().getPlayers().stream().filter((p) -> !PlayerMenuHelper.isRealPlayer(p)).filter((p) -> !BotManager.isPracticeBot(p.getName().getString())).filter((p) -> {
         TeamManager.BotTeam assignedTeam = TeamManager.getTeamForBot(p.getName().getString());
         return assignedTeam == null || assignedTeam.getName().equals(this.teamName);
      }).map((p) -> p.getName().getString()).sorted().collect(Collectors.toList());
   }

   private void rebuildGrid() {
      ItemStack filler = makeItem(McCompat.pane(DyeColor.GRAY), " ");
      int ps = this.botPageSize();

      for(int i = 0; i < ps; ++i) {
         this.container.setItem(i, filler.copy());
      }

      if (this.botList.isEmpty()) {
         this.botPage = 0;
         this.container.setItem(4, makeItem(Items.BARRIER, "§cNo bots spawned yet", "§7Use §e/vexbot spawn <name>", "§7to spawn bots, then reopen", "§7this menu to assign them."));
      } else {
         if (this.botPage > this.maxBotPage()) {
            this.botPage = this.maxBotPage();
         }

         int offset = this.botPage * ps;
         int shown = Math.min(ps, this.botList.size() - offset);

         for(int i = 0; i < shown; ++i) {
            this.container.setItem(i, this.makeBotHead((String)this.botList.get(offset + i)));
         }
      }

      this.refreshPaginationSlots(filler);
      int maxHumanPage = this.maxHumanPage();
      if (this.humanPage > maxHumanPage) {
         this.humanPage = maxHumanPage;
      }

      int hOffset = this.humanPage * 7;

      for(int j = 0; j < 7; ++j) {
         int slot = 37 + j;
         int hidx = hOffset + j;
         if (hidx < this.humanList.size()) {
            this.container.setItem(slot, this.makeHumanHead((PlayerMenuHelper.HumanEntry)this.humanList.get(hidx)));
         } else if (j == 3 && this.humanList.isEmpty()) {
            this.container.setItem(slot, makeItem(Items.PLAYER_HEAD, "§8No guests online", "§7LAN / Essential friends appear here", "§7when they join your world."));
         } else {
            this.container.setItem(slot, filler.copy());
         }
      }

      this.refreshHumanPaginationSlots(filler);
   }

   private int maxHumanPage() {
      return this.humanList.isEmpty() ? 0 : (this.humanList.size() - 1) / 7;
   }

   private void refreshHumanPaginationSlots(ItemStack filler) {
      if (this.maxHumanPage() <= 0) {
         this.container.setItem(36, filler.copy());
         this.container.setItem(44, filler.copy());
      } else {
         int pages = this.maxHumanPage() + 1;
         int var10000 = this.humanPage + 1;
         String pageLine = "§7Players page §f" + var10000 + "§7/§f" + pages;
         if (this.humanPage > 0) {
            this.container.setItem(36, makeItem(Items.SPECTRAL_ARROW, "§e◀ Prev players", pageLine));
         } else {
            this.container.setItem(36, makeItem(McCompat.pane(DyeColor.GRAY), "§8◀ First page", pageLine));
         }

         if (this.humanPage < this.maxHumanPage()) {
            this.container.setItem(44, makeItem(Items.SPECTRAL_ARROW, "§eNext players ▶", pageLine));
         } else {
            this.container.setItem(44, makeItem(McCompat.pane(DyeColor.GRAY), "§8Last page ▶", pageLine));
         }

      }
   }

   private void refreshPaginationSlots(ItemStack filler) {
      if (this.maxBotPage() <= 0) {
         this.container.setItem(47, filler.copy());
         this.container.setItem(48, filler.copy());
      } else {
         int pages = this.maxBotPage() + 1;
         int var10000 = this.botPage + 1;
         String pageLine = "§7Bots page §f" + var10000 + "§7/§f" + pages;
         if (this.botPage > 0) {
            this.container.setItem(47, makeItem(Items.SPECTRAL_ARROW, "§e◀ Previous bots", pageLine, "§8Click for previous " + this.botPageSize() + " bots"));
         } else {
            this.container.setItem(47, makeItem(McCompat.pane(DyeColor.GRAY), "§8◀ First page", pageLine));
         }

         if (this.botPage < this.maxBotPage()) {
            this.container.setItem(48, makeItem(Items.SPECTRAL_ARROW, "§eNext bots ▶", pageLine, "§8Click for next " + this.botPageSize() + " bots"));
         } else {
            this.container.setItem(48, makeItem(McCompat.pane(DyeColor.GRAY), "§8Last page ▶", pageLine));
         }

      }
   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (slotId < 0 || slotId >= 54 || this.isPlainClick()) {
         if (slotId == 52) {
            this.commitBotRoster();
            this.commitHumanRoster();
            if (VexBot.SERVER != null) {
               SettingsPersistence.save(VexBot.SERVER);
            }

            if (player instanceof ServerPlayer) {
               ServerPlayer sp = (ServerPlayer)player;
               TeamManager.BotTeam saved = TeamManager.get(this.teamName);
               String humans = saved != null && !saved.getPlayerNames().isEmpty() ? "§f" + String.join("§7, §f", saved.getPlayerNames()) : "§8(none)";
               String var10001 = this.teamName;
               sp.sendSystemMessage(VexText.literal("§a[VexBot] Team §e" + var10001 + " §asaved — §7bots: §f" + (saved != null ? saved.getBotNames().size() : 0) + "§7, humans: " + humans + "§7. §8(Use §e/vexbot team join§8 to add yourself; deselect here to remove.)"));
               sp.closeContainer();
            }

         } else if (!this.membersOnly && slotId == 50) {
            this.commitBotRoster();
            this.commitHumanRoster();
            if (VexBot.SERVER != null) {
               SettingsPersistence.save(VexBot.SERVER);
            }

            if (player instanceof ServerPlayer) {
               ServerPlayer sp = (ServerPlayer)player;
               sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamTargetsMenu(id, inv, this.server, this.teamName), VexText.literal("Team targets: " + this.teamName)));
            }

         } else if (!this.membersOnly && slotId == 53) {
            this.commitBotRoster();
            this.commitHumanRoster();
            if (VexBot.SERVER != null) {
               SettingsPersistence.save(VexBot.SERVER);
            }

            if (player instanceof ServerPlayer) {
               ServerPlayer sp = (ServerPlayer)player;
               TeamSettingsMenu.open(sp, this.teamName);
            }

         } else if (slotId == 45) {
            this.selected.addAll(this.botList);

            for(PlayerMenuHelper.HumanEntry e : this.humanList) {
               if (e.state() != PlayerMenuHelper.HumanRowState.ON_OTHER_TEAM) {
                  this.addHumanSelected(e.name());
               }
            }

            this.commitBotRoster();
            this.commitHumanRoster();
            this.refreshBotAndHumanVisuals();
            this.refreshCountSlot();
            this.refreshSelectAllSlots();
            this.sendAllDataToRemote();
         } else if (slotId == 46) {
            this.selected.clear();
            this.selectedHumans.clear();
            this.commitBotRoster();
            this.commitHumanRoster();
            this.refreshBotAndHumanVisuals();
            this.refreshCountSlot();
            this.refreshSelectAllSlots();
            this.sendAllDataToRemote();
         } else if (slotId == 47 && this.botPage > 0) {
            --this.botPage;
            this.rebuildGrid();
            this.refreshCountSlot();
            this.refreshSelectAllSlots();
            this.sendAllDataToRemote();
         } else if (slotId == 48 && this.botPage < this.maxBotPage()) {
            ++this.botPage;
            this.rebuildGrid();
            this.refreshCountSlot();
            this.refreshSelectAllSlots();
            this.sendAllDataToRemote();
         } else {
            int ps = this.botPageSize();
            int offset = this.botPage * ps;
            if (slotId >= 0 && slotId < ps) {
               int idx = offset + slotId;
               if (idx < this.botList.size()) {
                  String name = (String)this.botList.get(idx);
                  if (this.selected.contains(name)) {
                     this.selected.remove(name);
                  } else {
                     this.selected.add(name);
                  }

                  this.commitBotRoster();
                  this.container.setItem(slotId, this.makeBotHead(name));
                  this.refreshCountSlot();
                  this.refreshSelectAllSlots();
                  this.sendAllDataToRemote();
               }

            } else if (slotId == 36 && this.humanPage > 0) {
               --this.humanPage;
               this.rebuildGrid();
               this.refreshCountSlot();
               this.refreshSelectAllSlots();
               this.sendAllDataToRemote();
            } else if (slotId == 44 && this.humanPage < this.maxHumanPage()) {
               ++this.humanPage;
               this.rebuildGrid();
               this.refreshCountSlot();
               this.refreshSelectAllSlots();
               this.sendAllDataToRemote();
            } else if (slotId >= 37 && slotId < 44) {
               int idx = this.humanPage * 7 + (slotId - 37);
               if (idx >= 0 && idx < this.humanList.size()) {
                  PlayerMenuHelper.HumanEntry entry = (PlayerMenuHelper.HumanEntry)this.humanList.get(idx);
                  if (entry.state() == PlayerMenuHelper.HumanRowState.ON_OTHER_TEAM) {
                     if (player instanceof ServerPlayer) {
                        ServerPlayer sp = (ServerPlayer)player;
                        String var10002 = entry.name();
                        sp.sendSystemMessage(VexText.literal(sp, "§c[VexBot] §e" + var10002 + " §cis on team §e" + TeamManager.getTeamForMember(entry.name()).getName() + "§c — remove them there first."));
                     }

                     return;
                  }

                  String hname = entry.name();
                  if (this.containsHumanSelected(hname)) {
                     this.removeHumanSelected(hname);
                  } else {
                     this.addHumanSelected(hname);
                  }

                  this.commitHumanRoster();
                  this.container.setItem(slotId, this.makeHumanHead(entry));
                  this.refreshCountSlot();
                  this.refreshSelectAllSlots();
                  this.sendAllDataToRemote();
               }

            } else {
               this.vanillaClick(slotId, button, player);
            }
         }
      }
   }

   private void commitBotRoster() {
      TeamManager.setTeamBots(this.teamName, this.selected);
   }

   private void commitHumanRoster() {
      TeamManager.BotTeam team = TeamManager.get(this.teamName);
      Set<String> previous = (Set<String>)(team != null ? new LinkedHashSet(team.getPlayerNames()) : Set.of());
      LinkedHashSet<String> normalized = new LinkedHashSet();

      for(String name : this.selectedHumans) {
         if (name != null && !name.isBlank()) {
            ServerPlayer live = BotManager.resolveNonBotPlayerByName(this.server, name);
            normalized.add(live != null ? live.getName().getString() : name.strip());
         }
      }

      this.selectedHumans.clear();
      this.selectedHumans.addAll(normalized);
      TeamManager.setTeamPlayers(this.teamName, this.selectedHumans);

      for(String old : previous) {
         if (!this.containsHumanSelected(old)) {
            TeamManager.removePlayerFromTeam(this.teamName, old);
         }
      }

      this.humanList = PlayerMenuHelper.onlineHumans(this.server, this.teamName);
   }

   private void refreshBotAndHumanVisuals() {
      ItemStack filler = makeItem(McCompat.pane(DyeColor.GRAY), " ");
      int ps = this.botPageSize();
      int offset = this.botPage * ps;

      for(int i = 0; i < ps; ++i) {
         if (offset + i < this.botList.size()) {
            this.container.setItem(i, this.makeBotHead((String)this.botList.get(offset + i)));
         } else {
            this.container.setItem(i, filler.copy());
         }
      }

      this.refreshPaginationSlots(filler);
      int hOffset = this.humanPage * 7;

      for(int j = 0; j < 7; ++j) {
         int hidx = hOffset + j;
         int slot = 37 + j;
         if (hidx < this.humanList.size()) {
            this.container.setItem(slot, this.makeHumanHead((PlayerMenuHelper.HumanEntry)this.humanList.get(hidx)));
         } else {
            this.container.setItem(slot, filler.copy());
         }
      }

      this.refreshHumanPaginationSlots(filler);
   }

   private boolean containsHumanSelected(String name) {
      for(String s : this.selectedHumans) {
         if (s != null && s.equalsIgnoreCase(name)) {
            return true;
         }
      }

      return false;
   }

   private void addHumanSelected(String name) {
      this.removeHumanSelected(name);
      this.selectedHumans.add(name);
   }

   private void removeHumanSelected(String name) {
      this.selectedHumans.removeIf((s) -> s != null && s.equalsIgnoreCase(name));
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int i) {
      return ItemStack.EMPTY;
   }

   private ItemStack makeHumanHead(PlayerMenuHelper.HumanEntry entry) {
      String playerName = entry.name();
      boolean isSelected = this.containsHumanSelected(playerName);
      ItemStack head = new ItemStack(Items.PLAYER_HEAD);
      ServerPlayer sp = BotManager.resolveNonBotPlayerByName(this.server, playerName);
      if (sp != null) {
         head.set(DataComponents.PROFILE, ResolvableProfile.createResolved(sp.getGameProfile()));
      }

      String var10000;
      switch (entry.state()) {
         case ON_OTHER_TEAM:
            var10000 = "§8";
            break;
         case ON_THIS_TEAM:
         case AVAILABLE:
            var10000 = isSelected ? "§b" : "§7";
            break;
         default:
            throw new MatchException((String)null, (Throwable)null);
      }

      String prefix = var10000;
      String suffix = isSelected ? " §b✔" : (entry.state() == PlayerMenuHelper.HumanRowState.ON_OTHER_TEAM ? " §8(other team)" : "");
      head.set(DataComponents.CUSTOM_NAME, VexText.literal(prefix + playerName + suffix).setStyle(Style.EMPTY.withItalic(false)));
      List<Component> lore = new ArrayList();
      if (entry.state() == PlayerMenuHelper.HumanRowState.ON_OTHER_TEAM) {
         TeamManager.BotTeam other = TeamManager.getTeamForMember(playerName);
         String var10001 = other != null ? other.getName() : "?";
         lore.add(VexText.literal("§8On team §e" + var10001).setStyle(Style.EMPTY.withItalic(false)));
         lore.add(VexText.literal("§8Cannot add here").setStyle(Style.EMPTY.withItalic(false)));
      } else if (isSelected) {
         lore.add(VexText.literal("§b✔ On team roster").setStyle(Style.EMPTY.withItalic(false)));
         lore.add(VexText.literal("§8Click to remove").setStyle(Style.EMPTY.withItalic(false)));
      } else {
         lore.add(VexText.literal("§8Click to add to team").setStyle(Style.EMPTY.withItalic(false)));
      }

      lore.add(VexText.literal("§8Real player (LAN guest OK)").setStyle(Style.EMPTY.withItalic(false)));
      head.set(DataComponents.LORE, new ItemLore(lore));
      return head;
   }

   private ItemStack makeBotHead(String botName) {
      boolean isSelected = this.selected.contains(botName);
      TeamManager.BotTeam savedTeam = TeamManager.get(this.teamName);
      boolean isSaved = savedTeam != null && savedTeam.getBotNames().contains(botName);
      ItemStack head = new ItemStack(Items.PLAYER_HEAD);
      ServerPlayer botPlayer = BotManager.resolveTrackedBotPlayer(this.server, botName);
      if (botPlayer != null) {
         head.set(DataComponents.PROFILE, ResolvableProfile.createResolved(botPlayer.getGameProfile()));
      }

      String displayName = isSelected ? "§a" + botName + " §a✔" : "§7" + botName;
      head.set(DataComponents.CUSTOM_NAME, VexText.literal(displayName).setStyle(Style.EMPTY.withItalic(false)));
      List<Component> lore = new ArrayList();
      if (isSelected) {
         lore.add(VexText.literal(isSaved ? "§a✔ In this team" : "§e✔ Selected (unsaved)").setStyle(Style.EMPTY.withItalic(false)));
      } else {
         lore.add(VexText.literal("§8Click to add to team").setStyle(Style.EMPTY.withItalic(false)));
      }

      head.set(DataComponents.LORE, new ItemLore(lore));
      return head;
   }

   private void refreshSelectAllSlots() {
      boolean allBots = !this.botList.isEmpty() && this.selected.containsAll(this.botList);
      boolean allHumans = this.humanList.isEmpty() || this.humanList.stream().filter((e) -> e.state() != PlayerMenuHelper.HumanRowState.ON_OTHER_TEAM).allMatch((e) -> this.containsHumanSelected(e.name()));
      boolean allSelected = allBots && allHumans;
      this.container.setItem(45, makeItem(allSelected ? McCompat.pane(DyeColor.LIME) : McCompat.pane(DyeColor.GREEN), "§a✔ Select All", "§7All listed bots + online real players (row below bots)."));
      this.container.setItem(46, makeItem(McCompat.pane(DyeColor.RED), "§c✖ Deselect All", "§7Clears bot and human selections."));
   }

   private void refreshCountSlot() {
      int selBots = this.selected.size();
      int onlineBots = this.botList.size();
      int hSel = this.selectedHumans.size();
      int hOnline = this.humanList.size();
      String text = "§a" + selBots + " §7bots §8| §b" + hSel + "§7/§f" + hOnline + " §7humans §8| §f" + onlineBots + " §7bots online";
      if (this.maxBotPage() > 0) {
         text = text + " §8| §7bot p.§f" + (this.botPage + 1) + "§7/§f" + (this.maxBotPage() + 1);
      }

      if (this.maxHumanPage() > 0) {
         text = text + " §8| §7player p.§f" + (this.humanPage + 1) + "§7/§f" + (this.maxHumanPage() + 1);
      }

      this.container.setItem(49, makeItem(selBots <= 0 && this.selectedHumans.isEmpty() ? McCompat.pane(DyeColor.GRAY) : McCompat.pane(DyeColor.LIME), text));
   }

   static ItemStack makeItem(Item item, String name, String... lore) {
      ItemStack stack = new ItemStack(item);
      stack.set(DataComponents.CUSTOM_NAME, VexText.literal(name).setStyle(Style.EMPTY.withItalic(false)));
      List<String> loreLines = Arrays.stream(lore).filter((s) -> !s.isEmpty()).toList();
      if (!loreLines.isEmpty()) {
         List<Component> lines = loreLines.stream().map((l) -> VexText.literal(l).setStyle(Style.EMPTY.withItalic(false))).toList();
         stack.set(DataComponents.LORE, new ItemLore(lines));
      }

      return stack;
   }

   private static final class LockedSlot extends Slot {
      LockedSlot(SimpleContainer c, int i, int x, int y) {
         super(c, i, x, y);
      }

      public boolean mayPickup(Player p) {
         return false;
      }

      public boolean mayPlace(ItemStack s) {
         return false;
      }
   }
}
