package vexbot.gui;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.kit.KitManager;

public class KitDeleteConfirmMenu extends VexMenu {
   private static final int SLOT_LEFT = 11;
   private static final int SLOT_CENTER = 13;
   private static final int SLOT_RIGHT = 15;
   private final SimpleContainer container = new SimpleContainer(27);
   private final MinecraftServer server;
   private final String kitName;
   private boolean finalStep = false;

   public KitDeleteConfirmMenu(int containerId, Inventory playerInventory, MinecraftServer server, String kitName) {
      super(MenuType.GENERIC_9x3, containerId, playerInventory);
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.server = server;
      this.kitName = kitName;
      this.refresh();

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new KitListMenu.LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
      }

   }

   private void refresh() {
      ItemStack filler = KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), " ");

      for(int i = 0; i < 27; ++i) {
         this.container.setItem(i, filler.copy());
      }

      if (!this.finalStep) {
         this.container.setItem(13, KitListMenu.makeItem(Items.CHEST, "§e§l" + this.kitName, "§7Contains §f" + KitManager.countItems(this.server, this.kitName) + "§7 item(s)"));
         this.container.setItem(11, KitListMenu.makeItem(McCompat.pane(DyeColor.LIME), "§aCancel", "§7Keep this kit."));
         this.container.setItem(15, KitListMenu.makeItem(McCompat.pane(DyeColor.RED), "§cDelete", "§7Are you sure you want to", "§7delete kit §e" + this.kitName + "§7?"));
      } else {
         this.container.setItem(13, KitListMenu.makeItem(Items.BARRIER, "§c§l⚠ Cannot be undone!", "§4Deleting: §e" + this.kitName));
         this.container.setItem(15, KitListMenu.makeItem(McCompat.pane(DyeColor.LIME), "§aNo, go back", "§7Kit will not be deleted."));
         this.container.setItem(11, KitListMenu.makeItem(McCompat.pane(DyeColor.RED), "§c§lYes, delete forever!", "§4This cannot be undone!"));
      }

   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (!this.finalStep) {
         if (slotId == 15) {
            this.finalStep = true;
            this.refresh();
            this.sendAllDataToRemote();
         } else if (slotId == 11) {
            player.closeContainer();
         }
      } else if (slotId == 11) {
         KitManager.delete(this.server, this.kitName);
         player.closeContainer();
         if (player instanceof ServerPlayer) {
            ServerPlayer sp = (ServerPlayer)player;
            sp.sendSystemMessage(VexText.literal(sp, "§a[VexBot] Kit '§e" + this.kitName + "§a' has been deleted."));
         }
      } else if (slotId == 15) {
         player.closeContainer();
      }

      this.vanillaClick(slotId, button, player);
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int index) {
      return ItemStack.EMPTY;
   }
}
