package vexbot.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.ResolvableProfile;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.kit.KitManager;

public class PlayerSelectMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int PLAYER_SLOTS = 45;
   private static final int SLOT_PREV = 45;
   private static final int SLOT_BACK = 49;
   private static final int SLOT_NEXT = 53;
   private final SimpleContainer container;
   private final MinecraftServer server;
   private final String kitName;
   private final int returnPage;
   private final ServerPlayer opener;
   private final UUID[] slotToPlayer;
   private int page;
   private int totalPages;

   public PlayerSelectMenu(int containerId, Inventory playerInventory, MinecraftServer server, String kitName) {
      this(containerId, playerInventory, server, kitName, 0);
   }

   public PlayerSelectMenu(int containerId, Inventory playerInventory, MinecraftServer server, String kitName, int returnPage) {
      super(MenuType.GENERIC_9x6, containerId, playerInventory);
      this.container = new SimpleContainer(54);
      this.slotToPlayer = new UUID[54];
      this.page = 0;
      this.totalPages = 1;
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.server = server;
      this.kitName = kitName;
      this.returnPage = returnPage;
      this.opener = (ServerPlayer)playerInventory.player;
      this.refresh();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new KitListMenu.LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 103 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 161));
      }

   }

   private void refresh() {
      List<ServerPlayer> sorted = new ArrayList();
      sorted.add(this.opener);
      Stream var10000 = this.server.getPlayerList().getPlayers().stream().filter((px) -> !px.getUUID().equals(this.opener.getUUID())).sorted(Comparator.comparing((px) -> px.getName().getString()));
      Objects.requireNonNull(sorted);
      var10000.forEach(sorted::add);
      ItemStack filler = KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), " ");
      this.totalPages = Math.max(1, (sorted.size() + 45 - 1) / 45);
      if (this.page >= this.totalPages) {
         this.page = this.totalPages - 1;
      }

      int start = this.page * 45;

      for(int i = 0; i < 45; ++i) {
         int idx = start + i;
         if (idx < sorted.size()) {
            ServerPlayer p = (ServerPlayer)sorted.get(idx);
            this.slotToPlayer[i] = p.getUUID();
            this.container.setItem(i, this.makeHead(p));
         } else {
            this.slotToPlayer[i] = null;
            this.container.setItem(i, filler.copy());
         }
      }

      for(int i = 45; i < 54; ++i) {
         this.container.setItem(i, filler.copy());
      }

      this.container.setItem(49, KitListMenu.makeItem(Items.ARROW, "§f« Back to Kits", "§7Return to the kit list."));
      this.container.setItem(45, this.page > 0 ? KitListMenu.makeItem(Items.ARROW, "§f« Previous page") : filler.copy());
      this.container.setItem(53, this.page + 1 < this.totalPages ? KitListMenu.makeItem(Items.ARROW, "§fNext page »") : filler.copy());
   }

   private ItemStack makeHead(ServerPlayer player) {
      ItemStack head = new ItemStack(Items.PLAYER_HEAD);
      head.set(DataComponents.PROFILE, ResolvableProfile.createResolved(player.getGameProfile()));
      head.set(DataComponents.CUSTOM_NAME, VexText.literal("§a§l" + player.getName().getString()).setStyle(Style.EMPTY.withItalic(false)));
      head.set(DataComponents.LORE, new ItemLore(List.of(VexText.literal("§7Click to give §e" + this.kitName).setStyle(Style.EMPTY.withItalic(false)))));
      return head;
   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (player instanceof ServerPlayer sp) {
         if (slotId == 49) {
            sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, this.server, KitListMenu.Mode.GIVE, this.returnPage), VexText.literal("Give a Kit")));
         } else if (slotId == 45 && this.page > 0) {
            --this.page;
            this.refresh();
            this.sendAllDataToRemote();
         } else if (slotId == 53 && this.page + 1 < this.totalPages) {
            ++this.page;
            this.refresh();
            this.sendAllDataToRemote();
         } else if (slotId >= 0 && slotId < 45) {
            UUID targetId = this.slotToPlayer[slotId];
            if (targetId != null) {
               ServerPlayer target = this.server.getPlayerList().getPlayer(targetId);
               if (target != null && !target.isRemoved()) {
                  boolean ok = KitManager.give(this.server, target, this.kitName);
                  player.closeContainer();
                  MutableComponent var9;
                  if (ok) {
                     String var10001 = this.kitName;
                     var9 = VexText.literal("§a[VexBot] Gave kit §e" + var10001 + " §ato §f" + target.getName().getString() + "§a.");
                  } else {
                     var9 = VexText.literal("§c[VexBot] Kit §e" + this.kitName + " §cnot found.");
                  }

                  sp.sendSystemMessage(var9);
                  if (ok) {
                     target.sendSystemMessage(VexText.literal(target, "§6[VexBot] §fYou have been given kit §e" + this.kitName + "§f."));
                  }

                  this.vanillaClick(slotId, button, player);
               } else {
                  sp.sendSystemMessage(VexText.literal(sp, "§c[VexBot] That player is no longer online."));
                  this.refresh();
                  this.sendAllDataToRemote();
               }
            }
         }
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int index) {
      return ItemStack.EMPTY;
   }
}
