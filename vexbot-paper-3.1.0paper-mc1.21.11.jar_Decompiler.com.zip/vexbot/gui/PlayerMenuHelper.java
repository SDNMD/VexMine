package vexbot.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.fakeplayer.bot.BotPlayer;
import vexbot.team.TeamManager;

public final class PlayerMenuHelper {
   private PlayerMenuHelper() {
   }

   public static boolean isRealPlayer(ServerPlayer p) {
      return p != null && !(p instanceof BotPlayer);
   }

   public static List<HumanEntry> onlineHumans(MinecraftServer server, String teamName) {
      List<HumanEntry> out = new ArrayList();

      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (isRealPlayer(p) && !p.isSpectator()) {
            String name = p.getName().getString();
            TeamManager.BotTeam t = TeamManager.getTeamForMember(name);
            HumanRowState state;
            if (t == null) {
               state = PlayerMenuHelper.HumanRowState.AVAILABLE;
            } else if (t.getName().equalsIgnoreCase(teamName)) {
               state = PlayerMenuHelper.HumanRowState.ON_THIS_TEAM;
            } else {
               state = PlayerMenuHelper.HumanRowState.ON_OTHER_TEAM;
            }

            out.add(new HumanEntry(name, state));
         }
      }

      out.sort(Comparator.comparing(HumanEntry::name));
      return out;
   }

   public static String formatOnlineHumanSummary(MinecraftServer server, String teamName) {
      List<HumanEntry> humans = onlineHumans(server, teamName);
      if (humans.isEmpty()) {
         return "§7No other real players online on this server right now.";
      } else {
         StringBuilder sb = new StringBuilder("§7Online real players (§f" + humans.size() + "§7): ");

         for(int i = 0; i < humans.size(); ++i) {
            if (i > 0) {
               sb.append("§7, ");
            }

            HumanEntry e = (HumanEntry)humans.get(i);
            String var10000;
            switch (e.state().ordinal()) {
               case 0 -> var10000 = "§b";
               case 1 -> var10000 = "§a";
               case 2 -> var10000 = "§8";
               default -> throw new MatchException((String)null, (Throwable)null);
            }

            String color = var10000;
            sb.append(color).append(e.name());
         }

         return sb.toString();
      }
   }

   public static enum HumanRowState {
      AVAILABLE,
      ON_THIS_TEAM,
      ON_OTHER_TEAM;

      // $FF: synthetic method
      private static HumanRowState[] $values() {
         return new HumanRowState[]{AVAILABLE, ON_THIS_TEAM, ON_OTHER_TEAM};
      }
   }

   public static record HumanEntry(String name, HumanRowState state) {
   }
}
