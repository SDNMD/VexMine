package vexbot.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.function.Supplier;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import vexbot.SettingsPersistence;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.settings.GameplaySettingsScope;
import vexbot.settings.SettingsCli;
import vexbot.team.TeamManager;
import vexbot.team.TeamTactics;

public final class TeamSettingsMenu extends VexMenu {
   private static final int SIZE = 54;
   private static final int PER_PAGE = 45;
   private static final int SLOT_HEADER = 4;
   private static final int[] CATEGORY_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24};
   private static final int SLOT_CHANGED = 29;
   private static final int SLOT_HOME_SEARCH = 31;
   private static final int SLOT_ALL = 33;
   private static final int SLOT_SERVER_WIDE = 45;
   private static final int SLOT_CLOSE = 49;
   private static final int SLOT_BACK = 45;
   private static final int SLOT_PREV = 47;
   private static final int SLOT_INFO = 49;
   private static final int SLOT_NEXT = 51;
   private static final int SLOT_SEARCH = 53;
   private final SimpleContainer container = new SimpleContainer(54);
   private final MinecraftServer server;
   private final ServerPlayer viewer;
   private final String teamName;
   private Listing listing;
   private int page;
   private List<TeamSettingRows.Row> shown = List.of();
   private final Map<Integer, TeamSettingRows.Category> tiles = new HashMap();

   private TeamSettingsMenu(int id, Inventory inv, MinecraftServer server, ServerPlayer viewer, String teamName, Listing start) {
      super(MenuType.GENERIC_9x6, id, inv);
      BukkitCompat.setMenuPlayer(this, inv);
      this.server = server;
      this.viewer = viewer;
      this.teamName = teamName;
      this.listing = start;
      this.paint();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new KitListMenu.LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 103 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(inv, col, 8 + col * 18, 161));
      }

   }

   public static void open(ServerPlayer viewer, String teamName) {
      open(viewer, serverOf(viewer), teamName, (Listing)null);
   }

   public static void openBattleOrders(ServerPlayer viewer, String teamName) {
      open(viewer, serverOf(viewer), teamName, categoryListing(TeamSettingRows.Category.ORDERS, (Listing)null, 0));
   }

   public static void openSearch(ServerPlayer viewer, String teamName, String query) {
      open(viewer, serverOf(viewer), teamName, searchListing(query, (Listing)null, 0));
   }

   private static void open(ServerPlayer viewer, MinecraftServer server, String teamName, Listing start) {
      String canon = TeamManager.canonicalName(teamName);
      String name = canon != null ? canon : teamName;
      viewer.openMenu(new SimpleMenuProvider((id, inv, p) -> new TeamSettingsMenu(id, inv, server, viewer, name, start), VexText.literal("Team Settings: " + name)));
   }

   private static MinecraftServer serverOf(ServerPlayer p) {
      return p.level().getServer();
   }

   private static Listing categoryListing(TeamSettingRows.Category c, Listing back, int backPage) {
      return new Listing(c.title, (s, t) -> filter(TeamSettingRows.build(s, t), c), false, back, backPage);
   }

   private static Listing searchListing(String query, Listing back, int backPage) {
      String[] words = TeamSettingRows.norm(query.trim()).split("\\s+");
      return new Listing("Search: " + query.trim(), (s, t) -> {
         List<TeamSettingRows.Row> hits = new ArrayList();
         List<TeamSettingRows.Row> rest = new ArrayList();

         for(TeamSettingRows.Row r : TeamSettingRows.build(s, t)) {
            if (r.matches(words)) {
               (r.nameMatches(words) ? hits : rest).add(r);
            }
         }

         hits.addAll(rest);
         return hits;
      }, true, back, backPage);
   }

   private static List<TeamSettingRows.Row> filter(List<TeamSettingRows.Row> all, TeamSettingRows.Category c) {
      List<TeamSettingRows.Row> out = new ArrayList();

      for(TeamSettingRows.Row r : all) {
         if (r.category() == c) {
            out.add(r);
         }
      }

      return out;
   }

   MinecraftServer server() {
      return this.server;
   }

   ServerPlayer viewer() {
      return this.viewer;
   }

   String teamName() {
      return this.teamName;
   }

   void showPicker(String title, Supplier<List<TeamSettingRows.Row>> options) {
      this.listing = new Listing(title, (s, t) -> (List)options.get(), false, this.listing, this.page);
      this.page = 0;
   }

   void back() {
      if (this.listing != null) {
         this.page = this.listing.backPage();
         this.listing = this.listing.back();
      }
   }

   void openOther(MenuProvider provider) {
      this.viewer.openMenu(provider);
   }

   private TeamManager.BotTeam team() {
      return TeamManager.get(this.teamName);
   }

   private void paint() {
      for(int i = 0; i < 54; ++i) {
         this.container.setItem(i, filler());
      }

      this.shown = List.of();
      this.tiles.clear();
      TeamManager.BotTeam team = this.team();
      if (team == null) {
         this.container.setItem(22, item(Items.BARRIER, "§cTeam '" + this.teamName + "' no longer exists"));
      } else {
         if (this.listing == null) {
            this.paintHome(team);
         } else {
            this.paintList(team);
         }

      }
   }

   private void paintHome(TeamManager.BotTeam team) {
      List<TeamSettingRows.Row> all = TeamSettingRows.build(this.server, team);
      Map<TeamSettingRows.Category, int[]> counts = new EnumMap(TeamSettingRows.Category.class);
      int changed = 0;

      for(TeamSettingRows.Row r : all) {
         int[] c = (int[])counts.computeIfAbsent(r.category(), (k) -> new int[2]);
         int var10002 = c[0]++;
         if (r.changed()) {
            var10002 = c[1]++;
            ++changed;
         }
      }

      TeamTactics tc = team.tactics;
      SimpleContainer var10000 = this.container;
      Item var24 = Items.NAME_TAG;
      String var10003 = "§6Team §e" + team.getName();
      String[] var10004 = new String[5];
      int var10007 = team.getBotNames().size();
      var10004[0] = "§7Bots: §f" + var10007 + "§7 · Players: §f" + team.getPlayerNames().size();
      String var25 = tc.hasBoss() ? tc.boss : "none";
      var10004[1] = "§7Boss: §f" + var25 + "§7 · Formation: §f" + TeamSettingRows.pretty(tc.formation.name());
      var10004[2] = "§7Targets: §f" + TeamSettingRows.pretty(team.getMode().name());
      var25 = team.getAllies().isEmpty() ? "none" : String.join(", ", team.getAllies());
      var10004[3] = "§7Allies: §f" + var25;
      var10004[4] = "§d" + changed + "§7 setting(s) differ from the server's defaults";
      var10000.setItem(4, item(var24, var10003, var10004));
      int i = 0;

      for(TeamSettingRows.Category c : TeamSettingRows.Category.values()) {
         int[] n = (int[])counts.get(c);
         if (n != null && n[0] != 0) {
            if (i >= CATEGORY_SLOTS.length) {
               break;
            }

            int slot = CATEGORY_SLOTS[i++];
            this.tiles.put(slot, c);
            List<String> lore = new ArrayList(wrap(c.blurb));
            lore.add("§8" + n[0] + " setting(s)" + (n[1] > 0 ? " · §d" + n[1] + " changed" : ""));
            lore.add("§eClick to open");
            this.container.setItem(slot, item(c.icon, "§6" + c.title, (String[])lore.toArray((x$0) -> new String[x$0])));
         }
      }

      this.container.setItem(29, item(Items.WRITABLE_BOOK, "§dChanged For This Team", "§7Every setting this team has that differs", "§7from the server's own defaults.", "§8" + changed + " right now", "§eClick to open"));
      this.container.setItem(31, item(Items.COMPASS, "§aSearch Settings", "§7Type a word, like §fpearl§7, §fshield§7 or §fboss§7,", "§7and see every setting that matches.", "§eClick to search"));
      this.container.setItem(33, item(Items.BOOKSHELF, "§bAll Settings A–Z", "§7Every setting on one list, by name.", "§8" + all.size() + " in total", "§eClick to open"));
      GameplaySettingsScope global = GameplaySettingsScope.global();
      List<String> lore = new ArrayList(List.of("§7These apply to every bot on the server,", "§7whatever team it is on:"));

      for(String key : new TreeSet(TeamSettingRows.SERVER_WIDE)) {
         String v = SettingsCli.currentValue(global, key);
         if (v != null) {
            String var22 = VexBotSettingsMenu.displayName(key);
            lore.add("§8• §7" + var22 + ": §f" + v);
         }
      }

      lore.add("§eClick to open the server settings");
      this.container.setItem(45, item(Items.COMMAND_BLOCK, "§7Server-Wide Settings", (String[])lore.toArray((x$0) -> new String[x$0])));
      this.container.setItem(49, item(Items.BARRIER, "§cClose"));
      this.container.setItem(53, item(Items.COMPASS, "§aSearch", "§eClick to search"));
   }

   private void paintList(TeamManager.BotTeam team) {
      List<TeamSettingRows.Row> rows = this.listing.source().rows(this.server, team);
      int pages = Math.max(1, (rows.size() + 45 - 1) / 45);
      this.page = Math.max(0, Math.min(this.page, pages - 1));
      int from = this.page * 45;
      this.shown = rows.subList(from, Math.min(rows.size(), from + 45));

      for(int i = 0; i < this.shown.size(); ++i) {
         this.container.setItem(i, this.render((TeamSettingRows.Row)this.shown.get(i), this.listing.showCategory()));
      }

      if (rows.isEmpty()) {
         this.container.setItem(22, item(Items.BARRIER, "§7Nothing here", this.listing.title().startsWith("Search: ") ? "§7No setting matches that. Try one word." : "§7Nothing to show yet."));
      }

      this.container.setItem(45, item(Items.ARROW, "§eBack", this.listing.back() == null ? "§7To the categories" : "§7To " + this.listing.back().title()));
      if (this.page > 0) {
         this.container.setItem(47, item(Items.SPECTRAL_ARROW, "§ePrevious page", "§7Page " + this.page + " of " + pages));
      }

      if (this.page < pages - 1) {
         SimpleContainer var10000 = this.container;
         Item var10002 = Items.SPECTRAL_ARROW;
         String[] var10004 = new String[1];
         int var10007 = this.page + 2;
         var10004[0] = "§7Page " + var10007 + " of " + pages;
         var10000.setItem(51, item(var10002, "§eNext page", var10004));
      }

      this.container.setItem(49, item(Items.BOOK, "§6" + this.listing.title(), "§7Team §e" + this.teamName + "§7 · page §f" + (this.page + 1) + "§7 of §f" + pages + "§7 · §f" + rows.size() + "§7 row(s)", "§8Left-click: switch / next / up", "§8Right-click: previous / down", "§8Shift-click: a bigger step", "§8Changes apply and save at once."));
      this.container.setItem(53, item(Items.COMPASS, "§aSearch", "§eClick to search"));
   }

   private ItemStack render(TeamSettingRows.Row r, boolean showCategory) {
      String var10000;
      switch (r.kind()) {
         case TOGGLE -> var10000 = r.on() ? "§a" : "§c";
         case CHOICE -> var10000 = "§e";
         case NUMBER -> var10000 = "§b";
         case ACTION -> var10000 = "§6";
         case LINK -> var10000 = "§d";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      String colour = var10000;
      Item var7;
      if (r.icon() != null) {
         var7 = r.icon();
      } else {
         switch (r.kind()) {
            case TOGGLE -> var7 = McCompat.dye(r.on() ? DyeColor.LIME : DyeColor.GRAY);
            case CHOICE -> var7 = Items.COMPARATOR;
            case NUMBER -> var7 = Items.REPEATER;
            case ACTION -> var7 = Items.LEVER;
            case LINK -> var7 = Items.ARROW;
            default -> throw new MatchException((String)null, (Throwable)null);
         }
      }

      Item icon = var7;
      List<String> lore = new ArrayList(wrap(r.description()));
      if (r.value() != null) {
         lore.add("§7Currently: " + colour + r.value());
      }

      if (r.changed()) {
         lore.add("§d✎ Changed for this team");
      }

      if (showCategory && r.category() != TeamSettingRows.Category.OTHER) {
         lore.add("§8In " + r.category().title);
      }

      if (r.controls() != null && !r.controls().isEmpty()) {
         lore.add(r.controls());
      }

      ItemStack s = item(icon, colour + r.name(), (String[])lore.toArray((x$0) -> new String[x$0]));
      if (r.on() && r.kind() != TeamSettingRows.Kind.CHOICE && r.kind() != TeamSettingRows.Kind.NUMBER) {
         s.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
      }

      return s;
   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (slotId >= 0 && slotId < 54) {
         if (this.isPlainClick()) {
            TeamManager.BotTeam team = this.team();
            if (team == null) {
               this.tell("§c[VexBot] Team '§e" + this.teamName + "§c' no longer exists.");
               this.viewer.closeContainer();
            } else {
               boolean right = button == 1;
               if (this.listing == null) {
                  this.clickHome(slotId);
               } else {
                  this.clickList(slotId, right, quickMove);
               }

               if (this.viewer.containerMenu == this) {
                  this.paint();
                  this.sendAllDataToRemote();
               }

            }
         }
      } else {
         this.vanillaClick(slotId, button, player);
      }
   }

   private void clickHome(int slot) {
      TeamSettingRows.Category c = (TeamSettingRows.Category)this.tiles.get(slot);
      if (c != null) {
         this.listing = categoryListing(c, (Listing)null, 0);
         this.page = 0;
      } else {
         switch (slot) {
            case 29:
               this.listing = new Listing("Changed For This Team", (s, t) -> {
                  List<TeamSettingRows.Row> out = new ArrayList();

                  for(TeamSettingRows.Row r : TeamSettingRows.build(s, t)) {
                     if (r.changed()) {
                        out.add(r);
                     }
                  }

                  return out;
               }, true, (Listing)null, 0);
               this.page = 0;
               break;
            case 31:
            case 53:
               this.startSearch();
               break;
            case 33:
               this.listing = new Listing("All Settings A–Z", (s, t) -> {
                  List<TeamSettingRows.Row> out = new ArrayList(TeamSettingRows.build(s, t));
                  out.sort(Comparator.comparing((r) -> plain(r.name()).toLowerCase(Locale.ROOT)));
                  return out;
               }, true, (Listing)null, 0);
               this.page = 0;
               break;
            case 45:
               this.openOther(new SimpleMenuProvider((id, inv, p) -> new VexBotSettingsMenu(id, inv), VexText.literal("VexBot Settings")));
               break;
            case 49:
               this.viewer.closeContainer();
         }

      }
   }

   private void clickList(int slot, boolean right, boolean shift) {
      switch (slot) {
         case 45:
            this.back();
            return;
         case 46:
         case 48:
         case 49:
         case 50:
         case 52:
         default:
            if (slot < 45 && slot < this.shown.size()) {
               TeamSettingRows.Row r = (TeamSettingRows.Row)this.shown.get(slot);

               String msg;
               try {
                  msg = r.action().run(this, right, shift);
               } catch (RuntimeException e) {
                  msg = "§c" + e.getMessage();
               }

               SettingsPersistence.save(this.server);
               if (msg != null) {
                  this.tell(msg.startsWith("§c") ? "§c[VexBot] " + msg.substring(2) : "§7[VexBot] " + msg);
               }

               return;
            }

            return;
         case 47:
            this.page = Math.max(0, this.page - 1);
            return;
         case 51:
            ++this.page;
            return;
         case 53:
            this.startSearch();
      }
   }

   private void startSearch() {
      Listing here = this.listing;
      int herePage = this.page;
      SearchAnvilMenu.open(this.viewer, this.server, "Search team settings", (q) -> open(this.viewer, this.server, this.teamName, searchListing(q, here, herePage)), () -> open(this.viewer, this.server, this.teamName, here));
   }

   private void tell(String msg) {
      this.viewer.sendSystemMessage(VexText.literal(this.viewer, msg));
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int i) {
      return ItemStack.EMPTY;
   }

   private static ItemStack filler() {
      return item(McCompat.pane(DyeColor.GRAY), " ");
   }

   private static ItemStack item(Item icon, String name, String... lore) {
      ItemStack s = new ItemStack(icon);
      s.set(DataComponents.CUSTOM_NAME, VexText.literal(name).setStyle(Style.EMPTY.withItalic(false)));
      if (lore.length > 0) {
         List<Component> lines = new ArrayList(lore.length);

         for(String l : lore) {
            if (l != null) {
               lines.add(VexText.literal(l).setStyle(Style.EMPTY.withItalic(false)));
            }
         }

         s.set(DataComponents.LORE, new ItemLore(lines));
      }

      return s;
   }

   private static List<String> wrap(String text) {
      List<String> out = new ArrayList();
      if (text != null && !text.isBlank()) {
         StringBuilder line = new StringBuilder();
         int visible = 0;

         for(String word : text.trim().split("\\s+")) {
            int w = plain(word).length();
            if (visible > 0 && visible + 1 + w > 40) {
               out.add("§7" + String.valueOf(line));
               line.setLength(0);
               visible = 0;
            }

            if (visible > 0) {
               line.append(' ');
               ++visible;
            }

            line.append(word);
            visible += w;
         }

         if (line.length() > 0) {
            out.add("§7" + String.valueOf(line));
         }

         return out;
      } else {
         return out;
      }
   }

   private static String plain(String s) {
      return s.replaceAll("§.", "");
   }

   private static record Listing(String title, RowSource source, boolean showCategory, Listing back, int backPage) {
   }

   @FunctionalInterface
   private interface RowSource {
      List<TeamSettingRows.Row> rows(MinecraftServer var1, TeamManager.BotTeam var2);
   }
}
