package vexbot.gui;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import vexbot.compat.McCompat;
import vexbot.compat.VexAnvilMenu;
import vexbot.i18n.VexText;

public final class SearchAnvilMenu extends VexAnvilMenu {
   private final MinecraftServer server;
   private final Consumer<String> onSearch;
   private final Runnable onCancel;
   private String text = "";
   private boolean finished = false;

   private SearchAnvilMenu(int id, Inventory inv, MinecraftServer server, Consumer<String> onSearch, Runnable onCancel) {
      super(id, inv, ContainerLevelAccess.NULL);
      BukkitCompat.setMenuPlayer(this, inv);
      this.server = server;
      this.onSearch = onSearch;
      this.onCancel = onCancel;
      this.inputSlots.setItem(0, marker());
   }

   public static void open(ServerPlayer viewer, MinecraftServer server, String title, Consumer<String> onSearch, Runnable onCancel) {
      viewer.openMenu(new SimpleMenuProvider((id, inv, p) -> new SearchAnvilMenu(id, inv, server, onSearch, onCancel), VexText.literal(title)));
   }

   public boolean setItemName(String name) {
      this.text = name == null ? "" : name.trim();
      this.createResult();
      return true;
   }

   public void createResult() {
      if (this.text.isEmpty()) {
         this.resultSlots.setItem(0, ItemStack.EMPTY);
      } else {
         ItemStack s = new ItemStack(Items.COMPASS);
         s.set(DataComponents.CUSTOM_NAME, VexText.literal("§aSearch: §f" + this.text).setStyle(Style.EMPTY.withItalic(false)));
         s.set(DataComponents.LORE, new ItemLore(List.of(VexText.literal("§7Click to search, or press Esc.").setStyle(Style.EMPTY.withItalic(false)))));
         this.resultSlots.setItem(0, s);
      }

   }

   protected boolean interceptClick(int slotId, boolean plainClick, Player player) {
      if (slotId != 0 && slotId != 1) {
         if (slotId != 2) {
            return false;
         } else {
            if (plainClick && !this.resultSlots.getItem(0).isEmpty()) {
               this.finish(this.text);
            }

            return true;
         }
      } else {
         return true;
      }
   }

   protected boolean mayPickup(Player player, boolean hasStack) {
      return hasStack;
   }

   protected void onTake(Player player, ItemStack stack) {
      this.setCarried(ItemStack.EMPTY);
      this.finish(this.text);
   }

   public ItemStack quickMoveStack(Player player, int index) {
      return ItemStack.EMPTY;
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public void removed(Player player) {
      if (isMarker(this.getCarried())) {
         this.setCarried(ItemStack.EMPTY);
      }

      for(int i = 0; i < this.inputSlots.getContainerSize(); ++i) {
         ItemStack s = this.inputSlots.removeItemNoUpdate(i);
         if (!s.isEmpty() && !isMarker(s)) {
            if (player instanceof ServerPlayer) {
               ServerPlayer sp = (ServerPlayer)player;
               if (sp.hasDisconnected()) {
                  McCompat.drop(player, s, false);
                  continue;
               }
            }

            McCompat.placeBack(player.getInventory(), s);
         }
      }

      this.inputSlots.clearContent();
      this.resultSlots.clearContent();
      super.removed(player);
      Inventory inv = player.getInventory();

      for(int i = 0; i < inv.getContainerSize(); ++i) {
         if (isMarker(inv.getItem(i))) {
            inv.setItem(i, ItemStack.EMPTY);
         }
      }

      if (!this.finished) {
         this.finish(this.text);
      }

   }

   private void finish(String query) {
      if (!this.finished) {
         this.finished = true;
         this.server.execute(() -> {
            if (query.isEmpty()) {
               this.onCancel.run();
            } else {
               this.onSearch.accept(query);
            }

         });
      }
   }

   private static ItemStack marker() {
      ItemStack paper = new ItemStack(Items.PAPER);
      paper.set(DataComponents.CUSTOM_NAME, VexText.literal(""));
      return paper;
   }

   private static boolean isMarker(ItemStack s) {
      if (s != null && !s.isEmpty()) {
         Component name = (Component)s.get(DataComponents.CUSTOM_NAME);
         if (name == null) {
            return false;
         } else {
            return s.is(Items.PAPER) ? name.getString().isEmpty() : s.is(Items.COMPASS) && name.getString().startsWith("§aSearch: ");
         }
      } else {
         return false;
      }
   }
}
