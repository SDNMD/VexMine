package vexbot.gui;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import vexbot.compat.McCompat;
import vexbot.compat.VexMenu;
import vexbot.i18n.VexText;
import vexbot.kit.KitManager;

public class KitPreviewMenu extends VexMenu {
   private static final int ROWS = 6;
   private static final int SLOT_BACK = 49;
   private static final int GUI_LABEL = 36;
   private static final int GUI_HELMET = 37;
   private static final int GUI_CHEST = 38;
   private static final int GUI_LEGS = 39;
   private static final int GUI_BOOTS = 40;
   private static final int GUI_SEP = 41;
   private static final int GUI_OFFHAND = 42;
   private final SimpleContainer container = new SimpleContainer(54);
   private final MinecraftServer server;
   private final String kitName;
   private final int returnPage;

   public KitPreviewMenu(int containerId, Inventory playerInventory, MinecraftServer server, String kitName, int returnPage) {
      super(MenuType.GENERIC_9x6, containerId, playerInventory);
      BukkitCompat.setMenuPlayer(this, playerInventory);
      this.server = server;
      this.kitName = kitName;
      this.returnPage = returnPage;
      this.buildPreview();

      for(int row = 0; row < 6; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new KitListMenu.LockedSlot(this.container, col + row * 9, 8 + col * 18, 18 + row * 18));
         }
      }

      for(int row = 0; row < 3; ++row) {
         for(int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 103 + row * 18));
         }
      }

      for(int col = 0; col < 9; ++col) {
         this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 161));
      }

   }

   private void buildPreview() {
      ItemStack[] kit = KitManager.load(this.server, this.kitName);
      ItemStack fill = KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), " ");
      if (kit == null) {
         for(int i = 0; i < 54; ++i) {
            this.container.setItem(i, fill.copy());
         }

         this.container.setItem(49, makeBack());
      } else {
         for(int i = 0; i < 27; ++i) {
            this.container.setItem(i, kit[9 + i].copy());
         }

         for(int i = 0; i < 9; ++i) {
            this.container.setItem(27 + i, kit[i].copy());
         }

         this.container.setItem(36, KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§7Armor & Offhand"));
         this.container.setItem(37, kit[39].isEmpty() ? KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§8(no helmet)") : kit[39].copy());
         this.container.setItem(38, kit[38].isEmpty() ? KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§8(no chestplate)") : kit[38].copy());
         this.container.setItem(39, kit[37].isEmpty() ? KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§8(no leggings)") : kit[37].copy());
         this.container.setItem(40, kit[36].isEmpty() ? KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§8(no boots)") : kit[36].copy());
         this.container.setItem(41, fill.copy());
         this.container.setItem(42, kit[40].isEmpty() ? KitListMenu.makeItem(McCompat.pane(DyeColor.GRAY), "§8(no offhand)") : kit[40].copy());
         this.container.setItem(43, fill.copy());
         this.container.setItem(44, fill.copy());

         for(int i = 45; i < 54; ++i) {
            this.container.setItem(i, fill.copy());
         }

         this.container.setItem(49, makeBack());
      }
   }

   private static ItemStack makeBack() {
      return KitListMenu.makeItem(Items.ARROW, "§f« Back to Kits", "§7Return to the kit list.");
   }

   protected void vexClicked(int slotId, int button, boolean quickMove, Player player) {
      if (slotId == 49 && player instanceof ServerPlayer sp) {
         sp.openMenu(new SimpleMenuProvider((id, inv, p) -> new KitListMenu(id, inv, this.server, KitListMenu.Mode.GIVE, this.returnPage), VexText.literal("Give a Kit")));
      } else {
         this.vanillaClick(slotId, button, player);
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public ItemStack quickMoveStack(Player player, int index) {
      return ItemStack.EMPTY;
   }
}
