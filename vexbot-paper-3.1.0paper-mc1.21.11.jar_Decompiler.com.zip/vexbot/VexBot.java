package vexbot;

import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class VexBot {
   public static final String MOD_ID = "vexbot";
   public static final Logger LOGGER = LoggerFactory.getLogger("vexbot");
   public static final Identifier VERSION_CHANNEL = Identifier.parse("vexbot:version_check");
   public static MinecraftServer SERVER;

   private VexBot() {
   }
}
