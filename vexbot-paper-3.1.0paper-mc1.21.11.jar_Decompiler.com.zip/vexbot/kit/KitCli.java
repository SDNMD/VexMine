package vexbot.kit;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import vexbot.bot.BotManager;
import vexbot.gui.PlayerMenuHelper;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;
import vexbot.team.TeamTargetBalancer;

public final class KitCli {
   private KitCli() {
   }

   public static ServerPlayer resolveRecipient(MinecraftServer server, String name) {
      ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, name);
      return bot != null ? bot : BotManager.resolveNonBotPlayerByName(server, name);
   }

   public static int deleteKit(CommandSourceStack source, MinecraftServer server, String kitName) {
      if (!KitManager.exists(server, kitName)) {
         source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot deletekit list§r."));
         return 0;
      } else if (!KitManager.delete(server, kitName)) {
         source.sendFailure(VexText.literal("[VexBot] Could not delete kit '§e" + kitName + "§r'."));
         return 0;
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] Deleted kit §e" + kitName + "§r."), false);
         return 1;
      }
   }

   public static int listKits(CommandSourceStack source, MinecraftServer server) {
      List<String> kits = KitManager.list(server);
      if (kits.isEmpty()) {
         source.sendFailure(VexText.literal("[VexBot] No kits saved yet. Use §e/vexbot createkit <name>§r first."));
         return 0;
      } else {
         source.sendSuccess(() -> VexText.literal("[VexBot] Saved kits:"), false);

         for(String kit : kits) {
            int items = KitManager.countItems(server, kit);
            source.sendSuccess(() -> VexText.literal("  §e" + kit + " §8(" + items + " item(s))"), false);
         }

         source.sendSuccess(() -> VexText.literal("§8Use §e/vexbot givekit <kit> <player>§8 to give a kit."), false);
         return kits.size();
      }
   }

   public static int giveToPlayer(CommandSourceStack source, MinecraftServer server, String kitName, String targetName) {
      if (!KitManager.exists(server, kitName)) {
         source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot givekit list§r."));
         return 0;
      } else {
         ServerPlayer target = resolveRecipient(server, targetName);
         if (target == null) {
            source.sendFailure(VexText.literal("[VexBot] No online player or bot named '§e" + targetName + "§r'."));
            return 0;
         } else {
            KitManager.give(server, target, kitName);
            String who = target.getName().getString();
            source.sendSuccess(() -> VexText.literal("[VexBot] Gave kit §e" + kitName + "§r to §f" + who + "§r."), false);
            target.sendSystemMessage(VexText.literal(target, "§6[VexBot] §fYou have been given kit §e" + kitName + "§f."));
            return 1;
         }
      }
   }

   public static int giveToAll(CommandSourceStack source, MinecraftServer server, String kitName) {
      if (!KitManager.exists(server, kitName)) {
         source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot givekit list§r."));
         return 0;
      } else {
         int given = 0;
         int bots = 0;
         int humans = 0;
         Set<UUID> seen = new HashSet();

         for(ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isAlive() && !p.isSpectator() && seen.add(p.getUUID()) && KitManager.give(server, p, kitName)) {
               ++given;
               if (PlayerMenuHelper.isRealPlayer(p)) {
                  ++humans;
               } else {
                  ++bots;
               }
            }
         }

         if (given == 0) {
            source.sendFailure(VexText.literal("[VexBot] No one online to receive kit §e" + kitName + "§r."));
            return 0;
         } else {
            TeamTargetBalancer.rebalanceAll(server);
            source.sendSuccess(() -> VexText.literal("[VexBot] Gave kit §e" + kitName + "§r to §e" + given + "§r online (§f" + humans + " §7player(s), §f" + bots + " §7bot(s))."), false);
            return given;
         }
      }
   }

   public static int giveToTeam(CommandSourceStack source, MinecraftServer server, String teamName, String kitName) {
      if (!KitManager.exists(server, kitName)) {
         source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot givekit list§r."));
         return 0;
      } else {
         TeamManager.BotTeam team = TeamManager.get(teamName);
         if (team == null) {
            source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
            return 0;
         } else {
            int given = 0;
            int skipped = 0;

            for(String botName : team.getBotNames()) {
               ServerPlayer bot = BotManager.resolveTrackedBotPlayer(server, botName);
               if (bot != null && KitManager.give(server, bot, kitName)) {
                  ++given;
               }
            }

            for(String pname : team.getPlayerNames()) {
               ServerPlayer pl = BotManager.resolveNonBotPlayerByName(server, pname);
               if (pl != null) {
                  KitManager.give(server, pl, kitName);
                  ++given;
               } else {
                  ++skipped;
               }
            }

            if (given == 0) {
               source.sendFailure(VexText.literal("[VexBot] No online members in team §e" + teamName + "§r to receive kit §e" + kitName + "§r."));
               return 0;
            } else {
               TeamTargetBalancer.rebalance(server, teamName);
               source.sendSuccess(() -> VexText.literal("[VexBot] Gave kit §e" + kitName + "§r to §e" + given + "§r online member(s) of team §e" + teamName + "§r" + (skipped > 0 ? " §8(" + skipped + " offline/not found)" : "") + "."), false);
               return given;
            }
         }
      }
   }

   public static int getKitId(CommandSourceStack source, MinecraftServer server, String kitName) {
      if (!KitManager.exists(server, kitName)) {
         source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot givekit list§r."));
         return 0;
      } else {
         String id = KitShareCodec.encode(server, kitName);
         if (id == null) {
            source.sendFailure(VexText.literal("[VexBot] Could not encode kit '§e" + kitName + "§r'."));
            return 0;
         } else {
            sendKitIdMessage(source, kitName, id);
            return 1;
         }
      }
   }

   public static int updateKit(CommandSourceStack source, MinecraftServer server, String kitName) {
      Entity var4 = source.getEntity();
      if (var4 instanceof ServerPlayer player) {
         if (!KitManager.exists(server, kitName)) {
            source.sendFailure(VexText.literal("[VexBot] Kit '§e" + kitName + "§r' not found. Run §e/vexbot givekit list§r."));
            return 0;
         } else {
            KitManager.update(server, player, kitName);
            int items = KitManager.countItems(server, kitName);
            source.sendSuccess(() -> VexText.literal("[VexBot] Updated kit §e" + kitName + "§r from your inventory (§f" + items + "§r item(s))."), false);
            return 1;
         }
      } else {
         source.sendFailure(VexText.literal("[VexBot] Must be run as a player."));
         return 0;
      }
   }

   public static String importKitId(CommandSourceStack source, MinecraftServer server, String rawId) {
      KitShareCodec.SharedKit shared;
      try {
         shared = KitShareCodec.decode(server, rawId);
      } catch (IllegalArgumentException e) {
         source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
         return null;
      }

      String savedName = KitManager.importShared(server, shared);
      if (savedName == null) {
         source.sendFailure(VexText.literal("[VexBot] Could not save imported kit."));
      }

      return savedName;
   }

   public static int giveKitId(CommandSourceStack source, MinecraftServer server, String rawId) {
      KitShareCodec.SharedKit shared;
      try {
         shared = KitShareCodec.decode(server, rawId);
      } catch (IllegalArgumentException e) {
         source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
         return 0;
      }

      String savedName = KitManager.importShared(server, shared);
      if (savedName == null) {
         source.sendFailure(VexText.literal("[VexBot] Could not save imported kit."));
         return 0;
      } else {
         Entity var6 = source.getEntity();
         if (var6 instanceof ServerPlayer) {
            ServerPlayer player = (ServerPlayer)var6;
            KitManager.apply(player, shared.stacks());
            KitManager.applyEnder(player, shared.ender());
         }

         int items = KitManager.countItems(server, savedName);
         boolean renamed = !KitManager.sanitize(shared.preferredName()).equals(savedName) && !shared.preferredName().equals(savedName);
         boolean applied = source.getEntity() instanceof ServerPlayer;
         source.sendSuccess(() -> VexText.literal("[VexBot] Imported kit as §e" + savedName + "§r (§f" + items + "§r item(s)" + (renamed ? " — original name was taken" : "") + (applied ? " — applied to your inventory" : "") + "."), false);
         return 1;
      }
   }

   public static int giveAllKitId(CommandSourceStack source, MinecraftServer server, String rawId) {
      KitShareCodec.SharedKit shared;
      try {
         shared = KitShareCodec.decode(server, rawId);
      } catch (IllegalArgumentException e) {
         source.sendFailure(VexText.literal("[VexBot] " + e.getMessage()));
         return 0;
      }

      String savedName = KitManager.importShared(server, shared);
      if (savedName == null) {
         source.sendFailure(VexText.literal("[VexBot] Could not save imported kit."));
         return 0;
      } else {
         int items = KitManager.countItems(server, savedName);
         source.sendSuccess(() -> VexText.literal("[VexBot] Imported kit as §e" + savedName + "§r (§f" + items + "§r item(s)) — giving it to everyone…"), false);
         return giveToAll(source, server, savedName);
      }
   }

   public static int giveTeamKitId(CommandSourceStack source, MinecraftServer server, String teamName, String rawId) {
      TeamManager.BotTeam team = TeamManager.get(teamName);
      if (team == null) {
         source.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else {
         String resolvedTeam = team.getName();
         String savedName = importKitId(source, server, rawId);
         if (savedName == null) {
            return 0;
         } else {
            int items = KitManager.countItems(server, savedName);
            source.sendSuccess(() -> VexText.literal("[VexBot] Imported kit as §e" + savedName + "§r (§f" + items + "§r item(s)) — giving it to team §e" + resolvedTeam + "§r…"), false);
            return giveToTeam(source, server, resolvedTeam, savedName);
         }
      }
   }

   public static void sendKitIdMessage(CommandSourceStack source, String kitName, String kitId) {
      int items = KitManager.countItems(source.getServer(), kitName);
      source.sendSuccess(() -> VexText.literal("[VexBot] Kit ID for §e" + kitName + "§r (§f" + items + "§r items):"), false);
      Component copyButton = VexText.literal("§a§n[Click to copy kit ID]").withStyle(Style.EMPTY.withClickEvent(new ClickEvent.CopyToClipboard(kitId)).withHoverEvent(new HoverEvent.ShowText(VexText.literal("§7Copy the full kit ID to clipboard\n§8Works on any server with VexBot"))));
      source.sendSuccess(() -> copyButton, false);
      source.sendSuccess(() -> VexText.literal("§8Then run §e/vexbot givekitid §8and paste (Ctrl+V). Copy-paste works even for long IDs."), false);
   }
}
