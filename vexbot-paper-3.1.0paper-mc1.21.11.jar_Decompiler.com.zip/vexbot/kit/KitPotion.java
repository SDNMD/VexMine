package vexbot.kit;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Style;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import vexbot.i18n.VexText;

public final class KitPotion {
   private static final String TAG_KEY = "vexbot_kit";
   private static final int COLOR = 10170623;

   private KitPotion() {
   }

   public static ItemStack create(String kitName) {
      ItemStack stack = new ItemStack(Items.SPLASH_POTION);
      stack.set(DataComponents.POTION_CONTENTS, new PotionContents(Optional.empty(), Optional.of(10170623), List.of(), Optional.empty()));
      stack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
      stack.set(DataComponents.CUSTOM_NAME, VexText.literal("§5" + kitName + " Kit").setStyle(Style.EMPTY.withItalic(false)));
      stack.set(DataComponents.LORE, new ItemLore(List.of(VexText.literal("§7Right-click to instantly restock").setStyle(Style.EMPTY.withItalic(false)), VexText.literal("§7your inventory with the §e" + kitName + " §7kit.").setStyle(Style.EMPTY.withItalic(false)), VexText.literal("§8[VexBot Kit Potion]").setStyle(Style.EMPTY.withItalic(false)))));
      CompoundTag tag = new CompoundTag();
      tag.putString("vexbot_kit", kitName);
      stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
      return stack;
   }

   public static String getKitName(ItemStack stack) {
      if (!stack.isEmpty() && stack.is(Items.SPLASH_POTION)) {
         CustomData data = (CustomData)stack.get(DataComponents.CUSTOM_DATA);
         if (data == null) {
            return null;
         } else {
            String name = (String)data.copyTag().getString("vexbot_kit").orElse("");
            return name.isEmpty() ? null : name;
         }
      } else {
         return null;
      }
   }
}
