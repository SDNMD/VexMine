package vexbot.kit;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.equipment.trim.ArmorTrim;
import net.minecraft.world.item.equipment.trim.TrimMaterial;
import net.minecraft.world.item.equipment.trim.TrimPattern;
import vexbot.compat.McCompat;
import vexbot.i18n.VexText;

final class KitCompactCodec {
   static final int VERSION = 3;
   private static final int KIT_SIZE = 41;
   private static final Identifier[] ITEM_DICT = new Identifier[]{id("diamond_sword"), id("netherite_sword"), id("mace"), id("diamond_axe"), id("netherite_axe"), id("diamond_pickaxe"), id("netherite_pickaxe"), id("diamond_shovel"), id("netherite_shovel"), id("diamond_helmet"), id("diamond_chestplate"), id("diamond_leggings"), id("diamond_boots"), id("netherite_helmet"), id("netherite_chestplate"), id("netherite_leggings"), id("netherite_boots"), id("bow"), id("crossbow"), id("trident"), id("shield"), id("totem_of_undying"), id("golden_apple"), id("enchanted_golden_apple"), id("ender_pearl"), id("wind_charge"), id("experience_bottle"), id("splash_potion"), id("lingering_potion"), id("potion"), id("cobweb"), id("obsidian"), id("end_crystal"), id("white_shulker_box"), id("orange_shulker_box"), id("magenta_shulker_box"), id("light_blue_shulker_box"), id("yellow_shulker_box"), id("lime_shulker_box"), id("pink_shulker_box"), id("gray_shulker_box"), id("light_gray_shulker_box"), id("cyan_shulker_box"), id("purple_shulker_box"), id("blue_shulker_box"), id("brown_shulker_box"), id("green_shulker_box"), id("red_shulker_box"), id("black_shulker_box"), id("elytra"), id("firework_rocket"), id("arrow"), id("spectral_arrow"), id("tnt"), id("respawn_anchor"), id("glowstone"), id("crying_obsidian")};
   private static final int F_ENCH = 1;
   private static final int F_TRIM = 2;
   private static final int F_POTION = 4;
   private static final int F_CONTAINER = 8;
   private static final int F_DAMAGE = 16;
   private static final int F_NAME = 32;
   private static final int F_FALLBACK = 255;

   private static Identifier id(String path) {
      return Identifier.fromNamespaceAndPath("minecraft", path);
   }

   private KitCompactCodec() {
   }

   static byte[] encode(MinecraftServer server, String kitName, ItemStack[] stacks, ItemStack icon) throws IOException {
      ByteArrayOutputStream raw = new ByteArrayOutputStream(256);
      DataOutputStream out = new DataOutputStream(raw);
      out.writeByte(3);
      writeUtf(out, kitName);
      int count = 0;

      for(int i = 0; i < 41 && i < stacks.length; ++i) {
         if (!stacks[i].isEmpty()) {
            ++count;
         }
      }

      out.writeByte(count);

      for(int i = 0; i < 41 && i < stacks.length; ++i) {
         if (!stacks[i].isEmpty()) {
            writeItem(out, server, (byte)i, stacks[i]);
         }
      }

      if (!icon.isEmpty()) {
         out.writeBoolean(true);
         writeItem(out, server, (byte)-1, icon);
      } else {
         out.writeBoolean(false);
      }

      out.flush();
      return raw.toByteArray();
   }

   static KitShareCodec.SharedKit decode(MinecraftServer server, byte[] raw) throws IOException {
      DataInputStream in = new DataInputStream(new ByteArrayInputStream(raw));
      int version = in.readUnsignedByte();
      if (version != 3) {
         throw new IllegalArgumentException("Unsupported compact kit version: " + version);
      } else {
         String name = readUtf(in);
         int count = in.readUnsignedByte();
         ItemStack[] stacks = new ItemStack[41];

         for(int i = 0; i < 41; ++i) {
            stacks[i] = ItemStack.EMPTY;
         }

         for(int i = 0; i < count; ++i) {
            ItemEntry entry = readItem(in, server);
            if (entry.slot >= 0 && entry.slot < 41) {
               stacks[entry.slot] = entry.stack;
            }
         }

         ItemStack icon = ItemStack.EMPTY;
         if (in.readBoolean()) {
            icon = readItem(in, server).stack;
         }

         return new KitShareCodec.SharedKit(name, stacks, icon);
      }
   }

   private static void writeItem(DataOutputStream out, MinecraftServer server, byte slot, ItemStack stack) throws IOException {
      out.writeByte(slot);
      Registry<Item> items = server.registryAccess().lookupOrThrow(Registries.ITEM);
      int dictIdx = dictIndex(items, stack.getItem());
      if (dictIdx >= 0) {
         out.writeByte(0);
         out.writeByte(dictIdx);
      } else {
         out.writeByte(1);
         writeVarint(out, items.asHolderIdMap().getId(items.wrapAsHolder(stack.getItem())));
      }

      writeVarint(out, stack.getCount());
      if (needsFallback(stack)) {
         out.writeByte(255);
         writeFallbackNbt(out, server, stack);
      } else {
         int flags = 0;
         if (hasEnchants(stack)) {
            flags |= 1;
         }

         if (stack.get(DataComponents.TRIM) != null) {
            flags |= 2;
         }

         if (stack.get(DataComponents.POTION_CONTENTS) != null) {
            flags |= 4;
         }

         if (stack.get(DataComponents.CONTAINER) != null) {
            flags |= 8;
         }

         if (stack.getDamageValue() > 0) {
            flags |= 16;
         }

         if (stack.get(DataComponents.CUSTOM_NAME) != null) {
            flags |= 32;
         }

         out.writeByte(flags);
         if ((flags & 1) != 0) {
            writeEnchants(out, server, stack);
         }

         if ((flags & 2) != 0) {
            writeTrim(out, server, stack);
         }

         if ((flags & 4) != 0) {
            writePotion(out, server, stack);
         }

         if ((flags & 8) != 0) {
            writeContainer(out, server, stack);
         }

         if ((flags & 16) != 0) {
            writeVarint(out, stack.getDamageValue());
         }

         if ((flags & 32) != 0) {
            writeUtf(out, ((Component)stack.get(DataComponents.CUSTOM_NAME)).getString());
         }

      }
   }

   private static ItemEntry readItem(DataInputStream in, MinecraftServer server) throws IOException {
      int slot = in.readUnsignedByte();
      int refType = in.readUnsignedByte();
      Registry<Item> items = server.registryAccess().lookupOrThrow(Registries.ITEM);
      Item item;
      if (refType == 0) {
         int idx = in.readUnsignedByte();
         if (idx >= ITEM_DICT.length) {
            throw new IOException("Bad item dict index");
         }

         item = (Item)items.getValue(ITEM_DICT[idx]);
         if (item == null) {
            item = Items.AIR;
         }
      } else {
         int regId = readVarint(in);
         item = (Item)items.get(regId).map(Holder::value).orElse(Items.AIR);
      }

      int count = readVarint(in);
      ItemStack stack = new ItemStack(item, count);
      int flags = in.readUnsignedByte();
      if (flags == 255) {
         return new ItemEntry(slot, readFallbackNbt(in, server));
      } else {
         if ((flags & 1) != 0) {
            stack = applyEnchants(in, server, stack);
         }

         if ((flags & 2) != 0) {
            stack = applyTrim(in, server, stack);
         }

         if ((flags & 4) != 0) {
            stack = applyPotion(in, server, stack);
         }

         if ((flags & 8) != 0) {
            stack = applyContainer(in, server, stack);
         }

         if ((flags & 16) != 0) {
            stack.setDamageValue(readVarint(in));
         }

         if ((flags & 32) != 0) {
            stack.set(DataComponents.CUSTOM_NAME, VexText.literal(readUtf(in)));
         }

         return new ItemEntry(slot, stack);
      }
   }

   private static boolean needsFallback(ItemStack stack) {
      if (stack.get(DataComponents.BANNER_PATTERNS) != null) {
         return true;
      } else if (stack.get(DataComponents.WRITTEN_BOOK_CONTENT) != null) {
         return true;
      } else if (stack.get(DataComponents.FIREWORKS) != null) {
         return true;
      } else if (stack.get(DataComponents.CHARGED_PROJECTILES) != null) {
         return true;
      } else {
         return stack.get(DataComponents.BUNDLE_CONTENTS) != null;
      }
   }

   private static boolean hasEnchants(ItemStack stack) {
      ItemEnchantments e = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
      return e != null && !e.isEmpty();
   }

   private static void writeEnchants(DataOutputStream out, MinecraftServer server, ItemStack stack) throws IOException {
      Registry<Enchantment> reg = server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
      ItemEnchantments ench = (ItemEnchantments)stack.get(DataComponents.ENCHANTMENTS);
      List<Holder<Enchantment>> keys = new ArrayList(ench.keySet());
      out.writeByte(keys.size());

      for(Holder<Enchantment> h : keys) {
         writeVarint(out, reg.asHolderIdMap().getId(h));
         out.writeByte(Math.min(255, ench.getLevel(h)));
      }

   }

   private static ItemStack applyEnchants(DataInputStream in, MinecraftServer server, ItemStack stack) throws IOException {
      Registry<Enchantment> reg = server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
      int n = in.readUnsignedByte();
      ItemEnchantments.Mutable mut = new ItemEnchantments.Mutable((ItemEnchantments)stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY));

      for(int i = 0; i < n; ++i) {
         int eid = readVarint(in);
         int lvl = in.readUnsignedByte();
         reg.get(eid).ifPresent((h) -> mut.set(h, lvl));
      }

      stack.set(DataComponents.ENCHANTMENTS, mut.toImmutable());
      return stack;
   }

   private static void writeTrim(DataOutputStream out, MinecraftServer server, ItemStack stack) throws IOException {
      ArmorTrim trim = (ArmorTrim)stack.get(DataComponents.TRIM);
      Registry<TrimPattern> patterns = server.registryAccess().lookupOrThrow(Registries.TRIM_PATTERN);
      Registry<TrimMaterial> materials = server.registryAccess().lookupOrThrow(Registries.TRIM_MATERIAL);
      writeVarint(out, patterns.asHolderIdMap().getId(trim.pattern()));
      writeVarint(out, materials.asHolderIdMap().getId(trim.material()));
   }

   private static ItemStack applyTrim(DataInputStream in, MinecraftServer server, ItemStack stack) throws IOException {
      Registry<TrimPattern> patterns = server.registryAccess().lookupOrThrow(Registries.TRIM_PATTERN);
      Registry<TrimMaterial> materials = server.registryAccess().lookupOrThrow(Registries.TRIM_MATERIAL);
      int pid = readVarint(in);
      int mid = readVarint(in);
      Optional<Holder.Reference<TrimPattern>> p = patterns.get(pid);
      Optional<Holder.Reference<TrimMaterial>> m = materials.get(mid);
      if (p.isPresent() && m.isPresent()) {
         stack.set(DataComponents.TRIM, new ArmorTrim((Holder)m.get(), (Holder)p.get()));
      }

      return stack;
   }

   private static void writePotion(DataOutputStream out, MinecraftServer server, ItemStack stack) throws IOException {
      PotionContents pc = (PotionContents)stack.get(DataComponents.POTION_CONTENTS);
      Registry<Potion> potions = server.registryAccess().lookupOrThrow(Registries.POTION);
      int potionId = -1;
      Optional<Holder<Potion>> pot = pc.potion();
      if (pot.isPresent()) {
         potionId = potions.asHolderIdMap().getId((Holder)pot.get());
      }

      writeVarint(out, potionId);
      writeVarint(out, (Integer)pc.customColor().orElse(-1));
      out.writeByte(Math.min(255, pc.customEffects().size()));
      Registry<MobEffect> effects = server.registryAccess().lookupOrThrow(Registries.MOB_EFFECT);

      for(MobEffectInstance effect : pc.customEffects()) {
         writeVarint(out, effects.asHolderIdMap().getId(effect.getEffect()));
         writeVarint(out, effect.getAmplifier());
         writeVarint(out, effect.getDuration());
      }

   }

   private static ItemStack applyPotion(DataInputStream in, MinecraftServer server, ItemStack stack) throws IOException {
      Registry<Potion> potions = server.registryAccess().lookupOrThrow(Registries.POTION);
      Registry<MobEffect> effectReg = server.registryAccess().lookupOrThrow(Registries.MOB_EFFECT);
      int potionId = readVarint(in);
      int color = readVarint(in);
      int n = in.readUnsignedByte();
      List<MobEffectInstance> custom = new ArrayList();

      for(int i = 0; i < n; ++i) {
         int eid = readVarint(in);
         int amp = readVarint(in);
         int dur = readVarint(in);
         effectReg.get(eid).ifPresent((h) -> custom.add(new MobEffectInstance(h, dur, amp)));
      }

      Optional<Holder<Potion>> potHolder = potionId >= 0 ? potions.get(potionId).map((h) -> h) : Optional.empty();
      stack.set(DataComponents.POTION_CONTENTS, new PotionContents(potHolder, color >= 0 ? Optional.of(color) : Optional.empty(), custom, Optional.empty()));
      return stack;
   }

   private static void writeContainer(DataOutputStream out, MinecraftServer server, ItemStack stack) throws IOException {
      ItemContainerContents box = (ItemContainerContents)stack.get(DataComponents.CONTAINER);
      List<ItemStack> contents = new ArrayList();
      if (box != null) {
         for(ItemStack inner : McCompat.nonEmptyItems(box)) {
            contents.add(inner.copy());
         }
      }

      out.writeByte(Math.min(255, contents.size()));

      for(ItemStack inner : contents) {
         writeItem(out, server, (byte)0, inner);
      }

   }

   private static ItemStack applyContainer(DataInputStream in, MinecraftServer server, ItemStack stack) throws IOException {
      int n = in.readUnsignedByte();
      List<ItemStack> contents = new ArrayList();

      for(int i = 0; i < n; ++i) {
         contents.add(readItem(in, server).stack);
      }

      stack.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(contents));
      return stack;
   }

   private static void writeFallbackNbt(DataOutputStream out, MinecraftServer server, ItemStack stack) throws IOException {
      RegistryOps<Tag> ops = RegistryOps.create(NbtOps.INSTANCE, server.registryAccess());
      Tag tag = (Tag)ItemStack.CODEC.encodeStart(ops, stack).getOrThrow();
      ByteArrayOutputStream nbt = new ByteArrayOutputStream();
      NbtIo.writeUnnamedTag(tag, new DataOutputStream(nbt));
      writeVarint(out, nbt.size());
      out.write(nbt.toByteArray());
   }

   private static ItemStack readFallbackNbt(DataInputStream in, MinecraftServer server) throws IOException {
      int len = readVarint(in);
      byte[] data = in.readNBytes(len);
      Tag tag = NbtIo.readUnnamedTag(new DataInputStream(new ByteArrayInputStream(data)), NbtAccounter.create(2097152L));
      RegistryOps<Tag> ops = RegistryOps.create(NbtOps.INSTANCE, server.registryAccess());
      return (ItemStack)ItemStack.CODEC.parse(ops, tag).result().orElse(ItemStack.EMPTY);
   }

   private static int dictIndex(Registry<Item> items, Item item) {
      Identifier id = items.getKey(item);
      if (id == null) {
         return -1;
      } else {
         for(int i = 0; i < ITEM_DICT.length; ++i) {
            if (ITEM_DICT[i].equals(id)) {
               return i;
            }
         }

         return -1;
      }
   }

   private static void writeVarint(DataOutputStream out, int value) throws IOException {
      while((value & -128) != 0) {
         out.write(value & 127 | 128);
         value >>>= 7;
      }

      out.write(value);
   }

   private static int readVarint(DataInputStream in) throws IOException {
      int value = 0;
      int shift = 0;

      do {
         int b = in.readUnsignedByte();
         value |= (b & 127) << shift;
         if ((b & 128) == 0) {
            return value;
         }

         shift += 7;
      } while(shift <= 35);

      throw new IOException("Varint too long");
   }

   private static void writeUtf(DataOutputStream out, String s) throws IOException {
      byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
      writeVarint(out, bytes.length);
      out.write(bytes);
   }

   private static String readUtf(DataInputStream in) throws IOException {
      int len = readVarint(in);
      if (len == 0) {
         return "";
      } else if (len > 256) {
         throw new IOException("Name too long");
      } else {
         return new String(in.readNBytes(len), StandardCharsets.UTF_8);
      }
   }

   private static record ItemEntry(int slot, ItemStack stack) {
   }
}
