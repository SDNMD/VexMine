package vexbot.kit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.PlayerEnderChestContainer;
import net.minecraft.world.item.ItemStack;
import vexbot.VexBot;

public final class KitManager {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final int KIT_SIZE = 41;
   private static final int ENDER_SIZE = 27;
   private static final String ENDER_KEY = "ender";

   private KitManager() {
   }

   public static String sanitize(String name) {
      return name.replaceAll("[^a-zA-Z0-9_\\-]", "_");
   }

   private static Path kitDir(MinecraftServer server) {
      Path dir = server.getServerDirectory().resolve("vexbot_kits");

      try {
         Files.createDirectories(dir);
      } catch (IOException var3) {
      }

      return dir;
   }

   private static Path kitFile(MinecraftServer server, String name) {
      return kitDir(server).resolve(sanitize(name) + ".json");
   }

   private static Path iconFile(MinecraftServer server, String name) {
      return kitDir(server).resolve(sanitize(name) + ".icon.json");
   }

   public static void save(MinecraftServer server, ServerPlayer player, String name) {
      Inventory inv = player.getInventory();
      RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
      JsonObject root = new JsonObject();

      for(int i = 0; i < 41; ++i) {
         ItemStack stack = inv.getItem(i);
         if (!stack.isEmpty()) {
            JsonElement el = (JsonElement)ItemStack.CODEC.encodeStart(ops, stack).result().orElse((Object)null);
            if (el != null) {
               root.add(String.valueOf(i), el);
            }
         }
      }

      JsonObject ender = new JsonObject();
      PlayerEnderChestContainer ec = player.getEnderChestInventory();

      for(int i = 0; i < Math.min(27, ec.getContainerSize()); ++i) {
         ItemStack stack = ec.getItem(i);
         if (!stack.isEmpty()) {
            JsonElement el = (JsonElement)ItemStack.CODEC.encodeStart(ops, stack).result().orElse((Object)null);
            if (el != null) {
               ender.add(String.valueOf(i), el);
            }
         }
      }

      root.add("ender", ender);

      try {
         Files.writeString(kitFile(server, name), GSON.toJson(root));
      } catch (IOException e) {
         VexBot.LOGGER.error("[VexBot] Failed to save kit '{}'", name, e);
      }

   }

   public static ItemStack[] load(MinecraftServer server, String name) {
      Path file = kitFile(server, name);
      if (!Files.exists(file, new LinkOption[0])) {
         return null;
      } else {
         RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
         ItemStack[] stacks = new ItemStack[41];
         Arrays.fill(stacks, ItemStack.EMPTY);

         try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();

            for(Map.Entry<String, JsonElement> entry : root.entrySet()) {
               int slot;
               try {
                  slot = Integer.parseInt((String)entry.getKey());
               } catch (NumberFormatException var10) {
                  continue;
               }

               if (slot >= 0 && slot < 41) {
                  stacks[slot] = (ItemStack)ItemStack.CODEC.parse(ops, (JsonElement)entry.getValue()).result().orElse(ItemStack.EMPTY);
               }
            }

            return stacks;
         } catch (IllegalStateException | JsonParseException | IOException e) {
            VexBot.LOGGER.error("[VexBot] Failed to load kit '{}'", name, e);
            return null;
         }
      }
   }

   public static ItemStack[] loadEnder(MinecraftServer server, String name) {
      Path file = kitFile(server, name);
      if (!Files.exists(file, new LinkOption[0])) {
         return null;
      } else {
         RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);

         try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.has("ender") && root.get("ender").isJsonObject()) {
               ItemStack[] stacks = new ItemStack[27];
               Arrays.fill(stacks, ItemStack.EMPTY);

               for(Map.Entry<String, JsonElement> entry : root.getAsJsonObject("ender").entrySet()) {
                  int slot;
                  try {
                     slot = Integer.parseInt((String)entry.getKey());
                  } catch (NumberFormatException var10) {
                     continue;
                  }

                  if (slot >= 0 && slot < 27) {
                     stacks[slot] = (ItemStack)ItemStack.CODEC.parse(ops, (JsonElement)entry.getValue()).result().orElse(ItemStack.EMPTY);
                  }
               }

               return stacks;
            } else {
               return null;
            }
         } catch (IllegalStateException | JsonParseException | IOException e) {
            VexBot.LOGGER.error("[VexBot] Failed to load ender chest of kit '{}'", name, e);
            return null;
         }
      }
   }

   public static void applyEnder(ServerPlayer player, ItemStack[] stacks) {
      if (stacks != null) {
         PlayerEnderChestContainer ec = player.getEnderChestInventory();
         int n = Math.min(27, ec.getContainerSize());

         for(int i = 0; i < n; ++i) {
            ItemStack stack = i < stacks.length ? stacks[i] : ItemStack.EMPTY;
            ec.setItem(i, stack.isEmpty() ? ItemStack.EMPTY : stack.copy());
         }

      }
   }

   public static void apply(ServerPlayer player, ItemStack[] stacks) {
      Inventory inv = player.getInventory();
      inv.clearContent();

      for(int i = 0; i < 41; ++i) {
         ItemStack stack = i < stacks.length ? stacks[i] : ItemStack.EMPTY;
         inv.setItem(i, stack.isEmpty() ? ItemStack.EMPTY : stack.copy());
      }

   }

   public static boolean give(MinecraftServer server, ServerPlayer target, String name) {
      ItemStack[] stacks = load(server, name);
      if (stacks == null) {
         return false;
      } else {
         apply(target, stacks);
         applyEnder(target, loadEnder(server, name));
         return true;
      }
   }

   public static boolean update(MinecraftServer server, ServerPlayer player, String name) {
      if (!exists(server, name)) {
         return false;
      } else {
         save(server, player, name);
         return true;
      }
   }

   public static boolean delete(MinecraftServer server, String name) {
      try {
         deleteIcon(server, name);
         return Files.deleteIfExists(kitFile(server, name));
      } catch (IOException e) {
         VexBot.LOGGER.error("[VexBot] Failed to delete kit '{}'", name, e);
         return false;
      }
   }

   public static String rename(MinecraftServer server, String from, String to) {
      String src = sanitize(from);
      String dst = sanitize(to);
      if (dst.isEmpty()) {
         return "That name isn't usable.";
      } else if (!exists(server, src)) {
         return "No kit called '" + from + "'.";
      } else if (exists(server, dst)) {
         return "A kit called '" + to + "' already exists.";
      } else if (src.equalsIgnoreCase(dst)) {
         return "That's already its name.";
      } else {
         Path dir = kitDir(server);

         try {
            Files.move(dir.resolve(src + ".json"), dir.resolve(dst + ".json"));
         } catch (Exception e) {
            return "Couldn't rename the kit file: " + e.getMessage();
         }

         try {
            Path icon = dir.resolve(src + ".icon.json");
            if (Files.exists(icon, new LinkOption[0])) {
               Files.move(icon, dir.resolve(dst + ".icon.json"));
            }
         } catch (Exception var7) {
         }

         return null;
      }
   }

   public static void saveIcon(MinecraftServer server, String kitName, ItemStack icon) {
      RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
      JsonElement el = (JsonElement)ItemStack.CODEC.encodeStart(ops, icon).result().orElse((Object)null);
      if (el != null) {
         try {
            Files.writeString(iconFile(server, kitName), GSON.toJson(el));
         } catch (IOException e) {
            VexBot.LOGGER.error("[VexBot] Failed to save icon for kit '{}'", kitName, e);
         }

      }
   }

   public static ItemStack loadIcon(MinecraftServer server, String kitName) {
      Path file = iconFile(server, kitName);
      if (!Files.exists(file, new LinkOption[0])) {
         return ItemStack.EMPTY;
      } else {
         RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);

         try {
            JsonElement el = JsonParser.parseString(Files.readString(file));
            return (ItemStack)ItemStack.CODEC.parse(ops, el).result().orElse(ItemStack.EMPTY);
         } catch (IllegalStateException | JsonParseException | IOException var5) {
            return ItemStack.EMPTY;
         }
      }
   }

   public static void deleteIcon(MinecraftServer server, String kitName) {
      try {
         Files.deleteIfExists(iconFile(server, kitName));
      } catch (IOException var3) {
      }

   }

   public static List<String> list(MinecraftServer server) {
      Path dir = kitDir(server);

      try {
         Stream<Path> s = Files.list(dir);

         List var3;
         try {
            var3 = s.filter((p) -> p.toString().endsWith(".json") && !p.toString().endsWith(".icon.json")).map((p) -> {
               String f = p.getFileName().toString();
               return f.substring(0, f.length() - 5);
            }).sorted().toList();
         } catch (Throwable var6) {
            if (s != null) {
               try {
                  s.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (s != null) {
            s.close();
         }

         return var3;
      } catch (IOException var7) {
         return List.of();
      }
   }

   public static boolean exists(MinecraftServer server, String name) {
      return Files.exists(kitFile(server, name), new LinkOption[0]);
   }

   public static int countItems(MinecraftServer server, String name) {
      ItemStack[] stacks = load(server, name);
      if (stacks == null) {
         return 0;
      } else {
         int n = 0;

         for(ItemStack s : stacks) {
            if (!s.isEmpty()) {
               ++n;
            }
         }

         return n;
      }
   }

   public static JsonElement encodeStack(MinecraftServer server, ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
         return (JsonElement)ItemStack.CODEC.encodeStart(ops, stack).result().orElse((Object)null);
      } else {
         return null;
      }
   }

   public static String importShared(MinecraftServer server, KitShareCodec.SharedKit shared) {
      String savedName = uniqueKitName(server, shared.preferredName());
      RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
      JsonObject root = new JsonObject();
      ItemStack[] stacks = shared.stacks();

      for(int i = 0; i < stacks.length; ++i) {
         if (!stacks[i].isEmpty()) {
            JsonElement el = (JsonElement)ItemStack.CODEC.encodeStart(ops, stacks[i]).result().orElse((Object)null);
            if (el != null) {
               root.add(String.valueOf(i), el);
            }
         }
      }

      ItemStack[] sharedEnder = shared.ender();
      if (sharedEnder != null) {
         JsonObject ender = new JsonObject();

         for(int i = 0; i < sharedEnder.length && i < 27; ++i) {
            if (!sharedEnder[i].isEmpty()) {
               JsonElement el = (JsonElement)ItemStack.CODEC.encodeStart(ops, sharedEnder[i]).result().orElse((Object)null);
               if (el != null) {
                  ender.add(String.valueOf(i), el);
               }
            }
         }

         root.add("ender", ender);
      }

      try {
         Files.writeString(kitFile(server, savedName), GSON.toJson(root));
      } catch (IOException e) {
         VexBot.LOGGER.error("[VexBot] Failed to import shared kit '{}'", savedName, e);
         return null;
      }

      if (!shared.icon().isEmpty()) {
         saveIcon(server, savedName, shared.icon());
      }

      return savedName;
   }

   public static String uniqueKitName(MinecraftServer server, String preferred) {
      String base = sanitize(preferred != null && !preferred.isBlank() ? preferred.strip() : "imported_kit");
      if (base.isEmpty()) {
         base = "imported_kit";
      }

      if (!exists(server, base)) {
         return base;
      } else {
         for(int i = 2; i < 1000; ++i) {
            String candidate = base + "_" + i;
            if (!exists(server, candidate)) {
               return candidate;
            }
         }

         return base + "_" + System.currentTimeMillis();
      }
   }
}
