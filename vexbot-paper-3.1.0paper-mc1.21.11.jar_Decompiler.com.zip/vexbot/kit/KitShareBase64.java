package vexbot.kit;

import java.util.Base64;

final class KitShareBase64 {
   private KitShareBase64() {
   }

   static String encode(byte[] data) {
      return Base64.getUrlEncoder().withoutPadding().encodeToString(data);
   }

   static byte[] decode(String clean) {
      String stripped = clean.replaceAll("\\s+", "");

      try {
         return Base64.getUrlDecoder().decode(stripped);
      } catch (IllegalArgumentException var3) {
         throw new IllegalArgumentException("Could not read kit ID — bad base64 (truncated in chat?).");
      }
   }

   static byte[] decodeLegacy(String clean) {
      return Base64.getDecoder().decode(clean.replaceAll("\\s+", ""));
   }
}
