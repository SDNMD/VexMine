package vexbot.kit;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;

public final class KitShareCodec {
   public static final String PREFIX_V3 = "VBK3:";
   public static final String PREFIX_V2 = "VBK2:";
   public static final String PREFIX_V1 = "VBK1:";
   private static final int KIT_SIZE = 41;
   private static final int FORMAT_LIST = 4;
   private static final int BINARY_VERSION_V2 = 2;
   private static final long NBT_LIMIT = 16777216L;
   private static final int ENDER_SIZE = 27;

   private KitShareCodec() {
   }

   public static String encode(MinecraftServer server, String kitName) {
      ItemStack[] stacks = KitManager.load(server, kitName);
      if (stacks == null) {
         return null;
      } else {
         ItemStack icon = KitManager.loadIcon(server, kitName);
         ItemStack[] ender = KitManager.loadEnder(server, kitName);

         try {
            byte[] raw = encodeNbt(server, kitName, stacks, icon, ender);
            return "VBK3:" + KitShareBase64.encode(compress(raw));
         } catch (Exception var6) {
            return null;
         }
      }
   }

   private static byte[] encodeNbt(MinecraftServer server, String name, ItemStack[] stacks, ItemStack icon, ItemStack[] ender) throws IOException {
      RegistryOps<Tag> ops = server.registryAccess().createSerializationContext(NbtOps.INSTANCE);
      CompoundTag root = new CompoundTag();
      root.putString("name", name);
      root.putInt("format", 4);
      ListTag items = new ListTag();

      for(int i = 0; i < stacks.length && i < 41; ++i) {
         if (!stacks[i].isEmpty()) {
            CompoundTag entry = new CompoundTag();
            entry.putInt("slot", i);
            entry.put("item", (Tag)ItemStack.CODEC.encodeStart(ops, stacks[i]).getOrThrow());
            items.add(entry);
         }
      }

      root.put("items", items);
      if (!icon.isEmpty()) {
         root.put("icon", (Tag)ItemStack.CODEC.encodeStart(ops, icon).getOrThrow());
      }

      if (ender != null) {
         ListTag enderItems = new ListTag();

         for(int i = 0; i < ender.length && i < 27; ++i) {
            if (!ender[i].isEmpty()) {
               CompoundTag entry = new CompoundTag();
               entry.putInt("slot", i);
               entry.put("item", (Tag)ItemStack.CODEC.encodeStart(ops, ender[i]).getOrThrow());
               enderItems.add(entry);
            }
         }

         root.put("ender", enderItems);
      }

      ByteArrayOutputStream out = new ByteArrayOutputStream(512);
      NbtIo.writeUnnamedTag(root, new DataOutputStream(out));
      return out.toByteArray();
   }

   public static SharedKit decode(MinecraftServer server, String rawId) {
      if (rawId != null && !rawId.isBlank()) {
         String trimmed = rawId.strip();
         if (trimmed.regionMatches(true, 0, "VBK3:", 0, "VBK3:".length())) {
            return decodeV3(server, trimmed.substring("VBK3:".length()));
         } else if (trimmed.regionMatches(true, 0, "VBK2:", 0, "VBK2:".length())) {
            return decodeV2(server, trimmed.substring("VBK2:".length()));
         } else if (trimmed.regionMatches(true, 0, "VBK1:", 0, "VBK1:".length())) {
            return decodeLegacyV1(server, trimmed.substring("VBK1:".length()));
         } else {
            throw new IllegalArgumentException("Not a VexBot kit ID (expected VBK3:, VBK2:, or VBK1:).");
         }
      } else {
         throw new IllegalArgumentException("Kit ID is empty.");
      }
   }

   private static SharedKit decodeV3(MinecraftServer server, String payload) {
      byte[] raw;
      try {
         raw = decompress(KitShareBase64.decode(payload));
      } catch (IllegalArgumentException e) {
         throw e;
      } catch (Exception var9) {
         throw new IllegalArgumentException("Could not read kit ID — it may be incomplete or corrupted.");
      }

      if (raw.length > 0 && (raw[0] & 255) == 10) {
         try {
            return decodeNbt(server, raw);
         } catch (IllegalArgumentException e) {
            throw e;
         } catch (Exception var5) {
            throw new IllegalArgumentException("Could not read kit ID — it may be corrupted.");
         }
      } else {
         try {
            return KitCompactCodec.decode(server, raw);
         } catch (IllegalArgumentException e) {
            throw e;
         } catch (Exception var7) {
            throw new IllegalArgumentException("Could not read kit ID — it may be incomplete or corrupted.");
         }
      }
   }

   private static SharedKit decodeNbt(MinecraftServer server, byte[] raw) throws IOException {
      RegistryOps<Tag> ops = server.registryAccess().createSerializationContext(NbtOps.INSTANCE);
      Tag tag = NbtIo.readUnnamedTag(new DataInputStream(new ByteArrayInputStream(raw)), NbtAccounter.create(16777216L));
      if (!(tag instanceof CompoundTag root)) {
         throw new IllegalArgumentException("Kit ID data is not a valid kit.");
      } else {
         String name = root.getStringOr("name", "imported_kit");
         ItemStack[] ender = null;
         if (root.contains("ender")) {
            ender = new ItemStack[27];

            for(int i = 0; i < 27; ++i) {
               ender[i] = ItemStack.EMPTY;
            }

            for(Tag element : (ListTag)root.getList("ender").orElse(new ListTag())) {
               if (element instanceof CompoundTag) {
                  CompoundTag entry = (CompoundTag)element;
                  int slot = entry.getIntOr("slot", -1);
                  if (slot >= 0 && slot < 27) {
                     Tag itemTag = entry.get("item");
                     if (itemTag != null) {
                        ender[slot] = (ItemStack)ItemStack.CODEC.parse(ops, itemTag).result().orElse(ItemStack.EMPTY);
                     }
                  }
               }
            }
         }

         ItemStack[] stacks = new ItemStack[41];

         for(int i = 0; i < 41; ++i) {
            stacks[i] = ItemStack.EMPTY;
         }

         if (root.contains("items")) {
            for(Tag element : (ListTag)root.getList("items").orElse(new ListTag())) {
               if (element instanceof CompoundTag) {
                  CompoundTag entry = (CompoundTag)element;
                  int slot = entry.getIntOr("slot", -1);
                  if (slot >= 0 && slot < 41) {
                     Tag itemTag = entry.get("item");
                     if (itemTag != null) {
                        stacks[slot] = (ItemStack)ItemStack.CODEC.parse(ops, itemTag).result().orElse(ItemStack.EMPTY);
                     }
                  }
               }
            }
         } else {
            if (!root.contains("slots")) {
               throw new IllegalArgumentException("Kit ID is missing inventory data.");
            }

            CompoundTag slots = root.getCompoundOrEmpty("slots");

            for(String key : slots.keySet()) {
               int slot;
               try {
                  slot = Integer.parseInt(key);
               } catch (NumberFormatException var14) {
                  continue;
               }

               if (slot >= 0 && slot < 41) {
                  Tag itemTag = slots.get(key);
                  if (itemTag != null) {
                     stacks[slot] = (ItemStack)ItemStack.CODEC.parse(ops, itemTag).result().orElse(ItemStack.EMPTY);
                  }
               }
            }
         }

         ItemStack icon = ItemStack.EMPTY;
         if (root.contains("icon")) {
            Tag iconTag = root.get("icon");
            if (iconTag != null) {
               icon = (ItemStack)ItemStack.CODEC.parse(ops, iconTag).result().orElse(ItemStack.EMPTY);
            }
         }

         return new SharedKit(name, stacks, icon, ender);
      }
   }

   private static SharedKit decodeV2(MinecraftServer server, String payload) {
      try {
         return parseBinaryPayloadV2(server, decompress(KitShareBase64.decode(payload)));
      } catch (IllegalArgumentException e) {
         throw e;
      } catch (Exception var4) {
         throw new IllegalArgumentException("Could not read kit ID — it may be incomplete or corrupted.");
      }
   }

   private static SharedKit decodeLegacyV1(MinecraftServer server, String payload) {
      String clean = payload.replaceAll("\\s+", "");

      try {
         JsonObject root = JsonParser.parseString(new String(decompress(KitShareBase64.decodeLegacy(clean)), StandardCharsets.UTF_8)).getAsJsonObject();
         if (root.has("slots") && root.get("slots").isJsonObject()) {
            String name = root.has("name") ? root.get("name").getAsString() : "imported_kit";
            JsonElement iconEl = root.has("icon") ? root.get("icon") : null;
            ItemStack[] stacks = jsonSlotsToStacks(server, root.getAsJsonObject("slots"));
            ItemStack icon = jsonToStack(server, iconEl);
            return new SharedKit(name, stacks, icon);
         } else {
            throw new IllegalArgumentException("Kit ID is missing inventory data.");
         }
      } catch (IllegalArgumentException e) {
         throw e;
      } catch (Exception var9) {
         throw new IllegalArgumentException("Could not read legacy kit ID.");
      }
   }

   private static SharedKit parseBinaryPayloadV2(MinecraftServer server, byte[] raw) throws IOException {
      DataInputStream in = new DataInputStream(new ByteArrayInputStream(raw));
      int version = in.readUnsignedByte();
      if (version != 2) {
         throw new IllegalArgumentException("Unsupported kit binary version: " + version);
      } else {
         String name = readUtf(in);
         int count = in.readUnsignedByte();
         ItemStack[] stacks = new ItemStack[41];

         for(int i = 0; i < 41; ++i) {
            stacks[i] = ItemStack.EMPTY;
         }

         for(int i = 0; i < count; ++i) {
            int slot = in.readUnsignedByte();
            int len = in.readInt();
            byte[] nbt = in.readNBytes(len);
            if (slot < 41) {
               stacks[slot] = nbtToStack(server, nbt);
            }
         }

         ItemStack icon = ItemStack.EMPTY;
         if (in.readBoolean()) {
            int len = in.readInt();
            icon = nbtToStack(server, in.readNBytes(len));
         }

         return new SharedKit(name, stacks, icon);
      }
   }

   private static ItemStack nbtToStack(MinecraftServer server, byte[] data) throws IOException {
      if (data.length == 0) {
         return ItemStack.EMPTY;
      } else {
         Tag tag = NbtIo.readUnnamedTag(new DataInputStream(new ByteArrayInputStream(data)), NbtAccounter.create(2097152L));
         RegistryOps<Tag> ops = server.registryAccess().createSerializationContext(NbtOps.INSTANCE);
         return (ItemStack)ItemStack.CODEC.parse(ops, tag).result().orElse(ItemStack.EMPTY);
      }
   }

   private static ItemStack[] jsonSlotsToStacks(MinecraftServer server, JsonObject slots) {
      ItemStack[] stacks = new ItemStack[41];

      for(int i = 0; i < 41; ++i) {
         stacks[i] = ItemStack.EMPTY;
      }

      RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);

      for(Map.Entry<String, JsonElement> entry : slots.entrySet()) {
         int slot;
         try {
            slot = Integer.parseInt((String)entry.getKey());
         } catch (NumberFormatException var8) {
            continue;
         }

         if (slot >= 0 && slot < 41) {
            stacks[slot] = (ItemStack)ItemStack.CODEC.parse(ops, (JsonElement)entry.getValue()).result().orElse(ItemStack.EMPTY);
         }
      }

      return stacks;
   }

   private static ItemStack jsonToStack(MinecraftServer server, JsonElement el) {
      if (el == null) {
         return ItemStack.EMPTY;
      } else {
         RegistryOps<JsonElement> ops = server.registryAccess().createSerializationContext(JsonOps.INSTANCE);
         return (ItemStack)ItemStack.CODEC.parse(ops, el).result().orElse(ItemStack.EMPTY);
      }
   }

   private static byte[] compress(byte[] input) throws IOException {
      ByteArrayOutputStream out = new ByteArrayOutputStream(input.length / 2);
      Deflater deflater = new Deflater(9);

      try {
         DeflaterOutputStream def = new DeflaterOutputStream(out, deflater);

         try {
            def.write(input);
         } catch (Throwable var11) {
            try {
               def.close();
            } catch (Throwable var10) {
               var11.addSuppressed(var10);
            }

            throw var11;
         }

         def.close();
      } finally {
         deflater.end();
      }

      return out.toByteArray();
   }

   private static byte[] decompress(byte[] input) throws IOException {
      InflaterInputStream inf = new InflaterInputStream(new ByteArrayInputStream(input));
      return inf.readAllBytes();
   }

   private static String readUtf(DataInputStream in) throws IOException {
      int len = in.readUnsignedShort();
      return len == 0 ? "" : new String(in.readNBytes(len), StandardCharsets.UTF_8);
   }

   public static record SharedKit(String preferredName, ItemStack[] stacks, ItemStack icon, ItemStack[] ender) {
      public SharedKit(String preferredName, ItemStack[] stacks, ItemStack icon) {
         this(preferredName, stacks, icon, (ItemStack[])null);
      }
   }
}
