package vexbot.nick;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import vexbot.bot.BotManager;
import vexbot.i18n.VexText;

public final class NickCli {
   private NickCli() {
   }

   public static int nick(CommandSourceStack src, String targetName, String newName, String skinName) {
      ServerPlayer target = findPlayer(src.getServer(), targetName);
      if (target == null) {
         src.sendFailure(VexText.literal("§cNo online player or bot named '" + targetName + "'"));
         return 0;
      } else if (!newName.matches("[A-Za-z0-9_]{1,16}")) {
         src.sendFailure(VexText.literal("§cNick must be 1-16 letters/digits/underscores"));
         return 0;
      } else {
         ServerPlayer clash = findPlayer(src.getServer(), newName);
         if ((clash == null || clash == target) && (!BotManager.isTrackedBotName(newName) || newName.equalsIgnoreCase(NickManager.realName(target)))) {
            if (skinName == null) {
               NickManager.apply(target, newName, (String[])null);
               src.sendSuccess(() -> VexText.literal("§a" + targetName + " is now nicked as §f" + newName), true);
               return 1;
            } else {
               src.sendSuccess(() -> VexText.literal("§7Applying skin '" + skinName + "'… (first use uploads to MineSkin)"), false);
               MinecraftServer server = src.getServer();
               SkinStorage.getTexture(server, skinName).whenComplete((tex, err) -> server.execute(() -> {
                     ServerPlayer t = findPlayer(server, targetName);
                     if (t != null) {
                        if (err != null) {
                           String msg = err.getCause() != null ? err.getCause().getMessage() : err.getMessage();
                           src.sendFailure(VexText.literal("§c" + msg + " §7— nicking name only"));
                           NickManager.apply(t, newName, (String[])null);
                        } else {
                           NickManager.apply(t, newName, tex);
                           src.sendSuccess(() -> VexText.literal("§a" + targetName + " is now nicked as §f" + newName + "§a with skin §f" + skinName), true);
                        }
                     }
                  }));
               return 1;
            }
         } else {
            src.sendFailure(VexText.literal("§c'" + newName + "' is already another player's or bot's name"));
            return 0;
         }
      }
   }

   public static int stop(CommandSourceStack src, String targetName) {
      ServerPlayer target = findPlayer(src.getServer(), targetName);
      if (target == null) {
         src.sendFailure(VexText.literal("§cNo online player or bot named '" + targetName + "'"));
         return 0;
      } else if (!NickManager.stop(target)) {
         src.sendFailure(VexText.literal("§c" + targetName + " isn't nicked"));
         return 0;
      } else {
         src.sendSuccess(() -> VexText.literal("§a" + targetName + " is back to their real identity"), true);
         return 1;
      }
   }

   private static ServerPlayer findPlayer(MinecraftServer server, String name) {
      for(ServerPlayer p : server.getPlayerList().getPlayers()) {
         if (p.getGameProfile().name().equalsIgnoreCase(name) || p.getScoreboardName().equalsIgnoreCase(name)) {
            return p;
         }

         String was = NickManager.originalName(p.getUUID());
         if (was != null && was.equalsIgnoreCase(name)) {
            return p;
         }
      }

      return null;
   }
}
