package vexbot.nick;

import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import vexbot.SettingsPersistence;
import vexbot.i18n.VexText;
import vexbot.team.TeamManager;

public final class TeamSkinCli {
   private TeamSkinCli() {
   }

   public static int set(CommandSourceStack src, String teamName, String skinName) {
      MinecraftServer server = src.getServer();
      TeamManager.BotTeam team = resolve(teamName);
      if (team == null) {
         src.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else if (!SkinStorage.list(server, "vexbot_teamskins").contains(skinName)) {
         src.sendFailure(VexText.literal("[VexBot] No skin '§e" + skinName + ".png§r' in §evexbot_teamskins/§r. Drop the PNG in there first."));
         return 0;
      } else {
         team.teamSkin = skinName;
         SettingsPersistence.save(server);
         TeamSkinManager.warm(server, skinName);
         int bots = team.getBotNames().size();
         String note = TeamSkinManager.isReady(skinName) ? "" : " §7(first use uploads to MineSkin — give it a moment)§r";
         src.sendSuccess(() -> {
            String var10000 = team.getName();
            return VexText.literal("[VexBot] Team §e" + var10000 + "§r is now wearing §e" + skinName + "§r — §e" + bots + "§r bot" + (bots == 1 ? "" : "s") + note + ".");
         }, true);
         return 1;
      }
   }

   public static int clear(CommandSourceStack src, String teamName) {
      MinecraftServer server = src.getServer();
      TeamManager.BotTeam team = resolve(teamName);
      if (team == null) {
         src.sendFailure(VexText.literal("[VexBot] No team named '§e" + teamName + "§r'."));
         return 0;
      } else if (team.teamSkin != null && !team.teamSkin.isBlank()) {
         team.teamSkin = "";
         SettingsPersistence.save(server);
         TeamSkinManager.revert(server, team);
         src.sendSuccess(() -> VexText.literal("[VexBot] Team §e" + team.getName() + "§r is out of uniform."), true);
         return 1;
      } else {
         src.sendFailure(VexText.literal("[VexBot] Team §e" + team.getName() + "§r has no team skin."));
         return 0;
      }
   }

   public static int list(CommandSourceStack src) {
      MinecraftServer server = src.getServer();
      List<String> skins = SkinStorage.list(server, "vexbot_teamskins");
      if (skins.isEmpty()) {
         src.sendSuccess(() -> VexText.literal("[VexBot] No team skins yet. Drop a Minecraft skin PNG into §evexbot_teamskins/§r (next to your world's §evexbot_kits§r folder) and it will show up here."), false);
      } else {
         src.sendSuccess(() -> VexText.literal("[VexBot] Team skins in §evexbot_teamskins/§r: §f" + String.join("§7, §f", skins)), false);
      }

      StringBuilder worn = new StringBuilder();

      for(TeamManager.BotTeam t : TeamManager.allTeams()) {
         if (t.teamSkin != null && !t.teamSkin.isBlank()) {
            if (worn.length() > 0) {
               worn.append("§7, ");
            }

            int on = TeamSkinManager.online(server, t);
            int in = TeamSkinManager.wearing(server, t);
            worn.append("§e").append(t.getName()).append("§7=§f").append(t.teamSkin).append(in == on ? "§7 (" : "§c (").append(in).append('/').append(on).append(" wearing)§r");
         }
      }

      if (worn.length() > 0) {
         src.sendSuccess(() -> VexText.literal("[VexBot] In uniform: " + String.valueOf(worn)), false);
      }

      return 1;
   }

   private static TeamManager.BotTeam resolve(String name) {
      if (name == null) {
         return null;
      } else {
         TeamManager.BotTeam t = TeamManager.get(name);
         if (t != null) {
            return t;
         } else {
            for(String tn : TeamManager.teamNames()) {
               if (tn.equalsIgnoreCase(name)) {
                  return TeamManager.get(tn);
               }
            }

            return null;
         }
      }
   }
}
