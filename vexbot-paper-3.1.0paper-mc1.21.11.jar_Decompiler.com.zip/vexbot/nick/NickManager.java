package vexbot.nick;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.PlayerList;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.platform.Internals;

public final class NickManager {
   private static final Map<UUID, Nick> ORIGINALS = new ConcurrentHashMap();
   private static final Map<String, UUID> BY_NICK = new ConcurrentHashMap();
   private static final AtomicInteger VERSION = new AtomicInteger();

   private NickManager() {
   }

   public static int version() {
      return VERSION.get();
   }

   private static boolean current(ServerPlayer p, Nick n) {
      return n != null && n.nickName().equals(p.getGameProfile().name());
   }

   public static boolean isNicked(ServerPlayer p) {
      return current(p, (Nick)ORIGINALS.get(p.getUUID()));
   }

   public static boolean anyNicked() {
      return !ORIGINALS.isEmpty();
   }

   public static String realName(ServerPlayer p) {
      Nick n = (Nick)ORIGINALS.get(p.getUUID());
      return current(p, n) ? n.original().name() : p.getScoreboardName();
   }

   public static String realNameOf(String name) {
      if (name != null && !BY_NICK.isEmpty()) {
         UUID id = (UUID)BY_NICK.get(name.toLowerCase(Locale.ROOT));
         if (id == null) {
            return name;
         } else {
            MinecraftServer server = VexBot.SERVER;
            ServerPlayer p = server != null ? server.getPlayerList().getPlayer(id) : null;
            Nick n = (Nick)ORIGINALS.get(id);
            if (p != null && current(p, n) && n.nickName().equalsIgnoreCase(name)) {
               return BotManager.isTrackedBotName(name) ? name : n.original().name();
            } else {
               return name;
            }
         }
      } else {
         return name;
      }
   }

   private static void unindex(UUID id, Nick n) {
      if (n != null) {
         BY_NICK.remove(n.nickName().toLowerCase(Locale.ROOT), id);
      }

   }

   public static void apply(ServerPlayer p, String newName, String[] skinTex) {
      Nick prev = (Nick)ORIGINALS.get(p.getUUID());
      GameProfile original = current(p, prev) ? prev.original() : p.getGameProfile();
      unindex(p.getUUID(), prev);
      ORIGINALS.put(p.getUUID(), new Nick(original, newName));
      BY_NICK.put(newName.toLowerCase(Locale.ROOT), p.getUUID());
      GameProfile cur = p.getGameProfile();
      Multimap<String, Property> backing = LinkedHashMultimap.create();
      cur.properties().forEach((k, v) -> {
         if (skinTex == null || !"textures".equals(k)) {
            backing.put(k, v);
         }

      });
      if (skinTex != null) {
         backing.put("textures", new Property("textures", skinTex[0], skinTex[1]));
      }

      GameProfile nicked = new GameProfile(cur.id(), newName, new PropertyMap(backing));
      Internals.get().setGameProfile(p, nicked);
      VERSION.incrementAndGet();
      refresh(p);
   }

   public static boolean stop(ServerPlayer p) {
      Nick n = (Nick)ORIGINALS.remove(p.getUUID());
      unindex(p.getUUID(), n);
      VERSION.incrementAndGet();
      if (!current(p, n)) {
         return false;
      } else {
         Internals.get().setGameProfile(p, n.original());
         VERSION.incrementAndGet();
         refresh(p);
         return true;
      }
   }

   public static String originalName(UUID id) {
      Nick n = (Nick)ORIGINALS.get(id);
      return n == null ? null : n.original().name();
   }

   public static void forget(UUID id) {
      unindex(id, (Nick)ORIGINALS.remove(id));
      VERSION.incrementAndGet();
   }

   private static void refresh(ServerPlayer p) {
      ServerLevel level = p.level();
      PlayerList playerList = level.getServer().getPlayerList();
      playerList.broadcastAll(new ClientboundPlayerInfoRemovePacket(List.of(p.getUUID())));
      playerList.broadcastAll(ClientboundPlayerInfoUpdatePacket.createPlayerInitializing(List.of(p)));
      ChunkMap.TrackedEntity tracked = Internals.get().trackedEntity(level.getChunkSource().chunkMap, p.getId());
      if (tracked != null) {
         for(ServerPlayer viewer : playerList.getPlayers()) {
            if (viewer != p) {
               tracked.removePlayer(viewer);
               tracked.updatePlayer(viewer);
            }
         }

      }
   }

   private static record Nick(GameProfile original, String nickName) {
   }
}
