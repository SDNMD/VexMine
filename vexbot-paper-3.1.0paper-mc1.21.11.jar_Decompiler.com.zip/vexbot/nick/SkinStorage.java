package vexbot.nick;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.minecraft.server.MinecraftServer;
import vexbot.VexBot;

public final class SkinStorage {
   public static final String NICK_DIR = "vexbot_skins";
   public static final String TEAM_DIR = "vexbot_teamskins";
   private static final String MINESKIN_URL = "https://api.mineskin.org/generate/upload";
   private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();

   private SkinStorage() {
   }

   public static void ensureFolders(MinecraftServer server) {
      dir(server, "vexbot_skins");
      dir(server, "vexbot_teamskins");
   }

   public static Path dir(MinecraftServer server) {
      return dir(server, "vexbot_skins");
   }

   public static Path dir(MinecraftServer server, String folder) {
      Path dir = server.getServerDirectory().resolve(folder);

      try {
         Files.createDirectories(dir);
      } catch (Exception var4) {
      }

      return dir;
   }

   public static List<String> list(MinecraftServer server) {
      return list(server, "vexbot_skins");
   }

   public static List<String> list(MinecraftServer server, String folder) {
      try {
         Stream<Path> s = Files.list(dir(server, folder));

         List var3;
         try {
            var3 = s.map((p) -> p.getFileName().toString()).filter((n) -> n.toLowerCase().endsWith(".png")).map((n) -> n.substring(0, n.length() - 4)).sorted().toList();
         } catch (Throwable var6) {
            if (s != null) {
               try {
                  s.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (s != null) {
            s.close();
         }

         return var3;
      } catch (Exception var7) {
         return List.of();
      }
   }

   public static CompletableFuture<String[]> getTexture(MinecraftServer server, String name) {
      return getTexture(server, "vexbot_skins", name);
   }

   public static CompletableFuture<String[]> getTexture(MinecraftServer server, String folder, String name) {
      Path png = dir(server, folder).resolve(name + ".png");
      return !Files.isRegularFile(png, new LinkOption[0]) ? CompletableFuture.failedFuture(new IllegalArgumentException("No skin '" + name + ".png' in " + folder + "/")) : CompletableFuture.supplyAsync(() -> {
         try {
            byte[] bytes = Files.readAllBytes(png);
            String sha1 = sha1(bytes);
            Path cache = dir(server, folder).resolve(name + ".png.tex.json");
            if (Files.isRegularFile(cache, new LinkOption[0])) {
               JsonObject j = JsonParser.parseString(Files.readString(cache)).getAsJsonObject();
               if (sha1.equals(j.get("sha1").getAsString())) {
                  return new String[]{j.get("value").getAsString(), j.get("signature").getAsString()};
               }
            }

            String[] tex = uploadToMineSkin(name, bytes);
            JsonObject j = new JsonObject();
            j.addProperty("sha1", sha1);
            j.addProperty("value", tex[0]);
            j.addProperty("signature", tex[1]);
            Files.writeString(cache, j.toString());
            return tex;
         } catch (RuntimeException e) {
            throw e;
         } catch (Exception e) {
            throw new RuntimeException("Skin '" + name + "' failed: " + e.getMessage(), e);
         }
      });
   }

   private static String[] uploadToMineSkin(String name, byte[] png) throws Exception {
      String boundary = "vexbotskin" + Long.toHexString(System.nanoTime());
      ByteArrayOutputStream body = new ByteArrayOutputStream();
      body.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"" + name + ".png\"\r\nContent-Type: image/png\r\n\r\n").getBytes(StandardCharsets.UTF_8));
      body.write(png);
      body.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
      HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.mineskin.org/generate/upload")).header("Content-Type", "multipart/form-data; boundary=" + boundary).header("User-Agent", "VexBot").timeout(Duration.ofSeconds(60L)).POST(BodyPublishers.ofByteArray(body.toByteArray())).build();
      HttpResponse<String> resp = HTTP.send(req, BodyHandlers.ofString());
      if (resp.statusCode() / 100 != 2) {
         throw new RuntimeException("MineSkin upload failed (HTTP " + resp.statusCode() + ") — the server needs internet access; try again in a minute if rate-limited");
      } else {
         JsonObject data = JsonParser.parseString((String)resp.body()).getAsJsonObject().getAsJsonObject("data").getAsJsonObject("texture");
         String value = data.get("value").getAsString();
         String sig = data.get("signature").getAsString();
         VexBot.LOGGER.info("[VexBot] Skin '{}' uploaded to MineSkin and cached", name);
         return new String[]{value, sig};
      }
   }

   private static String sha1(byte[] bytes) throws Exception {
      StringBuilder sb = new StringBuilder();

      for(byte b : MessageDigest.getInstance("SHA-1").digest(bytes)) {
         sb.append(String.format("%02x", b));
      }

      return sb.toString();
   }
}
