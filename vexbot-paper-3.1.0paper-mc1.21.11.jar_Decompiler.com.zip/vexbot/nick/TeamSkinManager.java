package vexbot.nick;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.PlayerList;
import vexbot.VexBot;
import vexbot.bot.BotManager;
import vexbot.platform.Internals;
import vexbot.team.TeamManager;

public final class TeamSkinManager {
   private static final int CHECK_INTERVAL = 40;
   private static final Map<String, String[]> TEXTURES = new ConcurrentHashMap();
   private static final Map<String, Boolean> RESOLVING = new ConcurrentHashMap();
   private static final Map<String, long[]> FAILED = new ConcurrentHashMap();
   private static final long RETRY_MIN_MS = 60000L;
   private static final long RETRY_MAX_MS = 1800000L;
   private static final Map<UUID, String> DRESSED = new ConcurrentHashMap();
   private static int tickCounter = 0;

   private TeamSkinManager() {
   }

   private static String key(String s) {
      return s.toLowerCase(Locale.ROOT);
   }

   public static void warm(MinecraftServer server, String skinName) {
      if (skinName != null && !skinName.isBlank()) {
         FAILED.remove(key(skinName));
         resolve(server, skinName);
      }
   }

   private static void resolve(MinecraftServer server, String skinName) {
      String k = key(skinName);
      if (RESOLVING.putIfAbsent(k, Boolean.TRUE) == null) {
         SkinStorage.getTexture(server, "vexbot_teamskins", skinName).whenComplete((tex, err) -> {
            RESOLVING.remove(k);
            if (err == null && tex != null) {
               FAILED.remove(k);
               TEXTURES.put(k, tex);
               VexBot.LOGGER.info("[VexBot] Team skin '{}' ready", skinName);
            } else {
               Throwable cause = err == null ? null : (err.getCause() != null ? err.getCause() : err);
               long now = System.currentTimeMillis();
               long[] next = (long[])FAILED.compute(k, (kk, prev) -> {
                  long delay = prev == null ? 60000L : Math.min(prev[1] * 2L, 1800000L);
                  return new long[]{now + delay, delay};
               });
               VexBot.LOGGER.warn("[VexBot] Team skin '{}' could not be loaded: {} (retrying in {}s)", new Object[]{skinName, cause == null ? "unknown error" : cause.getMessage(), next[1] / 1000L});
            }
         });
      }
   }

   private static boolean backingOff(String skinName) {
      long[] f = (long[])FAILED.get(key(skinName));
      return f != null && System.currentTimeMillis() < f[0];
   }

   public static int wearing(MinecraftServer server, TeamManager.BotTeam team) {
      String[] tex = team.teamSkin == null ? null : (String[])TEXTURES.get(key(team.teamSkin));
      if (tex == null) {
         return 0;
      } else {
         int n = 0;

         for(ServerPlayer bot : botsOf(server, team)) {
            if (tex[0].equals(currentTexture(bot))) {
               ++n;
            }
         }

         return n;
      }
   }

   public static int online(MinecraftServer server, TeamManager.BotTeam team) {
      return botsOf(server, team).size();
   }

   public static boolean isReady(String skinName) {
      return skinName != null && TEXTURES.containsKey(key(skinName));
   }

   public static void revert(MinecraftServer server, TeamManager.BotTeam team) {
      for(ServerPlayer bot : botsOf(server, team)) {
         DRESSED.remove(bot.getUUID());
         if (currentTexture(bot) != null) {
            applyTexture(bot, (String[])null);
         }
      }

   }

   public static void onServerTick(MinecraftServer server) {
      if (++tickCounter >= 40) {
         tickCounter = 0;
         Set<UUID> uniformed = new HashSet();

         for(TeamManager.BotTeam team : TeamManager.allTeams()) {
            String skin = team.teamSkin;
            if (skin != null && !skin.isBlank()) {
               List<ServerPlayer> bots = botsOf(server, team);

               for(ServerPlayer bot : bots) {
                  uniformed.add(bot.getUUID());
               }

               String[] tex = (String[])TEXTURES.get(key(skin));
               if (tex == null) {
                  if (!backingOff(skin)) {
                     resolve(server, skin);
                  }
               } else {
                  for(ServerPlayer bot : bots) {
                     if (!NickManager.isNicked(bot) && !tex[0].equals(currentTexture(bot))) {
                        applyTexture(bot, tex);
                        DRESSED.put(bot.getUUID(), tex[0]);
                     }
                  }
               }
            }
         }

         Iterator<Map.Entry<UUID, String>> it = DRESSED.entrySet().iterator();

         while(it.hasNext()) {
            Map.Entry<UUID, String> e = (Map.Entry)it.next();
            if (!uniformed.contains(e.getKey())) {
               it.remove();
               ServerPlayer bot = server.getPlayerList().getPlayer((UUID)e.getKey());
               if (bot != null && ((String)e.getValue()).equals(currentTexture(bot))) {
                  applyTexture(bot, (String[])null);
               }
            }
         }

      }
   }

   private static String currentTexture(ServerPlayer p) {
      Iterator var1 = p.getGameProfile().properties().get("textures").iterator();
      if (var1.hasNext()) {
         Property prop = (Property)var1.next();
         return prop.value();
      } else {
         return null;
      }
   }

   private static void applyTexture(ServerPlayer p, String[] tex) {
      GameProfile cur = p.getGameProfile();
      Multimap<String, Property> backing = LinkedHashMultimap.create();
      cur.properties().forEach((k, v) -> {
         if (!"textures".equals(k)) {
            backing.put(k, v);
         }

      });
      if (tex != null) {
         Property prop = tex[1] != null && !tex[1].isEmpty() ? new Property("textures", tex[0], tex[1]) : new Property("textures", tex[0]);
         backing.put("textures", prop);
      }

      Internals.get().setGameProfile(p, new GameProfile(cur.id(), cur.name(), new PropertyMap(backing)));
      refresh(p);
   }

   private static void refresh(ServerPlayer p) {
      ServerLevel level = p.level();
      PlayerList playerList = level.getServer().getPlayerList();
      playerList.broadcastAll(new ClientboundPlayerInfoRemovePacket(List.of(p.getUUID())));
      playerList.broadcastAll(ClientboundPlayerInfoUpdatePacket.createPlayerInitializing(List.of(p)));
      ChunkMap.TrackedEntity tracked = Internals.get().trackedEntity(level.getChunkSource().chunkMap, p.getId());
      if (tracked != null) {
         for(ServerPlayer viewer : playerList.getPlayers()) {
            if (viewer != p) {
               tracked.removePlayer(viewer);
               tracked.updatePlayer(viewer);
            }
         }

      }
   }

   private static List<ServerPlayer> botsOf(MinecraftServer server, TeamManager.BotTeam team) {
      List<ServerPlayer> out = new ArrayList();

      for(String name : team.getBotNames()) {
         ServerPlayer p = server.getPlayerList().getPlayerByName(name);
         if (p == null) {
            p = BotManager.resolveTrackedBotPlayer(server, name);
         }

         if (p != null) {
            out.add(p);
         }
      }

      return out;
   }
}
