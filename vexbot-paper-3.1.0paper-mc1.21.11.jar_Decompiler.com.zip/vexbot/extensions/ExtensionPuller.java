package vexbot.extensions;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.channels.UnresolvedAddressException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import vexbot.i18n.VexText;
import vexbot.platform.Platform;
import vexbot.stats.Stats;

public final class ExtensionPuller {
   private static final Logger LOGGER = LoggerFactory.getLogger("VexBot-Extensions");
   private static final String[] DEFAULT_BASES = new String[]{"https://var-preserve-sci-holland.trycloudflare.com"};
   private static final String MANIFEST = "/extensions.json";
   private static final String CONFIG_FILE = "config/vexbot-extensions.txt";
   private static final Pattern SAFE_ID = Pattern.compile("[a-z0-9][a-z0-9-]{0,31}");
   private static final long MAX_BYTES = 67108864L;
   private static final Duration TIMEOUT = Duration.ofSeconds(20L);
   private static final HttpClient HTTP;
   private static volatile boolean busy;

   private ExtensionPuller() {
   }

   public static List<String> baseUrls() {
      List<String> out = new ArrayList();
      String prop = System.getProperty("vexbot.extensions.url", "").trim();
      if (!prop.isEmpty()) {
         addHost(out, prop);
      }

      for(String s : readConfiguredUrls()) {
         addHost(out, s);
      }

      for(String s : DEFAULT_BASES) {
         addHost(out, s);
      }

      return out;
   }

   private static void addHost(List<String> out, String raw) {
      String v;
      for(v = raw.trim(); v.endsWith("/"); v = v.substring(0, v.length() - 1)) {
      }

      if (!v.isEmpty() && !out.contains(v)) {
         out.add(v);
      }

   }

   private static List<String> readConfiguredUrls() {
      List<String> out = new ArrayList();

      try {
         Path f = Path.of("config/vexbot-extensions.txt");
         if (!Files.isRegularFile(f, new LinkOption[0])) {
            return out;
         }

         for(String line : Files.readAllLines(f)) {
            String s = line.trim();
            if (!s.isEmpty() && !s.startsWith("#")) {
               out.add(s);
            }
         }
      } catch (Exception var5) {
      }

      return out;
   }

   private static boolean allowedTransport(String base) {
      if (base.startsWith("https://")) {
         return true;
      } else if (!base.startsWith("http://")) {
         return false;
      } else {
         try {
            String host = URI.create(base).getHost();
            if (host == null) {
               return false;
            }

            if (host.equals("localhost") || host.startsWith("127.")) {
               return true;
            }

            if (host.startsWith("10.") || host.startsWith("192.168.")) {
               return true;
            }

            if (host.startsWith("172.")) {
               int second = Integer.parseInt(host.split("\\.")[1]);
               return second >= 16 && second <= 31;
            }

            if (host.startsWith("100.")) {
               int second = Integer.parseInt(host.split("\\.")[1]);
               return second >= 64 && second <= 127;
            }
         } catch (Exception var3) {
         }

         return false;
      }
   }

   public static void ensureConfig() {
      try {
         Path f = Path.of("config/vexbot-extensions.txt");
         Files.createDirectories(f.getParent());
         StringBuilder sb = new StringBuilder();
         sb.append("# Where /vexbot extensions pulls add-ons from.\n");
         sb.append("# One host per line, tried top to bottom until one answers.\n");
         sb.append("# Plain http:// is allowed only for private/LAN/Tailscale addresses.\n");
         sb.append("#\n");
         sb.append("# THIS FILE IS REGENERATED EVERY SERVER START - edits here are lost.\n");
         sb.append("# For a permanent custom host use: -Dvexbot.extensions.url=https://your.host\n");

         for(String s : DEFAULT_BASES) {
            sb.append(s).append(System.lineSeparator());
         }

         Files.writeString(f, sb.toString());
         LOGGER.info("[Extensions] host list reset to {} default host(s)", DEFAULT_BASES.length);
      } catch (Exception e) {
         LOGGER.debug("[Extensions] couldn't write {}: {}", "config/vexbot-extensions.txt", e.toString());
      }

   }

   public static int pull(CommandSourceStack src, String rawId) {
      if (!supported(src)) {
         return 0;
      } else {
         MinecraftServer server = src.getServer();
         String id = rawId.toLowerCase(Locale.ROOT);
         if (!SAFE_ID.matcher(id).matches()) {
            src.sendFailure(VexText.literal("[VexBot] Invalid extension name."));
            return 0;
         } else if (busy) {
            src.sendFailure(VexText.literal("[VexBot] Another download is already running."));
            return 0;
         } else {
            busy = true;
            say(server, src, "§8[§6VexBot§8] §7Scanning for §f" + id + "§7…");
            Thread worker = new Thread(() -> {
               try {
                  Resolved r = resolveHost(server, src);
                  if (r != null) {
                     runPull(server, src, r, id);
                  }
               } catch (Exception e) {
                  offlineOrError(server, src, e);
               } finally {
                  busy = false;
               }

            }, "VexBot-ExtensionPull");
            worker.setDaemon(true);
            worker.start();
            return 1;
         }
      }
   }

   public static int unload(CommandSourceStack src, String rawId) {
      if (!supported(src)) {
         return 0;
      } else {
         MinecraftServer server = src.getServer();
         String id = rawId.toLowerCase(Locale.ROOT);
         if (!SAFE_ID.matcher(id).matches()) {
            src.sendFailure(VexText.literal("[VexBot] Invalid extension name."));
            return 0;
         } else if (busy) {
            src.sendFailure(VexText.literal("[VexBot] Another extension task is already running."));
            return 0;
         } else {
            busy = true;
            Thread worker = new Thread(() -> {
               try {
                  Path mods = Platform.get().extensionsDir();
                  List<Path> found = new ArrayList();
                  String publishedFile = null;

                  try {
                     Resolved r = resolveHost(server, src, true);
                     if (r != null && r.manifest.has(id)) {
                        JsonObject e = r.manifest.getAsJsonObject(id);
                        if (e.has("file")) {
                           publishedFile = e.get("file").getAsString();
                        }
                     }
                  } catch (Exception var20) {
                  }

                  if (publishedFile != null) {
                     found.addAll(findInstalled(mods, publishedFile));
                  }

                  if (found.isEmpty()) {
                     String prefix = isPaper() ? id + "-paper" : id;

                     for(Path p : findInstalled(mods, prefix + "-0.jar")) {
                        String n = p.getFileName().toString();
                        if (Character.isDigit(n.charAt(prefix.length() + 1)) && isVexBotAddon(p)) {
                           found.add(p);
                        }
                     }
                  }

                  if (!found.isEmpty()) {
                     int removed = 0;

                     for(Path p : found) {
                        String name = p.getFileName().toString();

                        try {
                           Files.delete(p);
                           ++removed;
                           say(server, src, "§8[§6VexBot§8] §aRemoved §f" + name);
                           LOGGER.info("[Extensions] unloaded {}", name);
                        } catch (Exception var19) {
                           try {
                              Files.move(p, p.resolveSibling(name + ".old"), StandardCopyOption.REPLACE_EXISTING);
                              ++removed;
                              say(server, src, "§8[§6VexBot§8] §e" + name + "§7 was in use — renamed to .old, delete it later.");
                           } catch (Exception var18) {
                              say(server, src, "§8[§6VexBot§8] §cCouldn't remove §f" + name + "§c — delete it from " + folder() + " yourself.");
                           }
                        }
                     }

                     if (removed > 0) {
                        say(server, src, "§8[§6VexBot§8] §7Restart the server to finish unloading §f" + id + "§7 — an add-on that's already running can't be unloaded.");
                     }

                     return;
                  }

                  say(server, src, "§8[§6VexBot§8] §7Nothing installed matching §f" + id + "§7.");
               } catch (Exception e) {
                  offlineOrError(server, src, e);
                  return;
               } finally {
                  busy = false;
               }

            }, "VexBot-ExtensionUnload");
            worker.setDaemon(true);
            worker.start();
            return 1;
         }
      }
   }

   public static int list(CommandSourceStack src) {
      MinecraftServer server = src.getServer();
      say(server, src, "§8[§6VexBot§8] §7Scanning the extension list…");
      Thread worker = new Thread(() -> {
         try {
            Resolved r = resolveHost(server, src);
            if (r == null) {
               return;
            }

            JsonObject man = r.manifest;
            List<String> ids = new ArrayList(man.keySet());
            if (ids.isEmpty()) {
               say(server, src, "§8[§6VexBot§8] §7No extensions published yet.");
               return;
            }

            say(server, src, "§8[§6VexBot§8] §aAvailable: §f" + String.join("§7, §f", ids));

            for(String k : ids) {
               JsonObject e = man.getAsJsonObject(k);
               say(server, src, "  §8• §e" + k + " §7v" + (e.has("version") ? e.get("version").getAsString() : "?") + (e.has("description") ? " §8— §7" + e.get("description").getAsString() : ""));
            }
         } catch (Exception e) {
            offlineOrError(server, src, e);
         }

      }, "VexBot-ExtensionList");
      worker.setDaemon(true);
      worker.start();
      return 1;
   }

   public static int update(CommandSourceStack src) {
      if (!supported(src)) {
         return 0;
      } else {
         MinecraftServer server = src.getServer();
         if (busy) {
            src.sendFailure(VexText.literal("[VexBot] Another download is already running."));
            return 0;
         } else {
            busy = true;
            say(server, src, "§8[§6VexBot§8] §7Checking installed extensions for updates…");
            Thread worker = new Thread(() -> {
               try {
                  Resolved r = resolveHost(server, src);
                  if (r != null) {
                     runUpdateAll(server, src, r);
                  }
               } catch (Exception e) {
                  offlineOrError(server, src, e);
               } finally {
                  busy = false;
               }

            }, "VexBot-ExtensionUpdate");
            worker.setDaemon(true);
            worker.start();
            return 1;
         }
      }
   }

   private static void runPull(MinecraftServer server, CommandSourceStack src, Resolved r, String id) throws Exception {
      JsonObject manifest = r.manifest;
      if (!manifest.has(id)) {
         say(server, src, "§8[§6VexBot§8] §cNo extension called '" + id + "'. Try §f/vexbot extensions list§c.");
      } else {
         if (installEntry(server, src, r.base, id, manifest.getAsJsonObject(id), true)) {
            say(server, src, "§8[§6VexBot§8] §7Restart the server to load it.");
         }

      }
   }

   private static void runUpdateAll(MinecraftServer server, CommandSourceStack src, Resolved r) throws Exception {
      JsonObject manifest = r.manifest;
      Path mods = Platform.get().extensionsDir();
      int updated = 0;
      int current = 0;
      int skipped = 0;

      for(String id : manifest.keySet()) {
         JsonObject entry = manifest.getAsJsonObject(id);
         if (entry.has("file")) {
            String safeFile = safeFileName(entry.get("file").getAsString());
            if (safeFile == null) {
               ++skipped;
            } else {
               List<Path> installed = findInstalled(mods, safeFile);
               if (installed.isEmpty()) {
                  ++skipped;
               } else {
                  boolean alreadyCurrent = installed.size() == 1 && ((Path)installed.get(0)).getFileName().toString().equals(safeFile);
                  if (alreadyCurrent) {
                     ++current;
                  } else {
                     String oldVersion = versionFromFile(((Path)installed.get(0)).getFileName().toString());
                     if (installEntry(server, src, r.base, id, entry, false, oldVersion)) {
                        for(Path old : installed) {
                           if (!old.getFileName().toString().equals(safeFile)) {
                              retireOldJar(server, src, old);
                           }
                        }

                        ++updated;
                     }
                  }
               }
            }
         }
      }

      if (updated == 0 && current == 0) {
         say(server, src, "§8[§6VexBot§8] §7No extensions installed — nothing to update. Use §f/vexbot extensions pull <id>§7.");
      } else {
         say(server, src, "§8[§6VexBot§8] §a✔ Update finished — §f" + updated + "§a updated, §f" + current + "§a already current" + (skipped > 0 ? "§7, " + skipped + " not installed" : ""));
         if (updated > 0) {
            say(server, src, "§8[§6VexBot§8] §7Restart the server to load the new versions.");
         }

      }
   }

   private static boolean installEntry(MinecraftServer server, CommandSourceStack src, String base, String id, JsonObject entry, boolean verbose) throws Exception {
      return installEntry(server, src, base, id, entry, verbose, (String)null);
   }

   private static boolean installEntry(MinecraftServer server, CommandSourceStack src, String base, String id, JsonObject entry, boolean verbose, String fromVersion) throws Exception {
      String file = entry.get("file").getAsString();
      String want = entry.has("sha256") ? entry.get("sha256").getAsString().toLowerCase(Locale.ROOT) : null;
      String version = entry.has("version") ? entry.get("version").getAsString() : "?";
      String safeFile = safeFileName(file);
      if (safeFile == null) {
         say(server, src, "§8[§6VexBot§8] §cThe host offered an unsafe filename. Aborted.");
         LOGGER.warn("[Extensions] rejected filename from manifest: {}", file);
         return false;
      } else {
         say(server, src, "§8[§6VexBot§8] §7Found §f" + id + " §7v" + version + " §8— §7downloading…");
         HttpResponse<byte[]> res = HTTP.send(HttpRequest.newBuilder(URI.create(base + "/" + safeFile)).timeout(TIMEOUT).GET().header("User-Agent", "VexBot-ExtensionPuller").build(), BodyHandlers.ofByteArray());
         if (res.statusCode() != 200) {
            say(server, src, "§8[§6VexBot§8] §cDownload failed for " + id + " (HTTP " + res.statusCode() + ").");
            return false;
         } else {
            byte[] jar = (byte[])res.body();
            if (jar.length != 0 && (long)jar.length <= 67108864L) {
               if (verbose) {
                  say(server, src, "§8[§6VexBot§8] §7Verifying… §8(" + jar.length / 1024 + " KB)");
               }

               String got = sha256(jar);
               if (want != null && want.equals(got)) {
                  if (verbose) {
                     say(server, src, "§8[§6VexBot§8] §7Installing…");
                  }

                  Path mods = Platform.get().extensionsDir();
                  Files.createDirectories(mods);
                  Path tmp = mods.resolve(safeFile + ".part");
                  Path dest = mods.resolve(safeFile);
                  Files.write(tmp, jar, new OpenOption[0]);
                  Files.move(tmp, dest, StandardCopyOption.REPLACE_EXISTING);
                  say(server, src, "§8[§6VexBot§8] §a✔ Installed " + id + " v" + version + (fromVersion != null ? " §8(was v" + fromVersion + ")" : "") + " §7→ " + folder() + safeFile);
                  showChangelog(server, src, entry, version, fromVersion);
                  LOGGER.info("[Extensions] installed {} v{} ({} bytes)", new Object[]{id, version, jar.length});
                  Stats.extensionPulled(id);
                  return true;
               } else {
                  say(server, src, "§8[§6VexBot§8] §cChecksum mismatch on " + id + " — file discarded for safety.");
                  LOGGER.warn("[Extensions] {} checksum mismatch: want={} got={}", new Object[]{id, want, got});
                  return false;
               }
            } else {
               say(server, src, "§8[§6VexBot§8] §cDownload rejected — unexpected size.");
               return false;
            }
         }
      }
   }

   private static void showChangelog(MinecraftServer server, CommandSourceStack src, JsonObject entry, String version, String fromVersion) {
      if (entry.has("changelog")) {
         try {
            List<String> lines = new ArrayList();
            JsonElement cl = entry.get("changelog");
            if (cl.isJsonArray()) {
               for(JsonElement e : cl.getAsJsonArray()) {
                  lines.add(e.getAsString());
               }
            } else {
               lines.add(cl.getAsString());
            }

            if (lines.isEmpty()) {
               return;
            }

            String var10002 = fromVersion != null ? " since v" + fromVersion : " in v" + version;
            say(server, src, "§8[§6VexBot§8] §6What's new" + var10002 + ":");

            for(String line : lines) {
               say(server, src, "   §8• §f" + line);
            }
         } catch (Exception e) {
            LOGGER.debug("[Extensions] malformed changelog for v{}: {}", version, e.toString());
         }

      }
   }

   private static String versionFromFile(String fileName) {
      int dash = fileName.lastIndexOf(45);
      if (dash >= 0 && fileName.endsWith(".jar")) {
         String v = fileName.substring(dash + 1, fileName.length() - 4);
         return v.isEmpty() ? null : v;
      } else {
         return null;
      }
   }

   private static String safeFileName(String file) {
      String bare = Path.of(file).getFileName().toString();
      return bare.equals(file) && bare.endsWith(".jar") && !bare.contains("..") ? bare : null;
   }

   private static List<Path> findInstalled(Path mods, String publishedFile) {
      List<Path> out = new ArrayList();
      int dash = publishedFile.lastIndexOf(45);
      if (dash <= 0) {
         return out;
      } else {
         String stem = publishedFile.substring(0, dash + 1);
         if (!Files.isDirectory(mods, new LinkOption[0])) {
            return out;
         } else {
            try {
               Stream<Path> s = Files.list(mods);

               try {
                  Stream var10000 = s.filter((x$0) -> Files.isRegularFile(x$0, new LinkOption[0])).filter((p) -> {
                     String n = p.getFileName().toString();
                     return n.startsWith(stem) && n.endsWith(".jar");
                  });
                  Objects.requireNonNull(out);
                  var10000.forEach(out::add);
               } catch (Throwable var9) {
                  if (s != null) {
                     try {
                        s.close();
                     } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                     }
                  }

                  throw var9;
               }

               if (s != null) {
                  s.close();
               }
            } catch (Exception e) {
               LOGGER.warn("[Extensions] couldn't scan mods/: {}", e.toString());
            }

            return out;
         }
      }
   }

   private static boolean isVexBotAddon(Path jar) {
      try {
         ZipFile zip = new ZipFile(jar.toFile());

         boolean var18;
         label129: {
            boolean var22;
            label128: {
               label127: {
                  label126: {
                     boolean var6;
                     try {
                        ZipEntry meta = zip.getEntry("fabric.mod.json");
                        if (meta == null) {
                           ZipEntry yml = zip.getEntry("plugin.yml");
                           if (yml == null) {
                              var18 = false;
                              break label129;
                           }

                           InputStream in = zip.getInputStream(yml);

                           try {
                              text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                           } catch (Throwable var12) {
                              if (in != null) {
                                 try {
                                    in.close();
                                 } catch (Throwable var10) {
                                    var12.addSuppressed(var10);
                                 }
                              }

                              throw var12;
                           }

                           if (in != null) {
                              in.close();
                           }

                           if (Pattern.compile("(?im)^name\\s*:\\s*['\"]?VexBot['\"]?\\s*$").matcher(text).find()) {
                              var22 = false;
                              break label128;
                           }

                           var22 = Pattern.compile("(?im)^\\s*depend\\s*:.*\\bVexBot\\b").matcher(text).find() || Pattern.compile("(?is)\\bdepend\\s*:\\s*(?:\\n\\s*-\\s*[^\\n]*)*?\\n\\s*-\\s*['\"]?VexBot\\b").matcher(text).find();
                           break label127;
                        }

                        InputStream in = zip.getInputStream(meta);

                        String text;
                        try {
                           text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                        } catch (Throwable var11) {
                           if (in != null) {
                              try {
                                 in.close();
                              } catch (Throwable var9) {
                                 var11.addSuppressed(var9);
                              }
                           }

                           throw var11;
                        }

                        if (in != null) {
                           in.close();
                        }

                        JsonObject mod = JsonParser.parseString(text).getAsJsonObject();
                        if (mod.has("id") && "vexbot".equals(mod.get("id").getAsString())) {
                           var22 = false;
                           break label126;
                        }

                        JsonElement deps = mod.get("depends");
                        var6 = deps != null && deps.isJsonObject() && deps.getAsJsonObject().has("vexbot");
                     } catch (Throwable var13) {
                        try {
                           zip.close();
                        } catch (Throwable var8) {
                           var13.addSuppressed(var8);
                        }

                        throw var13;
                     }

                     zip.close();
                     return var6;
                  }

                  zip.close();
                  return var22;
               }

               zip.close();
               return var22;
            }

            zip.close();
            return var22;
         }

         zip.close();
         return var18;
      } catch (Exception var14) {
         return false;
      }
   }

   private static void retireOldJar(MinecraftServer server, CommandSourceStack src, Path old) {
      String name = old.getFileName().toString();

      try {
         Files.delete(old);
         LOGGER.info("[Extensions] removed superseded {}", name);
      } catch (Exception var6) {
         try {
            Files.move(old, old.resolveSibling(name + ".old"), StandardCopyOption.REPLACE_EXISTING);
            say(server, src, "§8[§6VexBot§8] §7Old §f" + name + "§7 renamed to .old (delete it later).");
         } catch (Exception e) {
            say(server, src, "§8[§6VexBot§8] §cCouldn't remove the old §f" + name + "§c — delete it manually or the server won't start (duplicate mod).");
            LOGGER.warn("[Extensions] failed to retire {}: {}", name, e.toString());
         }

      }
   }

   private static Resolved resolveHost(MinecraftServer server, CommandSourceStack src) {
      return resolveHost(server, src, false);
   }

   private static Resolved resolveHost(MinecraftServer server, CommandSourceStack src, boolean quiet) {
      List<String> hosts = baseUrls();
      String who = src.getPlayer() != null ? src.getPlayer().getGameProfile().name() : null;
      Exception last = null;

      for(String base : hosts) {
         if (allowedTransport(base)) {
            try {
               JsonObject man = fetchManifest(base, who);
               LOGGER.info("[Extensions] using host {}", base);
               return new Resolved(base, man);
            } catch (Exception e) {
               LOGGER.info("[Extensions] host {} did not answer: {}", base, e.toString());
               last = e;
            }
         } else {
            LOGGER.warn("[Extensions] skipping insecure host {}", base);
         }
      }

      if (quiet) {
         return null;
      } else {
         if (last != null) {
            offlineOrError(server, src, last);
         } else {
            say(server, src, "§8[§6VexBot§8] §cNo usable extension host configured.");
         }

         return null;
      }
   }

   private static JsonObject fetchManifest(String base) throws Exception {
      return fetchManifest(base, (String)null);
   }

   private static JsonObject fetchManifest(String base, String who) throws Exception {
      String q = who != null && !who.isBlank() ? "?u=" + URLEncoder.encode(who, StandardCharsets.UTF_8) : "";
      HttpResponse<String> res = HTTP.send(HttpRequest.newBuilder(URI.create(base + "/extensions.json" + q)).timeout(TIMEOUT).GET().header("User-Agent", "VexBot-ExtensionPuller").build(), BodyHandlers.ofString());
      if (res.statusCode() != 200) {
         throw new IllegalStateException("manifest HTTP " + res.statusCode());
      } else {
         return forThisGame(JsonParser.parseString((String)res.body()).getAsJsonObject());
      }
   }

   private static JsonObject forThisGame(JsonObject man) {
      String mc = "1.21.11";
      boolean paper = isPaper();
      String key = paper ? "paper" : "files";
      JsonObject out = new JsonObject();

      for(String id : man.keySet()) {
         JsonElement el = man.get(id);
         if (el.isJsonObject() && el.getAsJsonObject().has(key)) {
            JsonElement files = el.getAsJsonObject().get(key);
            if (!files.isJsonObject() || !files.getAsJsonObject().has(mc) || !files.getAsJsonObject().get(mc).isJsonObject()) {
               continue;
            }

            JsonObject pick = files.getAsJsonObject().getAsJsonObject(mc);
            JsonObject entry = el.getAsJsonObject().deepCopy();
            entry.remove("files");
            entry.remove("paper");
            if (pick.has("file")) {
               entry.add("file", pick.get("file"));
            }

            if (pick.has("sha256")) {
               entry.add("sha256", pick.get("sha256"));
            }

            el = entry;
         } else if (paper) {
            continue;
         }

         out.add(id, el);
      }

      return out;
   }

   private static boolean supported(CommandSourceStack src) {
      String loader = Platform.get().loaderName();
      if (!"Fabric".equals(loader) && !"Paper".equals(loader)) {
         src.sendFailure(VexText.literal("[VexBot] Extensions can only be installed on Fabric or Paper, not " + loader + "."));
         return false;
      } else {
         return true;
      }
   }

   private static boolean isPaper() {
      return "Paper".equals(Platform.get().loaderName());
   }

   private static String folder() {
      Path dir = Platform.get().extensionsDir();
      String var10000 = dir.getFileName() != null ? dir.getFileName().toString() : "mods";
      return var10000 + "/";
   }

   private static void offlineOrError(MinecraftServer server, CommandSourceStack src, Exception e) {
      Throwable root;
      for(root = e; root.getCause() != null && root.getCause() != root; root = root.getCause()) {
      }

      boolean offline = root instanceof UnknownHostException || root instanceof ConnectException || root instanceof SocketTimeoutException || root instanceof NoRouteToHostException || root instanceof UnresolvedAddressException || root instanceof HttpConnectTimeoutException;
      if (offline) {
         if (hasInternet()) {
            say(server, src, "§8[§6VexBot§8] §cThe extension host isn't reachable right now.");
            say(server, src, "§7Your connection is fine — the download server is down");
            say(server, src, "§7or moved. Try again later. Nothing was changed.");
         } else {
            say(server, src, "§8[§6VexBot§8] §cNo internet connection.");
            say(server, src, "§7This server can't reach the internet — check the Wi-Fi");
            say(server, src, "§7or network cable and try again. Nothing was changed.");
         }
      } else {
         say(server, src, "§8[§6VexBot§8] §cCouldn't fetch the extension: §7" + root.getMessage());
      }

      LOGGER.warn("[Extensions] pull failed: {}", root.toString());
   }

   private static boolean hasInternet() {
      try {
         HttpResponse<Void> r = HTTP.send(HttpRequest.newBuilder(URI.create("https://cloudflare.com/cdn-cgi/trace")).timeout(Duration.ofSeconds(6L)).method("HEAD", BodyPublishers.noBody()).build(), BodyHandlers.discarding());
         return r.statusCode() > 0;
      } catch (Exception var1) {
         return false;
      }
   }

   private static String sha256(byte[] data) throws Exception {
      byte[] d = MessageDigest.getInstance("SHA-256").digest(data);
      StringBuilder sb = new StringBuilder(d.length * 2);

      for(byte b : d) {
         sb.append(Character.forDigit(b >> 4 & 15, 16)).append(Character.forDigit(b & 15, 16));
      }

      return sb.toString();
   }

   private static void say(MinecraftServer server, CommandSourceStack src, String msg) {
      server.execute(() -> src.sendSystemMessage(VexText.literal(src, msg)));
   }

   static {
      HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).followRedirects(Redirect.NORMAL).build();
      busy = false;
   }

   private static record Resolved(String base, JsonObject manifest) {
   }
}
