package vexbot;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.server.MinecraftServer;
import vexbot.nick.NickManager;
import vexbot.settings.TechniqueConfig;
import vexbot.team.TeamManager;

public final class EffectiveSettings {
   private final TeamManager.BotTeam team;
   private final BotSettings.PlayStyle playStyle;
   private final DifficultyParams botDifficulty;
   private static final ConcurrentHashMap<String, EffectiveSettings> CACHE = new ConcurrentHashMap();
   private static volatile int cachedTick = -1;
   private static volatile long cachedEpoch = -1L;
   private static final AtomicLong EPOCH = new AtomicLong();
   private static String lastName;
   private static Object lastServer;
   private static int lastTick = -1;
   private static long lastEpoch = -1L;
   private static EffectiveSettings lastValue;

   public static void invalidate() {
      EPOCH.incrementAndGet();
   }

   public static EffectiveSettings of(String botName) {
      if (botName == null) {
         return new EffectiveSettings((String)null);
      } else {
         botName = NickManager.realNameOf(botName);
         MinecraftServer server = VexBot.SERVER;
         if (server == null) {
            return new EffectiveSettings(botName);
         } else {
            int tick = server.getTickCount();
            long epoch = EPOCH.get();
            boolean serverThread = server.isSameThread();
            if (serverThread && botName == lastName && server == lastServer && tick == lastTick && epoch == lastEpoch && tick == cachedTick && epoch == cachedEpoch) {
               return lastValue;
            } else {
               if (tick != cachedTick || epoch != cachedEpoch) {
                  CACHE.clear();
                  cachedTick = tick;
                  cachedEpoch = epoch;
               }

               EffectiveSettings hit = (EffectiveSettings)CACHE.get(botName);
               EffectiveSettings value = hit != null ? hit : (EffectiveSettings)CACHE.computeIfAbsent(botName, EffectiveSettings::new);
               if (serverThread) {
                  lastName = botName;
                  lastServer = server;
                  lastTick = tick;
                  lastEpoch = epoch;
                  lastValue = value;
               }

               return value;
            }
         }
      }
   }

   public EffectiveSettings(String botName) {
      this.team = TeamManager.getTeamForBot(botName);
      this.botDifficulty = BotSettings.botDifficultyFor(botName);
      BotSettings.PlayStyle raw = BotSettings.playStyleFor(botName);
      this.playStyle = raw == BotSettings.PlayStyle.ADAPTIVE ? BotSettings.adaptiveResolvedFor(botName) : raw;
   }

   public BotSettings.PlayStyle playStyle() {
      return this.playStyle;
   }

   public boolean equipArmor() {
      return this.team != null ? this.team.equipArmor : BotSettings.equipArmor;
   }

   public boolean usePotions() {
      return this.team != null ? this.team.usePotions : BotSettings.usePotions;
   }

   public boolean retreat() {
      if (this.retreatOrdered()) {
         return true;
      } else {
         boolean var10000;
         switch (this.playStyle) {
            case SAFE:
            case DEFENSIVE:
               var10000 = true;
               break;
            case AGGRESSIVE:
               var10000 = false;
               break;
            default:
               var10000 = this.team != null ? this.team.retreat : BotSettings.retreat;
         }

         return var10000;
      }
   }

   public boolean retreatOrdered() {
      return this.team != null && this.team.tactics != null && this.team.tactics.retreatWhenLow;
   }

   public boolean useCobwebs() {
      return this.team != null ? this.team.useCobwebs : BotSettings.useCobwebs;
   }

   public BotSettings.BunnyHopMode bunnyHopMode() {
      return this.team != null ? this.team.bunnyHopMode : BotSettings.bunnyHopMode;
   }

   public boolean autoTarget() {
      return this.team != null ? this.team.autoTarget : BotSettings.autoTarget;
   }

   public boolean targetPlayers() {
      return this.team != null ? this.team.targetPlayers : BotSettings.targetPlayers;
   }

   public boolean targetBots() {
      return this.team != null ? this.team.targetBots : BotSettings.targetBots;
   }

   public boolean targetMobs() {
      return this.team != null ? this.team.targetMobs : BotSettings.targetMobs;
   }

   public BotSettings.Difficulty difficulty() {
      return this.team != null ? this.team.difficulty : BotSettings.difficulty;
   }

   public DifficultyParams difficultyParams() {
      if (this.botDifficulty != null) {
         return this.botDifficulty;
      } else {
         return this.team != null ? this.team.difficultyParams : BotSettings.difficultyParams;
      }
   }

   public boolean revengeMode() {
      return this.team != null ? this.team.revengeMode : BotSettings.revengeMode;
   }

   public boolean useCarting() {
      return this.team != null ? this.team.useCarting : BotSettings.useCarting;
   }

   public BotSettings.BridgeMode bridgeMode() {
      return this.team != null ? this.team.bridgeMode : BotSettings.bridgeMode;
   }

   public double attackRange() {
      return this.team != null ? this.team.attackRange : BotSettings.attackRange;
   }

   public BotSettings.CartMode cartMode() {
      return this.team != null ? this.team.cartMode : BotSettings.cartMode;
   }

   public boolean ignoreCreative() {
      return this.team != null ? this.team.ignoreCreative : BotSettings.ignoreCreative;
   }

   public boolean useEnderPearl() {
      return this.team != null ? this.team.useEnderPearl : BotSettings.useEnderPearl;
   }

   public boolean pearlChasing() {
      return this.team != null ? this.team.pearlChasing : BotSettings.pearlChasing;
   }

   public boolean botLeaveOnDeath() {
      return this.team != null ? this.team.botLeaveOnDeath : BotSettings.botLeaveOnDeath;
   }

   public boolean useScaffolding() {
      return this.team != null ? this.team.useScaffolding : BotSettings.useScaffolding;
   }

   public boolean chorusEscape() {
      return this.team != null ? this.team.chorusEscape : BotSettings.chorusEscape;
   }

   public boolean fireEscape() {
      return this.team != null ? this.team.fireEscape : BotSettings.fireEscape;
   }

   public boolean shulkerSteal() {
      return this.team != null ? this.team.shulkerSteal : BotSettings.shulkerSteal;
   }

   public boolean spreadOut() {
      return this.team != null ? this.team.spreadOut : BotSettings.spreadOut;
   }

   public boolean shulkerRegear() {
      return this.team != null ? this.team.shulkerRegear : BotSettings.shulkerRegear;
   }

   public boolean enderChestRegear() {
      return this.team != null ? this.team.enderChestRegear : BotSettings.enderChestRegear;
   }

   public boolean webEscape() {
      return this.team != null ? this.team.webEscape : BotSettings.webEscape;
   }

   public boolean waterBucketClutch() {
      return this.team != null ? this.team.waterBucketClutch : BotSettings.waterBucketClutch;
   }

   public boolean hitWeb() {
      return this.team != null ? this.team.hitWeb : BotSettings.hitWeb;
   }

   public boolean pickupLoot() {
      return this.team != null ? this.team.pickupLoot : BotSettings.pickupLoot;
   }

   public int botPing() {
      return this.team != null ? this.team.botPing : BotSettings.botPing;
   }

   public boolean speedNoJump() {
      return this.team != null ? this.team.speedNoJump : BotSettings.speedNoJump;
   }

   public boolean maceTotem() {
      return this.team != null ? this.team.maceTotem : BotSettings.maceTotem;
   }

   public boolean chaseSpread() {
      return this.team != null ? this.team.chaseSpread : BotSettings.chaseSpread;
   }

   public boolean placeBlocksMoving() {
      return this.team != null ? this.team.placeBlocksMoving : BotSettings.placeBlocksMoving;
   }

   public double buildUpMinHeight() {
      return this.team != null ? this.team.buildUpMinHeight : BotSettings.buildUpMinHeight;
   }

   public double lootPackRadius() {
      return this.team != null ? this.team.lootPackRadius : BotSettings.lootPackRadius;
   }

   public BotSettings.HealingMode healingMode() {
      return this.team != null ? this.team.healingMode : BotSettings.healingMode;
   }

   public BotSettings.OffhandPreference offhandPreference() {
      return this.team != null ? this.team.offhandPreference : BotSettings.offhandPreference;
   }

   public double offhandTotemHearts() {
      return this.team != null ? this.team.offhandTotemHearts : BotSettings.offhandTotemHearts;
   }

   public boolean strafeInCombo() {
      return this.team != null ? this.team.strafeInCombo : BotSettings.strafeInCombo;
   }

   public BotSettings.CartDoctrine cartDoctrine() {
      return this.team != null ? this.team.cartDoctrine : BotSettings.cartDoctrine;
   }

   public boolean useBows() {
      return this.team != null ? this.team.useBows : BotSettings.useBows;
   }

   public boolean useOrbitalStrike() {
      return this.team != null ? this.team.useOrbitalStrike : BotSettings.useOrbitalStrike;
   }

   public double retreatHealthHearts() {
      double base = this.team != null ? this.team.retreatHealthHearts : BotSettings.retreatHealthHearts;
      double var10000;
      switch (this.playStyle) {
         case SAFE -> var10000 = Math.min((double)10.0F, base + (double)3.0F);
         case DEFENSIVE -> var10000 = Math.min((double)10.0F, base + (double)1.5F);
         case AGGRESSIVE -> var10000 = Math.max((double)1.0F, base * (double)0.5F);
         default -> var10000 = base;
      }

      return var10000;
   }

   public boolean wanderWhenIdle() {
      return this.team != null ? this.team.wanderWhenIdle : BotSettings.wanderWhenIdle;
   }

   public boolean riptideAnywhere() {
      return this.team != null ? this.team.riptideAnywhere : BotSettings.riptideAnywhere;
   }

   public boolean useElytraMace() {
      return this.team != null ? this.team.useElytraMace : BotSettings.useElytraMace;
   }

   public boolean useElytraSpear() {
      return this.team != null ? this.team.useElytraSpear : BotSettings.useElytraSpear;
   }

   public boolean useSpearDash() {
      return this.techniques().spearDash;
   }

   public boolean useStunSlam() {
      return this.techniques().stunSlam;
   }

   public boolean useWebDrain() {
      return this.team != null ? this.team.useWebDrain : BotSettings.useWebDrain;
   }

   public int webDrainChance() {
      return this.team != null ? this.team.webDrainChance : BotSettings.webDrainChance;
   }

   public int jumpResetChance() {
      return this.team != null ? this.team.jumpResetChance : BotSettings.jumpResetChance;
   }

   public int counterStunChance() {
      return this.team != null ? this.team.counterStunChance : BotSettings.counterStunChance;
   }

   public int stunSlamChance() {
      return this.difficultyParams().stunSlamChance;
   }

   public boolean shieldOnMaceDive() {
      return this.team != null ? this.team.shieldOnMaceDive : BotSettings.shieldOnMaceDive;
   }

   public boolean fastShieldCooldown() {
      return this.team != null ? this.team.fastShieldCooldown : BotSettings.fastShieldCooldown;
   }

   public boolean usePearlCatch() {
      return this.techniques().pearlCatch;
   }

   public TechniqueConfig.PearlCatchVariant pearlCatchType() {
      return this.techniques().pearlCatchVariant;
   }

   public boolean elytraGlide() {
      return this.techniques().pearlCatchGlide;
   }

   public TechniqueConfig techniques() {
      return this.team != null ? this.team.techniques : BotSettings.techniques;
   }

   public float getAccuracy() {
      return (float)this.difficultyParams().accuracy;
   }

   public boolean roll() {
      return ThreadLocalRandom.current().nextDouble() < (double)this.getAccuracy();
   }

   public float getClutchAccuracy() {
      return (float)this.difficultyParams().clutchAccuracy;
   }

   public boolean rollClutch() {
      return ThreadLocalRandom.current().nextDouble() < (double)this.getClutchAccuracy();
   }

   public boolean rollWebDrain() {
      if (!this.useWebDrain()) {
         return false;
      } else {
         int chance = this.webDrainChance();
         if (chance <= 0) {
            return false;
         } else if (chance >= 100) {
            return true;
         } else {
            return ThreadLocalRandom.current().nextDouble() * (double)100.0F < (double)chance;
         }
      }
   }

   public boolean rollJumpReset() {
      int chance = this.jumpResetChance();
      if (chance <= 0) {
         return false;
      } else if (chance >= 100) {
         return true;
      } else {
         return ThreadLocalRandom.current().nextDouble() * (double)100.0F < (double)chance;
      }
   }

   public boolean rollCounterStun() {
      int chance = this.counterStunChance();
      if (chance <= 0) {
         return false;
      } else if (chance >= 100) {
         return true;
      } else {
         return ThreadLocalRandom.current().nextDouble() * (double)100.0F < (double)chance;
      }
   }

   public boolean rollStunSlamChanceOnly() {
      int chance = this.stunSlamChance();
      if (chance <= 0) {
         return false;
      } else if (chance >= 100) {
         return true;
      } else {
         return ThreadLocalRandom.current().nextDouble() * (double)100.0F < (double)chance;
      }
   }

   public boolean rollStunSlam() {
      if (!this.useStunSlam()) {
         return false;
      } else {
         int chance = this.stunSlamChance();
         if (chance <= 0) {
            return false;
         } else if (chance >= 100) {
            return true;
         } else {
            return ThreadLocalRandom.current().nextDouble() * (double)100.0F < (double)chance;
         }
      }
   }
}
